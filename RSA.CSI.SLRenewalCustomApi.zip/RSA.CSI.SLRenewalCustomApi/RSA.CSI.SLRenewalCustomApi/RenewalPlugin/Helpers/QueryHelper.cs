﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;

namespace RSA.CSI.SLRenewalCustomApi.RenewalPlugin.Helpers
{
    public static class QueryHelper
    {
        public static bool RenewalOppExists(
            IOrganizationService service,
            Guid policyId)
        {
            var query = new QueryExpression("rsa_slopportunity")
            {
                ColumnSet = new ColumnSet("rsa_slopportunityid"),
                TopCount = 1
            };
            query.Criteria.AddCondition(
                "rsa_policy", ConditionOperator.Equal, policyId);
            query.Criteria.AddCondition(
                "rsa_opportunitystage", ConditionOperator.Equal, 866760012);

            return service.RetrieveMultiple(query).Entities.Count > 0;
        }

        public static Entity GetPriorOpportunity(
            IOrganizationService service,
            Guid policyId)
        {
            var query = new QueryExpression("rsa_slopportunity")
            {
                ColumnSet = new ColumnSet(true),
                TopCount = 1
            };
            query.Criteria.AddCondition(
                "rsa_policy", ConditionOperator.Equal, policyId);
            query.Criteria.AddCondition(
                "rsa_opportunitystage", ConditionOperator.Equal, 866760000);

            query.AddOrder("createdon", OrderType.Descending);

            var results = service.RetrieveMultiple(query).Entities;
            return results.Count > 0 ? results[0] : null;
        }

        public static Entity GetConfig(
            IOrganizationService service,
            Guid configId)
        {
            return service.Retrieve("rsa_slrenewalconfig", configId,
                new ColumnSet(
                    "rsa_name",
                    "rsa_policyfilterfetchxml",
                    "rsa_topopulateattributelist"));
        }

        public static List<string> ParseAttributeList(string attributeList)
        {
            if (string.IsNullOrWhiteSpace(attributeList))
                return new List<string>();

            return attributeList
                .Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(a => a.Trim().ToLower())
                .ToList();
        }

        public static Entity GetPolicy(
            IOrganizationService service,
            Guid policyId)
        {
            return service.Retrieve("rsa_policy", policyId,
                new ColumnSet(
                    "rsa_policyexpirydate",
                    "rsa_policystartdate",
                    "rsa_productid"));
        }
    }
}