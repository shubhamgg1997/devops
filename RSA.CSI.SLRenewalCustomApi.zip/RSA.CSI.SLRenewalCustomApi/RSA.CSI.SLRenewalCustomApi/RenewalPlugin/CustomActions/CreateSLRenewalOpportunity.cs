﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using RSA.CSI.SLRenewalCustomApi.RenewalPlugin.Helpers;
using System;
using System.Linq;

namespace RSA.CSI.SLRenewalCustomApi.RenewalPlugin.CustomActions
{
    public class CreateRenewalOpportunity : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            var context = (IPluginExecutionContext)serviceProvider
                .GetService(typeof(IPluginExecutionContext));
            var serviceFactory = (IOrganizationServiceFactory)serviceProvider
                .GetService(typeof(IOrganizationServiceFactory));
            var service = serviceFactory
                .CreateOrganizationService(context.UserId);
            var trace = (ITracingService)serviceProvider
                .GetService(typeof(ITracingService));

            try
            {
                trace.Trace("CreateRenewalOpportunity started");
                // ── 1. Validate input parameters ──────────────────────
                if (!context.InputParameters.Contains("PolicyId") ||
                    !context.InputParameters.Contains("ConfigId"))
                    throw new InvalidPluginExecutionException(
                        "PolicyId and ConfigId are required.");

                // Handle both string and EntityReference input types
                Guid policyId;
                Guid configId;

                var policyInput = context.InputParameters["PolicyId"];
                var configInput = context.InputParameters["ConfigId"];

                // PolicyId
                if (policyInput is EntityReference policyRef)
                    policyId = policyRef.Id;
                else if (policyInput is string policyStr)
                    policyId = new Guid(policyStr);
                else
                    throw new InvalidPluginExecutionException(
                        "PolicyId must be a GUID string or EntityReference.");

                // ConfigId
                if (configInput is EntityReference configRef)
                    configId = configRef.Id;
                else if (configInput is string configStr)
                    configId = new Guid(configStr);
                else
                    throw new InvalidPluginExecutionException(
                        "ConfigId must be a GUID string or EntityReference.");

                trace.Trace($"PolicyId: {policyId}, ConfigId: {configId}");

                // ── 2. Duplicate check ─────────────────────────────────
                if (QueryHelper.RenewalOppExists(service, policyId))
                {
                    trace.Trace("Renewal opp already exists - skipping");
                    context.OutputParameters["Result"] = "SKIPPED";
                    context.OutputParameters["NewOpportunityId"] = string.Empty;
                    return;
                }

                // ── 3. Get config record and parse fields to carry ─────
                var config = service.Retrieve(
                    "rsa_slrenewalconfig",
                    configId,
                    new ColumnSet(
                        "rsa_newcolumn",
                        "rsa_topopulateattributelist"));

                var attributeListRaw = config
                    .GetAttributeValue<string>("rsa_topopulateattributelist");

                if (string.IsNullOrWhiteSpace(attributeListRaw))
                    throw new InvalidPluginExecutionException(
                        $"Config record {configId} has no fields configured " +
                        $"in ToPopulateAttributeList.");

                var fieldsToCarry = attributeListRaw
                    .Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(f => f.Trim().ToLower())
                    .ToList();

                trace.Trace($"Config: {config.GetAttributeValue<string>("rsa_newcolumn")}");
                trace.Trace($"Fields to carry ({fieldsToCarry.Count}): " +
                    $"{string.Join(", ", fieldsToCarry)}");

                // ── 4. Get prior opportunity ───────────────────────────
                var priorOpp = QueryHelper.GetPriorOpportunity(
                    service, policyId);

                if (priorOpp == null)
                {
                    trace.Trace("No prior accepted opp found - skipping");
                    context.OutputParameters["Result"] = "NO_PRIOR_OPP";
                    context.OutputParameters["NewOpportunityId"] = string.Empty;
                    return;
                }

                trace.Trace($"Prior opp found: {priorOpp.Id}");

                // ── 5. Get policy record ───────────────────────────────
                var policy = QueryHelper.GetPolicy(service, policyId);

                // ── 6. Build new opportunity ───────────────────────────
                var newOpp = new Entity("rsa_slopportunity");

                // Always set
                newOpp["rsa_policy"] = new EntityReference("rsa_policy", policyId);
                newOpp["rsa_opportunitystage"] = new OptionSetValue(866760012);

                // Core fields - all from PRIOR OPP not policy
                CarryField(newOpp, priorOpp, "rsa_gbm", trace);
                CarryField(newOpp, priorOpp, "rsa_pl", trace);
                CarryField(newOpp, priorOpp, "rsa_customer", trace);
                CarryField(newOpp, priorOpp, "rsa_underwritertrader", trace);
                CarryField(newOpp, priorOpp, "rsa_brokername", trace);
                CarryField(newOpp, priorOpp, "rsa_brokertargetpremiumpc", trace);
                CarryField(newOpp, priorOpp, "rsa_uboname1", trace);

                // New policy dates - ONLY these come from policy record
                if (policy.Contains("rsa_policyexpirydate"))
                {
                    var currentExpiry = (DateTime)policy["rsa_policyexpirydate"];
                    newOpp["rsa_policystartdate"] = currentExpiry.AddDays(1);
                    newOpp["rsa_policyexpirydate"] = currentExpiry.AddYears(1);

                    trace.Trace($"Policy start: {currentExpiry.AddDays(1):d}");
                    trace.Trace($"Policy expiry: {currentExpiry.AddYears(1):d}");
                }

                // ── 7. Carry fields from config attribute list ─────────
                foreach (var fieldName in fieldsToCarry)
                {
                    // Skip if already set as a core field above
                    if (newOpp.Contains(fieldName))
                    {
                        trace.Trace($"Already set, skipping: {fieldName}");
                        continue;
                    }

                    CarryField(newOpp, priorOpp, fieldName, trace);
                }

                // ── 8. Create the record ───────────────────────────────
                var newOppId = service.Create(newOpp);
                trace.Trace($"Renewal opp created: {newOppId}");

                // ── 10. Update policy renewal date to next year ────────
                if (policy.Contains("rsa_policyexpirydate"))
                {
                    var policyUpdate = new Entity("rsa_policy", policyId);
                    var newRenewalDate =
                        ((DateTime)policy["rsa_policyexpirydate"]).AddYears(1);

                    policyUpdate["rsa_policyrenewaldate"] = newRenewalDate;
                    service.Update(policyUpdate);

                    trace.Trace($"Policy renewal date updated to: {newRenewalDate:d}");
                }

                context.OutputParameters["Result"] = "CREATED";
                context.OutputParameters["NewOpportunityId"] = newOppId.ToString();
            }
            catch (InvalidPluginExecutionException)
            {
                throw;
            }
            catch (Exception ex)
            {
                trace.Trace($"Error: {ex.Message}\n{ex.StackTrace}");
                throw new InvalidPluginExecutionException(
                    $"CreateRenewalOpportunity failed: {ex.Message}", ex);
            }
        }

        private void CarryField(
            Entity target,
            Entity source,
            string fieldName,
            ITracingService trace)
        {
            if (source.Contains(fieldName) && source[fieldName] != null)
            {
                target[fieldName] = source[fieldName];
                trace.Trace($"Carried: {fieldName}");
            }
            else
            {
                trace.Trace($"Not found or null: {fieldName}");
            }
        }
    }
}