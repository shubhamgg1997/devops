﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSA.CSI.SLRenewalCustomApi.RenewalPlugin.Models
{
    
        public class FieldConfigModel
        {
            public string FieldLogicalName { get; set; }
            public bool IsCommon { get; set; }
            public int? LineType { get; set; }
        }
    
}
