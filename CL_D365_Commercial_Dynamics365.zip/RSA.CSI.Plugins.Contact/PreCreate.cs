﻿using System;
using Microsoft.Xrm.Sdk;
using RSA.CSI.Plugins.Contact.Common;
using RSA.CSI.Plugins.Contact.Logic;

namespace RSA.CSI.Plugins.Contact
{
    public class PreCreate : PluginBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PreCreate"/> class.
        /// </summary>
        public PreCreate()
            : base(typeof(PreCreate))
        {
            RegisteredEvents.Add(new Tuple<int, string, string, Action<LocalPluginContext>>(20, "Create", "contact", ExecuteContactPreCreate));
        }

        /// <summary>
        /// Start Validating the record when the regsiterd event occurs
        /// </summary>
        /// <param name="localContext"></param>
        protected void ExecuteContactPreCreate(LocalPluginContext localContext)
        {
            #region Generic block of Context null checking and service creation block

            if (localContext == null)
            {
                //throw new ArgumentNullException("localContext");
                //Remediation - 19/07/2022
                throw new InvalidPluginExecutionException("localContext");
            }
            IPluginExecutionContext context = localContext.PluginExecutionContext;
            IOrganizationService service = localContext.OrganizationService;
            ITracingService tracingService = localContext.TracingService;
            #endregion Generic block of Context null checking and service creation block  
            //test Save

            #region Get Input Parameters

            if (context.InputParameters["Target"] != null && (Entity)context.InputParameters["Target"] != null)
            {
                try
                {
                    var enContactTarget = context.InputParameters["Target"] as Entity;
                    tracingService.Trace("Calling PreCreateLogic()");
                    PreCreateLogic preCreate = new PreCreateLogic(service, tracingService, enContactTarget);
                    preCreate.Execute();
                    tracingService.Trace("Successfully completed Contact Pre Create plugin");
                }
                catch (Exception ex)
                {
                    tracingService.Trace("Exception: " + ex.Message);
                    throw new InvalidPluginExecutionException("ExecuteContactPreCreatePlugin: " + ex.Message);
                }
            }
            else
            {
                tracingService.Trace("Target is null in PreCreate");
                throw new InvalidPluginExecutionException("Target is null in PreCreate");
            }

            #endregion  Get Input Parameters
        }
    }
}
