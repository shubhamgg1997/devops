﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;

namespace RSA.CSI.Plugins.Contact.Logic
{
    internal class PreCreateLogic
    {
        IOrganizationService service = null;
        ITracingService tracingService = null;
        Entity enContactTarget = null;


        #region Constructor 
        internal PreCreateLogic(IOrganizationService cService, ITracingService cTracingService,Entity cEnContactTarget)
        {
            service = cService;
            tracingService = cTracingService;
            enContactTarget = cEnContactTarget;

        }
        #endregion Constructor


        internal void Execute()
        {
            tracingService.Trace("In Execute Method");
            if(enContactTarget.Attributes.Contains("rsa_accountid") && enContactTarget.Attributes["rsa_accountid"] != null)
            {
                tracingService.Trace("AccountId contains data");
                string primaryReference = getAccountDetails(((EntityReference)enContactTarget.Attributes["rsa_accountid"]).Id);
                tracingService.Trace("primaryReference: " + primaryReference);
                if (!string.IsNullOrEmpty(primaryReference))
                {
                    string externalID = string.Empty;
                    externalID = primaryReference;

                    if(enContactTarget.Attributes.Contains("firstname") && !string.IsNullOrEmpty(enContactTarget.Attributes["firstname"].ToString()))
                    {
                        externalID = externalID + ":" + enContactTarget.Attributes["firstname"].ToString();
                        tracingService.Trace("First name contains data so externalID : " + externalID);
                        if (enContactTarget.Attributes.Contains("lastname") && !string.IsNullOrEmpty(enContactTarget.Attributes["lastname"].ToString()))
                        {
                            externalID = externalID + " " + enContactTarget.Attributes["lastname"].ToString();
                            tracingService.Trace("Last name contains data so externalID : " + externalID);
                        }
                    }
                    else if(enContactTarget.Attributes.Contains("lastname") && !string.IsNullOrEmpty(enContactTarget.Attributes["lastname"].ToString()))
                    {
                        externalID = externalID + ":" + enContactTarget.Attributes["lastname"].ToString();
                        tracingService.Trace("First name null and Last name contains data so externalID : " + externalID);
                    }

                    enContactTarget["rsa_externalid"] = externalID;
                    tracingService.Trace("Set External Id");

                }
            }
        }

        private string getAccountDetails(Guid accountId)
        {
            string primaryReference = string.Empty;
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='account'>
                                    <attribute name='name' />
                                    <attribute name='rsa_primaryreference' />
                                    <order attribute='name' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='accountid' operator='eq' value='{0}' />
                                    </filter>
                                  </entity>
                                </fetch>";
            var entityAccount = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, accountId)));
            if (entityAccount.Entities.Count > 0)
            {
                primaryReference = entityAccount[0].Attributes.Contains("rsa_primaryreference") ? entityAccount[0].GetAttributeValue<string>("rsa_primaryreference") : string.Empty;
            }
            return primaryReference;
        }
    }
}