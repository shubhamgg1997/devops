﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSA.User.UserTeamLevel
{
    public class UpdateUserLookupOnAssociate : IPlugin
    {
        private const string RELATIONSHIP_SCHEMA = "new_rsa_userteamlevel2_systemuser";
        private const string USER_LOOKUP_FIELD = "rsa_userteamlevel2";
        private const string CUSTOM_ENTITY = "rsa_userteamlevel2";
        
        public void Execute(IServiceProvider serviceProvider)
        {
            var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            var serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            var service = serviceFactory.CreateOrganizationService(context.UserId);
            var tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            tracing.Trace("AssociateUserUpdateLookup STARTED");
            try
            {
                if (!context.MessageName.Equals("Associate", StringComparison.OrdinalIgnoreCase))
                    return;          
                if (!context.InputParameters.Contains("Relationship"))
                    return;
                var relationship = (Relationship)context.InputParameters["Relationship"];
                tracing.Trace("Relationship: {0}", relationship.SchemaName);
                if (!relationship.SchemaName.Equals(RELATIONSHIP_SCHEMA, StringComparison.OrdinalIgnoreCase))
                    return;            
                if (!context.InputParameters.Contains("Target"))
                    return;
                var target = (EntityReference)context.InputParameters["Target"];
                if (!target.LogicalName.Equals(CUSTOM_ENTITY, StringComparison.OrdinalIgnoreCase))
                    return;               
                if (!context.InputParameters.Contains("RelatedEntities"))
                    return;
                var relatedEntities =
                    (EntityReferenceCollection)context.InputParameters["RelatedEntities"];
                foreach (var userRef in relatedEntities)
                {
                    if (!userRef.LogicalName.Equals("systemuser", StringComparison.OrdinalIgnoreCase))
                        continue;
                    tracing.Trace("Updating lookup for user: {0}", userRef.Id);                   
                    var userUpdate = new Entity("systemuser", userRef.Id);
                    userUpdate[USER_LOOKUP_FIELD] = new EntityReference(
                        CUSTOM_ENTITY,
                        target.Id
                    );
                    service.Update(userUpdate);
                }
            }
            catch (Exception ex)
            {
                tracing.Trace("UpdateUserLookupOnAssociate Error: {0}", ex.ToString());
                throw new InvalidPluginExecutionException("Error updating user lookup on relationship associate.", ex);
            }
        }
    }
}
