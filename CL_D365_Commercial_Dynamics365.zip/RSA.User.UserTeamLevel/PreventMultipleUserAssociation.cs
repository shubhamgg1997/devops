﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace RSA.User.UserTeamLevel
{
    public class PreventMultipleUserAssociation : IPlugin
    {
        private const string RELATIONSHIP_SCHEMA = "new_rsa_userteamlevel2_systemuser";

        private const string CUSTOM_ENTITY = "rsa_userteamlevel2";
        public void Execute(IServiceProvider serviceProvider)
        {
            var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

            var serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));

            var service = serviceFactory.CreateOrganizationService(context.UserId);

            var tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            tracing.Trace("AssociateUserValidation STARTED");
            try

            {
         
                if (!context.MessageName.Equals("Associate", StringComparison.OrdinalIgnoreCase))
                    return;           
                if (!context.InputParameters.Contains("Relationship"))
                    return;
                var relationship = (Relationship)context.InputParameters["Relationship"];
                tracing.Trace("Relationship Schema: {0}", relationship.SchemaName);
                if (!relationship.SchemaName.Equals(RELATIONSHIP_SCHEMA, StringComparison.OrdinalIgnoreCase))
                    return;               
                if (!context.InputParameters.Contains("Target"))
                    return;
                var target = (EntityReference)context.InputParameters["Target"];
                tracing.Trace("Target Entity: {0}", target.LogicalName);
                if (!target.LogicalName.Equals(CUSTOM_ENTITY, StringComparison.OrdinalIgnoreCase))
                    return;  
                if (!context.InputParameters.Contains("RelatedEntities"))
                    return;
                var relatedEntities =
                    (EntityReferenceCollection)context.InputParameters["RelatedEntities"];
                if (relatedEntities == null || relatedEntities.Count == 0)
                    return;
                foreach (var userRef in relatedEntities)
                {
                    if (!userRef.LogicalName.Equals("systemuser", StringComparison.OrdinalIgnoreCase))
                        return;
                    tracing.Trace("Validating user: {0}", userRef.Id);          
                    var user = service.Retrieve(
                    "systemuser",
                    userRef.Id,
                    new ColumnSet("rsa_userteamlevel2")

                );
                    if (user.Contains("rsa_userteamlevel2") && user["rsa_userteamlevel2"] != null)

                    {
                        throw new InvalidPluginExecutionException(

                            "This user is already associated with a record. Remove the user from the existing record before adding to a new one."

                        );

                    }
                }
            }
            catch (InvalidPluginExecutionException)

            {        

                throw;

            }
            catch (Exception ex)

            {

                tracing.Trace("PreventMultipleUserAssociations Error: {0}", ex.ToString());

                throw new InvalidPluginExecutionException(

                    "Unexpected error while validating user association.", ex);

            }
        }
    }
}
