﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSA.CSI.Plugins.EuroOpportunity
{
    public class InceptionYearPreUpdate : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
          
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                if(context.Depth > 1)   { return;  }

                if (context.InputParameters.Contains("Target") &&
                       context.InputParameters["Target"] is Entity)
                {
                    tracingService.Trace("Entity Target");
                    Entity entity = (Entity)context.InputParameters["Target"];
                    DateTime dtInceptionDate = entity.GetAttributeValue<DateTime>("rsa_inceptiondate");
                    if (dtInceptionDate != null)
                    {
                        //Adding 700 Minutes to handle alll the regions with plus and minus time zone offsets
                        dtInceptionDate = dtInceptionDate.AddMinutes(700);
                        entity["rsa_inceptionmonthnew"] = Convert.ToString(dtInceptionDate.Date.Month);
                        entity["rsa_inceptionyearnew"] = Convert.ToString(dtInceptionDate.Date.Year);
                        //Modified on : 03/03/2022; Modified By: Nida ; Defect : 1952 ; issue : duplicate Email trigger
                        tracingService.Trace("Inception Date Not Null");
                        //service.Update(entity);
                    }
                }
                
            }
            catch (InvalidPluginExecutionException e)
            {
                // catch exception
                tracingService.Trace("Exception Happened");
                throw new InvalidPluginExecutionException("An error has occurred: " + e.Message);
            }
        } 
        
    }
}



