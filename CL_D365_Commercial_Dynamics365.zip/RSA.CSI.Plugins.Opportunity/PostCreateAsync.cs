﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using RSA.CSI.Plugins.Opportunity.Common;
using RSA.CSI.Plugins.Opportunity.Logic;
using static RSA.CSI.Plugins.Opportunity.Helper.Constants;

namespace RSA.CSI.Plugins.Opportunity
{
    public class PostCreateAsync : PluginBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PostCreateAsync"/> class.
        /// </summary>
        public PostCreateAsync()
            : base(typeof(PostCreateAsync))
        {
            base.RegisteredEvents.Add(new Tuple<int, string, string, Action<LocalPluginContext>>(40, "Create", "opportunity", Execute));
        }

        /// <summary>
        /// Execute
        /// </summary>
        /// <param name="localContext"></param>
        protected void Execute(LocalPluginContext localContext)
        {
            #region Generic block of Context null checking and service creation block
            if (localContext == null)
            {
                //throw new ArgumentNullException("localContext");
                //Remediation - 20/07/2022
                throw new InvalidPluginExecutionException("localContext");
            }
            IPluginExecutionContext context = localContext.PluginExecutionContext;
            IOrganizationService service = localContext.OrganizationService;
            ITracingService tracingService = localContext.TracingService;
            #endregion

            tracingService.Trace("Triggered RSA.CSI.Plugins.Opportunity.PostCreateAsync=>Execute() method.");
            RenewalGenerationLogic renewalGenerationLogic = new RenewalGenerationLogic();
            renewalGenerationLogic.Execute(context, service, tracingService);
        }
    }
}