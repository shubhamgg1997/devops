﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using RSA.CSI.Plugins.Opportunity.Helper;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;
using static RSA.CSI.Plugins.Opportunity.Helper.Constants;

namespace RSA.CSI.Plugins.Opportunity.Logic
{
    internal class RenewalGenerationLogic
    {
        /// <summary>
        /// Execute
        /// </summary>
        /// <param name="context"></param>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        public void Execute(IPluginExecutionContext context, IOrganizationService service, ITracingService tracingService)
        {
            tracingService.Trace("RSA.CSI.Plugins.Opportunity.RenewalGenerationHelper=>Execute(updated) -  Loaded");
            ColumnSet csOpportunity = new ColumnSet(EnOpportunity.Id, EnOpportunity.Broker, EnOpportunity.Customer, EnOpportunity.DataOrigin, EnOpportunity.name, EnOpportunity.PolicyId, EnOpportunity.rsa_expiringpremium);

            Entity enOpportunity = null;
            enOpportunity = service.Retrieve(context.PrimaryEntityName, context.PrimaryEntityId, csOpportunity);
            if (enOpportunity == null)
            {
                tracingService.Trace("Opportunity fetch has failed.");
                return;
            }
            tracingService.Trace("Opportunity has fetched successfully.");

            Boolean bIsValidTrigger = this.IsValidTrigger(tracingService, enOpportunity);
            if (!bIsValidTrigger)
            {
                tracingService.Trace("This is NOT a valid trigger and Opportunity has NOT come from Renewal Generation process.");
                return;
            }
            tracingService.Trace("This is a valid trigger and Opportunity has come from Renewal Generation process.");

            ColumnSet csPolicy = new ColumnSet(EnPolicy.Id, EnPolicy.rsa_broker, EnPolicy.rsa_classofbusiness, EnPolicy.rsa_customer, EnPolicy.rsa_renewalgenerationid, EnPolicy.rsa_reviewtypecode, EnPolicy.rsa_operationshandlingsite, EnPolicy.rsa_tradinghandlingsite, EnPolicy.rsa_plcode);

            Entity enPolicy = null;
            enPolicy = service.Retrieve(EnPolicy.LogicalName, ((EntityReference)enOpportunity[EnOpportunity.PolicyId]).Id, csPolicy);
            if (enPolicy == null)
            {
                tracingService.Trace("Policy fetch has failed.");
                return;
            }
            tracingService.Trace("Policy has fetched successfully.");
            string policy_plName = string.Empty;
            if(((EntityReference)enPolicy[EnPolicy.rsa_plcode]).Name != string.Empty)
            {
                policy_plName = ((EntityReference)enPolicy[EnPolicy.rsa_plcode]).Name;
            }

            //Renewal Marine London Flow
            if(policy_plName.ToLower().Contains("marine") && (policy_plName.ToLower().Contains("london") || policy_plName.ToLower().Contains("regional")))
            {
                tracingService.Trace("This is Renewal Marine London/ Renewal Marine Regional flow so case will not be created");
            }
            else
            {
                this.CreateCase(service, tracingService, enOpportunity, enPolicy);
            }            
            tracingService.Trace("RSA.CSI.Plugins.Opportunity.RenewalGenerationHelper=>Execute(updated) -  Unloaded");
        }

        /// <summary>
        /// CreateCase
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="enOpportuntiy"></param>
        /// <param name="enPolicy"></param>
        private void CreateCase(IOrganizationService service, ITracingService tracingService, Entity enOpportuntiy, Entity enPolicy)
        {
            tracingService.Trace("Entered RSA.CSI.Plugins.Opportuntiy=>CreateCase() method.");
            Guid guidEmpty = Guid.Empty;
            string strEmpty = string.Empty;
            string promiseNewBusiness = null;
            string promiseRenewal = null;
            var enColTradingThresold = new EntityCollection(null);
            EntityReference BrokerFromPolicy = new EntityReference();
            var ms = Stream.Null;
            //var guidCaseStatusId = this.GetCaseStatusForRenewal(service, tracingService, NEW_RENEWAL_CASE_STATUS);
            try
            {
                tracingService.Trace($"EnCase.LogicalName: {EnCase.LogicalName}");
                Entity enCase = new Entity(EnCase.LogicalName);

                if (enPolicy.Attributes.Contains("rsa_broker"))
                {
                    tracingService.Trace($"enPolicy['rsa_broker'].Name: {((EntityReference)enPolicy.Attributes["rsa_broker"]).Name} & enPolicy['rsa_broker'].Id: {((EntityReference)enPolicy.Attributes["rsa_broker"]).Id}");
                    enCase["rsa_account"] = enPolicy.Attributes["rsa_broker"];
                    enCase["customerid"] = enPolicy.Attributes["rsa_broker"];
                    
                    BrokerFromPolicy = enPolicy.GetAttributeValue<EntityReference>("rsa_broker");
                    if (BrokerFromPolicy != null)
                    {
                        //Entity BrokerData = service.Retrieve(BrokerFromPolicy.LogicalName, BrokerFromPolicy.Id, new ColumnSet(new string[] { "rsa_promisenewbusiness", "rsa_promiserenewal" }));
                        //promiseNewBusiness = BrokerData.FormattedValues.ContainsKey("rsa_promisenewbusiness") ? BrokerData.FormattedValues["rsa_promisenewbusiness"] : null;
                        //tracingService.Trace("promise new business broker from broker value" + promiseNewBusiness);
                        //promiseRenewal = BrokerData.FormattedValues.ContainsKey("rsa_promiserenewal") ? BrokerData.FormattedValues["rsa_promiserenewal"] : null;
                        //tracingService.Trace("promise renewal broker from broker value" + promiseRenewal);
                    }
                }


                if (enPolicy.Attributes.Contains("rsa_classofbusiness") && enPolicy.Attributes.Contains("rsa_tradinghandlingsite"))
                {
                    QueryExpression condition = new QueryExpression("rsa_customlabel");
                    condition.TopCount = 1;
                    condition.NoLock = true;
                    condition.ColumnSet = new ColumnSet(new string[] { "rsa_dependentoptionsetjson" });
                    condition.Criteria = new FilterExpression();
                    condition.Criteria.AddCondition("rsa_name", ConditionOperator.Equal, "Policy_To_TradingThreshold_Site_Mapping");
                    EntityCollection siteMappingResult = service.RetrieveMultiple(condition);
                    string dependentOptionset = string.Empty;

                    ////// To BE REMOVED ////////
                    //enCase["rsa_traded"] = new OptionSetValue(866760001);
                    //////////////////////////////

                    foreach (var item in siteMappingResult.Entities)
                    {
                        dependentOptionset = Convert.ToString(item.Attributes["rsa_dependentoptionsetjson"]);
                    }

                    // tracingService.Trace("Custom Label Mapping retrieved: Trading Thrishold Mapping" + dependentOptionset);

                    var objsiteRoot = new SiteRoot();
                    //var ms = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(dependentOptionset));
                    //var ser = new DataContractJsonSerializer(objsiteRoot.GetType());
                    //objsiteRoot = ser.ReadObject(ms) as SiteRoot;
                    //ms.Close();
                    //Remediation - 21/07/2022
                    ms = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(dependentOptionset));
                    var ser = new DataContractJsonSerializer(objsiteRoot.GetType());
                    objsiteRoot = ser.ReadObject(ms) as SiteRoot;
                    tracingService.Trace("After Close");
                    if (objsiteRoot != null)
                    {
                        if (objsiteRoot.Site != null)
                        {
                            //Get the broker primary reference value to compare and get the ABR. 
                            Site objRS = objsiteRoot.Site.Find(a => a.PolicySite.ToLower().Equals((enPolicy.GetAttributeValue<OptionSetValue>("rsa_tradinghandlingsite").Value).ToString()));
                            if (objRS.ThresoldSite != string.Empty)
                            {
                                tracingService.Trace($"enPolicy['rsa_tradinghandlingsite'].Name:" + objRS.ThresoldSite);
                                string fetchXML = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                      <entity name='rsa_tradingthreshold'>
                                        <attribute name='rsa_name' />                                       
                                        <attribute name='rsa_classofbusiness' />
                                        <attribute name='rsa_tradingthresholdid' />
                                        <attribute name='rsa_renewaltradingthreshold' />
                                        <attribute name='rsa_renewalpromisethreshold' />
                                        <order attribute='rsa_name' descending='false' />
                                        <filter type='and'>
                                          <condition attribute='rsa_office' operator='eq' value='" + objRS.ThresoldSite.ToString() + @"' />
                                        </filter>
                                        <link-entity name='rsa_classofbusiness' from='rsa_classofbusinessid' to='rsa_classofbusiness' link-type='inner' alias='ad'>
                                          <filter type='and'>
                                            <condition attribute='rsa_name' operator='eq' value='" + ((EntityReference)enPolicy.Attributes["rsa_classofbusiness"]).Name.Replace("&", "&amp;") + @"' />
                                          </filter>
                                        </link-entity>
                                      </entity>
                                    </fetch>";

                                EntityCollection enTradingThreshold = service.RetrieveMultiple(new FetchExpression(fetchXML));
                                tracingService.Trace("enTradingThreshold Count : " + enTradingThreshold.Entities.Count);
                                if (enTradingThreshold.Entities.Count() >= 1)
                                {
                                    if (enTradingThreshold.Entities[0].Attributes.Contains("rsa_renewaltradingthreshold") && enOpportuntiy.Attributes.Contains("rsa_expiringpremium"))
                                    {
                                        decimal? expPremium = ((Money)enOpportuntiy.Attributes["rsa_expiringpremium"]).Value;
                                        tracingService.Trace("expPremium :" + expPremium);
                                        decimal? renTradingThreshold = ((Money)enTradingThreshold.Entities[0].Attributes["rsa_renewaltradingthreshold"]).Value;
                                        tracingService.Trace("renTradingThreshold :" + renTradingThreshold);
                                        decimal? renPromiseThreshold = ((Money)enTradingThreshold.Entities[0].Attributes["rsa_renewalpromisethreshold"]).Value;
                                        tracingService.Trace("renPromiseThreshold :" + renPromiseThreshold);
                                        //Bug #2344 : expPremium > renTradingThreshold
                                        if (expPremium > renTradingThreshold)
                                        {
                                            enCase["rsa_traded"] = new OptionSetValue(866760000);
                                        }
                                        else
                                        {
                                            enCase["rsa_traded"] = new OptionSetValue(866760001);
                                        }

                                        if (enOpportuntiy.Attributes.Contains("rsa_expiringpremium") && enTradingThreshold.Entities[0].Attributes.Contains("rsa_renewalpromisethreshold"))
                                        {

                                            tracingService.Trace("rsa_expiringpremium");
                                            if (expPremium >= renPromiseThreshold)
                                            {
                                                tracingService.Trace("set Promise");
                                                enCase["rsa_promise"] = new OptionSetValue(866760000); // set Promise
                                            }
                                            else
                                            {
                                                tracingService.Trace("set Non-Promise");
                                                enCase["rsa_promise"] = new OptionSetValue(866760001); // set Non-Promise
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    tracingService.Trace("ObjRS is null 1");
                                }
                            }
                            else
                            {
                                tracingService.Trace("ObjRS is null 2");
                            }
                        }
                        else
                        {
                            tracingService.Trace("objsiteRoot is null 3");
                        }

                    }
                    else
                    {
                        tracingService.Trace("objsiteRoot is null");
                    }


                }

                tracingService.Trace($"enOpportuntiy.Id: {enOpportuntiy.Id}");
                enCase["rsa_opportunityid"] = new EntityReference("opportunity", enOpportuntiy.Id);
                tracingService.Trace($"enPolicy.Id: {enPolicy.Id}");
                enCase["rsa_policyid"] = new EntityReference("rsa_policy", enPolicy.Id);

                if (enPolicy.Attributes.Contains("rsa_customer") && ((EntityReference)enPolicy.Attributes["rsa_customer"]).Id != guidEmpty)
                {
                    tracingService.Trace($"enPolicy['rsa_customer'].Name: {((EntityReference)enPolicy.Attributes["rsa_customer"]).Name} & enPolicy['rsa_customer'].Id: {((EntityReference)enPolicy.Attributes["rsa_customer"]).Id}");
                    enCase["rsa_customerrsa"] = enPolicy.Attributes["rsa_customer"];

                }
                //TODO check string length
                if (enPolicy.Attributes.Contains("rsa_renewalgenerationid") && ((EntityReference)enPolicy.Attributes["rsa_renewalgenerationid"]).Id != guidEmpty)
                {
                    tracingService.Trace($"enPolicy['rsa_renewalgenerationid'].Name: {((EntityReference)enPolicy.Attributes["rsa_renewalgenerationid"]).Name} & enPolicy['rsa_renewalgenerationid'].Id: {((EntityReference)enPolicy.Attributes["rsa_renewalgenerationid"]).Id}");
                    enCase["rsa_renewalgeneration"] = enPolicy.Attributes["rsa_renewalgenerationid"];
                }
                //TODO check string length

                if (enOpportuntiy.Attributes.Contains("name"))
                {
                    //Ramesh YELAMANENI : Defect id 2098 : 30 July 2021 : Renewal generation fix for the Case Number. 
                    tracingService.Trace($"enOpportuntiy.Name: {enOpportuntiy["name"]}");
                    // enCase["title"] = enOpportuntiy.Attributes["name"];
                }

                enCase["caseorigincode"] = new OptionSetValue(NEW_RENEWAL_CASE_ORIGIN);
                tracingService.Trace($"NEW_RENEWAL_CASE_ORIGIN: {NEW_RENEWAL_CASE_ORIGIN.ToString()}");

                if (enPolicy.Attributes.Contains("rsa_reviewtypecode"))
                {
                    //  tracingService.Trace($"enPolicy.rsa_reviewtypecode: {enPolicy.FormattedValues["rsa_reviewtypecode"].ToString()}");
                    // enCase["rsa_renewalreviewtype"] = enPolicy.FormattedValues["rsa_reviewtypecode"].ToString();
                }

                if (enPolicy.Attributes.Contains("rsa_classofbusiness"))
                {
                    tracingService.Trace($"enPolicy['rsa_classofbusiness'].Name: {((EntityReference)enPolicy.Attributes["rsa_classofbusiness"]).Name} & enPolicy['rsa_classofbusiness'].Id: {((EntityReference)enPolicy.Attributes["rsa_classofbusiness"]).Id}");
                    enCase["rsa_classofbusinessphoneenqid"] = enPolicy.Attributes["rsa_classofbusiness"]; // TODO
                    //enCase["rsa_status"] = new EntityReference("rsa_status", new Guid(CASE_STATUS_INITIAL_PROCESSING)); //Commented by Samiksha 30June
                    
                    // Samiksha Dhakde - 30 June 2022
                    // TFS 27 - Setting default status of case generated from renewal generation
                    QueryExpression ABRExpression = new QueryExpression("rsa_customlabel");
                    ABRExpression.TopCount = 1;
                    ABRExpression.NoLock = true;
                    ABRExpression.ColumnSet = new ColumnSet(new string[] { "rsa_dependentoptionsetjson" });
                    ABRExpression.Criteria = new FilterExpression();
                    ABRExpression.Criteria.AddCondition("rsa_name", ConditionOperator.Equal, "CaseRenewalStatus");
                    EntityCollection abrCustomLabel = service.RetrieveMultiple(ABRExpression);
                    string dependentOptionset = string.Empty;

                    foreach (var item in abrCustomLabel.Entities)
                    {
                        dependentOptionset = Convert.ToString(item.Attributes["rsa_dependentoptionsetjson"]);
                    }

                    //tracingService.Trace("Custom Label Mapping retrieved: CaseRenewalStatus" + dependentOptionset);

                    var objRSRoot = new RSRootObject();
                    var msStatus = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(dependentOptionset));
                    var ser = new DataContractJsonSerializer(objRSRoot.GetType());
                    objRSRoot = ser.ReadObject(msStatus) as RSRootObject;
                    tracingService.Trace("objRSRoot : " + objRSRoot);
                    msStatus.Close();
                    tracingService.Trace("After Close");
                    if (objRSRoot != null)
                    {
                        if (objRSRoot.RenewalStatus != null)
                        {
                           
                            RenewalStatus objRS = objRSRoot.RenewalStatus.Find(a => a.Classofbusiness.ToLower().Equals(((EntityReference)enPolicy.Attributes["rsa_classofbusiness"]).Name.ToLower()));
                            if (objRS != null)
                            {
                                tracingService.Trace("Obj RS: " +objRS);
                                enCase["rsa_status"] = new EntityReference("rsa_status", new Guid(objRS.DefaultStatusGUID));
                                tracingService.Trace("Case Status mapped with value : " + objRS.DefaultStatusGUID.ToString() + " - " + objRS.DefaultStatus.ToString());
                            }
                            else
                            {
                                tracingService.Trace("ObjRS is null");
                            }
                        }
                        else
                        {
                           tracingService.Trace("ObjRSRoot is null");
                        }

                    }
                    else
                    {
                       tracingService.Trace("objRSRoot is null");
                    }
                    //TFS_27 - END
                }

                // enCase["rsa_rsarecordtype"] = new OptionSetValue(NEW_RENEWAL_CASE_RECORDTYPE);
                //tracingService.Trace($"NEW_RENEWAL_CASE_ORIGIN: {NEW_RENEWAL_CASE_RECORDTYPE.ToString()}");
                tracingService.Trace("Case Type name fetch");
                //Defect id 1365 : Sumegh Dhole : Queue are not found for renewal generations
                //Get the record GUID for renewal case type
                QueryExpression CaseTypeName = new QueryExpression("rsa_casetype");
                CaseTypeName.ColumnSet = new ColumnSet(new string[] { "rsa_casetype" });
                CaseTypeName.NoLock = true;
                CaseTypeName.TopCount = 1;
                CaseTypeName.Criteria = new FilterExpression();
                ConditionExpression conditionExpression = new ConditionExpression();
                conditionExpression.AttributeName = "rsa_casetype";
                conditionExpression.Operator = ConditionOperator.Equal;
                conditionExpression.Values.Add("renewal");
                CaseTypeName.Criteria.AddCondition(conditionExpression);
                EntityCollection caseTypeColl = service.RetrieveMultiple(CaseTypeName);
                tracingService.Trace("Case Type name fetch" + caseTypeColl.Entities.Count);
                if (caseTypeColl.Entities.Count > 0)
                {
                    foreach (var item in caseTypeColl.Entities)
                    {
                        tracingService.Trace("Case Type name " + item.Id + Convert.ToString(item.Attributes["rsa_casetype"]));
                        enCase["rsa_casetype"] = new EntityReference("rsa_casetype", item.Id);
                    }
                }

                //Prachi Paunikar : 03 Sept 2021
                //2316 - Assigning Renewal Generated case to Unassigned User
                tracingService.Trace("calling getuser function");
                Entity enUser = getUser("Unassigned", service);
                tracingService.Trace("Record reterieved " + enUser);
                tracingService.Trace("Record reterieved " + enUser.Id);
                Guid userid = enUser.Id;
                EntityReference unassigneduser = new EntityReference("systemuser", enUser.Id);
                if (userid != Guid.Empty)
                {
                    enCase["ownerid"] = new EntityReference("systemuser", userid);
                }
                //End - 2316

                //if (guidCaseStatusId != Guid.Empty)
                //enCase["rsa_status"] = new EntityReference("rsa_status", guidCaseStatusId);

                #region Schema differences - Additional info equired
                /// <summary>Additional info equired
                /// <desc>Additional info required for this particular field mapping in CRM, hence commenting this mapping for now and will get back to it later on.</para>
                /// </summary>
                //Setting the Case fields with Policy data - Start
                //objNewCase.AccountId = policyRec.Broker__c;
                //objNewCase.Opportunity__c = mapPolicyName_OppID.get(policyRec.Name);
                //objNewCase.Policy__c = policyRec.Id;
                //objNewCase.Customer__c = policyRec.Customer__c;
                //objNewCase.Renewal_Case_Generation_Number__c = renGenId;
                //objNewCase.RecordTypeId = mapCaseRTByNames.get(mapRnwlGenConstants.get('NEW_RENEWAL_CASE_RECORDTYPE').Constant_Value__c).getRecordTypeId();
                //objNewCase.Status = mapRnwlGenConstants.get('NEW_RENEWAL_CASE_STATUS').Constant_Value__c;
                //objNewCase.OwnerId = mapRnwlGenConstants.get('NEW_RENEWAL_CASE_QUEUE').Constant_Value__c;
                //objNewCase.Origin = mapRnwlGenConstants.get('NEW_RENEWAL_CASE_ORIGIN').Constant_Value__c;
                //Setting the Case fields with Policy data - End
                tracingService.Trace("Case record creation started.");
                #endregion
                if (service != null)
                {
                    Guid guidCaseId = service.Create(enCase);
                    tracingService.Trace("Case record has got created.");

                    //if (guidCaseId != guidEmpty)
                    //{
                        ////Sumegh Dhole : Defect id 2098 : 30 July 2021 : Renewal generation fix for the default queue. 
                        //// this.AssignCaseToDefaultQueue(tracingService, service, enCase.LogicalName, guidCaseId, new Guid(DEFAULT_QUEUE));
                        //tracingService.Trace("Updating case status: " + guidCaseId.ToString());
                        //Entity enUpdateCase = new Entity(EnCase.LogicalName, guidCaseId);
                        ////////////////////////
                        //bool isIsieOfMan = false;
                        //if (enPolicy.Attributes.Contains("rsa_operationshandlingsite") && ((OptionSetValue)enPolicy.Attributes["rsa_operationshandlingsite"]).Value.ToString() == TRADE_CENTER_ISIE_OF_MAN)
                        //{
                        //    tracingService.Trace("Trade Center is Isie of Man");
                        //    string strPolicyCOB = ((EntityReference)enPolicy.Attributes["rsa_classofbusiness"]).Name;
                        //    if (strPolicyCOB == COB_COMBINED || strPolicyCOB == COB_CONSTRUCTION || strPolicyCOB == COB_LIABILITY || strPolicyCOB == COB_MOTOR_FLEET ||
                        //        strPolicyCOB == COB_MOTOR_TRADE || strPolicyCOB == COB_PROFIN_LONDDON_PI || strPolicyCOB == COB_PROFIN_LONDON_AH || strPolicyCOB == COB_PROFIN_SCOTTISH_BOND ||
                        //        strPolicyCOB == COB_PROPERTY || strPolicyCOB == COB_PROPERTY_OWNERS)
                        //    {
                        //        tracingService.Trace("Isie of Man related Class of business found");
                        //        isIsieOfMan = true;
                        //        enUpdateCase["rsa_status"] = new EntityReference("rsa_status", new Guid(CASE_STATUS_TO_BE_QUOTED));
                        //        tracingService.Trace("Case Status set ad To be Quoted");
                        //    }
                        //}

                        //if (isIsieOfMan == false)
                        //{
                        //    tracingService.Trace("Other Trade Center");
                        //    //// Defect#: 2093, 2098: Atul Agrawal
                        //    QueryExpression ABRExpression = new QueryExpression("rsa_customlabel");
                        //    ABRExpression.TopCount = 1;
                        //    ABRExpression.NoLock = true;
                        //    ABRExpression.ColumnSet = new ColumnSet(new string[] { "rsa_dependentoptionsetjson" });
                        //    ABRExpression.Criteria = new FilterExpression();
                        //    ABRExpression.Criteria.AddCondition("rsa_name", ConditionOperator.Equal, "CaseRenewalStatus");
                        //    EntityCollection abrCustomLabel = service.RetrieveMultiple(ABRExpression);

                        //    string dependentOptionset = string.Empty;

                        //    foreach (var item in abrCustomLabel.Entities)
                        //    {
                        //        dependentOptionset = Convert.ToString(item.Attributes["rsa_dependentoptionsetjson"]);
                        //    }

                        //   // tracingService.Trace("Custom Label Mapping retrieved: CaseRenewalStatus" + dependentOptionset);

                        //    var objRSRoot = new RSRootObject();
                        //    var ms = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(dependentOptionset));
                        //    var ser = new DataContractJsonSerializer(objRSRoot.GetType());
                        //    objRSRoot = ser.ReadObject(ms) as RSRootObject;
                        //    ms.Close();
                        //    tracingService.Trace("After Close");
                        //    if (objRSRoot != null)
                        //    {
                        //        if (objRSRoot.RenewalStatus != null)
                        //        {
                        //            //Get the broker primary reference value to compare and get the ABR. 
                        //            RenewalStatus objRS = objRSRoot.RenewalStatus.Find(a => a.Classofbusiness.ToLower().Equals(((EntityReference)enPolicy.Attributes["rsa_classofbusiness"]).Name.ToLower()));
                        //            if (objRS != null)
                        //            {
                        //                tracingService.Trace("Obj RS: ");
                        //                enUpdateCase["rsa_status"] = new EntityReference("rsa_status", new Guid(objRS.StatusGUID));
                        //                tracingService.Trace("Case Status mapped with value : " + objRS.StatusGUID.ToString() + " - " + objRS.Status.ToString());
                        //            }
                        //            else { tracingService.Trace("ObjRS is null"); }
                        //        }
                        //        else { tracingService.Trace("ObjRSRoot is null"); }

                        //    }
                        //    else
                        //    {
                        //        tracingService.Trace("objRSRoot is null");
                        //    }
                        //}
                        ////////////////////////
                        //service.Update(enUpdateCase);
                        //tracingService.Trace("Case Updated Successfully");
                    //}
                }
                tracingService.Trace("Exiting RSA.CSI.Plugins.Opportuntiy=>CreateCase() method.");
            }
            catch (Exception ex)
            {
                string sError = strEmpty;
                sError += "Error in RSA.CSI.Plugins.Opportunity=>CreateCase() method.";
                sError += string.Format("Desc.: {0}", ex.InnerException.Message);
                tracingService.Trace(sError);
            }
            finally 
            {
                ms.Close();
            }
        }

        /// <summary>
        /// GetCaseStatusForRenewal
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="strCaseRenewalStatus"></param>
        /// <returns></returns>
        private Guid GetCaseStatusForRenewal(IOrganizationService service, ITracingService tracingService, string strCaseRenewalStatus)
        {
            tracingService.Trace("Entered RSA.CSI.Plugins.Opportuntiy=>GetCaseStatusForRenewal() method.");
            var returnValue = Guid.Empty;
            try
            {
                var guidCaseTypeId = this.GetCaseTypeForRenewalById(service, tracingService, NEW_RENEWAL_CASE_TYPE);
                var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='rsa_status'>
                                <attribute name='rsa_name' />
                                <attribute name='createdon' />
                                <attribute name='rsa_casetype' />
                                <attribute name='rsa_statusid' />
                                <order attribute='rsa_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='rsa_name' operator='eq' value='{0}' />
                                  <condition attribute='rsa_casetype' operator='eq' value='{1}' />
                                </filter>
                              </entity>
                            </fetch>";
                var entityColCaseSatus = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, strCaseRenewalStatus, guidCaseTypeId)));
                if (entityColCaseSatus != null && entityColCaseSatus.Entities.Count > 0)
                {
                    returnValue = entityColCaseSatus.Entities[0].Id;
                    tracingService.Trace("Case Status Id has fetched successfully.");
                }
                else { tracingService.Trace("Case Status Id has NOT fetched successfully."); }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetching case status: " + ex.Message);
            }
            return returnValue;
        }

        /// <summary>
        /// GetCaseTypeForRenewalById
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="strCaseType"></param>
        /// <returns></returns>
        private Guid GetCaseTypeForRenewalById(IOrganizationService service, ITracingService tracingService, string strCaseType)
        {
            tracingService.Trace("Entered RSA.CSI.Plugins.Opportunity.RenewalGenerationHelper=>GetCaseTypeForRenewalById() method.");
            var returnValue = Guid.Empty;
            try
            {
                var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='rsa_casetype'>
                                <attribute name='rsa_casetypeid' />
                                <attribute name='rsa_casetype' />
                                <attribute name='createdon' />
                                <order attribute='rsa_casetype' descending='false' />
                                <filter type='and'>
                                  <condition attribute='rsa_casetype' operator='eq' value='{0}' />
                                </filter>
                              </entity>
                            </fetch>";
                var entityColCaseType = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, strCaseType)));
                if (entityColCaseType != null && entityColCaseType.Entities.Count > 0)
                {
                    returnValue = entityColCaseType.Entities[0].Id;
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetching case type id: " + ex.Message);
            }
            tracingService.Trace("Exiting RSA.CSI.Plugins.Opportunity.RenewalGenerationHelper=>GetCaseTypeForRenewalById() method.");
            return returnValue;
        }

        /// <summary>
        /// IsValidTrigger
        /// </summary>
        /// <param name="enOpportunity"></param>
        /// <returns></returns>
        private Boolean IsValidTrigger(ITracingService tracingService, Entity enOpportunity)
        {
            tracingService.Trace("Eneterd RSA.CSI.Plugins.Opportunity.RenewalGenerationHelper=>IsValidTrigger() method.");
            Boolean bIsValidTrigger = false;
            if (enOpportunity.Attributes.Contains(EnOpportunity.DataOrigin)
                && ((OptionSetValue)enOpportunity[EnOpportunity.DataOrigin]).Value == OPPORTUNITY_DATAORIGIN_RENEWAL_GENERATION)
            {
                if (enOpportunity.Attributes.Contains(EnOpportunity.PolicyId)
                    && enOpportunity[EnOpportunity.PolicyId] != null
                    && ((EntityReference)enOpportunity[EnOpportunity.PolicyId]).Id != Guid.Empty)
                {
                    bIsValidTrigger = true;
                }
            }
            else
            {
                bIsValidTrigger = false;
            }
            tracingService.Trace("Exiting RSA.CSI.Plugins.Opportunity.RenewalGenerationHelper=>IsValidTrigger() method.");
            return bIsValidTrigger;
        }


        /// <summary>
        /// Add Case to Default Queue.
        /// </summary>
        /// <param name="tracingService"></param>
        /// <param name="service"></param>
        /// <param name="entityName"></param>
        /// <param name="caseId"></param>
        /// <param name="destinationQueueId"></param>
        private void AssignCaseToDefaultQueue(ITracingService tracingService, IOrganizationService service, string entityName, Guid caseId, Guid destinationQueueId)
        {
            tracingService.Trace("Entered RSA.CSI.Plugins.Opportuntiy=>AssignCaseToDefaultQueue() method.");
            var routeRequest = new AddToQueueRequest
            {
                Target = new EntityReference(entityName, caseId),
                DestinationQueueId = destinationQueueId
            };
            // Execute the Request
            service.Execute(routeRequest);
            tracingService.Trace("Exiting RSA.CSI.Plugins.Opportuntiy=>AssignCaseToDefaultQueue() method.");
        }

        //Prachi Paunikar
        //2316 : For Fetching unassigned user
        public static Entity getUser(string name, IOrganizationService service)
        {
            try
            {
                var recordName = new Entity();
                QueryExpression query = new QueryExpression("systemuser");
                query.ColumnSet = new ColumnSet(new string[] { "firstname" });

                query.Criteria.AddCondition("firstname", ConditionOperator.Equal, name);
                query.NoLock = true;
                EntityCollection businessRecordTypes = service.RetrieveMultiple(query);
                if (businessRecordTypes != null && businessRecordTypes.Entities.Count > 0)
                {
                    recordName = businessRecordTypes.Entities[0];
                }
                return recordName;
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
    }
}