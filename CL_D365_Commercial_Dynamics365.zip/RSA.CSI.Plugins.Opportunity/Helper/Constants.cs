﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace RSA.CSI.Plugins.Opportunity.Helper
{
    internal class Constants
    {
        internal const string NEW_RENEWAL_CASE_TYPE = "Renewal";
        internal const string NEW_RENEWAL_CASE_STATUS = "Initial Processing";
        internal const int NEW_RENEWAL_CASE_ORIGIN = 866760002;
        internal const int NEW_RENEWAL_CASE_RECORDTYPE = 866760020;
        internal const int OPPORTUNITY_DATAORIGIN_RENEWAL_GENERATION = 866760003;
        internal const string DEFAULT_QUEUE = "99172d9f-2ac7-ea11-a812-000d3af01f8c";

        //// Defect: 2098 : Atul Agrawal
        internal const string TRADE_CENTER_ISIE_OF_MAN = "866760010";
        internal const string COB_COMBINED = "Combined";
        internal const string COB_CONSTRUCTION = "Construction";
        internal const string COB_LIABILITY = "Liability";
        internal const string COB_MOTOR_FLEET = "Motor Fleet";
        internal const string COB_MOTOR_TRADE = "Motor Trade";
        internal const string COB_PROFIN_LONDON_AH = "ProFin London - A&H";
        internal const string COB_PROFIN_LONDDON_PI = "ProFin London - PI";
        internal const string COB_PROFIN_SCOTTISH_BOND = "ProFin - Scottish Bonds";
        internal const string COB_PROPERTY = "Property";
        internal const string COB_PROPERTY_OWNERS = "Property Owners";
        internal const string CASE_STATUS_TO_BE_QUOTED = "9398b842-f7e2-ea11-a816-000d3a64927d";
        internal const string CASE_STATUS_INITIAL_PROCESSING = "b396b842-f7e2-ea11-a816-000d3a64927d";
        /// <summary>
        /// Incident entity
        /// </summary>
        internal class EnCase
        {
            public static string LogicalName = "incident";
            public static string Id = "incidentid";
            public static string rsa_account = "rsa_account";
            public static string rsa_opportunityid = "rsa_opportunityid";
            public static string rsa_policyid = "rsa_policyid";
            public static string customerid = "customerid";
            public static string rsa_customerrsa = "rsa_customerrsa";
            public static string rsa_renewalgeneration = "rsa_renewalgeneration";
            public static string title = "title";
            public static string caseorigincode = "caseorigincode";
            public static string rsa_renewalreviewtype = "rsa_renewalreviewtype";
            public static string rsa_classofbusinessphoneenqid = "rsa_classofbusinessphoneenqid";
            public static string rsa_rsarecordtype = "rsa_rsarecordtype";
            public static string rsa_status = "rsa_status";
        }

        /// <summary>
        /// Opportunity entity
        /// </summary>
        internal class EnOpportunity
        {
            public static string LogicalName = "opportunity";
            public static string Id = "opportunityid";
            public static string name = "name";
            public static string Broker = "parentaccountid";
            public static string PolicyId = "rsa_policyid";
            public static string Customer = "rsa_customer";
            public static string DataOrigin = "rsa_dataorigin";
            public static string rsa_expiringpremium = "rsa_expiringpremium";            
        }

        /// <summary>
        /// Policy entity
        /// </summary>
        internal class EnPolicy
        {
            public static string LogicalName = "rsa_policy";
            public static string Id = "rsa_policyid";
            public static string rsa_broker = "rsa_broker";
            public static string rsa_customer = "rsa_customer";
            public static string rsa_reviewtypecode = "rsa_reviewtypecode";
            public static string rsa_classofbusiness = "rsa_classofbusiness";
            public static string rsa_renewalgenerationid = "rsa_renewalgenerationid";
            //// Defect: 2098 ; Atul Agrawal
            public static string rsa_operationshandlingsite = "rsa_operationshandlingsite";
            public static string rsa_tradinghandlingsite = "rsa_tradinghandlingsite";
            public static string rsa_plcode = "rsa_plcode";

        }

        /// <summary>
        /// Renewal Generation entity
        /// </summary>
        internal class EnRenewalGeneration
        {
            public static string LogicalName = "rsa_renewalgeneration";
            public static string Id = "rsa_renewalgenerationid";

        }

        internal class EnStatus
        {
            public static string LogicalName = "rsa_status";
            public static string Id = "rsa_statusid";

            public static string Name = "rsa_name";
            public static string CaseType = "rsa_casetype";
        }
    }

    // Samiksha Dhakde - 01 July 2022
    // TFS-27 : Get Set for updated json for CaseRenewalStatus RSACustomlabel.
    public class NextStatus
    {
        [DataMember]
        public string StatusName { get; set; }
        [DataMember]
        public string StatusGUID { get; set; }
        [DataMember]
        public int StatusOrder { get; set; }

    }
    public class RenewalStatus
    {
        [DataMember]
        public string Classofbusiness { get; set; }
        [DataMember]
        public string CaseType { get; set; }
        [DataMember]
        public string DefaultStatusGUID { get; set; }
        [DataMember]
        public string DefaultStatus { get; set; }
        [DataMember]
        public List<NextStatus> NextStatus { get; set; }

    }
    // TFS27 Updation - End

    //[DataContract]
    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
    //public class RenewalStatus
    //{
    //    [DataMember]
    //    public string Classofbusiness { get; set; }
    //    [DataMember]
    //   public string CaseType { get; set; }
    //    [DataMember]
    //    public string StatusGUID { get; set; }
    //    [DataMember]
    //    public string Status { get; set; }
    //}
    

    [DataContract]
    public class RSRootObject
    {
        [DataMember]
        public List<RenewalStatus> RenewalStatus { get; set; }
    }
    

    public class Site
    {
        [DataMember]
        public string PolicySite { get; set; }
        [DataMember]
        public string ThresoldSite { get; set; }
    }

    [DataContract]
    public class SiteRoot
    {
        [DataMember]
        public List<Site> Site { get; set; }
    }


}