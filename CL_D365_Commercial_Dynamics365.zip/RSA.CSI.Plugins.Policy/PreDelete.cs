﻿using Microsoft.Xrm.Sdk;
using RSA.CSI.Plugins.Policy.Logic;
using RSA.CSI.Plugins.Policy.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSA.CSI.Plugins.Policy
{
    public class PreDelete : PluginBase
    {
        public PreDelete()
            : base(typeof(PreDelete))
        {
            base.RegisteredEvents.Add(new Tuple<int, string, string, Action<LocalPluginContext>>(20, "Delete", "rsa_policy", ExecutePolicyPreDelete));
        }

        protected void ExecutePolicyPreDelete(LocalPluginContext localContext)
        {
            #region Generic block of Context null checking and service creation block

            if (localContext == null)
            {
                //throw new ArgumentNullException("localContext");
                //Remediation - 20/07/2022
                throw new InvalidPluginExecutionException("localContext");
            }
            IPluginExecutionContext context = localContext.PluginExecutionContext;
            IOrganizationService service = localContext.OrganizationService;
            ITracingService tracingService = localContext.TracingService;
            #endregion Generic block of Context null checking and service creation block      

            #region Get Input Parameters

            if (context.InputParameters["Target"] != null &&
                context.PreEntityImages["PreImage"] != null)
            {
                try
                {
                    #region Need to register in Image
                    //rsa_opportunity
                    #endregion Need to register in Image                    

                    #region Call Function

                    if (context.Depth > 1)
                    {
                        tracingService.Trace("Plugin depth is greater than 1, hence RETURN: " + context.Depth);
                        return;
                    }
                    //Target Entity
                    var entityPolicyTarget = context.InputParameters["Target"] as Entity;
                    tracingService.Trace("Calling Execute Method()");
                    var entityPolicyPreImage = context.PreEntityImages["PreImage"] as Entity;
                    tracingService.Trace("Pre Image attribute(s) count: " + entityPolicyPreImage.Attributes.Count);
                    PreDeleteLogic policyPreDelete = new PreDeleteLogic(service, tracingService, entityPolicyTarget, entityPolicyPreImage, context.InitiatingUserId);
                    policyPreDelete.Execute();
                    tracingService.Trace("Successfully completed Policy Pre Delete plugin");
                    #endregion Call Function
                }
                catch (Exception ex)
                {
                    tracingService.Trace("PreDeletePolicy: " + ex.Message);
                    throw new InvalidPluginExecutionException(ex.Message);
                }
            }
            else
            {
                tracingService.Trace("Target is null");
                throw new InvalidPluginExecutionException("ExecutePolicyPreDeletePlugin: Target is null");
            }
            #endregion  Get Input Parameters
        }        
    }
}
