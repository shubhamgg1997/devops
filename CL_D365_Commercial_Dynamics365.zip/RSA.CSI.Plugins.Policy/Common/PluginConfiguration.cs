﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace RSA.CSI.Plugins.Policy.Common
{
   public class PluginConfiguration
    { /// <summary>Gets value node.</summary>
      /// <param name="doc">The document.</param>
      /// <param name="key">The key.</param>
      /// <returns>The value node.</returns>
        private static string GetValueNode(XmlDocument doc, string key)
        {
            var node = doc.SelectSingleNode($"Settings/setting[@name='{key}']");
            var selectSingleNode = node?.SelectSingleNode("value");
            if (selectSingleNode != null)
                return selectSingleNode.InnerText;
            return string.Empty;
        }

        /// <summary>Gets configuration data unique identifier.</summary>
        /// <param name="doc">The document.</param>
        /// <param name="label">The label.</param>
        /// <returns>The configuration data unique identifier.</returns>
        public static Guid GetConfigDataGuid(XmlDocument doc, string label)
        {
            string tempString = GetValueNode(doc, label);
            return tempString != string.Empty ? new Guid(tempString) : Guid.Empty;
        }

        /// <summary>Gets configuration data bool.</summary>
        /// <param name="doc">The document.</param>
        /// <param name="label">The label.</param>
        /// <returns>true if it succeeds, false if it fails.</returns>
        public static bool GetConfigDataBool(XmlDocument doc, string label)
        {
            bool retVar;
            return bool.TryParse(GetValueNode(doc, label), out retVar) && retVar;
        }

        /// <summary>Gets configuration data int.</summary>
        /// <param name="doc">The document.</param>
        /// <param name="label">The label.</param>
        /// <returns>The configuration data int.</returns>
        public static int GetConfigDataInt(XmlDocument doc, string label)
        {
            int retVar;
            if (int.TryParse(GetValueNode(doc, label), out retVar))
                return retVar;
            return -1;
        }

        /// <summary>Gets configuration data string.</summary>
        /// <param name="doc">The document.</param>
        /// <param name="label">The label.</param>
        /// <returns>The configuration data string.</returns>
        public static string GetConfigDataString(XmlDocument doc, string label)
        {
            return GetValueNode(doc, label);
        }
    }
}
