﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace RSA.CSI.Plugins.Policy.Common
{
  public abstract class PluginBase:IPlugin
    {
        private Collection<Tuple<int, string, string, Action<LocalPluginContext>>> registeredEvents;

        /// <summary>
        /// Gets the List of events that the plug-in should fire for. Each List
        /// Item is a <see cref="System.Tuple"/> containing the Pipeline Stage, Message and (optionally) the Primary Entity. 
        /// In addition, the fourth parameter provide the delegate to invoke on a matching registration.
        /// <!--<param name=""></param>-->
        /// Pre-Event = 20
        /// Post-Event = 40
        /// </summary>
        public Collection<Tuple<int, string, string, Action<LocalPluginContext>>> RegisteredEvents
            => registeredEvents ?? (registeredEvents = new Collection<Tuple<int, string, string, Action<LocalPluginContext>>>());

        /// <summary>Gets the name of the child class.</summary>
        /// <value>The name of the child class.</value>
        protected string ChildClassName { get; }

        /// <summary>Gets or sets the step count number (debugging purpose). </summary>
        /// <value>The count.</value>
        protected int StepCount { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="PluginBase"/> class.
        /// </summary>
        /// <param name="childClassName">The type of the derived class./>/></param>
        protected PluginBase(Type childClassName)
        {
            ChildClassName = childClassName?.ToString();
        }

        /// <summary>
        /// Executes the plug-in.
        /// </summary>
        /// <param name="serviceProvider">The service provider.</param>
        /// <remarks>
        /// For improved performance, Microsoft Dynamics CRM caches plug-in instances. 
        /// The plug-in's Execute method should be written to be stateless as the constructor 
        /// is not called for every invocation of the plug-in. Also, multiple system threads 
        /// could execute the plug-in at the same time. All per invocation state information 
        /// is stored in the context. This means that you should not use global variables in plug-ins.
        /// </remarks>
        public void Execute(IServiceProvider serviceProvider)
        {
            if (serviceProvider == null)
                throw new InvalidPluginExecutionException(nameof(serviceProvider));
                //Remediation - 20/07/2022
                //throw new ArgumentNullException(nameof(serviceProvider));

            LocalPluginContext localcontext = new LocalPluginContext(serviceProvider);

            try
            {
                localcontext.TracingService.Trace($"{Environment.NewLine}Entered {ChildClassName}.Execute()");
                localcontext.TracingService.Trace(
                    $"Correlation Id: '{localcontext.PluginExecutionContext.CorrelationId}', Initiating User: '{localcontext.PluginExecutionContext.InitiatingUserId}'");

                // Iterate over all of the expected registered events to ensure that the plugin
                // has been invoked by an expected event
                // For any given plug-in event at an instance in time, we would expect at most 1 result to match.
                Action<LocalPluginContext> entityAction =
                    (from a in RegisteredEvents
                     where a.Item1 == localcontext.PluginExecutionContext.Stage &&
                           a.Item2 == localcontext.PluginExecutionContext.MessageName &&
                           (string.IsNullOrWhiteSpace(a.Item3) || a.Item3 == localcontext.PluginExecutionContext.PrimaryEntityName)
                     select a.Item4).FirstOrDefault();

                if (entityAction != null)
                    entityAction.Invoke(localcontext);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                LogException(localcontext, ex, ex.Detail);
                //throw;
                //Remediation - 20/07/2022
                throw new InvalidPluginExecutionException(ex.Detail.Message);
            }
            catch (Exception ex)
            {
                LogException(localcontext, ex);
                //throw;
                //Remediation - 20/07/2022
                throw new InvalidPluginExecutionException(ex.Message);
            }
            finally
            {
                localcontext.TracingService.Trace($"Finished {ChildClassName}.Execute()");
            }
        }

        /// <summary>Logs an exception.</summary>
        /// <param name="localContext">Context for the local.</param>
        /// <param name="ex">The ex.</param>
        /// <param name="detail">The detail.</param>
        protected void LogException(LocalPluginContext localContext, Exception ex, OrganizationServiceFault detail = null)
        {
            try
            {
                localContext.TracingService.Trace($"Exception '{ChildClassName}':{Environment.NewLine}{ex.GetBaseException().Message}{Environment.NewLine}");
                localContext.TracingService.Trace($"StackTrace:{Environment.NewLine}{ex.StackTrace}{Environment.NewLine}");

                if (detail != null)
                {
                    localContext.TracingService.Trace($"Detail.Timestamp: {detail.Timestamp}");
                    localContext.TracingService.Trace($"Detail.Code: {detail.ErrorCode}");
                    localContext.TracingService.Trace($"Detail.Message: {detail.Message}");
                    localContext.TracingService.Trace("Detail.InnerFault: {0}",
                        null == detail.InnerFault ? "No Inner Fault" : detail.InnerFault.Message);
                }

                localContext.TracingService.Trace($"UserId: {localContext.PluginExecutionContext.UserId}");
                localContext.TracingService.Trace($"Primary Entity: {localContext.PluginExecutionContext.PrimaryEntityName}");
                localContext.TracingService.Trace($"Message: {localContext.PluginExecutionContext.MessageName}");
                localContext.TracingService.Trace($"Stage: {localContext.PluginExecutionContext.Stage}");
                localContext.TracingService.Trace($"Depth: {localContext.PluginExecutionContext.Depth}");
                localContext.TracingService.Trace($"StepCount: {StepCount}");

                if (localContext.PluginExecutionContext.InputParameters != null)
                {
                    // Log input parameters (to assist in debugging)
                    foreach (var inputParameter in localContext.PluginExecutionContext.InputParameters)
                    {
                        var entityRef = inputParameter.Value as EntityReference;
                        if (entityRef != null)
                        {
                            localContext.TracingService.Trace($"Input.{inputParameter.Key}={entityRef.Id}");
                            continue;
                        }

                        var entity = inputParameter.Value as Entity;
                        if (entity != null)
                        {
                            localContext.TracingService.Trace($"Input.{inputParameter.Key}={entity.LogicalName}_{entity.Id}");
                            if (entity.FormattedValues != null)
                                foreach (var formattedValue in entity.FormattedValues)
                                    localContext.TracingService.Trace($"{inputParameter.Key}.{formattedValue.Key}={formattedValue.Value}");
                            continue;
                        }

                        var opt = inputParameter.Value as OptionSetValue;
                        if (opt != null)
                        {
                            localContext.TracingService.Trace($"Input.{inputParameter.Key}={opt.Value}");
                            continue;
                        }

                        localContext.TracingService.Trace($"Input.{inputParameter.Key}={inputParameter.Value}");
                    }
                }

                if (localContext.PrimaryEntityFromInput != null)
                    localContext.TracingService.Trace($"PrimaryEntityFromInput={localContext.PrimaryEntityFromInput.Id}");

                if (localContext.PrimaryEntityPreImage != null)
                    localContext.TracingService.Trace($"PrimaryEntityPreImage={localContext.PrimaryEntityPreImage.Id}");

                if (localContext.PrimaryEntityPostImage != null)
                    localContext.TracingService.Trace($"PrimaryEntityPostImage={localContext.PrimaryEntityPostImage.Id}");

                if (localContext.PluginExecutionContext?.PreEntityImages != null)
                    foreach (var preEntityImage in localContext.PluginExecutionContext.PreEntityImages)
                        localContext.TracingService.Trace($"PreEntityImage.{preEntityImage.Key}={preEntityImage.Value.Id}");

                if (localContext.PluginExecutionContext?.PostEntityImages != null)
                    foreach (var postEntityImage in localContext.PluginExecutionContext.PostEntityImages)
                        localContext.TracingService.Trace($"PostEntityImage.{postEntityImage.Key}={postEntityImage.Value.Id}");

                LogDetails(localContext);
            }

            catch (Exception exception)
            {
                throw new InvalidPluginExecutionException(exception.Message);
            }
        }

        /// <summary>Logs details.</summary>
        /// <param name="localContext">Plugin context.</param>
        /// <remarks>Can be overloaded by derived classes to provide additional details</remarks>
        protected virtual void LogDetails(LocalPluginContext localContext)
        {
        }
    }
}
