﻿using Microsoft.Xrm.Sdk;
using RSA.CSI.Plugins.Policy.Common;
using RSA.CSI.Plugins.Policy.Logic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSA.CSI.Plugins.Policy
{
    public class PreUpdate : PluginBase
    {


        /// <summary>
        /// Initializes a new instance of the <see cref="PreUpdate"/> class.
        /// </summary>
        public PreUpdate()
            : base(typeof(PreUpdate))
        {
            RegisteredEvents.Add(new Tuple<int, string, string, Action<LocalPluginContext>>(20, "Update", "rsa_policy", ExecutePolicyPreUpdate));
        }

        /// <summary>
        /// Start Validating the record when the regsiterd event occurs
        /// </summary>
        /// <param name="localContext"></param>
        protected void ExecutePolicyPreUpdate(LocalPluginContext localContext)
        {
            #region Generic block of Context null checking and service creation block

            if (localContext == null)
            {
                //throw new ArgumentNullException("localContext");
                //Remediation - 20/07/2022
                throw new InvalidPluginExecutionException("localContext");
            }
            IPluginExecutionContext context = localContext.PluginExecutionContext;
            IOrganizationService service = localContext.OrganizationService;
            ITracingService tracingService = localContext.TracingService;
            #endregion Generic block of Context null checking and service creation block      

            #region Get Input Parameters

            if (context.InputParameters["Target"] != null &&
                context.PreEntityImages["PreImage"] != null)
            {
                try
                {
                    #region Need to register in PreImage
                    //rsa_schemecode
                    //rsa_policyrenewaldate
                    #endregion Need to register in PreImage

                    #region Call Function
                    var entityPolicyTarget = context.InputParameters["Target"] as Entity;
                    tracingService.Trace("Calling Execute Method()");


                    //added check for policy renewal date-time having 23:00 or any other time
                    if (entityPolicyTarget.Attributes.Contains("rsa_policyrenewaldate"))
                    {
                        var date = (DateTime?)entityPolicyTarget.Attributes["rsa_policyrenewaldate"];
                        if (date.HasValue)
                        {

                            tracingService.Trace("renewal date: " + entityPolicyTarget.Attributes["rsa_policyrenewaldate"]);
                            if (date.Value.Hour == 23)
                                date = date.Value.AddHours(1);
                            else if (date.Value.Hour > 1)
                                date = date.Value.AddHours(-1 * date.Value.Hour);
                            entityPolicyTarget.Attributes["rsa_policyrenewaldate"] = date;
                            tracingService.Trace("renewal date: " + entityPolicyTarget.Attributes["rsa_policyrenewaldate"]);
                        }

                    }
                                     
                    tracingService.Trace("Calling Execute Method()");
                    var entityPolicyPreImage = context.PreEntityImages["PreImage"] as Entity;
                    tracingService.Trace("Pre Image attribute(s) count: " + entityPolicyPreImage.Attributes.Count);

                    PreUpdateLogic policyPreUpdate = new PreUpdateLogic(service, tracingService, entityPolicyTarget, entityPolicyPreImage, context.InitiatingUserId);

                    policyPreUpdate.ValidatePolicyNumber();

                    if (context.Depth > 1)
                    {
                        tracingService.Trace("Plugin depth is greater than 1, hence RETURN: " + context.Depth);
                        return;
                    }                                    
                    
                    policyPreUpdate.Execute();
                    tracingService.Trace("Successfully completed Policy Pre Create plugin");
                    #endregion Call Function
                }
                catch (Exception ex)
                {
                    tracingService.Trace("Exception: " + ex.Message);
                    throw new InvalidPluginExecutionException(ex.Message);
                }
            }
            else
            {
                tracingService.Trace("Target is null");
                throw new InvalidPluginExecutionException("ExecutePolicyPreUpdatePlugin: Target is null");
            }

            #endregion  Get Input Parameters
        }
    }
}
