﻿using Microsoft.Xrm.Sdk;
using RSA.CSI.Plugins.Policy.Logic;
using RSA.CSI.Plugins.Policy.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSA.CSI.Plugins.Policy
{
    public class PostUpdate : PluginBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PostUpdate"/> class.
        /// </summary>
        public PostUpdate()
            : base(typeof(PostUpdate))
        {
            RegisteredEvents.Add(new Tuple<int, string, string, Action<LocalPluginContext>>(40, "Update", "rsa_policy", ExecutePolicyPostUpdate));
        }

        /// <summary>
        /// Start Validating the record when the regsiterd event occurs
        /// </summary>
        /// <param name="localContext"></param>
        protected void ExecutePolicyPostUpdate(LocalPluginContext localContext)
        {
            #region Generic block of Context null checking and service creation block

            if (localContext == null)
            {
                //throw new ArgumentNullException("localContext");
                //Remediation - 20/07/2022
                throw new InvalidPluginExecutionException("localContext");
            }
            IPluginExecutionContext context = localContext.PluginExecutionContext;
            IOrganizationService service = localContext.OrganizationService;
            ITracingService tracingService = localContext.TracingService;
            #endregion Generic block of Context null checking and service creation block       

            #region Get Input Parameters

            if (context != null && context.InputParameters.Contains("Target") &&
                context.PostEntityImages.Contains("PostImage"))
            {
                try
                {
                    #region PostImage
                    //rsa_opportunity
                    //rsa_newpolicynumber
                    //rsa_name
                    //rsa_premium
                    //rsa_policysystemcode
                    #endregion

                    #region Call Function

                    var entityPolicyTarget = context.InputParameters["Target"] as Entity;
                    tracingService.Trace("Calling Execute Method()");
                    var entityPolicyPostImage = context.PostEntityImages["PostImage"] as Entity;
                    if (context.Depth > 1)
                    {
                        tracingService.Trace("Plugin depth is greater than 1, hence RETURN: " + context.Depth);
                        return;
                    }
                    tracingService.Trace("Pre Image attribute(s) count: " + entityPolicyPostImage.Attributes.Count);
                    PostUpdateLogic policyPostUpdate = new PostUpdateLogic(service, tracingService, entityPolicyTarget, entityPolicyPostImage, context.InitiatingUserId);
                    policyPostUpdate.Execute();
                    tracingService.Trace("Successfully completed Case Pre Create plugin 1");
                    #endregion Call Function
                }
                catch (Exception ex)
                {
                    tracingService.Trace("Exception: " + ex.Message);
                    throw new InvalidPluginExecutionException("ExecuteCasePostUpdatePlugin: " + ex.Message);
                }
            }
            else
            {
                tracingService.Trace("Target is null");
                throw new InvalidPluginExecutionException("ExecuteCasePostUpdatePlugin: Target is null");
            }

            #endregion  Get Input Parameters
        }

        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = factory.CreateOrganizationService(null);
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            if (context.InputParameters.Contains("Target") &&
                context.InputParameters["Target"] is Entity)
            {
                try
                {
                    #region PostImage
                    //rsa_opportunity
                    //rsa_newpolicynumber
                    //rsa_name
                    //rsa_premium
                    //rsa_policysystemcode
                    #endregion

                    //Target Entity
                    var entityPolicyTarget = context.InputParameters["Target"] as Entity;
                    tracingService.Trace("Calling Execute Method()");
                    var entityPolicyPostImage = context.PostEntityImages["PostImage"] as Entity;
                    if (context.Depth > 1)
                    {
                        tracingService.Trace("Plugin depth is greater than 1, hence RETURN: " + context.Depth);
                        return;
                    }
                    tracingService.Trace("Pre Image attribute(s) count: " + entityPolicyPostImage.Attributes.Count);
                    PostUpdateLogic policyPostUpdate = new PostUpdateLogic(service, tracingService, entityPolicyTarget, entityPolicyPostImage, context.InitiatingUserId);
                    policyPostUpdate.Execute();               
                  
                }
                catch(Exception ex)
                {
                    tracingService.Trace("PostUpdatePolicy" + ex.Message.ToString());
                    throw new InvalidPluginExecutionException("An error occurred in the PostUpdatePolicy plug-in" + ex.Message.ToString());
                }
            }
            else
            {
                tracingService.Trace("Target is null");
                throw new InvalidPluginExecutionException("ExecutePolicyPostUpdatePlugin: Target is null");
            }
        }
    }
}
