﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSA.CSI.Plugins.Policy.Logic
{
    internal class PreUpdateLogic
    {
        IOrganizationService service = null;
        ITracingService tracingService = null;
        Entity enPolicyTarget = null;        
        Guid guidCallingUserId = Guid.Empty;
        Entity enPolicyPreImage = null;

        #region Constructor 
        internal PreUpdateLogic(IOrganizationService cService, ITracingService cTracingService, Entity cEnPolicyTarget, Entity cEntityPolicyPreImage, Guid cGuidCallingUserId)
        {
            service = cService;
            tracingService = cTracingService;
            enPolicyTarget = cEnPolicyTarget;
            enPolicyPreImage = cEntityPolicyPreImage;
            guidCallingUserId = cGuidCallingUserId;
        }
        #endregion Constructor

        internal void Execute()
        {
            var strCL0026 = GetCustomLabel("CL0026");
            tracingService.Trace("strCL0026 : " + strCL0026);
            if(strCL0026 == guidCallingUserId.ToString())
            {
                tracingService.Trace("strCL0026 == guidCallingUserId");
                if (enPolicyPreImage.Attributes.Contains("rsa_schemecode") &&
                    enPolicyTarget.Attributes.Contains("rsa_schemecode")
                    && enPolicyPreImage.Attributes["rsa_schemecode"] != enPolicyTarget.Attributes["rsa_schemecode"])
                {
                    tracingService.Trace("Pre and Target Schemecodes are not same");
                    enPolicyTarget["rsa_schemecode"] = enPolicyPreImage["rsa_schemecode"];
                }
            }

            tracingService.Trace("enPolicyPreImage.Attributes.Contains(rsa_PolicyRenewalDate) : " + enPolicyPreImage.Attributes.Contains("rsa_policyrenewaldate"));
            tracingService.Trace("enPolicyTarget.Attributes.Contains(rsa_PolicyRenewalDate) : " + enPolicyTarget.Attributes.Contains("rsa_policyrenewaldate"));
            if (enPolicyPreImage.Attributes.Contains("rsa_policyrenewaldate") &&
                enPolicyTarget.Attributes.Contains("rsa_policyrenewaldate") &&
                enPolicyTarget.Attributes["rsa_policyrenewaldate"] != enPolicyPreImage.Attributes["rsa_policyrenewaldate"])// && (DateTime)enPolicyTarget.Attributes["rsa_PolicyRenewalDate"] > (DateTime)enPolicyPreImage.Attributes["rsa_PolicyRenewalDate"])
            {
                tracingService.Trace("Pre and Target PolicyRenewal Date are not same");
                enPolicyTarget["rsa_renewalgenerationcaseassignstatuscode"] = null; // optionset
                enPolicyTarget["rsa_renewalgenerationid"] = null; //lookup
                enPolicyTarget["rsa_renewalgenerationfailreason"] = ""; // SIngleline
                enPolicyTarget["rsa_renewalgenerationstatuscode"] = null; // Optionset

                tracingService.Trace("Updated target Policy");
            }


        }

        /// <summary>
        /// Fetch record from Custom Label entity based on key 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        internal string GetCustomLabel(string key)
        {
            var returnValue = string.Empty;
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='rsa_customlabel'>
                                <attribute name='rsa_values' />
                                <attribute name='rsa_shortdescription' />
                                <attribute name='rsa_categories' />   
                                <filter type='and'>
                                  <condition attribute='rsa_name' operator='eq' value ='{0}'/>
                                </filter>
                              </entity>
                            </fetch>";
            var entityCustomLevel = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, key)));
            if (entityCustomLevel.Entities.Count > 0)
            {
                returnValue = entityCustomLevel[0].Attributes.Contains("rsa_values") ? entityCustomLevel[0].GetAttributeValue<string>("rsa_values") : string.Empty;
            }
            return returnValue;
        }

        public void ValidatePolicyNumber()
        {
            string policyNumber = string.Empty;

            if (enPolicyTarget.Attributes.Contains("rsa_name") &&
                enPolicyPreImage.Attributes.Contains("rsa_name") &&
                enPolicyTarget.Attributes["rsa_name"].ToString() != enPolicyPreImage.Attributes["rsa_name"].ToString())
            {
                policyNumber = enPolicyTarget.Attributes["rsa_name"].ToString();

                if(policyNumber.Trim() == "")
                {
                    throw new InvalidPluginExecutionException("Policy number is required for the policy record");
                }

                QueryExpression query = new QueryExpression("rsa_policy");
                query.ColumnSet = new ColumnSet(new string[] { "rsa_name" });
                query.Criteria.AddCondition("rsa_name", ConditionOperator.Equal, policyNumber);

                EntityCollection collection = service.RetrieveMultiple(query);

                if (collection.Entities.Count > 0)
                {
                    throw new InvalidPluginExecutionException("Policy record with the policy number " + policyNumber + " already exists.");
                }

            }
        }
    }
}
