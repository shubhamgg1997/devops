﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSA.CSI.Plugins.Policy.Logic
{
    internal class PreDeleteLogic
    {
        IOrganizationService service = null;
        ITracingService tracingService = null;
        Entity enPolicyTarget = null;        
        Guid guidCallingUserId = Guid.Empty;
        Entity enPolicyPreImage = null;

        #region Constructor 
        internal PreDeleteLogic(IOrganizationService cService, ITracingService cTracingService, Entity cEnPolicyTarget, Entity cEntityPolicyPreImage, Guid cGuidCallingUserId)
        {
            service = cService;
            tracingService = cTracingService;
            enPolicyTarget = cEnPolicyTarget;
            enPolicyPreImage = cEntityPolicyPreImage;
            guidCallingUserId = cGuidCallingUserId;
        }
        #endregion Constructor

        internal void Execute()
        {
            if (enPolicyPreImage.Attributes.Contains("rsa_opportunity") ||
                enPolicyTarget.Attributes.Contains("rsa_opportunity"))
            {
                tracingService.Trace("In loop of Opportunity");
                Entity enOpportunity = null;
                if(enPolicyPreImage.Attributes.Contains("rsa_opportunity"))
                {
                    tracingService.Trace("Calling GetOpportunityStage");
                    enOpportunity = this.GetOpportunityStage(((EntityReference)enPolicyPreImage.Attributes["rsa_opportunity"]).Id);
                }
                else if (enPolicyTarget.Attributes.Contains("rsa_opportunity"))
                {
                    tracingService.Trace("Calling GetOpportunityStage");
                    enOpportunity = this.GetOpportunityStage(((EntityReference)enPolicyTarget.Attributes["rsa_opportunity"]).Id);
                }
                if(enOpportunity != null && enOpportunity.Attributes.Contains("rsa_opportunitystage"))
                {
                    tracingService.Trace("found Opportunity Stage");
                    var stageName = ((EntityReference)enOpportunity.Attributes["rsa_opportunitystage"]).Name;
                    if(stageName.Contains("Accepted"))
                    {
                        tracingService.Trace("Stage is Accepted so throwing Error");
                        throw new Exception("A Policy linked to an Accepted Opportunity may not be deleted");
                    }
                }
            }
        }
        private Entity GetOpportunityStage(Guid guidOpptyId)
        {
            Entity enEntity = null;            
            try
            {
                var enDetails = service.Retrieve("opportunity", guidOpptyId, new ColumnSet("rsa_opportunitystage"));
                if (enDetails != null)
                {
                    enEntity = enDetails;
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetching Opportunity GetOpportunityDetails:" + ex.Message);
                //throw new Exception("Exception while fetching Policy and  Oppty  information in GetOpptyAndPolicyDetails: " + ex.Message);
            }
            return enEntity;
        }

    }
}
