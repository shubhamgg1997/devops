﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSA.CSI.Plugins.Policy.Logic
{
    internal class PostUpdateLogic
    {
        IOrganizationService service = null;
        ITracingService tracingService = null;
        Entity enPolicyTarget = null;
        Guid guidCallingUserId = Guid.Empty;
        Entity enPolicyPostImage = null;

        #region Constructor 
        internal PostUpdateLogic(IOrganizationService cService, ITracingService cTracingService, Entity cEnPolicyTarget, Entity cEntityPolicyPostImage, Guid cGuidCallingUserId)
        {
            service = cService;
            tracingService = cTracingService;
            enPolicyTarget = cEnPolicyTarget;
            enPolicyPostImage = cEntityPolicyPostImage;
            guidCallingUserId = cGuidCallingUserId;
        }
        #endregion Constructor

        internal void Execute()
        {
            if (enPolicyPostImage.Attributes.Contains("rsa_opportunity") ||
                enPolicyTarget.Attributes.Contains("rsa_opportunity"))
            {
                tracingService.Trace("In loop of Opportunity");
                Entity enOpportunity = null;
                String oldPolicyNo = null;
                String oldPolicySystem = null;
                Money oldPremium = null;
                String newPolicyNo = null;
                String newPolicySystem = null;
                String oldRenewalPolicyNumber = null;
                String newRenewalPolicyNumber = null;
                String policyNumber = null;
                Money newPremium = null;
                
                if (enPolicyTarget.Attributes.Contains("rsa_opportunity") && enPolicyTarget.Attributes["rsa_opportunity"] != null)
                {
                    tracingService.Trace("Calling GetOpportunityDetails");
                    enOpportunity = this.GetOpportunityDetails(((EntityReference)enPolicyTarget.Attributes["rsa_opportunity"]).Id);
                }
                else if (enPolicyPostImage.Attributes.Contains("rsa_opportunity") && enPolicyPostImage.Attributes["rsa_opportunity"] != null)
                {
                    tracingService.Trace("Calling GetOpportunityDetails");
                    enOpportunity = this.GetOpportunityDetails(((EntityReference)enPolicyPostImage.Attributes["rsa_opportunity"]).Id);
                }
                if (enOpportunity != null)
                {
                    tracingService.Trace("enOpportunity is not null");
                    if (enOpportunity.Attributes.Contains("rsa_policynumber"))
                    {
                        oldPolicyNo = Convert.ToString(enOpportunity.Attributes["rsa_policynumber"]);
                        tracingService.Trace("oldPolicyNo : " + oldPolicyNo);
                    }
                        
                    if (enOpportunity.Attributes.Contains("rsa_policysystem") &&
                        enOpportunity.FormattedValues.Contains("rsa_policysystem"))
                    {
                        oldPolicySystem = Convert.ToString(enOpportunity.FormattedValues["rsa_policysystem"]);
                        tracingService.Trace("oldPolicySystem : " + oldPolicySystem);
                    }
                        
                    if (enOpportunity.Attributes.Contains("rsa_newpolicynumber"))
                    {
                        oldRenewalPolicyNumber = Convert.ToString(enOpportunity.Attributes["rsa_newpolicynumber"]);
                        tracingService.Trace("oldRenewalPolicyNumber : " + oldRenewalPolicyNumber);
                    }
                        
                    if (enPolicyTarget.Attributes.Contains("rsa_newpolicynumber"))
                    {
                        policyNumber = Convert.ToString(enPolicyTarget.Attributes["rsa_newpolicynumber"]);
                        tracingService.Trace("policyNumber target: " + policyNumber);
                    }                        
                    else if (enPolicyPostImage.Attributes.Contains("rsa_newpolicynumber"))
                    {
                        policyNumber = Convert.ToString(enPolicyPostImage.Attributes["rsa_newpolicynumber"]);
                        tracingService.Trace("policyNumber PostImage: " + policyNumber);
                    }
                        
                    if (enOpportunity.Attributes.Contains("totalamount"))
                    {
                        oldPremium = (Money)enOpportunity.Attributes["totalamount"];
                        tracingService.Trace("oldPremium: " + oldPremium.ToString());
                    }
                        
                    if (enPolicyTarget.Attributes.Contains("rsa_policysystemcode") &&
                        enPolicyTarget.FormattedValues.Contains("rsa_policysystemcode"))
                    {
                        newPolicySystem = Convert.ToString(enPolicyTarget.FormattedValues["rsa_policysystemcode"]);
                        tracingService.Trace("newPolicySystem target : " + newPolicySystem);
                    }                        
                    else if (enPolicyPostImage.Attributes.Contains("rsa_policysystemcode") &&
                        enPolicyPostImage.FormattedValues.Contains("rsa_policysystemcode"))
                    {
                        newPolicySystem = Convert.ToString(enPolicyPostImage.FormattedValues["rsa_policysystemcode"]);
                        tracingService.Trace("newPolicySystem PostImage : " + newPolicySystem);
                    }
                        
                    if (enPolicyTarget.Attributes.Contains("rsa_name"))
                    {
                        newPolicyNo = Convert.ToString(enPolicyTarget.Attributes["rsa_name"]);
                        tracingService.Trace("newPolicySystem target : " + newPolicyNo);
                    }                        
                    else if (enPolicyPostImage.Attributes.Contains("rsa_name"))
                    {
                        newPolicyNo = Convert.ToString(enPolicyPostImage.Attributes["rsa_name"]);
                        tracingService.Trace("newPolicySystem preimage : " + newPolicyNo);
                    }
                        
                    if (enPolicyTarget.Attributes.Contains("rsa_premium"))
                    {
                        newPremium = (Money)enPolicyTarget.Attributes["rsa_premium"];
                        tracingService.Trace("newPremium target : " + newPremium);
                    }                        
                    else if (enPolicyPostImage.Attributes.Contains("rsa_premium"))
                    {
                        newPremium = (Money)enPolicyPostImage.Attributes["rsa_premium"];
                        tracingService.Trace("newPremium postImage : " + newPremium);
                    }
                        
                    if (enPolicyTarget.Attributes.Contains("rsa_newpolicynumber"))
                    {
                        newRenewalPolicyNumber = Convert.ToString(enPolicyTarget.Attributes["rsa_newpolicynumber"]);
                        tracingService.Trace("newRenewalPolicyNumber Target : " + newRenewalPolicyNumber);
                    }                        
                    else if (enPolicyPostImage.Attributes.Contains("rsa_newpolicynumber"))
                    {
                        newRenewalPolicyNumber = Convert.ToString(enPolicyPostImage.Attributes["rsa_newpolicynumber"]);
                        tracingService.Trace("newRenewalPolicyNumber PostImage : " + newRenewalPolicyNumber);
                    }                       


                    if (newPolicyNo != oldPolicyNo || newPolicySystem != oldPolicySystem || newPremium != oldPremium || newRenewalPolicyNumber != oldRenewalPolicyNumber)
                    {
                        tracingService.Trace("In Condition");
                        Entity enOpportunityToBeUpdate = new Entity("opportunity");
                        enOpportunityToBeUpdate.Id = (Guid)enOpportunity.Attributes["opportunityid"];
                        enOpportunityToBeUpdate["rsa_policyid"] = new EntityReference("rsa_policy", enPolicyTarget.Id);
                        tracingService.Trace("PolicyId : " + enPolicyTarget.Id.ToString());
                        if (!string.IsNullOrEmpty(newPolicyNo) && newPolicyNo.Length > 20)
                            enOpportunity["rsa_policynumber"] = newPolicyNo.Substring(0, 19);
                        else if(!string.IsNullOrEmpty(newPolicyNo))
                            enOpportunity["rsa_policynumber"] = newPolicyNo;
                        if (enPolicyTarget.Attributes.Contains("rsa_policysystemcode"))
                            enOpportunityToBeUpdate["rsa_policysystem"] = enPolicyTarget["rsa_policysystemcode"];
                        else if (enPolicyPostImage.Attributes.Contains("rsa_policysystemcode"))
                            enOpportunityToBeUpdate["rsa_policysystem"] = enPolicyPostImage["rsa_policysystemcode"];
                        try
                        {
                            service.Update(enOpportunityToBeUpdate);
                        }catch(Exception ex)
                        {
                            tracingService.Trace("PostUpdatePolicyLogic" + ex.Message.ToString());
                            throw new InvalidPluginExecutionException("An error occurred in the PreUpdatePolicyLogic plug-in while updating Opportunity: " + ex.Message.ToString());
                        }
                    }
                }
            }
        }

        private Entity GetOpportunityDetails(Guid guidOpptyId)
        {
            Entity enEntity = null;
            //rsa_policynumberbeforerenewal not Present in Opportunity
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' >
                    <entity name='opportunity'>
                        <attribute name='rsa_expiringpremium' />
                        <attribute name='rsa_classofbusiness' />
                        <attribute name='rsa_policysystem' />
                        <attribute name='rsa_policynumber' />
                        <attribute name='rsa_policyid' />
                        <attribute name='rsa_newpolicynumber' />	                    
                        <attribute name='totalamount' />
                        <attribute name='opportunityid' />
                        <filter type='and' >
                            <condition attribute='opportunityid' operator='eq' value='{0}' />
                        </filter>       
                    </entity>
                </fetch>";
            try
            {
                var enColDetails = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, guidOpptyId)));
                if (enColDetails != null && enColDetails.Entities.Count > 0)
                {
                    enEntity = enColDetails.Entities[0];
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetching Opportunity GetOpportunityDetails:" + ex.Message);
                //throw new Exception("Exception while fetching Policy and  Oppty  information in GetOpptyAndPolicyDetails: " + ex.Message);
            }
            return enEntity;
        }
    
    }
}
