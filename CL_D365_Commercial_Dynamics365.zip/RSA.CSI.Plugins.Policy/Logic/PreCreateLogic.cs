﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSA.CSI.Plugins.Policy.Logic
{
    internal class PreCreateLogic
    {
        private IOrganizationService service;
        private ITracingService tracingService;
        private Entity entityPolicyTarget;
        private Guid initiatingUserId;

        public PreCreateLogic(IOrganizationService service, ITracingService tracingService, Entity entityPolicyTarget, Guid initiatingUserId)
        {
            this.service = service;
            this.tracingService = tracingService;
            this.entityPolicyTarget = entityPolicyTarget;
            this.initiatingUserId = initiatingUserId;
        }

        internal void Execute()
        {
            tracingService.Trace("Plicy precreatelogic method executed");
        }

        public void ValidatePolicyNumber()
        {
            string policyNumber = string.Empty;

            if (entityPolicyTarget.Attributes.Contains("rsa_name"))
            {
                policyNumber = Convert.ToString(entityPolicyTarget.Attributes["rsa_name"]);

                if (string.IsNullOrEmpty(policyNumber))
                {
                    throw new InvalidPluginExecutionException("Policy number is required for the policy record");
                }

                QueryExpression query = new QueryExpression("rsa_policy");
                query.ColumnSet = new ColumnSet(new string[] { "rsa_name" });
                query.Criteria.AddCondition("rsa_name", ConditionOperator.Equal, policyNumber);

                EntityCollection collection = service.RetrieveMultiple(query);

                if (collection.Entities.Count > 0)
                {
                    throw new InvalidPluginExecutionException("Policy record with the policy number " + policyNumber + " already exists.");
                }

            }
        }
    }
}
