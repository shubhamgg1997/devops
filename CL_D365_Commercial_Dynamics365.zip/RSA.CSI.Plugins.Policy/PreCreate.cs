﻿using Microsoft.Xrm.Sdk;
using RSA.CSI.Plugins.Policy.Common;
using RSA.CSI.Plugins.Policy.Logic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSA.CSI.Plugins.Policy
{
    public class PreCreate : PluginBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PreCreate"/> class.
        /// </summary>
        public PreCreate() : base(typeof(PreCreate))
        {
            RegisteredEvents.Add(new Tuple<int, string, string, Action<LocalPluginContext>>(20, "Create", "rsa_policy", ExecutePolicyPreCreate));
        }

        /// <summary>
        /// Start Validating the record when the regsiterd event occurs
        /// </summary>
        /// <param name="localContext"></param>
        protected void ExecutePolicyPreCreate(LocalPluginContext localContext)
        {
            #region Generic block of Context null checking and service creation block

            if (localContext == null)
            {
                throw new InvalidPluginExecutionException("localContext");
            }

            IPluginExecutionContext context = localContext.PluginExecutionContext;
            IOrganizationService service = localContext.OrganizationService;
            ITracingService tracingService = localContext.TracingService;

            #endregion Generic block of Context null checking and service creation block  

            #region Get Input Parameters

            if (context.InputParameters["Target"] != null && (Entity)context.InputParameters["Target"] != null)
            {
                try
                {
                    
                    //Target Entity
                    var entityPolicyTarget = context.InputParameters["Target"] as Entity;
                    tracingService.Trace("Calling Execute Method()");
                    PreCreateLogic policyPreCreate = new PreCreateLogic(service, tracingService, entityPolicyTarget, context.InitiatingUserId);

                    policyPreCreate.ValidatePolicyNumber();

                    //added check for policy renewal date-time having 23:00 or any other time
                    if (entityPolicyTarget.Attributes.Contains("rsa_policyrenewaldate"))
                    {
                        var date = (DateTime?)entityPolicyTarget.Attributes["rsa_policyrenewaldate"];
                        if (date.HasValue)
                        {

                            tracingService.Trace("renewal date: " + entityPolicyTarget.Attributes["rsa_policyrenewaldate"]);
                            if (date.Value.Hour == 23)
                                date = date.Value.AddHours(1);
                            else if (date.Value.Hour > 1)
                                date = date.Value.AddHours(-1 * date.Value.Hour);
                            entityPolicyTarget.Attributes["rsa_policyrenewaldate"] = date;
                            tracingService.Trace("renewal date: " + entityPolicyTarget.Attributes["rsa_policyrenewaldate"]);
                        }
                    }

                    if (context.Depth > 1)
                    {
                        tracingService.Trace("Plugin depth is greater than 1, hence RETURN: " + context.Depth);
                        return;
                    }
                  
                    policyPreCreate.Execute();
                }
                catch (Exception ex)
                {
                    tracingService.Trace("Exception: " + ex.Message);
                    throw new InvalidPluginExecutionException("ExecuteCustomerPreCreatePlugin: " + ex.Message);
                }
            }
            else
            {
                tracingService.Trace("Target is null in PreCreate");
                throw new InvalidPluginExecutionException("Target is null in PreCreate");
            }

            #endregion  Get Input Parameters
        }
    }
}
