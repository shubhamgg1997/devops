﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace PreValidateOpportunityExtension
{
    public class opportunityExtPlugins : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {

            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            if (context.MessageName.ToLower() != "create")
            {
                return;
            }

            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)

            {


                Entity oppExtEntity = (Entity)context.InputParameters["Target"];

                try
                {
                    EntityReference opportunityId = oppExtEntity.GetAttributeValue<EntityReference>("rsa_opportunity");

                    if (opportunityId != null)
                    {
                        tracingService.Trace("OpportunityID : " + opportunityId.Id);
                        QueryExpression query = new QueryExpression("rsa_extensionopportunity");
                        query.ColumnSet = new ColumnSet(new string[] { "rsa_opportunity" });
                        query.Criteria.AddCondition("rsa_opportunity", ConditionOperator.Equal, opportunityId.Id);
                        EntityCollection retoppoExt = service.RetrieveMultiple(query);
                        tracingService.Trace("OpportunityExtensionCount" + retoppoExt.Entities.Count);
                        if (retoppoExt != null && retoppoExt.Entities.Count > 0)
                        {
                          
                            throw new InvalidPluginExecutionException("Opportunity Extension Is Already Exist");
                        }

                    }
                }

                catch (Exception ex)
                {
                   
                    throw new InvalidPluginExecutionException("Opportunity Extension Is Already Exist");
                }
            }
        }
    }

}