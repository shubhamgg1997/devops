﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;


namespace RSA.CSI.Plugins.OpportunityExtension.Logic
{
    public class Logic
    {
        public void updateGBPFields(IPluginExecutionContext context, IOrganizationService service, Entity target, Entity entity, Entity preImage, ITracingService tracer, int customtype)//entity=postImage
        {
            try
            {
                if (target == null) { target = entity; }
                if (preImage == null)
                {
                    preImage = entity;
                }
                Entity enparentOppty = null, enOpportunityExtension = entity;

                if (context.MessageName.ToLowerInvariant().Equals("update"))
                {
                    tracer.Trace("Start of updateGBPFields ");
                    EntityReference parentOppty = null;
                    if (target.Attributes.Contains("rsa_opportunity"))
                    {
                        parentOppty = entity.GetAttributeValue<EntityReference>("rsa_opportunity");
                    }
                    else if (entity.Attributes.Contains("rsa_opportunity"))
                    {
                        parentOppty = entity.GetAttributeValue<EntityReference>("rsa_opportunity");
                        tracer.Trace("Data Fetched from Oppty");

                    }

                    if (parentOppty != null)
                    {
                        tracer.Trace("parentOppty not null ");
                        enparentOppty = service.Retrieve(parentOppty.LogicalName, parentOppty.Id, new ColumnSet("rsa_exchangerateelc"));
                        decimal exchangerateELC = enparentOppty.GetAttributeValue<decimal>("rsa_exchangerateelc");
                        tracer.Trace("parentOppty exchangerateELC " + exchangerateELC);
                        var customSettings = GetCustomSettingsbytype(service, tracer, 866760027);
                        tracer.Trace("custom Settings:{0}", customSettings.Entities.Count);//39
                        if (customSettings.Entities.Count > 0)
                        {

                            foreach (var csentity in customSettings.Entities)
                            {
                                tracer.Trace(csentity.Attributes.Contains("rsa_formulatype") ? "1" : "0");
                                string formulaType = csentity.Attributes.Contains("rsa_formulatype") ? csentity.GetAttributeValue<string>("rsa_formulatype") : string.Empty;//to check
                                tracer.Trace("formulaType" + formulaType);
                                string PCorELC = csentity.Attributes.Contains("rsa_pcelc") ? csentity.GetAttributeValue<string>("rsa_pcelc") : string.Empty;//to check
                                tracer.Trace("PCorELC:" + PCorELC);
                                decimal opptyExchangeRate = 0.00m;
                                decimal opptyExchangeRateELC = 0.00m;
                                string formuladescription = csentity.Attributes.Contains("rsa_formuladescription") ? csentity.GetAttributeValue<string>("rsa_formuladescription") : string.Empty;//to check
                                if (formulaType.Contains("Currency_Convert") && PCorELC.Equals("ELC") && !string.IsNullOrEmpty(formuladescription) && context.MessageName.Equals("Update"))
                                {
                                    string gbpCurrencyField = csentity.Attributes.Contains("rsa_gbpcurrencyfield") ? csentity.GetAttributeValue<string>("rsa_gbpcurrencyfield") : string.Empty;
                                    tracer.Trace("gbpCurrencyField:" + gbpCurrencyField);
                                    string policyCurrencyPCField = csentity.Attributes.Contains("rsa_policycurrencypcfield") ? csentity.GetAttributeValue<string>("rsa_policycurrencypcfield") : string.Empty;
                                    tracer.Trace("policyCurrencyPCField:" + policyCurrencyPCField);

                                    string[] dataTypesplitgbp = gbpCurrencyField.Split('|');
                                    tracer.Trace("dataTypesplitgbp" + dataTypesplitgbp[0] + dataTypesplitgbp[1]);
                                    string[] dataTypesplitpc = policyCurrencyPCField.Split('|');
                                    tracer.Trace("dataTypesplitpc" + dataTypesplitpc[0] + dataTypesplitpc[1]);

                                    decimal opptyFieldPC = 0.00m;
                                    decimal opptyFieldGBP = 0.00m;

                                    if (enOpportunityExtension.Attributes.Contains(dataTypesplitpc[0]))
                                    {
                                        if (dataTypesplitpc[1].ToLower().Equals("money"))
                                        {
                                            Money opptyFieldPCmoney = enOpportunityExtension.Attributes.Contains(dataTypesplitpc[0]) ? enOpportunityExtension.GetAttributeValue<Money>(dataTypesplitpc[0]) : null;
                                            if (opptyFieldPCmoney != null)
                                            {
                                                opptyFieldPC = opptyFieldPCmoney.Value;
                                                tracer.Trace("opptyFieldPC:" + opptyFieldPC);
                                            }
                                        }
                                        else if (dataTypesplitpc[1].ToLower().Equals("decimal"))
                                        {
                                            opptyFieldPC = enOpportunityExtension.Attributes.Contains(dataTypesplitpc[0]) ? enOpportunityExtension.GetAttributeValue<decimal>(dataTypesplitpc[0]) : 0.00m;
                                            tracer.Trace("opptyFieldPC:" + opptyFieldPC);
                                        }
                                    }
                                    if (enparentOppty.Attributes.Contains("rsa_exchangerateelc"))
                                    {
                                        opptyExchangeRateELC = enparentOppty.GetAttributeValue<decimal>("rsa_exchangerateelc");
                                        tracer.Trace("opptyExchangeRateELC:" + opptyExchangeRateELC);
                                    }
                                    if (opptyFieldPC == 0.00m)
                                    {
                                        if (dataTypesplitgbp[1].ToLower().Equals("money"))
                                        {
                                            // entity[dataTypesplitgbp[0]] = new Money(0.00m);
                                            enOpportunityExtension[dataTypesplitgbp[0]] = new Money(0.00m);


                                        }
                                        else if (dataTypesplitgbp[1].ToLower().Equals("decimal"))
                                        {
                                            // entity[dataTypesplitgbp[0]] = 0.00m;
                                            enOpportunityExtension[dataTypesplitgbp[0]] = 0.00m;
                                        }

                                    }
                                    else if (opptyFieldPC != 0.00m && opptyExchangeRateELC != 0.00m)
                                    {

                                        if (dataTypesplitgbp[1].ToLower().Equals("money"))
                                        {

                                            decimal dc = opptyFieldPC / opptyExchangeRateELC;

                                            enOpportunityExtension[dataTypesplitgbp[0]] = new Money(dc);



                                            tracer.Trace("enOpportunityExtension[dataTypesplitgbp[0]] ", enOpportunityExtension[dataTypesplitgbp[0]]);
                                        }
                                        else if (dataTypesplitgbp[1].ToLower().Equals("decimal"))
                                        {
                                            // entity[dataTypesplitgbp[0]] = opptyFieldPC / opptyExchangeRateELC;
                                            enOpportunityExtension[dataTypesplitgbp[0]] = opptyFieldPC / opptyExchangeRateELC;
                                            //tracer.Trace("entity[gbpCurrencyField]", entity[gbpCurrencyField]);

                                        }



                                    }
                                }

                                else if (formulaType.Contains("Copy_Value") && !string.IsNullOrEmpty(formuladescription) && PCorELC.Equals("ELC") && context.MessageName.Equals("Update"))
                                {

                                    string gbpCurrencyField = csentity.Attributes.Contains("rsa_gbpcurrencyfield") ? csentity.GetAttributeValue<string>("rsa_gbpcurrencyfield") : string.Empty;
                                    tracer.Trace("gbpCurrencyField:" + gbpCurrencyField);
                                    string policyCurrencyPCField = csentity.Attributes.Contains("rsa_policycurrencypcfield") ? csentity.GetAttributeValue<string>("rsa_policycurrencypcfield") : string.Empty;
                                    tracer.Trace("policyCurrencyPCField:" + policyCurrencyPCField);
                                    string[] dataTypesplitgbp = gbpCurrencyField.Split('|');
                                    tracer.Trace("dataTypesplitgbp" + dataTypesplitgbp[0] + dataTypesplitgbp[1]);
                                    string[] dataTypesplitpc = policyCurrencyPCField.Split('|');
                                    tracer.Trace("dataTypesplitpc" + dataTypesplitpc[0] + dataTypesplitpc[1]);
                                    decimal opptyFieldPC = 0.00m;
                                    decimal opptyFieldGBP = 0.00m;

                                    if (enOpportunityExtension.Attributes.Contains(dataTypesplitpc[0]))
                                    {
                                        tracer.Trace("Inside Copyvalue money if");
                                        if (dataTypesplitpc[1].ToLower().Equals("money"))
                                        {
                                            tracer.Trace("Inside Copyvalue money1:" + dataTypesplitpc[0]);
                                            decimal opptyFieldPCmoney = 0m;
                                            opptyFieldPCmoney = enOpportunityExtension.GetAttributeValue<decimal>(dataTypesplitpc[0]);
                                            tracer.Trace("opptyFieldPCmoney483:" + opptyFieldPCmoney);

                                        }
                                        else if (dataTypesplitpc[1].ToLower().Equals("decimal"))
                                        {
                                            tracer.Trace("Inside Copyvalue decimal");
                                            opptyFieldPC = enOpportunityExtension.Attributes.Contains(dataTypesplitpc[0]) ? enOpportunityExtension.GetAttributeValue<decimal>(dataTypesplitpc[0]) : 0.00m;
                                            tracer.Trace("opptyFieldPC:" + opptyFieldPC);
                                        }
                                    }
                                    if (dataTypesplitgbp[1].ToLower().Equals("money"))
                                    {
                                        enOpportunityExtension[dataTypesplitgbp[0]] = new Money(opptyFieldPC);
                                        tracer.Trace("enOpportunityExtension[gbpCurrencyField]:" + enOpportunityExtension[dataTypesplitgbp[0]]);


                                    }
                                    else if (dataTypesplitgbp[1].ToLower().Equals("decimal"))
                                    {
                                        enOpportunityExtension[dataTypesplitgbp[0]] = opptyFieldPC;
                                        tracer.Trace("enOpportunityExtension[gbpCurrencyField]:" + enOpportunityExtension[dataTypesplitgbp[0]]);
                                    }
                                }


                            }

                            service.Update(enOpportunityExtension);
                        }
                    }
                }
            }


            catch (Exception ex)
            {
                tracer.Trace("updateGBPFields-Error" + ex.Message.ToString());
                throw new InvalidPluginExecutionException(ex.Message);
            }

        }






        public static EntityCollection GetCustomSettingsbytype(IOrganizationService service, ITracingService tracer, int customtype)
        {
            try
            {
                string fetchQuery = "<fetch mapping = 'logical'>";
                fetchQuery += "<entity name = 'rsa_customsetting'>";
                fetchQuery += "<attribute name='rsa_typeoffield' />";
                fetchQuery += "<attribute name = 'rsa_fieldlabel' />";
                fetchQuery += "<attribute name='rsa_fieldapi' />";
                fetchQuery += "<attribute name='rsa_gbpcurrencyfield' />";
                fetchQuery += "<attribute name='rsa_policycurrencypcfield' />";
                fetchQuery += "<attribute name='rsa_formulatype' />";
                fetchQuery += "<attribute name='rsa_formuladescription' />";
                fetchQuery += "<attribute name='rsa_pcelc' />";
                fetchQuery += "<filter type = 'and'>";
                fetchQuery += "<condition attribute = 'rsa_customsettingtype' operator= 'eq' value='" + customtype + "' />";
                fetchQuery += "<condition attribute = 'rsa_formuladescription' operator= 'not-null' />";
                fetchQuery += "<condition attribute = 'statecode' value = '0' operator= 'eq' />";
                fetchQuery += "</filter>";
                fetchQuery += "</entity>";
                fetchQuery += "</fetch>";
                EntityCollection customSettings = service.RetrieveMultiple(new FetchExpression(fetchQuery));
                tracer.Trace("Number of RcustomSettings: {0}", customSettings.Entities.Count);
                return customSettings;
            }
            catch (Exception ex)
            {
                tracer.Trace("GetCustomSettingsbyName-Error" + ex.Message.ToString());
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
    }
}
