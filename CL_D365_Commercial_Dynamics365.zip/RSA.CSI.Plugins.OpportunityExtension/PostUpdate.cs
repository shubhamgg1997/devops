﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using RSA.Crm.Plugins;
using System;
using System.Collections.Generic;
using System.ServiceModel;
using RSA.CSI.Plugins.OpportunityExtension.Logic;

namespace RSA.CSI.Plugins.OpportunityExtension
{
    public class PostUpdate : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService tracer = null;
            IPluginExecutionContext context = null;
            IOrganizationService service = null;

            CrmPluginHelper.Initialise(serviceProvider, ref context, ref service, ref tracer, false);
            tracer.Trace("context.Depth:{0}", context.Depth);
            if (context.Depth > 1)
            {
                return;
            }
            try
            {
                if ((context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity) && context.MessageName.ToLowerInvariant() == "update" && context.Stage == 40)
                {
                    tracer.Trace("Instace created and target is avaialble.");
                    Entity entity = (Entity)context.InputParameters["Target"];
                    Entity postImage = (Entity)context.PostEntityImages["PreImage"];
                    Entity preImage = (Entity)context.PreEntityImages["PreImage"];
                    OpportunityExtension.Logic.Logic logicOperation = new OpportunityExtension.Logic.Logic();
                    tracer.Trace("UpdateGBPField - Loading");
                    logicOperation.updateGBPFields(context, service, entity, postImage, preImage, tracer, 866760027);
                    tracer.Trace("UpdateGBPField - Unloaded");
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                CrmPluginHelper.CatchFaultException(ex, this);
            }
            catch (InvalidPluginExecutionException ex)
            {
                CrmPluginHelper.CatchInvalidPluginException(ex);
            }
            catch (Exception ex)
            {
                CrmPluginHelper.CatchGenericException(ex, this);
            }
        }
    }
}
