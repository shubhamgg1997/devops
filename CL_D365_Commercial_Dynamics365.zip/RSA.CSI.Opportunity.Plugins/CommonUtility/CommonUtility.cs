﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;

namespace RSA.CSI.Plugins.Utility
{
    public class CommonUtility
    {
        public static EntityCollection GetCutomLabelDetails(IOrganizationService service, string prm1, string prm2, string prm3)
        {
            string fetchQuery = "<fetch mapping = 'logical'>";
            fetchQuery += "<entity name = 'rsa_customlabel'>";
            fetchQuery += "<attribute name = 'rsa_name'/>";
            fetchQuery += "<attribute name = 'rsa_values'/>";
            fetchQuery += "<filter type = 'and'> ";
            fetchQuery += "<filter type = 'or'> ";
            if (!string.IsNullOrEmpty(prm1))
                fetchQuery += "<condition attribute = 'rsa_name' operator= 'eq' value = '"+ prm1 + "'/>";
            if (!string.IsNullOrEmpty(prm2))
                fetchQuery += "<condition attribute = 'rsa_name' operator= 'eq' value = '"+ prm2 + "'/>";
            if (!string.IsNullOrEmpty(prm3))
                fetchQuery += "<condition attribute = 'rsa_name' operator= 'eq' value = '" + prm3 + "'/>";
            fetchQuery += "</filter>";
            fetchQuery += "</filter>";
            fetchQuery += "</entity>";
            fetchQuery += "</fetch>";
            EntityCollection customLabel = service.RetrieveMultiple(new FetchExpression(fetchQuery));
            return customLabel;
        }
        public static EntityCollection GetExchangeRates(IOrganizationService service, string conversionIdsSet,Guid currencyid)
        {
            string fetchQuery = "<fetch mapping = 'logical'>";
            fetchQuery += "<entity name = 'rsa_exchangerate'>";
            fetchQuery += "<attribute name = 'rsa_rate'/>";
            fetchQuery += "<attribute name = 'rsa_currencyid'/>";
            fetchQuery += "<attribute name = 'rsa_exchangerateid'/>";
            fetchQuery += "<filter type = 'and'> ";
            fetchQuery += "<condition attribute = 'rsa_conversionidname' operator= 'like' value = '%" + conversionIdsSet + "%'/>";
            fetchQuery += "<condition attribute = 'rsa_currencyid' operator= 'eq' value = '" + currencyid + "' />";
            fetchQuery += "</filter>";
            fetchQuery += "</entity>";
            fetchQuery += "</fetch>";
            EntityCollection exchangeRates = service.RetrieveMultiple(new FetchExpression(fetchQuery));
            return exchangeRates;
        }
        public static Entity GetLookUpDetailsbyText(IOrganizationService service, string pName, string entityName, Guid lob)
        {
            try
            {
                var entity = new Entity(entityName);
                string fetchQuery = "<fetch mapping = 'logical'>";
                fetchQuery += "<entity name = '" + entityName + "'>";
                fetchQuery += "<attribute name='rsa_name' />";
                fetchQuery += "<filter type = 'and'>";
                fetchQuery += "<condition attribute = 'rsa_name' operator= 'eq' value = '" + pName + "' />";
                if(lob != Guid.Empty)
                fetchQuery += "<condition attribute = 'rsa_lineofbusiness' operator= 'eq' value = '"+ lob + "' />";
                fetchQuery += "</filter>";
                fetchQuery += "</entity>";
                fetchQuery += "</fetch>";
                EntityCollection lobDetails = service.RetrieveMultiple(new FetchExpression(fetchQuery));
                if (lobDetails.Entities.Count > 0)
                {
                    foreach (var entities in lobDetails.Entities)
                    {
                        entity = entities;
                    }
                }
                return entity;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public string GetNameByEntityId(IOrganizationService service, string strEntityName, Guid guidEntityId, String strAttributeName)
        {
            var strTransactionTypeName = string.Empty;
            try
            {
                var enTransType = service.Retrieve(strEntityName, guidEntityId, new ColumnSet(strAttributeName));
                if (enTransType != null && enTransType.Attributes.Contains(strAttributeName))
                {
                    strTransactionTypeName = enTransType.Attributes[strAttributeName].ToString();
                }
            }
            catch (Exception ex)
            {
                //tracingService.Trace("Exception while fetching from " + strEntityName + "with Id" + guidEntityId + "--Exception: " + ex.Message);
                //throw new Exception("Exception while fetching from " + strEntityName + "with Id" + guidEntityId + "--Exception: " + ex.Message);
            }
            return strTransactionTypeName;
        }
        public static EntityCollection GetCustomSettingsbyName(IOrganizationService service, string customName)
        {
            try
            {
                string fetchQuery = "<fetch mapping = 'logical'>";
                fetchQuery += "<entity name = 'rsa_customsetting'>";
                fetchQuery += "<attribute name='rsa_region' />";
                fetchQuery += "<attribute name = 'rsa_recordtypename' />";
                fetchQuery += "<attribute name='rsa_opportunityownerid' />";
                fetchQuery += "<attribute name='rsa_class_of_business' />";
                fetchQuery += "<filter type = 'and'>";
                fetchQuery += "<condition attribute = 'rsa_customsettingtypename' operator= 'like' value='" + customName + "%' />";
                fetchQuery += "</filter>";
                fetchQuery += "</entity>";
                fetchQuery += "</fetch>";
                EntityCollection customSettings = service.RetrieveMultiple(new FetchExpression(fetchQuery));
                return customSettings;
            }
            catch (Exception)
            {
                throw;
            }
        }

        //Get Opportunity Extension
        public static EntityCollection GetOpportunityExtension(IOrganizationService service, Guid opportunityId)
        {
            var fetchxml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='rsa_extensionopportunity'>
                                <attribute name='rsa_extensionopportunityid' />
                                <attribute name='rsa_name' />
                                <attribute name='createdon' />
                                <attribute name='rsa_annualaggquakefloodwindstormgbp' />
                                <attribute name='rsa_annualaggregrateforquakefloodwind' /> 
                                <order attribute='rsa_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='rsa_opportunity' operator='eq' uitype='opportunity' value='{0}' />
                                </filter>
                              </entity>
                            </fetch>";
            EntityCollection opportunityExtension = service.RetrieveMultiple(new FetchExpression(String.Format(fetchxml, opportunityId)));
            return opportunityExtension;
        }

        //Retrive Broker Primary Reference from Account
        public static string RetriveBrokerPrimaryReference(Guid opportunityId, IOrganizationService service, ITracingService tracer)
        {
            tracer.Trace("RetriveBrokerPrimaryReference starting");
            String primaryReference = string.Empty;
            var fetchxml = @"<fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>
                                <entity name='opportunity'>
                                <attribute name='name'/>
                                <attribute name='opportunityid'/>
                                <order descending='false' attribute='name'/>
                                <filter type='and'>
                                <condition attribute='opportunityid' value='{0}' uitype='opportunity' operator='eq'/></filter>
                                <link-entity name='account' alias='aa' link-type='inner' to='parentaccountid' from='accountid'>
                                <attribute name='rsa_primaryreference'/>
                                </link-entity>
                                </entity>
                                </fetch>";
            tracer.Trace("RetriveBrokerPrimaryReference fetchxml: "+ fetchxml);
            var OpportunityExtensiondata = service.RetrieveMultiple(new FetchExpression(String.Format(fetchxml, opportunityId)));
            tracer.Trace("RetriveBrokerPrimaryReference retrived entity collection");
            if (OpportunityExtensiondata != null && OpportunityExtensiondata.Entities.Count == 1)
            {
                tracer.Trace("RetriveBrokerPrimaryReference in condition");
                if(OpportunityExtensiondata.Entities[0].Attributes.Contains("aa.rsa_primaryreference"))
                {
                    primaryReference = ((AliasedValue)OpportunityExtensiondata.Entities[0]["aa.rsa_primaryreference"]).Value.ToString();
                    tracer.Trace("RetriveBrokerPrimaryReference primaryReference: " + primaryReference);
                }
                
            }
            return primaryReference;
        }

        //Area Name from Account
        public static string RetriveAreaName(Guid opportunityId, IOrganizationService service)
        {
            string areaName = string.Empty;
            var fetchxml_areaname = @"<fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>
                                        <entity name='opportunity'>
                                        <attribute name='name'/>
                                        <attribute name='opportunityid'/>
                                        <order descending='false' attribute='name'/>
                                        <filter type='and'>
                                        <condition attribute='opportunityid' value='{0}' uitype='opportunity' operator='eq'/>
                                        </filter>
                                        <link-entity name='account' alias='ab' link-type='inner' to='parentaccountid' from='accountid'>
                                        <attribute name='rsa_rsaareaname'/>
                                        <filter type='and'>
                                        <condition attribute='rsa_rsaareaname' operator='not-null'/>
                                        </filter>
                                        </link-entity>
                                        </entity>
                                        </fetch>";
            var accountAreaName = service.RetrieveMultiple(new FetchExpression(String.Format(fetchxml_areaname, opportunityId)));
            if (accountAreaName != null && accountAreaName.Entities.Count == 1)
            {
                areaName = (accountAreaName.Entities[0].FormattedValues["ab.rsa_rsaareaname"]);

            }
            return areaName;
        }

        //Case Received Date
        public static DateTime RetriveCaseReceivedDate(Guid opportunityId, IOrganizationService service)
        {
            DateTime caseReecivedDate = new DateTime();
            
            var fetchxml_case = @"<fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>
                                           <entity name='opportunity'>
                                            <attribute name='name'/>
                                            <attribute name='opportunityid'/>
                                            <order descending='false' attribute='name'/>
                                            <filter type='and'>
                                            <condition attribute='opportunityid' value='{0}' uitype='opportunity' operator='eq'/>
                                            </filter>
                                            <link-entity name='incident' alias='aa' link-type='inner' to='rsa_case' from='incidentid'>
                                            <attribute name='rsa_casereceiveddate'/>
                                            </link-entity>
                                            </entity>
                                            </fetch>";
            var caseCaseReceivedDate = service.RetrieveMultiple(new FetchExpression(String.Format(fetchxml_case, opportunityId)));
            if (caseCaseReceivedDate != null && caseCaseReceivedDate.Entities.Count == 1)
            {
                if(caseCaseReceivedDate.Entities[0].Attributes.Contains("aa.rsa_casereceiveddate"))
                {
                    caseReecivedDate = (DateTime)((AliasedValue)caseCaseReceivedDate.Entities[0]["aa.rsa_casereceiveddate"]).Value;
                }               

            }
            return caseReecivedDate;
        }

        //Current User
        public static bool retriveCurrentUser(Guid opportunityId, Guid UserId, IOrganizationService service, ITracingService tracer)
        {
            tracer.Trace("retriveCurrentUser starting");
            bool currentUser = false;
            Entity enOpportunity = service.Retrieve("opportunity", opportunityId, new ColumnSet("rsa_secondaryowner"));
            if (enOpportunity.Attributes.Contains("rsa_secondaryowner"))
            {
                tracer.Trace("retriveCurrentUser - rsa_secondaryowner contains data");
                string secondaryOwnerUserName = retrieveUserName(service, ((EntityReference)enOpportunity["rsa_secondaryowner"]).Id);
                tracer.Trace("retriveCurrentUser - secondaryOwnerUserName: "+ secondaryOwnerUserName);
                string loggedInUserUserName = retrieveUserName(service, UserId);
                tracer.Trace("retriveCurrentUser - loggedInUserUserName: " + loggedInUserUserName);
                if (secondaryOwnerUserName == loggedInUserUserName && !string.IsNullOrEmpty(secondaryOwnerUserName)
                    && !string.IsNullOrEmpty(loggedInUserUserName))
                {
                    currentUser = true;
                    tracer.Trace("retriveCurrentUser - currentUser: " + currentUser.ToString());
                }
                else
                {
                    currentUser = false;
                    tracer.Trace("retriveCurrentUser - currentUser: " + currentUser.ToString());
                }
            }
            return currentUser;
        }

        public static string retrieveUserName(IOrganizationService service, Guid userId)
        {
            var userName = string.Empty;
            Entity enUser = service.Retrieve("systemuser", userId, new ColumnSet("rsa_username"));
            if (enUser.Attributes.Contains("rsa_username"))
            {
                userName = enUser["rsa_username"].ToString();
            }
            return userName;
        }
    }
}
