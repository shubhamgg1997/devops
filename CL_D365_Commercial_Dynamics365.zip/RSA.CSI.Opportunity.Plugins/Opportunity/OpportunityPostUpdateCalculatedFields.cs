﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using RSA.Crm.Plugins;
using RSA.CSI.Plugins.Utility;
using System;
using System.ServiceModel;

namespace RSA.CSI.Plugins.Opportunity
{
    public class OpportunityPostUpdateCalculatedFields : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService tracer = null;
            IPluginExecutionContext context = null;
            IOrganizationService _orgService = null;

            CrmPluginHelper.Initialise(serviceProvider, ref context, ref _orgService, ref tracer, false);
            tracer.Trace("context.Depth:{0}", context.Depth);
            //Modified : 20-09-2022 ; Nida ; CR 1243,1778 - IYBValue issue fix as depth was causing issue
            if (context.Depth > 2)
            {
                return;
            }
            try
            {
                if ((context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity))
                {
                    string messageName = context.MessageName.ToLowerInvariant();
                    tracer.Trace("Instace created and target is avaialble.");
                    tracer.Trace("OpportunityPostUpdateCalculatedFields");
                    Entity enOpportunity = (Entity)context.InputParameters["Target"];
                    Entity enOpportunityImage = new Entity();
                    if (context.MessageName.ToLowerInvariant() == "update")
                    {
                        enOpportunityImage = (Entity)context.PreEntityImages["PreImage"];
                        tracer.Trace("OpportunityPostUpdateCalculatedFields is on Update");

                    }
                    else
                    {                        
                        tracer.Trace("OpportunityPostUpdateCalculatedFields is on Create" + enOpportunity.Id);
                    }
                    var enOppty = _orgService.Retrieve(enOpportunity.LogicalName, enOpportunity.Id, new ColumnSet("rsa_gwpinclfrontingpc", "rsa_actualvalue", "rsa_rsagwp", "rsa_commissionunderlying1"));

                    if (enOpportunity.Attributes.Contains("rsa_rsariskmanagementbursary_dc") || enOpportunity.Attributes.Contains("rsa_worktransfer1")
                        || enOpportunity.Attributes.Contains("rsa_vqs_dc")
                        || enOpportunity.Attributes.Contains("rsa_commissionunderlying1")
                        || enOpportunity.Attributes.Contains("rsa_rsalocalofficeoverriders")
                         || enOpportunity.Attributes.Contains("rsa_overseastax_dc")
                          || enOpportunity.Attributes.Contains("rsa_captivepremium_dc")
                       || enOpportunity.Attributes.Contains("rsa_rsagwp")
                        || enOpportunity.Attributes.Contains("rsa_propertydamagepremium_dc")
                        || enOpportunity.Attributes.Contains("rsa_thisyearsrsaline")
                        || enOpportunity.Attributes.Contains("rsa_polpremium")
                        || enOpportunity.Attributes.Contains("rsa_thisyearsrsapolline")
                        || enOpportunity.Attributes.Contains("rsa_commissionunderlying")
                        || enOpportunity.Attributes.Contains("rsa_internalreinsurance_dc")
                        || enOpportunity.Attributes.Contains("rsa_x100slippremium")
                          || enOpportunity.Attributes.Contains("rsa_thisyearsrsaline")
                        )

                    {
                        tracer.Trace("Calling getGWPPostDeductions");
                        enOpportunity["rsa_gwppostdeductions_dc"] = getGWPPostDeductions(_orgService, tracer, enOpportunity, enOpportunityImage, enOppty);
                        tracer.Trace("Executed getGWPPostDeductions");
                    }

                    tracer.Trace("After getGWPPostDeductions");


                    //Actual Line Share Change
                    if (enOpportunity.Attributes.Contains("rsa_rsasharegsl") || enOpportunity.Attributes.Contains("rsa_pyrsashare")
                        || enOpportunity.Attributes.Contains("rsa_pygwpexgrossupsterrorismgbp") || enOpportunity.Attributes.Contains("rsa_fximpactonpremiumgbp_dc")
                        || enOpportunity.Attributes.Contains("rsa_pygwpinclfrontinggbp") || enOpportunity.Attributes.Contains("rsa_pycaptivepremiumgbp_dc")
                        || enOpportunity.Attributes.Contains("rsa_rsapyinternalreinsurancegbp") || enOpportunity.Attributes.Contains("rsa_rsapycoinsurancegbp")
                        || enOpportunity.Attributes.Contains("rsa_pygrosspremiumgbp") || enOpportunity.Attributes.Contains("rsa_pygrosspremiumvariancegbp"))
                    {
                        tracer.Trace("Calling getActualLineShareChange");
                        enOpportunity["rsa_rsaactuallinesharechange"] = getActualLineShareChange(_orgService, tracer, enOpportunity, enOpportunityImage);
                        tracer.Trace("Executed getActualLineShareChange");
                    }

                    tracer.Trace("After getActualLineShareChange");

                    //rsa_grosspremiumvariancegbp_dc
                    if (enOpportunity.Attributes.Contains("rsa_grosspremiumvariancepc") || enOpportunity.Attributes.Contains("rsa_exchangerategslc")
                        || enOpportunity.Attributes.Contains("rsa_totalgwp100gsl")|| enOpportunity.Attributes.Contains("rsa_rsasharegsl") ||
                            enOpportunity.Attributes.Contains("rsa_rsagwppc") || enOpportunity.Attributes.Contains("rsa_grosspremiumvariancepc"))
                    {
                        tracer.Trace("Calling getGrossPremiumVarianceGBP");
                        enOpportunity["rsa_grosspremiumvariancegbp_dc"] = getGrossPremiumVarianceGBP(_orgService, enOpportunity, enOpportunityImage);
                        tracer.Trace("Executed getGrossPremiumVarianceGBP");
                    }


                    //CY Captive Premium (GBP)
                    if (enOpportunity.Attributes.Contains("rsa_rsacaptivepremiumpc") || enOpportunity.Attributes.Contains("rsa_exchangerategslc"))
                    {
                        tracer.Trace("Calling rsa_rsacycaptivepremiumgbp");
                        enOpportunity["rsa_rsacycaptivepremiumgbp"] = getCYCaptivePremiumGBP(_orgService, enOpportunity, enOpportunityImage);
                        tracer.Trace("Executed rsa_rsacycaptivepremiumgbp");
                    }

                    //rsa_rsagwppc
                    if (enOpportunity.Attributes.Contains("rsa_totalgwp100gsl") || enOpportunity.Attributes.Contains("rsa_rsasharegsl"))
                    {
                        tracer.Trace("Calling getRSAGWPPC");
                        enOpportunity["rsa_rsagwppc"] = getRSAGWPPC(_orgService, enOpportunity, enOpportunityImage, tracer);
                        tracer.Trace("Executed getRSAGWPPC ");
                    }


                    //rsa_gwpinclfrontinggbp_dc
                    if (enOpportunity.Attributes.Contains("rsa_gwpinclfrontingpc") || enOpportunity.Attributes.Contains("rsa_exchangerategslc")
                        || enOpportunity.Attributes.Contains("rsa_rsagwppc") || enOpportunity.Attributes.Contains("rsa_grosspremiumvariancepc")
                         || enOpportunity.Attributes.Contains("rsa_totalgwp100gsl") || enOpportunity.Attributes.Contains("rsa_rsasharegsl"))

                    {
                        tracer.Trace("Calling rsa_gwpinclfrontingpc");
                        enOpportunity["rsa_rsagwpinclfrontinggbp"] = getGWPInclFrontingGBP(_orgService, enOpportunity, enOpportunityImage, enOppty);
                        tracer.Trace("Executed rsa_gwpinclfrontingpc");
                    }

                    //rsa_netpremium_dc
                    if (enOpportunity.Attributes.Contains("rsa_policyid") || enOpportunity.Attributes.Contains("rsa_commission"))
                    {
                        tracer.Trace("Calling rsa_netpremium_dc");
                        enOpportunity["rsa_netpremium_dc"] = getNetPremium(_orgService, enOpportunity, enOpportunityImage, tracer);
                        tracer.Trace("Executed rsa_netpremium_dc");
                    }

                    //rsa_netpremiumgbpgsl_dc
                    //bug 962
                    if (enOpportunity.Attributes.Contains("rsa_netpremiumgbpgsl_dc"))
                    {
                        tracer.Trace("Calling rsa_netpremiumgbpgsl_dc");
                        enOpportunity["rsa_netpremiumgbpgsl_dc"] = getNetPremiumGBPGSL(_orgService, enOpportunity, enOpportunityImage);
                        tracer.Trace("Executed rsa_netpremiumgbpgsl_dc");
                    }

                    //rsa_nottakenuplastyearspremiumvalue_dc
                    if (enOpportunity.Attributes.Contains("rsa_lineofbusiness") || enOpportunity.Attributes.Contains("rsa_opportunitystage")
                        || enOpportunity.Attributes.Contains("rsa_rsaexpiringpremium"))
                    {
                        tracer.Trace("Calling rsa_nottakenuplastyearspremiumvalue_dc");
                        enOpportunity["rsa_nottakenuplastyearspremiumvalue_dc"] = getNotTakenUpLastYearsPremiumValue(_orgService, enOpportunity, enOpportunityImage);
                        tracer.Trace("Executed rsa_nottakenuplastyearspremiumvalue_dc");
                    }

                    //rsa_rsabusinesscombinedvalue_dc
                    if (enOpportunity.Attributes.Contains("rsa_opportunityvalue") || enOpportunity.Attributes.Contains("rsa_businesscombined"))
                    {
                        tracer.Trace("Calling getBusinessCombinedValue");
                        enOpportunity["rsa_rsabusinesscombinedvalue_dc"] = getBusinessCombinedValue(_orgService, tracer, enOpportunity, enOpportunityImage);
                        tracer.Trace("Executed getBusinessCombinedValue");
                    }


                    //rsa_tripounds_dc
                    if (enOpportunity.Attributes.Contains("rsa_lineofbusiness")
                        || enOpportunity.Attributes.Contains("rsa_totalgwp100gsl")
                    || enOpportunity.Attributes.Contains("rsa_tyelr_dc")
                    || enOpportunity.Attributes.Contains("rsa_rsaquotedpremium")
                       || enOpportunity.Attributes.Contains("rsa_thisyrsexplastyrsrates"))
                    {
                        tracer.Trace("Calling getTRIPounds");
                        enOpportunity["rsa_tripounds_dc"] = getTRIPounds(_orgService, tracer, enOpportunity, enOpportunityImage);
                        tracer.Trace("Executed getTRIPounds");
                    }

                    //rsa_worktransfer_dc
                    if (enOpportunity.Attributes.Contains("rsa_rsagwp") || enOpportunity.Attributes.Contains("rsa_worktransfer1") ||
                        enOpportunity.Attributes.Contains("rsa_propertydamagepremium_dc") ||
                         enOpportunity.Attributes.Contains("rsa_thisyearsrsaline") ||
                          enOpportunity.Attributes.Contains("rsa_thisyearsrsapolline") ||
                           enOpportunity.Attributes.Contains("rsa_internalreinsurance_dc") ||
                            enOpportunity.Attributes.Contains("rsa_polpremium")

                        )
                    {
                        tracer.Trace("Calling getWorkTransfer");
                        enOpportunity["rsa_worktransfer_dc"] = getWorkTransfer(_orgService, enOpportunity, enOpportunityImage, tracer);
                        tracer.Trace("Executed getWorkTransfer");
                    }
                    decimal inYearBenefitValue = 0;
                    //rsa_inyearbenefit_dc
                    if (enOpportunity.Attributes.Contains("rsa_actualvalue") || enOpportunity.Attributes.Contains("rsa_closedate") || enOpportunity.Attributes.Contains("rsa_opportunityvalue"))
                    {
                        tracer.Trace("Calling getInYearBenefit");
                        enOpportunity["rsa_inyearbenefit_dc"] = getInYearBenefit(_orgService, enOpportunity, enOpportunityImage, tracer, enOppty);
                        inYearBenefitValue = enOpportunity.GetAttributeValue<decimal>("rsa_inyearbenefit_dc");
                        tracer.Trace("Executed getInYearBenefit");
                    }

                    //rsa_nextyearbenefit_dc
                    if (enOpportunity.Attributes.Contains("rsa_actualvalue") || enOpportunity.Attributes.Contains("rsa_inyearbenefit_dc"))
                    {
                        tracer.Trace("Calling rsa_nextyearbenefit_dc");
                        enOpportunity["rsa_nextyearbenefit_dc"] = getNextYearBenefit(_orgService, enOpportunity, enOpportunityImage, enOppty, inYearBenefitValue, tracer);
                        tracer.Trace("Executed rsa_nextyearbenefit_dc");
                    }

                    //rsa_hrvalue1_dc
                    if (enOpportunity.Attributes.Contains("rsa_iybvalue") || enOpportunity.Attributes.Contains("rsa_hr1"))
                    {
                        tracer.Trace("Calling getHRValue1");
                        enOpportunity["rsa_hrvalue1_dc"] = getHRValue1(_orgService, enOpportunity, enOpportunityImage);
                        tracer.Trace("Executed getHRValue1");
                    }
                    //SMEDealsShopValue
                    if (enOpportunity.Attributes.Contains("rsa_shop") || enOpportunity.Attributes.Contains("rsa_opportunityvalue"))
                    {
                        tracer.Trace("Calling SMEDealsShopValue");
                        enOpportunity["rsa_rsashopvalue_dc"] = SMEDealsShopValue(_orgService, enOpportunity, enOpportunityImage);
                        tracer.Trace("Executed SMEDealsShopValue");
                    }
                    //rsa_rsapivalue_dc
                    if (enOpportunity.Attributes.Contains("rsa_pi") || enOpportunity.Attributes.Contains("rsa_opportunityvalue"))
                    {
                        tracer.Trace("Calling SMEDealsPiValue");
                        enOpportunity["rsa_rsapivalue_dc"] = SMEDealsPiValue(_orgService, enOpportunity, enOpportunityImage);
                        tracer.Trace("Executed SMEDealsPiValue");
                    }

                    // PHR Value(£)rsa_rsahrvalue_dc
                    //PHR % rsa_hr
                    if (enOpportunity.Attributes.Contains("rsa_hr") || enOpportunity.Attributes.Contains("rsa_opportunityvalue"))
                    {
                        tracer.Trace("Calling SMEDealsHRValue");
                        enOpportunity["rsa_rsahrvalue_dc"] = SMEDealsHRValue(_orgService, enOpportunity, enOpportunityImage);
                        tracer.Trace("Executed SMEDealsHRValue");
                    }
                    //Commercial Vehicle Value(£) rsa_rsacommercialvehiclevalue_dc
                    //Commercial Vehicle % rsa_commercialvehicle
                    if (enOpportunity.Attributes.Contains("rsa_commercialvehicle") || enOpportunity.Attributes.Contains("rsa_opportunityvalue"))
                    {
                        tracer.Trace("Calling SMEDealsCommercialVehicleValue");
                        enOpportunity["rsa_rsacommercialvehiclevalue_dc"] = SMEDealsCommercialVehicleValue(_orgService, enOpportunity, enOpportunityImage);
                        tracer.Trace("Executed SMEDealsCommercialVehicleValue");
                    }
                    //                    PA & Travel Value(£) rsa_patravelvalue_dc
                    //PA & Travel % rsa_patravel
                    if (enOpportunity.Attributes.Contains("rsa_patravel") || enOpportunity.Attributes.Contains("rsa_opportunityvalue"))
                    {
                        tracer.Trace("Calling SMEDealsPATravelValue");
                        enOpportunity["rsa_patravelvalue_dc"] = SMEDealsPATravelValue(_orgService, enOpportunity, enOpportunityImage);
                        tracer.Trace("Executed SMEDealsPATravelValue");
                    }
                    //                    D & O Value(£) rsa_rsadovalue_dc
                    //D & O % rsa_do
                    if (enOpportunity.Attributes.Contains("rsa_do") || enOpportunity.Attributes.Contains("rsa_opportunityvalue"))
                    {
                        tracer.Trace("Calling SMEDealsDOValue");
                        enOpportunity["rsa_rsadovalue_dc"] = SMEDealsDOValue(_orgService, enOpportunity, enOpportunityImage);
                        tracer.Trace("Executed SMEDealsDOValue");
                    }
                    //                    Office Value(£) rsa_officevalue_dc
                    //Office % rsa_office
                    if (enOpportunity.Attributes.Contains("rsa_office") || enOpportunity.Attributes.Contains("rsa_opportunityvalue"))
                    {
                        tracer.Trace("Calling SMEDealsOfficeValue");
                        enOpportunity["rsa_officevalue_dc"] = SMEDealsOfficeValue(_orgService, enOpportunity, enOpportunityImage);
                        tracer.Trace("Executed SMEDealsOfficeValue");
                    }
                    _orgService.Update(enOpportunity);

                    tracer.Trace("Opportunity Updated Successfully");


                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                CrmPluginHelper.CatchFaultException(ex, this);
            }
            catch (InvalidPluginExecutionException ex)
            {
                CrmPluginHelper.CatchInvalidPluginException(ex);
            }
            catch (Exception ex)
            {
                CrmPluginHelper.CatchGenericException(ex, this);
            }
        }
        public static decimal SMEDealsMinifleetValue(IOrganizationService orgService, Entity enOpportunity, Entity enPreImage, ITracingService tracer)
        {
            tracer.Trace("InsideSMEDealsMinifleetValue ");
            Money mopportunityValue = (enOpportunity.Attributes.Contains("rsa_opportunityvalue") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<Money>("rsa_opportunityvalue").ToString())) ? enOpportunity.GetAttributeValue<Money>("rsa_opportunityvalue")
                : (enPreImage.Attributes.Contains("rsa_opportunityvalue") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<Money>("rsa_opportunityvalue").ToString())) ? enPreImage.GetAttributeValue<Money>("rsa_opportunityvalue") : null;
            decimal opptyValue = Convert.ToDecimal(mopportunityValue.Value);
            tracer.Trace("InsideSMEDealsMinifleetValue opptyValue " + opptyValue);
            decimal minifleet = (enOpportunity.Attributes.Contains("rsa_minifleet") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_minifleet").ToString())) ? enOpportunity.GetAttributeValue<decimal>("rsa_minifleet")
             : (enPreImage.Attributes.Contains("rsa_minifleet") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_minifleet").ToString())) ? enPreImage.GetAttributeValue<decimal>("rsa_minifleet") : 0.00m;
            //Modified On: 07/11/2022 ; Chandani ; CR 1243,1778 ; Handle percentage fields
            minifleet = minifleet / 100; 
            decimal MinifleetValue = (opptyValue) * (minifleet);
            tracer.Trace("InsideSMEDealsMinifleetValue MinifleetValue " + MinifleetValue);
            return MinifleetValue;
        }
        public static decimal SMEDealsOfficeValue(IOrganizationService orgService, Entity enOpportunity, Entity enPreImage)
        {
            Money mopportunityValue = (enOpportunity.Attributes.Contains("rsa_opportunityvalue") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<Money>("rsa_opportunityvalue").ToString())) ? enOpportunity.GetAttributeValue<Money>("rsa_opportunityvalue")
    : (enPreImage.Attributes.Contains("rsa_opportunityvalue") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<Money>("rsa_opportunityvalue").ToString())) ? enPreImage.GetAttributeValue<Money>("rsa_opportunityvalue") : null;
            decimal opptyValue = Convert.ToDecimal(mopportunityValue.Value);
            decimal Office = (enOpportunity.Attributes.Contains("rsa_office") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_office").ToString())) ? enOpportunity.GetAttributeValue<decimal>("rsa_office")
                : (enPreImage.Attributes.Contains("rsa_office") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_office").ToString())) ? enPreImage.GetAttributeValue<decimal>("rsa_office") : 0;
            //Modified On: 07/11/2022 ; Chandani ; CR 1243,1778 ; Handle percentage fields
            Office = Office / 100;
            //Modified On: 07/09/2022 ; Nida ; CR 1243,1778 ; Handle percentage fields
            //decimal OfficeValue = opptyValue * (Office / 100);
            decimal OfficeValue = opptyValue * Office;
            return OfficeValue;
        }
        public static decimal SMEDealsDOValue(IOrganizationService orgService, Entity enOpportunity, Entity enPreImage)
        {
            Money mopportunityValue = (enOpportunity.Attributes.Contains("rsa_opportunityvalue") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<Money>("rsa_opportunityvalue").ToString())) ? enOpportunity.GetAttributeValue<Money>("rsa_opportunityvalue")
    : (enPreImage.Attributes.Contains("rsa_opportunityvalue") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<Money>("rsa_opportunityvalue").ToString())) ? enPreImage.GetAttributeValue<Money>("rsa_opportunityvalue") : null;
            decimal opptyValue = Convert.ToDecimal(mopportunityValue.Value);
            decimal dO = (enOpportunity.Attributes.Contains("rsa_do") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_do").ToString())) ? enOpportunity.GetAttributeValue<decimal>("rsa_do")
                : (enPreImage.Attributes.Contains("rsa_do") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_do").ToString())) ? enPreImage.GetAttributeValue<decimal>("rsa_do") : 0;
            //Modified On: 07/11/2022 ; Chandani ; CR 1243,1778 ; Handle percentage fields
            dO = dO / 100;
            //Modified On: 07/09/2022 ; Nida ; CR 1243,1778 ; Handle percentage fields
            //decimal dOValue = opptyValue * (dO / 100);
            decimal dOValue = opptyValue * dO;
            return dOValue;
        }

        public static decimal SMEDealsPATravelValue(IOrganizationService orgService, Entity enOpportunity, Entity enPreImage)
        {
            Money mopportunityValue = (enOpportunity.Attributes.Contains("rsa_opportunityvalue") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<Money>("rsa_opportunityvalue").ToString())) ? enOpportunity.GetAttributeValue<Money>("rsa_opportunityvalue")
    : (enPreImage.Attributes.Contains("rsa_opportunityvalue") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<Money>("rsa_opportunityvalue").ToString())) ? enPreImage.GetAttributeValue<Money>("rsa_opportunityvalue") : null;
            decimal opptyValue = Convert.ToDecimal(mopportunityValue.Value);
            decimal patravel = (enOpportunity.Attributes.Contains("rsa_patravel") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_patravel").ToString())) ? enOpportunity.GetAttributeValue<decimal>("rsa_patravel")
                : (enPreImage.Attributes.Contains("rsa_patravel") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_patravel").ToString())) ? enPreImage.GetAttributeValue<decimal>("rsa_patravel") : 0;
            //Modified On: 07/11/2022 ; Chandani ; CR 1243,1778 ; Handle percentage fields
            patravel = patravel / 100;
            //Modified On: 07/09/2022 ; Nida ; CR 1243,1778 ; Handle percentage fields
            //decimal patraveleValue = opptyValue * (patravel / 100);
            decimal patraveleValue = opptyValue * patravel;
            return patraveleValue;
        }
        public static decimal SMEDealsCommercialVehicleValue(IOrganizationService orgService, Entity enOpportunity, Entity enPreImage)
        {
            Money mopportunityValue = (enOpportunity.Attributes.Contains("rsa_opportunityvalue") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<Money>("rsa_opportunityvalue").ToString())) ? enOpportunity.GetAttributeValue<Money>("rsa_opportunityvalue")
    : (enPreImage.Attributes.Contains("rsa_opportunityvalue") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<Money>("rsa_opportunityvalue").ToString())) ? enPreImage.GetAttributeValue<Money>("rsa_opportunityvalue") : null;
            decimal opptyValue = Convert.ToDecimal(mopportunityValue.Value);
            decimal CommercialVehicle = (enOpportunity.Attributes.Contains("rsa_commercialvehicle") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_commercialvehicle").ToString())) ? enOpportunity.GetAttributeValue<decimal>("rsa_commercialvehicle")
                : (enPreImage.Attributes.Contains("rsa_commercialvehicle") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_commercialvehicle").ToString())) ? enPreImage.GetAttributeValue<decimal>("rsa_commercialvehicle") : 0;
            //Modified On: 07/11/2022 ; Chandani ; CR 1243,1778 ; Handle percentage fields
            CommercialVehicle = CommercialVehicle / 100;
            //Modified On: 07/09/2022 ; Nida ; CR 1243,1778 ; Handle percentage fields
            //decimal CommercialVehicleValue = opptyValue * (CommercialVehicle / 100);
            decimal CommercialVehicleValue = opptyValue * CommercialVehicle;
            return CommercialVehicleValue;
        }
        public static decimal SMEDealsHRValue(IOrganizationService orgService, Entity enOpportunity, Entity enPreImage)
        {
            Money mopportunityValue = (enOpportunity.Attributes.Contains("rsa_opportunityvalue") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<Money>("rsa_opportunityvalue").ToString())) ? enOpportunity.GetAttributeValue<Money>("rsa_opportunityvalue")
    : (enPreImage.Attributes.Contains("rsa_opportunityvalue") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<Money>("rsa_opportunityvalue").ToString())) ? enPreImage.GetAttributeValue<Money>("rsa_opportunityvalue") : null;
            decimal opptyValue = Convert.ToDecimal(mopportunityValue.Value);
            decimal HR = (enOpportunity.Attributes.Contains("rsa_hr") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_hr").ToString())) ? enOpportunity.GetAttributeValue<decimal>("rsa_hr")
                : (enPreImage.Attributes.Contains("rsa_hr") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_hr").ToString())) ? enPreImage.GetAttributeValue<decimal>("rsa_hr") : 0;
            //Modified On: 07/11/2022 ; Chandani ; CR 1243,1778 ; Handle percentage fields
            HR = HR / 100;
            //Modified On: 07/09/2022 ; Nida ; CR 1243,1778 ; Handle percentage fields
            //decimal PHRValue = opptyValue * (HR / 100);
            decimal PHRValue = opptyValue * HR;
            return PHRValue;
        }
        public static decimal SMEDealsPiValue(IOrganizationService orgService, Entity enOpportunity, Entity enPreImage)
        {
            Money mopportunityValue = (enOpportunity.Attributes.Contains("rsa_opportunityvalue") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<Money>("rsa_opportunityvalue").ToString())) ? enOpportunity.GetAttributeValue<Money>("rsa_opportunityvalue")
    : (enPreImage.Attributes.Contains("rsa_opportunityvalue") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<Money>("rsa_opportunityvalue").ToString())) ? enPreImage.GetAttributeValue<Money>("rsa_opportunityvalue") : null;
            decimal opptyValue = Convert.ToDecimal(mopportunityValue.Value);
            decimal Pi = (enOpportunity.Attributes.Contains("rsa_pi") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_pi").ToString())) ? enOpportunity.GetAttributeValue<decimal>("rsa_pi")
                : (enPreImage.Attributes.Contains("rsa_pi") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_pi").ToString())) ? enPreImage.GetAttributeValue<decimal>("rsa_pi") : 0;
            //Modified On: 07/11/2022 ; Chandani ; CR 1243,1778 ; Handle percentage fields
            Pi = Pi / 100;
            //Modified On: 07/09/2022 ; Nida ; CR 1243,1778 ; Handle percentage fields
            //decimal PiValue = opptyValue * (Pi / 100);
            decimal PiValue = opptyValue * Pi;
            return PiValue;
        }

        public static decimal SMEDealsShopValue(IOrganizationService orgService, Entity enOpportunity, Entity enPreImage)
        {
            Money mopportunityValue = (enOpportunity.Attributes.Contains("rsa_opportunityvalue") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<Money>("rsa_opportunityvalue").ToString())) ? enOpportunity.GetAttributeValue<Money>("rsa_opportunityvalue")
    : (enPreImage.Attributes.Contains("rsa_opportunityvalue") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<Money>("rsa_opportunityvalue").ToString())) ? enPreImage.GetAttributeValue<Money>("rsa_opportunityvalue") : null;
            decimal opptyValue = Convert.ToDecimal(mopportunityValue.Value);
            decimal shop = (enOpportunity.Attributes.Contains("rsa_shop") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_shop").ToString())) ? enOpportunity.GetAttributeValue<decimal>("rsa_shop")
                : (enPreImage.Attributes.Contains("rsa_shop") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_shop").ToString())) ? enPreImage.GetAttributeValue<decimal>("rsa_shop") : 0;
            //Modified On: 07/11/2022 ; Chandani ; CR 1243,1778 ; Handle percentage fields
            shop = shop / 100;
            //Modified On: 07/09/2022 ; Nida ; CR 1243,1778 ; Handle percentage fields
            //decimal shopValue = opptyValue * (shop / 100);
            decimal shopValue = opptyValue * shop;
            return shopValue;
        }

        public decimal getHRValue1(IOrganizationService orgService, Entity enOpportunity, Entity enPreImage)
        {
            decimal HRValue1 = 0;
            decimal rsa_hr1 = 0, rsa_iybvalue = 0;
            rsa_hr1 = (enOpportunity.Attributes.Contains("rsa_hr1") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_hr1").ToString())) ? enOpportunity.GetAttributeValue<decimal>("rsa_hr1")
                    : ((enPreImage.Attributes.Contains("rsa_hr1") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_hr1").ToString())) ? enPreImage.GetAttributeValue<decimal>("rsa_hr1") : 0);
            rsa_iybvalue = (enOpportunity.Attributes.Contains("rsa_iybvalue") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<Money>("rsa_iybvalue").ToString())) ? (decimal)(enOpportunity.GetAttributeValue<Money>("rsa_iybvalue")).Value
                        : ((enPreImage.Attributes.Contains("rsa_iybvalue") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<Money>("rsa_iybvalue").ToString())) ? (decimal)(enPreImage.GetAttributeValue<Money>("rsa_iybvalue")).Value : 0);
            //Modified On: 07/11/2022 ; Chandani ; CR 1243,1778 ; Handle percentage fields
            rsa_hr1 = rsa_hr1 / 100;
            //Modified On: 07/09/2022 ; Nida ; CR 1243,1778 ; Handle percentage fields
            //HRValue1 = rsa_iybvalue * (rsa_hr1 / 100);
            HRValue1 = rsa_iybvalue * rsa_hr1;
            return HRValue1;
        }

        public static decimal getInYearBenefit(IOrganizationService orgService, Entity enOpportunity, Entity enPreImage, ITracingService tracer, Entity enOpptyRetrieve)
        {
            decimal InYearBenefit = 0;
            DateTime closeDate = new DateTime();
            decimal ActualValue = 0.00m;
            //var enOppty = orgService.Retrieve(enOpportunity.LogicalName, enOpportunity.Id, new ColumnSet("rsa_actualvalue"));
            ActualValue = enOpptyRetrieve.Attributes.Contains("rsa_actualvalue")
                ? enOpptyRetrieve.GetAttributeValue<decimal>("rsa_actualvalue") : 0.00m;
            tracer.Trace("ActualValue" + ActualValue);
            //rsa_actualvalue = enOpportunity.Attributes.Contains("rsa_actualvalue") ? enOpportunity.GetAttributeValue<decimal>("rsa_actualvalue")
            //        : (enPreImage.Attributes.Contains("rsa_actualvalue") ?  enPreImage.GetAttributeValue<decimal>("rsa_actualvalue") : 0);

            if (enOpportunity.Attributes.Contains("rsa_closedate") || enPreImage.Attributes.Contains("rsa_closedate"))
            {
                closeDate = enOpportunity.Attributes.Contains("rsa_closedate") ? enOpportunity.GetAttributeValue<DateTime>("rsa_closedate")
                    : (enPreImage.Attributes.Contains("rsa_closedate") ? enPreImage.GetAttributeValue<DateTime>("rsa_closedate") : DateTime.Today);
                DateTime closeDate1 = new DateTime(closeDate.Year, 12, 31);
                tracer.Trace("closeDate1" + closeDate1.ToString());
                TimeSpan t1 = closeDate1 - closeDate.AddDays(-1);
                tracer.Trace("t1" + t1.ToString());
                //Bug id 875
                InYearBenefit = ActualValue * (decimal)(t1.TotalDays / 365);
            }
            return InYearBenefit;
        }

        public static decimal getNextYearBenefit(IOrganizationService orgService, Entity enOpportunity, Entity enPreImage, Entity enOpptyRetrieve, decimal inYearBenefitValue, ITracingService tracer)
        {
            decimal ActualValue = enOpptyRetrieve.Attributes.Contains("rsa_actualvalue") ? enOpptyRetrieve.GetAttributeValue<decimal>("rsa_actualvalue") : 0.00m;
            decimal inYearBenefit = 0.00m;
            if (inYearBenefitValue != 0.00m)
            {
                inYearBenefit = (enOpportunity.Attributes.Contains("rsa_inyearbenefit_dc") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_inyearbenefit_dc").ToString()))
                    ? enOpportunity.GetAttributeValue<decimal>("rsa_inyearbenefit_dc")
                : ((enPreImage.Attributes.Contains("rsa_inyearbenefit_dc") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_inyearbenefit_dc").ToString()))
                ? enPreImage.GetAttributeValue<decimal>("rsa_inyearbenefit_dc") : 0);
            }
            else
            {
                inYearBenefit = inYearBenefitValue;
            }
            decimal nextYearBenefit = ActualValue - inYearBenefit;
            return nextYearBenefit;
        }





        public static decimal getWorkTransfer(IOrganizationService orgService, Entity enOpportunity, Entity enPreImage, ITracingService tracer)
        {
            //decimal rsagwp = (enOpportunity.Attributes.Contains("rsa_rsagwp") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_rsagwp").ToString())) 
            //    ? enOpportunity.GetAttributeValue<decimal>("rsa_rsagwp")
            //    : ((enPreImage.Attributes.Contains("rsa_rsagwp") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_rsagwp").ToString())) 
            //    ?  enPreImage.GetAttributeValue<decimal>("rsa_rsagwp") : 0);
            tracer.Trace("calling getRSAGWP ");
            decimal rsagwp = getRSAGWP(orgService, tracer, enOpportunity, enPreImage);
            tracer.Trace("rsagwp from getWorkTransfer" + rsagwp);
            decimal worktransfer1 = (enOpportunity.Attributes.Contains("rsa_worktransfer1") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_worktransfer1").ToString()))
                ? enOpportunity.GetAttributeValue<decimal>("rsa_worktransfer1")
                : (enPreImage.Attributes.Contains("rsa_worktransfer1") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_worktransfer1").ToString()))
                ? enPreImage.GetAttributeValue<decimal>("rsa_worktransfer1") : 0;
            //Modified On: 07/11/2022 ; Chandani ; CR 1243,1778 ; Handle percentage fields
            worktransfer1 = worktransfer1 / 100;
            //Modified On: 07/09/2022 ; Nida ; CR 1243,1778 ; Handle percentage fields
            //decimal WorkTransfer = ((rsagwp) * (worktransfer1 / 100));
            decimal WorkTransfer = ((rsagwp) * worktransfer1);
            tracer.Trace("WorkTransfer from getWorkTransfer" + WorkTransfer);
            return WorkTransfer;
        }




        private static object getTRIPounds(IOrganizationService _orgService, ITracingService tracer, Entity enOpportunity, Entity enPreImage)
        {
            decimal TRIPounds = 0;

            string lineofBusiness = string.Empty;
            if (enOpportunity.Attributes.Contains("rsa_lineofbusiness") || enPreImage.Attributes.Contains("rsa_lineofbusiness"))
            {
                tracer.Trace("rsa_lineofbusiness has data");
                EntityReference lineofBusinessID = enOpportunity.Attributes.Contains("rsa_lineofbusiness") ? (enOpportunity.GetAttributeValue<EntityReference>("rsa_lineofbusiness"))
                    : enPreImage.Attributes.Contains("rsa_lineofbusiness") ? (enPreImage.GetAttributeValue<EntityReference>("rsa_lineofbusiness")) : null;
                tracer.Trace("lineofBusinessID" + lineofBusinessID);
                if (lineofBusinessID != null)
                {
                    //var enLOBName = _orgService.Retrieve(lineofBusinessID.LogicalName, lineofBusinessID.Id, new ColumnSet("rsa_name"));
                    CommonUtility common = new CommonUtility();
                    lineofBusiness = common.GetNameByEntityId(_orgService, "rsa_lineofbusiness", lineofBusinessID.Id, "rsa_name");
                    //lineofBusiness = lineofBusinessID.Name;


                }
                if (lineofBusiness.Equals("GSL - Renewal"))
                {
                    tracer.Trace("rsa_lineofbusiness = GSL - Renewal");
                    decimal rsa_totalgwp100gsl = 0, rsa_tyelr_dc = 0;

                    rsa_totalgwp100gsl = (enOpportunity.Attributes.Contains("rsa_totalgwp100gsl") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_totalgwp100gsl").ToString()))
                        ? enOpportunity.GetAttributeValue<decimal>("rsa_totalgwp100gsl")
                            : ((enPreImage.Attributes.Contains("rsa_totalgwp100gsl") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_totalgwp100gsl").ToString()))
                            ? enPreImage.GetAttributeValue<decimal>("rsa_totalgwp100gsl") : 0);
                    tracer.Trace("rsa_totalgwp100gsl " + rsa_totalgwp100gsl);

                    rsa_tyelr_dc = (enOpportunity.Attributes.Contains("rsa_tyelr_dc") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_tyelr_dc").ToString()))
                        ? enOpportunity.GetAttributeValue<decimal>("rsa_tyelr_dc")
                            : ((enPreImage.Attributes.Contains("rsa_tyelr_dc") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_tyelr_dc").ToString())) ? enPreImage.GetAttributeValue<decimal>("rsa_tyelr_dc") : 0);
                    tracer.Trace("rsa_tyelr_dc " + rsa_tyelr_dc);
                    if (rsa_tyelr_dc != 0)
                    {
                        tracer.Trace("TRIPounds " + (rsa_totalgwp100gsl - rsa_tyelr_dc) / rsa_tyelr_dc);
                        TRIPounds = (rsa_totalgwp100gsl - rsa_tyelr_dc) / rsa_tyelr_dc;
                        tracer.Trace("TRIPounds " + TRIPounds);
                    }
                }



                else
                {
                    tracer.Trace("totalamount 513 ");
                    decimal varTotalAmount = 0;
                    decimal varthisyrsexplastyrsrates = 0;
                    Money totalamount = null;
                    Money thisyrsexplastyrsrates = null;                    //bug id 1194
                    //totalamount = (enOpportunity.Attributes.Contains("rsa_rsaquotedpremium") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<Money>("rsa_rsaquotedpremium").ToString())) 
                    //    ? enOpportunity.GetAttributeValue<Money>("rsa_rsaquotedpremium")
                    //        : (enPreImage.Attributes.Contains("rsa_rsaquotedpremium") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<Money>("rsa_rsaquotedpremium").ToString())) 
                    //        ? enPreImage.GetAttributeValue<Money>("rsa_rsaquotedpremium") : null;
                    totalamount = enOpportunity.Attributes.Contains("rsa_rsaquotedpremium") ? enOpportunity.GetAttributeValue<Money>("rsa_rsaquotedpremium") :
                        enPreImage.Attributes.Contains("rsa_rsaquotedpremium") ? enPreImage.GetAttributeValue<Money>("rsa_rsaquotedpremium") : null;

                    if (totalamount != null)
                    {
                        varTotalAmount = totalamount.Value;
                    }
                    tracer.Trace("totalamount" + totalamount);
                    //rsa_thisyrsexplastyrsrates = (enOpportunity.Attributes.Contains("rsa_thisyrsexplastyrsrates") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<Money>("rsa_thisyrsexplastyrsrates").ToString()))
                    //    ? enOpportunity.GetAttributeValue<Money>("rsa_thisyrsexplastyrsrates")
                    //        : (enPreImage.Attributes.Contains("rsa_thisyrsexplastyrsrates") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<Money>("rsa_thisyrsexplastyrsrates").ToString()))
                    //        ? enPreImage.GetAttributeValue<Money>("rsa_thisyrsexplastyrsrates") : null;

                    thisyrsexplastyrsrates = enOpportunity.Attributes.Contains("rsa_thisyrsexplastyrsrates") ? enOpportunity.GetAttributeValue<Money>("rsa_thisyrsexplastyrsrates")
                        : enPreImage.Attributes.Contains("rsa_thisyrsexplastyrsrates") ? enPreImage.GetAttributeValue<Money>("rsa_thisyrsexplastyrsrates") : null;
                    tracer.Trace("rsa_thisyrsexplastyrsrates");
                    if (thisyrsexplastyrsrates != null)
                    {
                        varthisyrsexplastyrsrates = thisyrsexplastyrsrates.Value;
                    }
                    TRIPounds = varTotalAmount - varthisyrsexplastyrsrates;
                }
            }
            return TRIPounds;
        }
        public static decimal getRSAGWP(IOrganizationService orgService, ITracingService tracer, Entity enOpportunity, Entity enPreImage)
        {
            decimal propertydamagepremium_dc = (enOpportunity.Attributes.Contains("rsa_propertydamagepremium_dc") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_propertydamagepremium_dc").ToString())) ? enOpportunity.GetAttributeValue<decimal>("rsa_propertydamagepremium_dc") :
               (enPreImage.Attributes.Contains("rsa_propertydamagepremium_dc") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_propertydamagepremium_dc").ToString())) ? enPreImage.GetAttributeValue<decimal>("rsa_propertydamagepremium_dc") : 0;
            tracer.Trace("propertydamagepremium_dc LINE 522 " + propertydamagepremium_dc);
            decimal thisyearsrsaline = (enOpportunity.Attributes.Contains("rsa_thisyearsrsaline") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_rsalocalofficeoverriders").ToString()))
                ? enOpportunity.GetAttributeValue<decimal>("rsa_thisyearsrsaline") : (enPreImage.Attributes.Contains("rsa_thisyearsrsaline") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_thisyearsrsaline").ToString()))
                ? enPreImage.GetAttributeValue<decimal>("rsa_thisyearsrsaline") : 0;
            //Modified On: 07/11/2022 ; Chandani ; CR 1243,1778 ; Handle percentage fields
            thisyearsrsaline = thisyearsrsaline / 100;
            tracer.Trace("thisyearsrsaline LINE 526 " + thisyearsrsaline);

            decimal thisyearsrsapolline = (enOpportunity.Attributes.Contains("rsa_thisyearsrsapolline") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_thisyearsrsapolline").ToString()))
                ? enOpportunity.GetAttributeValue<decimal>("rsa_thisyearsrsapolline") : (enPreImage.Attributes.Contains("rsa_thisyearsrsapolline") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_thisyearsrsapolline").ToString()))
                ? enPreImage.GetAttributeValue<decimal>("rsa_thisyearsrsapolline") : 0;
            //Modified On: 07/11/2022 ; Chandani ; CR 1243,1778 ; Handle percentage fields
            thisyearsrsapolline = thisyearsrsapolline / 100;
            tracer.Trace("thisyearsrsapolline LINE 538 " + thisyearsrsapolline);
            decimal internalreinsurance_dc = (enOpportunity.Attributes.Contains("rsa_internalreinsurance_dc") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_internalreinsurance_dc").ToString()))
                ? enOpportunity.GetAttributeValue<decimal>("rsa_internalreinsurance_dc") : ((enPreImage.Attributes.Contains("rsa_internalreinsurance_dc") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_internalreinsurance_dc").ToString()))
                ? enPreImage.GetAttributeValue<decimal>("rsa_internalreinsurance_dc") : 0);
            tracer.Trace("internalreinsurance_dc LINE 542 " + internalreinsurance_dc);
            Money polpremium = (enOpportunity.Attributes.Contains("rsa_polpremium") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<Money>("rsa_polpremium").ToString()))
               ? enOpportunity.GetAttributeValue<Money>("rsa_polpremium") : (enPreImage.Attributes.Contains("rsa_polpremium") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<Money>("rsa_polpremium").ToString()))
               ? enPreImage.GetAttributeValue<Money>("rsa_polpremium") : null;
            // tracer.Trace("polpremium LINE 545" + polpremium);
            decimal valPOLPremium = 0.00m;
            if (polpremium != null && !polpremium.Equals(0.00m))  //bug 666 POl premium issue.
            {
                valPOLPremium = (polpremium).Value;
                tracer.Trace("polpremium LINE 551" + valPOLPremium);
            }
            decimal rsagwp = ((propertydamagepremium_dc * thisyearsrsaline) + (valPOLPremium * thisyearsrsapolline)) + internalreinsurance_dc;
            tracer.Trace("rsa_rsagwp: " + rsagwp.ToString());
            tracer.Trace("Exiting getRSAGWP");
            return rsagwp;
        }

        public static decimal getBusinessCombinedValue(IOrganizationService orgService, ITracingService trace, Entity enOpportunity, Entity enPreImage)
        {
            trace.Trace("Enter getBusinessCombinedValue");
            decimal opportunityvalue = (enOpportunity.Attributes.Contains("rsa_opportunityvalue") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<Money>("rsa_opportunityvalue").ToString()))
                ? (enOpportunity.GetAttributeValue<Money>("rsa_opportunityvalue")).Value : ((enPreImage.Attributes.Contains("rsa_opportunityvalue") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<Money>("rsa_opportunityvalue").ToString()))
                ? (enPreImage.GetAttributeValue<Money>("rsa_opportunityvalue")).Value : 0);
            trace.Trace("Enter opportunityvalue" + opportunityvalue);
            decimal businessCombined = (enOpportunity.Attributes.Contains("rsa_businesscombined") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_businesscombined").ToString()))
                ? enOpportunity.GetAttributeValue<decimal>("rsa_businesscombined") : ((enPreImage.Attributes.Contains("rsa_businesscombined") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_businesscombined").ToString()))
                ? enPreImage.GetAttributeValue<decimal>("rsa_businesscombined") : 0);
            //Modified On: 07/11/2022 ; Chandani ; CR 1243,1778 ; Handle percentage fields
            businessCombined = businessCombined / 100;
            trace.Trace("Enter businessCombined" + businessCombined);
            //Modified On: 07/09/2022 ; Nida ; CR 1243,1778 ; Handle percentage fields
            //decimal BusinessCombinedValue = opportunityvalue * (businessCombined/100);
            decimal BusinessCombinedValue = opportunityvalue * businessCombined;
            trace.Trace("Enter BusinessCombinedValue" + BusinessCombinedValue);
            return BusinessCombinedValue;
        }

        public static decimal getNotTakenUpLastYearsPremiumValue(IOrganizationService orgService, Entity enOpportunity, Entity enPreImage)
        {
            decimal NotTakenUpLastYearsPremiumValue = 0;
            if ((enOpportunity.Attributes.Contains("rsa_lineofbusiness") || enPreImage.Attributes.Contains("rsa_lineofbusiness"))
                && (enOpportunity.Attributes.Contains("rsa_opportunitystage") || enPreImage.Attributes.Contains("rsa_opportunitystage")))
            {
                //string lineofBusiness = enOpportunity.Attributes.Contains("rsa_lineofbusiness") ? (enOpportunity.GetAttributeValue<EntityReference>("rsa_lineofbusiness")).Name
                    //: (enPreImage.Attributes.Contains("rsa_lineofbusiness") ? (enPreImage.GetAttributeValue<EntityReference>("rsa_lineofbusiness")).Name : string.Empty);
                Guid lineofBusinessId = enOpportunity.Attributes.Contains("rsa_lineofbusiness") ? (enOpportunity.GetAttributeValue<EntityReference>("rsa_lineofbusiness")).Id
                    : (enPreImage.Attributes.Contains("rsa_lineofbusiness") ? (enPreImage.GetAttributeValue<EntityReference>("rsa_lineofbusiness")).Id : Guid.Empty);
                Guid opportunityStageId = enOpportunity.Attributes.Contains("rsa_opportunitystage") ? (enOpportunity.GetAttributeValue<EntityReference>("rsa_opportunitystage")).Id
                    : (enPreImage.Attributes.Contains("rsa_opportunitystage") ? (enPreImage.GetAttributeValue<EntityReference>("rsa_opportunitystage")).Id : Guid.Empty);

                CommonUtility common = new CommonUtility();
                string opportunityStage = common.GetNameByEntityId(orgService, "rsa_opportunitystage", opportunityStageId, "rsa_name");
                string lineofBusiness = common.GetNameByEntityId(orgService, "rsa_lineofbusiness", lineofBusinessId, "rsa_name");
                if (lineofBusiness.Contains("Renewal") && opportunityStage.Contains("Not Taken Up")
                    && (enOpportunity.Attributes.Contains("rsa_rsaexpiringpremium") || enPreImage.Attributes.Contains("rsa_rsaexpiringpremium")))
                {
                    //rsa_rsaexpiringpremium not available in D365 so replacing with rsa_expiringpremium - reverted back due to error
                    NotTakenUpLastYearsPremiumValue = (enOpportunity.Attributes.Contains("rsa_rsaexpiringpremium") && !string.IsNullOrEmpty(Convert.ToString(enOpportunity.GetAttributeValue<Money>("rsa_rsaexpiringpremium"))))
                        ? enOpportunity.GetAttributeValue<decimal>("rsa_rsaexpiringpremium")
                        : ((enPreImage.Attributes.Contains("rsa_rsaexpiringpremium") && !string.IsNullOrEmpty(Convert.ToString(enPreImage.GetAttributeValue<Money>("rsa_rsaexpiringpremium"))))
                        ? enPreImage.GetAttributeValue<decimal>("rsa_rsaexpiringpremium") : 0);
                }
            }
            return NotTakenUpLastYearsPremiumValue;
        }

        public static decimal getNetPremiumGBPGSL(IOrganizationService orgService, Entity enOpportunity, Entity enPreImage)
        {
            decimal NetPremiumGBPGSL = 0.0m;
            decimal RSAGrossPremiumGBPGSL = (enOpportunity.Attributes.Contains("rsa_rsagrosspremiumgbpgsl") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_rsagrosspremiumgbpgsl").ToString()))
                ? enOpportunity.GetAttributeValue<decimal>("rsa_rsagrosspremiumgbpgsl") : ((enPreImage.Attributes.Contains("rsa_rsagrosspremiumgbpgsl") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_rsagrosspremiumgbpgsl").ToString()))
                ? enPreImage.GetAttributeValue<decimal>("rsa_rsagrosspremiumgbpgsl") : 0);
            decimal RSACaptivePremiumGSL = (enOpportunity.Attributes.Contains("rsa_rsacaptivepremiumgsl_dc") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_rsacaptivepremiumgsl_dc").ToString()))
                ? enOpportunity.GetAttributeValue<decimal>("rsa_rsacaptivepremiumgsl_dc") : ((enPreImage.Attributes.Contains("rsa_rsacaptivepremiumgsl_dc") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_rsacaptivepremiumgsl_dc").ToString()))
                ? enPreImage.GetAttributeValue<decimal>("rsa_rsacaptivepremiumgsl_dc") : 0);
            decimal RSAInternalReinsuranceGBP = (enOpportunity.Attributes.Contains("rsa_rsainternalreinsurancegbp_dc") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_rsainternalreinsurancegbp_dc").ToString()))
                ? enOpportunity.GetAttributeValue<decimal>("rsa_rsainternalreinsurancegbp_dc") : ((enPreImage.Attributes.Contains("rsa_rsainternalreinsurancegbp_dc") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_rsainternalreinsurancegbp_dc").ToString()))
                ? enPreImage.GetAttributeValue<decimal>("rsa_rsainternalreinsurancegbp_dc") : 0);
            decimal RSAExternalReinsuranceGSL = (enOpportunity.Attributes.Contains("rsa_rsaexternalreinsurancegsl_dc") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_rsaexternalreinsurancegsl_dc").ToString()))
                ? enOpportunity.GetAttributeValue<decimal>("rsa_rsaexternalreinsurancegsl_dc") : ((enPreImage.Attributes.Contains("rsa_rsaexternalreinsurancegsl_dc") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_rsaexternalreinsurancegsl_dc").ToString()))
                ? enPreImage.GetAttributeValue<decimal>("rsa_rsaexternalreinsurancegsl_dc") : 0);
            NetPremiumGBPGSL = (RSAGrossPremiumGBPGSL - (RSACaptivePremiumGSL + RSAInternalReinsuranceGBP + RSAExternalReinsuranceGSL));
            return NetPremiumGBPGSL;
        }

        public static decimal getNetPremium(IOrganizationService orgService, Entity enOpportunity, Entity enPreImage, ITracingService tracer)
        {
            tracer.Trace("Inside getNetPremium1");
            decimal policyPremium = 0;
            tracer.Trace("Inside getNetPremium");
            if (enOpportunity.Attributes.Contains("rsa_policyid") || enPreImage.Attributes.Contains("rsa_policyid"))
            {
                tracer.Trace("Inside getNetPremium contains policy id");
                Guid policyGuid = Guid.Empty;

                if (enOpportunity.Attributes.Contains("rsa_policyid"))
                {
                    policyGuid = enPreImage.GetAttributeValue<EntityReference>("rsa_policyid") != null ? (enPreImage.GetAttributeValue<EntityReference>("rsa_policyid")).Id : Guid.Empty;
                }
                else if (enPreImage.Attributes.Contains("rsa_policyid"))
                {
                    policyGuid = enPreImage.GetAttributeValue<EntityReference>("rsa_policyid") != null ? (enPreImage.GetAttributeValue<EntityReference>("rsa_policyid")).Id : Guid.Empty;
                }
                else
                {
                    policyGuid = Guid.Empty;
                }
                tracer.Trace("policyGuid:" + policyGuid);
                if (policyGuid != Guid.Empty)
                {
                    tracer.Trace("policyGuid is not empty:" + policyGuid);

                    Entity enPolicy = orgService.Retrieve("rsa_policy", policyGuid, new ColumnSet("rsa_premium"));
                    tracer.Trace("enPolicy reteieved:");
                    if (enPolicy.Attributes.Contains("rsa_premium"))
                    {
                        tracer.Trace(" about to get policyPremium");
                        policyPremium = (decimal)((Money)enPolicy["rsa_premium"]).Value;
                        tracer.Trace("policyPremium" + policyPremium.ToString());
                    }
                }

            }
            tracer.Trace("get commission value");
            decimal commission = (enOpportunity.Attributes.Contains("rsa_commission") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_commission").ToString()))
                ? enOpportunity.GetAttributeValue<decimal>("rsa_commission") : ((enPreImage.Attributes.Contains("rsa_commission") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_commission").ToString()))
                ? enPreImage.GetAttributeValue<decimal>("rsa_commission") : 0);
            commission = commission / 100; 
            decimal NetPremium = policyPremium - (policyPremium * (commission));
            return NetPremium;
        }
        public static decimal getRSAGWPPC(IOrganizationService orgService, Entity enOpportunity, Entity enPreImage, ITracingService tracer)
        {
            decimal totalGWP100 = (enOpportunity.Attributes.Contains("rsa_totalgwp100gsl") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_totalgwp100gsl").ToString()))
                ? enOpportunity.GetAttributeValue<decimal>("rsa_totalgwp100gsl") : ((enPreImage.Attributes.Contains("rsa_totalgwp100gsl") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_totalgwp100gsl").ToString()))
                ? (enPreImage.GetAttributeValue<decimal>("rsa_totalgwp100gsl")) : 0);
            tracer.Trace("totalGWP100" + totalGWP100);

            decimal RSAshareGSL = (enOpportunity.Attributes.Contains("rsa_rsasharegsl") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_rsasharegsl").ToString()))
               ? enOpportunity.GetAttributeValue<decimal>("rsa_rsasharegsl") : ((enPreImage.Attributes.Contains("rsa_rsasharegsl") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_rsasharegsl").ToString()))
               ? enPreImage.GetAttributeValue<decimal>("rsa_rsasharegsl") : 0);
            //Modified On: 07/11/2022 ; Chandani ; CR 1243,1778 ; Handle percentage fields
            RSAshareGSL = RSAshareGSL / 100;
            tracer.Trace("RSAshareGSL" + RSAshareGSL);

            decimal RSAGWPPC = 0;
            RSAGWPPC = totalGWP100 * (RSAshareGSL);

            tracer.Trace("getRSAGWPPC Completed" + RSAGWPPC);

            return RSAGWPPC;
        }


        public static decimal getGWPInclFrontingGBP(IOrganizationService orgService, Entity enOpportunity, Entity enPreImage, Entity enOpptyRetrieve)
        {
            decimal rsa_exchangerategslc = (enOpportunity.Attributes.Contains("rsa_exchangerategslc") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_exchangerategslc").ToString()))
                ? enOpportunity.GetAttributeValue<decimal>("rsa_exchangerategslc") : ((enPreImage.Attributes.Contains("rsa_exchangerategslc") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_exchangerategslc").ToString()))
                ? enPreImage.GetAttributeValue<decimal>("rsa_exchangerategslc") : 0);

            decimal TotalGWP100gsl = (enOpportunity.Attributes.Contains("rsa_totalgwp100gsl") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_totalgwp100gsl").ToString()))
   ? enOpportunity.GetAttributeValue<decimal>("rsa_totalgwp100gsl") : ((enPreImage.Attributes.Contains("rsa_totalgwp100gsl") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_totalgwp100gsl").ToString()))
   ? enPreImage.GetAttributeValue<decimal>("rsa_totalgwp100gsl") : 0);

            decimal rsaShareGSL = (enOpportunity.Attributes.Contains("rsa_rsasharegsl") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_rsasharegsl").ToString()))
   ? enOpportunity.GetAttributeValue<decimal>("rsa_rsasharegsl") : ((enPreImage.Attributes.Contains("rsa_rsasharegsl") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_rsasharegsl").ToString()))
   ? enPreImage.GetAttributeValue<decimal>("rsa_rsasharegsl") : 0);
            //Modified On: 07/11/2022 ; Chandani ; CR 1243,1778 ; Handle percentage fields
            rsaShareGSL = rsaShareGSL / 100;
            decimal GrossPremiumVariancepc = (enOpportunity.Attributes.Contains("rsa_grosspremiumvariancepc") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_grosspremiumvariancepc").ToString()))
   ? enOpportunity.GetAttributeValue<decimal>("rsa_grosspremiumvariancepc") : ((enPreImage.Attributes.Contains("rsa_grosspremiumvariancepc") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_grosspremiumvariancepc").ToString()))
   ? enPreImage.GetAttributeValue<decimal>("rsa_grosspremiumvariancepc") : 0);



            decimal GWPInclFrontingGBP = 0;
            if (rsa_exchangerategslc != 0)
            {
                GWPInclFrontingGBP = ((TotalGWP100gsl* rsaShareGSL)+ GrossPremiumVariancepc) / rsa_exchangerategslc;
            }
            return GWPInclFrontingGBP;
        }

        public static decimal getCYCaptivePremiumGBP(IOrganizationService orgService, Entity enOpportunity, Entity enPreImage)
        {
            decimal rsa_rsacaptivepremiumpc = (enOpportunity.Attributes.Contains("rsa_rsacaptivepremiumpc") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_rsacaptivepremiumpc").ToString()))
                ? enOpportunity.GetAttributeValue<decimal>("rsa_rsacaptivepremiumpc") : ((enPreImage.Attributes.Contains("rsa_rsacaptivepremiumpc") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_rsacaptivepremiumpc").ToString()))
                ? enPreImage.GetAttributeValue<decimal>("rsa_rsacaptivepremiumpc") : 0);
            decimal rsa_exchangerategslc = (enOpportunity.Attributes.Contains("rsa_exchangerategslc") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_exchangerategslc").ToString()))
                ? enOpportunity.GetAttributeValue<decimal>("rsa_exchangerategslc") : ((enPreImage.Attributes.Contains("rsa_exchangerategslc") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_exchangerategslc").ToString()))
                ? enPreImage.GetAttributeValue<decimal>("rsa_exchangerategslc") : 0);

            decimal CYCaptivePremiumGBP = 0;
            if (rsa_exchangerategslc != 0)
            {
                CYCaptivePremiumGBP = rsa_rsacaptivepremiumpc / rsa_exchangerategslc;
            }
            return CYCaptivePremiumGBP;
        }

        public static decimal getGrossPremiumVarianceGBP(IOrganizationService orgService, Entity enOpportunity, Entity enPreImage)
        {
            decimal rsa_grosspremiumvariancepc = (enOpportunity.Attributes.Contains("rsa_grosspremiumvariancepc") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_grosspremiumvariancepc").ToString()))
                ? enOpportunity.GetAttributeValue<decimal>("rsa_grosspremiumvariancepc") : ((enPreImage.Attributes.Contains("rsa_grosspremiumvariancepc") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_grosspremiumvariancepc").ToString()))
                ? enPreImage.GetAttributeValue<decimal>("rsa_grosspremiumvariancepc") : 0);
            decimal rsa_exchangerategslc = (enOpportunity.Attributes.Contains("rsa_exchangerategslc") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_exchangerategslc").ToString()))
                ? enOpportunity.GetAttributeValue<decimal>("rsa_exchangerategslc") : ((enPreImage.Attributes.Contains("rsa_exchangerategslc") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_exchangerategslc").ToString()))
                ? enPreImage.GetAttributeValue<decimal>("rsa_exchangerategslc") : 0);

            decimal GrossPremiumVarianceGBP = 0;
            if (rsa_exchangerategslc != 0)
            {
                GrossPremiumVarianceGBP = rsa_grosspremiumvariancepc / rsa_exchangerategslc;
            }
            return GrossPremiumVarianceGBP;
        }

        public static decimal getPYGrossPremiumGBP(IOrganizationService orgService, Entity enOpportunity, Entity enPreImage, ITracingService tracer)
        {
            decimal pyRsaShare = (enOpportunity.Attributes.Contains("rsa_pyrsashare") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_pyrsashare").ToString()))
                ? enOpportunity.GetAttributeValue<decimal>("rsa_pyrsashare") : ((enPreImage.Attributes.Contains("rsa_pyrsashare") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_pyrsashare").ToString()))
                ? enPreImage.GetAttributeValue<decimal>("rsa_pyrsashare") : 0);
            //Modified On: 07/11/2022 ; Chandani ; CR 1243,1778 ; Handle percentage fields
            pyRsaShare = pyRsaShare / 100;
            tracer.Trace("rsa_pyrsashare" + pyRsaShare);

            Money pyTotalGWP100gbp = enOpportunity.Attributes.Contains("rsa_pytotalgwp100gbp") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<Money>("rsa_pytotalgwp100gbp").ToString())
                ? enOpportunity.GetAttributeValue<Money>("rsa_pytotalgwp100gbp") : enPreImage.Attributes.Contains("rsa_pytotalgwp100gbp") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<Money>("rsa_pytotalgwp100gbp").ToString())
                ? enPreImage.GetAttributeValue<Money>("rsa_pytotalgwp100gbp") : null;
            tracer.Trace("rsa_pytotalgwp100gbp" + pyTotalGWP100gbp);
            tracer.Trace("check 1");
            decimal pyTotalGWP100gbpVal = pyTotalGWP100gbp.Value;
            tracer.Trace("pyTotalGWP100gbpVal" + pyTotalGWP100gbpVal);
            decimal PYGrossPremiumGBP = pyTotalGWP100gbpVal + pyRsaShare;
            return PYGrossPremiumGBP;
        }
        public static decimal getPYGWPinclFrontingGBP(IOrganizationService orgService, Entity enOpportunity, Entity enPreImage, ITracingService tracer)
        {
            decimal pyGrossPremiumGbp = getPYGrossPremiumGBP(orgService, enOpportunity, enPreImage, tracer);

            tracer.Trace("rsa_pygrosspremiumgbp" + pyGrossPremiumGbp);

            Money pyGrossPremiumVarianceGbp = (enOpportunity.Attributes.Contains("rsa_pygrosspremiumvariancegbp") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<Money>("rsa_pygrosspremiumvariancegbp").ToString()))
                ? enOpportunity.GetAttributeValue<Money>("rsa_pygrosspremiumvariancegbp") : ((enPreImage.Attributes.Contains("rsa_pygrosspremiumvariancegbp") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<Money>("rsa_pygrosspremiumvariancegbp").ToString()))
                ? enPreImage.GetAttributeValue<Money>("rsa_pygrosspremiumvariancegbp") : null);
            tracer.Trace("rsa_pygrosspremiumvariancegbp" + pyGrossPremiumVarianceGbp);

            decimal PYGWPinclFrontingGBP = pyGrossPremiumVarianceGbp.Value + pyGrossPremiumGbp;
            return PYGWPinclFrontingGBP;
        }


        public static decimal getPYGWPexGrossupsTerrorismGBP(IOrganizationService orgService, Entity enOpportunity, Entity enPreImage, ITracingService tracer)
        {
            decimal pygwpinclfrontinggbp = getPYGWPinclFrontingGBP(orgService, enOpportunity, enPreImage, tracer);

            tracer.Trace("rsa_pygwpinclfrontinggbp" + pygwpinclfrontinggbp);

            decimal pycaptivepremiumgbp_dc = (enOpportunity.Attributes.Contains("rsa_pycaptivepremiumgbp_dc") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_pycaptivepremiumgbp_dc").ToString()))
                ? enOpportunity.GetAttributeValue<decimal>("rsa_pycaptivepremiumgbp_dc") : ((enPreImage.Attributes.Contains("rsa_pycaptivepremiumgbp_dc") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_pycaptivepremiumgbp_dc").ToString()))
                ? enPreImage.GetAttributeValue<decimal>("rsa_pycaptivepremiumgbp_dc") : 0);
            tracer.Trace("rsa_pycaptivepremiumgbp_dc" + pycaptivepremiumgbp_dc);

            decimal pyinternalreinsurancegbp = (enOpportunity.Attributes.Contains("rsa_rsapyinternalreinsurancegbp") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_rsapyinternalreinsurancegbp").ToString()))
    ? enOpportunity.GetAttributeValue<decimal>("rsa_rsapyinternalreinsurancegbp") : ((enPreImage.Attributes.Contains("rsa_rsapyinternalreinsurancegbp") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_rsapyinternalreinsurancegbp").ToString()))
    ? enPreImage.GetAttributeValue<decimal>("rsa_rsapyinternalreinsurancegbp") : 0);
            tracer.Trace("rsa_rsapyinternalreinsurancegbp" + pyinternalreinsurancegbp);

            decimal pycoinsurancegbp = (enOpportunity.Attributes.Contains("rsa_rsapycoinsurancegbp") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_rsapycoinsurancegbp").ToString()))
? enOpportunity.GetAttributeValue<decimal>("rsa_rsapycoinsurancegbp") : ((enPreImage.Attributes.Contains("rsa_rsapycoinsurancegbp") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_rsapycoinsurancegbp").ToString()))
? enPreImage.GetAttributeValue<decimal>("rsa_rsapycoinsurancegbp") : 0);
            tracer.Trace("rsa_rsapycoinsurancegbp" + pycoinsurancegbp);


            decimal PYGWPexGrossupsTerrorismGBP = pygwpinclfrontinggbp - pycaptivepremiumgbp_dc - pyinternalreinsurancegbp - pycoinsurancegbp;
            return PYGWPexGrossupsTerrorismGBP;
        }


        //////////////

        public static decimal getActualLineShareChange(IOrganizationService orgService, ITracingService tracer, Entity enOpportunity, Entity enPreImage)
        {
            tracer.Trace("Starting getActualLineShareChange");
            decimal rsaactuallinesharechange = 0;
            //Defect id 1420 : Pooja Raje : Business process error. 27 April 2021


            decimal rsasharegsl = (enOpportunity.Attributes.Contains("rsa_rsasharegsl") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_rsasharegsl").ToString()))
                ? enOpportunity.GetAttributeValue<decimal>("rsa_rsasharegsl") : ((enPreImage.Attributes.Contains("rsa_rsasharegsl") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_rsasharegsl").ToString()))
            ? enPreImage.GetAttributeValue<decimal>("rsa_rsasharegsl") : 0);
            //Modified On: 07/11/2022 ; Chandani ; CR 1243,1778 ; Handle percentage fields
            rsasharegsl = rsasharegsl / 100;
            //decimal rsasharegsl = enOpportunity.Attributes.Contains("rsa_rsasharegsl") ? enOpportunity.GetAttributeValue<decimal>("rsa_rsasharegsl") : enPreImage.Attributes.Contains("rsa_rsasharegsl") ? enOpportunity.GetAttributeValue<decimal>("rsa_rsasharegsl") : 0;
            tracer.Trace(" rsa_rsasharegsl from getActualLineShareChange " + rsasharegsl);
            //Defect id 1420 : Pooja Raje : Business process error. 27 April 2021
            //tracer.Trace("Starting rsa_pyrsashare");
            decimal pyrsashare = (enOpportunity.Attributes.Contains("rsa_pyrsashare") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_pyrsashare").ToString()))
                ? enOpportunity.GetAttributeValue<decimal>("rsa_pyrsashare") : ((enPreImage.Attributes.Contains("rsa_pyrsashare") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_pyrsashare").ToString()))
                ? enPreImage.GetAttributeValue<decimal>("rsa_pyrsashare") : 0);
            //Modified On: 07/11/2022 ; Chandani ; CR 1243,1778 ; Handle percentage fields
            pyrsashare = pyrsashare / 100;
            tracer.Trace(" pyrsashare from getActualLineShareChange " + pyrsashare);

            decimal pygwpexgrossupsterrorismgbp = (enOpportunity.Attributes.Contains("rsa_pygwpexgrossupsterrorismgbp") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_pygwpexgrossupsterrorismgbp").ToString()))
            ? enOpportunity.GetAttributeValue<decimal>("rsa_pygwpexgrossupsterrorismgbp") : ((enPreImage.Attributes.Contains("rsa_pygwpexgrossupsterrorismgbp") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_pygwpexgrossupsterrorismgbp").ToString()))
            ? enPreImage.GetAttributeValue<decimal>("rsa_pygwpexgrossupsterrorismgbp") : 0);
            tracer.Trace(" pygwpexgrossupsterrorismgbp from getActualLineShareChange " + pygwpexgrossupsterrorismgbp);                             
            

            //Defect id 1420 : Pooja Raje : Business process error. 27 April 2021
            decimal fximpactonpremiumgbp_dc = (enPreImage.Attributes.Contains("rsa_fximpactonpremiumgbp_dc") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_fximpactonpremiumgbp_dc").ToString()))
                 ? enPreImage.GetAttributeValue<decimal>("rsa_fximpactonpremiumgbp_dc") : ((enOpportunity.Attributes.Contains("rsa_fximpactonpremiumgbp_dc") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_fximpactonpremiumgbp_dc").ToString()))
                 ? enOpportunity.GetAttributeValue<decimal>("rsa_fximpactonpremiumgbp_dc") : 0);
            tracer.Trace("fximpactonpremiumgbp_dc from getActualLineShareChange " + fximpactonpremiumgbp_dc);

            if (pyrsashare != 0)
                rsaactuallinesharechange = ((rsasharegsl - pyrsashare) * (pygwpexgrossupsterrorismgbp + fximpactonpremiumgbp_dc)) / pyrsashare;
            tracer.Trace("rsaactuallinesharechange: " + rsaactuallinesharechange.ToString());
            tracer.Trace("Exiting getActualLineShareChange");
            return rsaactuallinesharechange;
        }


        public decimal getGWPPostDeductions(IOrganizationService orgService, ITracingService tracer, Entity enOpportunity, Entity enPreImage, Entity enOpptyRetrieve)
        {
            tracer.Trace("Starting getGWPPostDeductions");
            decimal rsagwp = enOpptyRetrieve.Attributes.Contains("rsa_rsagwp") ? enOpptyRetrieve.GetAttributeValue<decimal>("rsa_rsagwp") : 0;
            tracer.Trace("rsagwp" + rsagwp);
            decimal commissionunderlying1 = enOpptyRetrieve.Attributes.Contains("rsa_commissionunderlying1") ? enOpptyRetrieve.GetAttributeValue<decimal>("rsa_commissionunderlying1") : 0;
            decimal worktransfer_dc = getWorkTransfer(orgService, enOpportunity, enPreImage, tracer);//bug 176 fetch the value of wprk transfer pound
            tracer.Trace("worktransfer_dc" + worktransfer_dc);
            decimal rsariskmanagementbursary_dc = (enOpportunity.Attributes.Contains("rsa_rsariskmanagementbursary_dc") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_rsariskmanagementbursary_dc").ToString())) ? enOpportunity.GetAttributeValue<decimal>("rsa_rsariskmanagementbursary_dc") :
               (enPreImage.Attributes.Contains("rsa_rsariskmanagementbursary_dc") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_rsariskmanagementbursary_dc").ToString())) ? enPreImage.GetAttributeValue<decimal>("rsa_rsariskmanagementbursary_dc") : 0;
            decimal localofficeoverriders_dc = (enOpportunity.Attributes.Contains("rsa_rsalocalofficeoverriders") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_rsalocalofficeoverriders").ToString()))
                ? enOpportunity.GetAttributeValue<decimal>("rsa_rsalocalofficeoverriders") : ((enPreImage.Attributes.Contains("rsa_rsalocalofficeoverriders") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_rsalocalofficeoverriders").ToString()))
                ? enPreImage.GetAttributeValue<decimal>("rsa_rsalocalofficeoverriders") : 0);
            decimal overseastax_dc = (enOpportunity.Attributes.Contains("rsa_overseastax_dc") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_overseastax_dc").ToString()))
                ? enOpportunity.GetAttributeValue<decimal>("rsa_overseastax_dc") : ((enPreImage.Attributes.Contains("rsa_overseastax_dc") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_overseastax_dc").ToString()))
                ? enPreImage.GetAttributeValue<decimal>("rsa_overseastax_dc") : 0);
            decimal captivepremium = (enOpportunity.Attributes.Contains("rsa_captivepremium_dc") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_captivepremium_dc").ToString()))
                ? enOpportunity.GetAttributeValue<decimal>("rsa_captivepremium_dc") : ((enPreImage.Attributes.Contains("rsa_captivepremium_dc") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_captivepremium_dc").ToString()))
                ? enPreImage.GetAttributeValue<decimal>("rsa_captivepremium_dc") : 0);
            decimal rsa_gwppostdeductions_dc = rsagwp + commissionunderlying1 + worktransfer_dc + rsariskmanagementbursary_dc
                + localofficeoverriders_dc + overseastax_dc + captivepremium;
            tracer.Trace("rsa_gwppostdeductions_dc: " + rsa_gwppostdeductions_dc.ToString());
            tracer.Trace("Exiting getGWPPostDeductions");
            return rsa_gwppostdeductions_dc;
        }
    }
}
