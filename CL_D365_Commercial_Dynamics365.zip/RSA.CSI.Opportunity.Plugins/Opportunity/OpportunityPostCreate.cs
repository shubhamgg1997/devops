﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using RSA.Crm.Plugins;
using System;
using RSA.CSI.Plugins.Utility;
using RSA.CSI.Plugins.OpportunityLogic;
using System.ServiceModel;
using System.Net;

namespace RSA.CSI.Plugins.Opportunity
{
    public class OpportunityPostCreate : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService tracer = null;
            IPluginExecutionContext context = null;
            IOrganizationService service = null;

            CrmPluginHelper.Initialise(serviceProvider, ref context, ref service, ref tracer, false);
            tracer.Trace("context.Depth:{0}", context.Depth);
            if (context.Depth > 5)
            {
                return;
            }
            try
            {
                if ((context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity) && context.MessageName.ToLowerInvariant() == "create" && context.Stage == 40)
                {
                    string messageName = context.MessageName.ToLowerInvariant();
                    tracer.Trace("Instace created and target is avaialble.");
                    Entity postImage = (Entity)context.PostEntityImages["PostImage"];


                    EntityReference lineofBusiness = postImage.Attributes.Contains("rsa_lineofbusiness") ? postImage.GetAttributeValue<EntityReference>("rsa_lineofbusiness") : null;
                    bool? oCrOpportunityForNextYearifNtu = postImage.Attributes.Contains("rsa_createopportunityfornextyearifntu") ? postImage.GetAttributeValue<bool?>("rsa_createopportunityfornextyearifntu") : null;
                    string opptyName = postImage.Attributes.Contains("name") ? postImage.GetAttributeValue<string>("name") : null;

                    EntityReference newOpportunityStage = postImage.Attributes.Contains("rsa_opportunitystage") ? postImage.GetAttributeValue<EntityReference>("rsa_opportunitystage") : null;
                    string newStageName = string.Empty;
                    if (newOpportunityStage != null)
                    { newStageName = newOpportunityStage.Name.ToLowerInvariant(); }

                    bool? oCrOpptyforNextYearIfLapsed = postImage.Attributes.Contains("rsa_createopptyfornextyeariflapsed") ? postImage.GetAttributeValue<bool?>("rsa_createopptyfornextyeariflapsed") : null;

                    string newSchemes = postImage.FormattedValues.ContainsKey("rsa_schemes") ? postImage.FormattedValues["rsa_schemes"].ToLowerInvariant() : null;
                    string policyNumbers = postImage.Attributes.Contains("rsa_policynumbers") ? postImage.GetAttributeValue<string>("rsa_policynumbers") : null;
                    string policySystem = postImage.FormattedValues.ContainsKey("rsa_policysystem") ? postImage.FormattedValues["rsa_policysystem"] : null;
                    Money totalAmount = postImage.Attributes.Contains("rsa_rsaquotedpremium") ? postImage.GetAttributeValue<Money>("rsa_rsaquotedpremium") : null;
                    EntityReference accountId = postImage.Attributes.Contains("parentaccountid") ? postImage.GetAttributeValue<EntityReference>("parentaccountid") : null;
                    EntityReference Case = postImage.Attributes.Contains("rsa_case") ? postImage.GetAttributeValue<EntityReference>("rsa_case") : null;
                    EntityReference policyId = postImage.Attributes.Contains("rsa_policyid") ? postImage.GetAttributeValue<EntityReference>("rsa_policyid") : null;
                    EntityReference product = postImage.Attributes.Contains("rsa_productid") ? postImage.GetAttributeValue<EntityReference>("rsa_productid") : null;
                    EntityReference customer = postImage.Attributes.Contains("rsa_customer") ? postImage.GetAttributeValue<EntityReference>("rsa_customer") : null;
                    EntityReference classOfBusiness = postImage.Attributes.Contains("rsa_classofbusiness") ? postImage.GetAttributeValue<EntityReference>("rsa_classofbusiness") : null;
                    tracer.Trace("Fields Data Available");

                    EntityCollection customLabelDetails = CommonUtility.GetCutomLabelDetails(service, "Page_Layouts_supporting_To_GBP_conversion", string.Empty, string.Empty);
                    EntityCollection customSettings = OpportunityUpdate.GetCustomSettingsbyName(service, tracer, "Marine_Task_Comment_Field__c");
                    string customValue = string.Empty;
                    if (customLabelDetails.Entities.Count > 0)
                    {
                        foreach (var lablel in customLabelDetails.Entities)
                        {
                            customValue = lablel.Attributes.Contains("rsa_values") ? lablel.GetAttributeValue<string>("rsa_values") : string.Empty;
                            tracer.Trace("CustomValue:{0}", customValue);
                        }

                        if (!string.IsNullOrEmpty(customValue) && customValue.Contains(lineofBusiness.Name) && (
                            (messageName == "create" && oCrOpportunityForNextYearifNtu != null && oCrOpportunityForNextYearifNtu == true && newStageName == "not taken up") ||
                            (messageName == "create" && oCrOpptyforNextYearIfLapsed != null && oCrOpptyforNextYearIfLapsed == true && newStageName == "lapsed") ||
                            (messageName == "create" && newSchemes == "declaration" && (newStageName == "accepted" || newStageName == "renewed"))))
                        {

                            OpportunityUpdate objOppUpdate = new OpportunityUpdate();
                            tracer.Trace("Check Data Origin");
                            bool isRenewalOrigin = postImage.Attributes.Contains("rsa_dataorigin") ? ((OptionSetValue)postImage.Attributes["rsa_dataorigin"]).Value.Equals(866760003) : false;
                            tracer.Trace("Data Origin:", isRenewalOrigin);
                            if (!isRenewalOrigin)
                            {
                                objOppUpdate.CreateOpportunityClone(service, tracer, postImage);

                            }
                            tracer.Trace("Clone Opportunity Created");
                        }
                    }
                    #region Create Opportunity Extension
                    //Create Opportunity Extension
                    Guid opportunityId = context.PrimaryEntityId;
                    Guid userId = context.UserId;
                    tracer.Trace("OpportunityExtention Creation Start");
                    Entity enOpportunityExtension = new Entity("rsa_extensionopportunity");
                    enOpportunityExtension["rsa_brokerprimaryreference"] = CommonUtility.RetriveBrokerPrimaryReference(opportunityId, service, tracer);
                    tracer.Trace("enOpportunityExtension['rsa_brokerprimaryreference']:{0} ", CommonUtility.RetriveBrokerPrimaryReference(opportunityId, service, tracer));
                    enOpportunityExtension["rsa_areaname"] = CommonUtility.RetriveAreaName(opportunityId, service);
                    tracer.Trace("enOpportunityExtension['rsa_areaname']:{0} ", CommonUtility.RetriveAreaName(opportunityId, service));
                    var caseReceivedDate = CommonUtility.RetriveCaseReceivedDate(opportunityId, service);
                    if (caseReceivedDate.Equals(new DateTime(0001, 01, 01)))
                    {
                        tracer.Trace("In blank");
                        enOpportunityExtension["rsa_casereceiveddate"] = null;
                    }
                    else
                    {
                        tracer.Trace("Got case recieved date");
                        enOpportunityExtension["rsa_casereceiveddate"] = caseReceivedDate;
                    }

                    tracer.Trace("enOpportunityExtension['rsa_casereceiveddate']:{0} ", caseReceivedDate.ToString());
                    enOpportunityExtension["rsa_currentuser"] = CommonUtility.retriveCurrentUser(opportunityId, userId, service, tracer);
                    tracer.Trace("enOpportunityExtension['rsa_currentuser']:{0} ", CommonUtility.retriveCurrentUser(opportunityId, userId, service, tracer));
                    enOpportunityExtension["rsa_opportunity"] = new EntityReference("opportunity", opportunityId);
                    tracer.Trace("enOpportunityExtension['opportunityId']:{0} ", opportunityId);
                    enOpportunityExtension["rsa_lineofbusiness"] = new EntityReference("rsa_lineofbusiness", ((EntityReference)postImage.Attributes["rsa_lineofbusiness"]).Id);
                    tracer.Trace("enOpportunityExtension['rsa_lineofbusiness']:{0} ", ((EntityReference)postImage.Attributes["rsa_lineofbusiness"]).Id);

                    //Added as facing issue on copying stage
                    if (((EntityReference)postImage["rsa_opportunitystage"]).Id != null)
                    {
                        tracer.Trace("rsa_opportunitystage:  ", Convert.ToString(((EntityReference)postImage["rsa_opportunitystage"]).Id));
                        enOpportunityExtension["rsa_stage"] = new EntityReference("rsa_opportunitystage", ((EntityReference)postImage["rsa_opportunitystage"]).Id);
                    }
                    else
                    {
                        Entity opportunitystage = service.Retrieve("opportunity", opportunityId, new Microsoft.Xrm.Sdk.Query.ColumnSet("rsa_opportunitystage"));
                        if (opportunitystage != null && opportunitystage.Attributes.Contains("rsa_opportunitystage"))
                        {
                            tracer.Trace("rsa_opportunitystage:  ", Convert.ToString(((EntityReference)opportunitystage["rsa_opportunitystage"]).Id));
                            enOpportunityExtension["rsa_stage"] = new EntityReference("rsa_opportunitystage", ((EntityReference)opportunitystage["rsa_opportunitystage"]).Id);
                        }
                    }

                    //Code added by Jyoti 23/06/2022 CR-2234
                    tracer.Trace("Def-2234 Code change start");

                    EntityReference parentoppid = postImage.Attributes.Contains("rsa_parentopportunityid") ? postImage.GetAttributeValue<EntityReference>("rsa_parentopportunityid") : null;
                    if (parentoppid != null)
                    {
                        Entity parentopportunityextension = service.Retrieve(parentoppid.LogicalName, parentoppid.Id, new Microsoft.Xrm.Sdk.Query.ColumnSet("rsa_opportunityextensionid"));
                        if (parentopportunityextension != null && parentopportunityextension.Attributes.Contains("rsa_opportunityextensionid"))
                        {
                            tracer.Trace("Parent Opportunity Extension ID:  ", Convert.ToString(((EntityReference)parentopportunityextension["rsa_opportunityextensionid"]).Id));
                            enOpportunityExtension["rsa_parentopportunityextensionid"] = new EntityReference("rsa_extensionopportunity", ((EntityReference)parentopportunityextension["rsa_opportunityextensionid"]).Id);
                        }
                    }

                    //enOpportunityExtension["rsa_stage"]= new EntityReference("rsa_opportunitystage", ((EntityReference)postImage.Attributes["rsa_opportunitystage"]).Id);
                    //tracer.Trace("enOpportunityExtension['rsa_opportunitystage']:{0} ", ((EntityReference)postImage.Attributes["rsa_opportunitystage"]).Id);
                    enOpportunityExtension["rsa_name"] = opptyName;
                    tracer.Trace("opptyName :" + opptyName);
                    service.Create(enOpportunityExtension);
                    tracer.Trace("Opportunity Extension created successfully");
                    tracer.Trace("opptyName :" + lineofBusiness.Name);
                    string lobName = string.Empty;

                    //Defect 2564 : PC to GBP calcualations not working. 09 Dec 2021. 
                    if (lineofBusiness != null && string.IsNullOrEmpty(lineofBusiness.Name))
                    {
                        var lobDetails = service.Retrieve(lineofBusiness.LogicalName, lineofBusiness.Id, new ColumnSet("rsa_name"));
                        lobName = lobDetails["rsa_name"].ToString().ToLowerInvariant();
                        tracer.Trace("lobname" + lobName);
                    }
                    else
                    {
                        lobName = lineofBusiness.Name.ToLowerInvariant();
                    }
                    #endregion
                    if (lobName.ToLowerInvariant().Contains("marine"))
                    {
                        TriggerOperations operations = new TriggerOperations();
                        tracer.Trace("postcreate to start for pC to GBP");

                        operations.updateGBPFields(context, service, postImage, postImage, null, tracer, 866760027);

                    }

                    #region bug 2038 BAM for NB
                    tracer.Trace("Entered bug 2038 BAM - owner for Manrine and Non-marine: ");

                    tracer.Trace("lobName: " + lineofBusiness.Name);
                    Guid opportunityOwnerId = Guid.Empty;
                    Guid BAMUser = Guid.Empty;
                    Guid guidEmpty = Guid.Empty;
                    Guid brokerId = Guid.Empty;
                    string plname = string.Empty;
                    string ocobName = string.Empty;
                    string LINE_OF_BUSINESS_GSL_RENEWAL_MARINE_LONDON = WebUtility.HtmlEncode(lobName);
                    string settingCustomName = "Marine Renewal Opportunity Onwer";
                    string policyRegion = string.Empty;

                    //note: if policy available update owner else just update BAM
                    //if opportunity contains Policy

                    EntityReference opPolicy = postImage.Attributes.Contains("rsa_policyid") ? postImage.GetAttributeValue<EntityReference>("rsa_policyid") : null;
                    tracer.Trace("opPolicy: " + opPolicy);
                    if (opPolicy != null && lineofBusiness.Name.ToLowerInvariant().Contains("marine"))
                    {
                        tracer.Trace("policy available update owner " + opPolicy.Name);
                        Entity enPolicy = service.Retrieve(opPolicy.LogicalName, opPolicy.Id, new ColumnSet(true));

                        if (enPolicy.Attributes.Contains("rsa_tradinghandlingsite"))
                        {
                            policyRegion = Convert.ToString(enPolicy.FormattedValues["rsa_tradinghandlingsite"]);
                            tracer.Trace("policyRegion: " + policyRegion);

                        }
                        if(postImage.Contains("rsa_classofbusiness"))
                        {
                            ocobName = Convert.ToString(postImage.GetAttributeValue<EntityReference>("rsa_classofbusiness").Name);
                            tracer.Trace("Policy found , getting COB from postimage" ,ocobName);
                        }
                        opportunityOwnerId = GetOpportunityOwnerDetails(service, tracer, policyRegion, LINE_OF_BUSINESS_GSL_RENEWAL_MARINE_LONDON, ocobName, settingCustomName);

                        if (!opportunityOwnerId.Equals(Guid.Empty))
                        {
                            postImage["ownerid"] = new EntityReference("systemuser", opportunityOwnerId);
                            tracer.Trace("ownerid: updated" + opportunityOwnerId);
                        }
                        else {
                            tracer.Trace("calling getuser function");
                            Entity enUser = getUser("Unassigned", service);
                            tracer.Trace("Record reterieved " + enUser);
                            tracer.Trace("Record reterieved " + enUser.Id);
                            Guid userid = enUser.Id;
                            postImage["ownerid"]= new EntityReference("systemuser", enUser.Id);
                            tracer.Trace("Updated unassigned - owner");
                        }
                    }
                    else
                    {
                        //update owner for Non Marine
                        if (postImage.Attributes.Contains("rsa_pandlid") && ((EntityReference)postImage["rsa_pandlid"]).Id != guidEmpty
                               && postImage.Attributes.Contains("rsa_classofbusiness") && ((EntityReference)postImage["rsa_classofbusiness"]).Id != guidEmpty
                               && postImage.Attributes.Contains("parentaccountid") && ((EntityReference)postImage["parentaccountid"]).Id != guidEmpty &&
                               !lineofBusiness.Name.ToLowerInvariant().Contains("roi") && !lineofBusiness.Name.ToLowerInvariant().Contains("new business - ni")
                               && !lineofBusiness.Name.ToLowerInvariant().Contains("marine"))
                        {
                            plname = WebUtility.HtmlEncode(((EntityReference)postImage["rsa_pandlid"]).Name);
                            tracer.Trace("plname: " + plname);
                            ocobName = WebUtility.HtmlEncode(((EntityReference)postImage["rsa_classofbusiness"]).Name);
                            tracer.Trace("ocobName: " + ocobName);
                            brokerId = ((EntityReference)postImage["parentaccountid"]).Id;
                            tracer.Trace("brokerId: " + brokerId);

                            BAMUser = this.getBAMUser(service, tracer, plname, ocobName, brokerId);
                            tracer.Trace("BAM Line 225: " + BAMUser);
                            if (!BAMUser.Equals(Guid.Empty))
                            {
                                postImage["ownerid"] = new EntityReference("systemuser", BAMUser);
                            }
                            else
                            {
                                tracer.Trace("calling getuser function");
                                Entity enUser = getUser("Unassigned", service);
                                tracer.Trace("Record reterieved " + enUser);
                                tracer.Trace("Record reterieved " + enUser.Id);
                                Guid userid = enUser.Id;
                                postImage["ownerid"] = new EntityReference("systemuser", enUser.Id);
                                tracer.Trace("Updated unassigned - owner");
                            }
                        }
                    

                        // update owner - for  non Marine/ROI
                        string ocobROIName = string.Empty;
                        string oPLROIName = string.Empty;
                        EntityReference enRoiCOBName = postImage.GetAttributeValue<EntityReference>("rsa_classofbusinessroi");
                        EntityReference enRoiPandl = postImage.GetAttributeValue<EntityReference>("rsa_plroi");

                        if (enRoiCOBName != null && enRoiPandl != null)
                        {
                            Entity enCOB = service.Retrieve(enRoiCOBName.LogicalName, enRoiCOBName.Id, new ColumnSet(true));
                            if (enCOB.Attributes.Contains("rsa_name"))
                            {
                                ocobROIName = WebUtility.HtmlEncode(Convert.ToString(enCOB["rsa_name"]));
                                tracer.Trace("ROI ocobROIName: " + ocobROIName);

                            }
                            Entity enPL = service.Retrieve(enRoiPandl.LogicalName, enRoiPandl.Id, new ColumnSet(true));
                            if (enPL.Attributes.Contains("rsa_name"))
                            {
                                oPLROIName = WebUtility.HtmlEncode(Convert.ToString(enPL["rsa_name"]));
                                tracer.Trace("ROI oPLROIName: " + oPLROIName);

                            }
                        }

                        if ((lineofBusiness.Name.ToLowerInvariant().Contains("roi") || lineofBusiness.Name.ToLowerInvariant().Contains("new business - ni"))
                            && ocobROIName != null && oPLROIName != null
                            && postImage.Attributes.Contains("parentaccountid") && ((EntityReference)postImage["parentaccountid"]).Id != guidEmpty)

                        {
                            tracer.Trace("lobName: " + lineofBusiness);
                            brokerId = ((EntityReference)postImage["parentaccountid"]).Id;
                            tracer.Trace("brokerId: " + brokerId);
                            BAMUser = this.getBAMUser(service, tracer, oPLROIName, ocobROIName, brokerId);
                            tracer.Trace("BAM Line 276: " + BAMUser);
                            if (BAMUser != Guid.Empty)
                            {
                                postImage["ownerid"] = new EntityReference("systemuser", BAMUser);
                                tracer.Trace("Updated Owner   for ROI  opportunity: " + BAMUser);
                            }
                            else
                            {
                                tracer.Trace("calling getuser function");
                                Entity enUser = getUser("Unassigned", service);
                                tracer.Trace("Record reterieved " + enUser);
                                tracer.Trace("Record reterieved " + enUser.Id);
                                Guid userid = enUser.Id;
                                postImage["ownerid"] = new EntityReference("systemuser", enUser.Id);
                                tracer.Trace("Updated unassigned - owner");
                            }
                        }

                    }
                    service.Update(postImage);


                    #endregion



                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                CrmPluginHelper.CatchFaultException(ex, this);
            }
            catch (InvalidPluginExecutionException ex)
            {
                CrmPluginHelper.CatchInvalidPluginException(ex);
            }
            catch (Exception ex)
            {
                CrmPluginHelper.CatchGenericException(ex, this);
            }
        }

        public Guid GetOpportunityOwnerDetails(IOrganizationService service, ITracingService tracingService, string region, string recordtypename, string class_of_business, string customName)
        {
            Guid userGuid = Guid.Empty;
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' no-lock='true'>
                    <entity name='rsa_customsetting'>
                        <attribute name='rsa_region' />
                            <attribute name = 'rsa_recordtypename' />
                            <attribute name='rsa_opportunityownerid' />
                            <attribute name='rsa_class_of_business' /> 
							<attribute name='rsa_user' /> 							
                        <filter type='and'>
							<condition attribute='rsa_region' value='{0}' operator='eq'/>
							<condition attribute='rsa_recordtypename' value='{1}' operator='eq'/>
                             <filter type='or'>
                              <condition attribute = 'rsa_class_of_business' operator= 'null' />
                              <condition attribute = 'rsa_class_of_business' value = '{2}' operator= 'eq' />
                              </filter>
                              <condition attribute = 'rsa_customsettingtypename' operator= 'like' value='{3}%' />
							   </filter>                 
                    </entity>
                </fetch>";
            try
            {
                EntityCollection enOwnerDetails = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, region, recordtypename, class_of_business.Replace("&", "&amp;"), customName)));
                tracingService.Trace("" + region);
                tracingService.Trace("" + recordtypename);
                tracingService.Trace("" + class_of_business);
                tracingService.Trace("" + customName);
                tracingService.Trace("" + enOwnerDetails.Entities.Count);
                if (enOwnerDetails != null && enOwnerDetails.Entities.Count > 0)
                {
                    userGuid = enOwnerDetails[0].Attributes.Contains("rsa_user") ? ((EntityReference)enOwnerDetails[0].Attributes["rsa_user"]).Id : Guid.Empty;
                    tracingService.Trace("userGuid :" + userGuid);
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetching OpportunityOwnerDetails in GetOpportunityOwnerDetails:" + ex.Message);
            }
            return userGuid;
        }

        private Guid getBAMUser(IOrganizationService service, ITracingService tracingService, string plname, string cobName, Guid brokerId)
        {
            Guid userGuid = Guid.Empty;
            string BDMrole = string.Empty;
            var fetchXml = @"<fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>
                                <entity name='rsa_salesteamroles'>
                                <attribute name='rsa_salesteamrolesid'/>
                                <attribute name='rsa_name'/>
                                <attribute name='createdon'/>
                                <attribute name='rsa_salesmanagerrolename'/>
                                <attribute name='rsa_pl'/>
                                <attribute name='rsa_classofbusiness'/>
                                <attribute name='rsa_bdmrolename'/>
                                <order descending='false' attribute='rsa_name'/>
                                <link-entity name='rsa_pl' alias='aa' link-type='inner' to='rsa_pl' from='rsa_plid'>
                                <filter type='and'>
                                <condition attribute='rsa_name' value='{0}' operator='eq'/>
                                </filter>
                                </link-entity>
                                <link-entity name='rsa_classofbusiness' alias='ab' link-type='inner' to='rsa_classofbusiness' from='rsa_classofbusinessid'>
                                <filter type='and'>
                                <condition attribute='rsa_name' value='{1}' operator='eq'/>
                                </filter>
                                </link-entity>
                                </entity>
                                </fetch>";

            try
            {
                cobName = cobName.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;");
                plname = plname.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;");

                var enOwnerDetails = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, plname, cobName)));
                if (enOwnerDetails != null && enOwnerDetails.Entities.Count > 0)
                {
                    tracingService.Trace("BDMrole fetching");
                    BDMrole = enOwnerDetails[0].Attributes.Contains("rsa_bdmrolename") ? Convert.ToString(enOwnerDetails[0].Attributes["rsa_bdmrolename"]) : string.Empty;
                    tracingService.Trace("BDMrole:" + BDMrole);
                    if (BDMrole != string.Empty)
                    {
                        var fetchXmlBAMUser = @"<fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>
                                                    <entity name='connection'>
                                                    <attribute name='record2id'/>
                                                    <attribute name='record2roleid'/>
                                                    <attribute name='connectionid'/>
                                                    <order descending='false' attribute='record2id'/>
                                                    <filter type='and'>
                                                    <condition attribute='record1id' value='{0}' uitype='account' operator='eq'/>
                                                    </filter>
                                                    <link-entity name='connectionrole' alias='ae' link-type='inner' to='record2roleid' from='connectionroleid'>
                                                    <filter type='and'>
                                                    <condition attribute='name' value='{1}' operator='eq'/>
                                                    </filter>
                                                    </link-entity>
                                                    </entity>
                                                    </fetch>";

                        try
                        {
                            EntityCollection BAMUserDetails = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXmlBAMUser, brokerId, BDMrole)));//convert to entitycollection
                            if (BAMUserDetails != null && BAMUserDetails.Entities.Count > 0)
                            {
                                userGuid = BAMUserDetails[0].Attributes.Contains("record2id") ? ((EntityReference)BAMUserDetails[0].Attributes["record2id"]).Id : Guid.Empty;
                                tracingService.Trace("userGuid:" + userGuid.ToString());
                            }
                        }
                        catch (Exception ex)
                        {
                            tracingService.Trace("Exception while fetching BAMUserDetails in getBAMUser:" + ex.Message);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetching enOwnerDetails in getBAMUser:" + ex.Message);
            }
            return userGuid;
        }

        public  Entity getUser(string name, IOrganizationService service)
        {
            try
            {
                var recordName = new Entity();
                QueryExpression query = new QueryExpression("systemuser");
                query.ColumnSet = new ColumnSet(new string[] { "firstname" });

                query.Criteria.AddCondition("firstname", ConditionOperator.Equal, name);
                query.NoLock = true;
                EntityCollection businessRecordTypes = service.RetrieveMultiple(query);
                if (businessRecordTypes != null && businessRecordTypes.Entities.Count > 0)
                {
                    recordName = businessRecordTypes.Entities[0];
                }
                return recordName;
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

    }
}
