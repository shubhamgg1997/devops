﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using RSA.Crm.Plugins;
using System;
using RSA.CSI.Plugins.Utility;
using RSA.CSI.Plugins.OpportunityLogic;
using System.Collections.Generic;
using System.ServiceModel;

namespace RSA.CSI.Plugins.Opportunity
{
    public class OpportunityPostUpdate : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService tracer = null;
            IPluginExecutionContext context = null;
            IOrganizationService service = null;

            CrmPluginHelper.Initialise(serviceProvider, ref context, ref service, ref tracer, false);
            tracer.Trace("context.Depth:{0}", context.Depth);
            if (context.Depth > 1)
            {
                return;
            }
            try
            {
                if ((context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity) && context.MessageName.ToLowerInvariant() == "update" && context.Stage == 40)
                {
                    string messageName = context.MessageName.ToLowerInvariant();
                    tracer.Trace("Instace created and target is avaialble.");
                    Entity entity = (Entity)context.InputParameters["Target"];
                    Entity postImage = (Entity)context.PostEntityImages["PostImage"];
                    Entity preImage = (Entity)context.PreEntityImages["PostImage"];

                    EntityReference OppStage = postImage.Attributes.Contains("rsa_opportunitystage") ? postImage.GetAttributeValue<EntityReference>("rsa_opportunitystage") : null;


                    string stageName = string.Empty;
                    if (OppStage != null)
                    { stageName = OppStage.Name.ToLowerInvariant(); }
                    string schemes = postImage.FormattedValues.ContainsKey("rsa_schemes") ? postImage.FormattedValues["rsa_schemes"].ToLowerInvariant() : null;
                    EntityReference classOfBusiness = postImage.Attributes.Contains("rsa_classofbusiness") ? postImage.GetAttributeValue<EntityReference>("rsa_classofbusiness") : null;
                    string CobName = string.Empty;
                    if (classOfBusiness != null)
                    {
                        CobName = classOfBusiness.Name;
                        tracer.Trace("CobName", CobName);
                    }

                    EntityReference lineofBusiness = postImage.Attributes.Contains("rsa_lineofbusiness") ? postImage.GetAttributeValue<EntityReference>("rsa_lineofbusiness") : null;
                    bool? oCrOpportunityForNextYearifNtu = postImage.Attributes.Contains("rsa_createopportunityfornextyearifntu") ? postImage.GetAttributeValue<bool?>("rsa_createopportunityfornextyearifntu") : null;
                    bool? oCrOpptyforNextYearIfLapsed = postImage.Attributes.Contains("rsa_createopptyfornextyeariflapsed") ? postImage.GetAttributeValue<bool?>("rsa_createopptyfornextyeariflapsed") : null;
                    string policyNumber = postImage.Attributes.Contains("rsa_policynumber") ? postImage.GetAttributeValue<string>("rsa_policynumber") : null;
                    string newPolicyNumber = postImage.Attributes.Contains("rsa_newpolicynumber") ? postImage.GetAttributeValue<string>("rsa_newpolicynumber") : null;
                    string policyNumberfromPolicy = postImage.Attributes.Contains("rsa_policynumberfrompolicy") ? postImage.GetAttributeValue<string>("rsa_policynumberfrompolicy") : null;
                    int policySystemValue = postImage.Attributes.Contains("rsa_policysystem") ? postImage.GetAttributeValue<OptionSetValue>("rsa_policysystem").Value : 0;
                    Money totalAmount = postImage.Attributes.Contains("rsa_rsaquotedpremium") ? postImage.GetAttributeValue<Money>("rsa_rsaquotedpremium") : null;
                    EntityReference accountId = postImage.Attributes.Contains("parentaccountid") ? postImage.GetAttributeValue<EntityReference>("parentaccountid") : null;
                    EntityReference objCase = postImage.Attributes.Contains("rsa_case") ? postImage.GetAttributeValue<EntityReference>("rsa_case") : null;
                    EntityReference policyId = postImage.Attributes.Contains("rsa_policyid") ? postImage.GetAttributeValue<EntityReference>("rsa_policyid") : null;
                    EntityReference product = postImage.Attributes.Contains("rsa_productid") ? postImage.GetAttributeValue<EntityReference>("rsa_productid") : null;
                    EntityReference customer = postImage.Attributes.Contains("rsa_customer") ? postImage.GetAttributeValue<EntityReference>("rsa_customer") : null;
                    EntityReference oldcustomer = preImage.Attributes.Contains("rsa_customer") ? preImage.GetAttributeValue<EntityReference>("rsa_customer") : null;
                    EntityReference pnl = postImage.Attributes.Contains("rsa_pandlid") ? postImage.GetAttributeValue<EntityReference>("rsa_pandlid") : null;
                    DateTime closeDate = postImage.Attributes.Contains("rsa_closedate") ? postImage.GetAttributeValue<DateTime>("rsa_closedate") : DateTime.MinValue;
                    DateTime precloseDate = preImage.Attributes.Contains("rsa_closedate") ? postImage.GetAttributeValue<DateTime>("rsa_closedate") : DateTime.MinValue;
                    tracer.Trace("closedate", precloseDate);
                    EntityReference oldOpportunityStage = preImage.Attributes.Contains("rsa_opportunitystage") ? preImage.GetAttributeValue<EntityReference>("rsa_opportunitystage") : null;
                    string oldStageName = string.Empty;
                    if (oldOpportunityStage != null)
                    { oldStageName = oldOpportunityStage.Name.ToLowerInvariant(); }
                    string oldSchemes = preImage.FormattedValues.ContainsKey("rsa_schemes") ? preImage.FormattedValues["rsa_schemes"].ToLowerInvariant() : null;
                    EntityReference oldClassOfBusiness = preImage.Attributes.Contains("rsa_classofbusiness") ? preImage.GetAttributeValue<EntityReference>("rsa_classofbusiness") : null;
                    string oldCobName = string.Empty;
                    if (oldClassOfBusiness != null)
                    {
                        oldCobName = oldClassOfBusiness.Name;
                        tracer.Trace("oldCobName", oldCobName);
                    }
                    Money oldAmount = preImage.Attributes.Contains("rsa_rsaquotedpremium") ? preImage.GetAttributeValue<Money>("rsa_rsaquotedpremium") : null;
                    if (postImage.Attributes.Contains("rsa_rsaquotedpremium"))
                    {
                        entity["rsa_rsaquotedpremium"] = totalAmount;
                    }
                    else
                    {
                        entity["rsa_rsaquotedpremium"] = oldAmount;
                    }
                    entity.Id = entity.Id;
                    service.Update(entity);
                    int oldPSystemValue = preImage.Attributes.Contains("rsa_policysystem") ? preImage.GetAttributeValue<OptionSetValue>("rsa_policysystem").Value : 0;
                    string oldPolicyNumber = preImage.Attributes.Contains("rsa_policynumber") ? preImage.GetAttributeValue<string>("rsa_policynumber") : null;
                    EntityReference oldBroker = preImage.Attributes.Contains("parentaccountid") ? preImage.GetAttributeValue<EntityReference>("parentaccountid") : null;
                    string oldRenewalPolicyNo = preImage.Attributes.Contains("rsa_newpolicynumber") ? preImage.GetAttributeValue<string>("rsa_newpolicynumber") : null;
                    string opptyName = postImage.Attributes.Contains("name") ? postImage.GetAttributeValue<string>("name") : null;
                    int year = closeDate.Year;
                    tracer.Trace("year", year);
                    tracer.Trace("Fields Data Available");
                    EntityCollection customLabelDetails = CommonUtility.GetCutomLabelDetails(service, "Page_Layouts_supporting_To_GBP_conversion", string.Empty, string.Empty);
                    EntityCollection customSettings = OpportunityUpdate.GetCustomSettingsbyName(service, tracer, "Marine Task Comment Field");
                    string customValue = string.Empty;
                    if (customLabelDetails.Entities.Count > 0)
                    {
                        foreach (var lablel in customLabelDetails.Entities)
                        {
                            customValue = lablel.Attributes.Contains("rsa_values") ? lablel.GetAttributeValue<string>("rsa_values") : string.Empty;
                            tracer.Trace("Custom Value:{0}", customValue);
                        }
                        tracer.Trace("lineofBusiness" + lineofBusiness.Name);
                        //big id 859 For CLone oppty when stage is not taken up
                        if (!string.IsNullOrEmpty(customValue) && customValue.Contains(lineofBusiness.Name) && (
                            (messageName == "update" && oCrOpportunityForNextYearifNtu != null && oCrOpportunityForNextYearifNtu == true && stageName =="not taken up" && stageName != oldStageName) ||
                            //(messageName == "update" && oCrOpportunityForNextYearifNtu != null && oCrOpportunityForNextYearifNtu == true && oldStageName == "not taken up") ||
                            (messageName == "update" && oCrOpptyforNextYearIfLapsed != null && oCrOpptyforNextYearIfLapsed == true && stageName != oldStageName) ||
                            (messageName == "update" && oCrOpptyforNextYearIfLapsed != null && oCrOpptyforNextYearIfLapsed == true && oldStageName == "lapsed") ||
                            (messageName == "update" && schemes == "declaration" && (stageName == "accepted" || stageName == "renewed") && schemes != oldSchemes) ||
                            (messageName == "update" && schemes == "declaration" && (stageName == "accepted" || stageName == "renewed") && stageName != oldStageName)))
                        {
                            OpportunityUpdate objOppUpdate = new OpportunityUpdate();

                            tracer.Trace("opportunity clone tobe created:{0}");
                            objOppUpdate.CreateOpportunityClone(service, tracer, postImage);
                            tracer.Trace("Clone Opportunity Created");
                        }
                    }

                    if (lineofBusiness.Name.ToLowerInvariant().Contains("marine") && !lineofBusiness.Name.ToLowerInvariant().Contains("renewal"))
                    {
                        string policyNumbers = postImage.Attributes.Contains("rsa_policynumbers") ? postImage.GetAttributeValue<string>("rsa_policynumbers") : null;
                        if (stageName == "accepted" && policyNumbers != null)
                        {
                            bool isPolicy = false;
                            if (oldStageName != "accepted" || policyNumbers != null || policySystemValue != 0 || totalAmount != null || accountId != null)
                            {
                                isPolicy = true;
                            }
                            if (isPolicy)
                            {
                                EntityCollection policyDetails = OpportunityUpdate.GetPolicyData(service, tracer, policyNumbers);
                                if (policyDetails.Entities.Count > 0)
                                {
                                    foreach (var policy in policyDetails.Entities)
                                    {
                                        policy["rsa_opportunity"] = new EntityReference(postImage.LogicalName, postImage.Id);
                                        policy["rsa_customer"] = new EntityReference(customer.LogicalName, customer.Id);
                                        policy["rsa_broker"] = new EntityReference(accountId.LogicalName, accountId.Id);
                                        if (policySystemValue != 0)
                                            policy["rsa_policysystemcode"] = new OptionSetValue(policySystemValue);
                                        policy["rsa_plcode"] = new EntityReference(pnl.LogicalName, pnl.Id);
                                        policy["rsa_classofbusiness"] = new EntityReference(oldClassOfBusiness.LogicalName, oldClassOfBusiness.Id);
                                        if (closeDate != DateTime.MinValue)
                                        {
                                            policy["rsa_policyrenewaldate"] = closeDate;
                                        }
                                        service.Update(policy);
                                        tracer.Trace("Policy fields are updates");
                                    }
                                }
                                else
                                {
                                    Entity policy = new Entity("rsa_policy");
                                    policy["rsa_opportunity"] = new EntityReference(postImage.LogicalName, postImage.Id);
                                    policy["rsa_customer"] = new EntityReference(customer.LogicalName, customer.Id);
                                    policy["rsa_broker"] = new EntityReference(accountId.LogicalName, accountId.Id);
                                    policy["rsa_newpolicynumber"] = newPolicyNumber;
                                    if (policySystemValue != 0)
                                        policy["rsa_policysystemcode"] = new OptionSetValue(policySystemValue);
                                    policy["rsa_premium"] = totalAmount;
                                    policy["rsa_plcode"] = new EntityReference(pnl.LogicalName, pnl.Id);
                                    policy["rsa_name"] = policyNumber;
                                    policy["rsa_classofbusiness"] = new EntityReference(classOfBusiness.LogicalName, classOfBusiness.Id);
                                    if (closeDate != DateTime.MinValue)
                                    {
                                        policy["rsa_policyrenewaldate"] = closeDate;
                                    }
                                    policy["rsa_policynumber"] = policyNumber;
                                    policy["rsa_policystatuscode"] = new OptionSetValue(866760002);
                                    if (product != null)
                                        policy["rsa_productname"] = product.Name;
                                    else
                                        policy["rsa_productname"] = CobName;
                                   // service.Create(policy);
                                    tracer.Trace("Policy is Created");
                                }
                            }
                        }
                    }
                    else
                    {
                        if (objCase != null)
                        {
                            tracer.Trace("Object for case created");
                            Entity cases = new Entity("incident");
                            cases.Id = objCase.Id;
                            if (policyId != null)
                            {
                                cases["rsa_opportunityid"] = new EntityReference(postImage.LogicalName, postImage.Id);
                                cases["rsa_policyid"] = new EntityReference(policyId.LogicalName, policyId.Id);
                            }

                            //Bug 2373
                            CommonUtility common = new CommonUtility();
                            if (pnl.Id != null)
                            {
                                string plname = common.GetNameByEntityId(service, "rsa_pl", pnl.Id, "rsa_name");
                                cases["rsa_pl_w"] = plname;
                                tracer.Trace("Case P&L " + plname);
                            }
                            if (classOfBusiness.Id != null)
                            {
                                string classOfBusinessname = common.GetNameByEntityId(service, "rsa_classofbusiness", classOfBusiness.Id, "rsa_name");
                                cases["rsa_classofbusiness"] = classOfBusinessname;
                                tracer.Trace("Case Class of Business " + classOfBusinessname);
                            }
                            if (product.Id != null)
                            {
                                string productname = common.GetNameByEntityId(service, "rsa_product", product.Id, "rsa_name");
                                cases["rsa_product_w"] = productname;
                                tracer.Trace("Case Product " + productname);
                            }
                            

                            service.Update(cases);
                            tracer.Trace("Case is Updated");
                        }

                        if (stageName == "accepted" && !string.IsNullOrEmpty(policyNumber) && policyId != null)
                        {
                            if (oldStageName != "accepted" || policyNumber != oldPolicyNumber || policySystemValue != oldPSystemValue || totalAmount != oldAmount || accountId != oldBroker)
                            {

                                Entity policy = new Entity("rsa_policy");
                                if (policyId != null)
                                {

                                    policy["rsa_policyid"] = policyId.Id;
                                }
                                policy["rsa_opportunity"] = new EntityReference(postImage.LogicalName, postImage.Id);

                                policy["rsa_customer"] = new EntityReference(customer.LogicalName, customer.Id);

                                policy["rsa_broker"] = new EntityReference(accountId.LogicalName, accountId.Id);

                                policy["rsa_newpolicynumber"] = newPolicyNumber;
                                if (policySystemValue != 0)
                                {
                                    policy["rsa_policysystemcode"] = new OptionSetValue(policySystemValue);

                                }
                                policy["rsa_premium"] = totalAmount;

                                policy["rsa_name"] = policyNumber;

                                policy["rsa_plcode"] = new EntityReference(pnl.LogicalName, pnl.Id);

                                policy["rsa_classofbusiness"] = new EntityReference(oldClassOfBusiness.LogicalName, oldClassOfBusiness.Id);

                                if (closeDate != DateTime.MinValue)
                                {
                                    policy["rsa_policyrenewaldate"] = closeDate;
                                    tracer.Trace("rsa_policyrenewaldate");
                                }
                                policy["rsa_policynumber"] = policyNumber;
                                tracer.Trace("rsa_policynumber");

                                service.Update(policy);
                                tracer.Trace("Policy is Updated");
                            }
                        }
                    }
                    if (stageName == "renewed" && !string.IsNullOrEmpty(newPolicyNumber) && policyId != null)
                    {
                        if (oldStageName != "renewed" || policyNumber != oldPolicyNumber || policySystemValue != oldPSystemValue || totalAmount != oldAmount || accountId != oldBroker || newPolicyNumber != oldRenewalPolicyNo)
                        {
                            if (newPolicyNumber != policyNumber && policyNumberfromPolicy != newPolicyNumber)
                            {
                                Entity policy = new Entity("rsa_policy");
                                policy["rsa_opportunity"] = new EntityReference(postImage.LogicalName, postImage.Id);
                                policy["rsa_customer"] = new EntityReference(customer.LogicalName, customer.Id);
                                policy["rsa_broker"] = new EntityReference(accountId.LogicalName, accountId.Id);
                                policy["rsa_newpolicynumber"] = newPolicyNumber;
                                if (policySystemValue != 0)
                                    policy["rsa_policysystemcode"] = new OptionSetValue(policySystemValue);
                                policy["rsa_premium"] = totalAmount;
                                policy["rsa_plcode"] = new EntityReference(pnl.LogicalName, pnl.Id);
                                policy["rsa_classofbusiness"] = new EntityReference(oldClassOfBusiness.LogicalName, oldClassOfBusiness.Id);
                                policy["rsa_oldpolicynumber"] = policyNumber;
                                if (closeDate != DateTime.MinValue)
                                {
                                    policy["rsa_policyrenewaldate"] = closeDate;
                                }
                                policy["rsa_name"] = newPolicyNumber;
                                if (policyId != null)
                                    policy["rsa_policystatuscode"] = new OptionSetValue(866760002);
                                if (product != null)
                                    policy["rsa_productname"] = product.Name;
                               // service.Create(policy);
                                tracer.Trace("Policy is Created");
                            }
                            else
                            {
                                Entity policy = new Entity("rsa_policy");
                                policy["rsa_policyid"] = policyId.Id;
                                policy["rsa_opportunity"] = new EntityReference(postImage.LogicalName, postImage.Id);
                                policy["rsa_customer"] = new EntityReference(customer.LogicalName, customer.Id);
                                policy["rsa_broker"] = new EntityReference(accountId.LogicalName, accountId.Id);
                                if (policySystemValue != 0)
                                    policy["rsa_policysystemcode"] = new OptionSetValue(policySystemValue);
                                policy["rsa_premium"] = totalAmount;
                                policy["rsa_plcode"] = new EntityReference(pnl.LogicalName, pnl.Id);
                                policy["rsa_classofbusiness"] = new EntityReference(oldClassOfBusiness.LogicalName, oldClassOfBusiness.Id);
                                if (closeDate != DateTime.MinValue)
                                {
                                    policy["rsa_policyrenewaldate"] = closeDate;
                                }
                                policy["rsa_name"] = policyNumber;
                                if (policyId != null)
                                    policy["rsa_policystatuscode"] = new OptionSetValue(866760002);
                                if (product != null)
                                    policy["rsa_productname"] = product.Name;
                                service.Update(policy);
                                tracer.Trace("Policy is updated");
                            }
                        }
                    }
                    OpportunityUpdate objUpdate = new OpportunityUpdate();
                    objUpdate.CreateTask(service, postImage, preImage, tracer, stageName, oldStageName, CobName, oldCobName, lineofBusiness.Name, closeDate, product,context);
                    if (lineofBusiness.Name.ToLowerInvariant().Contains("marine"))
                    {
                        tracer.Trace("Reached Post Update Marine Gbp");

                        TriggerOperations operations = new TriggerOperations();
                        operations.updateGBPFields(context,service, entity,postImage, preImage, tracer, 866760027);
                        tracer.Trace("operations complete about to  Post Update ");
                       
                           
                       
                    }
                    decimal actualValue = postImage.Attributes.Contains("rsa_actualvalue") ? postImage.GetAttributeValue<decimal>("rsa_actualvalue") : 0.00m;
                    if (actualValue != 0 && closeDate != DateTime.MinValue)
                    {
                        tracer.Trace("actualValue:" + actualValue);
                        string yr = closeDate.Year.ToString();
                        string strdate = string.Concat("12/12/", yr);
                        tracer.Trace("strdate: " + strdate);
                        DateTime oDate = DateTime.ParseExact(strdate.ToString(), "dd/MM/yyyy", null);
                        tracer.Trace("oDate: " + oDate);
                        TimeSpan diff = (oDate - closeDate.AddDays(-1));
                        tracer.Trace("diff: " + diff.Days);
                        decimal a = diff.Days;
                        decimal cal = decimal.Divide(a, 365.00m);
                        tracer.Trace("cal:" + cal);
                        decimal set = actualValue * cal;
                        string sum = String.Format("{0:C}", set);
                        // postImage["rsa_inyearbenefit"] = new Money(100.00m); 
                        // postImage["rsa_inyearbenefit_dc"] = 100.00m;
                       //Commented as on update of opportunity key not found error occured; Modified By : Nida ;Modified On :23/03/2022
                       //tracer.Trace("diff: " + postImage["rsa_inyearbenefit_dc"]);
                        service.Update(postImage);
                        tracer.Trace("Service Updated");

                    }
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                CrmPluginHelper.CatchFaultException(ex, this);
            }
            catch (InvalidPluginExecutionException ex)
            {
                CrmPluginHelper.CatchInvalidPluginException(ex);
            }
            catch (Exception ex)
            {
                CrmPluginHelper.CatchGenericException(ex, this);
            }
        }
    }
}
