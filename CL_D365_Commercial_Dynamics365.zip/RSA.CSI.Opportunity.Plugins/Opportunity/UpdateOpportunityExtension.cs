﻿using Microsoft.Xrm.Sdk;
using RSA.Crm.Plugins;
using RSA.CSI.Plugins.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSA.CSI.Opportunity.Plugins.Opportunity
{
    public class UpdateOpportunityExtension : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService tracer = null;
            IPluginExecutionContext context = null;
            IOrganizationService service = null;

            CrmPluginHelper.Initialise(serviceProvider, ref context, ref service, ref tracer, false);
            tracer.Trace("context.Depth:{0}", context.Depth);
            if (context.Depth > 2)
            {
                return;
            }
            try
            {
                if ((context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity) && context.MessageName.ToLowerInvariant() == "update" && context.Stage == 40)
                {
                    tracer.Trace("In Target");
                    string messageName = context.MessageName.ToLowerInvariant();
                    Entity enOpportunity = (Entity)context.InputParameters["Target"];
                    tracer.Trace("Instace created and target is avaialble.");
                    Guid userId = context.UserId;
                    Guid opportunityId = context.PrimaryEntityId;

                    EntityCollection opportunityExtensionCol = CommonUtility.GetOpportunityExtension(service, opportunityId);
                    if (opportunityExtensionCol.Entities.Count > 0)
                    {
                        tracer.Trace("OpportunityExtention retrived, Count:{0} ", opportunityExtensionCol.Entities.Count);
                        Entity enOpportunityExtension = new Entity("rsa_extensionopportunity");
                        enOpportunityExtension.Id = opportunityExtensionCol.Entities[0].Id;
                        tracer.Trace("enOpportunityExtension.Id:{0} ", opportunityExtensionCol.Entities[0].Id.ToString());
                        enOpportunityExtension["rsa_brokerprimaryreference"] = CommonUtility.RetriveBrokerPrimaryReference(opportunityId, service, tracer);
                        tracer.Trace("enOpportunityExtension['rsa_brokerprimaryreference']:{0} ", CommonUtility.RetriveBrokerPrimaryReference(opportunityId, service, tracer));
                        enOpportunityExtension["rsa_areaname"] = CommonUtility.RetriveAreaName(opportunityId, service);
                        tracer.Trace("enOpportunityExtension['rsa_areaname']:{0} ", CommonUtility.RetriveAreaName(opportunityId, service));
                        //enOpportunityExtension["rsa_casereceiveddate"] = CommonUtility.RetriveCaseReceivedDate(opportunityId, service);
                        // tracer.Trace("enOpportunityExtension['rsa_casereceiveddate']:{0} ", CommonUtility.RetriveCaseReceivedDate(opportunityId, service));
                        var caseReceivedDate = CommonUtility.RetriveCaseReceivedDate(opportunityId, service);
                        string opptyName = enOpportunity.Attributes.Contains("name") ? enOpportunity.GetAttributeValue<string>("name") : string.Empty;
                        if (caseReceivedDate.Equals(new DateTime(0001, 01, 01)))
                        {
                            tracer.Trace("In blank");
                            enOpportunityExtension["rsa_casereceiveddate"] = null;
                        }
                        else
                        {
                            tracer.Trace("Got case recieved date");
                            enOpportunityExtension["rsa_casereceiveddate"] = caseReceivedDate;
                        }

                        tracer.Trace("enOpportunityExtension['rsa_casereceiveddate']:{0} ", caseReceivedDate.ToString());
                        enOpportunityExtension["rsa_currentuser"] = CommonUtility.retriveCurrentUser(opportunityId, userId, service, tracer);
                        tracer.Trace("enOpportunityExtension['rsa_currentuser']:{0} ", CommonUtility.retriveCurrentUser(opportunityId, userId, service, tracer));
                        //Added as facing issue on copying stage
                        if(enOpportunity.Attributes.Contains("rsa_opportunitystage"))
                        {
                            if(((EntityReference)enOpportunity["rsa_opportunitystage"]).Id != null)
                            {
                                tracer.Trace("rsa_opportunitystage:  ", Convert.ToString(((EntityReference)enOpportunity["rsa_opportunitystage"]).Id));
                                enOpportunityExtension["rsa_stage"] = new EntityReference("rsa_opportunitystage", ((EntityReference)enOpportunity["rsa_opportunitystage"]).Id);
                            }
                            else
                            {
                                Entity opportunitystage = service.Retrieve("opportunity", opportunityId, new Microsoft.Xrm.Sdk.Query.ColumnSet("rsa_opportunitystage"));
                                if (opportunitystage != null && opportunitystage.Attributes.Contains("rsa_opportunitystage"))
                                {
                                    tracer.Trace("rsa_opportunitystage:  ", Convert.ToString(((EntityReference)opportunitystage["rsa_opportunitystage"]).Id));
                                    enOpportunityExtension["rsa_stage"] = new EntityReference("rsa_opportunitystage", ((EntityReference)opportunitystage["rsa_opportunitystage"]).Id);
                                }
                            }
                            
                            
                        }
                        if(enOpportunity.Attributes.Contains("rsa_lineofbusiness"))
                        {
                            enOpportunityExtension["rsa_lineofbusiness"] = new EntityReference("rsa_lineofbusiness", ((EntityReference)enOpportunity["rsa_lineofbusiness"]).Id);
                        }
                        if (enOpportunity.Attributes.Contains("rsa_name"))
                        {
                            enOpportunityExtension["rsa_name"] = opptyName;
                        }
                        service.Update(enOpportunityExtension);
                        tracer.Trace("Opportunity Extension Updated successfully");
                    }
                }
            }
            catch (Exception ex)
            {
                CrmPluginHelper.CatchGenericException(ex, this);
            }
        }
    }
}
