﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using RSA.Crm.Plugins;
using System;
using RSA.CSI.Plugins.Utility;
using RSA.CSI.Plugins.OpportunityLogic;
using System.Collections.Generic;
using System.ServiceModel;

namespace RSA.CSI.Plugins.Opportunity
{
    public class OpportunityNamePostUpdate : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService tracer = null;
            IPluginExecutionContext context = null;
            IOrganizationService service = null;

            CrmPluginHelper.Initialise(serviceProvider, ref context, ref service, ref tracer, false);
            tracer.Trace("context.Depth:{0}", context.Depth);
            if (context.Depth > 1)
            {
                return;
            }
            try
            {
                if ((context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity) && context.MessageName.ToLowerInvariant() == "update" && context.Stage == 40)
                {
                    string messageName = context.MessageName.ToLowerInvariant();
                    tracer.Trace("Instace created and target is avaialble.");

                    Entity postImage = (Entity)context.PostEntityImages["PostImage"];
                    tracer.Trace("check postimage");
                    //Entity preImage = (Entity)context.PreEntityImages["PostImage"];
                   // tracer.Trace("check preImage");
                    DateTime closeDate = DateTime.MinValue;
                    tracer.Trace("check closeDate");
                    EntityReference encustomer = null;
                    tracer.Trace("check 1");
                    EntityReference encob = null;
                    tracer.Trace("check 2");
                    string cobname = string.Empty;
                    string customerName = string.Empty;
                    if (postImage.Attributes.Contains("rsa_classofbusiness"))
                    {
                        tracer.Trace("Entered Post ");
                        encob = postImage.Attributes.Contains("rsa_classofbusiness") ? postImage.GetAttributeValue<EntityReference>("rsa_classofbusiness") : null;
                        if (encob.Name != null && encob.Name != string.Empty)
                            cobname = encob.Name;
                        tracer.Trace("cobname ", cobname);
                    }
                    //else
                    //{
                    //    tracer.Trace("Entered Pre ");

                    //    encob = preImage.Attributes.Contains("rsa_classofbusiness") ? preImage.GetAttributeValue<EntityReference>("rsa_classofbusiness") : null;
                    //    Entity enCobs = TriggerOperations.getCOBname(encob.Id, service);
                    //    cobname = enCobs.Attributes.Contains("rsa_name") ? enCobs.GetAttributeValue<string>("rsa_name") : null;
                    //}
                    if (postImage.Attributes.Contains("rsa_customer"))
                    {
                        encustomer = postImage.Attributes.Contains("rsa_customer") ? postImage.GetAttributeValue<EntityReference>("rsa_customer") : null;
                        if (encustomer.Name != null && encustomer.Name != string.Empty) {
                            customerName = encustomer.Name;
                            tracer.Trace("encustomer:{0}", encustomer.Name);
                            tracer.Trace("encustomer:{0}", customerName);
                        } }
                    //else
                    //{
                    //    encustomer = preImage.Attributes.Contains("rsa_customer") ? preImage.GetAttributeValue<EntityReference>("rsa_customer") : null;
                    //    Entity encustomers = TriggerOperations.getCOBname(encustomer.Id, service);
                    //    customerName = encustomers.Attributes.Contains("rsa_name") ? encustomers.GetAttributeValue<string>("rsa_name") : null;
                    //    tracer.Trace("encustomer:{0}", customerName);
                    //}
                    if (postImage.Attributes.Contains("rsa_closedate"))
                    {
                        closeDate = postImage.Attributes.Contains("rsa_closedate") ? postImage.GetAttributeValue<DateTime>("rsa_closedate") : DateTime.MinValue;
                        tracer.Trace("closeDate:{0}", closeDate.Year);
                    }
                    //else
                    //{
                    //    closeDate = preImage.Attributes.Contains("rsa_closedate") ? preImage.GetAttributeValue<DateTime>("rsa_closedate") : DateTime.MinValue;
                    //    tracer.Trace("closeDate:{0}", closeDate.Year);
                    //}
                    if(closeDate != DateTime.MinValue || customerName!=null|| cobname!= null) {
                        postImage["name"] = cobname + "-" + customerName + "-" + closeDate.Year;
                        service.Update(postImage);
                    }
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                CrmPluginHelper.CatchFaultException(ex, this);
            }
            catch (InvalidPluginExecutionException ex)
            {
                CrmPluginHelper.CatchInvalidPluginException(ex);
            }
            catch (Exception ex)
            {
                CrmPluginHelper.CatchGenericException(ex, this);
            }
        }
    }
    
}