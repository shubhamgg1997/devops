﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using RSA.CSI.Plugins.Utility;
using System.Linq;

namespace RSA.CSI.Plugins.OpportunityLogic
{
    public class OpportunityUpdate
    {
        /// <summary>
        /// This function fetches the line of business details when a name is passed as a parameter.
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracer"></param>
        /// <param name="rName"></param>
        /// <returns></returns>
        public static EntityCollection GetRecordDetailsbyName(IOrganizationService service, ITracingService tracer, string rName)
        {
            try
            {
                string fetchQuery = "<fetch mapping = 'logical'>";
                fetchQuery += "<entity name = 'rsa_lineofbusiness'>";
                fetchQuery += "<attribute name = 'rsa_lineofbusinessid'/>";
                fetchQuery += "<attribute name = 'rsa_name'/>";
                fetchQuery += "<filter type = 'and'> ";
                fetchQuery += "<condition attribute = 'rsa_name' operator= 'like' value = '" + rName + "%'/>";
                fetchQuery += "</filter>";
                fetchQuery += "</entity>";
                fetchQuery += "</fetch>";
                tracer.Trace(" Record Details: {0}", fetchQuery);
                EntityCollection businessRecordTypes = service.RetrieveMultiple(new FetchExpression(fetchQuery));
                tracer.Trace(" Record Types: {0}", businessRecordTypes);
                return businessRecordTypes;

            }

            catch (Exception ex)
            {
                tracer.Trace("GetRecordDetailsbyName-Error" + ex.Message.ToString());
                throw new InvalidPluginExecutionException(ex.Message);

            }
        }
        /// <summary>
        /// This function gets the Case entity details based on the Guid which is passed as a parameter.
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracer"></param>
        /// <param name="caseId"></param>
        /// <returns></returns>

        public static Entity GetCaseDetailsbyCaseId(IOrganizationService service, ITracingService tracer, Guid caseId)
        {
            try
            {
                return service.Retrieve("incident", caseId, new ColumnSet("rsa_casereceiveddate"));
            }
            catch (Exception ex)
            {
                tracer.Trace("GetCaseDetailsbyCaseId-Error" + ex.Message.ToString());
                throw new InvalidPluginExecutionException(ex.Message);

            }
        }
        /// <summary>
        /// This function creates a clone of a existing opportunity record and sets various other fields of clone opportunity.
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracer"></param>
        /// <param name="entity"></param>
        /// <param name="lob"></param>
        /// <param name="stageName"></param>
        internal void CreatePipelineOpportunity(IOrganizationService service, ITracingService tracer, Entity entity, Entity preImage, EntityReference lob, string stageName)
        {
            try
            {
                if (stageName.ToLowerInvariant() == "accepted" || stageName.ToLowerInvariant() == "renewed")
                {
                    bool isCreateOppForNextYearIfAcce = false;
                    if (preImage.Attributes.Contains("rsa_createopportunityfornextyearifacce"))
                        isCreateOppForNextYearIfAcce = preImage.GetAttributeValue<bool>("rsa_createopportunityfornextyearifacce");
                    else
                        isCreateOppForNextYearIfAcce = entity.GetAttributeValue<bool>("rsa_createopportunityfornextyearifacce");

                    if (isCreateOppForNextYearIfAcce)
                    {
                        Entity cloneOpportunity = new Entity("opportunity");
                        EntityReference opportunityStage = entity.Attributes.Contains("rsa_opportunitystage") ? entity.GetAttributeValue<EntityReference>("rsa_opportunitystage") : null;
                        string name = entity.Attributes.Contains("name") ? entity.GetAttributeValue<string>("name") : null;
                        string opportunityOrigin = entity.FormattedValues.ContainsKey("rsa_opportunityorigin") ? entity.FormattedValues["rsa_opportunityorigin"] : null;
                        DateTime closeDate = entity.Attributes.Contains("rsa_closedate") ? entity.GetAttributeValue<DateTime>("rsa_closedate") : DateTime.MinValue;
                        EntityReference outcomeReason = entity.Attributes.Contains("rsa_outcomereasonid") ? entity.GetAttributeValue<EntityReference>("rsa_outcomereasonid") : null;
                        bool isUpdated = entity.Contains("rsa_isupdated") ? entity.GetAttributeValue<bool>("rsa_isupdated") : false;
                        EntityReference underwriterTrader = entity.Attributes.Contains("rsa_secondaryowner") ? entity.GetAttributeValue<EntityReference>("rsa_secondaryowner") : null;
                        decimal? brokerTargetPremiumGBP = entity.Attributes.Contains("rsa_targetpremium") ? entity.GetAttributeValue<decimal?>("rsa_targetpremium") : 0.00m;
                        int probability = entity.Attributes.Contains("closeprobability") ? entity.GetAttributeValue<int>("closeprobability") : 0;
                        EntityReference brokerContact = entity.Attributes.Contains("rsa_brokercontact") ? entity.GetAttributeValue<EntityReference>("rsa_brokercontact") : null;
                        string prospectType = entity.FormattedValues.ContainsKey("rsa_prospecttype") ? entity.FormattedValues["rsa_prospecttype"] : null;
                        EntityReference broker = entity.Attributes.Contains("parentaccountid") ? entity.GetAttributeValue<EntityReference>("parentaccountid") : null;
                        DateTime expiryDate = entity.Attributes.Contains("rsa_expirydate") ? entity.GetAttributeValue<DateTime>("rsa_expirydate") : DateTime.MinValue;
                        string opportunityDescription = entity.Attributes.Contains("rsa_opportunitydescription") ? entity.GetAttributeValue<string>("rsa_opportunitydescription") : null;
                        EntityReference customer = entity.Attributes.Contains("rsa_customer") ? entity.GetAttributeValue<EntityReference>("rsa_customer") : null;
                        EntityReference pl = entity.Attributes.Contains("rsa_pandlid") ? entity.GetAttributeValue<EntityReference>("rsa_pandlid") : null;
                        EntityReference classOfBusiness = entity.Attributes.Contains("rsa_classofbusiness") ? entity.GetAttributeValue<EntityReference>("rsa_classofbusiness") : null;
                        EntityReference product = entity.Attributes.Contains("rsa_productid") ? entity.GetAttributeValue<EntityReference>("rsa_productid") : null;
                        // Money expiryPremium = entity.Attributes.Contains("rsa_expirypremium") ? entity.GetAttributeValue<Money>("rsa_expirypremium") : null;
                        decimal expiryPremium = entity.Attributes.Contains("rsa_rsaexpirypremium") ? entity.GetAttributeValue<decimal>("rsa_rsaexpirypremium") : 0;
                        decimal elPremium = entity.Attributes.Contains("rsa_elpremium") ? (decimal)entity.GetAttributeValue<Money>("rsa_elpremium").Value : 0;
                        decimal plPremium = entity.Attributes.Contains("rsa_plpremium") ? (decimal)entity.GetAttributeValue<Money>("rsa_plpremium").Value : 0;
                        tracer.Trace("opportunity Fields data present");
                        //cloneOpportunity["rsa_name"] = name;
                        Guid stageID = CommonUtility.GetLookUpDetailsbyText(service, "In View", "rsa_opportunitystage", lob.Id).Id;
                        cloneOpportunity["rsa_opportunitystage"] = new EntityReference("rsa_opportunitystage", stageID);
                        cloneOpportunity["rsa_opportunityorigin"] = new OptionSetValue(866760000);

                        if (expiryDate != null)
                        {
                            cloneOpportunity["rsa_closedate"] = closeDate.AddDays(1);
                            tracer.Trace("Added days to Renewal Date");
                        }
                        if (broker != null)
                            cloneOpportunity["parentaccountid"] = new EntityReference("account", broker.Id);
                        cloneOpportunity["rsa_opportunitydescription"] = opportunityDescription;
                        if (customer != null)
                            cloneOpportunity["rsa_customer"] = new EntityReference("rsa_customer", customer.Id);
                        cloneOpportunity["rsa_createopportunityfornextyearifntu"] = false;
                        if (outcomeReason != null)
                            cloneOpportunity["rsa_outcomereasonid"] = new EntityReference("rsa_outcomereason", outcomeReason.Id);
                        if (underwriterTrader != null)
                            cloneOpportunity["rsa_secondaryowner"] = new EntityReference("systemuser", underwriterTrader.Id);
                        if (pl != null)
                            cloneOpportunity["rsa_pandlid"] = new EntityReference("rsa_pl", pl.Id);
                        if (classOfBusiness != null)
                            cloneOpportunity["rsa_classofbusiness"] = new EntityReference("rsa_classofbusiness", classOfBusiness.Id);
                        if (product != null)
                            cloneOpportunity["rsa_productid"] = new EntityReference("rsa_product", product.Id);
                        cloneOpportunity["rsa_lineofbusiness"] = new EntityReference("rsa_lineofbusiness", CommonUtility.GetLookUpDetailsbyText(service, "GSL - Renewal", "rsa_lineofbusiness", Guid.Empty).Id);
                        cloneOpportunity["rsa_rsaexpirypremium"] = expiryPremium;
                        cloneOpportunity["rsa_targetpremium"] = brokerTargetPremiumGBP;
                        cloneOpportunity["rsa_elpremium"] = elPremium;
                        cloneOpportunity["rsa_plpremium"] = plPremium;
                        cloneOpportunity["closeprobability"] = probability;
                        if (brokerContact != null)
                            cloneOpportunity["rsa_brokercontact"] = new EntityReference("contact", brokerContact.Id);
                        cloneOpportunity["rsa_isupdated"] = false;
                        service.Create(cloneOpportunity);
                        tracer.Trace("Clone Record Created for Opportunity");
                    }
                }
            }
            catch (Exception ex)
            {
                tracer.Trace("CreatePipelineOpportunity-Error" + ex.Message.ToString());
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
        /// <summary>
        /// This function fetches the Custom settings entity details by passing customName as a parameter
        /// </summary>
        /// <param name="service"></param>
        /// <param name="customName"></param>
        /// <returns></returns>
        public static EntityCollection GetCustomSettingsbyName(IOrganizationService service, ITracingService tracer, string customName)
        {
            try
            {
                string fetchQuery = "<fetch mapping = 'logical'>";
                fetchQuery += "<entity name = 'rsa_customsetting'>";
                fetchQuery += "<attribute name='rsa_typeoffield' />";
                fetchQuery += "<attribute name = 'rsa_fieldlabel' />";
                fetchQuery += "<attribute name='rsa_fieldapi' />";
                fetchQuery += "<filter type = 'and'>";
                fetchQuery += "<condition attribute = 'rsa_customsettingtypename' operator= 'like' value='" + customName + "%' />";
                fetchQuery += "</filter>";
                fetchQuery += "</entity>";
                fetchQuery += "</fetch>";
                EntityCollection customSettings = service.RetrieveMultiple(new FetchExpression(fetchQuery));
                tracer.Trace("Number of RcustomSettings: {0}", customSettings.Entities.Count);
                return customSettings;
            }
            catch (Exception ex)
            {
                tracer.Trace("GetCustomSettingsbyName-Error" + ex.Message.ToString());
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        ///by sujeet
        public static EntityCollection GetCustomSettingsbytype(IOrganizationService service, ITracingService tracer, int customtype)
        {
            try
            {
                string fetchQuery = "<fetch mapping = 'logical'>";
                fetchQuery += "<entity name = 'rsa_customsetting'>";
                fetchQuery += "<attribute name='rsa_typeoffield' />";
                fetchQuery += "<attribute name = 'rsa_fieldlabel' />";
                fetchQuery += "<attribute name='rsa_fieldapi' />";
                fetchQuery += "<attribute name='rsa_gbpcurrencyfield' />";
                fetchQuery += "<attribute name='rsa_policycurrencypcfield' />";
                fetchQuery += "<attribute name='rsa_formulatype' />";
                fetchQuery += "<attribute name='rsa_formuladescription' />";
                fetchQuery += "<attribute name='rsa_pcelc' />";
                fetchQuery += "<filter type = 'and'>";
                fetchQuery += "<condition attribute = 'rsa_customsettingtype' operator= 'eq' value='" + customtype + "' />";
                fetchQuery += "<condition attribute = 'rsa_formuladescription' operator= 'not-null' />";
                fetchQuery += "<condition attribute = 'statecode' value = '0' operator= 'eq' />";
                fetchQuery += "</filter>";
                fetchQuery += "</entity>";
                fetchQuery += "</fetch>";
                EntityCollection customSettings = service.RetrieveMultiple(new FetchExpression(fetchQuery));
                tracer.Trace("Number of RcustomSettings: {0}", customSettings.Entities.Count);
                return customSettings;
            }
            catch (Exception ex)
            {
                tracer.Trace("GetCustomSettingsbyName-Error" + ex.Message.ToString());
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
        /// <summary>
        /// This function creates a clone of the existing opportunity records based on certain conditions and sets various other fields of the clone opportunity.
        /// </summary>
        /// <param name="service"></param>
        /// <param name="entity"></param>
        internal void CreateOpportunityClone(IOrganizationService service, ITracingService tracer, Entity entity)
        {
            try
            {
                Entity cloneEntity = new Entity("opportunity");
                tracer.Trace("Clone Opportunity");
                Entity recordName = new Entity("rsa_lineofbusiness");
                tracer.Trace("recordName for rsa_lineofbusiness");
                EntityReference lineofBusiness = entity.Attributes.Contains("rsa_lineofbusiness") ? entity.GetAttributeValue<EntityReference>("rsa_lineofbusiness") : null;
                tracer.Trace("lineofBusiness" + lineofBusiness.Name);

                string description = entity.Attributes.Contains("rsa_opportunitydescription") ? entity.GetAttributeValue<string>("rsa_opportunitydescription") : null;
                tracer.Trace("description" + description);

                string masterPolicyNumber = entity.Attributes.Contains("rsa_masterpolicynumber") ? entity.GetAttributeValue<string>("rsa_masterpolicynumber") : null;
                tracer.Trace("masterPolicyNumber" + masterPolicyNumber);

                string name = entity.Attributes.Contains("name") ? entity.GetAttributeValue<string>("name") : null;
                tracer.Trace("name" + name);
                decimal? commissionPC = entity.Attributes.Contains("rsa_commissionpc") ? entity.GetAttributeValue<decimal?>("rsa_commissionpc") : null;
                tracer.Trace("commissionPC" + commissionPC);

                decimal commissionRsaPremiumPc = entity.Attributes.Contains("rsa_commissionrsapremiumpc") ? entity.GetAttributeValue<decimal>("rsa_commissionrsapremiumpc") : 0.00M;
                tracer.Trace("commissionRsaPremiumPc" + commissionRsaPremiumPc);

                int schemes = entity.Attributes.Contains("rsa_schemes") ? entity.GetAttributeValue<OptionSetValue>("rsa_schemes").Value : 0;
                tracer.Trace("schemes:" + schemes);

                EntityReference classification = entity.Attributes.Contains("rsa_classification") ? entity.GetAttributeValue<EntityReference>("rsa_classification") : null;
                tracer.Trace("classification:" + classification);

                EntityReference methodOfPlacement = entity.Attributes.Contains("rsa_methodofplacement") ? entity.GetAttributeValue<EntityReference>("rsa_methodofplacement") : null;
                tracer.Trace("methodOfPlacement:" + methodOfPlacement);

                int? sourceArea = entity.Attributes.Contains("rsa_sourcearea") ? entity.GetAttributeValue<OptionSetValue>("rsa_sourcearea").Value : 0;
                int? vat = entity.Attributes.Contains("rsa_vat") ? entity.GetAttributeValue<OptionSetValue>("rsa_vat").Value : 0;
                EntityReference state = entity.Attributes.Contains("rsa_state") ? entity.GetAttributeValue<EntityReference>("rsa_state") : null;
                tracer.Trace("state:" + state);

                EntityReference sourceCountry = entity.Attributes.Contains("rsa_sourcecountry") ? entity.GetAttributeValue<EntityReference>("rsa_sourcecountry") : null;
                int? exposureArea = entity.Attributes.Contains("rsa_exposurearea") ? entity.GetAttributeValue<OptionSetValue>("rsa_exposurearea").Value : 0;
                EntityReference exposureCountry = entity.Attributes.Contains("rsa_exposurecountry") ? entity.GetAttributeValue<EntityReference>("rsa_exposurecountry") : null;
                tracer.Trace("exposureCountry:" + exposureCountry);

                int? synergyBranch = entity.Attributes.Contains("rsa_synergybranch") ? entity.GetAttributeValue<OptionSetValue>("rsa_synergybranch").Value : 0;
                int? Risk = entity.Attributes.Contains("rsa_risk") ? entity.GetAttributeValue<OptionSetValue>("rsa_risk").Value : 0;
                decimal? rsaPremiumGocPC = entity.Attributes.Contains("rsa_rsapremiumgocpc") ? entity.GetAttributeValue<decimal?>("rsa_rsapremiumgocpc") : null;
                int? source = entity.Attributes.Contains("rsa_source") ? entity.GetAttributeValue<OptionSetValue>("rsa_source").Value : 0;
                EntityReference typeOfRisk = entity.Attributes.Contains("rsa_typeofrisk") ? entity.GetAttributeValue<EntityReference>("rsa_typeofrisk") : null;
                tracer.Trace("typeOfRisk:" + typeOfRisk);
                int? marineStamp = entity.Attributes.Contains("rsa_marinestamp") ? entity.GetAttributeValue<OptionSetValue>("rsa_marinestamp").Value : 0;
                string reinsuredName = entity.Attributes.Contains("rsa_reinsuredname") ? entity.GetAttributeValue<string>("rsa_reinsuredname") : null;
                string interest = entity.Attributes.Contains("rsa_interest") ? entity.GetAttributeValue<string>("rsa_interest") : null;
                EntityReference accountId = entity.Attributes.Contains("parentaccountid") ? entity.GetAttributeValue<EntityReference>("parentaccountid") : null;
                tracer.Trace("accountId post image is " + accountId.Name);
                EntityReference product = entity.Attributes.Contains("rsa_productid") ? entity.GetAttributeValue<EntityReference>("rsa_productid") : null;
                tracer.Trace("product post image is " + product.Name);
                int funnelStage = entity.Attributes.Contains("rsa_funnelstage") ? entity.GetAttributeValue<OptionSetValue>("rsa_funnelstage").Value : 0;
                tracer.Trace("funnelStage" + funnelStage);
                EntityReference customer = entity.Attributes.Contains("rsa_customer") ? entity.GetAttributeValue<EntityReference>("rsa_customer") : null;
                EntityReference classOfBusiness = entity.Attributes.Contains("rsa_classofbusiness") ? entity.GetAttributeValue<EntityReference>("rsa_classofbusiness") : null;
                int? region = entity.Attributes.Contains("rsa_region") ? entity.GetAttributeValue<OptionSetValue>("rsa_region").Value : 0;
                DateTime closeDate = entity.Attributes.Contains("rsa_closedate") ? entity.GetAttributeValue<DateTime>("rsa_closedate") : DateTime.MinValue;
                EntityReference opportunityStage = entity.Attributes.Contains("rsa_opportunitystage") ? entity.GetAttributeValue<EntityReference>("rsa_opportunitystage") : null;
                Boolean longTermAgreement = entity.Attributes.Contains("rsa_longtermagreement") ? entity.GetAttributeValue<Boolean>("rsa_longtermagreement") : false;
                DateTime? DateLTAExpires = entity.Attributes.Contains("rsa_contractDurationYears") ? entity.GetAttributeValue<DateTime?>("rsa_contractDurationYears") : null;
                EntityReference pl = entity.Attributes.Contains("rsa_pandlid") ? entity.GetAttributeValue<EntityReference>("rsa_pandlid") : null;
                EntityReference policyCurrrencyPC = entity.Attributes.Contains("rsa_currency") ? entity.GetAttributeValue<EntityReference>("rsa_currency") : null;
                int opportunityorigin = entity.Attributes.Contains("rsa_opportunityorigin") ? entity.GetAttributeValue<OptionSetValue>("rsa_opportunityorigin").Value : 0;
                tracer.Trace("opportunityorigin" + opportunityorigin);
                DateTime expirydatemarine = entity.Attributes.Contains("rsa_expirydatemarine") ? entity.GetAttributeValue<DateTime>("rsa_expirydatemarine") : DateTime.MinValue;
                decimal rsaexternalreinsuranceinclpanelpc = entity.Attributes.Contains("rsa_rsaexternalreinsuranceinclpanelpc") ? entity.GetAttributeValue<decimal>("rsa_rsaexternalreinsuranceinclpanelpc") : 0.00m;
                decimal? exchangerate = entity.Attributes.Contains("rsa_exchangerate") ? entity.GetAttributeValue<decimal?>("rsa_exchangerate") : null;

                EntityReference existingInsurer = entity.Attributes.Contains("rsa_existinginsurerid") ? entity.GetAttributeValue<EntityReference>("rsa_existinginsurerid") : null; ;
                int holdingAgent = entity.Attributes.Contains("rsa_holdingagent") ? (entity.GetAttributeValue<OptionSetValue>("rsa_holdingagent")).Value : 0;

                tracer.Trace("opportunity Fields data  present");
                //Sumegh Dhole : 09 March 2021 : Defect 859  : Mandatory field copied to clone opportunity
                cloneEntity["rsa_existinginsurerid"] = existingInsurer;
                if (holdingAgent != 0)
                {
                    cloneEntity["rsa_holdingagent"] = new OptionSetValue(holdingAgent);
                }
                //Resolve incident - if stage is NTA and NTA flag is Yes, NB opportunity was not getting saved due to missing LOB. 
                if (lineofBusiness != null)
                {
                    cloneEntity["rsa_lineofbusiness"] = new EntityReference("rsa_lineofbusiness", lineofBusiness.Id);
                    tracer.Trace("line of business addded to clone Opportunity :{0}", lineofBusiness.Id);
                }
                if (lineofBusiness != null)
                {
                    if (lineofBusiness.Name.ToLowerInvariant().Contains("marine") && lineofBusiness.Name.ToLowerInvariant().Contains("regional"))
                    {
                        cloneEntity["rsa_opportunityformid"] = getFormID(service, tracer, entity);
                        tracer.Trace("LOB contains New Business - Marine Regional" + cloneEntity["rsa_opportunityformid"]);

                        tracer.Trace("LOB contains New Business - Marine Regional");
                        recordName = CommonUtility.GetLookUpDetailsbyText(service, "New Business - Marine Regional", "rsa_lineofbusiness", Guid.Empty);
                        cloneEntity["rsa_lineofbusiness"] = new EntityReference("rsa_lineofbusiness", recordName.Id);
                        tracer.Trace("line of business addded to clone Opportunity :{0}", recordName.Id);
                        //Date 04022021 MAde changes for bug id 859 
                        cloneEntity["rsa_closedate"] = Convert.ToDateTime(closeDate).AddYears(1);
                        if (opportunityorigin != 0)
                        {
                            tracer.Trace("about to set rsa_opportunityorigin ");
                            cloneEntity["rsa_opportunityorigin"] = new OptionSetValue(866760000);
                        }
                        DateTime ExpirryMarine = closeDate.AddYears(2).AddDays(-1);
                        cloneEntity["rsa_expirydatemarine"] = Convert.ToDateTime(ExpirryMarine);
                        tracer.Trace(" Expirydatemarine:{0}", cloneEntity["rsa_expirydatemarine"]);
                        if (policyCurrrencyPC != null)
                        {
                            cloneEntity["rsa_currency"] = new EntityReference("transactioncurrency", policyCurrrencyPC.Id);
                            tracer.Trace("policyCurrrencyPC" + cloneEntity["rsa_currency"]);
                        }
                        if (funnelStage != 0)
                        {
                            cloneEntity["rsa_funnelstage"] = new OptionSetValue(funnelStage);
                            tracer.Trace("funnelStage" + cloneEntity["rsa_funnelstage"]);
                        }
                        cloneEntity["rsa_rsaexternalreinsuranceinclpanelpc"] = rsaexternalreinsuranceinclpanelpc;
                        cloneEntity["rsa_exchangerate"] = exchangerate;

                        if (closeDate != DateTime.MinValue || classOfBusiness.Name != null || customer.Name != null)
                        {
                            cloneEntity["name"] = customer.Name + "-" + classOfBusiness.Name + "-" + closeDate.AddYears(1).Year;
                        }


                    }
                    if (lineofBusiness.Name.ToLowerInvariant().Contains("marine") && lineofBusiness.Name.ToLowerInvariant().Contains("london"))
                    {
                        cloneEntity["rsa_opportunityformid"] = getFormID(service, tracer, entity);
                        recordName = CommonUtility.GetLookUpDetailsbyText(service, "New Business - Marine London", "rsa_lineofbusiness", Guid.Empty);
                        cloneEntity["rsa_lineofbusiness"] = new EntityReference("rsa_lineofbusiness", recordName.Id);
                        if (description != null)
                        {
                            cloneEntity["description"] = "This opportunity is created as " + name + "opportunity was Not Taken Up.";
                            tracer.Trace("Description addded to clone Opportunity :{0}", "This opportunity is created as " + name + "opportunity was Not Taken Up.");
                        }
                        recordName = CommonUtility.GetLookUpDetailsbyText(service, "Renewal - Marine London", "rsa_lineofbusiness", Guid.Empty);
                        cloneEntity["rsa_lineofbusiness"] = new EntityReference("rsa_lineofbusiness", recordName.Id);
                        //For marine declarations
                        if (masterPolicyNumber != null)
                        {
                            cloneEntity["rsa_expiringpolicynumber"] = masterPolicyNumber;
                            tracer.Trace("Expiring Policy Number addded to clone Opportunity :{0}", masterPolicyNumber);
                        }

                        if (rsaPremiumGocPC != null)
                        {
                            cloneEntity["rsa_expiringgrosspremiumpc"] = rsaPremiumGocPC;
                            tracer.Trace("Expiring Gross Premium (PC) addded to clone Opportunity :{0}", rsaPremiumGocPC);
                        }
                        if (commissionPC != null)
                        {
                            cloneEntity["rsa_rsaexpiringcommission"] = commissionPC;
                            tracer.Trace("Expiring Commission addded to clone Opportunity :{0}", commissionPC);
                        }
                        if (commissionRsaPremiumPc != 0)
                        {
                            cloneEntity["rsa_rsaexpiringcommissionpc"] = commissionRsaPremiumPc;
                            tracer.Trace("commission Rsa Premium(Pc) addded to clone Opportunity :{0}", commissionRsaPremiumPc);

                        }
                        //For marine europe synergy codes
                        if (schemes != 0)
                        {
                            cloneEntity["rsa_schemes"] = new OptionSetValue(schemes);
                            tracer.Trace("schemes addded to clone Opportunity :{0}", schemes);
                        }
                        if (classification != null)
                        {
                            cloneEntity["rsa_classification"] = new EntityReference("rsa_classification", classification.Id);
                        }
                        if (methodOfPlacement != null)
                        {
                            cloneEntity["rsa_methodofplacement"] = new EntityReference("rsa_methodofplacement", methodOfPlacement.Id);
                            tracer.Trace("methodOfPlacement addded to clone Opportunity :{0}", methodOfPlacement.Id);
                        }

                        if (sourceArea != 0)
                        {
                            cloneEntity["rsa_sourcearea"] = new OptionSetValue(sourceArea.Value);
                            tracer.Trace("sourceArea addded to clone Opportunity :{0}", sourceArea);

                        }
                        if (vat != 0)
                        {
                            cloneEntity["rsa_vat"] = new OptionSetValue(vat.Value);
                        }
                        if (state != null)
                        {
                            cloneEntity["rsa_state"] = new EntityReference("rsa_state", state.Id);
                        }
                        if (sourceCountry != null)
                        {
                            cloneEntity["rsa_sourcecountry"] = new EntityReference("rsa_country", sourceCountry.Id);
                        }
                        if (exposureArea != 0)
                        {
                            cloneEntity["rsa_exposurearea"] = new OptionSetValue(exposureArea.Value);
                        }
                        if (exposureCountry != null)
                        {
                            cloneEntity["rsa_exposurecountry"] = new EntityReference("rsa_country", exposureCountry.Id);
                        }
                        if (synergyBranch != 0)
                        {
                            // cloneEntity["rsa_synergybranch"] =new OptionSetValue( synergyBranch.Value);
                        }
                        if (Risk != 0)
                        {
                            cloneEntity["rsa_risk"] = new OptionSetValue(Risk.Value);
                            tracer.Trace("Risk:{0}", Risk);
                        }
                        if (source != 0)
                        {
                            cloneEntity["rsa_source"] = new OptionSetValue(source.Value);
                            tracer.Trace("source:{0}", source);
                        }
                        if (typeOfRisk != null)
                        {
                            cloneEntity["rsa_typeofrisk"] = new EntityReference("rsa_typeofrisk", typeOfRisk.Id);
                        }
                        if (marineStamp != 0)
                        {
                            cloneEntity["rsa_marinestamp"] = new OptionSetValue(marineStamp.Value);
                            tracer.Trace("MarineStamp :{0}", marineStamp);
                        }
                        if (reinsuredName != null)
                        {
                            cloneEntity["rsa_reinsuredname"] = reinsuredName;
                            tracer.Trace("Reinsured Name :{0}", reinsuredName);
                        }
                        if (interest != null)
                        {
                            cloneEntity["rsa_interest"] = interest;
                        }
                        if (name != null)
                        {
                            cloneEntity["name"] = name;
                            tracer.Trace("Name :{0}", name);
                        }
                    }
                    if (lineofBusiness.Name.ToLowerInvariant() == "marine" && lineofBusiness.Name.ToLowerInvariant() == "europe")
                    {
                        cloneEntity["rsa_opportunityformid"] = getFormID(service, tracer, entity);
                        recordName = CommonUtility.GetLookUpDetailsbyText(service, "New Business - Marine Europe", "rsa_lineofbusiness", Guid.Empty);
                        cloneEntity["rsa_lineofbusiness"] = new EntityReference("rsa_lineofbusiness", recordName.Id);
                        if (description != null)
                        {
                            cloneEntity["description"] = "This opportunity is created as " + name + "opportunity was Not Taken Up.";
                        }
                        recordName = CommonUtility.GetLookUpDetailsbyText(service, "Renewal - Marine Europe", "rsa_lineofbusiness", Guid.Empty);
                        cloneEntity["rsa_lineofbusiness"] = new EntityReference("rsa_lineofbusiness", recordName.Id);

                        if (masterPolicyNumber != null)
                        {
                            cloneEntity["rsa_expiringpolicynumber"] = masterPolicyNumber;
                        }
                        if (rsaPremiumGocPC != 0)
                        {
                            cloneEntity["rsa_expiringgrosspremiumpc"] = rsaPremiumGocPC;
                        }
                        if (commissionPC != 0)
                        {
                            cloneEntity["rsa_rsaexpiringcommission"] = commissionPC;
                        }
                        if (commissionRsaPremiumPc != 0)
                        {
                            cloneEntity["rsa_rsaexpiringcommissionpc"] = commissionRsaPremiumPc;
                        }
                        //For marine europe synergy codes
                        if (schemes != 0)
                        {
                            cloneEntity["rsa_schemes"] = new OptionSetValue(schemes);
                        }
                        if (classification != null)
                        {
                            cloneEntity["rsa_classification"] = new EntityReference("rsa_classification", classification.Id);
                        }
                        if (methodOfPlacement != null)
                        {
                            cloneEntity["rsa_methodofplacement"] = new EntityReference("rsa_methodofplacement", methodOfPlacement.Id);
                        }
                        if (sourceArea != 0)
                        {
                            cloneEntity["rsa_sourcearea"] = new OptionSetValue(sourceArea.Value);
                        }

                        if (vat != 0)
                        {
                            cloneEntity["rsa_vat"] = new OptionSetValue(vat.Value);

                            tracer.Trace("Vat :{0}", vat);
                        }
                        if (state != null)
                        {
                            cloneEntity["rsa_state"] = new EntityReference("rsa_state", state.Id);

                        }
                        if (sourceCountry != null)
                        {
                            cloneEntity["rsa_sourcecountry"] = new EntityReference("rsa_country", sourceCountry.Id);
                        }
                        if (exposureArea != 0)
                        {
                            cloneEntity["rsa_exposurearea"] = new OptionSetValue(exposureArea.Value);
                        }
                        if (exposureCountry != null)
                        {
                            cloneEntity["rsa_exposurecountry"] = new EntityReference("rsa_country", exposureCountry.Id);
                        }
                        if (synergyBranch != 0)
                        {
                            cloneEntity["rsa_synergybranch"] = new OptionSetValue(synergyBranch.Value);
                        }
                        if (Risk != 0)
                        {
                            cloneEntity["rsa_risk"] = new OptionSetValue(Risk.Value);
                        }
                        if (source != 0)
                        {
                            cloneEntity["rsa_source"] = new OptionSetValue(source.Value);
                        }
                        if (typeOfRisk != null)
                        {
                            cloneEntity["rsa_typeofrisk"] = new EntityReference("rsa_typeofrisk", typeOfRisk.Id);
                        }
                        if (marineStamp != 0)
                        {
                            cloneEntity["rsa_marinestamp"] = new OptionSetValue(marineStamp.Value);
                        }
                        if (reinsuredName != null)
                        {
                            cloneEntity["rsa_reinsuredname"] = reinsuredName;
                        }
                        if (interest != null)
                        {
                            cloneEntity["rsa_interest"] = interest;
                        }
                        if (name != null)
                        {
                            cloneEntity["name"] = name;
                            tracer.Trace("Name :{0}", name);
                        }
                    }
                }
                if (pl != null)
                {
                    cloneEntity["rsa_pandlid"] = new EntityReference("rsa_pl", pl.Id);
                    tracer.Trace("P&L :{0}", pl.Name);
                }
                if (classOfBusiness != null)
                {
                    cloneEntity["rsa_classofbusiness"] = new EntityReference("rsa_classofbusiness", classOfBusiness.Id);
                    tracer.Trace("Class of Business :{0}", classOfBusiness.Name);
                }
                if (customer != null)
                {
                    cloneEntity["rsa_customer"] = new EntityReference("rsa_customer", customer.Id);
                }
                if (accountId != null)
                {
                    cloneEntity["parentaccountid"] = new EntityReference("account", accountId.Id);
                    tracer.Trace("Broker :{0}", accountId.Name);
                }
                if (region != 0)
                {
                    cloneEntity["rsa_region"] = new OptionSetValue(region.Value);
                }
                if (closeDate != null)
                {
                    //cloneEntity["rsa_closedate"] = closeDate.AddYears(1);
                }
                recordName = CommonUtility.GetLookUpDetailsbyText(service, "In View", "rsa_opportunitystage", Guid.Empty);
                cloneEntity["rsa_opportunitystage"] = new EntityReference("rsa_opportunitystage", recordName.Id);
                if (longTermAgreement != false)
                {
                    cloneEntity["rsa_longtermagreement"] = longTermAgreement;
                }
                if (DateLTAExpires != null)
                {
                    cloneEntity["rsa_contractdurationyears"] = DateLTAExpires;
                }
                if (policyCurrrencyPC != null)
                {
                    cloneEntity["rsa_currency"] = new EntityReference("transactioncurrency", policyCurrrencyPC.Id);
                }
                if (product != null)
                {
                    cloneEntity["rsa_productid"] = new EntityReference("rsa_product", product.Id);
                    tracer.Trace("Product :{0}", product.Name);
                }
                //if (name != null)
                //{
                //    cloneEntity["name"] = name;
                //    tracer.Trace("Name :{0}", name);
                //}

                service.Create(cloneEntity);
            }
            catch (Exception ex)
            {
                tracer.Trace("CreateOpportunityClone-Error" + ex.Message.ToString());
                throw new InvalidPluginExecutionException(ex.Message);

            }
        }


        /// <summary>
        /// This function Fetches the Policy details based on the Policy Number which is passed as a parameter.
        /// </summary>
        /// <param name="service"></param>
        /// <param name="policyNumbers"></param>
        /// <returns></returns>
        public static EntityCollection GetPolicyData(IOrganizationService service, ITracingService tracer, string policyNumbers)
        {
            try
            {
                string[] policyNumber = null;
                if (policyNumbers.Contains(";"))
                {
                    policyNumber = policyNumbers.Split(';');
                }
                string fetchQuery = "<fetch mapping='logical'>";
                fetchQuery += "<entity name = 'rsa_policy'>";
                fetchQuery += "<attribute name='rsa_policyid'/>";
                fetchQuery += "<attribute name = 'rsa_name'/>";
                fetchQuery += "<attribute name='createdon'/>";
                fetchQuery += "<attribute name = 'rsa_customer'/>";
                fetchQuery += "<attribute name='rsa_policysystemcode'/>";
                fetchQuery += "<attribute name = 'rsa_newpolicynumber'/>";
                fetchQuery += "<attribute name='rsa_broker'/>";
                fetchQuery += "<attribute name = 'rsa_policyrenewaldate'/>";
                fetchQuery += "<attribute name='rsa_plcode'/>";
                fetchQuery += "<attribute name = 'rsa_classofbusiness' />";
                fetchQuery += "<attribute name='rsa_policynumber'/>";
                fetchQuery += "<attribute name = 'rsa_premium' />";
                fetchQuery += "<filter type = 'and'> ";

                if (policyNumber != null && policyNumber.Length > 0)
                {
                    fetchQuery += "<filter type = 'or'> ";
                    for (int i = 0; i < policyNumber.Length; i++)
                    {
                        fetchQuery += "<condition attribute = 'rsa_name' operator= 'eq' value = '" + policyNumber[i] + "'/>";
                    }
                    fetchQuery += "</filter>";
                }
                else
                    fetchQuery += "<condition attribute = 'rsa_name' operator= 'eq' value = '" + policyNumbers + "'/>";

                fetchQuery += "</filter>";
                fetchQuery += "</entity>";
                fetchQuery += "</fetch>";
                EntityCollection policy = service.RetrieveMultiple(new FetchExpression(fetchQuery));
                tracer.Trace("No. Of Policies :{0}", policy.Entities.Count);
                return policy;
            }
            catch (Exception ex)
            {
                tracer.Trace("GetPolicyData-Error" + ex.Message.ToString());
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
        /// <summary>
        /// This function sets the task entity fields named activity Date, status, subject ,due date,owner,related to based on certain conditions. 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="entity"></param>
        /// <param name="context"></param>
        /// <param name="tracer"></param>
        /// <param name="newStageName"></param>
        /// <param name="oldStageName"></param>
        /// <param name="newCobName"></param>
        /// <param name="oldCobName"></param>
        internal void CreateTask(IOrganizationService service, Entity postImage, Entity preImage, ITracingService tracer, string newStageName, string oldStageName, string newCobName, string oldCobName, string lobName, DateTime? closeDate, EntityReference product,IExecutionContext context)
        {
            try
            {
                Entity tempTask = new Entity("task");
                string oldproductName = string.Empty;
                EntityReference oldProduct = preImage.Attributes.Contains("rsa_productid") ? preImage.GetAttributeValue<EntityReference>("rsa_productid") : null;
                if (oldProduct != null)
                {
                    var oldproducts = service.Retrieve(oldProduct.LogicalName, oldProduct.Id, new ColumnSet("rsa_name"));
                    oldproductName = oldproducts["rsa_name"].ToString();
                }
                tracer.Trace("t4");
                EntityReference Product = postImage.Attributes.Contains("rsa_productid") ? postImage.GetAttributeValue<EntityReference>("rsa_productid") : null;
                bool oldCreateCQEActivity = preImage.Attributes.Contains("rsa_createcqeactivity") ? preImage.GetAttributeValue<bool>("rsa_createcqeactivity") : false;
                bool createCQEActivity = postImage.Attributes.Contains("rsa_createcqeactivity") ? postImage.GetAttributeValue<bool>("rsa_createcqeactivity") : false;
                int oldexposuresApplicable = preImage.Attributes.Contains("rsa_exposures") ? preImage.GetAttributeValue<OptionSetValue>("rsa_exposures").Value : 0;
                EntityReference opportunityStage = postImage.Attributes.Contains("rsa_opportunitystage") ? postImage.GetAttributeValue<EntityReference>("rsa_opportunitystage") : null;
                EntityReference owner = postImage.Attributes.Contains("ownerid") ? postImage.GetAttributeValue<EntityReference>("ownerid") : null;
                EntityReference taskStatus = tempTask.Attributes.Contains("rsa_taskstatus") ? tempTask.GetAttributeValue<EntityReference>("rsa_taskstatus") : null;
                int exposuresApplicable = postImage.Attributes.Contains("rsa_exposures") ? postImage.GetAttributeValue<OptionSetValue>("rsa_exposures").Value : 0;
                int noOfDays = 0;
                string productName = string.Empty;
                if (product != null)
                {
                    var products = service.Retrieve(product.LogicalName, product.Id, new ColumnSet("rsa_name"));
                    productName = products["rsa_name"].ToString();
                }
                if (lobName.ToLowerInvariant().Contains("marine"))
                {
                    if (lobName.ToLowerInvariant().Contains("new business"))
                    {
                        if (lobName.ToLowerInvariant().Contains("regional"))
                        {
                            if (newStageName == "accepted" && newStageName != oldStageName)
                            {

                                tempTask = SetOpptyTaskFields(service, tracer, 10, "Process New Business Policy", postImage.Id, owner.Id, "In Progress", true, DateTime.Now);
                                tracer.Trace("Added Data to task fields");
                                if (closeDate != null)
                                {
                                    //TFS 335: Opportunity SLA Calculation || Modified on : 18.11.2022 || Samiksha Dhakde
                                    tempTask = SetOpptyTaskFields(service, tracer, 10, "Process New Business Policy", postImage.Id, owner.Id, "In Progress", true, (DateTime)closeDate);
                                   // tempTask["scheduledend"] = Convert.ToDateTime(closeDate).AddDays(10);
                                }
                                service.Create(tempTask);
                                tracer.Trace("New Task Created");
                            }
                        }
                        else if (lobName.ToLowerInvariant().Contains("london"))
                        {
                            if (newStageName == "accepted")
                            {
                                if (newStageName != oldStageName)
                                {
                                    noOfDays = DateTime.DaysInMonth(DateTime.Now.Year, DateTime.Now.Month);  //
                                    if (DateTime.Now.Day >= 1 && DateTime.Now.Day <= noOfDays - 7)
                                    {
                                        tempTask = SetOpptyTaskFields(service, tracer, 5, "Prepare Operations Data Entry Instruction", postImage.Id, owner.Id, "In Progress", false, DateTime.Now);
                                        tracer.Trace("Added Data to task fields");
                                        service.Create(tempTask);
                                        tracer.Trace("New Task Created");
                                    }
                                    else if (DateTime.Now.Day >= noOfDays - 6 && DateTime.Now.Day <= noOfDays)
                                    {
                                        tempTask = SetOpptyTaskFields(service, tracer, 1, "Prepare Operations Data Entry Instruction", postImage.Id, owner.Id, "In Progress", false, DateTime.Now);
                                        tracer.Trace("Added Data to task fields");
                                        service.Create(tempTask);
                                        tracer.Trace("New Task Created");
                                    }
                                }
                                if ((newStageName != oldStageName && oldCobName.ToLowerInvariant().Contains("lm cargo") && (productName.ToLowerInvariant().Contains("ilu cargo") || productName.ToLowerInvariant().Contains("ilu specie") || productName.ToLowerInvariant().Contains("lon cargo") || productName.ToLowerInvariant().Contains("lon specie")))
                                    ||
                                   (oldCobName.ToLowerInvariant().Contains("lm cargo") && (productName.ToLowerInvariant().Contains("ilu cargo") || productName.ToLowerInvariant().Contains("ilu specie") || productName.ToLowerInvariant().Contains("lon cargo") || productName.ToLowerInvariant().Contains("lon specie")) && newCobName != oldCobName)
                                   ||
                                   (oldCobName.ToLowerInvariant() == "lm cargo" && (productName.ToLowerInvariant() == "ilu cargo" || productName.ToLowerInvariant() == "ilu specie" || productName.ToLowerInvariant() == "lon cargo" || productName.ToLowerInvariant() == "lon specie") && productName != oldproductName && oldproductName.ToLowerInvariant() == "ilu cargo" && oldproductName.ToLowerInvariant() == "ilu specie"))
                                {
                                    tempTask = SetOpptyTaskFields(service, tracer, 3, "Work Up CQE Quote", postImage.Id, owner.Id, "Unassigned", false, DateTime.Now);
                                    tracer.Trace("Added Data to task fields");
                                    service.Create(tempTask);
                                    tracer.Trace("New Task Created");
                                }
                            }
                            if (createCQEActivity && !oldCreateCQEActivity)
                            {
                                tempTask = SetOpptyTaskFields(service, tracer, 1, "Work Up CQE Quote", postImage.Id, owner.Id, "Unassigned", false, DateTime.Now);
                                tracer.Trace("Added Data to task fields");
                                service.Create(tempTask);
                                tracer.Trace("New Task Created");
                            }
                            if ((exposuresApplicable == 866760000 && oldexposuresApplicable == 866760001 && newStageName.ToLowerInvariant() == "accepted") || (exposuresApplicable == 866760000 && newStageName == "accepted" && oldStageName != "accepted"))
                            {
                                tempTask = SetOpptyTaskFields(service, tracer, 3, "Process Exposures", postImage.Id, owner.Id, "Unassigned", false, DateTime.Now);
                                service.Create(tempTask);
                                tracer.Trace("New Task Created");
                            }
                        }
                    }
                    else if (lobName.ToLowerInvariant().Contains("renewal"))
                    {
                        if (lobName.ToLowerInvariant().Contains("regional"))
                        {
                            if (newStageName.ToLowerInvariant() == "renewed")
                            {
                                if (newStageName != oldStageName)
                                {
                                    var finalDate = new DateTime();
                                    if (closeDate != null)
                                    {
                                        finalDate = Convert.ToDateTime(closeDate).AddDays(20);
                                    }
                                    //TFS 335: Opportunity SLA Calculation || Modified on: 18.11.2022 || Samiksha Dhakde
                                    tempTask = SetOpptyTaskFields(service, tracer, 1, "Process Renewal", postImage.Id, owner.Id, "In Progress", true, DateTime.Now);
                                    tracer.Trace("Added Data to task fields");

                                    if (tempTask != null)
                                    {
                                        if (closeDate != null)
                                        {
                                            //TFS 335: Opportunity SLA Calculation || Modified on : 18.11.2022 || Samiksha Dhakde
                                            tempTask = SetOpptyTaskFields(service, tracer, 20, "Process Renewal", postImage.Id, owner.Id, "In Progress", true, (DateTime)closeDate);
                                            //tempTask["scheduledend"] = Convert.ToDateTime(closeDate).AddDays(20);
                                            //tempTask["rsa_duedatetime"] = Convert.ToDateTime(closeDate).AddDays(20);
                                        }
                                        service.Create(tempTask);
                                        tracer.Trace("New Task Created");
                                    }
                                }
                            }

                            if (newStageName == "lapsed")
                            {
                                if (newStageName != oldStageName)
                                {

                                    tempTask = SetOpptyTaskFields(service, tracer, 3, "Process Lapse", postImage.Id, owner.Id, "In Progress", true, DateTime.Now);
                                    service.Create(tempTask);
                                    tracer.Trace("New Task Created");
                                }
                            }
                            if (newStageName == "extended")
                            {
                                if (newStageName != oldStageName)
                                {
                                    tempTask = SetOpptyTaskFields(service, tracer, 1, "Process Extension", postImage.Id, owner.Id, "In Progress", true, DateTime.Now);
                                    service.Create(tempTask);
                                    tracer.Trace("New Task Created");
                                }
                            }
                        }
                        else if (lobName.ToLowerInvariant().Contains("london"))
                        {
                            Entity entityPostImage = (Entity)context.PostEntityImages["PostImage"];
                            
                            Entity UnassignedUser = getUser("Unassigned", service);
                            tracer.Trace("Record reterieved " + UnassignedUser.Id.ToString());
                            if (newStageName != oldStageName && entityPostImage.Attributes.Contains("rsa_opportunitystage") && exposuresApplicable != 866760000 && (newStageName == "renewed" || newStageName == "lapsed" || newStageName == "extended" || newStageName == "non – renewable"))
                            {
                                //if (newStageName.ToLowerInvariant() == "renewed")
                                //{
                                //    if ((newStageName != oldStageName && oldCobName.ToLowerInvariant() == "lm cargo" && (productName.ToLowerInvariant() == "ilu cargo") || productName.ToLowerInvariant() == "ilu specie")
                                //    ||
                                //      (oldCobName.ToLowerInvariant() == "lm cargo" && (productName.ToLowerInvariant() == "ilu cargo" || productName.ToLowerInvariant() == "ilu specie") && newCobName != oldCobName)
                                //      ||
                                //       (newCobName.ToLowerInvariant() == "lm cargo" && (productName.ToLowerInvariant() == "ilu cargo" || productName.ToLowerInvariant() == "ilu specie") && newCobName != oldCobName)
                                //        ||
                                //       (oldCobName.ToLowerInvariant() == "lm cargo" && (productName.ToLowerInvariant() == "ilu cargo" || productName.ToLowerInvariant() == "ilu specie") && productName != oldproductName && oldproductName.ToLowerInvariant() != "ilu cargo" && oldproductName.ToLowerInvariant() != "ilu specie"))
                                //    {
                                //        string TraceString = string.Empty;
                                //        // Ramesh : Added new task creation functionality for LONDON MARINE RENEWAL FLOW
                                //        if (lobName == "Renewal - Marine London")
                                //        {
                                //            tempTask = SetOpptyTaskFields(service, tracer, 3, "Work up CQE Renewal", postImage.Id, UnassignedUser.Id, "Unassigned");
                                //            TraceString = "New Task Created from 'LONDON MARINE RENEWAL'";
                                //        }
                                //        else
                                //        {
                                //            tempTask = SetOpptyTaskFields(service, tracer, 3, "Process Lapse", postImage.Id, owner.Id, "Unassigned");
                                //            TraceString = "New Task Created from 'Normal Flow'";
                                //        }
                                //        //  service.Create(tempTask);
                                //        tracer.Trace(TraceString);
                                //    }
                                //}
                                //if (newStageName != oldStageName && ((newStageName.ToLowerInvariant() == "renewed" && (oldCobName.ToLowerInvariant() != "lm cargo" || newCobName.ToLowerInvariant() != "lm cargo") && (productName.ToLowerInvariant() != "ilu cargo") || productName.ToLowerInvariant() != "ilu specie")
                                //    || newStageName == "lapsed" || newStageName == "extended" || newStageName == "non – renewable"))
                                //{
                                    noOfDays = DateTime.DaysInMonth(DateTime.Now.Year, DateTime.Now.Month);
                                    if (DateTime.Now.Day >= 1 && DateTime.Now.Day <= noOfDays - 7)
                                    {
                                        tempTask = SetOpptyTaskFields(service, tracer, 5, "Prepare Operations Data Entry Instruction", postImage.Id, owner.Id, "In Progress", false, DateTime.Now);
                                        tracer.Trace("Added Data to task fields");
                                        service.Create(tempTask);
                                        tracer.Trace("New Task Created");

                                    }
                                    else if (DateTime.Now.Day >= noOfDays - 6 && DateTime.Now.Day <= noOfDays)
                                    {
                                        tempTask = SetOpptyTaskFields(service, tracer, 1, "Prepare Operations Data Entry Instruction", postImage.Id, owner.Id, "In Progress", false, DateTime.Now);
                                        tracer.Trace("Added Data to task fields");
                                        service.Create(tempTask);
                                        tracer.Trace("New Task Created");
                                    }
                               // }
                            }
                            if (createCQEActivity && !oldCreateCQEActivity)
                            {
                                // tempTask = SetOpptyTaskFields(service, tracer, 5, "Work Up CQE Quote", postImage.Id, owner.Id, "Unassigned");
                                tempTask = SetOpptyTaskFields(service, tracer, 5, "Work Up CQE Renewal", postImage.Id, owner.Id, "Unassigned", false, DateTime.Now);
                                service.Create(tempTask);
                                tracer.Trace("New Task Created");
                            }
                            if (entityPostImage.Attributes.Contains("rsa_exposures") && (exposuresApplicable != oldexposuresApplicable)&&
                                ((exposuresApplicable == 866760000 && oldexposuresApplicable == 866760001&& newStageName.ToLowerInvariant() == "renewed")|| (exposuresApplicable == 866760000 
                                && newStageName.ToLowerInvariant() == "renewed" && oldStageName.ToLowerInvariant() == "renewed")))
                            {
                                // Ramesh : Added new task creation functionality for LONDON MARINE RENEWAL FLOW
                                string TraceString = string.Empty;
                                //if (lobName == "Renewal - Marine London")
                                //{
                                    tempTask = SetOpptyTaskFields(service, tracer, 3, "Process Exposures", postImage.Id, UnassignedUser.Id, "Unassigned", false, DateTime.Now);
                                    TraceString = "New Task Created from 'LONDON MARINE RENEWAL'";
                                //}
                               
                                   // tempTask = SetOpptyTaskFields(service, tracer, 3, "Process Exposures", postImage.Id, owner.Id, "Unassigned");
                                   // TraceString = "New Task Created from 'Normal flow'";
                                
                                tracer.Trace("Added Data to task fields");
                                service.Create(tempTask);
                                tracer.Trace(TraceString);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                tracer.Trace("setTaskFields-Error" + ex.Message.ToString());
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        /// <summary>
        /// This function simply sets the Task entity fields named activity date, due date, status,subject,owner and related to with corresponding opportunity fields.
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracer"></param>
        /// <param name="numberOfDays"></param>
        /// <param name="taskSubject"></param>
        /// <param name="activityWhatId"></param>
        /// <param name="activityOwner_ID"></param>
        /// <param name="activityStatus"></param>
        /// <returns></returns>
        static Entity SetOpptyTaskFields(IOrganizationService service, ITracingService tracer, int numberOfDays, string taskSubject, Guid activityWhatId, Guid activityOwner_ID, string activityStatus, bool isHolidayApplicable, DateTime taskstartDate)
        {
            try
            {
                //TFS 335: Opportunity SLA Calculation || Modified on : 18.11.2022 || Samiksha Dhakde
                DateTime finalEndDate = DateTime.Now;
                Entity entempTasks = new Entity("task");
                entempTasks["rsa_tasktype"] = new EntityReference("rsa_activitytype", CommonUtility.GetLookUpDetailsbyText(service, "MARINE_NEW_RENEWAL", "rsa_activitytype", Guid.Empty).Id); 
                if (isHolidayApplicable)
                {
                    DateTime startDate = taskstartDate;                  
                    DateTime endDate = startDate.AddDays(numberOfDays);
                    List<Entity> calendarRules = new List<Entity>();
                    Entity businessClosureCalendar = null;
                    QueryExpression holidayQuery = new QueryExpression("calendar") { NoLock = true };
                    holidayQuery.Criteria.AddCondition("type", ConditionOperator.Equal, 2);
                    EntityCollection businessClosureCalendars = service.RetrieveMultiple(holidayQuery);
                    businessClosureCalendar = businessClosureCalendars.Entities[0];
                    calendarRules = (businessClosureCalendar.GetAttributeValue<EntityCollection>("calendarrules")).Entities.ToList();
                    List<DateTime> orholidays = calendarRules.Select(rule => rule.GetAttributeValue<DateTime>("starttime")).Where(date => date >= startDate.Date && date <= endDate.Date).ToList();
                    tracer.Trace("1st iteration Number of Days : " + numberOfDays);
                    tracer.Trace("EndDate after adding number of Days: " + endDate);
                    tracer.Trace("Holiday count between "+ startDate+" and "+ endDate+ " = " + orholidays.Count);
                    int difCount = 0;
                    int temp = orholidays.Count;
                    endDate = endDate.AddDays(temp);
                    List<DateTime> difholidays = calendarRules.Select(rule => rule.GetAttributeValue<DateTime>("starttime")).Where(date => date >= startDate.Date && date <= endDate.Date).ToList();
                    do
                    {
                        tracer.Trace("Entered do while loop ");
                        difCount = difholidays.Count;
                        endDate = endDate.AddDays(difCount - temp);
                        tracer.Trace("Do while EndDate: " + endDate);
                        numberOfDays = (endDate - startDate).Days;
                        tracer.Trace("Do while numberOfDays: " + numberOfDays);
                        finalEndDate = calculateBusinessHours(service, tracer, numberOfDays, taskstartDate).Date;
                        tracer.Trace("Do while finalEndDate: " + finalEndDate.Date);
                        temp = difCount;
                        difholidays = calendarRules.Select(rule => rule.GetAttributeValue<DateTime>("starttime")).Where(date => date >= startDate.Date && date <= finalEndDate.Date).ToList();
                        tracer.Trace("Do while difholidays / difcount: " + difholidays.Count + "Do while temp: " + temp);

                    } while (temp != difholidays.Count);

                    tracer.Trace("Exit do while loop ");
                    tracer.Trace("Final Number of Days: " + numberOfDays);  
                   
                }
                tracer.Trace("Final Due Date Time is : " + finalEndDate);
                //throw new InvalidPluginExecutionException();
                entempTasks["scheduledend"] = finalEndDate.Date;
                entempTasks["rsa_duedatetime"] = finalEndDate;
                //entempTasks["scheduledend"] = calculateBusinessHours(service, tracer, numberOfDays, taskstartDate).Date;
               //  tracer.Trace("Activity Date :{0}", CalculateBusinessHours(service, tracer, numberOfDays).Date);
               // entempTasks["rsa_duedatetime"] = calculateBusinessHours(service, tracer, numberOfDays, taskstartDate).Date;
                //tracer.Trace("Due Date :{0}", CalculateBusinessHours(service, tracer, numberOfDays));
                entempTasks["subject"] = taskSubject;
                tracer.Trace("Subject :{0}", taskSubject);
                entempTasks["regardingobjectid"] = new EntityReference("opportunity", activityWhatId);
                entempTasks["rsa_opportunitytotaskid"] = new EntityReference("opportunity", activityWhatId);
                entempTasks["ownerid"] = new EntityReference("systemuser", activityOwner_ID); //changes done
                if(taskSubject == "Process Exposures" || taskSubject == "Work up CQE Renewal")//Unass
                {
                    entempTasks["rsa_status"] = new OptionSetValue(866760016);
                }
                //TFS 335: Task Status update for tasksubject: Process New business policy || Modified on : 18.11.2022 || Samiksha Dhakde
                if (taskSubject == "Prepare Operations Data Entry Instruction" || taskSubject == "Process Renewal" 
                    || taskSubject == "Process Lapse" || taskSubject == "Process Extension" || taskSubject ==  "Process New Business Policy")
                {
                    entempTasks["rsa_status"] = new OptionSetValue(866760001);
                }
                entempTasks["rsa_taskstatus"] = new EntityReference("rsa_taskstatus", CommonUtility.GetLookUpDetailsbyText(service, activityStatus, "rsa_taskstatus", Guid.Empty).Id);
                tracer.Trace("Data added to task fields");
                return entempTasks;
            }
            catch (Exception ex)
            {
                tracer.Trace("setOpptyTaskFields-Error" + ex.Message.ToString());
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
        /// <summary>
        /// This function is used to calculate the number of business Hours
        /// </summary>
        /// <param name="service"></param>
        /// <param name="numberOfDays"></param>
        /// <returns></returns>


        static DateTime CalculateBusinessHours(IOrganizationService service, ITracingService tracer, int numberOfDays)
        {
            try
            {
                DateTime now = DateTime.Now;
                DateTime endDate = now.AddDays(numberOfDays);
                DayOfWeek endDate_Today = endDate.DayOfWeek;
                DayOfWeek now_Today = now.DayOfWeek;
                int count = 0;
                //DateTime d1 = now.Date;
                //DateTime d2 = endDate.Date;

                int wday = numberOfDays;
                int addedDays = 0;
                if (endDate_Today == DayOfWeek.Saturday)
                {
                    endDate = endDate.AddDays(2);
                    addedDays = 2;
                }
                if (endDate_Today == DayOfWeek.Sunday)
                {
                    endDate = endDate.AddDays(1);
                    addedDays = 1;
                }
                do
                {
                    if (now_Today == DayOfWeek.Saturday)
                    {
                        count++;
                    }
                    if (now_Today == DayOfWeek.Sunday)
                    {
                        count++;
                    }
                    now = now.AddDays(1);
                }
                while (now < endDate);
                endDate = endDate.AddDays(count - addedDays);
                tracer.Trace("endDate :{0}", endDate);
                return endDate;
            }
            catch (Exception ex)
            {
                tracer.Trace("CalculateBusinessHours-Error" + ex.Message.ToString());
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
        public static DateTime calculateBusinessHours(IOrganizationService service, ITracingService tracer, int numberOfDays, DateTime taskStartDate)
        {
            DateTime now = taskStartDate;
            DateTime endDate = now.AddDays(numberOfDays);
            tracer.Trace("EndDate just after "+numberOfDays+" adding days : " + endDate);
            DayOfWeek endDate_Today = endDate.DayOfWeek;
            tracer.Trace("End Date.Dayofweek: " + endDate_Today);
            int count = 0;
            //DateTime d1 = DateTime.valueOf(now);
            //DateTime d2 = Date.valueOf(endDate);
            int wDay = numberOfDays;
            int addedDays = 0;
            //if (endDate.GetDateTimeFormats('EEEE') == 'Saturday')
            //{
            //    endDate = endDate.addDays(2);
            //    addedDays = 2;
            //}
            //if (endDate.format('EEEE') == 'Sunday')
            //{
            //    endDate = endDate.addDays(1);
            //    addedDays = 1;
            //}

            if (endDate_Today == DayOfWeek.Saturday)
            {
                endDate = endDate.AddDays(2);
                addedDays = 2;
            }
            if (endDate_Today == DayOfWeek.Sunday)
            {
                endDate = endDate.AddDays(1);
                addedDays = 1;
            }
            do
            {
                if (now.DayOfWeek == DayOfWeek.Saturday)
                {
                    count++;
                }
                if (now.DayOfWeek == DayOfWeek.Sunday)
                {
                    count++;
                }
                now = now.AddDays(1);
            } while (now < endDate);
            //TFS 335: Opportunity SLA Calculation || Modified on : 18.11.2022 || Samiksha Dhakde
            int countDays = count - addedDays;
           
            tracer.Trace("Weekend count: " + count + " EndDate Weeekend addedDays: " + addedDays + " TotalDays added to end  date = " + countDays);
            while(countDays > 0)
            {
                endDate = endDate.AddDays(1);               
                if((endDate.DayOfWeek != DayOfWeek.Saturday) && (endDate.DayOfWeek != DayOfWeek.Sunday))
                {       
                    countDays--;                   
                }
                tracer.Trace("Countdays " + countDays);
            } 
            //endDate = endDate.AddDays(businessdays + weekends);

            tracer.Trace("End Date after Calculating business hours: " + endDate);
            /*if(endDate.format('EEEE') == 'Saturday')
            {
                endDate = endDate.addDays(2);
            }
            if(endDate.format('EEEE') == 'Sunday')
            {
                endDate = endDate.addDays(1);
            }*/

            return endDate;

        }
        public string getFormID(IOrganizationService service, ITracingService tracer, Entity entity)
        {
            string formID = string.Empty;
            EntityReference lob = entity.GetAttributeValue<EntityReference>("rsa_lineofbusiness");
            var fetchXmlQuery = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
    "<entity name='rsa_formlayoutmapping'>" +
    "<attribute name='rsa_formlayoutmappingid' />" +
    "<attribute name='rsa_name' />" +
    "<attribute name='rsa_lineofbusiness' />" +
    "<attribute name='rsa_form' />" +
    "<order attribute='rsa_name' descending='false' />" +
    "<filter type='and'>" +
    "<condition attribute='rsa_lineofbusiness' operator='eq' value= '" + lob.Id + "'/>" +
    "</filter>" +
    "<link-entity name='rsa_formlayout' from='rsa_formlayoutid' to='rsa_form' link-type='inner' alias='ae'>" +
    "<attribute name='rsa_formid'/>" +
    "<filter type='and'>" +
    "<condition attribute='rsa_entityname' operator='eq' value='866760000' />" +
    "</filter>" +
    "</link-entity>" +
    "</entity>" +
    "</fetch>";
            tracer.Trace("FetchXML Query : {0}", fetchXmlQuery);
            EntityCollection formLayoutMapping = service.RetrieveMultiple(new FetchExpression(fetchXmlQuery));
            tracer.Trace("Count of Formlayouts: {0}", formLayoutMapping.Entities.Count);
            if (formLayoutMapping.Entities.Count > 0)
            {
                foreach (var formLayout in formLayoutMapping.Entities)
                {
                    formID = Convert.ToString(((AliasedValue)formLayout.Attributes["ae.rsa_formid"]).Value);
                    tracer.Trace("FormID : {0}", formID);
                    break;
                }
            }

            return formID;
        }
        public static Entity getUser(string name, IOrganizationService service)
        {
            try
            {
                var recordName = new Entity();
                QueryExpression query = new QueryExpression("systemuser");
                query.ColumnSet = new ColumnSet(new string[] { "firstname" });

                query.Criteria.AddCondition("firstname", ConditionOperator.Equal, name);
                query.NoLock = true;
                EntityCollection businessRecordTypes = service.RetrieveMultiple(query);
                if (businessRecordTypes != null && businessRecordTypes.Entities.Count > 0)
                {
                    recordName = businessRecordTypes.Entities[0];
                }
                return recordName;
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
    }
}