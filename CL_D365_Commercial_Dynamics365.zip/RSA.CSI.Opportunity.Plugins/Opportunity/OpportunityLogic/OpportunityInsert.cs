﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;

namespace RSA.CSI.Plugins.OpportunityLogic
{
   public class OpportunityInsert
    {
        /// <summary>
        /// This function fetches field data for agency code entity with respect to Broker Id.
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracer"></param>
        /// <param name="agencyId"></param>
        /// <returns></returns>
        public static Entity GetAgencyCodebyBrokerId(IOrganizationService service, ITracingService tracer ,Guid agencyId)
        {
            var agencyCode = new Entity();
            try
            {
                string fetchQuery = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>";
                fetchQuery += "<entity name = 'rsa_agencycode'>";
                fetchQuery += "<attribute name = 'rsa_agencycodeid'/>";
                fetchQuery += "<attribute name = 'rsa_name'/>";
                fetchQuery += "<attribute name = 'rsa_policysystem'/>";
                fetchQuery += "<attribute name = 'rsa_agencyreference'/>";
                fetchQuery += "<attribute name = 'rsa_agencycodekey'/>";
                fetchQuery += "<attribute name = 'rsa_agency'/>";
                fetchQuery += "<filter type = 'and'> ";
                fetchQuery += "<condition attribute = 'rsa_agency' operator= 'eq' value = '" + agencyId + "'/>";
                fetchQuery += "</filter>";
                fetchQuery += "</entity>";
                fetchQuery += "</fetch>";
                tracer.Trace("Fetch XML Data : {0}", fetchQuery);
  
                EntityCollection agencyCodes = service.RetrieveMultiple(new FetchExpression(fetchQuery));
                if (agencyCodes != null && agencyCodes.Entities.Count > 0) {
                        agencyCode = agencyCodes.Entities[0];
                        tracer.Trace("Agencycode Data : {0}", agencyCode);
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);             

            }
            return agencyCode;
        }
    }
}
