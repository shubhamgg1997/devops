﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using RSA.CSI.Plugins.Utility;


namespace RSA.CSI.Plugins.OpportunityLogic
{
    public class TriggerOperations
    {
        /// <summary>
        /// This function updates the exchange rate and exchange Id field on opportunity entity.
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracer"></param>
        /// <param name="entity"></param>
        /// <param name="oppCurrency"></param>
        /// <param name="exLimitCurrencyELC"></param>
        internal void UpdateExchangeRateOnOppty(IOrganizationService service, ITracingService tracer, Entity entity, EntityReference lineofBusiness, string currencyName, string currencyNameELC, Guid currencyID , Guid ELCcurrencyID)
        {
            tracer.Trace("currencyName:" + currencyName);
            tracer.Trace("currencyNameELC:" + currencyNameELC);
            string conversionIdsSet = string.Empty;
            string recordTypeNames = string.Empty;
            string[] recordTypeName = null;
            Dictionary<string, Entity> my_Dict = new Dictionary<string, Entity>();
            EntityCollection customLabels = CommonUtility.GetCutomLabelDetails(service, "Conversion_ID_Currency", "Page_Layouts_supporting_To_GBP_conversion", string.Empty);
            if (customLabels.Entities.Count > 0)
            {
                foreach (var objCustomLabel in customLabels.Entities)
                {
                    string customLabelName = objCustomLabel.GetAttributeValue<string>("rsa_name");
                    if (customLabelName == "Conversion_ID_Currency")
                    {
                        conversionIdsSet = objCustomLabel.Attributes.Contains("rsa_values") ? objCustomLabel.GetAttributeValue<string>("rsa_values") : string.Empty; //gbp
                    }

                    if (customLabelName == "Page_Layouts_supporting_To_GBP_conversion")
                    {
                        recordTypeNames = objCustomLabel.Attributes.Contains("rsa_values") ? objCustomLabel.GetAttributeValue<string>("rsa_values") : string.Empty;
                        if (recordTypeNames.Contains(";"))
                            recordTypeName = recordTypeNames.Split(';'); //??
                    }
                }
                EntityCollection ELCexchangeRates = null;
                if (recordTypeName != null && recordTypeName.Length > 0)
                {
                    EntityCollection exchangeRates = CommonUtility.GetExchangeRates(service, conversionIdsSet, currencyID);
                    if (ELCcurrencyID != Guid.Empty) {
                        ELCexchangeRates = CommonUtility.GetExchangeRates(service, conversionIdsSet, ELCcurrencyID);
                    }
                    tracer.Trace("Exchange Rate Count:{0}", exchangeRates.Entities.Count);
                   // tracer.Trace("ELC Exchange Rate Count:{0}", ELCexchangeRates.Entities.Count);
                    for (int i = 0; i <= (recordTypeName.Length) - 1; i++)
                    {
                        Guid lobID = CommonUtility.GetLookUpDetailsbyText(service, recordTypeName[i], "rsa_lineofbusiness", Guid.Empty).Id;
                        if (lineofBusiness != null && lineofBusiness.Id == lobID)
                        {
                            if (exchangeRates.Entities.Count > 0)
                            {
                                foreach (var exrate in exchangeRates.Entities)
                                {
                                    EntityReference exrCurrency = exrate.GetAttributeValue<EntityReference>("rsa_currencyid");
                                    tracer.Trace("exrCurrency:" + exrCurrency.Name);
                                    if (currencyName.ToLowerInvariant() == exrCurrency.Name.ToLowerInvariant() || currencyNameELC.ToLowerInvariant() == exrCurrency.Name.ToLowerInvariant())
                                    {
                                        decimal exRates = exrate.Attributes.Contains("rsa_rate") ? exrate.GetAttributeValue<decimal>("rsa_rate") : 0;
                                        tracer.Trace("exRates:"+ exRates);
                                        if (exrCurrency.Name != null && exRates != 0 && !string.IsNullOrEmpty(currencyName) && currencyName.ToLowerInvariant() == exrCurrency.Name.ToLowerInvariant())
                                        {
                                            tracer.Trace("Exchange line 67");
                                            entity["rsa_exchangerate"] = exrate.GetAttributeValue<decimal>("rsa_rate");
                                            //entity["rsa_exchangeid"] = exrate.Id;
                                        }
                                       
                                    }
                                }
                            }
                            #region exchange rate ELC
                            if (ELCexchangeRates != null && ELCexchangeRates.Entities.Count > 0)
                            {
                                tracer.Trace("Insde Exchange Rate ELC ");
                                foreach (var exrate in ELCexchangeRates.Entities)
                                {
                                    EntityReference exrCurrency = exrate.GetAttributeValue<EntityReference>("rsa_currencyid");
                                    tracer.Trace("exrCurrency:" + exrCurrency.Name);
                                    if (currencyNameELC.ToLowerInvariant() == exrCurrency.Name.ToLowerInvariant()  &&!string.IsNullOrEmpty(currencyNameELC))
                                    {
                                        decimal exRates = exrate.Attributes.Contains("rsa_rate") ? exrate.GetAttributeValue<decimal>("rsa_rate") : 0;
                                        tracer.Trace("exRates:" + exRates);
                                        if (exrCurrency.Name != null && exRates != 0 && !string.IsNullOrEmpty(currencyNameELC) && currencyNameELC.ToLowerInvariant() == exrCurrency.Name.ToLowerInvariant())
                                        {
                                            entity["rsa_exchangerateelc"] = exrate.GetAttributeValue<decimal>("rsa_rate");
                                            tracer.Trace("Exchange Rate ELC is updated" + entity["rsa_exchangerateelc"]);
                                        }

                                    }
                                }
                            }
                            else
                            {
                                entity["rsa_exchangerateelc"] = null;
                            }
                            #endregion


                        }
                    }
                }
            }
        }
        /// <summary>
        /// This function updates the Period of Insurance field on opportunity entity...
        /// </summary>
        /// <param name="tracer"></param>
        /// <param name="entity"></param>
        internal void UpdateGBPvaluesOnOppty(ITracingService tracer, Entity entity, DateTime expiryDateMarine, DateTime closeDate)
        {
            try
            {
                if (closeDate != DateTime.MinValue && expiryDateMarine != DateTime.MinValue)
                    tracer.Trace("find out the dates.");
                entity["rsa_periodofinsurancemonths"] = GetMonthsBetween(closeDate, tracer, expiryDateMarine);
            }
            catch (Exception ex)
            {
                tracer.Trace("UpdateGBPvaluesOnOppty-Error" + ex.Message.ToString());
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
        /// <summary>
        /// This function updates rsa_aisagencycode,rsa_risksolutionsagencycode,rsa_ukrisagencycode,rsa_siclopsagencycode,rsa_epoqagencycode and rsa_synergyagencycode fields with respect to policy system field 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="entity"></param>
        /// <param name="tracer"></param>
        internal void UpdateAgencyCodesOnOpportunity(IPluginExecutionContext context, IOrganizationService service, ITracingService tracer, Entity entity, EntityReference broker)
        {
            try
            {
                if (broker != null)
                {
                    Entity OpptyExtension = new Entity("rsa_extensionopportunity");
                    EntityReference opportunityextensionid = entity.Attributes.Contains("rsa_opportunityextensionid") ? entity.GetAttributeValue<EntityReference>("rsa_opportunityextensionid") : null;
                    if (opportunityextensionid!=null) { OpptyExtension.Id = opportunityextensionid.Id; }
                    var agencyCode = OpportunityInsert.GetAgencyCodebyBrokerId(service, tracer, broker.Id);
                    if (agencyCode != null)
                    {
                        if (agencyCode.Attributes.Contains("rsa_agency") && agencyCode.Attributes.Contains("rsa_policysystem"))
                        {
                            string policySystem = agencyCode.Attributes.ContainsKey("rsa_policysystem") ? agencyCode.FormattedValues["rsa_policysystem"] : string.Empty;
                            tracer.Trace("policy system:{0}", policySystem);
                            string name = agencyCode.Attributes.Contains("rsa_name") ? agencyCode.GetAttributeValue<string>("rsa_name") : string.Empty;
                            if (!string.IsNullOrEmpty(name))
                            {
                                if (policySystem == "AIS")
                                {
                                    OpptyExtension["rsa_aisagencycode"] = name;
                                }
                                else if (policySystem == "Risk Solutions")
                                {
                                    OpptyExtension["rsa_risksolutionsagencycode"] = name;
                                }
                                else if (policySystem == "UKRIS")
                                {
                                    tracer.Trace("rsa_ukrisagencycode policySystem == UKRIS");
                                    OpptyExtension["rsa_ukrisagencycode"] = name;
                                }
                                else if (policySystem == "SICS")
                                {
                                    OpptyExtension["rsa_siclopsagencycode"] = name;
                                }
                                else if (policySystem == "EPOQ")
                                {
                                    OpptyExtension["rsa_epoqagencycode"] = name;
                                }
                                else if (policySystem == "SICLOPS")
                                {
                                    OpptyExtension["rsa_siclopsagencycode"] = name;
                                }
                                else if (policySystem == "Synergy")
                                {
                                    OpptyExtension["rsa_synergyagencycode"] = name;
                                }
                                tracer.Trace("fields updated successfully");
                            }
                        }
                        if (context.MessageName.ToLowerInvariant() == "update" && opportunityextensionid!=null)
                            service.Update(OpptyExtension);
                    }
                }
            }
            catch (Exception ex)
            {
                tracer.Trace("UpdateAgencyCodesOnOpportunity-Error" + ex.Message.ToString());
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
        /// <summary>
        /// This function updates the owner field on renewal opportunity
        /// </summary>
        /// <param name="service"></param>
        /// <param name="entity"></param>
        /// <param name="tracer"></param>
        /// <param name="lobName"></param>
        internal void UpdateOwnerOnRenewalOppty(IOrganizationService service, Entity entity, ITracingService tracer, string lobName)
        {
            try
            {
                var customSettings = CommonUtility.GetCustomSettingsbyName(service, "Marine_Renewal_Opportunity");
                tracer.Trace("custom Settings:{0}", customSettings.Entities.Count);
                if (customSettings.Entities.Count > 0)
                {
                    foreach (var csentity in customSettings.Entities)
                    {
                        string csLobName = csentity.Attributes.Contains("rsa_recordtypename") ? csentity.GetAttributeValue<string>("rsa_recordtypename") : string.Empty;
                        if (lobName.ToLowerInvariant() == csLobName.ToLowerInvariant())
                        {
                            string region = csentity.Attributes.Contains("rsa_region") ? csentity.GetAttributeValue<string>("rsa_region") : string.Empty;
                            tracer.Trace("Region:{0},", region);
                            string oppRegion = entity.FormattedValues.ContainsKey("rsa_region") ? entity.FormattedValues["rsa_region"] : string.Empty;

                            string cob = csentity.Attributes.Contains("rsa_class_of_business") ? csentity.GetAttributeValue<string>("rsa_class_of_business") : string.Empty;
                            EntityReference oppCob = entity.Attributes.Contains("rsa_classofbusiness") ? entity.GetAttributeValue<EntityReference>("rsa_classofbusiness") : null;
                            string cobName = string.Empty;
                            if (oppCob != null)
                            {
                                var cobDetails = service.Retrieve(oppCob.LogicalName, oppCob.Id, new ColumnSet("rsa_name"));
                                cobName = cobDetails["rsa_name"].ToString();
                            }
                            string activityOwnerId = csentity.Attributes.Contains("rsa_opportunityownerid") ? csentity.GetAttributeValue<string>("rsa_opportunityownerid") : string.Empty;

                            if (!string.IsNullOrEmpty(region) && region.ToLowerInvariant() == oppRegion.ToLowerInvariant())
                            {
                                if (string.IsNullOrEmpty(cob))
                                {
                                    if (!string.IsNullOrEmpty(activityOwnerId))
                                    {
                                        //entity["ownerid"] = new EntityReference("systemuser", new Guid(activityOwnerId));
                                    }
                                }
                                if (cob != null && cob.ToLowerInvariant() == cobName.ToLowerInvariant())
                                {
                                    //entity["ownerid"] = new EntityReference("systemuser", new Guid(activityOwnerId));
                                }
                            }
                            if (string.IsNullOrEmpty(region))
                            {
                                if (cob != null && cob.ToLowerInvariant() == cobName.ToLowerInvariant())
                                {
                                    //entity["ownerid"] = new EntityReference("systemuser", new Guid(activityOwnerId));
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                tracer.Trace("UpdateOwnerOnRenewalOppty-Error" + ex.Message.ToString());
                throw new InvalidPluginExecutionException(ex.Message);
            }

        }


        /// <summary>
        /// ////////////////// by sujeet//////////////////
        /// </summary>
        /// <param name="service"></param>
        /// <param name="entity"></param>
        /// <param name="tracer"></param>
        /// <param name="lobName"></param>
        internal void updateGBPFields(IPluginExecutionContext context, IOrganizationService service, Entity target, Entity entity, Entity preImage, ITracingService tracer, int customtype)//entity=postImage
        {
            try
            {

                if (target == null) { target = entity; }
                if (preImage == null)
                {
                    preImage = entity;
                }
                Entity OpptyExtension = null, enOpportunityExtension = null;
                decimal check = entity.GetAttributeValue<decimal>("rsa_brokertargetpremiumpc");
                
                if (context.MessageName.Equals("Update"))
                {
                    Guid opportunityId = context.PrimaryEntityId;
                    EntityCollection opportunityExtensionCol = CommonUtility.GetOpportunityExtension(service, opportunityId);
                    if (opportunityExtensionCol.Entities.Count > 0)
                    {
                        tracer.Trace("OpportunityExtention retrived, Count:{0} ", opportunityExtensionCol.Entities.Count);
                        enOpportunityExtension = new Entity("rsa_extensionopportunity");
                        enOpportunityExtension.Id = opportunityExtensionCol.Entities[0].Id;
                    }

                    EntityReference exOppty = entity.Attributes.Contains("rsa_opportunityextensionid") ? entity.GetAttributeValue<EntityReference>("rsa_opportunityextensionid") : null;
                    if (exOppty != null)
                    {
                        OpptyExtension = service.Retrieve(exOppty.LogicalName, exOppty.Id, new ColumnSet("rsa_annualaggregatedeductionelcgbp", "rsa_annualaggregatedeductionelcpc", "rsa_excesselcgbp", "rsa_excesselcpc", "rsa_limitelcgbp", "rsa_limitelc", "rsa_feesadditionaltopremiumelcgbp", "rsa_feesadditionaltopremiumelcpc", "rsa_settlementauthorityelcgbp", "rsa_settlementauthorityelc", "rsa_anyonetransitgbp", "rsa_anyonetransit", "rsa_anyonelossgbp", "rsa_anyoneloss", "rsa_annualaggquakefloodwindstormgbp", "rsa_annualaggregrateforquakefloodwind"));

                    }
                }
                var customSettings = OpportunityUpdate.GetCustomSettingsbytype(service, tracer, 866760027);
                tracer.Trace("custom Settings:{0}", customSettings.Entities.Count);//39
                if (customSettings.Entities.Count > 0)
                {

                    foreach (var csentity in customSettings.Entities)
                    {
                        tracer.Trace(csentity.Attributes.Contains("rsa_formulatype") ? "1" : "0");
                        string formulaType = csentity.Attributes.Contains("rsa_formulatype") ? csentity.GetAttributeValue<string>("rsa_formulatype") : string.Empty;//to check
                        tracer.Trace("formulaType" + formulaType);
                        string PCorELC = csentity.Attributes.Contains("rsa_pcelc") ? csentity.GetAttributeValue<string>("rsa_pcelc") : string.Empty;//to check
                        tracer.Trace("PCorELC:" + PCorELC);
                        decimal opptyExchangeRate = 0.00m;
                        decimal opptyExchangeRateELC = 0.00m;

                        //entity=oppty
                        string formuladescription = csentity.Attributes.Contains("rsa_formuladescription") ? csentity.GetAttributeValue<string>("rsa_formuladescription") : string.Empty;//to check
                        if (formulaType.Contains("Currency_Convert") && PCorELC.Contains("PC") && !string.IsNullOrEmpty(formuladescription))//to check
                        {
                            string gbpCurrencyField = csentity.Attributes.Contains("rsa_gbpcurrencyfield") ? csentity.GetAttributeValue<string>("rsa_gbpcurrencyfield") : string.Empty;
                            tracer.Trace("gbpCurrencyField:" + gbpCurrencyField);
                            string policyCurrencyPCField = csentity.Attributes.Contains("rsa_policycurrencypcfield") ? csentity.GetAttributeValue<string>("rsa_policycurrencypcfield") : string.Empty;
                            tracer.Trace("policyCurrencyPCField:" + policyCurrencyPCField);
                            string[] dataTypesplitgbp = gbpCurrencyField.Split('|');
                            tracer.Trace("dataTypesplitgbp" + dataTypesplitgbp[0] + dataTypesplitgbp[1]);
                            string[] dataTypesplitpc = policyCurrencyPCField.Split('|');
                            tracer.Trace("dataTypesplitpc" + dataTypesplitpc[0] + dataTypesplitpc[1]);
                            decimal opptyFieldPC = 0.00m;
                            // decimal opptyFieldGBP = 0.00m;

                            if (entity.Attributes.Contains(dataTypesplitpc[0]))
                            {
                                if (dataTypesplitpc[1].ToLower().Equals("money"))
                                {
                                    Money opptyFieldPCmoney = entity.Attributes.Contains(dataTypesplitpc[0]) ? entity.GetAttributeValue<Money>(dataTypesplitpc[0]) : null;
                                    if (opptyFieldPCmoney != null)
                                    {
                                        opptyFieldPC = opptyFieldPCmoney.Value;
                                        tracer.Trace("opptyFieldPC:" + opptyFieldPC);
                                    }
                                }
                                else if (dataTypesplitpc[1].ToLower().Equals("decimal"))
                                {
                                    opptyFieldPC = entity.Attributes.Contains(dataTypesplitpc[0]) ? entity.GetAttributeValue<decimal>(dataTypesplitpc[0]) : 00m;

                                    tracer.Trace("opptyFieldPCDecimalpostimage :" + opptyFieldPC);
                                }



                            }
                            if (entity.Attributes.Contains("rsa_exchangerate") || entity.Attributes.Contains("rsa_exchangerategslc"))
                            {
                                opptyExchangeRate = entity.GetAttributeValue<decimal>("rsa_exchangerate");
                                tracer.Trace("rsa_exchangerate:" + opptyExchangeRate);
                                opptyExchangeRateELC = entity.Attributes.Contains("rsa_exchangerategslc") ? entity.GetAttributeValue<decimal>("rsa_exchangerategslc") : 0.00m;
                                tracer.Trace("opptyExchangeRateELC:" + opptyExchangeRateELC);
                            }
                            if (opptyFieldPC == 0.00m)
                            {
                                if (dataTypesplitgbp[1].ToLower().Equals("money"))
                                {
                                    entity[dataTypesplitgbp[0]] = new Money(0.00m);
                                }
                                else if (dataTypesplitgbp[1].ToLower().Equals("decimal"))
                                {
                                    entity[dataTypesplitgbp[0]] = 0.00m;

                                }
                            }
                            else if (opptyFieldPC != 0.00m && opptyExchangeRate != 0.00m)
                            {
                                if (dataTypesplitgbp[1].ToLower().Equals("money"))
                                {

                                    decimal dc = opptyFieldPC / opptyExchangeRate;

                                    entity[dataTypesplitgbp[0]] = new Money(dc);
                                    //tracer.Trace("entity[gbpCurrencyField]", entity[gbpCurrencyField]);
                                }
                                else if (dataTypesplitgbp[1].ToLower().Equals("decimal"))
                                {

                                    decimal dc = opptyFieldPC / opptyExchangeRate;
                                    entity[dataTypesplitgbp[0]] = Convert.ToDecimal(dc);
                                    tracer.Trace("entity[dataTypesplitgbp[0]]" + entity[dataTypesplitgbp[0]]);
                                }

                            }
                        }
                        else if (formulaType.Contains("Currency_Convert") && PCorELC.Equals("ELC") && !string.IsNullOrEmpty(formuladescription) && context.MessageName.Equals("Update"))
                        {
                            string gbpCurrencyField = csentity.Attributes.Contains("rsa_gbpcurrencyfield") ? csentity.GetAttributeValue<string>("rsa_gbpcurrencyfield") : string.Empty;
                            tracer.Trace("gbpCurrencyField:" + gbpCurrencyField);
                            string policyCurrencyPCField = csentity.Attributes.Contains("rsa_policycurrencypcfield") ? csentity.GetAttributeValue<string>("rsa_policycurrencypcfield") : string.Empty;
                            tracer.Trace("policyCurrencyPCField:" + policyCurrencyPCField);

                            string[] dataTypesplitgbp = gbpCurrencyField.Split('|');
                            tracer.Trace("dataTypesplitgbp" + dataTypesplitgbp[0] + dataTypesplitgbp[1]);
                            string[] dataTypesplitpc = policyCurrencyPCField.Split('|');
                            tracer.Trace("dataTypesplitpc" + dataTypesplitpc[0] + dataTypesplitpc[1]);

                            decimal opptyFieldPC = 0.00m;
                            decimal opptyFieldGBP = 0.00m;
                            if (OpptyExtension != null)
                            {
                                if (OpptyExtension.Attributes.Contains(dataTypesplitpc[0]))
                                {
                                    if (dataTypesplitpc[1].ToLower().Equals("money"))
                                    {
                                        Money opptyFieldPCmoney = OpptyExtension.Attributes.Contains(dataTypesplitpc[0]) ? OpptyExtension.GetAttributeValue<Money>(dataTypesplitpc[0]) : null;
                                        if (opptyFieldPCmoney != null)
                                        {
                                            opptyFieldPC = opptyFieldPCmoney.Value;
                                            tracer.Trace("opptyFieldPC:" + opptyFieldPC);

                                        }

                                    }
                                    else if (dataTypesplitpc[1].ToLower().Equals("decimal"))
                                    {
                                        opptyFieldPC = OpptyExtension.Attributes.Contains(dataTypesplitpc[0]) ? OpptyExtension.GetAttributeValue<decimal>(dataTypesplitpc[0]) : 0.00m;
                                        tracer.Trace("opptyFieldPC:" + opptyFieldPC);
                                    }
                                }
                            }
                            if (entity.Attributes.Contains("rsa_exchangerate") && entity.Attributes.Contains("rsa_exchangerateelc"))
                            {
                                opptyExchangeRate = entity.GetAttributeValue<decimal>("rsa_exchangerate");
                                tracer.Trace("rsa_exchangerate:" + opptyExchangeRate);
                                opptyExchangeRateELC = entity.GetAttributeValue<decimal>("rsa_exchangerateelc");
                                tracer.Trace("opptyExchangeRateELC:" + opptyExchangeRateELC);
                            }
                            if (OpptyExtension != null)
                            {
                                if (opptyFieldPC == 0.00m)
                                {
                                    if (dataTypesplitgbp[1].ToLower().Equals("money"))
                                    {
                                        // entity[dataTypesplitgbp[0]] = new Money(0.00m);
                                        enOpportunityExtension[dataTypesplitgbp[0]] = new Money(0.00m);


                                    }
                                    else if (dataTypesplitgbp[1].ToLower().Equals("decimal"))
                                    {
                                        // entity[dataTypesplitgbp[0]] = 0.00m;
                                        enOpportunityExtension[dataTypesplitgbp[0]] = 0.00m;
                                    }

                                }
                                else if (opptyFieldPC != 0.00m && opptyExchangeRateELC != 0.00m)
                                {

                                    if (dataTypesplitgbp[1].ToLower().Equals("money"))
                                    {

                                        decimal dc = opptyFieldPC / opptyExchangeRateELC;

                                        enOpportunityExtension[dataTypesplitgbp[0]] = new Money(dc);


                                        tracer.Trace("enOpportunityExtension[dataTypesplitgbp[0]] ", enOpportunityExtension[dataTypesplitgbp[0]]);
                                    }
                                    else if (dataTypesplitgbp[1].ToLower().Equals("decimal"))
                                    {
                                        // entity[dataTypesplitgbp[0]] = opptyFieldPC / opptyExchangeRateELC;
                                        enOpportunityExtension[dataTypesplitgbp[0]] = opptyFieldPC / opptyExchangeRateELC;
                                        //tracer.Trace("entity[gbpCurrencyField]", entity[gbpCurrencyField]);

                                    }



                                }
                            }
                        }

                        else if (formulaType.Contains("Copy_Value") && !string.IsNullOrEmpty(formuladescription) && PCorELC.Equals("ELC") && context.MessageName.Equals("Update"))
                        {

                            string gbpCurrencyField = csentity.Attributes.Contains("rsa_gbpcurrencyfield") ? csentity.GetAttributeValue<string>("rsa_gbpcurrencyfield") : string.Empty;
                            tracer.Trace("gbpCurrencyField:" + gbpCurrencyField);
                            string policyCurrencyPCField = csentity.Attributes.Contains("rsa_policycurrencypcfield") ? csentity.GetAttributeValue<string>("rsa_policycurrencypcfield") : string.Empty;
                            tracer.Trace("policyCurrencyPCField:" + policyCurrencyPCField);
                            string[] dataTypesplitgbp = gbpCurrencyField.Split('|');
                            tracer.Trace("dataTypesplitgbp" + dataTypesplitgbp[0] + dataTypesplitgbp[1]);
                            string[] dataTypesplitpc = policyCurrencyPCField.Split('|');
                            tracer.Trace("dataTypesplitpc" + dataTypesplitpc[0] + dataTypesplitpc[1]);
                            decimal opptyFieldPC = 0.00m;
                            decimal opptyFieldGBP = 0.00m;
                            if (OpptyExtension != null)
                            {
                                if (OpptyExtension.Attributes.Contains(dataTypesplitpc[0]))
                                {
                                    tracer.Trace("Inside Copyvalue money if");
                                    if (dataTypesplitpc[1].ToLower().Equals("money"))
                                    {
                                        tracer.Trace("Inside Copyvalue money1:" + dataTypesplitpc[0]);
                                       decimal opptyFieldPCmoney = 0m;
                                        opptyFieldPCmoney = OpptyExtension.GetAttributeValue<decimal>(dataTypesplitpc[0]);
                                        tracer.Trace("opptyFieldPCmoney483:" + opptyFieldPCmoney);

                                    }
                                    else if (dataTypesplitpc[1].ToLower().Equals("decimal"))
                                    {
                                        tracer.Trace("Inside Copyvalue decimal");
                                        opptyFieldPC = OpptyExtension.Attributes.Contains(dataTypesplitpc[0]) ? OpptyExtension.GetAttributeValue<decimal>(dataTypesplitpc[0]) : 0.00m;
                                        tracer.Trace("opptyFieldPC:" + opptyFieldPC);
                                    }
                                }

                                if (dataTypesplitgbp[1].ToLower().Equals("money"))
                                {
                                    enOpportunityExtension[dataTypesplitgbp[0]] = new Money(opptyFieldPC);
                                    tracer.Trace("enOpportunityExtension[gbpCurrencyField]:" + enOpportunityExtension[dataTypesplitgbp[0]]);


                                }
                                else if (dataTypesplitgbp[1].ToLower().Equals("decimal"))
                                {
                                    enOpportunityExtension[dataTypesplitgbp[0]] = opptyFieldPC;
                                    tracer.Trace("enOpportunityExtension[gbpCurrencyField]:" + enOpportunityExtension[dataTypesplitgbp[0]]);
                                }
                            }
                        }
                        else if (formulaType.Contains("Copy_Value") && PCorELC.Equals("PC") && !string.IsNullOrEmpty(formuladescription))
                        {
                            string gbpCurrencyField = csentity.Attributes.Contains("rsa_gbpcurrencyfield") ? csentity.GetAttributeValue<string>("rsa_gbpcurrencyfield") : string.Empty;
                            tracer.Trace("gbpCurrencyField:" + gbpCurrencyField);
                            string policyCurrencyPCField = csentity.Attributes.Contains("rsa_policycurrencypcfield") ? csentity.GetAttributeValue<string>("rsa_policycurrencypcfield") : string.Empty;
                            tracer.Trace("policyCurrencyPCField:" + policyCurrencyPCField);
                            string[] dataTypesplitgbp = gbpCurrencyField.Split('|');
                            tracer.Trace("dataTypesplitgbp" + dataTypesplitgbp[0] + dataTypesplitgbp[1]);
                            string[] dataTypesplitpc = policyCurrencyPCField.Split('|');
                            tracer.Trace("dataTypesplitpc" + dataTypesplitpc[0] + dataTypesplitpc[1]);
                            decimal opptyFieldPC = 0.00m;
                            decimal opptyFieldGBP = 0.00m;

                            if (entity.Attributes.Contains(dataTypesplitpc[0]))
                            {
                                tracer.Trace("Inside Copyvalue money if");
                                if (dataTypesplitpc[1].ToLower().Equals("money"))
                                {
                                    tracer.Trace("Inside Copyvalue money1:" + dataTypesplitpc[0]);
                                    decimal opptyFieldPCmoney = 0m;
                                    opptyFieldPCmoney = entity.GetAttributeValue<decimal>(dataTypesplitpc[0]);
                                    tracer.Trace("opptyFieldPCmoney483:" + opptyFieldPCmoney);

                                }
                                else if (dataTypesplitpc[1].ToLower().Equals("decimal"))
                                {
                                    tracer.Trace("Inside Copyvalue decimal");
                                    opptyFieldPC = entity.Attributes.Contains(dataTypesplitpc[0]) ? entity.GetAttributeValue<decimal>(dataTypesplitpc[0]) : 0.00m;
                                    tracer.Trace("opptyFieldPC:" + opptyFieldPC);
                                }
                            }
                            if (dataTypesplitgbp[1].ToLower().Equals("money"))
                            {
                                entity[dataTypesplitgbp[0]] = new Money(opptyFieldPC);
                                tracer.Trace("entity[gbpCurrencyField]:" + entity[dataTypesplitgbp[0]]);


                            }
                            else if (dataTypesplitgbp[1].ToLower().Equals("decimal"))
                            {
                                entity[dataTypesplitgbp[0]] = opptyFieldPC;
                                tracer.Trace("entity[gbpCurrencyField]:" + entity[dataTypesplitgbp[0]]);
                            }
                        }

                        else
                        {
                        }

                    }
                    if (entity != null) {
                        tracer.Trace("Update Entity ");
                        if(context.MessageName.Equals("Update"))
                        {
                            service.Update(entity);
                        }
                        
                       
                    }
                    if (enOpportunityExtension != null && OpptyExtension != null)
                    {
                        service.Update(enOpportunityExtension);
                    }
                }
            }


            catch (Exception ex)
            {
                tracer.Trace("updateGBPFields-Error" + ex.Message.ToString());
                throw new InvalidPluginExecutionException(ex.Message);
            }

        }




        /// <summary>
        /// This function calculates the month between start date and end date
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="tracer"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        static decimal GetMonthsBetween(DateTime startDate, ITracingService tracer, DateTime endDate)
        {
            try
            {
                return ((startDate.Year - endDate.Year) * 12) + startDate.Month - endDate.Month;
            }
            catch (Exception ex)
            {
                tracer.Trace("GetMonthsBetween-Error" + ex.Message.ToString());
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        public static Entity getCOBnameANDPl(Guid guid, IOrganizationService service,string schema,string primaryKey)
        {
            try
            {
                var recordName = new Entity();
                QueryExpression query = new QueryExpression(schema);
                query.ColumnSet = new ColumnSet(new string[]{"rsa_name"});
                query.NoLock = true; 
                query.Criteria.AddCondition(primaryKey, ConditionOperator.Equal, guid);
                EntityCollection businessRecordTypes = service.RetrieveMultiple(query);
                if (businessRecordTypes != null && businessRecordTypes.Entities.Count > 0)
                {
                    recordName = businessRecordTypes.Entities[0];
                }
                return recordName;
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
        public static Entity getCustomername(Guid guid, IOrganizationService service)
        {
            try
            {
                var recordName = new Entity();
                QueryExpression query = new QueryExpression("rsa_customer");
                query.ColumnSet = new ColumnSet(true);
                query.NoLock = true;
                query.Criteria.AddCondition("rsa_customerid", ConditionOperator.Equal, guid);
                EntityCollection businessRecordTypes = service.RetrieveMultiple(query);
                if (businessRecordTypes != null && businessRecordTypes.Entities.Count > 0)
                {
                    recordName = businessRecordTypes.Entities[0];
                }
                return recordName;
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        public static Entity GetBrokername(Guid guid, IOrganizationService service)
        {
            try
            {
               
                var recordName = new Entity();
                QueryExpression query = new QueryExpression("account");
                query.ColumnSet = new ColumnSet(true);
                query.Criteria.AddCondition("accountid", ConditionOperator.Equal, guid);
                EntityCollection businessRecordTypes = service.RetrieveMultiple(query);
                if (businessRecordTypes != null && businessRecordTypes.Entities.Count > 0)
                {
                    recordName = businessRecordTypes.Entities[0];
                   
                          
                }
                return recordName;
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
        public static Entity GetOwnername(Guid guid, IOrganizationService service)
        {
            try
            {

                var recordName = new Entity();
                QueryExpression query = new QueryExpression("systemuser");
                query.ColumnSet = new ColumnSet(true);
                query.Criteria.AddCondition("systemuserid", ConditionOperator.Equal, guid);
                EntityCollection businessRecordTypes = service.RetrieveMultiple(query);
                if (businessRecordTypes != null && businessRecordTypes.Entities.Count > 0)
                {
                    recordName = businessRecordTypes.Entities[0];


                }
                return recordName;
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
    }
}
