﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using RSA.Crm.Plugins;
using System;
using RSA.CSI.Plugins.Utility;
using RSA.CSI.Plugins.OpportunityLogic;
using System.Collections.Generic;
using System.ServiceModel;
using Microsoft.Crm.Sdk.Messages;

namespace RSA.CSI.Plugins.Opportunity
{
    public class OpportunityPreUpdate : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService tracer = null;
            IPluginExecutionContext context = null;
            IOrganizationService service = null;

            CrmPluginHelper.Initialise(serviceProvider, ref context, ref service, ref tracer, false);
            if (context.Depth > 1)
            {
                return;
            }

            try
            {
                if ((context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity) && context.MessageName.ToLowerInvariant() == "update" && context.Stage == 20)
                {
                    tracer.Trace("Instace created and target is avaialble.");
                    Entity entity = (Entity)context.InputParameters["Target"];
                    Entity preImage = (Entity)context.PreEntityImages["PreImage"];
                    string lobName = string.Empty;
                    EntityReference lineofBusiness = null;


                    string cobName = string.Empty;
                    string custName = string.Empty;
                    EntityReference customer = entity.Attributes.Contains("rsa_customer") ? entity.GetAttributeValue<EntityReference>("rsa_customer") : null;
                    EntityReference classOfBusiness = entity.Attributes.Contains("rsa_classofbusiness") ? entity.GetAttributeValue<EntityReference>("rsa_classofbusiness") : null;
                    //if (customer != null)
                    //{
                    //    Entity cust = TriggerOperations.getCustomername(customer.Id, service);
                    //    custName = cust.Attributes.Contains("rsa_name") ? cust.GetAttributeValue<string>("rsa_name") : null;
                    //    tracer.Trace("custName", custName);
                    //}
                    // Bug :2080 -On Update

                    if (entity.Attributes.Contains("rsa_closedate"))
                    {
                        DateTime closeDates = entity.GetAttributeValue<DateTime>("rsa_closedate");
                        // int year = closeDates.Year;
                        // tracer.Trace("year", year);
                        int? Timezone = RetrieveCurrentUsersSettings(service);
                        DateTime closeDateval = RetrieveLocalTimeFromUTCTime(closeDates, Timezone, service);
                        if (closeDateval != null)
                        {
                            tracer.Trace("closeDates.Month" + closeDateval.Month);
                            int quarter = (closeDateval.Month + 2) / 3;
                            tracer.Trace("quarter" + quarter);
                            string fiscalYear = "Q" + quarter + "-" + closeDateval.Year;
                            entity["rsa_fiscalyear"] = fiscalYear;
                            tracer.Trace("Fiscalyear Update" + fiscalYear);
                        }
                    }

                    if (classOfBusiness != null)
                    {
                        Entity enCob = TriggerOperations.getCOBnameANDPl(classOfBusiness.Id, service, "rsa_classofbusiness", "rsa_classofbusinessid");
                        cobName = enCob.Attributes.Contains("rsa_name") ? enCob.GetAttributeValue<string>("rsa_name") : null;
                        tracer.Trace("cobName", cobName);
                    }
                    //if (year != 0 || customer != null || classOfBusiness != null)
                    //{
                    //    entity["name"] = custName + "-" + cobName + "-" + year;
                    //    tracer.Trace("name updated1");
                    //}
                    ///////////////////
                    if (entity.Attributes.Contains("rsa_lineofbusiness"))
                    {
                        lineofBusiness = entity.Attributes.Contains("rsa_lineofbusiness") ? entity.GetAttributeValue<EntityReference>("rsa_lineofbusiness") : null;
                        if (lineofBusiness != null)
                            lobName = lineofBusiness.Name.ToLowerInvariant();
                    }
                    else
                    {
                        lineofBusiness = preImage.Attributes.Contains("rsa_lineofbusiness") ? preImage.GetAttributeValue<EntityReference>("rsa_lineofbusiness") : null;
                        if (lineofBusiness != null)
                            lobName = lineofBusiness.Name.ToLowerInvariant();
                        tracer.Trace("lobName" + lobName);
                    }

                    EntityReference stage = entity.Attributes.Contains("rsa_opportunitystage") ? entity.GetAttributeValue<EntityReference>("rsa_opportunitystage") : null;
                    string stageName = string.Empty;
                    if (stage != null)
                    {
                        var satgeList = service.Retrieve(stage.LogicalName, stage.Id, new ColumnSet("rsa_name"));
                        stageName = satgeList["rsa_name"].ToString();
                    }


                    decimal triPercent = entity.Attributes.Contains("rsa_tripercent") ? entity.GetAttributeValue<decimal>("rsa_tripercent") : 0;
                    decimal triActual = entity.Attributes.Contains("rsa_triactual") ? entity.GetAttributeValue<decimal>("rsa_triactual") : 0;
                    decimal tri = entity.Attributes.Contains("rsa_tri") ? entity.GetAttributeValue<decimal>("rsa_tri") : 0;

                    if ((!string.IsNullOrEmpty(stageName) && (stageName.ToLowerInvariant() == "quoted" || stageName.ToLowerInvariant() == "renewed" || stageName.ToLowerInvariant() == "lapsed" || stageName.ToLowerInvariant() == "decline to renew")) || (triPercent != 0) || (triActual != 0) || (tri != 0))
                    {
                        entity["rsa_isupdated"] = true;
                        tracer.Trace("Update isUpdated field as true");
                    }
                    string pr1Value = string.Empty;
                    string pr2Value = string.Empty;
                    EntityCollection customLabels = CommonUtility.GetCutomLabelDetails(service, "Opportunity_Stages_for_Last_Exch_Rate_Key", "Page_Layouts_supporting_To_GBP_conversion", string.Empty);
                    if (customLabels.Entities.Count > 0)
                    {
                        foreach (var objCustomLabel in customLabels.Entities)
                        {
                            string customLabelName = objCustomLabel.GetAttributeValue<string>("rsa_name");
                            if (customLabelName == "Opportunity_Stages_for_Last_Exch_Rate_Key")
                            {
                                pr1Value = objCustomLabel.Attributes.Contains("rsa_values") ? objCustomLabel.GetAttributeValue<string>("rsa_values") : string.Empty;
                                tracer.Trace("is value:{0}", pr1Value);
                            }
                            if (customLabelName == "Page_Layouts_supporting_To_GBP_conversion")
                            {
                                pr2Value = objCustomLabel.Attributes.Contains("rsa_values") ? objCustomLabel.GetAttributeValue<string>("rsa_values") : string.Empty;
                                tracer.Trace("is value:{0}", pr2Value);
                            }
                        }
                    }

                    if (lobName == "gsl - new business" || lobName == "gsl - renewal")
                    {
                        //string name = entity.Attributes.Contains("name") ? entity.GetAttributeValue<string>("name") : string.Empty;
                        //string description = entity.Attributes.Contains("rsa_opportunitydescription") ? entity.GetAttributeValue<string>("rsa_opportunitydescription") : string.Empty;
                        //if (!string.IsNullOrEmpty(description))
                        //{
                        //    entity["rsa_opportunityname"] = name + description;
                        //    tracer.Trace("Updated Opportunity Name:{0}", name + description);
                        //}
                        //else
                        //{
                        //    entity["rsa_opportunityname"] = name;
                        //    tracer.Trace(" Opportunity Name:{0}", name);
                        //}
                    }
                    EntityReference oppCurrency = null;
                    tracer.Trace("line 128");
                    if (entity.Attributes.Contains("rsa_currency"))
                    {
                        tracer.Trace("line 131");
                        oppCurrency = entity.Attributes.Contains("rsa_currency") ? entity.GetAttributeValue<EntityReference>("rsa_currency") : null;
                        tracer.Trace("oppCurrency:{0}", oppCurrency);
                    }
                    else
                    {
                        oppCurrency = preImage.Attributes.Contains("rsa_currency") ? preImage.GetAttributeValue<EntityReference>("rsa_currency") : null;
                        tracer.Trace("line 136");
                    }
                    string currencyName = string.Empty;
                    string currencycode = string.Empty;
                    if (oppCurrency != null)
                    {
                        var currencyList = service.Retrieve(oppCurrency.LogicalName, oppCurrency.Id, new ColumnSet("currencyname"));
                        currencyName = currencyList["currencyname"].ToString();
                        tracer.Trace("currencyName" + currencyName);
                    }

                    EntityReference exLimitCurrencyELC = null;
                    tracer.Trace("obj exLimitCurrencyELC created");
                    if (entity.Attributes.Contains("rsa_excesslimitcurrencyelcid") && entity.GetAttributeValue<EntityReference>("rsa_excesslimitcurrencyelcid") != null)
                    {
                        exLimitCurrencyELC = entity.Attributes.Contains("rsa_excesslimitcurrencyelcid") ? entity.GetAttributeValue<EntityReference>("rsa_excesslimitcurrencyelcid") : null;
                        tracer.Trace("exLimitCurrencyELC" + exLimitCurrencyELC.Id);
                    }
                    //else if (preImage.Attributes.Contains("rsa_excesslimitcurrencyelcid") && preImage.GetAttributeValue<EntityReference>("rsa_excesslimitcurrencyelcid")!=null) { 
                    //exLimitCurrencyELC = preImage.Attributes.Contains("rsa_excesslimitcurrencyelcid") ? preImage.GetAttributeValue<EntityReference>("rsa_excesslimitcurrencyelcid") : null;
                    //tracer.Trace("exLimitCurrencyELC" + exLimitCurrencyELC.Id); }
                    string currencyNameELC = string.Empty;
                    if (exLimitCurrencyELC != null)
                    {
                        var currencyListELC = service.Retrieve(exLimitCurrencyELC.LogicalName, exLimitCurrencyELC.Id, new ColumnSet("currencyname"));
                        currencyNameELC = currencyListELC["currencyname"].ToString();
                        tracer.Trace("currencyNameELC" + currencyNameELC);
                    }
                    decimal? exchangeRate = null;
                    if (entity.Attributes.Contains("rsa_exchangerate"))
                        exchangeRate = entity.Attributes.Contains("rsa_exchangerate") ? entity.GetAttributeValue<decimal?>("rsa_exchangerate") : null;
                    else
                        exchangeRate = preImage.Attributes.Contains("rsa_exchangerate") ? preImage.GetAttributeValue<decimal?>("rsa_exchangerate") : null;

                    decimal? exchangeRateELC = null;
                    if (entity.Attributes.Contains("rsa_exchangerate"))
                        exchangeRateELC = entity.Attributes.Contains("rsa_exchangerateelc") ? entity.GetAttributeValue<decimal?>("rsa_exchangerateelc") : null;
                    else
                        exchangeRateELC = preImage.Attributes.Contains("rsa_exchangerateelc") ? preImage.GetAttributeValue<decimal?>("rsa_exchangerateelc") : null;
                    tracer.Trace("exchangeRateELC:{0}", exchangeRateELC);

                    // if ((oppCurrency != null && exchangeRate == null) || (exLimitCurrencyELC != null && exchangeRateELC == null))
                    if ((oppCurrency != null) && (exLimitCurrencyELC == null))
                    {
                        TriggerOperations operations = new TriggerOperations();
                        operations.UpdateExchangeRateOnOppty(service, tracer, entity, lineofBusiness, currencyName, currencyNameELC, oppCurrency.Id, Guid.Empty);
                        tracer.Trace("Exchange Rate on Opportunity update");
                    }
                    if ((oppCurrency != null) && (exLimitCurrencyELC != null))
                    {
                        TriggerOperations operations = new TriggerOperations();
                        operations.UpdateExchangeRateOnOppty(service, tracer, entity, lineofBusiness, currencyName, currencyNameELC, oppCurrency.Id, exLimitCurrencyELC.Id);
                        tracer.Trace("Exchange Rate on Opportunity update when exLimitCurrencyELC is not null");
                    }

                    if (!string.IsNullOrEmpty(stageName) && !string.IsNullOrEmpty(lobName) && pr1Value.Contains(stageName) && pr2Value.Contains(lobName))
                    {
                        tracer.Trace("preupdate line177");
                        if (exchangeRate != null)
                            entity["rsa_exchangerateatlastkeystage"] = exchangeRate;
                        tracer.Trace("rsa_exchangerateatlastkeystage Updated");
                    }

                    if (!string.IsNullOrEmpty(lobName) && lobName.Contains("marine"))
                    {
                        DateTime expiryDateMarine = DateTime.MinValue;
                        if (entity.Attributes.Contains("rsa_expirydatemarine"))
                            expiryDateMarine = entity.Attributes.Contains("rsa_expirydatemarine") ? entity.GetAttributeValue<DateTime>("rsa_expirydatemarine") : DateTime.MinValue;

                        else
                            expiryDateMarine = preImage.Attributes.Contains("rsa_expirydatemarine") ? preImage.GetAttributeValue<DateTime>("rsa_expirydatemarine") : DateTime.MinValue;

                        DateTime closeDate = DateTime.MinValue;
                        if (entity.Attributes.Contains("rsa_closedate"))
                        {
                            closeDate = entity.Attributes.Contains("rsa_closedate") ? entity.GetAttributeValue<DateTime>("rsa_closedate") : DateTime.MinValue;
                            tracer.Trace("closeDate :{0}", closeDate);
                        }
                        else
                        {
                            closeDate = preImage.Attributes.Contains("rsa_closedate") ? preImage.GetAttributeValue<DateTime>("rsa_closedate") : DateTime.MinValue;
                            tracer.Trace("closeDate :{0}", closeDate);
                        }
                        EntityReference broker = null;
                        if (entity.Attributes.Contains("parentaccountid"))
                        {
                            broker = entity.Attributes.Contains("parentaccountid") ? entity.GetAttributeValue<EntityReference>("parentaccountid") : null;
                            
                        }
                        else
                            broker = preImage.Attributes.Contains("parentaccountid") ? preImage.GetAttributeValue<EntityReference>("parentaccountid") : null;

                        #region Call Function
                        TriggerOperations operations = new TriggerOperations();
                        operations.UpdateGBPvaluesOnOppty(tracer, entity, expiryDateMarine, closeDate);
                        operations.UpdateAgencyCodesOnOpportunity(context, service, tracer, entity, broker);
                        #endregion

                        if (expiryDateMarine != DateTime.MinValue)
                        {
                            entity["rsa_expirydate"] = expiryDateMarine;
                            tracer.Trace("rsa_expirydate :{0}", expiryDateMarine);
                        }
                        else if (expiryDateMarine == DateTime.MinValue && closeDate != DateTime.MinValue)
                        {
                            entity["rsa_expirydate"] = closeDate.AddYears(1).AddDays(-1);
                            tracer.Trace("Expiry Date is Updated with Renewal Date with an added year and subtracted day");
                        }
                    }
                    tracer.Trace("stageName:" + stageName);
                    tracer.Trace("reacehd preupdate 226");
                    if (!string.IsNullOrEmpty(stageName))
                    {
                        tracer.Trace("preupdate line 229");
                        OpportunityUpdate oppUpdate = new OpportunityUpdate();
                        oppUpdate.CreatePipelineOpportunity(service, tracer, preImage, entity, lineofBusiness, stageName);
                        tracer.Trace("Pipeline Opportunity Created");
                    }
                    string policyLimitPC = string.Empty;
                    if (entity.Attributes.Contains("rsa_rsapolicylimitpc"))
                    {
                        policyLimitPC = entity.Attributes.Contains("rsa_rsapolicylimitpc") ? entity.GetAttributeValue<string>("rsa_rsapolicylimitpc") : string.Empty;
                    }

                    else
                        policyLimitPC = preImage.Attributes.Contains("rsa_rsapolicylimitpc") ? preImage.GetAttributeValue<string>("rsa_rsapolicylimitpc") : string.Empty;

                    tracer.Trace("policyLimitPC" + policyLimitPC);
                    if (!string.IsNullOrEmpty(policyLimitPC))
                    {
                        tracer.Trace("policyLimitPC" + policyLimitPC);
                        entity["rsa_policylimitpc"] = Convert.ToDecimal(policyLimitPC);
                    }
                    //throw new InvalidPluginExecutionException("Check1");

                    //if (lineofBusiness.Name.ToLowerInvariant().Contains("marine"))
                    //{
                    //    TriggerOperations operations = new TriggerOperations();
                    //    operations.updateGBPFields(service, entity,preImage, tracer, 866760027);

                    //}
                    #region 33918 Changes
                    //tracer.Trace("33918 changes start");
                    //string[] modifiedFieldValue = new string[] { };
                    //string result = string.Empty;
                    //string brokerName = string.Empty; string ownerName = string.Empty;
                    //EntityReference opprtunityRecordType = entity.Attributes.Contains("rsa_lineofbusiness") ? entity.GetAttributeValue<EntityReference>("rsa_lineofbusiness") : null;
                    ////string expiringPolicyNumber = entity.Attributes.Contains("rsa_expiringpolicynumber") ? entity.GetAttributeValue<string>("rsa_expiringpolicynumber") : null;
                    //string policyNumbers = entity.Attributes.Contains("rsa_policynumbers") ? entity.GetAttributeValue<string>("rsa_policynumbers") : null;
                    //EntityReference entityBroker = entity.Attributes.Contains("parentaccountid") ? entity.GetAttributeValue<EntityReference>("parentaccountid") : null;
                    //EntityReference owner = entity.Attributes.Contains("ownerid") ? entity.GetAttributeValue<EntityReference>("ownerid") : null;

                    //#region Get Customer,Broker and Owner Updated Name
                    //if (customer != null)
                    //{
                    //    Entity cust = TriggerOperations.getCustomername(customer.Id, service);
                    //    custName = cust.Attributes.Contains("rsa_name") ? cust.GetAttributeValue<string>("rsa_name") : null;
                    //    // tracer.Trace("custName", custName);
                    //}
                    //if (entityBroker != null)
                    //{

                    //    Entity brok = TriggerOperations.GetBrokername(entityBroker.Id, service);

                    //    brokerName = brok.Attributes.Contains("name") ? brok.GetAttributeValue<string>("name") : null;
                    //    // tracer.Trace("brokerName", brokerName);
                    //}
                    //if (owner != null)
                    //{

                    //    Entity ownerN = TriggerOperations.GetOwnername(owner.Id, service);

                    //    ownerName = ownerN.Attributes.Contains("fullname") ? ownerN.GetAttributeValue<string>("fullname") : null;
                    //    // tracer.Trace("OwnerName", ownerName);
                    //}
                    //#endregion
                    //if (entity.Attributes.Contains("parentaccountid")
                    //|| entity.Attributes.Contains("rsa_lineofbusiness")
                    //|| entity.Attributes.Contains("rsa_classofbusiness")
                    //|| entity.Attributes.Contains("rsa_policynumbers")
                    //|| entity.Attributes.Contains("rsa_customer")
                    //|| entity.Attributes.Contains("ownerid")
                    //|| entity.Attributes.Contains("rsa_closedate")
                    //|| entity.Attributes.Contains("rsa_totalgwp100pc")
                    //|| entity.Attributes.Contains("rsa_exchangerate"))

                    //{

                    //    tracer.Trace(modifiedFieldValue.ToString());

                    //    if (opprtunityRecordType != null) { modifiedFieldValue = new List<string>(modifiedFieldValue) { "Opportunity Record Type: " + lineofBusiness.Name }.ToArray(); }
                    //    if (classOfBusiness != null) { modifiedFieldValue = new List<string>(modifiedFieldValue) { "Class of Business: " + classOfBusiness.Name }.ToArray(); }
                    //    if (policyNumbers != null) { modifiedFieldValue = new List<string>(modifiedFieldValue) { "Policy Number(s): " + policyNumbers }.ToArray(); }
                    //    if (entityBroker != null) { modifiedFieldValue = new List<string>(modifiedFieldValue) { "Broker Name (Account): " + brokerName }.ToArray(); }
                    //    if (customer != null) { modifiedFieldValue = new List<string>(modifiedFieldValue) { "Customer: " + custName }.ToArray(); }
                    //    if (owner != null) { modifiedFieldValue = new List<string>(modifiedFieldValue) { "Owner: " + ownerName }.ToArray(); }
                    //    if (entity.Attributes.Contains("rsa_closedate"))
                    //    {
                    //        DateTime closeDates = entity.GetAttributeValue<DateTime>("rsa_closedate");

                    //        int? Timezone = RetrieveCurrentUsersSettings(service);
                    //        DateTime closeDateval = RetrieveLocalTimeFromUTCTime(closeDates, Timezone, service);
                    //        modifiedFieldValue = new List<string>(modifiedFieldValue) { "Renewal Date: " + closeDateval.ToShortDateString() }.ToArray();
                    //    }
                    //    if (entity.Attributes.Contains("rsa_totalgwp100pc") || entity.Attributes.Contains("rsa_exchangerate"))
                    //    {

                    //        decimal? preTotalGwp100PC = null; decimal? totalgwp100gbp = null; EntityReference preOppCurrency = null; EntityReference opportunityCurrency = null;
                    //        if (preImage.Attributes.Contains("rsa_totalgwp100pc"))
                    //            preTotalGwp100PC = preImage.Attributes.Contains("rsa_totalgwp100pc") ? preImage.GetAttributeValue<decimal?>("rsa_totalgwp100pc") : null;

                    //        decimal? totalGwp100PC = null;
                    //        if (entity.Attributes.Contains("rsa_totalgwp100pc"))
                    //            totalGwp100PC = entity.Attributes.Contains("rsa_totalgwp100pc") ? entity.GetAttributeValue<decimal?>("rsa_totalgwp100pc") : null;
                    //        else
                    //            totalGwp100PC = preImage.Attributes.Contains("rsa_totalgwp100pc") ? preImage.GetAttributeValue<decimal?>("rsa_totalgwp100pc") : null;


                    //        decimal? exRate = null;
                    //        if (entity.Attributes.Contains("rsa_exchangerate"))
                    //            exRate = entity.Attributes.Contains("rsa_exchangerate") ? entity.GetAttributeValue<decimal?>("rsa_exchangerate") : null;
                    //        else
                    //            exRate = preImage.Attributes.Contains("rsa_exchangerate") ? preImage.GetAttributeValue<decimal?>("rsa_exchangerate") : null;

                    //        if (entity.Attributes.Contains("rsa_currency"))
                    //            opportunityCurrency = entity.Attributes.Contains("rsa_currency") ? entity.GetAttributeValue<EntityReference>("rsa_currency") : null;
                    //        if (preImage.Attributes.Contains("rsa_currency"))
                    //            preOppCurrency = preImage.Attributes.Contains("rsa_currency") ? preImage.GetAttributeValue<EntityReference>("rsa_currency") : null;

                    //        if ((opportunityCurrency != null && preOppCurrency != null && opportunityCurrency.Id != preOppCurrency.Id)
                    //            || preTotalGwp100PC != totalGwp100PC)
                    //        {
                    //            totalgwp100gbp = totalGwp100PC / exRate;
                    //            tracer.Trace("totalgwp100gbp" + totalgwp100gbp);
                    //            totalgwp100gbp = Decimal.Round(totalgwp100gbp.Value, 2);
                    //            modifiedFieldValue = new List<string>(modifiedFieldValue) { "Total GWP 100% (GBP): " + totalgwp100gbp.ToString() }.ToArray();
                    //        }

                    //    }
                    //     result = string.Join(",", modifiedFieldValue);
                    //    if (!string.IsNullOrWhiteSpace(result))
                    //    {
                    //        tracer.Trace(result);
                    //        entity["rsa_fieldsmodifiedon"] = DateTime.Now.AddHours(1);
                    //        entity["rsa_modifiedfieldvalue"] = result;
                    //    }
                    //}

                    #endregion
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                CrmPluginHelper.CatchFaultException(ex, this);
            }
            catch (InvalidPluginExecutionException ex)
            {
                CrmPluginHelper.CatchInvalidPluginException(ex);
            }
            catch (Exception ex)
            {
                CrmPluginHelper.CatchGenericException(ex, this);
            }
        }
        public int? RetrieveCurrentUsersSettings(IOrganizationService service)

        {

            var currentUserSettings = service.RetrieveMultiple(

                new QueryExpression("usersettings")

                {

                    ColumnSet = new ColumnSet("timezonecode"),

                    Criteria = new FilterExpression

                    {

                        Conditions =

                        {

                            new ConditionExpression("systemuserid", ConditionOperator.EqualUserId)

                        }

                    },
                    NoLock = true

                }).Entities[0].ToEntity<Entity>();

            //return time zone code

            return (int?)currentUserSettings.Attributes["timezonecode"];

        }

        public DateTime RetrieveLocalTimeFromUTCTime(DateTime utcTime, int? timeZoneCode, IOrganizationService service)

        {

            if (!timeZoneCode.HasValue)

                return DateTime.Now;

            var request = new LocalTimeFromUtcTimeRequest

            {

                TimeZoneCode = timeZoneCode.Value,

                UtcTime = utcTime.ToUniversalTime()

            };

            var response = (LocalTimeFromUtcTimeResponse)service.Execute(request);

            return response.LocalTime;

        }
    }
}
