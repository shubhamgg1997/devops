﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using RSA.Crm.Plugins;
using System;
using RSA.CSI.Plugins.Utility;
using RSA.CSI.Plugins.OpportunityLogic;
using System.ServiceModel;
using Microsoft.Crm.Sdk.Messages;
using System.Net;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.IO;
using System.Text;

namespace RSA.CSI.Plugins.Opportunity
{
    public class OpportunityPreCreate : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService tracer = null;
            IPluginExecutionContext context = null;
            IOrganizationService service = null;


            CrmPluginHelper.Initialise(serviceProvider, ref context, ref service, ref tracer, false);
            tracer.Trace(context.Depth.ToString());
            if (context.Depth > 1 && context.Depth >= 5)
            {
                tracer.Trace(context.Depth.ToString());
                return;
            }
            tracer.Trace(context.Depth.ToString());
            try
            {
                string lobName = string.Empty;
                if ((context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity) && context.MessageName.ToLowerInvariant() == "create" && context.Stage == 20)
                {
                    tracer.Trace("Instace created and target is avaialble.");
                    tracer.Trace("Instace created and target is avaialble.1");
                    Entity entity = (Entity)context.InputParameters["Target"];
                    EntityReference lineofBusiness = entity.Attributes.Contains("rsa_lineofbusiness") ? entity.GetAttributeValue<EntityReference>("rsa_lineofbusiness") : null;

                    #region bug 2349  //to trigger the PC GBP calculation for opportunities created using RG Process
                    EntityReference en_RG = entity.GetAttributeValue<EntityReference>("rsa_renewalgeneration");
                    if (en_RG != null && lineofBusiness != null)
                    {
                        if (lineofBusiness.Name.ToLowerInvariant().Contains("marine"))
                        {
                            TriggerOperations operations = new TriggerOperations();
                            tracer.Trace("precreate to start for pC to GBP");

                            operations.updateGBPFields(context, service, entity, entity, null, tracer, 866760027);
                        }

                    }
                    #endregion
                    //Bug 2569
                    if (context.Depth > 1 && context.Depth >= 5)
                    { // Stop the code if Depth is > 1
                        tracer.Trace("context.Depth: " + context.Depth.ToString());
                        return;
                    }


                    string cobName = string.Empty;
                    string custName = string.Empty;
                    string plName = string.Empty;
                    string plNameROI = string.Empty;
                    EntityReference enPl = null;
                    EntityReference exLimitCurrencyELC = null;
                    if (entity.Attributes.Contains("rsa_pandlid"))
                    {
                        tracer.Trace(" P&L is there ");
                        enPl = entity.Attributes.Contains("rsa_pandlid") ? entity.GetAttributeValue<EntityReference>("rsa_pandlid") : null;
                        if (enPl.Name != null && enPl.Name != string.Empty)
                            plName = enPl.Name;
                        tracer.Trace("plName " + plName);
                    }
                    bool exflagcheck = false;

                    if (entity.Attributes.Contains("rsa_excesslimitcurrencyelcid"))
                    {
                        exLimitCurrencyELC = entity.GetAttributeValue<EntityReference>("rsa_excesslimitcurrencyelcid");
                        tracer.Trace("exLimitCurrencyELC" + exLimitCurrencyELC);
                        if (exLimitCurrencyELC == null)
                        {
                            exflagcheck = true;
                            tracer.Trace("exflagcheck " + exflagcheck);
                        }
                    }
                    decimal actualValue = entity.Attributes.Contains("rsa_actualvalue") ? entity.GetAttributeValue<decimal>("rsa_actualvalue") : 0.00m;

                    EntityReference customer = entity.Attributes.Contains("rsa_customer") ? entity.GetAttributeValue<EntityReference>("rsa_customer") : null;
                    if (customer != null)
                    {
                        Entity cust = TriggerOperations.getCustomername(customer.Id, service);
                        custName = cust.Attributes.Contains("rsa_name") ? cust.GetAttributeValue<string>("rsa_name") : null;
                    }
                    EntityReference classOfBusiness = entity.Attributes.Contains("rsa_classofbusiness") ? entity.GetAttributeValue<EntityReference>("rsa_classofbusiness") : null;
                    if (classOfBusiness != null)
                    {
                        Entity enCob = TriggerOperations.getCOBnameANDPl(classOfBusiness.Id, service, "rsa_classofbusiness", "rsa_classofbusinessid");
                        cobName = enCob.Attributes.Contains("rsa_name") ? enCob.GetAttributeValue<string>("rsa_name") : null;
                        tracer.Trace("COB data  " + cobName);
                    }
                    string opptyName = entity.Attributes.Contains("name") ? entity.GetAttributeValue<string>("name") : null;

                    DateTime closeDates = entity.GetAttributeValue<DateTime>("rsa_closedate");
                    int? Timezone = RetrieveCurrentUsersSettings(service);
                    DateTime closeDateval = RetrieveLocalTimeFromUTCTime(closeDates, Timezone, service);
                    int year = closeDates.Year;
                    tracer.Trace("Field Data Available");
                    // Bug :2080
                    if (closeDateval != null)
                    {
                        tracer.Trace("closeDates.Month" + closeDateval.Month);
                        int quarter = (closeDateval.Month + 2) / 3;
                        tracer.Trace("quarter" + quarter);
                        string fiscalYear = "Q" + quarter + "-" + year;
                        entity["rsa_fiscalyear"] = fiscalYear;
                        tracer.Trace("Fiscalyear After Set" + fiscalYear);
                    }

                    if (lineofBusiness != null && string.IsNullOrEmpty(lineofBusiness.Name))
                    {
                        var lobDetails = service.Retrieve(lineofBusiness.LogicalName, lineofBusiness.Id, new ColumnSet("rsa_name"));
                        lobName = lobDetails["rsa_name"].ToString().ToLowerInvariant();
                        tracer.Trace("lobname" + lobName);
                    }
                    else
                        lobName = lineofBusiness.Name.ToLowerInvariant();
                    tracer.Trace("lobname else" + lobName);
                    EntityReference pnl = entity.Attributes.Contains("rsa_pandlid") ? entity.GetAttributeValue<EntityReference>("rsa_pandlid") : null;
                    //tracer.Trace("pnl" + pnl);
                    EntityReference enPlROI = null;
                    if (lobName.Equals("new business - roi") || lobName.Equals("new business - ni"))
                    {
                        enPlROI = entity.Attributes.Contains("rsa_plroi") ? entity.GetAttributeValue<EntityReference>("rsa_plroi") : null;
                        if (enPlROI != null)
                        {
                            Entity enPlROIretrieve = TriggerOperations.getCOBnameANDPl(enPlROI.Id, service, "rsa_pl", "rsa_plid");
                            enPlROI.Name = enPlROIretrieve.Attributes.Contains("rsa_name") ? enPlROIretrieve.GetAttributeValue<string>("rsa_name") : null;
                            tracer.Trace("enPlROI " + enPlROI.Name);
                        }
                    }
                    // Bug id : 1723
                    string PLROIName = " ";

                    if (enPlROI == null)
                    {
                        PLROIName = string.Empty;
                    }
                    tracer.Trace("Data available for Opportunity line of business , P&L , P&LROI ");
                    if (lineofBusiness != null)
                    {
                        if (lobName == "new business - roi" && pnl != null && (enPlROI == null || string.IsNullOrEmpty(PLROIName)))
                        {
                            Entity objPNL = CommonUtility.GetLookUpDetailsbyText(service, "sme", "rsa_pl", lineofBusiness.Id);
                            if (objPNL.Id != Guid.Empty)
                                entity["rsa_pandlid"] = new EntityReference(objPNL.LogicalName, objPNL.Id);
                            Entity cob = CommonUtility.GetLookUpDetailsbyText(service, "traditional", "rsa_classofbusiness", lineofBusiness.Id);
                            entity["rsa_classofbusiness"] = new EntityReference(cob.LogicalName, cob.Id);
                            tracer.Trace("Opportunity Class Of business is updated {0}", cob.Id);
                        }
                        if (lobName == "gsl - new business" || lobName == "gsl - renewal")
                        {
                            string name = entity.Attributes.Contains("name") ? entity.GetAttributeValue<string>("name") : string.Empty;
                            string description = entity.Attributes.Contains("rsa_opportunitydescription") ? entity.GetAttributeValue<string>("rsa_opportunitydescription") : string.Empty;
                            // entity["rsa_opportunityname"] = name + description;
                            tracer.Trace("Opportunity name is updated {0}", name + description);
                        }


                        EntityReference policy = entity.Attributes.Contains("rsa_policyid") ? entity.GetAttributeValue<EntityReference>("rsa_policyid") : null;
                        string oprHandling = string.Empty;
                        if (policy != null)
                        {
                            var policyDetails = service.Retrieve(policy.LogicalName, policy.Id, new ColumnSet("rsa_operationshandlingsite", "rsa_premium"));
                            tracer.Trace("Policy Details :{0}", policyDetails);
                            if (policyDetails != null)
                            {
                                tracer.Trace("Policy Details :{0}", policyDetails);
                                if (policyDetails.Attributes.Contains("rsa_operationshandlingsite") && policyDetails.FormattedValues["rsa_operationshandlingsite"] != null)
                                { //bug 2012 Error due to missing trading handler
                                    oprHandling = policyDetails.Attributes.ContainsKey("rsa_operationshandlingsite") ? policyDetails.FormattedValues["rsa_operationshandlingsite"] : null; //bug id 1989 Null check.
                                    tracer.Trace("updated ops handling site  {0}", oprHandling);
                                }
                                ///Bug 2624 - set last year premium
                                string fetchAllOpportunity = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' count='1'>";
                                fetchAllOpportunity += "<entity name='opportunity'>";
                                fetchAllOpportunity += "<attribute name='name' />";
                                fetchAllOpportunity += "<attribute name='opportunityid' />";
                                fetchAllOpportunity += "<attribute name='rsa_lineofbusiness' />";
                                fetchAllOpportunity += "<attribute name='rsa_opportunitystage' />";
                                fetchAllOpportunity += "<attribute name='createdon' />";
                                fetchAllOpportunity += "<attribute name='rsa_policyid' />";
                                fetchAllOpportunity += "<attribute name='rsa_expiringpremium' />";
                                fetchAllOpportunity += "<attribute name='rsa_rsaquotedpremium' />";
                                fetchAllOpportunity += "<order attribute='createdon' descending='true' />";
                                fetchAllOpportunity += "<filter type='and'>";
                                fetchAllOpportunity += "<condition attribute='rsa_policyid' operator='eq' value='" + policyDetails.Id + "' />";
                                fetchAllOpportunity += "</filter>";
                                fetchAllOpportunity += "</entity>";
                                fetchAllOpportunity += "</fetch>";

                                EntityCollection opportunityColl = service.RetrieveMultiple(new FetchExpression(fetchAllOpportunity));
                                tracer.Trace("Opportunity Count" + opportunityColl.Entities.Count);
                                if (opportunityColl != null && opportunityColl.Entities.Count == 0)
                                {
                                    tracer.Trace("Opportunity Count is 0");
                                    if (policyDetails.Attributes.Contains("rsa_premium"))
                                        entity["rsa_expiringpremium"] = policyDetails["rsa_premium"];
                                }
                                else if (opportunityColl != null && opportunityColl.Entities.Count > 0)
                                {
                                    tracer.Trace("Opportunity Count is greater than 0");
                                    foreach (var item in opportunityColl.Entities)
                                    {
                                        entity["rsa_expiringpremium"] = item.Attributes.Contains("rsa_rsaquotedpremium") ? item.GetAttributeValue<Money>("rsa_rsaquotedpremium") : new Money(0.00M);
                                    }
                                }


                            }
                        }

                        string pr1Value = string.Empty;
                        string pr2Value = string.Empty;
                        EntityCollection customLabels = CommonUtility.GetCutomLabelDetails(service, "Opportunity_Stages_for_Last_Exch_Rate_Key", "Page_Layouts_supporting_To_GBP_conversion", string.Empty);
                        if (customLabels.Entities.Count > 0)
                        {
                            foreach (var objCustomLabel in customLabels.Entities)
                            {
                                string customLabelName = objCustomLabel.GetAttributeValue<string>("rsa_name");
                                if (customLabelName == "Opportunity_Stages_for_Last_Exch_Rate_Key")
                                {
                                    pr1Value = objCustomLabel.Attributes.Contains("rsa_values") ? objCustomLabel.GetAttributeValue<string>("rsa_values") : string.Empty;
                                }
                                if (customLabelName == "Page_Layouts_supporting_To_GBP_conversion")
                                {
                                    pr2Value = objCustomLabel.Attributes.Contains("rsa_values") ? objCustomLabel.GetAttributeValue<string>("rsa_values") : string.Empty;
                                }
                            }
                            tracer.Trace("Value : {0}", pr1Value);
                            tracer.Trace("Value : {0}", pr2Value);
                        }

                        if (lobName.Contains("renewal") && oprHandling.ToLowerInvariant() == "isle of man")
                        {
                            Entity lob = CommonUtility.GetLookUpDetailsbyText(service, "Renewal - Isle of Man", "rsa_lineofbusiness", Guid.Empty);
                            entity["rsa_lineofbusiness"] = new EntityReference(lob.LogicalName, lob.Id);
                        }

                        EntityReference oppCurrency = entity.Attributes.Contains("rsa_currency") ? entity.GetAttributeValue<EntityReference>("rsa_currency") : null;
                        string currencyName = string.Empty;
                        if (oppCurrency != null)
                        {
                            var currencyList = service.Retrieve(oppCurrency.LogicalName, oppCurrency.Id, new ColumnSet("currencyname"));
                            currencyName = currencyList["currencyname"].ToString();

                        }

                        string currencyNameELC = string.Empty;




                        if (entity.Attributes.Contains("rsa_excesslimitcurrencyelcid") && exLimitCurrencyELC != null)
                        {

                            var currencyListELC = service.Retrieve(exLimitCurrencyELC.LogicalName, exLimitCurrencyELC.Id, new ColumnSet("currencyname"));
                            currencyNameELC = currencyListELC["currencyname"].ToString();
                        }


                        if (oppCurrency != null && exLimitCurrencyELC == null)
                        {
                            TriggerOperations operations = new TriggerOperations();
                            operations.UpdateExchangeRateOnOppty(service, tracer, entity, lineofBusiness, currencyName, currencyNameELC, oppCurrency.Id, Guid.Empty);
                            tracer.Trace("Exchange Rate Successfully Updated");
                        }

                        else if (entity.Attributes.Contains("rsa_excesslimitcurrencyelcid") && oppCurrency != null && exLimitCurrencyELC != null)
                        {
                            TriggerOperations operations = new TriggerOperations();
                            operations.UpdateExchangeRateOnOppty(service, tracer, entity, lineofBusiness, currencyName, currencyNameELC, oppCurrency.Id, exLimitCurrencyELC.Id);
                            tracer.Trace("Exchange Rate Successfully Updated when exLimitCurrencyELC is not null");
                        }

                        EntityReference stage = entity.Attributes.Contains("rsa_opportunitystage") ? entity.GetAttributeValue<EntityReference>("rsa_opportunitystage") : null;
                        decimal exchangeRate = entity.Contains("rsa_exchangerate") ? entity.GetAttributeValue<decimal>("rsa_exchangerate") : 0;
                        decimal exchangeRateELC = entity.Contains("rsa_exchangerateelc") ? entity.GetAttributeValue<decimal>("rsa_exchangerateelc") : 0;

                        if (stage != null)
                        {
                            var satgeList = service.Retrieve(stage.LogicalName, stage.Id, new ColumnSet("rsa_name"));
                            string stageName = satgeList["rsa_name"].ToString();
                            if (!string.IsNullOrEmpty(pr1Value) && pr1Value.Contains(stageName) && pr2Value.ToLowerInvariant().Contains(lobName))
                            {
                                if (exchangeRate != 0)
                                    entity["rsa_exchangerateatlastkeystage"] = exchangeRate;
                            }
                        }

                        if (lobName.Contains("marine"))
                        {
                            DateTime expiryDateMarine = entity.Attributes.Contains("rsa_expirydatemarine") ? entity.GetAttributeValue<DateTime>("rsa_expirydatemarine") : DateTime.MinValue;
                            DateTime closeDate = entity.Attributes.Contains("rsa_closedate") ? entity.GetAttributeValue<DateTime>("rsa_closedate") : DateTime.MinValue;
                            if (expiryDateMarine != DateTime.MinValue)
                            {
                                entity["rsa_expirydate"] = expiryDateMarine;
                            }
                            else if (expiryDateMarine == DateTime.MinValue && closeDate != DateTime.MinValue)
                            {
                                entity["rsa_expirydate"] = closeDate.AddYears(1).AddDays(-1);
                                tracer.Trace("Expiry Date is Updated with Renewal Date with an added year");
                            }
                            TriggerOperations operations = new TriggerOperations();
                            operations.UpdateGBPvaluesOnOppty(tracer, entity, expiryDateMarine, closeDate);
                            tracer.Trace("Updated GBP values in Opportunity");
                            EntityReference broker = entity.Attributes.Contains("parentaccountid") ? entity.GetAttributeValue<EntityReference>("parentaccountid") : null;
                            operations.UpdateAgencyCodesOnOpportunity(context, service, tracer, entity, broker);
                            tracer.Trace("Updated Agency Code in Opportunity");

                            if (lobName.Contains("london") || lobName.Contains("europe") && !lineofBusiness.Name.ToLowerInvariant().Contains("renewal"))
                            {
                                if (oppCurrency != null && exLimitCurrencyELC == null)
                                {
                                    entity["rsa_excesslimitcurrencyelcid"] = new EntityReference(oppCurrency.LogicalName, oppCurrency.Id);
                                }

                                if (exchangeRate != 0 && exchangeRateELC == 0)
                                {
                                    entity["rsa_exchangerateelc"] = exchangeRate;
                                    tracer.Trace("is Exchange Rate:{0}", exchangeRate);
                                }
                                string exchangeID = entity.Contains("rsa_exchangeid") ? entity.GetAttributeValue<string>("rsa_exchangeid") : string.Empty;
                                string exchangeIdELC = entity.Contains("rsa_exchangeidelc") ? entity.GetAttributeValue<string>("rsa_exchangeidelc") : string.Empty;
                                if (!string.IsNullOrEmpty(exchangeID) && string.IsNullOrEmpty(exchangeIdELC))
                                {
                                    entity["rsa_exchangeidelc"] = exchangeID;
                                    tracer.Trace("is ExchangeID:{0}", exchangeID);
                                }
                            }

                            string schemeValue = entity.Attributes.Contains("rsa_schemes") ? entity.FormattedValues["rsa_schemes"] : string.Empty;
                            if (lobName.Contains("renewal") && !string.IsNullOrEmpty(schemeValue) && schemeValue.ToLowerInvariant() != "declaration")
                            {
                                operations.UpdateOwnerOnRenewalOppty(service, entity, tracer, lobName);
                                tracer.Trace("Owner is updated on Renewal of an Opportunity");
                            }
                        }

                        tracer.Trace("Opp working fine");

                    }

                    if ((enPlROI != null) && (lobName.Equals("new business - ni") || lobName.Equals("new business - roi")) && (year != 0 || plName != null || custName != null))
                    {
                        tracer.Trace("Lob contains Ni or ROI");
                        if (!string.IsNullOrEmpty(enPlROI.Name))
                        {
                            plNameROI = enPlROI.Name;
                            tracer.Trace("plNameROI " + plNameROI);
                        }
                        entity["name"] = custName + "-" + plNameROI + "-" + year;
                        tracer.Trace("Name is " + custName + "-" + plNameROI + "-" + year);
                    }
                    else if ((!lobName.ToLowerInvariant().Contains("new business - ni") || !lobName.ToLowerInvariant().Contains("new business - roi")) && year != 0 && custName != null && cobName != null)
                    {
                        tracer.Trace("Lob does not contain Ni or ROI");
                        entity["name"] = custName + "-" + cobName + "-" + year;
                        tracer.Trace("Name   is " + custName + "-" + cobName + "-" + year);
                    }

                    //2569
                    if (closeDateval != DateTime.MinValue)
                    {
                        tracer.Trace("closeDateval" + closeDateval);
                        entity["rsa_opportunityrenewalmonth"] = closeDateval.ToString("MMMM"); //bug 1862; //bug 1862 Renewal month not populating
                    }
                    if (lobName.ToLowerInvariant().Contains("marine"))
                    {
                        TriggerOperations operations = new TriggerOperations();
                        tracer.Trace("precreate to start for pC to GBP");

                        operations.updateGBPFields(context, service, entity, entity, null, tracer, 866760027);
                    }
                    #region bug 2032
                    string policyLimitPC = entity.Attributes.Contains("rsa_rsapolicylimitpc") ? entity.GetAttributeValue<string>("rsa_rsapolicylimitpc") : string.Empty;
                    tracer.Trace("policyLimitPC" + policyLimitPC);

                    if (!string.IsNullOrEmpty(policyLimitPC))
                        entity["rsa_policylimitpc"] = Convert.ToDecimal(policyLimitPC);
                    //throw new InvalidPluginExecutionException("Check1");
                    #endregion

                    if (actualValue != 0 && closeDates != DateTime.MinValue)
                    {
                        string yr = year.ToString();
                        string strdate = string.Concat("31/12/", yr);
                        tracer.Trace("strdate: " + strdate);
                        //DateTime oDate = DateTime.Parse(Convert.ToString(strdate));
                        DateTime oDate = DateTime.ParseExact(strdate.ToString(), "dd/MM/yyyy", null);
                        tracer.Trace("oDate: " + oDate);
                        TimeSpan diff = (oDate - closeDates.AddDays(-1));
                        tracer.Trace("diff: " + diff);
                        entity["rsa_inyearbenefit"] = actualValue * diff.Days * 365;
                    }

                    ///GBP Fields Logic
                    ///
                    tracer.Trace("Executing GBP Fields Logic");
                    tracer.Trace("lineofBusiness" +lineofBusiness.Name);
                    tracer.Trace("entity.LogicalName" + entity.LogicalName);
                    this.PopulateOpportunityFields(service, tracer, lineofBusiness, entity);
                    tracer.Trace("Updated fields with '0' on create if no data");
                 
                    
                    tracer.Trace("Updated fields with '0' on create if no data");

                    #region bug 2038 BAM for marine/Non marine
                    tracer.Trace("Entered bug 2038 BAM for NB: ");

                    Guid opportunityOwnerId = Guid.Empty;
                    Guid BAMUser = Guid.Empty;
                    Guid guidEmpty = Guid.Empty;
                    Guid brokerId = Guid.Empty;
                    string plname = string.Empty;
                    string ocobName = string.Empty;
                    string ocobROIName = string.Empty;

                    EntityReference enCOBName = entity.GetAttributeValue<EntityReference>("rsa_classofbusiness");
                    EntityReference enPandl = entity.GetAttributeValue<EntityReference>("rsa_pandlid");
                    EntityReference enRoiCOBName = entity.GetAttributeValue<EntityReference>("rsa_classofbusinessroi");
                    EntityReference enRoiPandl = entity.GetAttributeValue<EntityReference>("rsa_plroi");
                    if (enRoiCOBName != null)
                    {
                        Entity enCOB = service.Retrieve(enRoiCOBName.LogicalName, enRoiCOBName.Id, new ColumnSet(true));
                        if (enCOB.Attributes.Contains("rsa_name"))
                        {
                            ocobROIName = WebUtility.HtmlEncode(Convert.ToString(enCOB["rsa_name"]));
                            tracer.Trace("ocobROIName: " + ocobROIName);

                        }
                    }

                    //pass value from  opportunity  to update BAM for Marine
                    if (enPandl != null && enPandl.Name != null && enPandl.Id != guidEmpty
                        && enCOBName != null && enCOBName.Name != null && enCOBName.Id != guidEmpty &&
                            entity.Attributes.Contains("parentaccountid") && ((EntityReference)entity["parentaccountid"]).Id != guidEmpty
                           && !lobName.ToLowerInvariant().Contains("roi") && !lobName.ToLowerInvariant().Contains("new business - ni"))
                    //  NI to be skipped
                    {
                        tracer.Trace("lobName: " + lobName);
                        plname = WebUtility.HtmlEncode(((EntityReference)entity["rsa_pandlid"]).Name);
                        tracer.Trace("plname: " + plname);
                        ocobName = WebUtility.HtmlEncode(enCOBName.Name);
                        tracer.Trace("ocobName: " + enCOBName.Name);
                        brokerId = ((EntityReference)entity["parentaccountid"]).Id;
                        tracer.Trace("brokerId: " + brokerId);
                        BAMUser = this.getBAMUser(service, tracer, plname, ocobName, brokerId);
                        tracer.Trace("BAM Line 405: " + BAMUser);
                        if (BAMUser != Guid.Empty)
                        {
                            entity["rsa_bdaownerbam"] = new EntityReference("systemuser", BAMUser);
                            tracer.Trace("Updated BAM user in opportunity: " + BAMUser);
                        }
                    }

                    //pass value from ROI opportunity entity to update BAM
                    if ((lobName.ToLowerInvariant().Contains("roi") || lobName.ToLowerInvariant().Contains("new business - ni")) && enPlROI != null &&
                        enPlROI.Name != null && enPlROI.Id != guidEmpty
                        && ocobROIName != null
                            && entity.Attributes.Contains("parentaccountid") && ((EntityReference)entity["parentaccountid"]).Id != guidEmpty)

                    {
                        tracer.Trace("lobName: " + lobName);
                        plname = WebUtility.HtmlEncode(((EntityReference)entity["rsa_plroi"]).Name);
                        tracer.Trace("ROI plname: " + plname);

                        tracer.Trace("ROI ocobName: " + ocobROIName);
                        brokerId = ((EntityReference)entity["parentaccountid"]).Id;
                        tracer.Trace("brokerId: " + brokerId);
                        BAMUser = this.getBAMUser(service, tracer, plname, ocobROIName, brokerId);
                        tracer.Trace("BAM Line 429: " + BAMUser);
                        if (BAMUser != Guid.Empty)
                        {
                            entity["rsa_bdaownerbam"] = new EntityReference("systemuser", BAMUser);
                            tracer.Trace("Updated BAM user for ROI  opportunity: " + BAMUser);
                        }
                    }


                    #endregion

                }

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                CrmPluginHelper.CatchFaultException(ex, this);
            }
            catch (InvalidPluginExecutionException ex)
            {
                CrmPluginHelper.CatchInvalidPluginException(ex);
            }
            catch (Exception ex)
            {
                CrmPluginHelper.CatchGenericException(ex, this);
            }
        }
        public int? RetrieveCurrentUsersSettings(IOrganizationService service)

        {

            var currentUserSettings = service.RetrieveMultiple(

                new QueryExpression("usersettings")

                {

                    ColumnSet = new ColumnSet("timezonecode"),

                    Criteria = new FilterExpression

                    {

                        Conditions =

                        {

                            new ConditionExpression("systemuserid", ConditionOperator.EqualUserId)

                        }

                    },
                    NoLock = true

                }).Entities[0].ToEntity<Entity>();

            //return time zone code

            return (int?)currentUserSettings.Attributes["timezonecode"];

        }
        ///

        ///  Retrive the local time from the UTC time.

        ///

        /// UTC Date time which needs to convert to Local DateTime

        /// TimeZoneCode

        /// IOrganizationService service

        ///

        public DateTime RetrieveLocalTimeFromUTCTime(DateTime utcTime, int? timeZoneCode, IOrganizationService service)

        {

            if (!timeZoneCode.HasValue)

                return DateTime.Now;

            var request = new LocalTimeFromUtcTimeRequest

            {

                TimeZoneCode = timeZoneCode.Value,

                UtcTime = utcTime.ToUniversalTime()

            };

            var response = (LocalTimeFromUtcTimeResponse)service.Execute(request);

            return response.LocalTime;

        }

        private Guid getBAMUser(IOrganizationService service, ITracingService tracingService, string plname, string cobName, Guid brokerId)
        {
            Guid userGuid = Guid.Empty;
            string BDMrole = string.Empty;
            var fetchXml = @"<fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>
                                <entity name='rsa_salesteamroles'>
                                <attribute name='rsa_salesteamrolesid'/>
                                <attribute name='rsa_name'/>
                                <attribute name='createdon'/>
                                <attribute name='rsa_salesmanagerrolename'/>
                                <attribute name='rsa_pl'/>
                                <attribute name='rsa_classofbusiness'/>
                                <attribute name='rsa_bdmrolename'/>
                                <order descending='false' attribute='rsa_name'/>
                                <link-entity name='rsa_pl' alias='aa' link-type='inner' to='rsa_pl' from='rsa_plid'>
                                <filter type='and'>
                                <condition attribute='rsa_name' value='{0}' operator='eq'/>
                                </filter>
                                </link-entity>
                                <link-entity name='rsa_classofbusiness' alias='ab' link-type='inner' to='rsa_classofbusiness' from='rsa_classofbusinessid'>
                                <filter type='and'>
                                <condition attribute='rsa_name' value='{1}' operator='eq'/>
                                </filter>
                                </link-entity>
                                </entity>
                                </fetch>";

            try
            {
                cobName = cobName.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;");
                plname = plname.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;");

                var enOwnerDetails = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, plname, cobName)));
                if (enOwnerDetails != null && enOwnerDetails.Entities.Count > 0)
                {
                    tracingService.Trace("BDMrole fetching");
                    BDMrole = enOwnerDetails[0].Attributes.Contains("rsa_bdmrolename") ? Convert.ToString(enOwnerDetails[0].Attributes["rsa_bdmrolename"]) : string.Empty;
                    tracingService.Trace("BDMrole:" + BDMrole);
                    if (BDMrole != string.Empty)
                    {
                        var fetchXmlBAMUser = @"<fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>
                                                    <entity name='connection'>
                                                    <attribute name='record2id'/>
                                                    <attribute name='record2roleid'/>
                                                    <attribute name='connectionid'/>
                                                    <order descending='false' attribute='record2id'/>
                                                    <filter type='and'>
                                                    <condition attribute='record1id' value='{0}' uitype='account' operator='eq'/>
                                                    </filter>
                                                    <link-entity name='connectionrole' alias='ae' link-type='inner' to='record2roleid' from='connectionroleid'>
                                                    <filter type='and'>
                                                    <condition attribute='name' value='{1}' operator='eq'/>
                                                    </filter>
                                                    </link-entity>
                                                    </entity>
                                                    </fetch>";

                        try
                        {
                            EntityCollection BAMUserDetails = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXmlBAMUser, brokerId, BDMrole)));//convert to entitycollection
                            if (BAMUserDetails != null && BAMUserDetails.Entities.Count > 0)
                            {
                                userGuid = BAMUserDetails[0].Attributes.Contains("record2id") ? ((EntityReference)BAMUserDetails[0].Attributes["record2id"]).Id : Guid.Empty;
                                tracingService.Trace("userGuid:" + userGuid.ToString());
                            }
                        }
                        catch (Exception ex)
                        {
                            tracingService.Trace("Exception while fetching BAMUserDetails in getBAMUser:" + ex.Message);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetching enOwnerDetails in getBAMUser:" + ex.Message);
            }
            return userGuid;
        }

        /// <summary>
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <returns></returns>
        private Entity PopulateOpportunityFields(IOrganizationService service, ITracingService tracingService, EntityReference lineofbuisness ,Entity entity)
        {
            string strCustomerName = string.Empty;

            var enOpportunity = new Entity("opportunity");
            try
            {
                // Populate default values of opportunity for different sources, not for Renewal
                //1. fetch RSA custom label for default values config. 
                // Dependentoptionset // JSON parsing
                //List of default values.. populate if doesnt contain data
                tracingService.Trace("Fetch custom Label for default values of currency and decimal");
                QueryExpression CustomLblDefaultvalue = new QueryExpression("rsa_customlabel");
                CustomLblDefaultvalue.TopCount = 1;
                CustomLblDefaultvalue.NoLock = true;
                CustomLblDefaultvalue.ColumnSet = new ColumnSet(new string[] { "rsa_dependentoptionsetjson", "rsa_name" });
                ConditionExpression cond = new ConditionExpression();
                cond.AttributeName = "rsa_opportunitylob";
                cond.Operator = ConditionOperator.Equal;
                // cond.Values.Add(lob.Id);
                cond.Values.Add(lineofbuisness.Id);
                CustomLblDefaultvalue.Criteria.AddCondition(cond);
                EntityCollection customLblColl = service.RetrieveMultiple(CustomLblDefaultvalue);
                tracingService.Trace("Fetch custom Label for default values count :" + customLblColl.Entities.Count + "---" + lineofbuisness.Id + "--" + lineofbuisness.Id);
                RSAcustomlabelJson rSAcustomlabelJson = new RSAcustomlabelJson();
                foreach (var item in customLblColl.Entities)
                {

                    string decimalDefaultJson = item.Attributes.Contains("rsa_dependentoptionsetjson") ? Convert.ToString(item.Attributes["rsa_dependentoptionsetjson"]) : string.Empty;
                    tracingService.Trace("DefaultJSON found");
                    //Parse this string to object 
                    var ms = new MemoryStream(Encoding.UTF8.GetBytes(decimalDefaultJson));
                    var ser = new DataContractJsonSerializer(rSAcustomlabelJson.GetType());
                    rSAcustomlabelJson = ser.ReadObject(ms) as RSAcustomlabelJson;
                    ms.Close();
                    tracingService.Trace("Start populating data");
                    List<ParentFieldDependency> prtDependency = rSAcustomlabelJson.ParentFieldDependency;
                    foreach (var decimalCollectionItem in prtDependency)
                    {
                        List<DecimalCurrencyfield> DecimalDependency = decimalCollectionItem.DecimalCurrencyfields;

                        foreach (var decimalitem in DecimalDependency)
                        {
                            if (decimalitem.DataType != null)
                            {
                                tracingService.Trace("Attribute Schema : " + decimalitem.DependentField);
                                if (entity.Attributes.Contains(decimalitem.DependentField))
                                {
                                     tracingService.Trace("Attribute Schema present in existing object ");
                                    switch (decimalitem.DataType.ToLower())
                                    {
                                        case "money":
                                            entity[decimalitem.DependentField] = ((Money)entity[decimalitem.DependentField]).Value != 0.00M ? entity[decimalitem.DependentField] : new Money(0.00M);
                                            break;
                                        case "decimal":
                                            entity[decimalitem.DependentField] = Convert.ToDecimal(entity[decimalitem.DependentField]) != 0.00M ? entity[decimalitem.DependentField] : 0.00M;
                                            break;
                                        default:
                                            break;
                                    }
                                }
                                else
                                {
                                    tracingService.Trace("Attribute Schema not present in existing object hence marking it as 0.00");
                                    switch (decimalitem.DataType.ToLower())
                                    {
                                        case "money":
                                            entity[decimalitem.DependentField] = new Money(0.00M);
                                            break;
                                        case "decimal":
                                            entity[decimalitem.DependentField] = 0.00M;
                                            break;
                                        default:
                                            break;
                                    }
                                }
                            }
                        }
                    }
                }
                //

                tracingService.Trace("Population of opportunity completed");

            }
            catch (Exception ex)
            {
                tracingService.Trace("Opportunity population failed: " + ex.Message);
                enOpportunity = null;
            }
            return enOpportunity;
        }

    }
    public class OptionSet
    {
        //  [DataMember]
        public string DependentField { get; set; }
        //[DataMember]
        public string ApplicableValue { get; set; }
    }
    public class LookUp
    {
    }
    [DataContract]
    public class DecimalCurrencyfield
    {
        [DataMember]
        public string DependentField { get; set; }
        [DataMember]
        public int DefaultValue { get; set; }
        [DataMember]
        public string DataType { get; set; }
    }

    [DataContract]
    public class ParentFieldDependency
    {
        [DataMember]
        public List<OptionSet> OptionSet { get; set; }
        [DataMember]
        public List<LookUp> LookUp { get; set; }
        [DataMember]
        public List<DecimalCurrencyfield> DecimalCurrencyfields { get; set; }
    }

    [DataContract]
    public class RSAcustomlabelJson
    {
        [DataMember]
        public string ParentField { get; set; }
        [DataMember]
        public List<ParentFieldDependency> ParentFieldDependency { get; set; }
    }
}
