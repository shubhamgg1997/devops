﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using RSA.Crm.Plugins;
using System;
using RSA.CSI.Plugins.Utility;
using RSA.CSI.Plugins.OpportunityLogic;
using System.Collections.Generic;
using System.ServiceModel;

namespace RSA.CSI.Plugins.Opportunity
{
    public class OpportunityNamePostUpdate : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService tracer = null;
            IPluginExecutionContext context = null;
            IOrganizationService service = null;

            CrmPluginHelper.Initialise(serviceProvider, ref context, ref service, ref tracer, false);
            tracer.Trace("context.Depth:{0}", context.Depth);
            if (context.Depth > 1)
            {
                return;
            }
            try
            {
                if ((context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity) && context.MessageName.ToLowerInvariant() == "update" && context.Stage == 40)
                {
                    string messageName = context.MessageName.ToLowerInvariant();
                    tracer.Trace("Instace created and target is avaialble.");
                    tracer.Trace("Instace created and target is avaialble12.");
                    Entity postImage = (Entity)context.PostEntityImages["PostImage"];
                    tracer.Trace("check postimage");
                    DateTime closeDate = DateTime.MinValue;
                    tracer.Trace("check closeDate");
                    EntityReference encustomer = null;
                    tracer.Trace("check 1");
                    EntityReference encob = null;
                    EntityReference enLob = null;
                    EntityReference enPl = null;
                    tracer.Trace("check 2");
                    string cobname = string.Empty;
                    string lobName = string.Empty;
                    string customerName = string.Empty;
                    string plName = string.Empty;
                    string plNameROI = string.Empty;
                    if (postImage.Attributes.Contains("rsa_pandlid"))
                    {
                        tracer.Trace(" P&L is there ");
                        enPl = postImage.Attributes.Contains("rsa_pandlid") ? postImage.GetAttributeValue<EntityReference>("rsa_pandlid") : null;
                        if (enPl.Name != null && enPl.Name != string.Empty)
                            plName = enPl.Name;
                        tracer.Trace("plName "+ plName);
                    }
                    if (postImage.Attributes.Contains("rsa_classofbusiness"))
                    {
                        tracer.Trace("Entered Post ");
                        encob = postImage.Attributes.Contains("rsa_classofbusiness") ? postImage.GetAttributeValue<EntityReference>("rsa_classofbusiness") : null;
                        if (encob.Name != null && encob.Name != string.Empty)
                            cobname = encob.Name;
                        tracer.Trace("cobname "+ cobname);
                    }
                    if (postImage.Attributes.Contains("rsa_lineofbusiness"))
                    {
                        tracer.Trace("line of business is there ");
                        enLob = postImage.Attributes.Contains("rsa_lineofbusiness") ? postImage.GetAttributeValue<EntityReference>("rsa_lineofbusiness") : null;
                        if (enLob.Name != null && enLob.Name != string.Empty)
                            lobName = enLob.Name;
                        tracer.Trace("line of busines is "+ lobName);
                    }
                    if (postImage.Attributes.Contains("rsa_customer"))
                    {
                        encustomer = postImage.Attributes.Contains("rsa_customer") ? postImage.GetAttributeValue<EntityReference>("rsa_customer") : null;
                        if (encustomer.Name != null && encustomer.Name != string.Empty) {
                            customerName = encustomer.Name;
                            tracer.Trace("encustomer:{0}", customerName);
                        } }
                    if (postImage.Attributes.Contains("rsa_closedate"))
                    {
                        closeDate = postImage.Attributes.Contains("rsa_closedate") ? postImage.GetAttributeValue<DateTime>("rsa_closedate") : DateTime.MinValue;
                        tracer.Trace("closeDate:{0}", closeDate.Year);
                    }
                    if ((lobName.ToLowerInvariant().Contains("new business - ni") || lobName.ToLowerInvariant().Contains("new business - roi"))&&(closeDate != DateTime.MinValue || plName != null || customerName != null)) {
                        tracer.Trace("LOB Contains NI or ROI");
                        EntityReference enPlROI = postImage.Attributes.Contains("rsa_plroi") ? postImage.GetAttributeValue<EntityReference>("rsa_plroi") : null;
                        if (enPlROI != null && !string.IsNullOrEmpty(enPlROI.Name))
                        {
                            plNameROI = enPlROI.Name;
                            tracer.Trace("plNameROI " + plNameROI);

                            postImage["name"] = customerName + "-" + plNameROI + "-" + closeDate.Year;

                            tracer.Trace("name is" + customerName + "-" + plNameROI + "-" + closeDate.Year);
                        }
                    }
                    else if((!lobName.ToLowerInvariant().Contains("new business - ni") || !lobName.ToLowerInvariant().Contains("new business - roi")) && (closeDate != DateTime.MinValue || customerName!=null|| cobname!= null)) {
                        tracer.Trace("LOB does not Contains NI or ROI");
                        postImage["name"] = customerName + "-" + cobname + "-" + closeDate.Year;
                    }
                    if (closeDate!=DateTime.MinValue) {
                        postImage["rsa_opportunityrenewalmonth"] = closeDate.ToString("MMMM"); //bug 1862
                    }
                   
                    service.Update(postImage);
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                CrmPluginHelper.CatchFaultException(ex, this);
            }
            catch (InvalidPluginExecutionException ex)
            {
                CrmPluginHelper.CatchInvalidPluginException(ex);
            }
            catch (Exception ex)
            {
                CrmPluginHelper.CatchGenericException(ex, this);
            }
        }
    }
    
}