﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSA.CSI.Common.Constants
{
    public class AISMessage
    {
        public const string EntityName = "rsa_aismessage";
        public const string EntityId = "rsa_aismessageid";

        public const string PolicyNumber = "rsa_policynumber";
        public const string QuoteNumber = "rsa_quotenumber";
        public const string MessageType = "rsa_messagetype";
        public const string Owner = "ownerid";
        public const string CreatedOn = "createdon";
        public const string MessageStatus = "rsa_messagestatus";
        public const string CustomerBusinessName = "rsa_customerbusinessname";
        public const string CustomerName = "rsa_customername";
        public const string CustomerPostCode = "rsa_customerpostcode";
        public const string CustomerPhysicalAddress = "rsa_customerphysicaladdress";
        public const string CustomerDuplicateCheckStatus = "rsa_customerduplicatecheckstatus";
        public const string CustomerMiddleName = "rsa_customermiddlename";
        public const string PhysicalAddressFinal = "rsa_physicaladdressfinal";
        public const string AgentCode = "rsa_agentcode";
        public const string AgentName = "rsa_agentname";
        public const string AnnualPremiumIncludingTaxes = "rsa_annualpremiumincludingtaxes";
        public const string TransactionalPremiumIncludingTaxes = "rsa_transactionalpremiumincludingtaxes";
        public const string RevisedPremium = "rsa_revisedpremium";
        public const string Premium = "rsa_premium";
        public const string AnnualRevisedPremium = "rsa_annualrevisedpremium";
        public const string TransactionalRevisedPremium = "rsa_transactionalrevisedpremium";
        public const string PrimaryReference = "rsa_primaryreference";
        public const string QuotePolicyNumber = "rsa_quotepolicynumber";
        public const string QuotePolicyStatus = "rsa_quotepolicystatus";
        public const string QuotePolicyStatusPL = "rsa_quotepolicystatus1";
        public const string QuotePolicyVersion = "rsa_quotepolicyversion";
        public const string CodeToRelatedQuotesPolicies = "rsa_codetorelatequotespolicies";
        public const string PolicyRenewalDate = "rsa_policyrenewaldate";
        public const string EffectiveDate = "rsa_effectivedate";
        public const string QuoteExpirationDate = "rsa_quoteexpirationdate";
        public const string InceptionDate = "rsa_inceptiondate";
        public const string RenewalIndicator = "rsa_renewalindicator";
        public const string ReasonForDivertDecline = "rsa_reasonfordivertdecline";
        public const string ReasonForDivertDeclinePL = "rsa_reasonfordivertdecline1";
        public const string RetryCount = "rsa_retrycount";
        public const string Scheme = "rsa_schemeid";
        public const string SchemePL = "rsa_schemecode";
        public const string SchemeDescription = "rsa_schemedescription";
        public const string BlanketCertificateIndicator = "rsa_blanketcertificateindicator";
        public const string RelatedPolicy = "rsa_relatedpolicy";
        public const string Broker = "rsa_brokerid";
        public const string Customer = "rsa_possiblesmeduplicatelinkid";
        public const string RouteOfSale = "rsa_routeofsale";
        public const string PLCode = "rsa_plcode";
        public const string ClassOfBusiness = "rsa_classofbusiness";
        public const string PolicyMovementReasonId = "rsa_policymovementreasonid";
        public const string PolicyMovementType = "rsa_policymovementtype";
        public const string PolicyMovementTypeLKP = "rsa_policymovementtype1";
        public const string ProductName = "rsa_productname";
        public const string ProductCode = "rsa_productcode";
        public const string ProductId = "rsa_productid";
        public const string ModifiedOn = "modifiedon";
        public const string ErrorDescription = "rsa_errordescription";
        public const int TaskAISMessagesAction_TopCount = 25;
        public const string BrokerDoesNotExist = "Broker doesn\'t exist.";
        public const string CustomerDoesNotExist = "Customer doesn\'t exist.";
        public const string PostCodeDoesNotExist = "Post Code doesn\'t exist.";
        public const string CustPostCodeDoesNotExist = "Customer Name or Post Code doesn\'t exist.";
        public const string PolicyDoesNotExist = "Policy doesn\'t exist.";
        public const string PolicyNotProcessed = "Policy has not processed.";
        public const string QuoteDoesNotExist = "Quote doesn\'t exist.";
        public const string QuoteNotProcessed = "Quote has not processed.";
        public const string MessageTypeDoesNotExist = "Message type cannot be blank and it should be either Policy/Quote/Task.";
        public const string MessageDummyBroker= "Ignoring this record as dummy broker found";
        public const string PolicyNumberQuoteNumberDoesNotExist = "TASK SHOULD HAVE EITHER POLICY NUMBER OR QUOTE NUMBER.";
        public const string QuoteNumberPrimaryRefferenceDoesNotExist = "QUOTE SHOULD HAVE QUOTE NUMBER AND PRIMARY REFFERENCE";
        public const string AgentEmailAddress = "rsa_agentemailaddress";
        public const string AgentIndividualEmailAddress = "rsa_agentindividualemailaddress";
        public const string AgentIndividualEmailAddress3 = "rsa_agentindividualemailaddress3";
        public const string AgentIndividualEmailType = "rsa_agentindividualemailtype";
        public const string AgentIndividualMiddleName = "rsa_agentindividualmiddlename";
        public const string AgentIndividualName = "rsa_agentindividualname";
        public const string AgentIndividualPhoneNumber = "rsa_agentindividualphonenumber";
        public const string AgentIndividualPhoneNumberType = "rsa_agentindividualphonenumbertype";
        public const string AgentIndividualSurname = "rsa_agentindividualsurname";
        public const string AgentPhoneNumber = "rsa_agentphonenumber";
        public const string AgentPhoneNumberType = "rsa_agentphonenumbertype";
        public const string AgentEmailAddressType = "rsa_agentemailaddresstype";
        public const string Title = "rsa_title";
        public const string Description = "rsa_description";
        public const string CustomerPhoneNumber1 = "rsa_customerphonenumber1";
        public const string DueDate = "rsa_duedate";
        //public const string CustomerPhysicalAddress = "rsa_customerphysicaladdress";
        public const string CustomerEmailAddress1 = "rsa_customeremailaddress1";
        public const string AIS_Dummy_Broker__PrimaryRefrence= "rsa_name";

        public enum AISMessage_Status
        {
            Error = 866760000,
            New = 866760001,
            Processed = 866760002,
            ProcessedwithError = 866760003,
            Waiting = 866760004
        }
        public enum AISMessage_Message_Type
        {
            Policy = 866760000,
            Quote = 866760001,
            Task = 866760002
        }
    }

    public class Task
    {
        public const string EntityName = "task";
        public const string EntityId = "activityid";
        public const string DisplayName = "Task";

        public const string Subject = "subject";
        public const string RelatedTo = "regardingobjectid";
        public const string DueDate = "scheduledend";
        public const string owner = "ownerid";

    }

    public class Policy
    {
        public const string EntityName = "rsa_policy";
        public const string EntityId = "rsa_policyid";
        public const string DisplayName = "Policy";

        public const string Name = "rsa_name";
        public const string PolicyNumber = "rsa_policynumber";
        public const string Owner = "ownerid";
        public const string QuotePolicyVersion = "rsa_quotepolicyversion";
        public const string PolicyStatus = "rsa_policystatuscode";
        public const string PolicyKey = "rsa_policykey";
        public const string Broker = "rsa_broker";
        public const string BrokerPanel = "rsa_brokerpanel";
        public const string Customer = "rsa_customer";
        public const string CreatedOn = "createdon";
        public const string ModifiedOn = "modifiedon";
        public const string PolicySystem = "rsa_policysystemcode";
        public const string QuotePolicyStatus = "rsa_quotepolicystatuscode";
        public const string AnnualPremiumIncludingTaxes = "rsa_annualpremiumincludingtaxes";
        public const string TransactionalPremiumIncludingTaxes = "rsa_transactionalpremiumincludingtaxes";
        public const string RevisedPremium = "rsa_revisedpremium";
        public const string Premium = "rsa_premium";
        public const string AnnualRevisedPremium = "rsa_annualrevisedpremium";
        public const string TransactionalRevisedPremium = "rsa_transactionalrevisedpremium";
        public const string PrimaryReference = "rsa_primaryreference";
        public const string AgentName = "rsa_agency";
        public const string AgentCode = "rsa_agentcode";
        public const string CodetoRelateQuotesPolicies = "rsa_codetorelatequotespolicies";
        public const string PolicyRenewalDate = "rsa_policyrenewaldate";
        public const string SchemeId = "rsa_schemeid";
        public const string SchemeDescription = "rsa_schemedescription";
        public const string SchemePL = "rsa_schemecode";
        //public const string DataOrigin = "rsa_dataorigin";
        public const string DataOrigin = "rsa_dataorigincode";
        //public const string RouteOfSale = "rsa_routeofsale";
        public const string ReasonForDivertDecline = "rsa_reasonfordivertdeclinecode";
        public const string RenewalIndicator = "rsa_renewalindicator";
        public const string InceptionDate = "rsa_inceptiondate";
        public const string QuoteExpirationDate = "rsa_quoteexpirationdate";
        public const string EffectiveDate = "rsa_effectivedate";
        public const string CodeToRelatedQuotesPolicies = "rsa_codetorelatequotespolicies";
        public const string BlanketCertificateIndicator = "rsa_blanketcertificateindicator";
        public const string PolicyMovementReason = "rsa_policymovementreason";
        public const string RouteOfSale = "rsa_routeofsalecode";
        public const string SalesTeam = "rsa_salesteam";
        public const string PLCode = "rsa_plcode";
        public const string ClassOfBusiness = "rsa_classofbusiness";
        public const string PolicyMovementType = "rsa_policymovementtype";
        public const string ProductName = "rsa_productname";
        public const string ProductCode = "rsa_productcode";
        public const string ProductId = "rsa_productid";
        public const string AgeOfPolicy = "rsa_ageofpolicy";
        public const string AreaName = "rsa_areaname";
        public const string City = "rsa_city";
        public const string Country = "rsa_country";
        public const string IsDeleted = "rsa_isdeleted";
        public const string Folio = "rsa_folio";
        public const string FolioGWP = "rsa_foliogwp";
        public const string FolioPolicyHolder = "rsa_foliopolicyholder";
        public const string LicenseLevelRequiredLevel = "rsa_licenselevelrequiredlevelcode";
        public const string LicenseLevelRequiredProduct = "rsa_licenselevelrequiredproductid";
        public const string MumbaiHandler = "rsa_mumbaihandler";
        public const string NumberOfFolios = "rsa_numberoffolios";
        public const string OperationsHandlingSite = "rsa_operationshandlingsite";
        public const string Opportunity = "rsa_opportunity";
        public const string ParentPolicy = "rsa_parentpolicy";
        public const string PolicyCancellationDate = "rsa_policycancellationdate";
        public const string PolicyCount = "rsa_policycount";
        public const string PolicyDescription = "rsa_policydescription";
        //public const string PolicyKey = "rsa_policykey";
        public const string PolicyHandler = "rsa_policyhandler";
        public const string PolicyStartDate = "rsa_policystartdate";
        public const string PolicyTrader = "rsa_policytrader";
        public const string PostCode = "rsa_postcode";
        public const string Renewable = "rsa_renewable";
        public const string RenewalGenerationCaseAssignStatus = "rsa_renewalgenerationcaseassignstatuscode";
        public const string RenewalGenerationFailReason = "rsa_renewalgenerationfailreason";
        public const string RenewalGenerationId = "rsa_renewalgenerationid";
        public const string RenewalGenerationStatus = "rsa_renewalgenerationstatuscode";
        public const string ReviewType = "rsa_reviewtypecode";
        public const string StagingId = "rsa_stagingid";
        public const string StateCounty = "rsa_statecounty";
        public const string StreetAddress = "rsa_streetaddress";
        public const string SystemModStamp = "rsa_systemmodstamp";
        public const string TradingHandlingSite = "rsa_tradinghandlingsite";




        public enum Policy_System
        {
            AIS = 866760000,
            UKRIS = 866760001,
            SICS = 866760002,
            SICLOPS = 866760003,
            ATLAS = 866760004,
            SYNERGY = 866760005,
            EPOQ = 866760006
        }

        #region Commented unused code
        /*
        public enum Quote_Policy_Status
        {
            Live = 860000,
            Cancelled = 860001,
            Pending = 860002,
            Suspended = 860008,
            Complete = 860003,
            ConvertedTo = 860004,
            Expired = 860005,
            NoQuote = 860006,
            NotTakenUp = 860007
        }
        public enum Policy_Status
        {
            Live = 860000,
            Cancelled = 860001,
            Pending = 860002,
            Suspended = 860003,
            Complete = 860004,
            ConvertedTo = 860005,
            Expired = 860006,
            NoQuote = 860007,
            NotTakenUp = 860008
        }

        public enum Data_Origin
        {
            DataMigration = 86001,
            Integration = 86002,
            EndUser = 86000
        }

        public enum Route_Of_Sale
        {
            EDI = 860001,
            iMarke = 860000,
            Traditional = 860002
        }
        public enum Reason_For_Divert_Decline
        {
            Reason1 = 860000,
            Reason2 = 860001
        }
        */
        #endregion Commented unused code
    }

    public class Quote
    {
        public const string EntityName = "rsa_rsaquote";
        public const string EntityId = "rsa_rsaquoteid";
        public const string DisplayName = "Quote";

        public const string Name = "rsa_name";
        public const string Customer = "rsa_customerid";
        public const string Broker = "rsa_brokerid";
        public const string Owner = "ownerid";
        public const string ModifiedOn = "modifiedon";
        public const string AgentCode = "rsa_agentcode";
        public const string Brokerid = "rsa_brokerid";
        public const string SchemeId = "rsa_schemeid";
        public const string ProductName = "rsa_productname";
        public const string ProductCode = "rsa_productcode";
        public const string AnnualPremiumincludingTaxes = "rsa_annualpremiumincludingtaxes";
        public const string AnnualRevisedPremium = "rsa_annualrevisedpremium";
        public const string RevisedPremium = "rsa_revisedpremium";
        public const string TransactionalPremiumincludingtaxes = "rsa_transactionalpremiumincludingtaxes";
        public const string TransactionalRevisedPremium = "rsa_transactionalrevisedpremium";
        public const string Premium = "rsa_premium";
        public const string QuoteExpirationDate = "rsa_quoteexpirationdate";
        public const string ReasonforDivertDecline = "rsa_reasonfordivertdecline";
        public const string SchemeDescription = "rsa_schemedescription";
        public const string PrimaryReference = "rsa_primaryreference";
        public const string AgentName = "rsa_agentname";
        public const string QuotePolicyStatus = "rsa_quotepolicystatus";
        public const string QuotePolicyVersion = "rsa_quotepolicyversion";
        public const string CodetorelateQuotesPolicies = "rsa_codetorelatequotespolicies";
        public const string PolicyRenewalDate = "rsa_policyrenewaldate";
        public const string PolicyMovementType = "rsa_policymovementtypeid";
        public const string PolicyMovementReasonId = "rsa_policymovementreasonid";
        public const string EffectiveDate = "rsa_effectivedate";
        public const string InceptionDate = "rsa_inceptiondate";
        public const string RenewalIndicator = "rsa_renewalindicator";
        public const string RouteOfsale = "rsa_routeofsale";
        public const string ReletedPolicy = "rsa_relatedpolicyid";
        public const string PL = "rsa_pl";
        public const string ClassOfBusiness = "rsa_classofbusiness";
        public const string QuoteSystem = "rsa_quotesystem";
        public const string TotalAmount = "totalamount";
        public const string ProductId = "rsa_products";
        public const string IsDeleted = "rsa_isdeleted";
        public const string SystemModStamp = "rsa_systemmodstamp";
    }

    public class Customer
    {
        public const string EntityName = "rsa_customer";
        public const string EntityId = "rsa_customerid";
        public const string DisplayName = "Customer";

        public const string Name = "rsa_name";
        public const string ExternalId = "rsa_rsaexternalid";
        public const string ModifiedOn = "modifiedon";
        public const string Street = "rsa_street";
        public const string PostalCode = "rsa_rsapostalcode";
        public const string Keyword = "rsa_rsacustomerkeyword";
        public const string KeywordPrefix3Value = "rsa_rsakeywordprefix3value";
        public const string KeywordCheckName = "rsa_keywordcheckname";
    }

    public class AgencyCode
    {
        public const string EntityName = "rsa_agencycode";
        public const string EntityId = "rsa_agencycodeid";
        public const string DisplayName = "AgencyCode";

        public const string Name = "rsa_name";
        public const string Agency = "rsa_agency";
        public const string ModifiedOn = "modifiedon";
    }

    public class Broker
    {
        public const string EntityName = "account";
        public const string EntityId = "accountid";
        public const string DisplayName = "Broker";
        public const string PrimaryReference = "rsa_primaryreference";
        public const string Name = "name";
        public const string ModifiedOn = "modifiedon";
        public const string PrimaryContactId = "primarycontactid";
    }

    public class RSACustomLabel
    {
        public const string EntityName = "rsa_customlabel";
        public const string EntityId = "rsa_customlabelid";
        public const string DisplayName = "RSACustomLabel";

        public const string Name = "rsa_name";
        public const string Values = "rsa_values";
        public const string ShortDescription = "rsa_shortdescription";
        public const string Categories = "rsa_categories";
        public const string ModifiedOn = "modifiedon";
        public const string CL0034_Policy_Status = "CL0034_Policy_Status";

        public static object AIS_Dummy_Broker__PrimaryRefrence = "AIS_Dummy_Broker__PrimaryRefrence";
    }

    public class PolicyMovementType
    {
        public const string EntityName = "rsa_policymovementtype";
        public const string EntityId = "rsa_policymovementtypeid";
        public const string DisplayName = "PolicyMovementType";

        public const string Name = "rsa_name";
        public const string ModifiedOn = "modifiedon";
    }

    public class RSAProduct
    {
        public const string EntityName = "rsa_product";
        public const string EntityId = "rsa_productid";
        public const string DisplayName = "RSAProduct";

        public const string Name = "rsa_name";
        public const string PAndLId = "rsa_pandlid";
        public const string ClassOfBusinessId = "rsa_classofbusinessid";
        public const string ModifiedOn = "modifiedon";
    }

    public class Case
    {
        public const string EntityName = "incident";
        public const string EntityId = "incidentid";
        public const string DisplayName = "Case";

        public const string Title = "title";
        public const string PolicyId = "rsa_policyid";
        public const string Broker = "rsa_account";
        public const string Customer = "rsa_customerrsa";
        public const string CustomerId = "customerid";
        public const string Subject = "rsa_subject";
        public const string Description = "description";
        public const string AISTaskDueDate = "rsa_aistaskduedate";
        public const string CustomerPhysicalAddress = "rsa_customerphysicaladdress";
        public const string CustomerPostCode = "rsa_customerpostcode";
        public const string CustomerPhoneNumber1 = "rsa_customerphonenumber1";
        public const string CustomerEmailAddress1 = "rsa_customeremailaddress1";
        public const string RouteOfSale = "rsa_routeofsale";
        public const string PrimaryContactId = "primarycontactid";
        public const string QuoteId = "rsa_quoteid";
        public const string ModifiedOn = "modifiedon";
        public const string CaseType = "rsa_casetype";
        public const string Status = "rsa_status";
        public const string OwnerName = "ownerid";
        public const string CaseOrigin = "caseorigincode";
        public const string AISPrimaryReference = "rsa_aisprimaryreference";
        public const string Product = "rsa_product_w";
        public const string ProductSMEMiniFleet = "SME Minifleet";
        public const string SMEiMarketMotor = "51a560d2-8230-eb11-bf68-000d3a7fcea9";
        public const string SMEiMarketNonMotor = "53a560d2-8230-eb11-bf68-000d3a7fcea9";
        public const string SMEBPO = "3da560d2-8230-eb11-bf68-000d3a7fcea9";
        public enum Case_Origin
        {
            AIS = 866760004
        }
    }

    public class AISMessageNotification
    {
        public const string EntityName = "rsa_aismessagenotification";
        public const string EntityId = "rsa_aismessagenotificationid";
        public const string DisplayName = "AIS Message Notification";

        public const string AISMessage = "rsa_aismessage";
        public const string Case = "rsa_case";
        public const string MethodName = "rsa_methodname";
        public const string Policy = "rsa_policy";
        public const string Quote = "rsa_quote";
        public const string SystemDefinedError = "rsa_systemdefinederror";
        public const string Type = "rsa_type";
        public const string UserDefinedError = "rsa_userdefinederror";

        public enum AISMessageNotification_Type
        {
            Error = 866760000,
            Success = 866760001
        }
    }

    public class SMECustomerStaging
    {
        public const string EntityName = "rsa_smecustomerstaging";
        public const string EntityId = "rsa_smecustomerstagingid";
        public const string DisplayName = "SME customer staging";

        public const string AISMessage = "rsa_aismessageid";
        public const string Case = "rsa_caseid";
        public const string CustomerBusinessName = "rsa_customerbusinessname";
        public const string CustomerKeyword = "rsa_customerkeyword";
        public const string CustomerName = "rsa_customername";
        public const string CustomerNameBigrams = "rsa_customernamebigrams";
        public const string CustomerNameFinal = "rsa_customernamefinal";
        public const string CustomerNameStripped = "rsa_customernamestripped";
        public const string CustomerSurname = "rsa_customersurname";
        public const string CustomerUpsertKey = "rsa_customerupsertkey";
        public const string DuplicateLikeness = "rsa_duplicatelikeness";
        public const string KeywordCheckName = "rsa_keywordcheckname";
        public const string PhysicalAddress = "rsa_physicaladdress";
        public const string PhysicalAddressFinal = "rsa_physicaladdressfinal";
        public const string Customer = "rsa_possiblesmeduplicatelinkid";
        public const string PostCodeOriginal = "rsa_postcode";
        public const string PostCodeFinal = "rsa_postcodefinal";
        public const string KeywordPrefix = "rsa_rsakeywordprefix";
        public const string KeywordPrefix3 = "rsa_rsakeywordprefix3";
        public const string KeywordPrefix3Value = "rsa_rsakeywordprefix3value";
        public const string PostCodePrefix = "rsa_rsapostcodeprefix";
        public const string StoreCaseOwner = "rsa_storecaseowner";
        public const string DuplicateCheckStatus = "rsa_duplicatecheckstatus";
        public const string Status = "rsa_status";

        public enum SMECustomerStaging_DuplicateCheckStatus
        {
            Checking = 866760000,
            Duplicate = 866760001,
            Done = 866760002,
            NoDuplicates = 866760003
        }

        public enum SMECustomerStaging_Status
        {
            Error = 866760000,
            Processed = 866760001,
            ProcessedWithError = 866760002,
            Waiting = 866760003
        }
    }
}
