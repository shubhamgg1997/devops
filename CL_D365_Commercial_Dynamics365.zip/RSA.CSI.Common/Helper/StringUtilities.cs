﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace RSA.CSI.Plugins.Helper
{
    public static class StringUtilities
    {
        #region Regx Constants
        private static String regex1 = "[^\\d\\w\\s]+|\\s(?=\\s)|(\\s|^)(limited|ltd|plc|llp|and|uk)(?=\\s|(\\s)*$)";
        private static String regex2 = "[^\\d\\w\\s]";
        private static String regex3 = "[^\\d\\w\\s]+|\\s(?=\\s)|(\\s|^)" +
                        "(limited|ltd|plc|llp|company|associat(es?|ion)" +
                        "|dece?a?s?e?d?" +
                        "|account(ing|ants?)" +
                        "|agency|advertising|services?" +
                        "|and|uk|mrs?|road|street)(?=\\s|(\\s)*$)";
        private static String regex4 = "[^\\d\\w\\s]+|\\s(?=\\s)|(\\s|^)(limited|ltd|plc|llp|company|associat(es?|ion)|dece?a?s?e?d?|account(ing|ants?)|agency|international|management|group|advertising|services?|and|uk|mrs?|road|street)(?=\\s|(\\s)*$)";
        private static String regex5 = "[^\\d\\w\\s]+|\\s(?=\\s)|(\\s|^)[^\\d\\w\\s]*(limited|ltd|plc|llp|company|associat(es?|ion)|dece?a?s?e?d?|account(ing|ants?)|agency|international|management|group|advertising|services?|and|uk|mrs?|road|street)[^\\d\\w\\s]*(?=\\s|(\\s)*$)";
        private static String regex6 = "(?<=\\S)[^\\d\\w\\s](?=[\\d\\w])";
        private static String regex7 = "[^\\d\\w\\s]+|\\s(?=\\s)|(\\s|^)[^\\d\\w\\s]*(limited?|ltd|co|plc|ll(p|c)?|sons|compan(y|ies)|associat(es?|ion)|account(ing|ants?)|agency|international|europe|management|group|advertising|servi?c?e?s?|propert(y|ies)?|investments?|solutions?|distributions?|restaurants?|enterprises?|holdings?|and|uk|m(rs|iss|r|s)|road|street|dece?a?s?e?d?)[^\\d\\w\\s]*(?=\\s|(\\s)*$)";
        private static String regex8 = "[^\\d\\w\\s]+|\\s(?=\\s)|(\\s|^)[^\\d\\w\\s]*(limited?|ltd|co|plc|ll(p|c)?|sons|compan(y|ies)|associat(es?|ion)|agency|international|europe|management|group|servi?c?e?s?|enterprises?|holdings?|and|uk|m(rs|iss|r|s)|road|street|dece?a?s?e?d?)[^\\d\\w\\s]*(?=\\s|(\\s)*$)";

        private static String regex9 = "[^\\d\\w\\s]+";
        private static String regex10 = "\\s(?=\\s)|(\\s|^)[^\\d\\w\\s]*(limited?|ltd|co|plc|ll(p|c)?|sons|compan(y|ies)|associat(es?|ion)|agency|international|europe|management|group|servi?c?e?s?|enterprises?|holdings?|and|uk|m(rs|iss|r|s)|road|street|dece?a?s?e?d?)[^\\d\\w\\s]*(?=\\s|(\\s)*$)";
        #endregion Regx Constants

        public static String TrimString(string s1)
        {
            String output = string.Empty;
            Regex rgex;
            if (!String.IsNullOrEmpty(s1))
            {
                output = s1.ToLower().Trim();
                rgex = new Regex(regex6);
                output = rgex.Replace(output, " ");
                rgex = new Regex(regex9);
                output = rgex.Replace(output, " ");
                rgex = new Regex(regex10);
                output = rgex.Replace(output, "");
            }
            return output.Trim();
        }

        /// <summary>
        /// Pass the Input Parameters Array and String and Get Job Details in Return
		/// Get Return as String
        /// </summary>
        /// <param name="valueList"></param>
        /// <param name="separator"></param>
        /// <returns></returns>
        public static String ListToString(string[] valueList, String separator)
        {
            String valueString = null;
            if (valueList != null && !String.IsNullOrEmpty(separator))
            {
                foreach (var value in valueList)
                {
                    if (String.IsNullOrEmpty(valueString)) valueString = value;
                    else if (valueString.Length + value.Length < 255)
                        valueString += separator + value;
                }
            }
            return valueString;
        }

        public static String GetKeyWords(String s)
        {
            String keyword = null;
            String[] parts = Split(s, " ");
            foreach (var part in parts)
            {
                if (part.Trim().Length > 3)
                {
                    String partStart = part.Trim().Substring(0, 2);
                    if (!IsNumeric(partStart))
                    { keyword = part.ToUpper(); break; }
                }
            }
            if (String.IsNullOrEmpty(keyword))
            {
                foreach (var part in parts)
                {
                    if (part.Trim().Length > 2)
                    {
                        String partStart = part.Trim().Substring(0, 1);
                        if (!IsNumeric(partStart))
                        { keyword = part.ToUpper(); break; }
                    }
                }
            }
            if (String.IsNullOrEmpty(keyword) && parts.Length > 0)
            {
                foreach (var part in parts)
                {
                    if (part.Trim().Length > 2)
                    {
                        keyword = part.ToUpper(); break;
                    }
                }
            }
            return keyword;
        }

        public static string[] Split(this string toSplit, string splitOn)
        {
            return toSplit.Split(new string[] { splitOn }, StringSplitOptions.None);
        }

        public static Boolean IsNumeric(String intStr)
        {
            var regex = "[^0-9.-]";
            if (String.IsNullOrEmpty(intStr)) return false;
            // Remove all non-digits
            String testStr = regex.Replace(intStr, "");
            // Same length?
            if (testStr.Length != intStr.Length) return false;
            // Only a .?
            if (testStr.Equals(".")) return false;
            // More than one .?
            if (testStr.IndexOf('.') > -1 && testStr.IndexOf('.') != testStr.LastIndexOf('.')) return false;
            return true;
        }

        public static String GetKeywordPrefix3(String s)
        {
            if (!String.IsNullOrEmpty(s))
            {
                if (s.Length == 1 || s.Length == 2)
                    s = s.PadRight(1, '_');
                else if (s.Length == 3)
                    s = s.Substring(0, 3);
                return s;
            }
            return "";
        }

        /// <summary>
        /// Get days count between start date and end date excluding Sunday/Saturday
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        internal static int CalcualteBusinessDays(DateTime startDate, DateTime endDate)
        {            
            var count = 0;
            var curDate = startDate;
            while (curDate <= endDate)
            {
                var dayOfWeek = curDate.DayOfWeek;
                if (!((dayOfWeek == DayOfWeek.Saturday) || (dayOfWeek == DayOfWeek.Sunday)))
                    count++;
                curDate = curDate.AddDays(1);
            }            
            return count;

        }
    }
}