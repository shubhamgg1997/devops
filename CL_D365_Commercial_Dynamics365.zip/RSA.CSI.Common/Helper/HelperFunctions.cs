﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Json;
using System.Text;

namespace RSA.CSI.Plugins.Helper
{
    public static class HelperFunctions
    {
        #region Public Subs / Functions

        public static T GetAttributeValue<T>(string attributeName, Entity entity, Boolean suppressErrorIfNotFound = true)
        {
            T value = default(T);

            //String empty validation
            if (!string.IsNullOrEmpty(attributeName))
            {
                attributeName = attributeName.ToLowerInvariant();

                try
                {
                    //Null Validation
                    if (entity != null)
                    {
                        if (entity.Attributes.Any(item => item.Key.ToLowerInvariant().Equals(attributeName.ToLowerInvariant())))
                            value = (T)entity.Attributes.FirstOrDefault(item => item.Key.ToLowerInvariant().Equals(attributeName.ToLowerInvariant())).Value;
                    }
                }
                catch (Exception ex)
                {
                    value = default(T);

                    //Throw exception if suppress is set to faluse
                    if (suppressErrorIfNotFound.Equals(false)) throw ex;
                }
            }

            return value;
        }

        public static StringBuilder GetMessageFromException(Exception exception, string title, Boolean includeStackTrace = false)
        {
            StringBuilder message = new StringBuilder();

            //Null validation
            if (exception != null)
            {
                message.AppendLine("An error occurred");
                message.AppendLine($"Title: {title}");
                message.AppendLine($"Message: {exception.Message}");
                if (includeStackTrace) message.AppendLine($"Stack Trace: {exception.StackTrace}");

                string msg = GetInnerExceptionMessage(exception, includeStackTrace).ToString();

                //String empty validation
                if (!string.IsNullOrEmpty(msg)) { message.AppendLine(msg); }
            }
            else message.AppendLine("Invalid exception: No exception message found");

            return message;
        }

        #region Serialization / Deserialization

        public static string Serialize<T>(T serializeableObject, Boolean throwException = false)
        {
            string serializedObject = string.Empty;

            //Null validation
            if (!object.Equals((object)serializeableObject, (object)default(T)))
            {
                MemoryStream memoryStream = null;
                try
                {
                    DataContractJsonSerializer contractJsonSerializer = new DataContractJsonSerializer(typeof(T));
                    //MemoryStream memoryStream = new MemoryStream();
                    //contractJsonSerializer.WriteObject(memoryStream, serializeableObject);
                    //serializedObject = Encoding.UTF8.GetString(memoryStream.ToArray());
                    //memoryStream.Close();
                    //Remediation - 20/07/2022
                    memoryStream = new MemoryStream();
                    contractJsonSerializer.WriteObject(memoryStream, serializeableObject);
                    serializedObject = Encoding.UTF8.GetString(memoryStream.ToArray());
                }
                catch (Exception ex)
                {
                    if (throwException) throw ex;
                    else serializedObject = string.Empty;
                }
                finally 
                {
                    memoryStream.Close();
                }
            }

            return serializedObject;
        }

        public static T Deserialize<T>(string json, Boolean throwException = false)
        {
            T deserializedObject = default(T);

            try
            {
                //String empty validation
                if (!string.IsNullOrEmpty(json))
                {
                    using (MemoryStream memoryStream = new MemoryStream(Encoding.Unicode.GetBytes(json)))
                        deserializedObject = (T)new DataContractJsonSerializer(typeof(T)).ReadObject(memoryStream);
                }
            }
            catch (Exception ex)
            {
                if (throwException) throw ex;
                else deserializedObject = default(T);
            }

            return deserializedObject;
        }

        #endregion

        #region Reterive Methods

        public static Entity RetrieveEntity(EntityReference entityReference, IOrganizationService organizationService)
        {
            return HelperFunctions.RetrieveEntity(entityReference, null, organizationService);
        }

        public static Entity RetrieveEntity(EntityReference entityReference, string[] attributes, IOrganizationService organizationService)
        {
            Entity entity = null;
            ColumnSet columnSet = new ColumnSet(true);

            //Null validation
            if (attributes != null && attributes.Length > 0) columnSet = new ColumnSet(attributes);

            try
            {
                if (entityReference != null)
                    entity = organizationService.Retrieve(entityReference.LogicalName, entityReference.Id, columnSet);
            }
            catch
            {
                entity = (Entity)null;
            }

            return entity;
        }

        public static EntityMetadata RetrieveEntityMetadata(string logicalName, Microsoft.Xrm.Sdk.Metadata.EntityFilters entityFilter, IOrganizationService organizationService, Boolean retrieveAsIfPublished = false)
        {
            EntityMetadata entityMetadata = null;

            if (organizationService != null)
            {
                try
                {
                    OrganizationRequest request = new OrganizationRequest("RetrieveEntity");
                    request.Parameters.Add("EntityFilters", entityFilter);
                    request.Parameters.Add("LogicalName", logicalName);
                    request.Parameters.Add("MetadataId", Guid.Empty);
                    request.Parameters.Add("RetrieveAsIfPublished", retrieveAsIfPublished);

                    OrganizationResponse response = organizationService.Execute(request);

                    //Null validation
                    if (response != null && response.Results != null) entityMetadata = response.Results["EntityMetadata"] as EntityMetadata;
                }
                catch { entityMetadata = null; }
            }

            return entityMetadata;
        }

        #endregion

        #region OptionSet Methods

        public static OptionSetValue GetOptionSetValue(string attributeLogicalName, string entityLogicaName, string externalValueOrLabel, IOrganizationService organizationService, int? languageCode = null)
        {
            OptionSetValue optionSetValue = null;

            //String empty validation
            if (!string.IsNullOrEmpty(externalValueOrLabel))
                optionSetValue = GetOptionSetValue(Helper.HelperFunctions.GetOptionSetMetadata(attributeLogicalName, entityLogicaName, organizationService), externalValueOrLabel, languageCode);

            return optionSetValue;
        }

        public static OptionSetValue GetOptionSetValue(OptionSetMetadata optionSetMetadata, string externalValueOrLabel, int? languageCode = null)
        {
            OptionSetValue optionSetValue = null;

            //Null validation
            if (optionSetMetadata != null && !string.IsNullOrEmpty(externalValueOrLabel))
            {
                OptionMetadata optionMetadata = optionSetMetadata.Options.FirstOrDefault(item => !string.IsNullOrEmpty(item.ExternalValue) && item.ExternalValue.ToLowerInvariant().Equals(externalValueOrLabel.ToLowerInvariant()));

                //Null validation                
                if (optionMetadata == null)
                {
                    optionMetadata = optionSetMetadata.Options.FirstOrDefault(item => item.Label.UserLocalizedLabel.Label.ToLowerInvariant().Equals(externalValueOrLabel.ToLowerInvariant()));

                    if (languageCode.HasValue)
                    {
                        optionMetadata = optionSetMetadata.Options.FirstOrDefault(item => item.Label.LocalizedLabels.Select(xitem => xitem.LanguageCode.Equals(languageCode.Value)
                                                                                 && xitem.Label.ToLowerInvariant().Equals(externalValueOrLabel.ToLowerInvariant())).FirstOrDefault());
                    }
                }

                if (optionMetadata != null && optionMetadata.Value.HasValue)
                    optionSetValue = new OptionSetValue(optionMetadata.Value.Value);
            }

            return optionSetValue;
        }

        public static string GetOptionSetLabel(string attributeLogicalName, string entityLogicaName, OptionSetValue optionSetValue, IOrganizationService organizationService, int? languageCode = null)
        {
            return GetOptionSetLabel(GetOptionSetMetadata(attributeLogicalName, entityLogicaName, organizationService), optionSetValue, languageCode);
        }

        public static string GetOptionSetLabel(OptionSetMetadata optionSetMetadata, OptionSetValue optionSetValue, int? languageCode = null)
        {
            string label = string.Empty;

            //Null validation
            if (optionSetMetadata != null && optionSetValue != null)
                label = GetOptionSetLabel(optionSetMetadata.Options.FirstOrDefault(item => item.Value.Equals(optionSetValue.Value)), languageCode);

            return label;
        }

        public static string GetOptionSetLabel(OptionMetadata optionMetadata, int? languageCode = null)
        {
            string label = string.Empty;

            //Null validation
            if (optionMetadata != null)
            {
                label = optionMetadata.Label.UserLocalizedLabel.Label;

                if (languageCode.HasValue)
                {
                    LocalizedLabel localizedLabel = optionMetadata.Label.LocalizedLabels.FirstOrDefault(item => item.LanguageCode.Equals(languageCode));

                    //Null validation
                    if (localizedLabel != null) label = localizedLabel.Label;
                }
            }

            return label;
        }

        public static string GetOptionSetExternalValue(string attributeLogicalName, string entityLogicaName, OptionSetValue optionSetValue, IOrganizationService organizationService)
        {
            return GetOptionSetExternalValue(GetOptionSetMetadata(attributeLogicalName, entityLogicaName, organizationService), optionSetValue);
        }

        public static string GetOptionSetExternalValue(OptionSetMetadata optionSetMetadata, OptionSetValue optionSetValue)
        {
            string externalValue = string.Empty;

            //Null validation
            if (optionSetMetadata != null && optionSetValue != null)
            {
                OptionMetadata optionMetadata = optionSetMetadata.Options.FirstOrDefault(item => item.Value.Equals(optionSetValue.Value));

                //Null validation
                if (optionMetadata != null) externalValue = optionMetadata.ExternalValue;
            }

            return externalValue;
        }

        public static OptionSetMetadata GetOptionSetMetadata(string attributeLogicalName, string entityLogicaName, IOrganizationService organizationService)
        {
            OptionSetMetadata optionSetMetadata = null;

            //string empty validation
            if (!string.IsNullOrEmpty(entityLogicaName))
            {
                RetrieveAttributeRequest retrieveAttributeRequest = new RetrieveAttributeRequest()
                {
                    EntityLogicalName = entityLogicaName,
                    LogicalName = attributeLogicalName,
                    RetrieveAsIfPublished = false,
                };

                RetrieveAttributeResponse retrieveAttributeResponse = organizationService.Execute(retrieveAttributeRequest) as RetrieveAttributeResponse;

                //Null validation
                if (retrieveAttributeResponse != null)
                {
                    AttributeMetadata attributeMetadata = retrieveAttributeResponse.AttributeMetadata;

                    if (attributeMetadata is StateAttributeMetadata)
                        optionSetMetadata = (attributeMetadata as StateAttributeMetadata).OptionSet;
                    else if (attributeMetadata is StatusAttributeMetadata)
                        optionSetMetadata = (attributeMetadata as StatusAttributeMetadata).OptionSet;
                    else if (attributeMetadata is PicklistAttributeMetadata)
                        optionSetMetadata = (attributeMetadata as PicklistAttributeMetadata).OptionSet;
                    else if (attributeMetadata is EntityNameAttributeMetadata)
                        optionSetMetadata = (attributeMetadata as EntityNameAttributeMetadata).OptionSet;
                }
            }
            else
            {
                RetrieveOptionSetRequest retrieveOptionSetRequest = new RetrieveOptionSetRequest();
                retrieveOptionSetRequest.Name = attributeLogicalName;

                RetrieveOptionSetResponse retrieveOptionSetResponse = organizationService.Execute(retrieveOptionSetRequest) as RetrieveOptionSetResponse;

                //Null validation
                if (retrieveOptionSetResponse != null) optionSetMetadata = retrieveOptionSetResponse.OptionSetMetadata as OptionSetMetadata;
            }

            return optionSetMetadata;
        }

        #endregion

        #endregion

        #region Private Subs / Functions

        /// <summary>
        /// this method is used to get the inner exception message
        /// </summary>
        /// <param name="exception"></param>
        /// <returns>GetInnerExceptionMessage</returns>
        private static StringBuilder GetInnerExceptionMessage(Exception exception)
        {
            return GetInnerExceptionMessage(exception, false);
        }

        /// <summary>
        /// This method is used to get the inner exception message and null validation is done for exception
        /// </summary>
        /// <param name="exception"></param>
        /// <param name="isInnerException"></param>
        /// <returns></returns>
        private static StringBuilder GetInnerExceptionMessage(Exception exception, Boolean isInnerException)
        {
            StringBuilder message = new StringBuilder();

            //Null validation
            if (exception != null)
            {
                if (!isInnerException) message.AppendLine($"Inner Exception Message: {exception.Message}");
                else message.AppendLine(exception.Message);

                //Null validation
                if (exception.InnerException != null)
                {
                    string _message = GetInnerExceptionMessage(exception.InnerException, true).ToString();
                    if (!string.IsNullOrEmpty(_message)) message.AppendLine(_message);
                }
            }

            return message;
        }

        #endregion
    }
}