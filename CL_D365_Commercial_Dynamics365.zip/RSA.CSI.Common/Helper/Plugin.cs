﻿namespace RSA.CSI.Plugins.Helper
{
    using System;
    using System.Text;
    using System.Collections.ObjectModel;
    using System.Collections.Generic;
    using System.ServiceModel;
    using System.Linq;
    using Microsoft.Xrm.Sdk;
    using Microsoft.Xrm.Sdk.Metadata;

    /// <summary>
    /// Base class for all Plugins.
    /// </summary>    
    public abstract class Plugin : IPlugin
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="Plugin"/> class.
        /// </summary>
        /// <param name="childClassName">The <see cref=" cred="Type"/> of the derived class.</param>
        internal Plugin(Type childClassName)
        {
            this.ChildClassName = childClassName.ToString();
        }

        #endregion

        #region Public Properties / Variables

        public enum SdkMessageProcessingStepStage
        {
            InitialPreoperation_Forinternaluseonly = 5,
            Prevalidation = 10,
            Preoperation = 20,
            Postoperation = 40,
            Postoperation_Deprecated = 50,
            InternalPostoperationAfterExternalPlugins_Forinternaluseonly = 45,
            InternalPostoperationBeforeExternalPlugins_Forinternaluseonly = 35,
            InternalPreoperationBeforeExternalPlugins_Forinternaluseonly = 15,
            InternalPreoperationAfterExternalPlugins_Forinternaluseonly = 25,
            MainOperation_Forinternaluseonly = 30,
            FinalPostoperation_Forinternaluseonly = 55,
        }

        #endregion

        #region Private Properties / Variables

        private Collection<Event> events;

        #endregion

        #region Protected Properties / Variables

        /// <summary>
        /// Gets the List of events that the plug-in should fire for. Each List
        /// Item is a <see cref="System.Tuple"/> containing the Pipeline Stage, Message and (optionally) the Primary Entity. 
        /// In addition, the fourth parameter provide the delegate to invoke on a matching registration.
        /// </summary>
        protected Collection<Event> Events
        {
            get
            {
                //Null validation
                if (this.events == null) this.events = new Collection<Event>();

                return this.events;
            }
        }

        /// <summary>
        /// Gets or sets the name of the child class.
        /// </summary>
        /// The name of the child class.</value>
        protected string ChildClassName
        {
            get;
            private set;
        }

        #endregion

        #region Public Subs / Functions

        /// <summary>
        /// Executes the plug-in.
        /// </summary>
        /// <param name="serviceProvider">The service provider.</param>
        /// <remarks>
        /// For improved performance, Microsoft Dynamics CRM caches plug-in instances. 
        /// The plug-in's Execute method should be written to be stateless as the constructor 
        /// is not called for every invocation of the plug-in. Also, multiple system threads 
        /// could execute the plug-in at the same time. All per invocation state information 
        /// is stored in the context. This means that you should not use global variables in plug-ins.
        /// </remarks>
        public void Execute(IServiceProvider serviceProvider)
        {
            //Null validation
            if (serviceProvider == null) //throw new ArgumentNullException("serviceProvider");  //Remediation - 14/07/2022
                throw new InvalidPluginExecutionException("serviceProvider");
            // Construct the Local plug-in context.
            PluginContext pluginContext = new PluginContext(serviceProvider);

            pluginContext.LogMessage($"Entered {this.ChildClassName}.Execute()");
            pluginContext.LogMessage($"Correlation Id: {pluginContext.PluginExecutionContext.CorrelationId} | Initiating User: {pluginContext.PluginExecutionContext.InitiatingUserId}");
            pluginContext.LogMessage($"Start Execution {this.ChildClassName}: {pluginContext.PluginExecutionContext.PrimaryEntityName}, Message: {pluginContext.PluginExecutionContext.MessageName}");

            try
            {
                // Iterate over all of the expected registered events to ensure that the plugin
                // has been invoked by an expected event
                // For any given plug-in event at an instance in time, we would expect at most 1 result to match.
                List<Event> events = new List<Event>();
                events.AddRange(this.Events.Where(item => item.Stage.GetHashCode().Equals(pluginContext.PluginExecutionContext.Stage)
                                                && item.MessageName.ToLowerInvariant().Equals(pluginContext.PluginExecutionContext.MessageName.ToLowerInvariant())
                                                && item.PrimaryEntityName.ToLowerInvariant().Equals(pluginContext.PluginExecutionContext.PrimaryEntityName.ToLowerInvariant())
                                                && (string.IsNullOrEmpty(item.SecondaryEntityName) ? true : item.SecondaryEntityName.ToLowerInvariant().Equals(pluginContext.PluginExecutionContext.SecondaryEntityName.ToLowerInvariant()))));

                //Null validation
                if (events != null && events.Any())
                {
                    events.ForEach(_event =>
                    {
                        string methodName = string.Empty;
                        Boolean invokeAction = true;

                        //Null validation
                        if (_event.FilteredAttributes != null && _event.FilteredAttributes.Any())
                        {
                            Entity targetEntity = pluginContext.TargetEntity;

                            //Null validation
                            if (targetEntity != null && (targetEntity.Attributes != null && targetEntity.Attributes.Any()))
                                invokeAction = _event.FilteredAttributes.Any(attribute => targetEntity.Attributes.Select(item => item.Key.ToLowerInvariant()).Contains(attribute.ToLowerInvariant()));
                        }

                        //Null validation
                        if (_event.Action != null && _event.Action.Method != null) methodName = _event.Action.Method.Name;

                        //Invoke action if valid to be invoked
                        if (invokeAction)
                        {
                            if (_event.Action != null)
                            {
                                pluginContext.LogMessage($"Start invoking action for {methodName}");

                                _event.Action.Invoke(pluginContext);

                                pluginContext.LogMessage($"End invoking action for {methodName}");
                            }
                            else pluginContext.ThrowException($"Unable to invoke plugin action for stage: {pluginContext.PluginExecutionContext.Stage} | Message Name: {pluginContext.PluginExecutionContext.MessageName} | Primary Entity Name: {pluginContext.PluginExecutionContext.PrimaryEntityName}, Method Name: {methodName}");
                        }
                        else pluginContext.LogMessage($"Unable to invoke action for {methodName}");
                    });
                }
                else pluginContext.ThrowException($"Missing Plugin Event For Stage: {pluginContext.PluginExecutionContext.Stage} | Message Name: {pluginContext.PluginExecutionContext.MessageName} | Primary Entity Name: {pluginContext.PluginExecutionContext.PrimaryEntityName}");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                pluginContext.LogException(ex, "Plugin.Execute");

                // Handle the exception.
                //throw;  // Remediation - 14/07/2022
                throw new InvalidPluginExecutionException(ex.Detail.Message);
            }
            finally
            {
                pluginContext.LogMessage($"End Execution {this.ChildClassName}: {pluginContext.PluginExecutionContext.PrimaryEntityName}, Message: {pluginContext.PluginExecutionContext.MessageName}");
            }
        }

        /// <summary>
        /// Get Attribute Value from entity
        /// </summary>
        /// <param name="attributeLogicalName">Attribute Logical Name</param>
        /// <param name="entity">Entity to Retrieve attribute value</param>
        /// <remarks>
        /// Get attribte value from entity parameter
        /// </remarks>
        public T GetAttributeValue<T>(string attributeName, Entity entity)
        {
            return Helper.HelperFunctions.GetAttributeValue<T>(attributeName, entity);
        }

        #endregion

        #region Protected Subs / Functions

        /// <summary>
        /// Update Entity
        /// </summary>
        /// <param name="attritbutes">Attributes To Be Updated</param>
        /// <param name="primaryIdAttribute">Entity Primiary Id Name</param>
        /// <param name="entity">Reference Entity</param>
        /// <param name="pluginContext">Local Plugin Context</param>
        /// <remarks>
        /// Update entity record
        /// </remarks>
        protected void UpdateEntity(Dictionary<string, object> attritbutes, ref Entity entity, PluginContext pluginContext)
        {
            //Null validation
            if (pluginContext != null && entity != null)
            {
                //Null validation
                if (attritbutes != null && attritbutes.Any())
                {
                    Boolean updating = pluginContext.PluginExecutionContext.Stage.Equals(SdkMessageProcessingStepStage.Postoperation)
                            , entityValid = (RetrieveEntity(entity.ToEntityReference(), pluginContext.OrganizationService) != null);

                    Entity updateEntity = new Entity(entity.LogicalName);

                    if (!entityValid) updating = false;

                    foreach (KeyValuePair<string, object> attritbute in attritbutes)
                    {
                        string attributeName = attritbute.Key;
                        object attribute = attritbute.Value;

                        if (!updating)
                        {
                            if (entity.Contains(attributeName)) entity[attributeName] = attribute;
                            else entity.Attributes.Add(attributeName, attribute);
                        }
                        else
                        {
                            if (updateEntity.Contains(attributeName)) updateEntity[attributeName] = attribute;
                            else updateEntity.Attributes.Add(attributeName, attribute);
                        }
                    }

                    if (updating)
                    {
                        EntityMetadata entityMetadata = RetrieveEntityMetadata(entity.LogicalName, EntityFilters.Entity, pluginContext.OrganizationService);

                        //Null validation
                        if (entityMetadata != null) updateEntity.Attributes.Add(entityMetadata.PrimaryIdAttribute, entity.Id);

                        pluginContext.OrganizationService.Update(updateEntity);
                    }
                }
            }
        }

        /// <summary>
        /// Get entity
        /// </summary>
        /// <param name="organizationService">Organization Service</param>
        /// <param name="entityReference">Entity Reference</param>
        /// <remarks>
        /// Get entity record
        /// </remarks>
        protected static Entity RetrieveEntity(Microsoft.Xrm.Sdk.EntityReference entityReference, IOrganizationService organizationService)
        {
            return Helper.HelperFunctions.RetrieveEntity(entityReference, organizationService);
        }

        /// <summary>
        /// Get entity
        /// </summary>
        /// <param name="organizationService">Organization Service</param>
        /// <param name="entityReference">Entity Reference</param>
        /// <param name="attributes">Attributes to return</param>
        /// <remarks>
        /// Get entity record
        /// </remarks>
        protected static Entity RetrieveEntity(Microsoft.Xrm.Sdk.EntityReference entityReference, string[] attributes, IOrganizationService organizationService)
        {
            return Helper.HelperFunctions.RetrieveEntity(entityReference, attributes, organizationService);
        }

        /// <summary>
        /// Get Entity Metadata
        /// </summary>
        /// <param name="entityLogicalName">Entity Logical Name</param>
        /// <param name="organizationService">Organization Service</param>
        /// <remarks>
        /// Return Entity Metadata 
        /// </remarks>
        protected static EntityMetadata RetrieveEntityMetadata(string entityLogicalName, IOrganizationService organizationService, Boolean retrieveAsIfPublished = false)
        {
            return RetrieveEntityMetadata(entityLogicalName
                                        , Microsoft.Xrm.Sdk.Metadata.EntityFilters.Entity | Microsoft.Xrm.Sdk.Metadata.EntityFilters.Attributes | Microsoft.Xrm.Sdk.Metadata.EntityFilters.Relationships
                                        , organizationService
                                        , retrieveAsIfPublished);
        }

        /// <summary>
        /// Get Entity Metadata
        /// </summary>
        /// <param name="entityLogicalName">Entity Logical Name</param>
        /// <param name="entityFilter">Entity Filter</param>
        /// <param name="organizationService">Organization Service</param>
        /// <remarks>
        /// Return Entity Metadata 
        /// </remarks>
        protected static EntityMetadata RetrieveEntityMetadata(string logicalName, Microsoft.Xrm.Sdk.Metadata.EntityFilters entityFilter, IOrganizationService organizationService, Boolean retrieveAsIfPublished = false)
        {
            return Helper.HelperFunctions.RetrieveEntityMetadata(logicalName, entityFilter, organizationService, retrieveAsIfPublished);
        }

        #endregion

        #region Context Class

        /// <summary>
        /// <remarks>Remember to change the "pluginName" to your plugin namespace for error handling naming</remarks>
        /// </summary>
        public class PluginContext
        {
            #region Cosntructors

            private PluginContext() { }

            internal PluginContext(IServiceProvider serviceProvider)
            {
                //Null validation
                if (serviceProvider == null) //throw new ArgumentNullException("serviceProvider");  // Remediation - 14/07/2022
                    throw new InvalidPluginExecutionException("serviceProvider");

                // Obtain the execution context service from the service provider.
                this.PluginExecutionContext = serviceProvider.GetService(typeof(IPluginExecutionContext)) as IPluginExecutionContext;

                // Obtain the tracing service from the service provider.
                this.TracingService = serviceProvider.GetService(typeof(ITracingService)) as ITracingService;

                // Obtain the Organization Service factory service from the service provider
                IOrganizationServiceFactory factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));

                // Use the factory to generate the Organization organizationService.
                this.OrganizationService = factory.CreateOrganizationService(this.PluginExecutionContext.UserId);
            }

            #endregion

            #region Private Properties / Variables

            private StringBuilder messages = new StringBuilder();
            private EntityReference targetEntityMoniker = null;
            private Entity targetEntity = null
                           , targetEntityPre= null
                           , targetEntityPost = null;

            #endregion

            #region Public Properties / Variables

            public StringBuilder Messages
            {
                get { return messages; }
            }

            #endregion

            #region Protected Properties / Variables

            internal IServiceProvider ServiceProvider
            {
                get;
                private set;
            }

            internal IOrganizationService OrganizationService
            {
                get;
                private set;
            }

            internal IPluginExecutionContext PluginExecutionContext
            {
                get;
                private set;
            }

            internal ITracingService TracingService
            {
                get;
                private set;
            }

            internal EntityReference TargetEntityMoniker
            {
                get
                {
                    //Null validation
                    if (targetEntityMoniker == null)
                    {
                        targetEntityMoniker = GetInputParameter<EntityReference>("EntityMoniker");

                        //Null validation
                        if (targetEntityMoniker == null) targetEntityMoniker = GetInputParameter<EntityReference>("Target");
                        if (targetEntityMoniker == null && this.TargetEntity != null) targetEntityMoniker = this.TargetEntity.ToEntityReference();
                    }

                    return targetEntityMoniker;
                }
            }

            internal Entity TargetEntity
            {
                get
                {
                    //Null validation
                    if (targetEntity == null) targetEntity = GetInputParameter<Entity>("Target");

                    return targetEntity;
                }
            }

            internal Entity TargetEntityPre
            {
                get
                {
                    //Null validation
                    if (targetEntityPre == null)
                    {
                        //Null validation
                        if (PluginExecutionContext.PreEntityImages != null && PluginExecutionContext.PreEntityImages.Any())
                        {
                            if (PluginExecutionContext.PreEntityImages.Any(item => item.Key.ToLowerInvariant().Equals(PluginExecutionContext.PrimaryEntityName)))
                                targetEntityPost = PluginExecutionContext.PreEntityImages.FirstOrDefault(item => item.Key.ToLowerInvariant().Equals(PluginExecutionContext.PrimaryEntityName.ToLowerInvariant())).Value;

                            //Null validation
                            if (targetEntityPre == null && PluginExecutionContext.PreEntityImages.Any(item => item.Key.ToLowerInvariant().Equals(PluginExecutionContext.SecondaryEntityName.ToLowerInvariant())))
                                targetEntityPre = PluginExecutionContext.PreEntityImages.FirstOrDefault(item => item.Key.ToLowerInvariant().Equals(PluginExecutionContext.SecondaryEntityName.ToLowerInvariant())).Value;
                        }
                    }

                    return targetEntityPre;
                }
            }

            internal Entity TargetEntityPost
            {
                get
                {
                    //Null validation
                    if (targetEntityPost == null)
                    {
                        //Null validation
                        if (PluginExecutionContext.PostEntityImages != null && PluginExecutionContext.PostEntityImages.Any())
                        {
                            if (PluginExecutionContext.PostEntityImages.Any(item => item.Key.ToLowerInvariant().Equals(PluginExecutionContext.PrimaryEntityName.ToLowerInvariant())))
                                targetEntityPost = PluginExecutionContext.PostEntityImages.FirstOrDefault(item => item.Key.ToLowerInvariant().Equals(PluginExecutionContext.PrimaryEntityName.ToLowerInvariant())).Value;

                            //Null validation
                            if (targetEntityPost == null && PluginExecutionContext.PostEntityImages.Any(item => item.Key.ToLowerInvariant().Equals(PluginExecutionContext.SecondaryEntityName.ToLowerInvariant())))
                                targetEntityPost = PluginExecutionContext.PostEntityImages.FirstOrDefault(item => item.Key.ToLowerInvariant().Equals(PluginExecutionContext.SecondaryEntityName.ToLowerInvariant())).Value;
                        }
                    }

                    return targetEntityPost;
                }
            }

            #endregion

            #region Private Subs / Functions

            /// <summary>
            /// Trace Message
            /// </summary>
            /// <param name="message">Message to be traced</param>
            /// <remarks>
            /// Writes message to tracing service
            /// </remarks>
            private void Trace(string message)
            {
                //String empty validation
                if (!string.IsNullOrWhiteSpace(message) && this.TracingService != null) this.TracingService.Trace(message);
            }

            #endregion

            #region Protected Subs / Functions

            /// <summary>
            /// Logs message
            /// </summary>
            /// <param name="message">Message to be logged</param>
            /// <remarks>
            /// Logs custom message to the tracing service
            /// </remarks>
            internal void LogMessage(string message)
            {
                LogMessage(message, false);
            }

            /// <summary>
            /// Logs message
            /// </summary>
            /// <param name="message">Message to be logged</param>
            /// <param name="throwException">Throw exception after message is logged</param>
            /// <remarks>
            /// Logs custom message to the tracing service
            /// </remarks>
            internal void LogMessage(string message, Boolean throwException)
            {
                this.messages.AppendLine(message);

                Trace(message);

                if (throwException) ThrowException(message);
            }

            /// <summary>
            /// Logs error
            /// </summary>
            /// <param name="exception">Exception to be logged</param>
            /// <param name="title">Title giving to the exception</param>
            /// <remarks>
            /// Logs custom message to the tracing service
            /// </remarks>
            internal void LogException(Exception exception, string title)
            {
                LogException(exception, title, false);
            }

            /// <summary>
            /// Logs error
            /// </summary>
            /// <param name="exception">Exception to be logged</param>
            /// <param name="title">Title giving to the exception</param>
            /// <param name="includeStackTrace">Include stack trace?</param>
            /// <remarks>
            /// Logs custom message to the tracing service
            /// </remarks>
            internal void LogException(Exception exception, string title, Boolean includeStackTrace)
            {
                StringBuilder message = Helper.HelperFunctions.GetMessageFromException(exception, title, includeStackTrace);

                Trace($"Plug-in error: {title}");
                Trace($"Error details: {message.ToString()}");

                this.messages.AppendLine(message.ToString());
            }

            /// <summary>
            /// Throws Plugin Exception
            /// </summary>
            /// <param name="message">Message to be thrown</param>
            /// <remarks>
            /// Throws a new instanace of InvalidPluginExecutionException
            /// </remarks>
            internal void ThrowException(string message)
            {
                ThrowException(message, new Exception("Error thrown by application"));
            }

            /// <summary>
            /// Throws Plugin Exception
            /// </summary>
            /// <param name="title">Title giving to the exception</param>
            /// <param name="message">Message to be thrown</param>
            /// <param name="exception">Exception thrown</param>
            /// <remarks>
            /// Throws a new instanace of InvalidPluginExecutionException
            /// </remarks>
            internal void ThrowException(string message, Exception exception, Boolean includeStackTrace = false)
            {
                string messageName = (PluginExecutionContext != null) ? PluginExecutionContext.MessageName : string.Empty;

                StringBuilder messages = Helper.HelperFunctions.GetMessageFromException(exception, "Plugin.ThrowException", includeStackTrace);
                messages.AppendLine("Logged Message");
                messages.AppendLine(this.messages.ToString());

                throw new InvalidPluginExecutionException($"{message} ({messageName}) Err Msg: {messages.ToString()}", exception);
            }

            #endregion

            #region Public Subs / Functions  

            /// <summary>
            /// Get Attribute Value
            /// </summary>
            /// <param name="attributeLogicalName">Attribute Logical Name</param>
            /// <remarks>
            /// Get attribte value from entity input parameter or from plugin images
            /// </remarks>
            public T GetAttributeValue<T>(string attributeLogicalName, Boolean suppressErrorIfNotFound = true)
            {
                T attributeValue = default(T);

                try
                {
                    //Validate is attribute is in target entity. Get attribute value from entity
                    attributeValue = Helper.HelperFunctions.GetAttributeValue<T>(attributeLogicalName, this.TargetEntity, suppressErrorIfNotFound);

                    //Attribute is not in target entity. Search pre entity for attribute value
                    if (object.Equals(attributeValue, default(T)) && this.TargetEntityPre != null)
                        attributeValue = Helper.HelperFunctions.GetAttributeValue<T>(attributeLogicalName, this.TargetEntityPre, suppressErrorIfNotFound);

                    //Attribute is not in pre entity. Search post entity for attribute value
                    if (object.Equals(attributeValue, default(T)) && this.TargetEntityPost != null)
                        attributeValue = Helper.HelperFunctions.GetAttributeValue<T>(attributeLogicalName, this.TargetEntityPost, suppressErrorIfNotFound);
                }
                catch (Exception ex)
                {
                    //if error return default object
                    attributeValue = default(T);

                    //Log Error
                    LogException(ex, "PluginContext.GetAttributeValue");

                    //Throw exception if suppress is set to faluse
                    if (suppressErrorIfNotFound.Equals(false)) throw ex;
                }

                return attributeValue;
            }

            public T GetInputParameter<T>(string name, Boolean suppressErrorIfNotFound = true)
            {
                T inputParameter = default(T);

                //Null validation
                if (this.PluginExecutionContext != null)
                {
                    //Null validation
                    if (this.PluginExecutionContext.InputParameters != null && this.PluginExecutionContext.InputParameters.Any())
                    {
                        try
                        {
                            inputParameter = this.PluginExecutionContext.InputParameters.Where(item => item.Key.ToLowerInvariant().Equals(name.ToLowerInvariant()))
                                                                                        .Select(item => (T)item.Value)
                                                                                        .FirstOrDefault();
                        }
                        catch (Exception ex)
                        {
                            //if error return default object
                            inputParameter = default(T);

                            //Log Error
                            LogException(ex, "PluginContext.GetInputParameter");

                            //Throw exception if suppress is set to faluse
                            if (suppressErrorIfNotFound.Equals(false)) //throw ex; //Remediation - 14/07/2022
                                throw new InvalidPluginExecutionException(ex.Message);
                        }
                    }
                }

                return inputParameter;
            }

            #endregion
        }

        #endregion

        #region Event Class

        public class Event
        {
            #region Contructors

            public Event(SdkMessageProcessingStepStage stage, string messageName, string primaryEntityName, Action<PluginContext> action) : this(stage, messageName, primaryEntityName, null, action) { }
            public Event(SdkMessageProcessingStepStage stage, string messageName, string primaryEntityName, Collection<string> filteredAttributes, Action<PluginContext> action) : this(stage, messageName, primaryEntityName, string.Empty, filteredAttributes, action) { }
            public Event(SdkMessageProcessingStepStage stage, string messageName, string primaryEntityName, string secondaryEntityName, Collection<string> filteredAttributes, Action<PluginContext> action)
            {
                this.Stage = stage;
                this.MessageName = messageName;
                this.PrimaryEntityName = primaryEntityName;
                this.SecondaryEntityName = secondaryEntityName;
                this.FilteredAttributes = filteredAttributes;
                this.Action = action;
            }

            #endregion

            #region Protected Properties / Variables

            public SdkMessageProcessingStepStage Stage { get; set; }
            public string MessageName { get; set; }
            public string PrimaryEntityName { get; set; }
            public string SecondaryEntityName { get; set; }
            public Collection<string> FilteredAttributes { get; set; }
            public Action<PluginContext> Action { get; set; }

            #endregion
        }

        #endregion
    }
}