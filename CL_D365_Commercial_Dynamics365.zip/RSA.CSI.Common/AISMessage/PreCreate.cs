﻿using Microsoft.Xrm.Sdk;
using RSA.CSI.Plugins.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace RSA.CSI.Common.AISMessage
{
    public class PreCreate : Plugin
    {
        #region Constructors
        public PreCreate() : base(typeof(PreCreate))
        {
            this.Events.Add(new Event(SdkMessageProcessingStepStage.Preoperation, "Create", "rsa_aismessage", new Action<PluginContext>(this.Execute)));
        }
        #endregion

        #region Public Subs / Functions
        protected void Execute(PluginContext pluginContext)
        {
            Exception exception = null;
            if (pluginContext == null) exception = new ArgumentNullException(nameof(pluginContext));

            IPluginExecutionContext context = pluginContext.PluginExecutionContext;
            IOrganizationService service = pluginContext.OrganizationService;
            ITracingService tracingService = pluginContext.TracingService;

            Entity entity;
            pluginContext.LogMessage("rsa_aismessage.PreCreate logic- Loaded.");
            try
            {
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    entity = (Entity)context.InputParameters["Target"];
                    Logic.AISMessageLogic logic = new Logic.AISMessageLogic(pluginContext, entity, null);
                    logic.PreCreate();
                }
            }
            catch (FaultException<OrganizationServiceFault> ex) { pluginContext.ThrowException("Fault Exception Occured", ex); }
            catch (Exception ex) { exception = ex; }
            finally { if (exception != null) { pluginContext.LogException(exception, "AISMessageLogic.PreCreate"); 
                    //throw new InvalidPluginExecutionException(exception.Message);
                } }

            pluginContext.LogMessage("rsa_aismessage.PreCreate logic- Unloaded.");
        }
        #endregion
    }
}