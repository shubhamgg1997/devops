﻿using Microsoft.Xrm.Sdk;
using RSA.CSI.Plugins.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace RSA.CSI.Common.AISMessage
{
    public class PostCreate : Plugin
    {
        #region Constructors
        public PostCreate() : base(typeof(PostCreate))
        {
            this.Events.Add(new Event(SdkMessageProcessingStepStage.Postoperation, "Create", "rsa_aismessage", new Action<PluginContext>(this.Execute)));
        }
        #endregion Constructors

        #region Public Subs / Functions
        protected void Execute(PluginContext pluginContext)
        {
            Exception exception = null;
            if (pluginContext == null) exception = new ArgumentNullException(nameof(pluginContext));

            IPluginExecutionContext context = pluginContext.PluginExecutionContext;
            IOrganizationService service = pluginContext.OrganizationService;
            ITracingService tracingService = pluginContext.TracingService;

            Entity entity;
            pluginContext.LogMessage("rsa_aismessage.PostCreate logic- Loaded.");
            try
            {
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    entity = (Entity)context.InputParameters["Target"];
                    Logic.AISMessageLogic logic = new Logic.AISMessageLogic(pluginContext, entity, null);
                    logic.PostCreate();
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                pluginContext.ThrowException("Fault Exception Occured", ex);
            }
            catch (Exception ex)
            {
                exception = ex;
            }
            finally
            {
                if (exception != null) { pluginContext.LogException(exception, "rsa_aismessage.PostCreate");
                    //throw new InvalidPluginExecutionException(exception.Message);
                }
            }
            pluginContext.LogMessage("rsa_aismessage.PostCreate logic- Unloaded.");
        }
        #endregion Public Subs / Functions
    }
}
