﻿using Microsoft.Xrm.Sdk;
using System;
using System.ServiceModel;
using System.Activities;
using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Xrm.Sdk.Query;
using RSA.CSI.Common.Logic;

namespace RSA.CSI.Common.AISMessage
{
    public class RetryTaskMechanism : CodeActivity
    {
        [RequiredArgument]
        [Input("Max Retry Count")]
        public InArgument<int> MaxRetryCount { get; set; }

        protected override void Execute(CodeActivityContext _executionContext)
        {
            IWorkflowContext _context = _executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = _executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(_context.InitiatingUserId);

            ITracingService tracingService = _executionContext.GetExtension<ITracingService>();
            decimal maxCountRetry = MaxRetryCount.Get<decimal>(_executionContext);

            //Fetch waiting task where retry count is less than 4 and status is waiting
            tracingService.Trace("intiating user id" + _context.InitiatingUserId + " user id : " + _context.UserId);
            FilterExpression filterExpression = null;
            ColumnSet columns = null;
            OrderExpression orderExpression = null;
            EntityCollection entityCollection = null;
            int topCount;
            topCount = Constants.AISMessage.TaskAISMessagesAction_TopCount;
            filterExpression = new FilterExpression
            {
                FilterOperator = LogicalOperator.And,
                Conditions = {
                    new ConditionExpression(Constants.AISMessage.MessageStatus, ConditionOperator.Equal, (int)Constants.AISMessage.AISMessage_Status.Waiting),
                    new ConditionExpression(Constants.AISMessage.MessageType, ConditionOperator.Equal, (int)Constants.AISMessage.AISMessage_Message_Type.Task),
                    new ConditionExpression(Constants.AISMessage.RetryCount, ConditionOperator.LessEqual, maxCountRetry),
                }
            };

            // columns = new ColumnSet(new string[] {"rsa_messagetype", "rsa_messagestatus" });
            columns = new ColumnSet(true);

            orderExpression = new OrderExpression(Constants.AISMessage.ModifiedOn, OrderType.Descending);
            tracingService.Trace("Fetch AIS Message entity collection");
            entityCollection = GetEntityCollection(service, tracingService, Constants.AISMessage.EntityName, filterExpression, orderExpression, columns, topCount);
            tracingService.Trace("Completed Fetch AIS Message entity collection");
            foreach (var item in entityCollection.Entities)
            {
                TaskMechanism(item, tracingService, service, maxCountRetry);
            }
        }

        private EntityCollection GetEntityCollection(IOrganizationService service, ITracingService trace, string entityName, FilterExpression filterExpression, OrderExpression orderExpression, ColumnSet columnSet, int topCount = 0)
        {
            trace.Trace("AISMessageLogic.GetEntityCollection- Loaded");
            Exception exception = null;
            EntityCollection collection = null;
            try
            {
                QueryExpression query = new QueryExpression
                {
                    NoLock = true,
                    Distinct = false,
                    EntityName = entityName,
                    ColumnSet = columnSet,
                    Criteria =
                    {
                        Filters =
                        {
                            filterExpression
                        }
                    }
                };
                // if (topCount > 0) query.TopCount = topCount;
                if (orderExpression != null) query.Orders.Add(orderExpression);
                trace.Trace("AIS Message entity collection");
                collection = service.RetrieveMultiple(query);
                trace.Trace("AIS Message entity collection retrieved" + collection.Entities.Count);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                new InvalidPluginExecutionException("Fault Exception Occured", ex);
                trace.Trace("Fault Exception Occured" + ex.Message);
            }
            catch (Exception ex) { exception = ex; }
            finally
            {
                if (exception != null)
                {
                    trace.Trace("AISMessageLogic.GetEntityCollection" + exception);
                    // throw new InvalidPluginExecutionException(exception.Message);
                }
            }
            trace.Trace("AISMessageLogic.GetEntityCollection- Unloaded");
            return collection;
        }

        internal void UpdateAISMessageStatus(IOrganizationService service, ITracingService trace, decimal retrycount, Guid aisMessageId, int iStatusValue, string erroMessage = null)
        {
            trace.Trace("AISMessageLogic.UpdateAISMessageStatus- Loaded");
            Exception exception = null;
            try
            {
                Entity entityUpdate = new Entity(Constants.AISMessage.EntityName);

                entityUpdate.Id = aisMessageId;
                trace.Trace($"Updated AIS Message:", aisMessageId);
                if (!string.IsNullOrEmpty(erroMessage))
                {
                    entityUpdate[Constants.AISMessage.ErrorDescription] = erroMessage;
                    trace.Trace($"Error AIS Message:", erroMessage);
                }
                entityUpdate[Constants.AISMessage.MessageStatus] = new OptionSetValue(iStatusValue);
                trace.Trace($"Message Status AIS Message:", iStatusValue);
                entityUpdate[Constants.AISMessage.RetryCount] = retrycount;
                trace.Trace($"Retry Count AIS Message:", retrycount);
                service.Update(entityUpdate);
                trace.Trace($"Updated AIS Message:'{aisMessageId}' status to '{iStatusValue}'");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                trace.Trace("Fault Exception Occured", ex.Message);
            }
            catch (Exception ex) { exception = ex; }
            finally
            {
                if (exception != null)
                {
                    trace.Trace("AISMessageLogic.UpdateAISMessageStatus" + exception);
                    // throw new InvalidPluginExecutionException(exception.Message);
                }
            }
            trace.Trace("AISMessageLogic.UpdateAISMessageStatus- Unloaded");
        }

        private Entity CreateAISMessageNotification(IOrganizationService service, ITracingService trace, Entity aisMessage, Entity Policy, Entity Quote, EntityReference eCase, int Type, string SystemDefinedError, string UserDefinedError, string MethodName)
        {
            trace.Trace("AISMessageNotificationLogic.CreateAISMessageNotification- Loaded");
            Exception exception = null;
            Entity eAisNotification = null;
            bool bHasAisNotificationProcessed = false;
            try
            {
                eAisNotification = new Entity(Constants.AISMessageNotification.EntityName);
                eAisNotification[Constants.AISMessageNotification.AISMessage] = new EntityReference(Constants.AISMessage.EntityName, aisMessage.Id);

                if (Policy != null)
                    eAisNotification[Constants.AISMessageNotification.Policy] = new EntityReference(Constants.Policy.EntityName, Policy.Id);

                if (Quote != null)
                    eAisNotification[Constants.AISMessageNotification.Quote] = new EntityReference(Constants.Quote.EntityName, Quote.Id);

                if (eCase != null)
                    eAisNotification[Constants.AISMessageNotification.Case] = eCase;

                if (Type == 0)
                    eAisNotification[Constants.AISMessageNotification.Type] = new OptionSetValue((int)Constants.AISMessageNotification.AISMessageNotification_Type.Error);
                else
                    eAisNotification[Constants.AISMessageNotification.Type] = new OptionSetValue((int)Constants.AISMessageNotification.AISMessageNotification_Type.Success);

                eAisNotification[Constants.AISMessageNotification.UserDefinedError] = UserDefinedError;

                eAisNotification[Constants.AISMessageNotification.SystemDefinedError] = SystemDefinedError;

                eAisNotification[Constants.AISMessageNotification.MethodName] = MethodName;

                Guid gAisNotificationId = service.Create(eAisNotification);
                eAisNotification.Id = gAisNotificationId;

                if (eAisNotification.Id != Guid.Empty)
                    bHasAisNotificationProcessed = true;

                trace.Trace($"AIS Message Notification: '{gAisNotificationId}' has been created successfully.");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                trace.Trace("Fault Exception Occured", ex);
            }
            catch (Exception ex) { exception = ex; }
            finally
            {
                if (exception != null)
                {
                    trace.Trace("AISMessageNotificationLogic.CreateAISMessageNotification" + exception);
                    //  throw new InvalidPluginExecutionException(exception.Message);
                }
            }
            trace.Trace("AISMessageNotificationLogic.CreateAISMessageNotification- Unloaded");
            return eAisNotification;
        }

        private Entity GetPolicy(Entity entity, IOrganizationService service, ITracingService trace, string policyNumber = null, ColumnSet column = null)
        {
            trace.Trace("AISMessageLogic.GetPolicy- Loaded");
            Exception exception = null;
            Entity ePolicyRecord = null;
            string sPolicyNumber = string.Empty
                    , entityName_Policy = string.Empty;
            EntityCollection ecPolicies = null;
            ColumnSet columns_Policy = null;
            OrderExpression order_Policy = null;
            FilterExpression filterExpression_Policy = null;
            int topCount_Policy;

            try
            {
                if (string.IsNullOrEmpty(policyNumber) && entity.Attributes.Contains(Constants.AISMessage.PolicyNumber))
                    sPolicyNumber = Convert.ToString(entity[Constants.AISMessage.PolicyNumber]);
                else
                    sPolicyNumber = policyNumber;

                trace.Trace($"sPolicyNumber: '{sPolicyNumber}'");

                if (column == null)
                {
                    columns_Policy = new ColumnSet(Constants.Policy.EntityId, Constants.Policy.Name, Constants.Policy.QuotePolicyVersion
                                        , Constants.Policy.PolicyStatus, Constants.Policy.PolicyKey, Constants.Policy.Broker
                                        , Constants.Policy.Customer, Constants.Policy.ModifiedOn, Constants.Policy.Owner, Constants.Policy.PolicySystem
                                        , Constants.Policy.ProductCode, Constants.Policy.ProductName, Constants.Policy.QuotePolicyStatus, Constants.Policy.QuotePolicyVersion);
                }
                else { columns_Policy = column; }

                trace.Trace($"columns_Policy: '{columns_Policy}'");

                topCount_Policy = 1; entityName_Policy = Constants.Policy.EntityName;
                order_Policy = new OrderExpression(Constants.Policy.ModifiedOn, OrderType.Descending);
                filterExpression_Policy = new FilterExpression
                {
                    FilterOperator = LogicalOperator.And,
                    Conditions =
                    {
                        new ConditionExpression(Constants.Policy.PolicySystem,ConditionOperator.Equal,(int)Constants.Policy.Policy_System.AIS),
                        new ConditionExpression(Constants.Policy.Name,ConditionOperator.Equal,sPolicyNumber)
                    }
                };
                ecPolicies = this.GetEntityCollection(service, trace, entityName_Policy, filterExpression_Policy, order_Policy, columns_Policy, topCount_Policy);
                if (ecPolicies != null && ecPolicies.Entities.Count > 0)
                    ePolicyRecord = ecPolicies[0];
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                trace.Trace("Fault Exception Occured", ex);
            }
            catch (Exception ex) { exception = ex; }
            finally
            {
                if (exception != null)
                {
                    trace.Trace("AISMessageLogic.GetPolicy" + exception);
                    //    throw new InvalidPluginExecutionException(exception.Message);
                }
            }
            trace.Trace("AISMessageLogic.GetPolicy- Unloaded");
            return ePolicyRecord;
        }



        public void TaskMechanism(Entity enTATMaisMessage, ITracingService trace, IOrganizationService service, decimal maxCountRetry)
        {
            Exception exception = null;
            string sPolicyNumber = string.Empty
                    , sQuoteNumber = string.Empty;

            try
            {
                trace.Trace($"entity.Id - Outside If: {enTATMaisMessage.Id}");
                decimal retrycount = enTATMaisMessage.Attributes.Contains(Constants.AISMessage.RetryCount) ? (decimal)enTATMaisMessage.Attributes[Constants.AISMessage.RetryCount] : 0;
                retrycount = retrycount + 1;
                if (enTATMaisMessage != null && enTATMaisMessage.GetAttributeValue<OptionSetValue>(Constants.AISMessage.MessageStatus).Value.Equals((int)Constants.AISMessage.AISMessage_Status.Waiting)) //if (entityCollection != null && entityCollection.Entities.Count > 0)
                {
                    //foreach (Entity enTATMaisMessage in entityCollection.Entities)
                    trace.Trace($"enTATMaisMessage.Id : {enTATMaisMessage.Id}");

                    //Entity enTATMaisMessage = entity;

                    if (!enTATMaisMessage.Attributes.ContainsKey(Constants.AISMessage.PolicyNumber) && !enTATMaisMessage.Attributes.ContainsKey(Constants.AISMessage.QuoteNumber))
                    {
                        trace.Trace($"Policy Number: '{enTATMaisMessage.Attributes.Contains(Constants.AISMessage.PolicyNumber)}' ");
                        trace.Trace($"Quote Number: '{enTATMaisMessage.Attributes.Contains(Constants.AISMessage.QuoteNumber)}' ");
                        trace.Trace($"enTATMaisMessage.Id:", enTATMaisMessage.Id);
                        trace.Trace($"RetryCount:", retrycount);
                        if (retrycount > maxCountRetry)
                        {
                            UpdateAISMessageStatus(service, trace, retrycount, enTATMaisMessage.Id, (int)Constants.AISMessage.AISMessage_Status.Error, Constants.AISMessage.PolicyNumberQuoteNumberDoesNotExist);
                        }
                        else
                        {
                            UpdateAISMessageStatus(service, trace, retrycount, enTATMaisMessage.Id, (int)Constants.AISMessage.AISMessage_Status.Waiting, Constants.AISMessage.PolicyNumberQuoteNumberDoesNotExist);
                        }
                        CreateAISMessageNotification(service, trace, enTATMaisMessage, null, null, null, 0, Constants.AISMessage.PolicyNumberQuoteNumberDoesNotExist, Constants.AISMessage.PolicyNumberQuoteNumberDoesNotExist, "Create AIS Message (Task)");
                        trace.Trace(Constants.AISMessage.PolicyNumberQuoteNumberDoesNotExist);
                        trace.Trace("AISMessageLogic.ProcessTaskAISMessages()- Unloaded");
                        return;
                    }

                    if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.PolicyNumber))
                    {
                        Entity entity_P = null;
                        ColumnSet columns_P = null;
                        string policyNumber = string.Empty
                                , title = string.Empty;

                        policyNumber = enTATMaisMessage[Constants.AISMessage.PolicyNumber].ToString();

                        columns_P = new ColumnSet(Constants.Policy.EntityId, Constants.Policy.Name, Constants.Policy.QuotePolicyVersion
        , Constants.Policy.PolicyStatus, Constants.Policy.PolicyKey, Constants.Policy.Broker
        , Constants.Policy.Customer, Constants.Policy.ModifiedOn, Constants.Policy.Owner, Constants.Policy.PolicySystem
        , Constants.Policy.ProductCode, Constants.Policy.ProductName, Constants.Policy.QuotePolicyStatus, Constants.Policy.QuotePolicyVersion);

                        entity_P = GetPolicy(enTATMaisMessage, service, trace, policyNumber, columns_P);
                        trace.Trace("Entity Policy");
                        trace.Trace($"entity_P: '{entity_P}'");
                        trace.Trace("Entity Policy Fetched");
                        if (entity_P != null && entity_P.Id != Guid.Empty)
                        {
                            Entity enCaseCreate = new Entity(Constants.Case.EntityName);
                            enCaseCreate[Constants.Case.PolicyId] = new EntityReference(Constants.Policy.EntityName, entity_P.Id);

                            trace.Trace($"Entity: '{Constants.Case.EntityName}'");

                            EntityReference erBroker = null;
                            bool bDoesBrokerExist = false;
                            if (entity_P.Attributes.Contains(Constants.Policy.Broker))
                            {
                                erBroker = entity_P.GetAttributeValue<EntityReference>(Constants.Policy.Broker);
                                bDoesBrokerExist = true;
                                trace.Trace($"Fetched Broker 1: '{erBroker}' ");
                            }
                            else if (erBroker == null && enTATMaisMessage.Attributes.Contains(Constants.AISMessage.Broker))
                            {
                                erBroker = enTATMaisMessage.GetAttributeValue<EntityReference>(Constants.AISMessage.Broker);
                                bDoesBrokerExist = true;
                                trace.Trace($"Fetched Broker 2: '{erBroker}' ");
                            }
                            else
                            {
                                //Do nothing
                                trace.Trace($"No Broker");

                            }


                            if (erBroker != null)
                                enCaseCreate[Constants.Case.Broker] = enCaseCreate[Constants.Case.CustomerId] = erBroker;
                            else
                            {
                                trace.Trace($"enTATMaisMessage.Id:", enTATMaisMessage.Id);
                                trace.Trace($"RetryCount:", retrycount);

                                if (retrycount > maxCountRetry)
                                {
                                    UpdateAISMessageStatus(service, trace, retrycount, enTATMaisMessage.Id, (int)Constants.AISMessage.AISMessage_Status.ProcessedwithError, Constants.AISMessage.BrokerDoesNotExist);
                                }
                                else
                                {
                                    UpdateAISMessageStatus(service, trace, retrycount, enTATMaisMessage.Id, (int)Constants.AISMessage.AISMessage_Status.Waiting, Constants.AISMessage.BrokerDoesNotExist);
                                }
                               // this.UpdateAISMessageStatus(service, trace, retrycount, enTATMaisMessage.Id, (int)Constants.AISMessage.AISMessage_Status.ProcessedwithError, Constants.AISMessage.BrokerDoesNotExist);
                                this.CreateAISMessageNotification(service, trace, enTATMaisMessage, entity_P, null, null, 0, Constants.AISMessage.BrokerDoesNotExist, Constants.AISMessage.BrokerDoesNotExist, "Create Case for Policy");
                                trace.Trace($"AIS Message: '{enTATMaisMessage.Id.ToString()}' doesn't have Broker to be processed.");

                            }

                            EntityReference erCustomer = null;
                            if (entity_P.Attributes.Contains(Constants.Policy.Customer))
                                erCustomer = entity_P.GetAttributeValue<EntityReference>(Constants.Policy.Customer);
                            else if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.Customer))
                                erCustomer = enTATMaisMessage.GetAttributeValue<EntityReference>(Constants.AISMessage.Customer);

                            if (erCustomer != null)
                                enCaseCreate[Constants.Case.Customer] = erCustomer;

                            if (!string.IsNullOrEmpty(title))
                            {
                                //enCaseCreate[Constants.Case.Title] = title;
                                enCaseCreate[Constants.Case.Subject] = title;
                            }

                            if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.Description))
                                enCaseCreate[Constants.Case.Description] = enTATMaisMessage[Constants.AISMessage.Description];

                            if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.DueDate))
                                enCaseCreate[Constants.Case.AISTaskDueDate] = enTATMaisMessage[Constants.AISMessage.DueDate];

                            if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.CustomerPhysicalAddress))
                                enCaseCreate[Constants.Case.CustomerPhysicalAddress] = enTATMaisMessage[Constants.AISMessage.CustomerPhysicalAddress];

                            if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.CustomerPostCode))
                                enCaseCreate[Constants.Case.CustomerPostCode] = enTATMaisMessage[Constants.AISMessage.CustomerPostCode];

                            if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.CustomerPhoneNumber1))
                                enCaseCreate[Constants.Case.CustomerPhoneNumber1] = enTATMaisMessage[Constants.AISMessage.CustomerPhoneNumber1];

                            if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.CustomerEmailAddress1))
                                enCaseCreate[Constants.Case.CustomerEmailAddress1] = enTATMaisMessage[Constants.AISMessage.CustomerEmailAddress1];

                            if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.RouteOfSale))
                                enCaseCreate[Constants.Case.RouteOfSale] = enTATMaisMessage.FormattedValues[Constants.AISMessage.RouteOfSale];

                            //Setting case type as SME Renewal Review
                            enCaseCreate[Constants.Case.CaseType] = new EntityReference("rsa_casetype", new Guid("8caa1262-f6e2-ea11-a818-000d3a649f51"));
                            trace.Trace("Case Type" + enCaseCreate[Constants.Case.CaseType]);
                            //Setting status as New
                            enCaseCreate[Constants.Case.Status] = new EntityReference("rsa_status", new Guid("8e97b842-f7e2-ea11-a816-000d3a64927d"));
                            trace.Trace("Status" + enCaseCreate[Constants.Case.Status]);

                            Guid guid = service.Create(enCaseCreate);
                            trace.Trace($"Case Created: '{title}'");
                            trace.Trace($"enTATMaisMessage.Id:", enTATMaisMessage.Id);
                            trace.Trace($"RetryCount:", retrycount);
                            if (retrycount > maxCountRetry)
                            {
                                UpdateAISMessageStatus(service, trace, retrycount, enTATMaisMessage.Id, (int)Constants.AISMessage.AISMessage_Status.Processed);
                            }
                            else
                            {
                                UpdateAISMessageStatus(service, trace, retrycount, enTATMaisMessage.Id, (int)Constants.AISMessage.AISMessage_Status.Processed);
                            }
                            //this.UpdateAISMessageStatus(service, trace, retrycount, enTATMaisMessage.Id, (int)Constants.AISMessage.AISMessage_Status.Processed);
                            this.CreateAISMessageNotification(service, trace, enTATMaisMessage, entity_P, null, new EntityReference(Constants.Case.EntityName, guid), 1, "Message processed successfully", "Message processed successfully", "Create Case for Policy");

                        }
                        else
                        {
                            trace.Trace("Entity not Fetched");
                            trace.Trace($"enTATMaisMessage.Id:", enTATMaisMessage.Id);
                            trace.Trace($"RetryCount:", retrycount);

                            if (retrycount > maxCountRetry)
                            {
                                UpdateAISMessageStatus(service, trace, retrycount, enTATMaisMessage.Id, (int)Constants.AISMessage.AISMessage_Status.Error, Constants.AISMessage.PolicyDoesNotExist);
                            }
                            else
                            {
                                UpdateAISMessageStatus(service, trace, retrycount, enTATMaisMessage.Id, (int)Constants.AISMessage.AISMessage_Status.Waiting, Constants.AISMessage.PolicyDoesNotExist);
                            }

                           // this.UpdateAISMessageStatus(service, trace, retrycount, enTATMaisMessage.Id, (int)Constants.AISMessage.AISMessage_Status.Error, Constants.AISMessage.PolicyDoesNotExist);
                            this.CreateAISMessageNotification(service, trace, enTATMaisMessage, null, null, null, 0, Constants.AISMessage.PolicyDoesNotExist, Constants.AISMessage.PolicyDoesNotExist, "Create Case for Policy");

                        }


                    }
                    else if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.QuoteNumber))
                    {
                        FilterExpression filterExpression_Q = null;
                        OrderExpression orderExpression_Q = null;
                        EntityCollection entityCollection_Q = null;
                        Entity entity_Q = null;
                        ColumnSet columns_Q = null;
                        string quoteNumber = string.Empty;

                        quoteNumber = enTATMaisMessage[Constants.AISMessage.QuoteNumber].ToString();
                        trace.Trace($"Quote Number : '{quoteNumber}'");
                        columns_Q = new ColumnSet(Constants.Quote.AgentCode, Constants.Quote.AgentName, Constants.Quote.AnnualPremiumincludingTaxes
                                                    , Constants.Quote.AnnualRevisedPremium, Constants.Quote.Brokerid, Constants.Quote.ClassOfBusiness, Constants.Quote.CodetorelateQuotesPolicies
                                                    , Constants.Quote.Customer, Constants.Quote.IsDeleted, Constants.Quote.EffectiveDate, Constants.Quote.InceptionDate
                                                    , Constants.Quote.Owner, Constants.Quote.PL, Constants.Quote.PolicyMovementReasonId, Constants.Quote.PolicyMovementType
                                                    , Constants.Quote.PolicyRenewalDate, Constants.Quote.Premium, Constants.Quote.PrimaryReference, Constants.Quote.ProductId
                                                    , Constants.Quote.ProductName, Constants.Quote.QuoteExpirationDate, Constants.Quote.Name
                                                    , Constants.Quote.QuotePolicyVersion, Constants.Quote.ReasonforDivertDecline, Constants.Quote.RenewalIndicator, Constants.Quote.RevisedPremium
                                                    , Constants.Quote.RouteOfsale, Constants.Quote.SchemeDescription, Constants.Quote.SystemModStamp, Constants.Quote.TransactionalPremiumincludingtaxes
                                                    , Constants.Quote.TransactionalRevisedPremium);
                        filterExpression_Q = new FilterExpression
                        {
                            FilterOperator = LogicalOperator.And,
                            Conditions = { new ConditionExpression(Constants.Quote.Name, ConditionOperator.Equal, quoteNumber) }
                        };
                        columns_Q = new ColumnSet(Constants.Quote.EntityId, Constants.Quote.Name);

                        trace.Trace($"entityCollection_Q: '{entityCollection_Q}'");

                        orderExpression_Q = new OrderExpression(Constants.Quote.ModifiedOn, OrderType.Descending);

                        entityCollection_Q = GetEntityCollection(service, trace, Constants.Quote.EntityName, filterExpression_Q, orderExpression_Q, columns_Q, 1);

                        if (entityCollection_Q != null && entityCollection_Q.Entities.Count != 0)
                            entity_Q = entityCollection_Q[0];

                        trace.Trace($"entity_Q: '{entity_Q}'");

                        if (entity_Q != null && entity_Q.Id != Guid.Empty)
                        {
                            string title = string.Empty;

                            Entity enCaseCreate = new Entity(Constants.Case.EntityName);

                            enCaseCreate[Constants.Case.QuoteId] = new EntityReference(entity_Q.LogicalName, entity_Q.Id);

                            EntityReference erBroker = null;
                            bool bDoesBrokerExist = false;
                            if (entity_Q.Attributes.Contains(Constants.Quote.Broker))
                            {
                                erBroker = entity_Q.GetAttributeValue<EntityReference>(Constants.Quote.Broker);
                                bDoesBrokerExist = true;
                                trace.Trace($"Fetched Broker 1: '{erBroker}' ");
                            }
                            else if (erBroker == null && enTATMaisMessage.Attributes.Contains(Constants.AISMessage.Broker))
                            {
                                erBroker = enTATMaisMessage.GetAttributeValue<EntityReference>(Constants.AISMessage.Broker);
                                bDoesBrokerExist = true;
                                trace.Trace($"Fetched Broker 2: '{erBroker}' ");
                            }
                            else
                            {
                                trace.Trace($"No Broker");
                                //Do Nothing
                            }


                            if (erBroker != null)
                                enCaseCreate[Constants.Case.Broker] = enCaseCreate[Constants.Case.CustomerId] = erBroker;

                            else
                            {
                                trace.Trace($"enTATMaisMessage.Id:", enTATMaisMessage.Id);
                                trace.Trace($"RetryCount:", retrycount);

                                if (retrycount > maxCountRetry)
                                {
                                    UpdateAISMessageStatus(service, trace, retrycount, enTATMaisMessage.Id, (int)Constants.AISMessage.AISMessage_Status.ProcessedwithError, Constants.AISMessage.BrokerDoesNotExist);
                                }
                                else
                                {
                                    UpdateAISMessageStatus(service, trace, retrycount, enTATMaisMessage.Id, (int)Constants.AISMessage.AISMessage_Status.Waiting, Constants.AISMessage.BrokerDoesNotExist);
                                }
                               // this.UpdateAISMessageStatus(service, trace, retrycount, enTATMaisMessage.Id, (int)Constants.AISMessage.AISMessage_Status.ProcessedwithError, Constants.AISMessage.BrokerDoesNotExist);
                                this.CreateAISMessageNotification(service, trace, enTATMaisMessage, null, entity_Q, null, 0, Constants.AISMessage.BrokerDoesNotExist, Constants.AISMessage.BrokerDoesNotExist, "Create Case for Quote");
                                trace.Trace($"AIS Message: '{enTATMaisMessage.Id.ToString()}' doesn't have Broker to be processed.");

                            }

                            EntityReference erCustomer = null;
                            if (entity_Q.Attributes.Contains(Constants.Quote.Customer))
                                erCustomer = entity_Q.GetAttributeValue<EntityReference>(Constants.Quote.Customer);

                            else if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.Customer))
                                erCustomer = enTATMaisMessage.GetAttributeValue<EntityReference>(Constants.AISMessage.Customer);

                            if (erCustomer != null)
                                enCaseCreate[Constants.Case.Customer] = erCustomer;

                            trace.Trace($"Fetched Customer: '{erCustomer}' ");

                            //if (aisMessage.Attributes.Contains(Constants.AISMessage.Title))
                            //    title = aisMessage[Constants.AISMessage.Title].ToString();

                            //if (string.IsNullOrEmpty(title) && entity_Q.Attributes.Contains(Constants.Quote.Name))
                            //    title = entity_Q[Constants.Quote.Name].ToString();

                            if (!string.IsNullOrEmpty(title))
                            {
                                // enCaseCreate[Constants.Case.Title] = title;
                                enCaseCreate[Constants.Case.Subject] = title;
                            }

                            if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.Description))
                                enCaseCreate[Constants.Case.Description] = enTATMaisMessage[Constants.AISMessage.Description];

                            if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.DueDate))
                                enCaseCreate[Constants.Case.AISTaskDueDate] = enTATMaisMessage[Constants.AISMessage.DueDate];

                            if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.CustomerPhysicalAddress))
                                enCaseCreate[Constants.Case.CustomerPhysicalAddress] = enTATMaisMessage[Constants.AISMessage.CustomerPhysicalAddress];

                            if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.CustomerPostCode))
                                enCaseCreate[Constants.Case.CustomerPostCode] = enTATMaisMessage[Constants.AISMessage.CustomerPostCode];

                            if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.CustomerPhoneNumber1))
                                enCaseCreate[Constants.Case.CustomerPhoneNumber1] = enTATMaisMessage[Constants.AISMessage.CustomerPhoneNumber1];

                            if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.CustomerEmailAddress1))
                                enCaseCreate[Constants.Case.CustomerEmailAddress1] = enTATMaisMessage[Constants.AISMessage.CustomerEmailAddress1];

                            if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.RouteOfSale))
                                enCaseCreate[Constants.Case.RouteOfSale] = enTATMaisMessage.FormattedValues[Constants.AISMessage.RouteOfSale];

                            //Setting case type as SME Renewal Review
                            enCaseCreate[Constants.Case.CaseType] = new EntityReference("rsa_casetype", new Guid("8caa1262-f6e2-ea11-a818-000d3a649f51"));
                            trace.Trace("Case Type" + enCaseCreate[Constants.Case.CaseType]);

                            //Setting status as New
                            enCaseCreate[Constants.Case.Status] = new EntityReference("rsa_status", new Guid("8e97b842-f7e2-ea11-a816-000d3a64927d"));
                            trace.Trace("Status" + enCaseCreate[Constants.Case.Status]);

                            Guid guid = service.Create(enCaseCreate);
                            trace.Trace($"enTATMaisMessage.Id:", enTATMaisMessage.Id);
                            trace.Trace($"RetryCount:", retrycount);
                            if (retrycount > maxCountRetry)
                            {
                                UpdateAISMessageStatus(service, trace, retrycount, enTATMaisMessage.Id, (int)Constants.AISMessage.AISMessage_Status.Processed);
                            }
                            else
                            {
                                UpdateAISMessageStatus(service, trace, retrycount, enTATMaisMessage.Id, (int)Constants.AISMessage.AISMessage_Status.Processed);
                            }
                            //UpdateAISMessageStatus(service, trace, retrycount, enTATMaisMessage.Id, (int)Constants.AISMessage.AISMessage_Status.Processed);
                            CreateAISMessageNotification(service, trace, enTATMaisMessage, null, entity_Q, new EntityReference(Constants.Case.EntityName, guid), 1, "Message processed successfully", "Message processed successfully", "Create Case for Quote");

                        }
                        else
                        {
                            trace.Trace($"enTATMaisMessage.Id:", enTATMaisMessage.Id);
                            trace.Trace($"RetryCount:", retrycount);
                            if (retrycount > maxCountRetry)
                            {
                                UpdateAISMessageStatus(service, trace, retrycount, enTATMaisMessage.Id, (int)Constants.AISMessage.AISMessage_Status.Error , Constants.AISMessage.QuoteDoesNotExist);
                            }
                            else
                            {
                                UpdateAISMessageStatus(service, trace, retrycount, enTATMaisMessage.Id, (int)Constants.AISMessage.AISMessage_Status.Waiting, Constants.AISMessage.QuoteDoesNotExist);
                            }
                           // UpdateAISMessageStatus(service, trace, retrycount, enTATMaisMessage.Id, (int)Constants.AISMessage.AISMessage_Status.Error, Constants.AISMessage.QuoteDoesNotExist);
                            CreateAISMessageNotification(service, trace, enTATMaisMessage, null, null, null, 0, Constants.AISMessage.QuoteDoesNotExist, Constants.AISMessage.QuoteDoesNotExist, "Create Case for Quote");

                        }
                    }

                }
            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                trace.Trace("Fault Exception Occured", ex);
            }
            catch (Exception ex) { exception = ex; }
            finally
            {
                if (exception != null)
                {
                    trace.Trace("AISMessageLogic.ProcessTaskAISMessages" + exception);
                    //throw new InvalidPluginExecutionException(exception.Message);
                }
            }
            trace.Trace("AISMessageLogic.ProcessTaskAISMessages()- Unloaded");
        }

    }
}

