﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using RSA.CSI.Plugins.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using static RSA.CSI.Plugins.Helper.Plugin;
using System.Text.RegularExpressions;
using System.Runtime.Serialization;
using System.IO;
using System.Runtime.Serialization.Json;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Messages;

namespace RSA.CSI.Common.Logic
{
    public class AISMessageLogic
    {
        #region Global variables
        /// <summary>
        /// Global variables
        /// </summary>
        private readonly PluginContext pluginContext;
        private readonly IPluginExecutionContext context;
        private readonly IOrganizationService service;
        private readonly ITracingService tracingService;
        private readonly Entity entity;
        private Entity ePolicy;
        private Entity eCustomer;
        private Entity eBroker;
        private EntityReference erCustomer;
        private Entity eQuote;
        private EntityReference erBroker;
        private EntityReference erPolicy;
        private EntityReference erProduct;
        private readonly EntityReference entityRef;
        private readonly Guid gInitiatingUserId;
        private bool bDoesBrokerExist = false;
        #endregion Global variables

        #region Constructor
        /// <summary>
        /// AISMessageLogic Constructor
        /// </summary>
        /// <param name="service">IOrganizationService object</param>
        /// <param name="tracingService">ITracingService object</param>
        /// <param name="eTask">Target entity</param>
        /// <param name="eTaskRef">EntityReference for delete opeartions message, otherwise keep it null.</param>
        /// <param name="gLoggedInUserId">Plugin Initiating User Id</param>
        public AISMessageLogic(PluginContext oPluginContext, Entity oEntity, EntityReference oEntityRef)
        {
            pluginContext = oPluginContext;
            context = pluginContext.PluginExecutionContext;
            service = pluginContext.OrganizationService;
            tracingService = pluginContext.TracingService;
            entity = oEntity;
            entityRef = oEntityRef;
            gInitiatingUserId = context.InitiatingUserId;
        }

        /*
        public AISMessageLogic(IOrganizationService oService, Entity oEntity, EntityReference oEntityRef)
        {
            //pluginContext = oPluginContext;
            //context = pluginContext.PluginExecutionContext;
            service = oService;
            //tracingService = pluginContext.TracingService;
            entity = oEntity;
            entityRef = oEntityRef;
            //gInitiatingUserId = context.InitiatingUserId;
        }
        */
        #endregion Constructor

        #region Public Subs / Functions
        /// <summary>
        /// PreCreate plugin main method
        /// </summary>
        public void PreCreate()
        {
            Exception exception = null;
            pluginContext.LogMessage("AISMessageLogic.PreCreate()- Loaded");
            try
            {
                this.ValidateAISMessagePreCreate();
                this.ValidateAISMessagePostProcessing();
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                pluginContext.ThrowException("Fault Exception Occured", ex);
            }
            catch (Exception ex) { exception = ex; }
            finally
            {
                if (exception != null)
                {
                    pluginContext.LogException(exception, "AISMessageLogic.PreCreate");
                    //throw new InvalidPluginExecutionException(exception.Message);
                }
            }

            pluginContext.LogMessage("AISMessageLogic.PreCreate()- Unloaded");
        }

        /// <summary>
        /// PostCreate plugin main method
        /// </summary>
        public void PostCreate()
        {
            Exception exception = null;
            pluginContext.LogMessage("AISMessageLogic.PostCreate()- Loaded");
            try
            {
                Boolean isCustomerCreated = false,
                        bFoundMatchingCustomer = false,
                        doesMessageTypeExist = false;

                string sMessageType = "";
                if (!entity.Attributes.Contains(Constants.AISMessage.MessageType))
                {

                    pluginContext.LogMessage(Constants.AISMessage.MessageTypeDoesNotExist);
                    this.UpdateAISMessageStatus((int)Constants.AISMessage.AISMessage_Status.Error, Constants.AISMessage.MessageTypeDoesNotExist);
                    this.CreateAISMessageNotification(entity, null, null, null, 0, Constants.AISMessage.MessageTypeDoesNotExist, Constants.AISMessage.MessageTypeDoesNotExist, "Create AIS Message");
                    pluginContext.LogMessage("AISMessageLogic.PostCreate()- Unloaded");
                    return;
                }

                //Create SME Staging
                if (entity.Attributes.Contains(Constants.AISMessage.MessageType))
                {
                    sMessageType = entity.FormattedValues[Constants.AISMessage.MessageType].Trim();
                    pluginContext.LogMessage($"sMessageTypeName: '{sMessageType}' | doesMessageTypeExist = true");
                    doesMessageTypeExist = true;
                }

                if (entity.Attributes.Contains(Constants.AISMessage.AgentCode))
                {
                    var priamryReference = Convert.ToString(entity.Attributes[Constants.AISMessage.AgentCode]);
                    if (!string.IsNullOrEmpty(priamryReference))
                    {
                        object[] oRSACustomeLabels_DummyBroker = { Constants.RSACustomLabel.AIS_Dummy_Broker__PrimaryRefrence };
                        List<string> brokerPrimaryReferences = new List<string>();
                        EntityCollection ecRSACustomLabels_DummyBroker = this.GetCustomLabel(oRSACustomeLabels_DummyBroker);
                        if (ecRSACustomLabels_DummyBroker != null && ecRSACustomLabels_DummyBroker.Entities.Count > 0 && ecRSACustomLabels_DummyBroker[0].Contains(Constants.RSACustomLabel.Values)
                                               && !string.IsNullOrEmpty(ecRSACustomLabels_DummyBroker[0][Constants.RSACustomLabel.Values].ToString()))
                        {
                            string customValue = ecRSACustomLabels_DummyBroker[0][Constants.RSACustomLabel.Values].ToString();
                            brokerPrimaryReferences = customValue.Split(",").ToList();
                        }
                        if (brokerPrimaryReferences.Any(p => p == priamryReference))
                        {
                            pluginContext.LogMessage(Constants.AISMessage.MessageDummyBroker);
                            this.UpdateAISMessageStatus((int)Constants.AISMessage.AISMessage_Status.Error, Constants.AISMessage.MessageDummyBroker);
                            this.CreateAISMessageNotification(entity, null, null, null, 0, Constants.AISMessage.MessageDummyBroker, Constants.AISMessage.MessageDummyBroker, "Create AIS Message");
                            pluginContext.LogMessage("AISMessageLogic.PostCreate()- Unloaded");
                            return;
                        }
                    }
                }

                string sCustomerName = string.Empty;
                string sPostalCode = string.Empty;
                string externalid = string.Empty;
                if (entity.Attributes.Contains(Constants.AISMessage.CustomerBusinessName))
                    sCustomerName = Convert.ToString(entity[Constants.AISMessage.CustomerBusinessName]);
                if (string.IsNullOrEmpty(sCustomerName) && entity.Attributes.Contains(Constants.AISMessage.CustomerName))
                    sCustomerName = Convert.ToString(entity[Constants.AISMessage.CustomerName]);
                if (!string.IsNullOrEmpty(sCustomerName))
                    sCustomerName = sCustomerName.Trim();

                //Modified by: Samiksha Dhakde on 11:01:2023
                if (entity.Attributes.Contains(Constants.AISMessage.CustomerPostCode))
                    sPostalCode = Convert.ToString(entity[Constants.AISMessage.CustomerPostCode]);
                if (!string.IsNullOrEmpty(sCustomerName) && !string.IsNullOrEmpty(sPostalCode))
                {
                    externalid = sCustomerName + ":" + sPostalCode;
                }

                if (!string.IsNullOrEmpty(externalid))
                {
                    FilterExpression filterEx = null;
                    ColumnSet column = null;
                    OrderExpression order = null;

                    filterEx = new FilterExpression
                    {
                        FilterOperator = LogicalOperator.And,
                        //Conditions = { new ConditionExpression(Constants.Customer.Name, ConditionOperator.Like, $"%{sCustomerName}%") }
                        //Defect : 2096
                        //Conditions = { new ConditionExpression(Constants.Customer.Name, ConditionOperator.Equal, $"{sCustomerName}") }
                        Conditions = { new ConditionExpression(Constants.Customer.ExternalId, ConditionOperator.Equal, $"{externalid}") }
                    };
                    column = new ColumnSet(Constants.Customer.EntityId, Constants.Customer.Name, Constants.Customer.ExternalId);
                    order = new OrderExpression(Constants.Customer.ModifiedOn, OrderType.Descending);
                    EntityCollection ecCustomerColl = this.GetEntityCollection(Constants.Customer.EntityName, filterEx, order, column, 1);
                    string postCode = string.Empty;
                    //if (sMessageType == "Policy" || sMessageType == "Quote")
                    //{
                    if (ecCustomerColl != null && ecCustomerColl.Entities.Count != 0)
                    {
                        eCustomer = ecCustomerColl[0];
                        pluginContext.LogMessage("Calling CreateSMECustomerStaging on Create of AIS Message");
                        postCode = entity.Attributes.Contains(Constants.AISMessage.CustomerPostCode) ? entity.GetAttributeValue<string>(Constants.AISMessage.CustomerPostCode) : string.Empty;
                        tracingService.Trace("Post Code is :" + postCode);
                    }

                    //    //======================SAMIKSHA DHAKDE (23/01/2023) START==============================================
                    //    else
                    //    {
                    //        // Modified by: Samiksha Dhakde || Modified on: 26-12-2022
                    //        // Create customer record if the external id i.e. Customer Name + Postal Code provided does not exist in dynamics.
                    //        pluginContext.LogMessage("Start Creating the customer record as Customer provided doesn't exist in dynamics");
                    //        isCustomerCreated = false;
                    //        eCustomer = this.CreateCustomer(out isCustomerCreated);
                    //        bFoundMatchingCustomer = true;
                    //        isCustomerCreated = true;
                    //        tracingService.Trace("Customer Record successfully Created");
                    //        tracingService.Trace("Mapping Customer record to AIS Message eCustomer " + eCustomer);
                    //        if (eCustomer != null)
                    //        {
                    //            tracingService.Trace("eCustomer PostCreate is not null");
                    //            entity[Constants.AISMessage.Customer] = new EntityReference(eCustomer.LogicalName, eCustomer.Id);
                    //        }
                    //    }
                    //}
                    //======================SAMIKSHA DHAKDE (23/01/2023) END==============================================

                    //postCode = entity.Attributes.Contains(Constants.AISMessage.CustomerPostCode) ? entity.GetAttributeValue<string>(Constants.AISMessage.CustomerPostCode) : string.Empty;
                    //string customerKey = sCustomerName + ":" + postCode;
                    //tracingService.Trace("Customer Key:" + customerKey);
                    //tracingService.Trace("Post Code:" + postCode);
                    //tracingService.Trace("Customer Name:" + sCustomerName);


                    Entity getCustomer = null;
                    QueryExpression query1 = new QueryExpression(Constants.Customer.EntityName);
                    query1.ColumnSet = new ColumnSet(true);
                    query1.NoLock = true;
                    query1.Criteria.AddFilter(LogicalOperator.And);
                    query1.Criteria.AddCondition(Constants.Customer.ExternalId, ConditionOperator.Equal, externalid);
                    query1.Criteria.AddCondition(Constants.Customer.Name, ConditionOperator.Equal, sCustomerName);
                    EntityCollection cus1 = service.RetrieveMultiple(query1);

                    tracingService.Trace("cus1 : " + cus1);
                    tracingService.Trace("cus1 count : " + cus1.Entities.Count);
                    if (cus1 != null && cus1.Entities.Count > 0 && !string.IsNullOrEmpty(postCode))
                    {
                        tracingService.Trace(cus1.Entities.Count().ToString());
                        getCustomer = cus1.Entities[0];
                        CreateSMECustomerStaging(getCustomer, sCustomerName, entity, postCode, 1);
                    }

                    else if (cus1.Entities.Count == 0)
                    {
                        string[] customerKeyWord = sCustomerName.Split(' ');
                        string cuskeyword = null;
                        string keywordPrefixValue3 = string.Empty;
                        if (customerKeyWord[0].Equals("Mrs") || customerKeyWord[0].Equals("Mr") || customerKeyWord[0].Equals("Miss"))
                        {
                            cuskeyword = customerKeyWord[1].ToUpperInvariant();
                        }
                        else
                        {
                            cuskeyword = customerKeyWord[0].ToUpperInvariant();
                        }
                        if (cuskeyword != null)
                        {

                            var len = cuskeyword.Length;
                            if (len == 1)
                            {
                                keywordPrefixValue3 = String.Concat(cuskeyword, "_");
                            }
                            else if (len == 2)
                            {
                                keywordPrefixValue3 = String.Concat(cuskeyword, "_");
                            }
                            else
                            {
                                keywordPrefixValue3 = cuskeyword.Substring(0, 3);
                            }
                        }
                        tracingService.Trace("KeywordPrefixValue3 :" + keywordPrefixValue3);

                        string stripped = Regex.Replace(sCustomerName.ToLowerInvariant(), @"[^0-9a-zA-Z]+", " ");
                        string customerStripped = "[" + Regex.Replace(stripped, @"\s+", " ") + "]";
                        tracingService.Trace("Keyword Check Name:" + customerStripped);

                        QueryExpression query2 = new QueryExpression(Constants.Customer.EntityName);
                        query2.ColumnSet = new ColumnSet(true);
                        query2.NoLock = true;
                        query2.Criteria.AddFilter(LogicalOperator.And);
                        query2.Criteria.AddCondition(Constants.Customer.KeywordPrefix3Value, ConditionOperator.Equal, keywordPrefixValue3);
                        query2.Criteria.AddCondition(Constants.Customer.Name, ConditionOperator.Equal, sCustomerName);
                        query2.Criteria.AddCondition(Constants.Customer.KeywordCheckName, ConditionOperator.Equal, customerStripped);
                        EntityCollection cus2 = service.RetrieveMultiple(query2);
                        tracingService.Trace(cus2.Entities.Count().ToString());

                        if (cus2 != null && cus2.Entities.Count > 0)
                        {
                            getCustomer = cus2.Entities[0];
                            CreateSMECustomerStaging(getCustomer, sCustomerName, entity, postCode, 3);
                        }
                        else
                        {
                            tracingService.Trace("No Duplicates");
                            CreateSMECustomerStaging(null, sCustomerName, entity, postCode, 4);
                        }

                    }
                }

                //Commented by Samiksha Dhakde: 11/01/2023 :AIS Message Notification while customerdoesnotexist is handled in functions
                //else
                //{
                //    pluginContext.LogMessage(Constants.AISMessage.CustomerDoesNotExist);
                //    this.UpdateAISMessageStatus((int)Constants.AISMessage.AISMessage_Status.Error, Constants.AISMessage.CustomerDoesNotExist);

                //    this.CreateAISMessageNotification(entity, null, null, null, 0, Constants.AISMessage.CustomerDoesNotExist, Constants.AISMessage.CustomerDoesNotExist, "Create AIS Message");
                //    pluginContext.LogMessage("AISMessageLogic.PostCreate()- Unloaded");
                //    return;
                //}

                string sMessageTypeName = string.Empty;
                sMessageTypeName = entity.FormattedValues[Constants.AISMessage.MessageType].Trim();
                pluginContext.LogMessage($"sMessageTypeName: '{sMessageTypeName}'");
                switch (sMessageTypeName)
                {
                    case Constants.Policy.DisplayName:
                        this.ProcessPolicyAISMessage();
                        break;
                    case Constants.Quote.DisplayName:
                        this.ProcessQuoteAISMessage();
                        break;
                    case Constants.Task.DisplayName:
                        this.ProcessTaskAISMessage();
                        break;
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                //pluginContext.ThrowException("Fault Exception Occured", ex);
            }
            catch (Exception ex) { exception = ex; }
            finally
            {
                if (exception != null)
                {
                    pluginContext.LogException(exception, "AISMessageLogic.PostCreate");
                    //throw new InvalidPluginExecutionException(exception.Message);
                }
            }
            pluginContext.LogMessage("AISMessageLogic.PostCreate()- Unloaded");
        }



        /// <summary>
        /// ProcessTaskAISMessage custom action main method.
        /// </summary>
        public void TaskAISMessagesAction()
        {
            pluginContext.LogMessage("AISMessageLogic.ProcessTaskAISMessages()- Loaded");
            Exception exception = null;
            string sPolicyNumber = string.Empty
                    , sQuoteNumber = string.Empty;

            //FilterExpression filterExpression = null;
            //ColumnSet columns = null;
            //OrderExpression orderExpression = null;
            //EntityCollection entityCollection = null;
            //int topCount;

            try
            {
                //topCount = Constants.AISMessage.TaskAISMessagesAction_TopCount;
                //filterExpression = new FilterExpression
                //{
                //    FilterOperator = LogicalOperator.And,
                //    Conditions = {
                //        new ConditionExpression(Constants.AISMessage.MessageStatus, ConditionOperator.Equal, (int)Constants.AISMessage.AISMessage_Status.Waiting),
                //        new ConditionExpression(Constants.AISMessage.MessageType, ConditionOperator.Equal, (int)Constants.AISMessage.AISMessage_Message_Type.Task),
                //        new ConditionExpression(Constants.AISMessage.CreatedOn, ConditionOperator.OnOrAfter, DateTime.Today.Date),
                //    }

                //};


                //columns = new ColumnSet(true);
                //orderExpression = new OrderExpression(Constants.AISMessage.ModifiedOn, OrderType.Descending);

                //entityCollection = this.GetEntityCollection(Constants.AISMessage.EntityName, filterExpression, orderExpression, columns, topCount);

                pluginContext.LogMessage($"entity.Id - Outside If: {entity.Id}");
                Entity enTATMaisMessage = service.Retrieve(Constants.AISMessage.EntityName, entity.Id, new ColumnSet(true));
      
                if (enTATMaisMessage != null && enTATMaisMessage.GetAttributeValue<OptionSetValue>(Constants.AISMessage.MessageStatus).Value.Equals((int)Constants.AISMessage.AISMessage_Status.Waiting)) //if (entityCollection != null && entityCollection.Entities.Count > 0)
                {
                    //foreach (Entity enTATMaisMessage in entityCollection.Entities)
                    pluginContext.LogMessage($"enTATMaisMessage.Id : {enTATMaisMessage.Id}");

                    //Entity enTATMaisMessage = entity;

                    if (!enTATMaisMessage.Attributes.ContainsKey(Constants.AISMessage.PolicyNumber) && !enTATMaisMessage.Attributes.ContainsKey(Constants.AISMessage.QuoteNumber))
                    {
                        pluginContext.LogMessage($"Policy Number: '{enTATMaisMessage.Attributes.Contains(Constants.AISMessage.PolicyNumber)}' ");
                        pluginContext.LogMessage($"Quote Number: '{enTATMaisMessage.Attributes.Contains(Constants.AISMessage.QuoteNumber)}' ");

                        this.UpdateAISMessageStatus((int)Constants.AISMessage.AISMessage_Status.Waiting, Constants.AISMessage.PolicyNumberQuoteNumberDoesNotExist);
                        this.CreateAISMessageNotification(enTATMaisMessage, null, null, null, 0, Constants.AISMessage.PolicyNumberQuoteNumberDoesNotExist, Constants.AISMessage.PolicyNumberQuoteNumberDoesNotExist, "Create AIS Message (Task)");
                        pluginContext.LogMessage(Constants.AISMessage.PolicyNumberQuoteNumberDoesNotExist);
                        pluginContext.LogMessage("AISMessageLogic.ProcessTaskAISMessages()- Unloaded");
                        return;
                    }

                    if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.PolicyNumber))
                    {
                        //this.CreateAISMessageNotification(entity, null, null, null, 1, "Message processed successfully", "Message processed successfully", "Create Case for Policy");
                        //return;
                        Entity entity_P = null;
                        ColumnSet columns_P = null;
                        string policyNumber = string.Empty
                                , title = string.Empty;

                        policyNumber = enTATMaisMessage[Constants.AISMessage.PolicyNumber].ToString();

                        columns_P = new ColumnSet(Constants.Policy.EntityId, Constants.Policy.Name, Constants.Policy.QuotePolicyVersion
        , Constants.Policy.PolicyStatus, Constants.Policy.PolicyKey, Constants.Policy.Broker
        , Constants.Policy.Customer, Constants.Policy.ModifiedOn, Constants.Policy.Owner, Constants.Policy.PolicySystem
        , Constants.Policy.ProductCode, Constants.Policy.ProductName, Constants.Policy.QuotePolicyStatus, Constants.Policy.QuotePolicyVersion);

                        entity_P = this.GetPolicy(policyNumber, columns_P);
                        tracingService.Trace("Entity Policy");
                        pluginContext.LogMessage($"entity_P: '{entity_P}'");
                        tracingService.Trace("Entity Policy Fetched");
                        if (entity_P != null && entity_P.Id != Guid.Empty)
                        {
                            Entity enCaseCreate = new Entity(Constants.Case.EntityName);
                            enCaseCreate[Constants.Case.PolicyId] = new EntityReference(Constants.Policy.EntityName, entity_P.Id);

                            pluginContext.LogMessage($"Entity: '{Constants.Case.EntityName}'");

                            erBroker = null;

                            if (entity_P.Attributes.Contains(Constants.Policy.Broker))
                            {
                                erBroker = entity_P.GetAttributeValue<EntityReference>(Constants.Policy.Broker);
                                bDoesBrokerExist = true;
                                pluginContext.LogMessage($"Fetched Broker 1: '{erBroker}' ");
                            }
                            else if (erBroker == null && enTATMaisMessage.Attributes.Contains(Constants.AISMessage.Broker))
                            {
                                erBroker = enTATMaisMessage.GetAttributeValue<EntityReference>(Constants.AISMessage.Broker);
                                bDoesBrokerExist = true;
                                pluginContext.LogMessage($"Fetched Broker 2: '{erBroker}' ");
                            }
                            else
                            {
                                //Do nothing
                                pluginContext.LogMessage($"No Broker");

                            }


                            if (erBroker != null)
                                enCaseCreate[Constants.Case.Broker] = enCaseCreate[Constants.Case.CustomerId] = erBroker;
                            else
                            {
                                this.UpdateAISMessageStatus(enTATMaisMessage.Id, (int)Constants.AISMessage.AISMessage_Status.ProcessedwithError, Constants.AISMessage.BrokerDoesNotExist);
                                this.CreateAISMessageNotification(enTATMaisMessage, entity_P, null, null, 0, Constants.AISMessage.BrokerDoesNotExist, Constants.AISMessage.BrokerDoesNotExist, "Create Case for Policy");
                                pluginContext.LogMessage($"AIS Message: '{enTATMaisMessage.Id.ToString()}' doesn't have Broker to be processed.");

                            }

                            erCustomer = null;
                            if (entity_P.Attributes.Contains(Constants.Policy.Customer))
                                erCustomer = entity_P.GetAttributeValue<EntityReference>(Constants.Policy.Customer);
                            else if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.Customer))
                                erCustomer = enTATMaisMessage.GetAttributeValue<EntityReference>(Constants.AISMessage.Customer);

                            if (erCustomer != null)
                                enCaseCreate[Constants.Case.Customer] = erCustomer;

                            //if (aisMessage.Attributes.Contains(Constants.AISMessage.Title))
                            //    title = aisMessage[Constants.AISMessage.Title].ToString();

                            //if (string.IsNullOrEmpty(title) && entity_P.Attributes.Contains(Constants.Policy.Name))
                            //    title = entity_P[Constants.Policy.Name].ToString();

                            if (!string.IsNullOrEmpty(title))
                            {
                                //enCaseCreate[Constants.Case.Title] = title;
                                enCaseCreate[Constants.Case.Subject] = title;
                            }

                            if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.Description))
                                enCaseCreate[Constants.Case.Description] = enTATMaisMessage[Constants.AISMessage.Description];

                            if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.DueDate))
                                enCaseCreate[Constants.Case.AISTaskDueDate] = enTATMaisMessage[Constants.AISMessage.DueDate];

                            if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.CustomerPhysicalAddress))
                                enCaseCreate[Constants.Case.CustomerPhysicalAddress] = enTATMaisMessage[Constants.AISMessage.CustomerPhysicalAddress];

                            if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.CustomerPostCode))
                                enCaseCreate[Constants.Case.CustomerPostCode] = enTATMaisMessage[Constants.AISMessage.CustomerPostCode];

                            if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.CustomerPhoneNumber1))
                                enCaseCreate[Constants.Case.CustomerPhoneNumber1] = enTATMaisMessage[Constants.AISMessage.CustomerPhoneNumber1];

                            if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.CustomerEmailAddress1))
                                enCaseCreate[Constants.Case.CustomerEmailAddress1] = enTATMaisMessage[Constants.AISMessage.CustomerEmailAddress1];

                            if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.RouteOfSale))
                                enCaseCreate[Constants.Case.RouteOfSale] = enTATMaisMessage.FormattedValues[Constants.AISMessage.RouteOfSale];
                            //Bug 1855
                            //Modified By: Nida
                            //Modified On:24 Jan,2022

                            if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.PrimaryReference))
                                enCaseCreate[Constants.Case.AISPrimaryReference] = enTATMaisMessage[Constants.AISMessage.PrimaryReference];

                            //Setting case type as SME Renewal Review
                            enCaseCreate[Constants.Case.CaseType] = new EntityReference("rsa_casetype", new Guid("8caa1262-f6e2-ea11-a818-000d3a649f51"));
                            tracingService.Trace("Case Type" + enCaseCreate[Constants.Case.CaseType]);

                            //Setting status as New
                            enCaseCreate[Constants.Case.Status] = new EntityReference("rsa_status", new Guid("8e97b842-f7e2-ea11-a816-000d3a64927d"));
                            tracingService.Trace("Status" + enCaseCreate[Constants.Case.Status]);

                            //Setting Origin as AIS
                            enCaseCreate[Constants.Case.CaseOrigin] = new OptionSetValue((int)Constants.Case.Case_Origin.AIS);
                            tracingService.Trace("Case Origin " + enCaseCreate[Constants.Case.CaseOrigin]);

                            //Setting Owner Name as Unassigned
                            tracingService.Trace("Calling getuser function");
                            Entity enUser = getUser("Unassigned", service);
                            tracingService.Trace("Record reterieved " + enUser);
                            Guid userid = enUser.Id;
                            EntityReference unassigneduser = new EntityReference("systemuser", enUser.Id);
                            if (userid != Guid.Empty)
                            {
                                enCaseCreate[Constants.Case.OwnerName] = new EntityReference("systemuser", userid);
                                tracingService.Trace("Owner Name " + enCaseCreate[Constants.Case.OwnerName]);
                            }


                            //if (bDoesBrokerExist)
                            //{
                            //    Guid brokerId = enCaseCreate.GetAttributeValue<EntityReference>(Constants.Case.Broker).Id;
                            //    Entity enBroker = service.Retrieve(Constants.Broker.EntityName, brokerId, new ColumnSet(Constants.Broker.EntityId, Constants.Broker.PrimaryContactId));
                            //    if (enBroker != null && enBroker.Attributes.Contains(Constants.Broker.PrimaryContactId))
                            //        enCaseCreate[Constants.Case.PrimaryContactId] = enBroker[Constants.Broker.PrimaryContactId];
                            //}

                            Guid guid = service.Create(enCaseCreate);
                            pluginContext.LogMessage($"Case Created: '{title}'");
                            this.UpdateAISMessageStatus(enTATMaisMessage.Id, (int)Constants.AISMessage.AISMessage_Status.Processed);
                            this.CreateAISMessageNotification(enTATMaisMessage, entity_P, null, new EntityReference(Constants.Case.EntityName, guid), 1, "Message processed successfully", "Message processed successfully", "Create Case for Policy");

                        }
                        else
                        {
                            tracingService.Trace("Entity not Fetched");
                            this.UpdateAISMessageStatus(enTATMaisMessage.Id, (int)Constants.AISMessage.AISMessage_Status.Waiting, Constants.AISMessage.PolicyDoesNotExist);
                            this.CreateAISMessageNotification(enTATMaisMessage, null, null, null, 0, Constants.AISMessage.PolicyDoesNotExist, Constants.AISMessage.PolicyDoesNotExist, "Create Case for Policy");

                        }


                    }
                    else if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.QuoteNumber))
                    {
                        //this.CreateAISMessageNotification(entity, null, null, null, 1, "Message processed successfully", "Message processed successfully", "Create Case for Quote");
                        //return;
                        FilterExpression filterExpression_Q = null;
                        OrderExpression orderExpression_Q = null;
                        EntityCollection entityCollection_Q = null;
                        Entity entity_Q = null;
                        ColumnSet columns_Q = null;
                        string quoteNumber = string.Empty;

                        quoteNumber = enTATMaisMessage[Constants.AISMessage.QuoteNumber].ToString();
                        pluginContext.LogMessage($"Quote Number : '{quoteNumber}'");
                        columns_Q = new ColumnSet(Constants.Quote.AgentCode, Constants.Quote.AgentName, Constants.Quote.AnnualPremiumincludingTaxes
                                                    , Constants.Quote.AnnualRevisedPremium, Constants.Quote.Brokerid, Constants.Quote.ClassOfBusiness, Constants.Quote.CodetorelateQuotesPolicies
                                                    , Constants.Quote.Customer, Constants.Quote.IsDeleted, Constants.Quote.EffectiveDate, Constants.Quote.InceptionDate
                                                    , Constants.Quote.Owner, Constants.Quote.PL, Constants.Quote.PolicyMovementReasonId, Constants.Quote.PolicyMovementType
                                                    , Constants.Quote.PolicyRenewalDate, Constants.Quote.Premium, Constants.Quote.PrimaryReference, Constants.Quote.ProductId
                                                    , Constants.Quote.ProductName, Constants.Quote.QuoteExpirationDate, Constants.Quote.Name
                                                    , Constants.Quote.QuotePolicyVersion, Constants.Quote.ReasonforDivertDecline, Constants.Quote.RenewalIndicator, Constants.Quote.RevisedPremium
                                                    , Constants.Quote.RouteOfsale, Constants.Quote.ReletedPolicy, Constants.Quote.SchemeDescription, Constants.Quote.SystemModStamp, Constants.Quote.TransactionalPremiumincludingtaxes
                                                    , Constants.Quote.TransactionalRevisedPremium);
                        filterExpression_Q = new FilterExpression
                        {
                            FilterOperator = LogicalOperator.And,
                            Conditions = { new ConditionExpression(Constants.Quote.Name, ConditionOperator.Equal, quoteNumber) }
                        };
                        columns_Q = new ColumnSet(Constants.Quote.EntityId, Constants.Quote.Name, Constants.Quote.ReletedPolicy);

                        pluginContext.LogMessage($"entityCollection_Q: '{entityCollection_Q}'");

                        orderExpression_Q = new OrderExpression(Constants.Quote.ModifiedOn, OrderType.Descending);

                        entityCollection_Q = this.GetEntityCollection(Constants.Quote.EntityName, filterExpression_Q, orderExpression_Q, columns_Q, 1);

                        if (entityCollection_Q != null && entityCollection_Q.Entities.Count != 0)
                            entity_Q = entityCollection_Q[0];

                        pluginContext.LogMessage($"entity_Q: '{entity_Q}'");

                        if (entity_Q != null && entity_Q.Id != Guid.Empty)
                        {
                            string title = string.Empty;

                            Entity enCaseCreate = new Entity(Constants.Case.EntityName);

                            enCaseCreate[Constants.Case.QuoteId] = new EntityReference(entity_Q.LogicalName, entity_Q.Id);
                            tracingService.Trace("Description:2650");
                            //Description:2650 Update policy from  quote here; modified By: Nida; Modified on: 27th May 2022.
                            if (entity_Q.Attributes.Contains(Constants.Quote.ReletedPolicy))
                            {
                                erPolicy = entity_Q.GetAttributeValue<EntityReference>(Constants.Quote.ReletedPolicy);
                                tracingService.Trace("erPolicy", erPolicy.LogicalName);
                                tracingService.Trace("erPolicy", erPolicy.Name);
                                enCaseCreate[Constants.Case.PolicyId] = new EntityReference(Constants.Policy.EntityName, erPolicy.Id);
                            }
                            erBroker = null;
                            if (entity_Q.Attributes.Contains(Constants.Quote.Broker))
                            {
                                erBroker = entity_Q.GetAttributeValue<EntityReference>(Constants.Quote.Broker);
                                bDoesBrokerExist = true;
                                pluginContext.LogMessage($"Fetched Broker 1: '{erBroker}' ");
                            }


                            else if (erBroker == null && enTATMaisMessage.Attributes.Contains(Constants.AISMessage.Broker))
                            {
                                erBroker = enTATMaisMessage.GetAttributeValue<EntityReference>(Constants.AISMessage.Broker);
                                bDoesBrokerExist = true;
                                pluginContext.LogMessage($"Fetched Broker 2: '{erBroker}' ");
                            }
                            else
                            {
                                pluginContext.LogMessage($"No Broker");
                                //Do Nothing
                            }


                            if (erBroker != null)
                                enCaseCreate[Constants.Case.Broker] = enCaseCreate[Constants.Case.CustomerId] = erBroker;

                            else
                            {
                                this.UpdateAISMessageStatus(enTATMaisMessage.Id, (int)Constants.AISMessage.AISMessage_Status.ProcessedwithError, Constants.AISMessage.BrokerDoesNotExist);
                                this.CreateAISMessageNotification(enTATMaisMessage, null, entity_Q, null, 0, Constants.AISMessage.BrokerDoesNotExist, Constants.AISMessage.BrokerDoesNotExist, "Create Case for Quote");
                                pluginContext.LogMessage($"AIS Message: '{enTATMaisMessage.Id.ToString()}' doesn't have Broker to be processed.");

                            }

                            erCustomer = null;
                            if (entity_Q.Attributes.Contains(Constants.Quote.Customer))
                                erCustomer = entity_Q.GetAttributeValue<EntityReference>(Constants.Quote.Customer);

                            else if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.Customer))
                                erCustomer = enTATMaisMessage.GetAttributeValue<EntityReference>(Constants.AISMessage.Customer);

                            if (erCustomer != null)
                                enCaseCreate[Constants.Case.Customer] = erCustomer;

                            pluginContext.LogMessage($"Fetched Customer: '{erCustomer}' ");

                            //if (aisMessage.Attributes.Contains(Constants.AISMessage.Title))
                            //    title = aisMessage[Constants.AISMessage.Title].ToString();

                            //if (string.IsNullOrEmpty(title) && entity_Q.Attributes.Contains(Constants.Quote.Name))
                            //    title = entity_Q[Constants.Quote.Name].ToString();

                            if (!string.IsNullOrEmpty(title))
                            {
                                // enCaseCreate[Constants.Case.Title] = title;
                                enCaseCreate[Constants.Case.Subject] = title;
                            }

                            if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.Description))
                                enCaseCreate[Constants.Case.Description] = enTATMaisMessage[Constants.AISMessage.Description];

                            if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.DueDate))
                                enCaseCreate[Constants.Case.AISTaskDueDate] = enTATMaisMessage[Constants.AISMessage.DueDate];

                            if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.CustomerPhysicalAddress))
                                enCaseCreate[Constants.Case.CustomerPhysicalAddress] = enTATMaisMessage[Constants.AISMessage.CustomerPhysicalAddress];

                            if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.CustomerPostCode))
                                enCaseCreate[Constants.Case.CustomerPostCode] = enTATMaisMessage[Constants.AISMessage.CustomerPostCode];

                            if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.CustomerPhoneNumber1))
                                enCaseCreate[Constants.Case.CustomerPhoneNumber1] = enTATMaisMessage[Constants.AISMessage.CustomerPhoneNumber1];

                            if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.CustomerEmailAddress1))
                                enCaseCreate[Constants.Case.CustomerEmailAddress1] = enTATMaisMessage[Constants.AISMessage.CustomerEmailAddress1];

                            if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.RouteOfSale))
                                enCaseCreate[Constants.Case.RouteOfSale] = enTATMaisMessage.FormattedValues[Constants.AISMessage.RouteOfSale];

                            //Bug 1855
                            //Modified By: Nida
                            //Modified On:24 Jan,2022

                            if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.PrimaryReference))
                                enCaseCreate[Constants.Case.AISPrimaryReference] = enTATMaisMessage[Constants.AISMessage.PrimaryReference];

                            //Setting case type as SME Renewal Review
                            enCaseCreate[Constants.Case.CaseType] = new EntityReference("rsa_casetype", new Guid("8caa1262-f6e2-ea11-a818-000d3a649f51"));
                            tracingService.Trace("Case Type" + enCaseCreate[Constants.Case.CaseType]);

                            //Setting status as New
                            enCaseCreate[Constants.Case.Status] = new EntityReference("rsa_status", new Guid("8e97b842-f7e2-ea11-a816-000d3a64927d"));
                            tracingService.Trace("Status" + enCaseCreate[Constants.Case.Status]);


                            //Setting Origin as AIS
                            enCaseCreate[Constants.Case.CaseOrigin] = new OptionSetValue((int)Constants.Case.Case_Origin.AIS);
                            tracingService.Trace("Case Origin " + enCaseCreate[Constants.Case.CaseOrigin]);

                            //Setting Owner Name as Unassigned
                            tracingService.Trace("Calling getuser function");
                            Entity enUser = getUser("Unassigned", service);
                            tracingService.Trace("Record reterieved " + enUser);
                            Guid userid = enUser.Id;
                            EntityReference unassigneduser = new EntityReference("systemuser", enUser.Id);
                            if (userid != Guid.Empty)
                            {
                                enCaseCreate[Constants.Case.OwnerName] = new EntityReference("systemuser", userid);
                                tracingService.Trace("Owner Name " + enCaseCreate[Constants.Case.OwnerName]);
                            }


                            //if (bDoesBrokerExist)
                            //{
                            //    Guid brokerId = enCaseCreate.GetAttributeValue<EntityReference>(Constants.Case.Broker).Id;
                            //    Entity enBroker = service.Retrieve(Constants.Broker.EntityName, brokerId, new ColumnSet(Constants.Broker.EntityId, Constants.Broker.PrimaryContactId));
                            //    if (enBroker != null && enBroker.Attributes.Contains(Constants.Broker.PrimaryContactId))
                            //        enCaseCreate[Constants.Case.PrimaryContactId] = enBroker[Constants.Broker.PrimaryContactId];
                            //}

                            Guid guid = service.Create(enCaseCreate);

                            #region addtoqueue for Task Type of AIS message
                            tracingService.Trace("Routing Case to SME - BPO");
                            erProduct = null;//error
                            if (entity_Q.Attributes.Contains(Constants.Quote.ReletedPolicy))
                            {

                                tracingService.Trace("ReletedPolicy ==", Constants.Quote.ReletedPolicy);
                                this.AssignCaseToDefaultQueue(tracingService, service, enCaseCreate.LogicalName, guid, new Guid(Constants.Case.SMEBPO));
                                tracingService.Trace("Case has assigned to SME - BPO ");

                            }
                            #endregion addtoqueue

                            this.UpdateAISMessageStatus(enTATMaisMessage.Id, (int)Constants.AISMessage.AISMessage_Status.Processed);
                            this.CreateAISMessageNotification(enTATMaisMessage, null, entity_Q, new EntityReference(Constants.Case.EntityName, guid), 1, "Message processed successfully", "Message processed successfully", "Create Case for Quote");

                        }
                        else
                        {
                            this.UpdateAISMessageStatus(enTATMaisMessage.Id, (int)Constants.AISMessage.AISMessage_Status.Waiting, Constants.AISMessage.QuoteDoesNotExist);
                            this.CreateAISMessageNotification(enTATMaisMessage, null, null, null, 0, Constants.AISMessage.QuoteDoesNotExist, Constants.AISMessage.QuoteDoesNotExist, "Create Case for Quote");

                        }
                    }



                }
            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                pluginContext.ThrowException("Fault Exception Occured", ex);
            }
            catch (Exception ex) { exception = ex; }
            finally
            {
                if (exception != null)
                {
                    pluginContext.LogException(exception, "AISMessageLogic.ProcessTaskAISMessages");
                    //throw new InvalidPluginExecutionException(exception.Message);
                }
            }
            pluginContext.LogMessage("AISMessageLogic.ProcessTaskAISMessages()- Unloaded");
        }

        /// <summary>
        /// Defect 2552 -Create case if message type is quote and Primary refference has data
        /// Modified On -27/1/2022
        /// Modified By -Nida
        ///  /// Modified by Sumegh :TFs-258 : 11 Aug 2022 :  Code commented for CR requirement to be reversed and case creation to stop as per business requirement
        //public void QuoteAISMessagesAction()
        //{
        //    pluginContext.LogMessage("AISMessageLogic.QuoteAISMessagesAction()- inside block Loaded");
        //    Exception exception = null;
        //    string sPolicyNumber = string.Empty
        //            , sQuoteNumber = string.Empty;
        //    try
        //    {
        //        pluginContext.LogMessage($"entity.Id - Outside If: {entity.Id}");
        //        Entity enTATMaisMessage = service.Retrieve(Constants.AISMessage.EntityName, entity.Id, new ColumnSet(true));

        //        if (enTATMaisMessage != null && enTATMaisMessage.GetAttributeValue<OptionSetValue>(Constants.AISMessage.MessageStatus).Value.Equals((int)Constants.AISMessage.AISMessage_Status.Waiting)) //if (entityCollection != null && entityCollection.Entities.Count > 0)
        //        {
        //            pluginContext.LogMessage($"enTATMaisMessage.Id : {enTATMaisMessage.Id}");
        //            if (!enTATMaisMessage.Attributes.ContainsKey(Constants.AISMessage.PrimaryReference) && !enTATMaisMessage.Attributes.ContainsKey(Constants.AISMessage.QuoteNumber))
        //            {
        //                pluginContext.LogMessage($"PrimaryReference : '{enTATMaisMessage.Attributes.Contains(Constants.AISMessage.PrimaryReference)}' ");
        //                pluginContext.LogMessage($"Quote Number: '{enTATMaisMessage.Attributes.Contains(Constants.AISMessage.QuoteNumber)}' ");

        //                this.UpdateAISMessageStatus((int)Constants.AISMessage.AISMessage_Status.Waiting, Constants.AISMessage.QuoteNumberPrimaryRefferenceDoesNotExist);
        //                this.CreateAISMessageNotification(enTATMaisMessage, null, null, null, 0, Constants.AISMessage.QuoteNumberPrimaryRefferenceDoesNotExist, Constants.AISMessage.QuoteNumberPrimaryRefferenceDoesNotExist, "Create AIS Message (Task)");
        //                pluginContext.LogMessage(Constants.AISMessage.QuoteNumberPrimaryRefferenceDoesNotExist);
        //                pluginContext.LogMessage("AISMessageLogic.QuoteAISMessagesAction()- Unloaded 722");
        //                return;
        //            }

        //            if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.QuoteNumber) && enTATMaisMessage.Attributes.Contains(Constants.AISMessage.PrimaryReference))
        //            {
        //                FilterExpression filterExpression_Q = null;
        //                OrderExpression orderExpression_Q = null;
        //                EntityCollection entityCollection_Q = null;
        //                Entity entity_Q = null;
        //                ColumnSet columns_Q = null;
        //                string quoteNumber = string.Empty;

        //                quoteNumber = enTATMaisMessage[Constants.AISMessage.QuoteNumber].ToString();
        //                pluginContext.LogMessage($"Quote Number : '{quoteNumber}'");
        //                columns_Q = new ColumnSet(Constants.Quote.AgentCode, Constants.Quote.AgentName, Constants.Quote.AnnualPremiumincludingTaxes
        //                                            , Constants.Quote.AnnualRevisedPremium, Constants.Quote.Brokerid, Constants.Quote.ClassOfBusiness, Constants.Quote.CodetorelateQuotesPolicies
        //                                            , Constants.Quote.Customer, Constants.Quote.IsDeleted, Constants.Quote.EffectiveDate, Constants.Quote.InceptionDate
        //                                            , Constants.Quote.Owner, Constants.Quote.PL, Constants.Quote.PolicyMovementReasonId, Constants.Quote.PolicyMovementType
        //                                            , Constants.Quote.PolicyRenewalDate, Constants.Quote.Premium, Constants.Quote.PrimaryReference, Constants.Quote.ProductId
        //                                            , Constants.Quote.ProductName, Constants.Quote.QuoteExpirationDate, Constants.Quote.Name
        //                                            , Constants.Quote.QuotePolicyVersion, Constants.Quote.ReasonforDivertDecline, Constants.Quote.RenewalIndicator, Constants.Quote.RevisedPremium
        //                                            , Constants.Quote.RouteOfsale, Constants.Quote.SchemeDescription, Constants.Quote.SystemModStamp, Constants.Quote.TransactionalPremiumincludingtaxes
        //                                            , Constants.Quote.TransactionalRevisedPremium);
        //                filterExpression_Q = new FilterExpression
        //                {
        //                    FilterOperator = LogicalOperator.And,
        //                    Conditions = { new ConditionExpression(Constants.Quote.Name, ConditionOperator.Equal, quoteNumber) }
        //                };
        //                columns_Q = new ColumnSet(Constants.Quote.EntityId, Constants.Quote.Name,Constants.Quote.ProductName);

        //                pluginContext.LogMessage($"entityCollection_Q: '{entityCollection_Q}'");

        //                orderExpression_Q = new OrderExpression(Constants.Quote.ModifiedOn, OrderType.Descending);

        //                entityCollection_Q = this.GetEntityCollection(Constants.Quote.EntityName, filterExpression_Q, orderExpression_Q, columns_Q, 1);

        //                if (entityCollection_Q != null && entityCollection_Q.Entities.Count != 0)
        //                    entity_Q = entityCollection_Q[0];

        //                pluginContext.LogMessage($"entity_Q: '{entity_Q}'");

        //                if (entity_Q != null && entity_Q.Id != Guid.Empty)
        //                {
        //                    string title = string.Empty;

        //                    Entity enCaseCreate = new Entity(Constants.Case.EntityName);

        //                    enCaseCreate[Constants.Case.QuoteId] = new EntityReference(entity_Q.LogicalName, entity_Q.Id);

        //                    #region retrive broker
        //                    erBroker = null;
        //                    if (entity_Q.Attributes.Contains(Constants.Quote.Broker))
        //                    {
        //                        erBroker = entity_Q.GetAttributeValue<EntityReference>(Constants.Quote.Broker);
        //                        pluginContext.LogMessage($"Fetched Broker 1: '{erBroker}' ");
        //                    }
        //                    else if (erBroker == null && enTATMaisMessage.Attributes.Contains(Constants.AISMessage.Broker))
        //                    {
        //                        erBroker = enTATMaisMessage.GetAttributeValue<EntityReference>(Constants.AISMessage.Broker);
        //                        pluginContext.LogMessage($"Fetched Broker 2: '{erBroker}' ");
        //                    }
        //                    else
        //                    {
        //                        pluginContext.LogMessage($"No Broker");
        //                        //Do Nothing
        //                    }

        //                    #endregion

        //                    if (erBroker != null)
        //                        enCaseCreate[Constants.Case.Broker] = enCaseCreate[Constants.Case.CustomerId] = erBroker;

        //                    else
        //                    {
        //                        this.UpdateAISMessageStatus(enTATMaisMessage.Id, (int)Constants.AISMessage.AISMessage_Status.ProcessedwithError, Constants.AISMessage.BrokerDoesNotExist);
        //                        this.CreateAISMessageNotification(enTATMaisMessage, null, entity_Q, null, 0, Constants.AISMessage.BrokerDoesNotExist, Constants.AISMessage.BrokerDoesNotExist, "Create Case for Quote");
        //                        pluginContext.LogMessage($"AIS Message: '{enTATMaisMessage.Id.ToString()}' doesn't have Broker to be processed.");

        //                    }

        //                    erCustomer = null;
        //                    if (entity_Q.Attributes.Contains(Constants.Quote.Customer))
        //                        erCustomer = entity_Q.GetAttributeValue<EntityReference>(Constants.Quote.Customer);

        //                    else if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.Customer))
        //                        erCustomer = enTATMaisMessage.GetAttributeValue<EntityReference>(Constants.AISMessage.Customer);

        //                    if (erCustomer != null)
        //                        enCaseCreate[Constants.Case.Customer] = erCustomer;

        //                    pluginContext.LogMessage($"Fetched Customer: '{erCustomer}' ");

        //                    if (!string.IsNullOrEmpty(title))
        //                    {
        //                        enCaseCreate[Constants.Case.Subject] = title;
        //                    }


        //                    if (enTATMaisMessage.Attributes.Contains(Constants.AISMessage.PrimaryReference))
        //                        enCaseCreate[Constants.Case.AISPrimaryReference] = enTATMaisMessage[Constants.AISMessage.PrimaryReference];

        //                    //Setting case type as SME imarket Reffereal
        //                    enCaseCreate[Constants.Case.CaseType] = new EntityReference("rsa_casetype", new Guid("7eaa1262-f6e2-ea11-a818-000d3a649f51"));
        //                    tracingService.Trace("Case Type" + enCaseCreate[Constants.Case.CaseType]);

        //                    //Setting status as New
        //                    enCaseCreate[Constants.Case.Status] = new EntityReference("rsa_status", new Guid("8e97b842-f7e2-ea11-a816-000d3a64927d"));
        //                    tracingService.Trace("Status" + enCaseCreate[Constants.Case.Status]);


        //                    //Setting Origin as AIS
        //                    enCaseCreate[Constants.Case.CaseOrigin] = new OptionSetValue((int)Constants.Case.Case_Origin.AIS);
        //                    tracingService.Trace("Case Origin " + enCaseCreate[Constants.Case.CaseOrigin]);

        //                    //Setting Owner Name as Unassigned
        //                    tracingService.Trace("Calling getuser function");
        //                    Entity enUser = getUser("Unassigned", service);
        //                    tracingService.Trace("Record reterieved " + enUser);
        //                    Guid userid = enUser.Id;
        //                    EntityReference unassigneduser = new EntityReference("systemuser", enUser.Id);
        //                    if (userid != Guid.Empty)
        //                    {
        //                        enCaseCreate[Constants.Case.OwnerName] = new EntityReference("systemuser", userid);
        //                        tracingService.Trace("Owner Name " + enCaseCreate[Constants.Case.OwnerName]);
        //                    }
        //                    Guid guid = service.Create(enCaseCreate);                        
        //                    #region addtoqueue based on Product Value
        //                    tracingService.Trace("Constants.Case.Product has value");
        //                         erProduct = null;//error
        //                    if (entity_Q.Attributes.Contains(Constants.Quote.ProductName))
        //                    {

        //                        //erProduct = entity_Q.GetAttributeValue<EntityReference>(Constants.Quote.ProductId);
        //                        string sProductName = entity_Q.GetAttributeValue<String>(Constants.Quote.ProductName);
        //                        //tracingService.Trace("product", erProduct);
        //                        tracingService.Trace("product name", sProductName);

        //                        if (sProductName != null)
        //                        {
        //                            tracingService.Trace("Case - Quote has rsa_Productname");

        //                            if (sProductName == Constants.Case.ProductSMEMiniFleet)
        //                            {
        //                                tracingService.Trace("Product name ==", Constants.Case.ProductSMEMiniFleet);
        //                                this.AssignCaseToDefaultQueue(tracingService, service, enCaseCreate.LogicalName, guid, new Guid(Constants.Case.SMEiMarketMotor));
        //                                tracingService.Trace("Case has assigned to SMEiMarketMotor ");
        //                            }
        //                            else
        //                            {
        //                                tracingService.Trace("Product ==", Constants.Case.ProductSMEMiniFleet);

        //                                this.AssignCaseToDefaultQueue(tracingService, service, enCaseCreate.LogicalName, guid, new Guid(Constants.Case.SMEiMarketNonMotor));
        //                                tracingService.Trace("Case has assigned to SMEinonMarketMotor");

        //                            }
        //                        }
        //                    }
        //                    #endregion addtoqueue

        //                    this.UpdateAISMessageStatus(enTATMaisMessage.Id, (int)Constants.AISMessage.AISMessage_Status.Processed);
        //                    this.CreateAISMessageNotification(enTATMaisMessage, null, entity_Q, new EntityReference(Constants.Case.EntityName, guid), 1, "Message processed successfully", "Message processed successfully", "Create Case for Quote");
        //                    ///create Task for AIS Quote
        //                    ///This activity handled in ABRLogic.cs line 270
        //                    //this.SetQuoteTaskFields(service, tracingService, "Renewal Work Up", guid, enUser.Id, "Not Started");
        //                }
        //                else
        //                {
        //                    this.UpdateAISMessageStatus(enTATMaisMessage.Id, (int)Constants.AISMessage.AISMessage_Status.Waiting, Constants.AISMessage.QuoteDoesNotExist);
        //                    this.CreateAISMessageNotification(enTATMaisMessage, null, null, null, 0, Constants.AISMessage.QuoteDoesNotExist, Constants.AISMessage.QuoteDoesNotExist, "Create Case for Quote");

        //                }

        //            }
        //        }
        //    }

        //    catch (FaultException<OrganizationServiceFault> ex)
        //    {
        //        pluginContext.ThrowException("Fault Exception Occured", ex);
        //    }
        //    catch (Exception ex) { exception = ex; }
        //    finally
        //    {
        //        if (exception != null)
        //        {
        //            pluginContext.LogException(exception, "AISMessageLogic.QuoteAISMessagesAction");
        //        }
        //    }
        //    pluginContext.LogMessage("AISMessageLogic.QuoteAISMessagesAction()- inside block Unloaded");
        //}
        /////
        /// </summary>

        /// <param name="name"></param>
        /// <param name="service"></param>
        /// <returns></returns>
        private Entity getUser(string name, IOrganizationService service)
        {
            try
            {
                var recordName = new Entity();
                QueryExpression query = new QueryExpression("systemuser");
                query.ColumnSet = new ColumnSet(new string[] { "firstname" });

                query.Criteria.AddCondition("firstname", ConditionOperator.Equal, name);
                query.NoLock = true;
                EntityCollection businessRecordTypes = service.RetrieveMultiple(query);
                if (businessRecordTypes != null && businessRecordTypes.Entities.Count > 0)
                {
                    recordName = businessRecordTypes.Entities[0];
                }
                return recordName;
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        #endregion Public Subs / Functions

        #region Private Subs / Functions
        /// <summary>
        /// If Message Type or Customer (Business) Name are blank on AIS Message new record, then the record creation would get failed.
        /// </summary>
        private void ValidateAISMessagePreCreate()
        {
            pluginContext.LogMessage("AISMessageLogic.ValidateAISMessagePreCreate- Loaded");
            Exception exception = null;
            try
            {
                bool doesMessageTypeExist = false
                        , doesPolicyNumberExist = false
                        , doesQuoteNumberExist = false
                        , bFoundMatchingBroker = false
                        , isBrokerCreated = false
                        , bFoundMatchingCustomer = false
                        , isCustomerCreated = false;

                string sMessageTypeName = string.Empty
                        , sPolicyNumber = string.Empty
                        , sQuoteNumber = string.Empty
                        , sErrDisplayMessage = string.Empty
                        , sPostalCode = string.Empty
                        , sCustomerName = string.Empty
                        , sPrimaryReference = string.Empty;

                if (entity.Attributes.Contains(Constants.AISMessage.AgentCode))
                {
                    var priamryReference = Convert.ToString(entity.Attributes[Constants.AISMessage.AgentCode]);
                    if (!string.IsNullOrEmpty(priamryReference))
                    {
                        object[] oRSACustomeLabels = { Constants.RSACustomLabel.AIS_Dummy_Broker__PrimaryRefrence };
                        List<string> brokerPrimaryReferences = new List<string>();
                        EntityCollection ecRSACustomLabels = this.GetCustomLabel(oRSACustomeLabels);
                        if (ecRSACustomLabels != null && ecRSACustomLabels.Entities.Count > 0 && ecRSACustomLabels[0].Contains(Constants.RSACustomLabel.Values)
                                               && !string.IsNullOrEmpty(ecRSACustomLabels[0][Constants.RSACustomLabel.Values].ToString()))
                        {
                            string customValue = ecRSACustomLabels[0][Constants.RSACustomLabel.Values].ToString();
                            brokerPrimaryReferences = customValue.Split(",").ToList();
                        }
                        if (brokerPrimaryReferences.Any(p => p == priamryReference))
                        {
                            tracingService.Trace("Ignoring this record as dummy broker found");
                            return;
                        }
                    }
                }

                if (entity.Attributes.Contains(Constants.AISMessage.MessageType))
                {
                    sMessageTypeName = entity.FormattedValues[Constants.AISMessage.MessageType].Trim();
                    pluginContext.LogMessage($"sMessageTypeName: '{sMessageTypeName}' | doesMessageTypeExist = true");
                    doesMessageTypeExist = true;
                }
                if (!doesMessageTypeExist)
                {
                    sErrDisplayMessage = $"MESSAGE TYPE SHOULD BE EITHER POLICY/QUOTE/TASK.";
                    // throw new InvalidPluginExecutionException(sErrDisplayMessage);
                }
                else
                {
                    //Bug 1701
                    //Copy quote/policy status to quote/policy status1
                    int optionQuotePolicyStatus;
                    if (entity.Attributes.Contains(Constants.AISMessage.QuotePolicyStatus))
                    {
                        optionQuotePolicyStatus = Convert.ToInt32(entity[Constants.AISMessage.QuotePolicyStatus]);
                        pluginContext.LogMessage($"Option Set value : '{optionQuotePolicyStatus}'");

                        Dictionary<int, int> quotepolicystatus = new Dictionary<int, int>();
                        quotepolicystatus.Add(866760014, 866760000); // Live
                        quotepolicystatus.Add(866760005, 866760001); // Cancelled
                        quotepolicystatus.Add(866760012, 866760002); // Pending
                        quotepolicystatus.Add(866760013, 866760003); // Suspended
                        quotepolicystatus.Add(866760017, 866760004); // Complete
                        quotepolicystatus.Add(866760023, 866760005); // Converted To
                        quotepolicystatus.Add(866760018, 866760006); // Expired
                        quotepolicystatus.Add(866760021, 866760007); // No quote
                        quotepolicystatus.Add(866760022, 866760008); // Not taken up
                        quotepolicystatus.Add(866760007, 866760009); // Referred
                        quotepolicystatus.Add(866760008, 866760010); // Declined
                        quotepolicystatus.Add(866760009, 866760011); // Authorised

                        pluginContext.LogMessage("Dictionary count : " + quotepolicystatus.Count);

                        foreach (var item in quotepolicystatus)
                        {
                            if (item.Key.Equals(optionQuotePolicyStatus))
                            {
                                entity[Constants.AISMessage.QuotePolicyStatusPL] = new OptionSetValue(item.Value);
                                pluginContext.LogMessage("Set value" + item.Value);
                            }
                        }


                        //if (optionQuotePolicyStatus == 866760000 || optionQuotePolicyStatus == 866760001 || optionQuotePolicyStatus == 866760002 || optionQuotePolicyStatus == 866760003 || optionQuotePolicyStatus == 866760004 || optionQuotePolicyStatus == 866760005 || optionQuotePolicyStatus == 866760006 || optionQuotePolicyStatus == 866760007 || optionQuotePolicyStatus == 866760008 || optionQuotePolicyStatus == 866760009 || optionQuotePolicyStatus == 866760010 || optionQuotePolicyStatus == 866760011)
                        //{
                        //    entity[Constants.AISMessage.QuotePolicyStatusPL] = new OptionSetValue(optionQuotePolicyStatus);
                        //    pluginContext.LogMessage("Set value");
                        //}

                    }
                    entity[Constants.AISMessage.RetryCount] = 0.00M;

                    // Modified by: Samiksha Dhakde || Modified on: 26-12-2022 
                    // AIS Requirement: If Message type is Policy or Quote then Broker and Customer validation and creation
                    if (sMessageTypeName == "Policy" || sMessageTypeName == "Quote")
                    {
                        #region Customer PreCreate Commented
                        if (entity.Attributes.Contains(Constants.AISMessage.CustomerBusinessName))
                            sCustomerName = Convert.ToString(entity[Constants.AISMessage.CustomerBusinessName]);
                        if (string.IsNullOrEmpty(sCustomerName) && entity.Attributes.Contains(Constants.AISMessage.CustomerName))
                            sCustomerName = Convert.ToString(entity[Constants.AISMessage.CustomerName]);
                        if (!string.IsNullOrEmpty(sCustomerName))
                            sCustomerName = sCustomerName.Trim();
                        if (entity.Attributes.Contains(Constants.AISMessage.CustomerPostCode))
                            sPostalCode = entity[Constants.AISMessage.CustomerPostCode].ToString();

                        tracingService.Trace("sCustomerName : " + sCustomerName + " sPostalCode : " + sPostalCode);

                        if (string.IsNullOrEmpty(sCustomerName) || string.IsNullOrEmpty(sPostalCode))
                        {
                            sErrDisplayMessage = $"AIS MESSAGE SHOULD HAVE CUSTOMER NAME & Postal Code";
                            pluginContext.LogMessage($"sCustomerName, sPostalCode is empty");
                            //throw new InvalidPluginExecutionException(sErrDisplayMessage);

                        }
                        else
                        {
                            pluginContext.LogMessage($"sCustomerName contains data: " + sCustomerName);
                            pluginContext.LogMessage($"sPostalCode contains data: " + sPostalCode);
                            string externalid = sCustomerName + ":" + sPostalCode;
                            FilterExpression filterEx = null;
                            ColumnSet column = null;
                            OrderExpression order = null;

                            filterEx = new FilterExpression
                            {
                                FilterOperator = LogicalOperator.And,
                                //Conditions = { new ConditionExpression(Constants.Customer.Name, ConditionOperator.Like, $"%{sCustomerName}%") }
                                ////Defect : 2096
                                //Conditions = { new ConditionExpression(Constants.Customer.Name, ConditionOperator.Equal, $"{sCustomerName}") }
                                Conditions = { new ConditionExpression(Constants.Customer.ExternalId, ConditionOperator.Equal, $"{externalid}") }
                            };
                            column = new ColumnSet(Constants.Customer.EntityId, Constants.Customer.Name, Constants.Customer.ExternalId);
                            order = new OrderExpression(Constants.Customer.ModifiedOn, OrderType.Descending);
                            pluginContext.LogMessage($"Calling GetEntityCollection from Customer Method");
                            EntityCollection ecCustomerColl = this.GetEntityCollection(Constants.Customer.EntityName, filterEx, order, column, 1);
                            pluginContext.LogMessage($"ecCustomerColl:" + Convert.ToString(ecCustomerColl.Entities.Count));
                            if (ecCustomerColl != null && ecCustomerColl.Entities.Count != 0)
                            {
                                pluginContext.LogMessage($"ecCustomerColl having data");
                                eCustomer = ecCustomerColl[0];
                                pluginContext.LogMessage($"Disabled this.GetCustomer() method and used this.GetEntitiy() instead.");
                                bFoundMatchingCustomer = true;
                                pluginContext.LogMessage($"bFoundMatchingCustomer: true");
                                //Create SME Customer Staging
                                //CreateSMECustomerStaging(eCustomer,  sCustomerName, null, null);

                            }
                            else
                            {
                                // Modified by: Samiksha Dhakde || Modified on: 26-12-2022
                                // Create customer record if the external id i.e. Customer Name + Postal Code provided does not exist in dynamics.
                                pluginContext.LogMessage("Start Creating the customer record as Customer provided doesn't exist in dynamics");
                                isCustomerCreated = false;

                                eCustomer = this.CreateCustomer(out isCustomerCreated);
                                bFoundMatchingCustomer = true;
                                isCustomerCreated = true;

                            }
                        }
                        if (!bFoundMatchingCustomer)
                        {
                            pluginContext.LogMessage($"bFoundMatchingCustomer: false");
                            sErrDisplayMessage = $"CUSTOMER DOESN\'T EXIST FOR THIS AIS MESSAGE.";
                            //  throw new InvalidPluginExecutionException(sErrDisplayMessage);
                        }
                    }
                    #endregion

                    if (entity.Attributes.Contains(Constants.AISMessage.PolicyNumber) && sMessageTypeName != "Quote")
                    {
                        pluginContext.LogMessage($"Checking Policy Number");

                        if (!string.IsNullOrEmpty(Convert.ToString(entity[Constants.AISMessage.PolicyNumber])))
                        {
                            sPolicyNumber = entity[Constants.AISMessage.PolicyNumber].ToString();
                            pluginContext.LogMessage($"sPolicyNumber: '{sPolicyNumber}'");
                            doesPolicyNumberExist = true;
                        }
                    }

                    if (entity.Attributes.Contains(Constants.AISMessage.QuoteNumber) && sMessageTypeName != "Policy")
                    {
                        pluginContext.LogMessage($"Checking Quote Number");

                        if (!string.IsNullOrEmpty(Convert.ToString(entity[Constants.AISMessage.QuoteNumber])))
                        {
                            sQuoteNumber = entity[Constants.AISMessage.QuoteNumber].ToString();
                            pluginContext.LogMessage($"sQuoteNumber: '{sQuoteNumber}'");
                            doesQuoteNumberExist = true;
                        }

                    }

                    pluginContext.LogMessage($"sMessageTypeName: '{sMessageTypeName}', doesPolicyNumberExist: '{doesPolicyNumberExist}' and doesQuoteNumberExist: '{doesQuoteNumberExist}'");
                    switch (sMessageTypeName)
                    {
                        case Constants.Policy.DisplayName:
                            if (!doesPolicyNumberExist)
                            {
                                sErrDisplayMessage = $"POLICY AIS MESSAGE SHOULD HAVE A POLICY NUMBER.";
                                //        throw new InvalidPluginExecutionException(sErrDisplayMessage);
                            }
                            break;
                        case Constants.Quote.DisplayName:
                            if (!doesQuoteNumberExist)
                            {
                                sErrDisplayMessage = $"QUOTE AIS MESSAGE SHOULD HAVE A QUOTE NUMBER.";
                                //      throw new InvalidPluginExecutionException(sErrDisplayMessage);
                            }
                            break;
                        case Constants.Task.DisplayName:
                            if (!doesPolicyNumberExist && !doesQuoteNumberExist)
                            {
                                sErrDisplayMessage = $"TASK SHOULD HAVE EITHER POLICY NUMBER OR QUOTE NUMBER.";
                                //    throw new InvalidPluginExecutionException(sErrDisplayMessage);
                            }
                            break;
                    }
                }

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                pluginContext.ThrowException("Fault Exception Occured", ex);
            }
            catch (Exception ex) { exception = ex; }
            finally
            {
                if (exception != null)
                {
                    pluginContext.LogException(exception, "AISMessageLogic.ValidateAISMessagePreCreate");
                    //   throw new InvalidPluginExecutionException(exception.Message);
                }
            }

            pluginContext.LogMessage("AISMessageLogic.ValidateAISMessagePreCreate- Unloaded");
        }

        /// <summary>
        /// Transform certain fields and populate values for the same on AIS Message.
        /// </summary>
        private void ValidateAISMessagePostProcessing()
        {
            pluginContext.LogMessage("AISMessageLogic.ValidateAISMessagePostProcessing- Loaded");
            Exception exception = null;
            try
            {
                tracingService.Trace("eCustomer " + eCustomer);
                if (eCustomer != null)
                {
                    tracingService.Trace("eCustomer ValidateAISMessagePostProcessing is not null");
                    entity[Constants.AISMessage.Customer] = new EntityReference(eCustomer.LogicalName, eCustomer.Id);
                }

                if (entity.Attributes.Contains(Constants.AISMessage.AgentCode))
                {
                    Entity eAgencyCode = this.GetAgencyCode(entity[Constants.AISMessage.AgentCode].ToString());
                    tracingService.Trace("ValidateAISMessagePostProcessing Agency Code: " + eAgencyCode);
                    if (eAgencyCode != null)
                    {
                        erBroker = eAgencyCode.GetAttributeValue<EntityReference>(Constants.AgencyCode.Agency);
                        entity[Constants.AISMessage.Broker] = erBroker;
                    }
                }
                if (entity.Attributes.Contains(Constants.AISMessage.QuotePolicyStatus))
                {
                    OptionSetValue value = HelperFunctions.GetOptionSetValue(Constants.AISMessage.QuotePolicyStatusPL, entity.LogicalName, entity[Constants.AISMessage.QuotePolicyStatus].ToString(), service);
                    if (value != null)
                        entity[Constants.AISMessage.QuotePolicyStatusPL] = value;
                }
                if (entity.Attributes.Contains(Constants.AISMessage.ReasonForDivertDecline))
                {
                    OptionSetValue value = HelperFunctions.GetOptionSetValue(Constants.AISMessage.ReasonForDivertDeclinePL, entity.LogicalName, entity[Constants.AISMessage.ReasonForDivertDecline].ToString(), service);
                    if (value != null)
                        entity[Constants.AISMessage.ReasonForDivertDeclinePL] = value;
                }
                if (entity.Attributes.Contains(Constants.AISMessage.Scheme))
                {
                    OptionSetValue value = HelperFunctions.GetOptionSetValue(Constants.AISMessage.SchemePL, entity.LogicalName, entity[Constants.AISMessage.Scheme].ToString(), service);
                    if (value != null)
                        entity[Constants.AISMessage.SchemePL] = value;
                }

                string sPolicyMovementTypeName = string.Empty;
                if (entity.Attributes.Contains(Constants.AISMessage.PolicyMovementType))
                    sPolicyMovementTypeName = entity[Constants.AISMessage.PolicyMovementType].ToString();
                if (!string.IsNullOrEmpty(sPolicyMovementTypeName))
                {
                    FilterExpression filterEx = null;
                    ColumnSet column = null;
                    OrderExpression order = null;
                    Entity enPolicyMovementType = null;
                    EntityCollection ecPolicyMovementType = null;

                    filterEx = new FilterExpression
                    {
                        FilterOperator = LogicalOperator.And,
                        //Conditions = { new ConditionExpression(Constants.PolicyMovementType.Name, ConditionOperator.Like, $"%{sPolicyMovementTypeName}%"), }
                        //Defect:2096
                        Conditions = { new ConditionExpression(Constants.PolicyMovementType.Name, ConditionOperator.Equal, $"{sPolicyMovementTypeName}"), }
                    };
                    column = new ColumnSet(Constants.PolicyMovementType.EntityId, Constants.PolicyMovementType.Name, Constants.PolicyMovementType.ModifiedOn);
                    order = new OrderExpression(Constants.Customer.ModifiedOn, OrderType.Descending);
                    ecPolicyMovementType = this.GetEntityCollection(Constants.PolicyMovementType.EntityName, filterEx, order, column, 1);
                    if (ecPolicyMovementType != null && ecPolicyMovementType.Entities.Count != 0)
                    {
                        enPolicyMovementType = ecPolicyMovementType[0];
                        if (enPolicyMovementType != null && enPolicyMovementType.Id != Guid.Empty)
                            entity[Constants.AISMessage.PolicyMovementTypeLKP] = new EntityReference(enPolicyMovementType.LogicalName, enPolicyMovementType.Id);
                    }
                }
                string sProductNameValue = string.Empty;
                if (entity.Attributes.Contains(Constants.AISMessage.ProductCode))
                    sProductNameValue = entity[Constants.AISMessage.ProductCode].ToString();
                if (string.IsNullOrEmpty(sProductNameValue) && entity.Attributes.Contains(Constants.AISMessage.ProductName))
                    sProductNameValue = entity[Constants.AISMessage.ProductName].ToString();
                if (!string.IsNullOrEmpty(sProductNameValue))
                {
                    FilterExpression filterEx = null;
                    ColumnSet column = null;
                    OrderExpression order = null;
                    Entity enRSAProduct = null;
                    EntityCollection enRSAProductColl = null;

                    filterEx = new FilterExpression
                    {
                        FilterOperator = LogicalOperator.And,
                        //Conditions = { new ConditionExpression(Constants.RSAProduct.Name, ConditionOperator.Like, $"%{sProductNameValue}%"), }
                        //Defect: 2096
                        Conditions = { new ConditionExpression(Constants.RSAProduct.Name, ConditionOperator.Equal, $"{sProductNameValue}"), }
                    };
                    column = new ColumnSet(Constants.RSAProduct.EntityId, Constants.RSAProduct.Name, Constants.RSAProduct.PAndLId, Constants.RSAProduct.ClassOfBusinessId, Constants.RSAProduct.ModifiedOn);
                    order = new OrderExpression(Constants.RSAProduct.ModifiedOn, OrderType.Descending);
                    enRSAProductColl = this.GetEntityCollection(Constants.RSAProduct.EntityName, filterEx, order, column, 1);
                    if (enRSAProductColl != null && enRSAProductColl.Entities.Count != 0)
                    {
                        enRSAProduct = enRSAProductColl[0];
                        if (enRSAProduct != null && enRSAProduct.Id != Guid.Empty)
                        {
                            entity[Constants.AISMessage.ProductId] = new EntityReference(enRSAProduct.LogicalName, enRSAProduct.Id);
                            if (enRSAProduct.Attributes.Contains(Constants.RSAProduct.PAndLId))
                                entity[Constants.AISMessage.PLCode] = enRSAProduct.GetAttributeValue<EntityReference>(Constants.RSAProduct.PAndLId);
                            if (enRSAProduct.Attributes.Contains(Constants.RSAProduct.ClassOfBusinessId))
                                entity[Constants.AISMessage.ClassOfBusiness] = enRSAProduct.GetAttributeValue<EntityReference>(Constants.RSAProduct.ClassOfBusinessId);
                        }
                    }
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                //  pluginContext.ThrowException("Fault Exception Occured", ex);
            }
            catch (Exception ex) { exception = ex; }
            finally
            {
                if (exception != null)
                {
                    pluginContext.LogException(exception, "AISMessageLogic.ValidateAISMessagePostProcessing");
                    //  throw new InvalidPluginExecutionException(exception.Message);
                }
            }
            pluginContext.LogMessage("AISMessageLogic.ValidateAISMessagePostProcessing- Unloaded");
        }

        /// <summary>
        /// This method does process Policy AIS Message.
        /// </summary>
        private void ProcessPolicyAISMessage()
        {
            pluginContext.LogMessage("AISMessageLogic.ProcessPolicyAISMessage- Loaded");
            Exception exception = null;
            try
            {
                string sPolicyNumber = string.Empty
                        , sCL0034_Policy_Status = string.Empty;

                bool bHasPolicyProcessed = false;

                if (entity.Attributes.Contains(Constants.AISMessage.PolicyNumber)
                    && !string.IsNullOrEmpty(entity[Constants.AISMessage.PolicyNumber].ToString()))
                {
                    sPolicyNumber = entity[Constants.AISMessage.PolicyNumber].ToString();
                    pluginContext.LogMessage($"sPolicyNumber: '{sPolicyNumber}'");

                    //Commented by Samiksha Dhakde on 11:01:2023 : AIS Message Notification for customer does not exist handled in 1413 line.
                    //if (!entity.Attributes.Contains(Constants.AISMessage.Customer))
                    //{
                    //    tracingService.Trace("rsa_possiblesmeduplicatelinkid does not contain data");
                    //    pluginContext.LogMessage(Constants.AISMessage.CustomerDoesNotExist);
                    //    this.UpdateAISMessageStatus((int)Constants.AISMessage.AISMessage_Status.Error, Constants.AISMessage.CustomerDoesNotExist);
                    //    this.CreateAISMessageNotification(entity, null, null, null, 0, Constants.AISMessage.CustomerDoesNotExist, Constants.AISMessage.CustomerDoesNotExist, "Create AIS Message (Policy)");
                    //Commented on 11:01:2023 by Samiksha Dhakde - AIS Requiremnet --> Policy create/update should not be stopped at any phase.
                    //pluginContext.LogMessage("AISMessageLogic.ProcessPolicyAISMessage- Unoaded");
                    //return;
                    //}

                    erCustomer = entity.GetAttributeValue<EntityReference>(Constants.AISMessage.Customer);
                    ePolicy = this.GetPolicy();
                    if (ePolicy == null)
                    {
                        pluginContext.LogMessage($"ePolicy == null");
                        pluginContext.LogMessage($"CREATE POLICY RECORD IN CRM.");
                        ePolicy = this.CreatePolicy(out bHasPolicyProcessed);
                    }
                    else
                    {
                        pluginContext.LogMessage($"UPDATE POLICY '{ePolicy.Id}' RECORD IN CRM.");

                        object[] oRSACustomeLabels = { Constants.RSACustomLabel.CL0034_Policy_Status };

                        EntityCollection ecRSACustomLabels = this.GetCustomLabel(oRSACustomeLabels);
                        if (ecRSACustomLabels != null && ecRSACustomLabels.Entities.Count > 0 && ecRSACustomLabels[0].Contains(Constants.RSACustomLabel.Values)
                            && !string.IsNullOrEmpty(ecRSACustomLabels[0][Constants.RSACustomLabel.Values].ToString()))
                        {
                            sCL0034_Policy_Status = ecRSACustomLabels[0][Constants.RSACustomLabel.Values].ToString();
                        }

                        pluginContext.LogMessage($"UPDATE POLICY STATUS: '{sCL0034_Policy_Status}' IN CRM.");

                        if (string.IsNullOrEmpty(sCL0034_Policy_Status) ||
                                (!string.IsNullOrEmpty(sCL0034_Policy_Status)
                                && ePolicy.Attributes.Contains(Constants.Policy.PolicyStatus)
                                && sCL0034_Policy_Status.ToLower().Trim().Contains(ePolicy.FormattedValues[Constants.Policy.PolicyStatus].ToLower().Trim())))
                        {
                            ePolicy = this.UpdatePolicy(ePolicy, out bHasPolicyProcessed);
                        }
                    }
                    if (bHasPolicyProcessed)
                    {
                        //Modified by Samiksha Dhakde on 11:01:2023 to handle AIS Message Notifcation creation : AIS Requirement.
                        if (bDoesBrokerExist && entity.Attributes.Contains(Constants.AISMessage.Customer))
                        {
                            this.UpdateAISMessageStatus((int)Constants.AISMessage.AISMessage_Status.Processed);
                            this.CreateAISMessageNotification(entity, ePolicy, null, null, 1, "Message processed successfully", "Message processed successfully", "Create Policy");
                        }
                        if (!entity.Attributes.Contains(Constants.AISMessage.Customer))
                        {
                            this.UpdateAISMessageStatus((int)Constants.AISMessage.AISMessage_Status.ProcessedwithError, Constants.AISMessage.CustPostCodeDoesNotExist);
                            this.CreateAISMessageNotification(entity, ePolicy, null, null, 0, Constants.AISMessage.CustPostCodeDoesNotExist, Constants.AISMessage.CustPostCodeDoesNotExist, "Create AIS Message (Policy)");
                        }
                        if (!bDoesBrokerExist)
                        {
                            this.UpdateAISMessageStatus((int)Constants.AISMessage.AISMessage_Status.ProcessedwithError, Constants.AISMessage.BrokerDoesNotExist);
                            this.CreateAISMessageNotification(entity, ePolicy, null, null, 0, Constants.AISMessage.BrokerDoesNotExist, Constants.AISMessage.BrokerDoesNotExist, "Create Policy");
                        }

                    }
                    else
                    {
                        this.UpdateAISMessageStatus((int)Constants.AISMessage.AISMessage_Status.Error);
                        this.CreateAISMessageNotification(entity, null, null, null, 0, Constants.AISMessage.PolicyNotProcessed, Constants.AISMessage.PolicyNotProcessed, "Create Policy");
                    }
                    pluginContext.LogMessage($"Policy record:'{ePolicy.Id}' has been processed successfully.");
                }
                else
                {
                    this.UpdateAISMessageStatus((int)Constants.AISMessage.AISMessage_Status.Error, Constants.AISMessage.PolicyDoesNotExist);
                    this.CreateAISMessageNotification(entity, null, null, null, 0, Constants.AISMessage.PolicyDoesNotExist, Constants.AISMessage.PolicyDoesNotExist, "Create AIS Message (Policy)");
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                pluginContext.ThrowException("Fault Exception Occured", ex);
            }
            catch (Exception ex) { exception = ex; }
            finally
            {
                if (exception != null)
                {
                    pluginContext.LogException(exception, "AISMessageLogic.ProcessPolicyAISMessage");
                    //  throw new InvalidPluginExecutionException(exception.Message);
                }
            }
            pluginContext.LogMessage("AISMessageLogic.ProcessPolicyAISMessage- Unloaded");
        }

        /// <summary>
        /// This method does process Quote AIS Message.
        /// </summary>
        private void ProcessQuoteAISMessage()
        {
            pluginContext.LogMessage("AISMessageLogic.ProcessQuoteAISMessage- Loaded");
            Exception exception = null;
            try
            {
                string sQuoteNumber = string.Empty;
                bool bHasQuoteProcessed = false;

                if (entity.Attributes.Contains(Constants.AISMessage.QuoteNumber)
                    && !string.IsNullOrEmpty(entity[Constants.AISMessage.QuoteNumber].ToString()))
                {
                    ///create case
                    ///Modified on- 27/01/2022 Nida
                    pluginContext.LogMessage("ProcessQuoteAISMessage.UpdateAISMessageStatus- Loaded");
                    this.UpdateAISMessageStatus((int)Constants.AISMessage.AISMessage_Status.Waiting);
                    entity[Constants.AISMessage.MessageStatus] = new OptionSetValue((int)Constants.AISMessage.AISMessage_Status.Waiting);
                    pluginContext.LogMessage("ProcessQuoteAISMessage.QuoteAISMessagesAction- Loaded");
                    /// Modified by Sumegh :TFs-258 : 11 Aug 2022 :  Code commented for CR requirement to be reversed and case creation to stop as per business requirement
                    //this.QuoteAISMessagesAction();
                    pluginContext.LogMessage("AISMessageLogic.QuoteAISMessagesAction- UnLoaded");
                    ///end case creation

                    sQuoteNumber = entity[Constants.AISMessage.QuoteNumber].ToString();
                    pluginContext.LogMessage($"sQuoteNumber: '{sQuoteNumber}'");

                    //if (!entity.Attributes.Contains(Constants.AISMessage.Customer))
                    //{
                    //    pluginContext.LogMessage(Constants.AISMessage.CustomerDoesNotExist);
                    //    this.UpdateAISMessageStatus((int)Constants.AISMessage.AISMessage_Status.Error, Constants.AISMessage.CustomerDoesNotExist);
                    //    this.CreateAISMessageNotification(entity, null, null, null, 0, Constants.AISMessage.CustomerDoesNotExist, Constants.AISMessage.CustomerDoesNotExist, "Create AIS Message (Quote)");
                    //Commented by Samiksha Dhakde 11:01:2023 AIS Requiremnt : Quote create/update should not be stopped if cutomer does not exist.
                    //pluginContext.LogMessage("AISMessageLogic.ProcessQuoteAISMessage- Unoaded");
                    //return;
                    //}
                    //Commented by Samiksha Dhakde 11:01:2023 AIS Requiremnt : Quote create/update should not be stopped if cutomer does not exist.
                    erCustomer = entity.GetAttributeValue<EntityReference>(Constants.AISMessage.Customer);
                    if (erCustomer == null)
                    {
                        pluginContext.LogMessage("erCustomer == null");
                        //Commented by Samiksha Dhakde 11:01:2023
                        //return;
                    }
                    else
                    {
                        pluginContext.LogMessage($"Customer: '{erCustomer.Id}' has been identified.");
                        {
                            FilterExpression filterEx = null;
                            ColumnSet column = null;
                            OrderExpression order = null;
                            EntityCollection ecQuotes = null;

                            filterEx = new FilterExpression
                            {
                                FilterOperator = LogicalOperator.And,
                                Conditions = { new ConditionExpression(Constants.Quote.Name, ConditionOperator.Equal, sQuoteNumber) }
                            };
                            column = new ColumnSet(Constants.Quote.EntityId, Constants.Quote.Name);
                            order = new OrderExpression(Constants.Quote.ModifiedOn, OrderType.Descending);
                            ecQuotes = this.GetEntityCollection(Constants.Quote.EntityName, filterEx, order, column, 1);
                            if (ecQuotes != null && ecQuotes.Entities.Count != 0)
                                eQuote = ecQuotes[0];
                        }
                    }

                    if (eQuote == null)
                    {
                        pluginContext.LogMessage("eQuote == null");
                        pluginContext.LogMessage($"CREATE Quote RECORD IN CRM.");
                        eQuote = this.CreateQuote(out bHasQuoteProcessed);
                        pluginContext.LogMessage($"eQuote record:'{eQuote.Id}' has been processed successfully.");

                        pluginContext.LogMessage("Processing QuoteAISMessagesAction post New Quote creation");
                        /// Modified by Sumegh :TFs-258 : 11 Aug 2022 :  Code commented for CR requirement to be reversed and case creation to stop as per business requirement
                        //this.QuoteAISMessagesAction();
                    }
                    else
                    {
                        pluginContext.LogMessage($"UPDATE Quote '{eQuote.Id}' RECORD IN CRM.");

                        eQuote = this.UpdateQuote(eQuote, out bHasQuoteProcessed);
                    }

                    if (bHasQuoteProcessed)
                    {
                        //Modified by Samiksha Dhakde on 11:01:2023 to handle AIS Message Notifcation creation : AIS Requirement.
                        if (bDoesBrokerExist && entity.Attributes.Contains(Constants.AISMessage.Customer))
                        {
                            this.UpdateAISMessageStatus((int)Constants.AISMessage.AISMessage_Status.Processed);
                            this.CreateAISMessageNotification(entity, null, eQuote, null, 1, "Message processed successfully", "Message processed successfully", "Create Policy");
                        }
                        if (!entity.Attributes.Contains(Constants.AISMessage.Customer))
                        {
                            this.UpdateAISMessageStatus((int)Constants.AISMessage.AISMessage_Status.ProcessedwithError, Constants.AISMessage.CustomerDoesNotExist);
                            this.CreateAISMessageNotification(entity, null, eQuote, null, 0, Constants.AISMessage.CustPostCodeDoesNotExist, Constants.AISMessage.CustPostCodeDoesNotExist, "Create AIS Message (Policy)");
                        }
                        if (!bDoesBrokerExist)
                        {
                            this.UpdateAISMessageStatus((int)Constants.AISMessage.AISMessage_Status.ProcessedwithError, Constants.AISMessage.BrokerDoesNotExist);
                            this.CreateAISMessageNotification(entity, null, eQuote, null, 0, Constants.AISMessage.BrokerDoesNotExist, Constants.AISMessage.BrokerDoesNotExist, "Create Policy");
                        }

                    }
                    else
                    {
                        this.UpdateAISMessageStatus((int)Constants.AISMessage.AISMessage_Status.Error);
                        this.CreateAISMessageNotification(entity, null, null, null, 0, Constants.AISMessage.QuoteNotProcessed, Constants.AISMessage.QuoteNotProcessed, "Create Quote");
                    }
                    //pluginContext.LogMessage($"eQuote record:'{eQuote.Id}' has been processed successfully.");
                }
                else
                {
                    this.UpdateAISMessageStatus((int)Constants.AISMessage.AISMessage_Status.Error, Constants.AISMessage.QuoteDoesNotExist);
                    this.CreateAISMessageNotification(entity, null, null, null, 0, Constants.AISMessage.QuoteDoesNotExist, Constants.AISMessage.QuoteDoesNotExist, "Create AIS Message (Quote)");
                }
                pluginContext.LogMessage($"eQuote record:'{eQuote.Id}' has been processed successfully.");


            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                pluginContext.ThrowException("Fault Exception Occured", ex);
            }
            catch (Exception ex) { exception = ex; }
            finally
            {
                if (exception != null)
                {
                    pluginContext.LogException(exception, "AISMessageLogic.ProcessQuoteAISMessage");
                    //throw new InvalidPluginExecutionException(exception.Message);
                }
            }
            pluginContext.LogMessage("AISMessageLogic.ProcessQuoteAISMessage- Unloaded");
        }

        /// <summary>
        /// This method does process Task AIS Message.
        /// </summary>
        private void ProcessTaskAISMessage()
        {
            pluginContext.LogMessage("AISMessageLogic.ProcessTaskAISMessage- Loaded");
            Exception exception = null;
            try
            {
                this.UpdateAISMessageStatus((int)Constants.AISMessage.AISMessage_Status.Waiting);
                entity[Constants.AISMessage.MessageStatus] = new OptionSetValue((int)Constants.AISMessage.AISMessage_Status.Waiting);
                this.TaskAISMessagesAction();
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                pluginContext.ThrowException("Fault Exception Occured", ex);
            }
            catch (Exception ex) { exception = ex; }
            finally
            {
                if (exception != null)
                {
                    pluginContext.LogException(exception, "AISMessageLogic.ProcessTaskAISMessage");
                    //throw new InvalidPluginExecutionException(exception.Message);
                }
            }
            pluginContext.LogMessage("AISMessageLogic.ProcessTaskAISMessage- Unloaded");
        }

        /// <summary>
        /// Retrieves multiples records for a spcific filter.
        /// </summary>
        /// <param name="sEntityName"></param>
        /// <param name="inTopCount"></param>
        /// <param name="filterExpression"></param>
        /// <param name="order"></param>
        /// <param name="column"></param>
        /// <returns></returns>
        private EntityCollection GetEntityCollection(string entityName, FilterExpression filterExpression, OrderExpression orderExpression, ColumnSet columnSet, int topCount = 0)
        {
            pluginContext.LogMessage("AISMessageLogic.GetEntityCollection- Loaded");
            Exception exception = null;
            EntityCollection collection = null;
            try
            {
                pluginContext.LogMessage("AISMessageLogic.GetEntityCollection- Try");
                QueryExpression query = new QueryExpression
                {
                    NoLock = true,
                    Distinct = false,
                    EntityName = entityName,
                    ColumnSet = columnSet,
                    Criteria =
                    {
                        Filters =
                        {
                            filterExpression
                        }
                    }

                };
                if (topCount > 0) query.TopCount = topCount;
                if (orderExpression != null) query.Orders.Add(orderExpression);

                collection = service.RetrieveMultiple(query);
                pluginContext.LogMessage("AISMessageLogic.GetEntityCollection- Completed");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                pluginContext.ThrowException("Fault Exception Occured", ex);
            }
            catch (Exception ex) { exception = ex; }
            finally
            {
                if (exception != null)
                {
                    pluginContext.LogException(exception, "AISMessageLogic.GetEntityCollection");
                    // throw new InvalidPluginExecutionException(exception.Message);
                }
            }
            pluginContext.LogMessage("AISMessageLogic.GetEntityCollection- Unloaded");
            return collection;
        }

        /// <summary>
        /// This method does retrieve poilyc record.
        /// </summary>
        /// <returns></returns>
        private Entity GetPolicy(string policyNumber = null, ColumnSet column = null)
        {
            pluginContext.LogMessage("AISMessageLogic.GetPolicy- Loaded");
            Exception exception = null;
            Entity ePolicyRecord = null;
            string sPolicyNumber = string.Empty
                    , entityName_Policy = string.Empty;
            EntityCollection ecPolicies = null;
            ColumnSet columns_Policy = null;
            OrderExpression order_Policy = null;
            FilterExpression filterExpression_Policy = null;
            int topCount_Policy;

            try
            {
                if (string.IsNullOrEmpty(policyNumber) && entity.Attributes.Contains(Constants.AISMessage.PolicyNumber))
                    sPolicyNumber = Convert.ToString(entity[Constants.AISMessage.PolicyNumber]);
                else
                    sPolicyNumber = policyNumber;

                pluginContext.LogMessage($"sPolicyNumber: '{sPolicyNumber}'");

                if (column == null)
                {
                    columns_Policy = new ColumnSet(Constants.Policy.EntityId, Constants.Policy.Name, Constants.Policy.QuotePolicyVersion
                                        , Constants.Policy.PolicyStatus, Constants.Policy.PolicyKey, Constants.Policy.Broker
                                        , Constants.Policy.Customer, Constants.Policy.ModifiedOn, Constants.Policy.Owner, Constants.Policy.PolicySystem
                                        , Constants.Policy.ProductCode, Constants.Policy.ProductName, Constants.Policy.QuotePolicyStatus, Constants.Policy.QuotePolicyVersion);
                }
                else { columns_Policy = column; }

                pluginContext.LogMessage($"columns_Policy: '{columns_Policy}'");

                topCount_Policy = 1; entityName_Policy = Constants.Policy.EntityName;
                order_Policy = new OrderExpression(Constants.Policy.ModifiedOn, OrderType.Descending);
                filterExpression_Policy = new FilterExpression
                {
                    FilterOperator = LogicalOperator.And,
                    Conditions =
                    {
                        new ConditionExpression(Constants.Policy.PolicySystem,ConditionOperator.Equal,(int)Constants.Policy.Policy_System.AIS),
                        new ConditionExpression(Constants.Policy.Name,ConditionOperator.Equal,sPolicyNumber)
                    }
                };
                ecPolicies = this.GetEntityCollection(entityName_Policy, filterExpression_Policy, order_Policy, columns_Policy, topCount_Policy);
                if (ecPolicies != null && ecPolicies.Entities.Count > 0)
                    ePolicyRecord = ecPolicies[0];
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                pluginContext.ThrowException("Fault Exception Occured", ex);
            }
            catch (Exception ex) { exception = ex; }
            finally
            {
                if (exception != null)
                {
                    pluginContext.LogException(exception, "AISMessageLogic.GetPolicy");
                    //    throw new InvalidPluginExecutionException(exception.Message);
                }
            }
            pluginContext.LogMessage("AISMessageLogic.GetPolicy- Unloaded");
            return ePolicyRecord;
        }

        /// <summary>
        /// Create a new AIS message notification record for AIS Message values.
        /// </summary>
        /// <param name="bHasAisNotificationProcessed"></param>
        /// <returns></returns>
        private Entity CreateAISMessageNotification(Entity aisMessage, Entity Policy, Entity Quote, EntityReference eCase, int Type, string SystemDefinedError, string UserDefinedError, string MethodName)
        {
            pluginContext.LogMessage("AISMessageNotificationLogic.CreateAISMessageNotification- Loaded");
            Exception exception = null;
            Entity eAisNotification = null;
            bool bHasAisNotificationProcessed = false;
            try
            {
                eAisNotification = new Entity(Constants.AISMessageNotification.EntityName);
                eAisNotification[Constants.AISMessageNotification.AISMessage] = new EntityReference(Constants.AISMessage.EntityName, aisMessage.Id);

                if (Policy != null)
                    eAisNotification[Constants.AISMessageNotification.Policy] = new EntityReference(Constants.Policy.EntityName, Policy.Id);

                if (Quote != null)
                    eAisNotification[Constants.AISMessageNotification.Quote] = new EntityReference(Constants.Quote.EntityName, Quote.Id);

                if (eCase != null)
                    eAisNotification[Constants.AISMessageNotification.Case] = eCase;

                if (Type == 0)
                    eAisNotification[Constants.AISMessageNotification.Type] = new OptionSetValue((int)Constants.AISMessageNotification.AISMessageNotification_Type.Error);
                else
                    eAisNotification[Constants.AISMessageNotification.Type] = new OptionSetValue((int)Constants.AISMessageNotification.AISMessageNotification_Type.Success);

                eAisNotification[Constants.AISMessageNotification.UserDefinedError] = UserDefinedError;

                eAisNotification[Constants.AISMessageNotification.SystemDefinedError] = SystemDefinedError;

                eAisNotification[Constants.AISMessageNotification.MethodName] = MethodName;

                Guid gAisNotificationId = service.Create(eAisNotification);
                eAisNotification.Id = gAisNotificationId;

                if (eAisNotification.Id != Guid.Empty)
                    bHasAisNotificationProcessed = true;

                pluginContext.LogMessage($"AIS Message Notification: '{gAisNotificationId}' has been created successfully.");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                pluginContext.ThrowException("Fault Exception Occured", ex);
            }
            catch (Exception ex) { exception = ex; }
            finally
            {
                if (exception != null)
                {
                    pluginContext.LogException(exception, "AISMessageNotificationLogic.CreateAISMessageNotification");
                    //  throw new InvalidPluginExecutionException(exception.Message);
                }
            }
            pluginContext.LogMessage("AISMessageNotificationLogic.CreateAISMessageNotification- Unloaded");
            return eAisNotification;
        }


        /// <summary>
        /// Create a new SME customer Staging.
        /// </summary>
        /// <param name="bHasSMECustomerStagingProcessed"></param>
        /// <returns></returns>
        private Entity CreateSMECustomerStaging(Entity customer, string customerName, Entity aisMessage, string cusPostalCode, int DuplicateStatus)
        {
            pluginContext.LogMessage("SMECustomerStaging.CreateSMECustomerStaging- Loaded");
            Exception exception = null;
            Entity eSMECustomerStagingCreate = null;
            bool bHasSMECustomerStagingProcessed = false;
            try
            {
                eSMECustomerStagingCreate = new Entity(Constants.SMECustomerStaging.EntityName);

                eSMECustomerStagingCreate[Constants.SMECustomerStaging.AISMessage] = new EntityReference(Constants.AISMessage.EntityName, aisMessage.Id); ;
                tracingService.Trace("Duplicate Status: " + DuplicateStatus);
                if (DuplicateStatus == 1)
                {
                    eSMECustomerStagingCreate[Constants.SMECustomerStaging.DuplicateCheckStatus] = new OptionSetValue((int)Constants.SMECustomerStaging.SMECustomerStaging_DuplicateCheckStatus.Done);
                    tracingService.Trace("Check1 ");
                }
                if (DuplicateStatus == 2)
                {
                    eSMECustomerStagingCreate[Constants.SMECustomerStaging.DuplicateCheckStatus] = new OptionSetValue((int)Constants.SMECustomerStaging.SMECustomerStaging_DuplicateCheckStatus.Checking);
                    tracingService.Trace("Check2 ");
                }
                if (DuplicateStatus == 3)
                {
                    eSMECustomerStagingCreate[Constants.SMECustomerStaging.DuplicateCheckStatus] = new OptionSetValue((int)Constants.SMECustomerStaging.SMECustomerStaging_DuplicateCheckStatus.Duplicate);
                    tracingService.Trace("Check1 ");
                }
                if (DuplicateStatus == 4)
                {
                    eSMECustomerStagingCreate[Constants.SMECustomerStaging.DuplicateCheckStatus] = new OptionSetValue((int)Constants.SMECustomerStaging.SMECustomerStaging_DuplicateCheckStatus.NoDuplicates);
                    tracingService.Trace("Check2 ");
                }
                tracingService.Trace("Getting Customer:");

                if (customer != null)
                {
                    eSMECustomerStagingCreate[Constants.SMECustomerStaging.Customer] = new EntityReference(Constants.Customer.EntityName, customer.Id);

                }
                var customerNameBigrams = RSA.CSI.Plugins.Helper.DiceCoefficient.GetBigramString(customerName);
                tracingService.Trace("Check3 ");
                string[] customerKeyWord = customerName.Split(' ');
                string cuskeyword = null;
                if (customerKeyWord[0].Equals("Mrs") || customerKeyWord[0].Equals("Mr") || customerKeyWord[0].Equals("Miss"))
                {
                    cuskeyword = customerKeyWord[1].ToUpperInvariant();
                }
                else
                {
                    cuskeyword = customerKeyWord[0].ToUpperInvariant();
                }

                eSMECustomerStagingCreate[Constants.SMECustomerStaging.CustomerKeyword] = cuskeyword;

                tracingService.Trace("Post Code inside SME Staging: " + cusPostalCode);
                if (!string.IsNullOrEmpty(cusPostalCode))
                {
                    tracingService.Trace("Post Code inside if in SME Staging: " + cusPostalCode);
                    eSMECustomerStagingCreate[Constants.SMECustomerStaging.PostCodeFinal] = cusPostalCode;

                    string[] customerPostalCode = cusPostalCode.ToString().Split(' ');
                    string postalCodePrefix = customerPostalCode[0];

                    eSMECustomerStagingCreate[Constants.SMECustomerStaging.PostCodePrefix] = postalCodePrefix;

                }

                tracingService.Trace("Post Code inside if - end in SME Staging: " + cusPostalCode);

                eSMECustomerStagingCreate[Constants.SMECustomerStaging.CustomerNameBigrams] = customerNameBigrams;
                tracingService.Trace("Check4 ");
                eSMECustomerStagingCreate[Constants.SMECustomerStaging.CustomerNameFinal] = customerName;

                string stripped = Regex.Replace(customerName.ToLowerInvariant(), @"[^0-9a-zA-Z]+", " ");
                string customerStripped = Regex.Replace(stripped, @"\s+", " ");

                eSMECustomerStagingCreate[Constants.SMECustomerStaging.CustomerNameStripped] = customerStripped;

                eSMECustomerStagingCreate[Constants.SMECustomerStaging.CustomerName] = customerName;

                tracingService.Trace("Check5 ");
                if (cuskeyword != null)
                {
                    var len = cuskeyword.Length;
                    if (len == 1)
                    {
                        var keywordPrefixLen1 = String.Concat(cuskeyword, "_");
                        eSMECustomerStagingCreate[Constants.SMECustomerStaging.KeywordPrefix] = keywordPrefixLen1;
                    }
                    else
                    {
                        var keywordPrefix = cuskeyword.Substring(0, 2);
                        eSMECustomerStagingCreate[Constants.SMECustomerStaging.KeywordPrefix] = keywordPrefix;
                    }
                }

                tracingService.Trace("Check6 ");
                if (cuskeyword != null)
                {
                    var len = cuskeyword.Length;
                    if (len == 1)
                    {
                        var keywordPrefix3Len1 = String.Concat(cuskeyword, "_");
                        eSMECustomerStagingCreate[Constants.SMECustomerStaging.KeywordPrefix3] = keywordPrefix3Len1;
                        eSMECustomerStagingCreate[Constants.SMECustomerStaging.KeywordPrefix3Value] = keywordPrefix3Len1;
                    }
                    else if (len == 2)
                    {
                        var keywordPrefix3Len2 = String.Concat(cuskeyword, "_");
                        eSMECustomerStagingCreate[Constants.SMECustomerStaging.KeywordPrefix3] = keywordPrefix3Len2;
                        eSMECustomerStagingCreate[Constants.SMECustomerStaging.KeywordPrefix3Value] = keywordPrefix3Len2;
                    }
                    else
                    {
                        var keywordPrefix3 = cuskeyword.Substring(0, 3);
                        eSMECustomerStagingCreate[Constants.SMECustomerStaging.KeywordPrefix3] = keywordPrefix3;
                        eSMECustomerStagingCreate[Constants.SMECustomerStaging.KeywordPrefix3Value] = keywordPrefix3;
                    }
                }
                tracingService.Trace("Check7 ");
                eSMECustomerStagingCreate[Constants.SMECustomerStaging.PhysicalAddress] = aisMessage.GetAttributeValue<string>(Constants.AISMessage.CustomerPhysicalAddress);

                Guid gSMEStageid = service.Create(eSMECustomerStagingCreate);
                eSMECustomerStagingCreate.Id = gSMEStageid;

                if (eSMECustomerStagingCreate.Id != Guid.Empty)
                    bHasSMECustomerStagingProcessed = true;

                pluginContext.LogMessage($"SME Customer Staging : '{gSMEStageid}' has been created successfully.");
            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                pluginContext.ThrowException("Fault Exception Occured", ex);
            }
            catch (Exception ex) { exception = ex; }
            finally
            {
                if (exception != null)
                {
                    pluginContext.LogException(exception, "SMECustomerStagingCreate.CreateSMECustomerStaging");
                    //throw new InvalidPluginExecutionException(exception.Message);
                }
            }
            pluginContext.LogMessage("SMECustomerStagingCreate.CreateSMECustomerStaging- Unloaded");
            return eSMECustomerStagingCreate;


        }

        //Modified by: Samiksha Dhakde || Modified on: 5-Jan-2023
        //Create Customer if external id (Customer name + post code) provided does not exist in dynamics.
        private Entity CreateCustomer(out bool isCustomerRecordProcessed)
        {
            pluginContext.LogMessage("AISMessageLogic.CreateCustomer- Loaded");
            Entity eCustomerCreate = null;
            isCustomerRecordProcessed = false;
            try
            {
                eCustomerCreate = new Entity(Constants.Customer.EntityName);
                if (entity.Attributes.Contains(Constants.AISMessage.CustomerBusinessName) && !string.IsNullOrEmpty(Convert.ToString(entity[Constants.AISMessage.CustomerBusinessName])))
                    eCustomerCreate[Constants.Customer.Name] = Convert.ToString(entity[Constants.AISMessage.CustomerBusinessName]);
                else
                    eCustomerCreate[Constants.Customer.Name] = Convert.ToString(entity[Constants.AISMessage.CustomerName]);
                if (entity.Attributes.Contains(Constants.AISMessage.CustomerPostCode))
                    eCustomerCreate[Constants.Customer.PostalCode] = Convert.ToString(entity[Constants.AISMessage.CustomerPostCode]);


                //CreateRequest request = new CreateRequest();
                //request.Target = eCustomerCreate;
                //request.Parameters.Add("SuppressDuplicateDetection", false);

                //Guid gCustomerId = service.Create(eCustomerCreate);
                //try
                //{

                //    pluginContext.LogMessage("Trace try before");
                //    CreateResponse response = (CreateResponse)service.Execute(request);

                //    eCustomerCreate.Id = response.id;
                //    pluginContext.LogMessage("Trace try after");
                //}
                //catch (Exception ex)
                //{
                //    pluginContext.LogMessage("Duplicates exist");
                //    throw ex;
                //}
                Guid gCustomerId = service.Create(eCustomerCreate);
                eCustomerCreate.Id = gCustomerId;

                if (eCustomerCreate.Id != Guid.Empty)
                    isCustomerRecordProcessed = true;

                pluginContext.LogMessage($"Customer: '{eCustomerCreate.Id}' has been created successfully.");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                pluginContext.ThrowException("Fault Exception Occured", ex);
            }
            return eCustomerCreate;
        }


        /// <summary>
        /// Update SME customer Staging.
        /// </summary>
        /// <returns></returns>
        private void UpdateSMEStagingCustomerStaging(int iStatusValue)
        {
            pluginContext.LogMessage("SMEStagingCustomerStaging.UpdateSMEStagingCustomerStaging- Loaded");
            Exception exception = null;
            try
            {
                Entity entityUpdate = new Entity(entity.LogicalName);
                entityUpdate.Id = entity.Id;
                service.Update(entityUpdate);
                pluginContext.LogMessage($"Updated SME Customer Staging:'{entity.Id}' status to '{iStatusValue}'");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                pluginContext.ThrowException("Fault Exception Occured", ex);
            }
            catch (Exception ex) { exception = ex; }
            finally
            {
                if (exception != null)
                {
                    pluginContext.LogException(exception, "SMEStagingCustomerStaging.UpdateSMEStagingCustomerStaging");
                    // throw new InvalidPluginExecutionException(exception.Message);
                }
            }
            pluginContext.LogMessage("SMEStagingCustomerStaging.UpdateSMEStagingCustomerStaging- Unloaded");
        }

        /// <summary>
        /// Create a new policy record for AIS Message values.
        /// </summary>
        /// <param name="bHasPolicyProcessed"></param>
        /// <returns></returns>
        private Entity CreatePolicy(out bool bHasPolicyProcessed)
        {
            pluginContext.LogMessage("AISMessageLogic.CreatePolicy- Loaded");
            Exception exception = null;
            Entity ePolicyCreate = null;
            bHasPolicyProcessed = false;
            try
            {
                ePolicyCreate = new Entity(Constants.Policy.EntityName);
                if (entity.Attributes.Contains(Constants.AISMessage.PolicyNumber))
                {
                    ePolicyCreate[Constants.Policy.Name] = Convert.ToString(entity[Constants.AISMessage.PolicyNumber]);
                    ePolicyCreate[Constants.Policy.PolicyNumber] = Convert.ToString(entity[Constants.AISMessage.PolicyNumber]);
                }
                if (entity.Attributes.Contains(Constants.AISMessage.QuoteExpirationDate))
                    ePolicyCreate[Constants.Policy.QuoteExpirationDate] = entity[Constants.AISMessage.QuoteExpirationDate];
                if (entity.Attributes.Contains(Constants.AISMessage.ProductCode))
                    ePolicyCreate[Constants.Policy.ProductCode] = Convert.ToString(entity[Constants.AISMessage.ProductCode]);
                if (entity.Attributes.Contains(Constants.AISMessage.InceptionDate))
                    ePolicyCreate[Constants.Policy.InceptionDate] = entity[Constants.AISMessage.InceptionDate];
                if (entity.Attributes.Contains(Constants.AISMessage.ProductName))
                    ePolicyCreate[Constants.Policy.ProductName] = Convert.ToString(entity[Constants.AISMessage.ProductName]);
                if (entity.Attributes.Contains(Constants.AISMessage.QuotePolicyVersion))
                    ePolicyCreate[Constants.Policy.QuotePolicyVersion] = Convert.ToString(entity[Constants.AISMessage.QuotePolicyVersion]);
                if (entity.Attributes.Contains(Constants.AISMessage.ReasonForDivertDeclinePL))
                    ePolicyCreate[Constants.Policy.ReasonForDivertDecline] = entity[Constants.AISMessage.ReasonForDivertDeclinePL];
                if (entity.Attributes.Contains(Constants.AISMessage.CodeToRelatedQuotesPolicies))
                    ePolicyCreate[Constants.Policy.CodeToRelatedQuotesPolicies] = Convert.ToString(entity[Constants.AISMessage.CodeToRelatedQuotesPolicies]);
                if (entity.Attributes.Contains(Constants.AISMessage.AnnualPremiumIncludingTaxes))
                    ePolicyCreate[Constants.Policy.AnnualPremiumIncludingTaxes] = entity[Constants.AISMessage.AnnualPremiumIncludingTaxes];
                if (entity.Attributes.Contains(Constants.AISMessage.RenewalIndicator))
                    ePolicyCreate[Constants.Policy.RenewalIndicator] = entity[Constants.AISMessage.RenewalIndicator];
                if (entity.Attributes.Contains(Constants.AISMessage.PolicyRenewalDate))
                    ePolicyCreate[Constants.Policy.PolicyRenewalDate] = entity[Constants.AISMessage.PolicyRenewalDate];
                if (entity.Attributes.Contains(Constants.AISMessage.AnnualRevisedPremium))
                    ePolicyCreate[Constants.Policy.AnnualRevisedPremium] = entity[Constants.AISMessage.AnnualRevisedPremium];
                if (entity.Attributes.Contains(Constants.AISMessage.Scheme))
                    ePolicyCreate[Constants.Policy.SchemeId] = entity[Constants.AISMessage.Scheme];
                if (entity.Attributes.Contains(Constants.AISMessage.SchemePL))
                    ePolicyCreate[Constants.Policy.SchemePL] = entity[Constants.AISMessage.SchemePL];
                if (entity.Attributes.Contains(Constants.AISMessage.TransactionalPremiumIncludingTaxes))
                    ePolicyCreate[Constants.Policy.TransactionalPremiumIncludingTaxes] = entity[Constants.AISMessage.TransactionalPremiumIncludingTaxes];
                if (entity.Attributes.Contains(Constants.AISMessage.SchemeDescription))
                    ePolicyCreate[Constants.Policy.SchemeDescription] = entity[Constants.AISMessage.SchemeDescription];
                if (entity.Attributes.Contains(Constants.AISMessage.TransactionalRevisedPremium))
                    ePolicyCreate[Constants.Policy.TransactionalRevisedPremium] = entity[Constants.AISMessage.TransactionalRevisedPremium];
                if (entity.Attributes.Contains(Constants.AISMessage.BlanketCertificateIndicator))
                    ePolicyCreate[Constants.Policy.BlanketCertificateIndicator] = entity[Constants.AISMessage.BlanketCertificateIndicator];
                if (entity.Attributes.Contains(Constants.AISMessage.EffectiveDate))
                    ePolicyCreate[Constants.Policy.EffectiveDate] = entity[Constants.AISMessage.EffectiveDate];
                if (entity.Attributes.Contains(Constants.AISMessage.Broker))
                {
                    ePolicyCreate[Constants.Policy.Broker] = entity[Constants.AISMessage.Broker];
                    bDoesBrokerExist = true;
                }

                if (erCustomer != null)
                    ePolicyCreate[Constants.Policy.Customer] = erCustomer;
                if (entity.Attributes.Contains(Constants.AISMessage.RevisedPremium))
                    ePolicyCreate[Constants.Policy.RevisedPremium] = entity[Constants.AISMessage.RevisedPremium];
                if (entity.Attributes.Contains(Constants.AISMessage.Premium))
                    ePolicyCreate[Constants.Policy.Premium] = entity[Constants.AISMessage.Premium];
                if (entity.Attributes.Contains(Constants.AISMessage.PrimaryReference))
                    ePolicyCreate[Constants.Policy.PrimaryReference] = Convert.ToString(entity[Constants.AISMessage.PrimaryReference]);
                if (entity.Attributes.Contains(Constants.AISMessage.AgentCode))
                    ePolicyCreate[Constants.Policy.AgentCode] = Convert.ToString(entity[Constants.AISMessage.AgentCode]);
                if (entity.Attributes.Contains(Constants.AISMessage.AgentName))
                    ePolicyCreate[Constants.Policy.AgentName] = Convert.ToString(entity[Constants.AISMessage.AgentName]);
                ePolicyCreate[Constants.Policy.PolicySystem] = new OptionSetValue((int)Constants.Policy.Policy_System.AIS);

                var statusOptionsetRoot = new PQStatusJSON();
                statusOptionsetRoot = getPolicyQuoteStatusJsonValues("PolicyQuoteStatus_AISMessage");

                PolicyQuoteStatusMapping policyQuoteStatusMap = new PolicyQuoteStatusMapping();

                if (statusOptionsetRoot.PolicyQuoteStatusMapping != null && entity.Attributes.Contains(Constants.AISMessage.QuotePolicyStatusPL))
                {
                    tracingService.Trace("Inside if - policyQuoteStatusMap Quote Status");
                    policyQuoteStatusMap = (PolicyQuoteStatusMapping)statusOptionsetRoot.PolicyQuoteStatusMapping.FirstOrDefault(a => a.AISStatus.Equals(entity.GetAttributeValue<OptionSetValue>(Constants.AISMessage.QuotePolicyStatusPL).Value));
                    tracingService.Trace("policyQuoteStatusMap Quote Status" + policyQuoteStatusMap.PolicyStatus);
                    ePolicyCreate[Constants.Policy.PolicyStatus] = new OptionSetValue((int)policyQuoteStatusMap.PolicyStatus);
                }
                //if (entity.Attributes.Contains(Constants.AISMessage.ProductId))
                //    ePolicyCreate[Constants.Policy.ProductId] = entity[Constants.AISMessage.ProductId];

                var rosOptionsetRoot = new RouteOfSaleJSON();
                rosOptionsetRoot = getRouteOfSaleJsonValues("RouteofSale_AISMessage");

                RouteOfSaleMapping rosMap = new RouteOfSaleMapping();

                if (rosOptionsetRoot.RouteOfSaleMapping != null && entity.Attributes.Contains(Constants.AISMessage.RouteOfSale))
                {
                    rosMap = (RouteOfSaleMapping)rosOptionsetRoot.RouteOfSaleMapping.Find(a => a.AISROS.Equals(entity.GetAttributeValue<OptionSetValue>(Constants.AISMessage.RouteOfSale).Value));
                    tracingService.Trace("RouteOfSaleMapping Quote Status" + rosMap.ToString());

                    ePolicyCreate[Constants.Policy.RouteOfSale] = new OptionSetValue((int)rosMap.PolicyROS);
                }
                //ePolicyCreate[Constants.Policy.RouteOfSale] = entity[Constants.AISMessage.RouteOfSale];
                //if (entity.Attributes.Contains(Constants.AISMessage.PLCode))
                //    ePolicyCreate[Constants.Policy.PLCode] = entity[Constants.AISMessage.PLCode];
                //if (entity.Attributes.Contains(Constants.AISMessage.ClassOfBusiness))
                //    ePolicyCreate[Constants.Policy.ClassOfBusiness] = entity[Constants.AISMessage.ClassOfBusiness];
                if (entity.Attributes.Contains(Constants.AISMessage.PolicyMovementReasonId))
                    ePolicyCreate[Constants.Policy.PolicyMovementReason] = entity[Constants.AISMessage.PolicyMovementReasonId];
                if (entity.Attributes.Contains(Constants.AISMessage.PolicyMovementTypeLKP))
                    ePolicyCreate[Constants.Policy.PolicyMovementType] = entity[Constants.AISMessage.PolicyMovementTypeLKP];

                if (entity.Attributes.Contains(Constants.AISMessage.RouteOfSale) && entity.Attributes.Contains(Constants.AISMessage.ProductCode))
                {

                    int routeofSale = ((OptionSetValue)entity[Constants.AISMessage.RouteOfSale]).Value;
                    string prodCode = Convert.ToString(entity[Constants.AISMessage.ProductCode]);

                    EntityReference pl, cob, product = null;
                    string fetchProductTransformation = "<fetch distinct = 'false' mapping = 'logical' outputformat = 'xmlplatform' version = '1.0' >";
                    fetchProductTransformation += "<entity name = 'rsa_producttransformation'>";
                    fetchProductTransformation += "<attribute name = 'rsa_producttransformationid'/>";
                    fetchProductTransformation += "<attribute name = 'rsa_name'/>";
                    fetchProductTransformation += "<attribute name = 'createdon'/>";
                    fetchProductTransformation += "<attribute name = 'rsa_product'/>";
                    fetchProductTransformation += "<attribute name = 'rsa_pl'/>";
                    fetchProductTransformation += "<attribute name = 'rsa_classofbusiness'/>";
                    fetchProductTransformation += "<attribute name = 'rsa_route_of_sale'/>";
                    fetchProductTransformation += "<attribute name = 'rsa_product_name'/>";
                    fetchProductTransformation += "<attribute name = 'rsa_product_code'/>";
                    fetchProductTransformation += "<order descending = 'false' attribute = 'rsa_name'/>";
                    fetchProductTransformation += "<filter type = 'and'>";
                    fetchProductTransformation += "<condition attribute = 'rsa_route_of_sale' operator= 'eq' value = '" + routeofSale + "' />";
                    fetchProductTransformation += "<condition attribute = 'rsa_product_code' operator= 'eq' value = '" + prodCode + "' />";
                    fetchProductTransformation += "</filter>";
                    fetchProductTransformation += "</entity>";
                    fetchProductTransformation += "</fetch>";

                    EntityCollection ecProductTransformation = service.RetrieveMultiple(new FetchExpression(fetchProductTransformation));

                    if (ecProductTransformation.Entities.Count > 0)
                    {
                        tracingService.Trace("Inside If");

                        pl = ecProductTransformation.Entities[0].Attributes.Contains("rsa_pl") ? ecProductTransformation.Entities[0].GetAttributeValue<EntityReference>("rsa_pl") : null;
                        cob = ecProductTransformation.Entities[0].Attributes.Contains("rsa_classofbusiness") ? ecProductTransformation.Entities[0].GetAttributeValue<EntityReference>("rsa_classofbusiness") : null;
                        product = ecProductTransformation.Entities[0].Attributes.Contains("rsa_product") ? ecProductTransformation.Entities[0].GetAttributeValue<EntityReference>("rsa_product") : null;


                        if (pl != null)
                        {
                            ePolicyCreate[Constants.Policy.PLCode] = new EntityReference(pl.LogicalName, pl.Id);
                            tracingService.Trace("Inside If - 1659" + pl.Name);
                        }

                        if (cob != null)
                        {
                            ePolicyCreate[Constants.Policy.ClassOfBusiness] = new EntityReference(cob.LogicalName, cob.Id);
                            tracingService.Trace("Inside If - 1665" + cob.Name);
                        }

                        if (product != null)
                        {
                            ePolicyCreate[Constants.Policy.ProductId] = new EntityReference(product.LogicalName, product.Id);
                            tracingService.Trace("Inside If - 1671" + product.Name);
                        }
                    }
                }


                Guid gPolicyId = service.Create(ePolicyCreate);
                ePolicyCreate.Id = gPolicyId;

                if (ePolicyCreate.Id != Guid.Empty)
                    bHasPolicyProcessed = true;

                pluginContext.LogMessage($"Policy: '{gPolicyId}' has been created successfully.");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                pluginContext.ThrowException("Fault Exception Occured", ex);
            }
            catch (Exception ex) { exception = ex; }
            finally
            {
                if (exception != null)
                {
                    pluginContext.LogException(exception, "AISMessageLogic.CreatePolicy");
                    //throw new InvalidPluginExecutionException(exception.Message);
                }
            }
            pluginContext.LogMessage("AISMessageLogic.CreatePolicy- Unloaded");
            return ePolicyCreate;
        }

        /// <summary>
        /// Update policy record with AIS Message values.
        /// </summary>
        /// <param name="ePolicy"></param>
        /// <param name="bHasPolicyProcessed"></param>
        /// <returns></returns>

        private Entity UpdatePolicy(Entity ePolicy, out bool bHasPolicyProcessed)
        {
            pluginContext.LogMessage("AISMessageLogic.UpdatePolicy- Loaded");
            Exception exception = null;
            Entity ePolicyUpdate = null;
            string sPolicyNumber = string.Empty;
            bHasPolicyProcessed = false;
            try
            {
                if (entity.Attributes.Contains(Constants.AISMessage.PolicyNumber))
                    sPolicyNumber = Convert.ToString(entity[Constants.AISMessage.PolicyNumber]);

                ePolicyUpdate = new Entity(Constants.Policy.EntityName);
                ePolicyUpdate.Id = ePolicy.Id;

                if (entity.Attributes.Contains(Constants.AISMessage.PolicyNumber))
                {
                    ePolicyUpdate[Constants.Policy.Name] = Convert.ToString(entity[Constants.AISMessage.PolicyNumber]);
                    ePolicyUpdate[Constants.Policy.PolicyNumber] = Convert.ToString(entity[Constants.AISMessage.PolicyNumber]);
                }
                if (entity.Attributes.Contains(Constants.AISMessage.QuoteExpirationDate))
                    ePolicyUpdate[Constants.Policy.QuoteExpirationDate] = entity[Constants.AISMessage.QuoteExpirationDate];
                if (entity.Attributes.Contains(Constants.AISMessage.ProductCode))
                    ePolicyUpdate[Constants.Policy.ProductCode] = Convert.ToString(entity[Constants.AISMessage.ProductCode]);
                if (entity.Attributes.Contains(Constants.AISMessage.InceptionDate))
                    ePolicyUpdate[Constants.Policy.InceptionDate] = entity[Constants.AISMessage.InceptionDate];
                if (entity.Attributes.Contains(Constants.AISMessage.ProductName))
                    ePolicyUpdate[Constants.Policy.ProductName] = Convert.ToString(entity[Constants.AISMessage.ProductName]);
                if (entity.Attributes.Contains(Constants.AISMessage.QuotePolicyVersion))
                    ePolicyUpdate[Constants.Policy.QuotePolicyVersion] = Convert.ToString(entity[Constants.AISMessage.QuotePolicyVersion]);
                if (entity.Attributes.Contains(Constants.AISMessage.ReasonForDivertDeclinePL))
                    ePolicyUpdate[Constants.Policy.ReasonForDivertDecline] = entity[Constants.AISMessage.ReasonForDivertDeclinePL];
                if (entity.Attributes.Contains(Constants.AISMessage.CodeToRelatedQuotesPolicies))
                    ePolicyUpdate[Constants.Policy.CodeToRelatedQuotesPolicies] = Convert.ToString(entity[Constants.AISMessage.CodeToRelatedQuotesPolicies]);
                if (entity.Attributes.Contains(Constants.AISMessage.AnnualPremiumIncludingTaxes))
                    ePolicyUpdate[Constants.Policy.AnnualPremiumIncludingTaxes] = entity[Constants.AISMessage.AnnualPremiumIncludingTaxes];
                if (entity.Attributes.Contains(Constants.AISMessage.RenewalIndicator))
                    ePolicyUpdate[Constants.Policy.RenewalIndicator] = entity[Constants.AISMessage.RenewalIndicator];
                if (entity.Attributes.Contains(Constants.AISMessage.PolicyRenewalDate))
                    ePolicyUpdate[Constants.Policy.PolicyRenewalDate] = entity[Constants.AISMessage.PolicyRenewalDate];
                if (entity.Attributes.Contains(Constants.AISMessage.AnnualRevisedPremium))
                    ePolicyUpdate[Constants.Policy.AnnualRevisedPremium] = entity[Constants.AISMessage.AnnualRevisedPremium];
                if (entity.Attributes.Contains(Constants.AISMessage.Scheme))
                    ePolicyUpdate[Constants.Policy.SchemeId] = entity[Constants.AISMessage.Scheme];
                if (entity.Attributes.Contains(Constants.AISMessage.SchemePL))
                    ePolicyUpdate[Constants.Policy.SchemePL] = entity[Constants.AISMessage.SchemePL];
                if (entity.Attributes.Contains(Constants.AISMessage.TransactionalPremiumIncludingTaxes))
                    ePolicyUpdate[Constants.Policy.TransactionalPremiumIncludingTaxes] = entity[Constants.AISMessage.TransactionalPremiumIncludingTaxes];
                if (entity.Attributes.Contains(Constants.AISMessage.SchemeDescription))
                    ePolicyUpdate[Constants.Policy.SchemeDescription] = entity[Constants.AISMessage.SchemeDescription];
                if (entity.Attributes.Contains(Constants.AISMessage.TransactionalRevisedPremium))
                    ePolicyUpdate[Constants.Policy.TransactionalRevisedPremium] = entity[Constants.AISMessage.TransactionalRevisedPremium];
                if (entity.Attributes.Contains(Constants.AISMessage.BlanketCertificateIndicator))
                    ePolicyUpdate[Constants.Policy.BlanketCertificateIndicator] = entity[Constants.AISMessage.BlanketCertificateIndicator];
                if (entity.Attributes.Contains(Constants.AISMessage.EffectiveDate))
                    ePolicyUpdate[Constants.Policy.EffectiveDate] = entity[Constants.AISMessage.EffectiveDate];
                if (entity.Attributes.Contains(Constants.AISMessage.Broker))
                {
                    ePolicyUpdate[Constants.Policy.Broker] = entity[Constants.AISMessage.Broker];
                    bDoesBrokerExist = true;
                }
                if (erCustomer != null)
                    ePolicyUpdate[Constants.Policy.Customer] = erCustomer;
                if (entity.Attributes.Contains(Constants.AISMessage.RevisedPremium))
                    ePolicyUpdate[Constants.Policy.RevisedPremium] = entity[Constants.AISMessage.RevisedPremium];
                if (entity.Attributes.Contains(Constants.AISMessage.Premium))
                    ePolicyUpdate[Constants.Policy.Premium] = entity[Constants.AISMessage.Premium];
                if (entity.Attributes.Contains(Constants.AISMessage.PrimaryReference))
                    ePolicyUpdate[Constants.Policy.PrimaryReference] = Convert.ToString(entity[Constants.AISMessage.PrimaryReference]);
                if (entity.Attributes.Contains(Constants.AISMessage.AgentCode))
                    ePolicyUpdate[Constants.Policy.AgentCode] = Convert.ToString(entity[Constants.AISMessage.AgentCode]);
                if (entity.Attributes.Contains(Constants.AISMessage.AgentName))
                    ePolicyUpdate[Constants.Policy.AgentName] = Convert.ToString(entity[Constants.AISMessage.AgentName]);
                ePolicyUpdate[Constants.Policy.PolicySystem] = new OptionSetValue((int)Constants.Policy.Policy_System.AIS);

                var rosOptionsetRoot = new RouteOfSaleJSON();
                rosOptionsetRoot = getRouteOfSaleJsonValues("RouteofSale_AISMessage");

                RouteOfSaleMapping rosMap = new RouteOfSaleMapping();

                if (rosOptionsetRoot.RouteOfSaleMapping != null && entity.Attributes.Contains(Constants.AISMessage.RouteOfSale))
                {
                    rosMap = (RouteOfSaleMapping)rosOptionsetRoot.RouteOfSaleMapping.Find(a => a.AISROS.Equals(entity.GetAttributeValue<OptionSetValue>(Constants.AISMessage.RouteOfSale).Value));
                    tracingService.Trace("RouteOfSaleMapping Quote Status" + rosMap.ToString());

                    ePolicyUpdate[Constants.Policy.RouteOfSale] = new OptionSetValue((int)rosMap.PolicyROS);
                }
                //ePolicyUpdate[Constants.Policy.RouteOfSale] = entity[Constants.AISMessage.RouteOfSale];


                var statusOptionsetRoot = new PQStatusJSON();
                statusOptionsetRoot = getPolicyQuoteStatusJsonValues("PolicyQuoteStatus_AISMessage");

                PolicyQuoteStatusMapping policyQuoteStatusMap = new PolicyQuoteStatusMapping();

                if (statusOptionsetRoot.PolicyQuoteStatusMapping != null && entity.Attributes.Contains(Constants.AISMessage.QuotePolicyStatusPL))
                {
                    tracingService.Trace("Inside if - policyQuoteStatusMap Quote Status");
                    policyQuoteStatusMap = (PolicyQuoteStatusMapping)statusOptionsetRoot.PolicyQuoteStatusMapping.FirstOrDefault(a => a.AISStatus.Equals(entity.GetAttributeValue<OptionSetValue>(Constants.AISMessage.QuotePolicyStatusPL).Value));
                    tracingService.Trace("policyQuoteStatusMap Quote Status" + policyQuoteStatusMap.ToString());

                    ePolicyUpdate[Constants.Policy.PolicyStatus] = new OptionSetValue((int)policyQuoteStatusMap.PolicyStatus);


                }
                /*if (entity.Attributes.Contains(Constants.AISMessage.ProductId))
                    ePolicyUpdate[Constants.Policy.ProductId] = entity[Constants.AISMessage.ProductId];
                if (entity.Attributes.Contains(Constants.AISMessage.PLCode))
                    ePolicyUpdate[Constants.Policy.PLCode] = entity[Constants.AISMessage.PLCode];
                if (entity.Attributes.Contains(Constants.AISMessage.ClassOfBusiness))
                    ePolicyUpdate[Constants.Policy.ClassOfBusiness] = entity[Constants.AISMessage.ClassOfBusiness];*/

                if (entity.Attributes.Contains(Constants.AISMessage.RouteOfSale) && entity.Attributes.Contains(Constants.AISMessage.ProductCode))
                {

                    int routeofSale = ((OptionSetValue)entity[Constants.AISMessage.RouteOfSale]).Value;
                    string prodCode = Convert.ToString(entity[Constants.AISMessage.ProductCode]);

                    EntityReference pl, cob, product = null;
                    string fetchProductTransformation = "<fetch distinct = 'false' mapping = 'logical' outputformat = 'xmlplatform' version = '1.0' no-lock='true'>";
                    fetchProductTransformation += "<entity name = 'rsa_product'>";
                    fetchProductTransformation += "<attribute name = 'rsa_productid'/>";
                    fetchProductTransformation += "<attribute name = 'rsa_name'/>";
                    fetchProductTransformation += "<attribute name = 'createdon'/>";
                    fetchProductTransformation += "<attribute name = 'rsa_pandlid'/>";
                    fetchProductTransformation += "<attribute name = 'rsa_classofbusinessid'/>";
                    fetchProductTransformation += "<attribute name = 'rsa_aisrouteofsale'/>";
                    fetchProductTransformation += "<attribute name = 'rsa_aismessagerouteofsale'/>";
                    fetchProductTransformation += "<attribute name = 'rsa_aisproductcode'/>";
                    fetchProductTransformation += "<order descending = 'false' attribute = 'rsa_name'/>";
                    fetchProductTransformation += "<filter type = 'and'>";
                    fetchProductTransformation += "<condition attribute = 'rsa_aismessagerouteofsale' operator= 'eq' value = '" + routeofSale + "' />";
                    fetchProductTransformation += "<condition attribute = 'rsa_aisproductcode' operator= 'eq' value = '" + prodCode + "' />";
                    fetchProductTransformation += "</filter>";
                    fetchProductTransformation += "</entity>";
                    fetchProductTransformation += "</fetch>";


                    EntityCollection ecProductTransformation = service.RetrieveMultiple(new FetchExpression(fetchProductTransformation));

                    if (ecProductTransformation.Entities.Count > 0)
                    {
                        tracingService.Trace("Inside If");

                        pl = ecProductTransformation.Entities[0].Attributes.Contains("rsa_pl") ? ecProductTransformation.Entities[0].GetAttributeValue<EntityReference>("rsa_pl") : null;
                        cob = ecProductTransformation.Entities[0].Attributes.Contains("rsa_classofbusiness") ? ecProductTransformation.Entities[0].GetAttributeValue<EntityReference>("rsa_classofbusiness") : null;
                        //product = ecProductTransformation.Entities[0].Attributes.Contains("rsa_product") ? ecProductTransformation.Entities[0].GetAttributeValue<EntityReference>("rsa_product") : null;
                        Guid products = ecProductTransformation.Entities[0].Id;

                        if (pl != null)
                        {
                            ePolicyUpdate[Constants.Policy.PLCode] = new EntityReference(pl.LogicalName, pl.Id);
                            tracingService.Trace("Inside If - 1659" + pl.Name);
                        }

                        if (cob != null)
                        {
                            ePolicyUpdate[Constants.Policy.ClassOfBusiness] = new EntityReference(cob.LogicalName, cob.Id);
                            tracingService.Trace("Inside If - 1665" + cob.Name);
                        }

                        if (products != null)
                        {
                            //ePolicyUpdate[Constants.Policy.ProductId] = new EntityReference(product.LogicalName, product.Id);
                            ePolicyUpdate[Constants.Policy.ProductId] = new EntityReference("rsa_product", ecProductTransformation.Entities[0].Id);
                            tracingService.Trace("Inside If - 1671" + products);
                        }
                    }
                }

                if (entity.Attributes.Contains(Constants.AISMessage.PolicyMovementReasonId))
                    ePolicyUpdate[Constants.Policy.PolicyMovementReason] = entity[Constants.AISMessage.PolicyMovementReasonId];
                if (entity.Attributes.Contains(Constants.AISMessage.PolicyMovementTypeLKP))
                    ePolicyUpdate[Constants.Policy.PolicyMovementType] = entity[Constants.AISMessage.PolicyMovementTypeLKP];

                service.Update(ePolicyUpdate);
                bHasPolicyProcessed = true;
                pluginContext.LogMessage($"Policy No. '{sPolicyNumber}' has been updated successfully.");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                pluginContext.ThrowException("Fault Exception Occured", ex);
            }
            catch (Exception ex) { exception = ex; }
            finally
            {
                if (exception != null)
                {
                    pluginContext.LogException(exception, "AISMessageLogic.UpdatePolicy");
                    // throw new InvalidPluginExecutionException(exception.Message);
                }
            }
            pluginContext.LogMessage("AISMessageLogic.UpdatePolicy- Unloaded");
            return ePolicyUpdate;
        }

        /// <summary>
        /// Use this method to get broker entity reference.
        /// </summary>
        /// <param name="sBrokerCode"></param>
        /// <returns></returns>
        private Entity GetAgencyCode(string sBrokerCode)
        {
            pluginContext.LogMessage("AISMessageLogic.GetBroker- Loaded");
            Exception exception = null;
            Entity entity = null;
            EntityCollection ecAgencyCodes = null;
            string entityName = string.Empty;
            int topCount;
            ColumnSet column = null;
            FilterExpression filterExpression = null;
            OrderExpression order = null;

            try
            {
                topCount = 1; entityName = Constants.AgencyCode.EntityName;
                order = new OrderExpression(Constants.AgencyCode.ModifiedOn, OrderType.Descending);
                column = new ColumnSet(Constants.AgencyCode.Name, Constants.AgencyCode.EntityId, Constants.AgencyCode.Agency);
                filterExpression = new FilterExpression
                {
                    FilterOperator = LogicalOperator.And,
                    Conditions =
                                {
                                    //new ConditionExpression(Constants.AgencyCode.Name,ConditionOperator.Like,$"%{sBrokerCode}%")
                                    //Defect: 2096
                                    new ConditionExpression(Constants.AgencyCode.Name,ConditionOperator.Equal,$"{sBrokerCode}")
                                }
                };

                ecAgencyCodes = this.GetEntityCollection(entityName, filterExpression, order, column, topCount);
                if (ecAgencyCodes != null && ecAgencyCodes.Entities.Count > 0)
                    entity = ecAgencyCodes[0];
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                pluginContext.ThrowException("Fault Exception Occured", ex);
            }
            catch (Exception ex) { exception = ex; }
            finally
            {
                if (exception != null)
                {
                    pluginContext.LogException(exception, "AISMessageLogic.GetBroker");
                    // throw new InvalidPluginExecutionException(exception.Message);
                }
            }
            pluginContext.LogMessage("AISMessageLogic.GetBroker- Unloaded");
            return entity;
        }

        /// <summary>
        /// This method does create Quote record.
        /// </summary>
        /// <param name="bHasPolicyProcessed"></param>
        /// <returns></returns>
        private Entity CreateQuote(out bool bHasPolicyProcessed)
        {
            pluginContext.LogMessage("AISMessageLogic.CreateQuote- Loaded");
            bHasPolicyProcessed = false;
            Exception exception = null;
            Entity eQuoteCreate = null;

            try
            {
                eQuoteCreate = new Entity(Constants.Quote.EntityName);

                eQuoteCreate[Constants.Quote.Name] = Convert.ToString(entity[Constants.AISMessage.QuoteNumber]);

                if (entity.Attributes.Contains(Constants.AISMessage.Scheme))
                    eQuoteCreate[Constants.Quote.SchemeId] = Convert.ToString(entity[Constants.AISMessage.Scheme]);

                if (entity.Attributes.Contains(Constants.AISMessage.Broker))
                {
                    eQuoteCreate[Constants.Quote.Brokerid] = entity[Constants.AISMessage.Broker];
                    bDoesBrokerExist = true;
                }

                if (erCustomer != null)
                    eQuoteCreate[Constants.Quote.Customer] = entity[Constants.AISMessage.Customer];

                if (entity.Attributes.Contains(Constants.AISMessage.AnnualPremiumIncludingTaxes))
                    eQuoteCreate[Constants.Quote.AnnualPremiumincludingTaxes] = entity[Constants.AISMessage.AnnualPremiumIncludingTaxes];

                if (entity.Attributes.Contains(Constants.AISMessage.AnnualRevisedPremium))
                    eQuoteCreate[Constants.Quote.AnnualRevisedPremium] = entity[Constants.AISMessage.AnnualRevisedPremium];

                if (entity.Attributes.Contains(Constants.AISMessage.RevisedPremium))
                    eQuoteCreate[Constants.Quote.RevisedPremium] = entity[Constants.AISMessage.RevisedPremium];

                if (entity.Attributes.Contains(Constants.AISMessage.TransactionalPremiumIncludingTaxes))
                    eQuoteCreate[Constants.Quote.TransactionalPremiumincludingtaxes] = entity[Constants.AISMessage.TransactionalPremiumIncludingTaxes];

                if (entity.Attributes.Contains(Constants.AISMessage.TransactionalRevisedPremium))
                    eQuoteCreate[Constants.Quote.TransactionalRevisedPremium] = entity[Constants.AISMessage.TransactionalRevisedPremium];

                if (entity.Attributes.Contains(Constants.AISMessage.Premium))
                    eQuoteCreate[Constants.Quote.Premium] = entity[Constants.AISMessage.Premium];

                if (entity.Attributes.Contains(Constants.AISMessage.QuoteExpirationDate))
                    eQuoteCreate[Constants.Quote.QuoteExpirationDate] = entity[Constants.AISMessage.QuoteExpirationDate];

                if (entity.Attributes.Contains(Constants.AISMessage.ReasonForDivertDeclinePL))
                    eQuoteCreate[Constants.Quote.ReasonforDivertDecline] = entity[Constants.AISMessage.ReasonForDivertDeclinePL];

                if (entity.Attributes.Contains(Constants.AISMessage.SchemeDescription))
                    eQuoteCreate[Constants.Quote.SchemeDescription] = Convert.ToString(entity[Constants.AISMessage.SchemeDescription]);

                if (entity.Attributes.Contains(Constants.AISMessage.AgentName))
                    eQuoteCreate[Constants.Quote.AgentName] = Convert.ToString(entity[Constants.AISMessage.AgentName]);

                if (entity.Attributes.Contains(Constants.AISMessage.AgentCode))
                    eQuoteCreate[Constants.Quote.AgentCode] = Convert.ToString(entity[Constants.AISMessage.AgentCode]);

                if (entity.Attributes.Contains(Constants.AISMessage.PrimaryReference))
                    eQuoteCreate[Constants.Quote.PrimaryReference] = Convert.ToString(entity[Constants.AISMessage.PrimaryReference]);

                tracingService.Trace("PolicyQuoteStatusMap Quote Status");

                var statusOptionsetRoot = new PQStatusJSON();
                statusOptionsetRoot = getPolicyQuoteStatusJsonValues("PolicyQuoteStatus_AISMessage");

                PolicyQuoteStatusMapping policyQuoteStatusMap = new PolicyQuoteStatusMapping();

                if (statusOptionsetRoot.PolicyQuoteStatusMapping != null && entity.Attributes.Contains(Constants.AISMessage.QuotePolicyStatusPL))
                {
                    tracingService.Trace("Inside if - policyQuoteStatusMap Quote Status");
                    policyQuoteStatusMap = (PolicyQuoteStatusMapping)statusOptionsetRoot.PolicyQuoteStatusMapping.FirstOrDefault(a => a.AISStatus.Equals(entity.GetAttributeValue<OptionSetValue>(Constants.AISMessage.QuotePolicyStatusPL).Value));
                    tracingService.Trace("policyQuoteStatusMap Quote Status" + policyQuoteStatusMap.ToString());

                    eQuoteCreate[Constants.Quote.QuotePolicyStatus] = new OptionSetValue((int)policyQuoteStatusMap.QuoteStatus);
                }
                //eQuoteCreate[Constants.Quote.QuotePolicyStatus] = entity[Constants.AISMessage.QuotePolicyStatusPL];

                if (entity.Attributes.Contains(Constants.AISMessage.QuotePolicyVersion))
                    eQuoteCreate[Constants.Quote.QuotePolicyVersion] = Convert.ToString(entity[Constants.AISMessage.QuotePolicyVersion]);

                if (entity.Attributes.Contains(Constants.AISMessage.CodeToRelatedQuotesPolicies))
                    eQuoteCreate[Constants.Quote.CodetorelateQuotesPolicies] = Convert.ToString(entity[Constants.AISMessage.CodeToRelatedQuotesPolicies]);

                if (entity.Attributes.Contains(Constants.AISMessage.PolicyRenewalDate))
                    eQuoteCreate[Constants.Quote.PolicyRenewalDate] = entity[Constants.AISMessage.PolicyRenewalDate];

                if (entity.Attributes.Contains(Constants.AISMessage.PolicyMovementReasonId))
                    eQuoteCreate[Constants.Quote.PolicyMovementReasonId] = entity[Constants.AISMessage.PolicyMovementReasonId];

                if (entity.Attributes.Contains(Constants.AISMessage.PolicyMovementTypeLKP))
                    eQuoteCreate[Constants.Quote.PolicyMovementType] = entity[Constants.AISMessage.PolicyMovementTypeLKP];

                if (entity.Attributes.Contains(Constants.AISMessage.EffectiveDate))
                    eQuoteCreate[Constants.Quote.EffectiveDate] = entity[Constants.AISMessage.EffectiveDate];

                if (entity.Attributes.Contains(Constants.AISMessage.InceptionDate))
                    eQuoteCreate[Constants.Quote.InceptionDate] = entity[Constants.AISMessage.InceptionDate];

                //if (entity.Attributes.Contains(Constants.AISMessage.RenewalIndicator))
                //    eQuote[Constants.Quote.RenewalIndicator] = entity[Constants.AISMessage.RenewalIndicator].ToString();

                var rosOptionsetRoot = new RouteOfSaleJSON();
                rosOptionsetRoot = getRouteOfSaleJsonValues("RouteofSale_AISMessage");

                RouteOfSaleMapping rosMap = new RouteOfSaleMapping();

                if (rosOptionsetRoot.RouteOfSaleMapping != null && entity.Attributes.Contains(Constants.AISMessage.RouteOfSale))
                {
                    rosMap = (RouteOfSaleMapping)rosOptionsetRoot.RouteOfSaleMapping.Find(a => a.AISROS.Equals(entity.GetAttributeValue<OptionSetValue>(Constants.AISMessage.RouteOfSale).Value));
                    tracingService.Trace("RouteOfSaleMapping Quote Status" + rosMap.ToString());

                    eQuoteCreate[Constants.Quote.RouteOfsale] = new OptionSetValue((int)rosMap.QuoteROS);
                }
                //eQuoteCreate[Constants.Quote.RouteOfsale] = entity[Constants.AISMessage.RouteOfSale];

                if (entity.Attributes.Contains(Constants.AISMessage.ProductCode))
                {
                    tracingService.Trace(Constants.Quote.ProductCode + "-" + Convert.ToString(entity[Constants.AISMessage.ProductCode]));
                    eQuoteCreate[Constants.Quote.ProductCode] = Convert.ToString(entity[Constants.AISMessage.ProductCode]);
                }

                if (entity.Attributes.Contains(Constants.AISMessage.ProductName))
                {
                    tracingService.Trace(Constants.Quote.ProductName + "-" + Convert.ToString(entity[Constants.AISMessage.ProductName]));
                    eQuoteCreate[Constants.Quote.ProductName] = Convert.ToString(entity[Constants.AISMessage.ProductName]);
                }

                if (entity.Attributes.Contains(Constants.AISMessage.ProductId))
                {
                    tracingService.Trace(Constants.Quote.ProductId + "-" + Convert.ToString(entity[Constants.AISMessage.ProductId]));
                    eQuoteCreate[Constants.Quote.ProductId] = entity[Constants.AISMessage.ProductId];
                }

                if (entity.Attributes.Contains(Constants.AISMessage.PLCode))
                {
                    tracingService.Trace(Constants.Quote.PL + "-" + Convert.ToString(entity[Constants.AISMessage.PLCode]));
                    eQuoteCreate[Constants.Quote.PL] = entity[Constants.AISMessage.PLCode];
                }

                if (entity.Attributes.Contains(Constants.AISMessage.ClassOfBusiness))
                {
                    tracingService.Trace(Constants.Quote.ClassOfBusiness + "-" + Convert.ToString(entity[Constants.AISMessage.ClassOfBusiness]));
                    eQuoteCreate[Constants.Quote.ClassOfBusiness] = entity[Constants.AISMessage.ClassOfBusiness];
                }

                eQuoteCreate[Constants.Quote.QuoteSystem] = new OptionSetValue((int)Constants.Policy.Policy_System.AIS);
                tracingService.Trace(Constants.Quote.QuoteSystem + "-" + (int)Constants.Policy.Policy_System.AIS);

                if (entity.Attributes.Contains(Constants.AISMessage.PolicyNumber))
                {
                    ePolicy = this.GetPolicy();
                    if (ePolicy != null)
                        eQuoteCreate[Constants.Quote.ReletedPolicy] = new EntityReference(ePolicy.LogicalName, ePolicy.Id);
                }

                Guid gQuoteCreateId = service.Create(eQuoteCreate);
                if (gQuoteCreateId != Guid.Empty)
                {
                    eQuoteCreate.Id = gQuoteCreateId;
                    bHasPolicyProcessed = true;
                }

                pluginContext.LogMessage($"Quote: '{eQuoteCreate.Id}' has been created successfully.");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                pluginContext.ThrowException("Fault Exception Occured", ex);
            }
            catch (Exception ex) { exception = ex; }
            finally
            {
                if (exception != null)
                {
                    pluginContext.LogException(exception, "AISMessageLogic.CreateQuote");
                    // throw new InvalidPluginExecutionException(exception.Message);
                }
            }
            pluginContext.LogMessage("AISMessageLogic.CreateQuote- Unloaded");
            return eQuoteCreate;
        }

        /// <summary>
        /// This method does update Quote record.
        /// </summary>
        /// <param name="eQuote"></param>
        /// <param name="bHasPolicyProcessed"></param>
        /// <returns></returns>
        private Entity UpdateQuote(Entity eQuote, out bool bHasQuoteProcessed)
        {
            pluginContext.LogMessage("AISMessageLogic.UpdateQuote- Loaded");
            Exception exception = null;
            string sQuoteNumber = string.Empty;
            bHasQuoteProcessed = false;
            Entity eQuoteUpdate = null;

            try
            {
                if (entity.Attributes.Contains(Constants.AISMessage.QuoteNumber))
                    sQuoteNumber = Convert.ToString(entity[Constants.AISMessage.QuoteNumber]);

                eQuoteUpdate = new Entity(eQuote.LogicalName);
                eQuoteUpdate.Id = eQuote.Id;

                eQuoteUpdate[Constants.Quote.Name] = sQuoteNumber;

                if (entity.Attributes.Contains(Constants.AISMessage.Scheme))
                    eQuoteUpdate[Constants.Quote.SchemeId] = Convert.ToString(entity[Constants.AISMessage.Scheme]);

                if (entity.Attributes.Contains(Constants.AISMessage.Broker))
                {
                    eQuoteUpdate[Constants.Quote.Brokerid] = entity[Constants.AISMessage.Broker];
                    bDoesBrokerExist = true;
                }
                if (erCustomer != null)
                    eQuoteUpdate[Constants.Quote.Customer] = entity[Constants.AISMessage.Customer];


                if (entity.Attributes.Contains(Constants.AISMessage.AnnualPremiumIncludingTaxes))
                    eQuoteUpdate[Constants.Quote.AnnualPremiumincludingTaxes] = entity[Constants.AISMessage.AnnualPremiumIncludingTaxes];

                if (entity.Attributes.Contains(Constants.AISMessage.AnnualRevisedPremium))
                    eQuoteUpdate[Constants.Quote.AnnualRevisedPremium] = entity[Constants.AISMessage.AnnualRevisedPremium];

                if (entity.Attributes.Contains(Constants.AISMessage.RevisedPremium))
                    eQuoteUpdate[Constants.Quote.RevisedPremium] = entity[Constants.AISMessage.RevisedPremium];

                if (entity.Attributes.Contains(Constants.AISMessage.TransactionalPremiumIncludingTaxes))
                    eQuoteUpdate[Constants.Quote.TransactionalPremiumincludingtaxes] = entity[Constants.AISMessage.TransactionalPremiumIncludingTaxes];

                if (entity.Attributes.Contains(Constants.AISMessage.TransactionalRevisedPremium))
                    eQuoteUpdate[Constants.Quote.TransactionalRevisedPremium] = entity[Constants.AISMessage.TransactionalRevisedPremium];

                if (entity.Attributes.Contains(Constants.AISMessage.Premium))
                    eQuoteUpdate[Constants.Quote.Premium] = entity[Constants.AISMessage.Premium];

                if (entity.Attributes.Contains(Constants.AISMessage.QuoteExpirationDate))
                    eQuoteUpdate[Constants.Quote.QuoteExpirationDate] = entity[Constants.AISMessage.QuoteExpirationDate];

                if (entity.Attributes.Contains(Constants.AISMessage.ReasonForDivertDeclinePL))
                    eQuoteUpdate[Constants.Quote.ReasonforDivertDecline] = entity[Constants.AISMessage.ReasonForDivertDeclinePL];

                if (entity.Attributes.Contains(Constants.AISMessage.SchemeDescription))
                    eQuoteUpdate[Constants.Quote.SchemeDescription] = Convert.ToString(entity[Constants.AISMessage.SchemeDescription]);

                if (entity.Attributes.Contains(Constants.AISMessage.AgentName))
                    eQuoteUpdate[Constants.Quote.AgentName] = Convert.ToString(entity[Constants.AISMessage.AgentName]);

                if (entity.Attributes.Contains(Constants.AISMessage.AgentCode))
                    eQuoteUpdate[Constants.Quote.AgentCode] = Convert.ToString(entity[Constants.AISMessage.AgentCode]);

                if (entity.Attributes.Contains(Constants.AISMessage.PrimaryReference))
                    eQuoteUpdate[Constants.Quote.PrimaryReference] = Convert.ToString(entity[Constants.AISMessage.PrimaryReference]);

                var statusOptionsetRoot = new PQStatusJSON();
                statusOptionsetRoot = getPolicyQuoteStatusJsonValues("PolicyQuoteStatus_AISMessage");

                PolicyQuoteStatusMapping policyQuoteStatusMap = new PolicyQuoteStatusMapping();

                if (statusOptionsetRoot.PolicyQuoteStatusMapping != null && entity.Attributes.Contains(Constants.AISMessage.QuotePolicyStatusPL))
                {
                    tracingService.Trace("Inside if - policyQuoteStatusMap Quote Status");
                    policyQuoteStatusMap = (PolicyQuoteStatusMapping)statusOptionsetRoot.PolicyQuoteStatusMapping.FirstOrDefault(a => a.AISStatus.Equals(entity.GetAttributeValue<OptionSetValue>(Constants.AISMessage.QuotePolicyStatusPL).Value));
                    tracingService.Trace("policyQuoteStatusMap Quote Status" + policyQuoteStatusMap.ToString());

                    eQuoteUpdate[Constants.Quote.QuotePolicyStatus] = new OptionSetValue((int)policyQuoteStatusMap.QuoteStatus);
                }
                //eQuoteUpdate[Constants.Quote.QuotePolicyStatus] = entity[Constants.AISMessage.QuotePolicyStatusPL];

                if (entity.Attributes.Contains(Constants.AISMessage.QuotePolicyVersion))
                    eQuoteUpdate[Constants.Quote.QuotePolicyVersion] = Convert.ToString(entity[Constants.AISMessage.QuotePolicyVersion]);

                if (entity.Attributes.Contains(Constants.AISMessage.CodeToRelatedQuotesPolicies))
                    eQuoteUpdate[Constants.Quote.CodetorelateQuotesPolicies] = Convert.ToString(entity[Constants.AISMessage.CodeToRelatedQuotesPolicies]);

                if (entity.Attributes.Contains(Constants.AISMessage.PolicyRenewalDate))
                    eQuoteUpdate[Constants.Quote.PolicyRenewalDate] = entity[Constants.AISMessage.PolicyRenewalDate];

                if (entity.Attributes.Contains(Constants.AISMessage.PolicyMovementReasonId))
                    eQuoteUpdate[Constants.Quote.PolicyMovementReasonId] = entity[Constants.AISMessage.PolicyMovementReasonId];

                if (entity.Attributes.Contains(Constants.AISMessage.PolicyMovementTypeLKP))
                    eQuoteUpdate[Constants.Quote.PolicyMovementType] = entity[Constants.AISMessage.PolicyMovementTypeLKP];

                if (entity.Attributes.Contains(Constants.AISMessage.EffectiveDate))
                    eQuoteUpdate[Constants.Quote.EffectiveDate] = entity[Constants.AISMessage.EffectiveDate];

                if (entity.Attributes.Contains(Constants.AISMessage.InceptionDate))
                    eQuoteUpdate[Constants.Quote.InceptionDate] = entity[Constants.AISMessage.InceptionDate];

                //if (entity.Attributes.Contains(Constants.AISMessage.RenewalIndicator))
                //eQuoteUpdate[Constants.Quote.RenewalIndicator] = entity[Constants.AISMessage.RenewalIndicator].ToString();

                var rosOptionsetRoot = new RouteOfSaleJSON();
                rosOptionsetRoot = getRouteOfSaleJsonValues("RouteofSale_AISMessage");

                RouteOfSaleMapping rosMap = new RouteOfSaleMapping();

                if (rosOptionsetRoot.RouteOfSaleMapping != null && entity.Attributes.Contains(Constants.AISMessage.RouteOfSale))
                {
                    rosMap = (RouteOfSaleMapping)rosOptionsetRoot.RouteOfSaleMapping.Find(a => a.AISROS.Equals(entity.GetAttributeValue<OptionSetValue>(Constants.AISMessage.RouteOfSale).Value));
                    tracingService.Trace("RouteOfSaleMapping Quote Status" + rosMap.ToString());

                    eQuoteUpdate[Constants.Quote.RouteOfsale] = new OptionSetValue((int)rosMap.QuoteROS);
                }
                //eQuoteUpdate[Constants.Quote.RouteOfsale] = entity[Constants.AISMessage.RouteOfSale];

                if (entity.Attributes.Contains(Constants.AISMessage.ProductCode))
                    eQuoteUpdate[Constants.Quote.ProductCode] = Convert.ToString(entity[Constants.AISMessage.ProductCode]);

                if (entity.Attributes.Contains(Constants.AISMessage.ProductName))
                    eQuoteUpdate[Constants.Quote.ProductName] = Convert.ToString(entity[Constants.AISMessage.ProductName]);

                if (entity.Attributes.Contains(Constants.AISMessage.ProductId))
                    eQuoteUpdate[Constants.Quote.ProductId] = entity[Constants.AISMessage.ProductId];

                if (entity.Attributes.Contains(Constants.AISMessage.PLCode))
                    eQuoteUpdate[Constants.Quote.PL] = entity[Constants.AISMessage.PLCode];

                if (entity.Attributes.Contains(Constants.AISMessage.ClassOfBusiness))
                    eQuoteUpdate[Constants.Quote.ClassOfBusiness] = entity[Constants.AISMessage.ClassOfBusiness];

                eQuoteUpdate[Constants.Quote.QuoteSystem] = new OptionSetValue((int)Constants.Policy.Policy_System.AIS);

                if (entity.Attributes.Contains(Constants.AISMessage.PolicyNumber))
                {
                    ePolicy = this.GetPolicy();
                    if (ePolicy != null)
                        eQuoteUpdate[Constants.Quote.ReletedPolicy] = new EntityReference(ePolicy.LogicalName, ePolicy.Id);
                }
                service.Update(eQuoteUpdate);
                //if (eQuoteUpdate.Id != Guid.Empty)
                bHasQuoteProcessed = true;

                pluginContext.LogMessage($"Quote No. '{sQuoteNumber}' has been updated successfully.");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                pluginContext.ThrowException("Fault Exception Occured", ex);
            }
            catch (Exception ex) { exception = ex; }
            finally
            {
                if (exception != null)
                {
                    pluginContext.LogException(exception, "AISMessageLogic.UpdateQuote");
                    // throw new InvalidPluginExecutionException(exception.Message);
                }
            }
            pluginContext.LogMessage("AISMessageLogic.UpdateQuote- Unloaded");
            return eQuoteUpdate;
        }

        private RouteOfSaleJSON getRouteOfSaleJsonValues(string strCustomLabel)
        {
            tracingService.Trace("getRouteOfSaleJsonValues - Loaded");
            var rosOptionsetRoot = new RouteOfSaleJSON();

            string dependentOptionset = string.Empty;

            QueryExpression ROSExpression = new QueryExpression("rsa_customlabel");
            ROSExpression.TopCount = 1;
            ROSExpression.NoLock = true;
            ROSExpression.ColumnSet = new ColumnSet(new string[] { "rsa_dependentoptionsetjson" });
            ROSExpression.Criteria = new FilterExpression();
            ROSExpression.Criteria.AddCondition("rsa_name", ConditionOperator.Equal, strCustomLabel);
            EntityCollection rosCustomLabel = service.RetrieveMultiple(ROSExpression);
            if (rosCustomLabel != null && rosCustomLabel.Entities.Count > 0)
            {
                tracingService.Trace("rosCustomLabel != null && rosCustomLabel.Entities.Count > 0");

                if (rosCustomLabel.Entities[0].Contains("rsa_dependentoptionsetjson")
                    && !string.IsNullOrEmpty(rosCustomLabel.Entities[0]["rsa_dependentoptionsetjson"].ToString()))
                {
                    dependentOptionset = rosCustomLabel.Entities[0]["rsa_dependentoptionsetjson"].ToString();
                    tracingService.Trace("Optionset Mapping retrieved: Route of Sale Optionset");

                    //var ms = new MemoryStream(Encoding.UTF8.GetBytes(dependentOptionset));
                    //var ser = new DataContractJsonSerializer(rosOptionsetRoot.GetType());
                    //rosOptionsetRoot = ser.ReadObject(ms) as RouteOfSaleJSON;
                    //ms.Close();
                    //Remediation - 20/07/2022
                    var ms = new MemoryStream(Encoding.UTF8.GetBytes(dependentOptionset));
                    try
                    {
                        var ser = new DataContractJsonSerializer(rosOptionsetRoot.GetType());
                        rosOptionsetRoot = ser.ReadObject(ms) as RouteOfSaleJSON;
                    }
                    catch (Exception ex)
                    {
                        throw new InvalidPluginExecutionException(ex.Message);
                    }
                    finally
                    {
                        ms.Close();
                    }
                }
            }
            else
            {
                tracingService.Trace("rosCustomLabel == null || rosCustomLabel.Entities.Count < 1");
            }
            tracingService.Trace("getRouteOfSaleJsonValues - Unloaded");
            return rosOptionsetRoot;
        }

        private PQStatusJSON getPolicyQuoteStatusJsonValues(string strCustomLabel)
        {
            tracingService.Trace("getPolicyQuoteStatusJsonValues - Loaded");
            var statusOptionsetRoot = new PQStatusJSON();

            string dependentOptionset = string.Empty;

            QueryExpression StatusExpression = new QueryExpression("rsa_customlabel");
            StatusExpression.TopCount = 1;
            StatusExpression.NoLock = true;
            StatusExpression.ColumnSet = new ColumnSet(new string[] { "rsa_dependentoptionsetjson" });
            StatusExpression.Criteria = new FilterExpression();
            StatusExpression.Criteria.AddCondition("rsa_name", ConditionOperator.Equal, strCustomLabel);
            EntityCollection rosCustomLabel = service.RetrieveMultiple(StatusExpression);

            if (rosCustomLabel != null && rosCustomLabel.Entities.Count > 0)
            {
                tracingService.Trace("rosCustomLabel != null && rosCustomLabel.Entities.Count > 0");

                if (rosCustomLabel.Entities[0].Contains("rsa_dependentoptionsetjson")
                    && !string.IsNullOrEmpty(rosCustomLabel.Entities[0]["rsa_dependentoptionsetjson"].ToString()))
                {
                    tracingService.Trace("Optionset Mapping retrieved: PolicyQuote Status Optionset");
                    dependentOptionset = rosCustomLabel.Entities[0]["rsa_dependentoptionsetjson"].ToString();
                    //var ms = new MemoryStream(Encoding.UTF8.GetBytes(dependentOptionset));
                    //var ser = new DataContractJsonSerializer(statusOptionsetRoot.GetType());
                    //statusOptionsetRoot = ser.ReadObject(ms) as PQStatusJSON;
                    //ms.Close();
                    //Remediation - 20/07/2022
                    var ms = new MemoryStream(Encoding.UTF8.GetBytes(dependentOptionset));
                    try
                    {
                        var ser = new DataContractJsonSerializer(statusOptionsetRoot.GetType());
                        statusOptionsetRoot = ser.ReadObject(ms) as PQStatusJSON;
                    }
                    catch (Exception ex)
                    {
                        throw new InvalidPluginExecutionException(ex.Message);
                    }
                    finally
                    {
                        ms.Close();
                    }
                }

            }

            tracingService.Trace("getPolicyQuoteStatusJsonValues - Unloaded");
            return statusOptionsetRoot;

        }
        /// <summary>
        /// This method does update 'Message Status' field value on AIS Message record.
        /// </summary>
        /// <param name="iStatusValue">Message Status value</param>
        private void UpdateAISMessageStatus(int iStatusValue, string erroMessage = null)
        {
            pluginContext.LogMessage("AISMessageLogic.UpdateAISMessageStatus- Loaded");
            Exception exception = null;
            try
            {
                Entity entityUpdate = new Entity(entity.LogicalName);
                entityUpdate.Id = entity.Id;
                if (erBroker != null)
                    entityUpdate[Constants.AISMessage.Broker] = erBroker;
                if (eCustomer != null)
                {
                    tracingService.Trace("eCustomer has data " + eCustomer);
                    entityUpdate[Constants.AISMessage.Customer] = new EntityReference(eCustomer.LogicalName, eCustomer.Id);
                }
                if (!string.IsNullOrEmpty(erroMessage))
                    entityUpdate[Constants.AISMessage.ErrorDescription] = erroMessage;
                entityUpdate[Constants.AISMessage.MessageStatus] = new OptionSetValue(iStatusValue);
                service.Update(entityUpdate);
                pluginContext.LogMessage($"Updated AIS Message:'{entity.Id}' status to '{iStatusValue}'");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                pluginContext.ThrowException("Fault Exception Occured", ex);
            }
            catch (Exception ex) { exception = ex; }
            finally
            {
                if (exception != null)
                {
                    pluginContext.LogException(exception, "AISMessageLogic.UpdateAISMessageStatus");
                    //  throw new InvalidPluginExecutionException(exception.Message);
                }
            }
            pluginContext.LogMessage("AISMessageLogic.UpdateAISMessageStatus- Unloaded");
        }

        /// <summary>
        /// This method does update 'Message Status' field value on AIS Message record.
        /// </summary>
        /// <param name="aisMessageId"></param>
        /// <param name="iStatusValue"></param>
        /// <param name="erroMessage"></param>
        private void UpdateAISMessageStatus(Guid aisMessageId, int iStatusValue, string erroMessage = null)
        {
            pluginContext.LogMessage("AISMessageLogic.UpdateAISMessageStatus- Loaded");
            Exception exception = null;
            try
            {
                Entity entityUpdate = new Entity(Constants.AISMessage.EntityName);

                entityUpdate.Id = aisMessageId;
                if (!string.IsNullOrEmpty(erroMessage))
                    entityUpdate[Constants.AISMessage.ErrorDescription] = erroMessage;
                entityUpdate[Constants.AISMessage.MessageStatus] = new OptionSetValue(iStatusValue);
                service.Update(entityUpdate);
                pluginContext.LogMessage($"Updated AIS Message:'{entity.Id}' status to '{iStatusValue}'");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                pluginContext.ThrowException("Fault Exception Occured", ex);
            }
            catch (Exception ex) { exception = ex; }
            finally
            {
                if (exception != null)
                {
                    pluginContext.LogException(exception, "AISMessageLogic.UpdateAISMessageStatus");
                    // throw new InvalidPluginExecutionException(exception.Message);
                }
            }
            pluginContext.LogMessage("AISMessageLogic.UpdateAISMessageStatus- Unloaded");
        }


        /// <summary>
        /// GetCustomLabel
        /// </summary>
        /// <param name="sKeyName"></param>
        /// <returns></returns>
        private EntityCollection GetCustomLabel(object[] sKeyName)
        {
            pluginContext.LogMessage("AISMessageLogic.ProcessPolicyAISMessage- Loaded.");
            Exception exception = null;
            string entityName = string.Empty; int topCount;
            ColumnSet column = null; OrderExpression order = null;
            EntityCollection ecRSACustomLabels = null; FilterExpression filterExpression = null;
            try
            {
                topCount = 1; entityName = Constants.RSACustomLabel.EntityName;
                column = new ColumnSet(Constants.RSACustomLabel.Name, Constants.RSACustomLabel.Values, Constants.RSACustomLabel.ShortDescription, Constants.RSACustomLabel.Categories);
                order = new OrderExpression(Constants.RSACustomLabel.ModifiedOn, OrderType.Descending);
                filterExpression = new FilterExpression
                {
                    FilterOperator = LogicalOperator.And,
                    Conditions = { new ConditionExpression(Constants.RSACustomLabel.Name, ConditionOperator.In, sKeyName), },
                };
                ecRSACustomLabels = this.GetEntityCollection(entityName, filterExpression, order, column, topCount);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                pluginContext.ThrowException("Fault Exception Occured", ex);
            }
            catch (Exception ex) { exception = ex; }
            finally
            {
                if (exception != null)
                {
                    pluginContext.LogException(exception, "AISMessageLogic.GetCustomLabel");
                    //throw new InvalidPluginExecutionException(exception.Message);
                }
            }
            pluginContext.LogMessage("TaskManagementLogic=>GetCustomLabel()- Unloaded.");
            return ecRSACustomLabels;
        }

        ///<summary>
        ///Add to queue
        ///</summary> 
        private void AssignCaseToDefaultQueue(ITracingService tracingService, IOrganizationService service, string entityName, Guid caseId, Guid destinationQueueId)
        {
            tracingService.Trace("Entered RSA.CSI.Plugins.Opportuntiy=>AssignCaseToDefaultQueue() method.");
            var routeRequest = new AddToQueueRequest
            {
                Target = new EntityReference(entityName, caseId),
                DestinationQueueId = destinationQueueId
            };
            // Execute the Request
            service.Execute(routeRequest);
            tracingService.Trace("Exiting RSA.CSI.Plugins.Opportuntiy=>AssignCaseToDefaultQueue() method.");
        }
        /////<summary>Create Task for AIS Quote
        /////</summary>
        //private void SetQuoteTaskFields(IOrganizationService service, ITracingService tracer, string taskSubject, Guid activityWhatId, Guid activityOwner_ID, string activityStatus)
        //{
        //    try
        //    {
        //        tracer.Trace("Creating Task for AIS Quote");
        //        Entity entempTasks = new Entity("task");
        //        entempTasks["rsa_tasktype"] = new EntityReference("rsa_activitytype", this.GetLookUpDetailsbyText(service, "Renewal Work Up", "rsa_activitytype", Guid.Empty).Id);
        //        entempTasks["subject"] = taskSubject;
        //        tracer.Trace("Subject :{0}", taskSubject);
        //        entempTasks["regardingobjectid"] = new EntityReference("incident", activityWhatId);             
        //        entempTasks["ownerid"] = new EntityReference("systemuser", activityOwner_ID); 
        //        entempTasks["rsa_status"] = new OptionSetValue(866760000);
        //        entempTasks["rsa_taskstatus"] = new EntityReference("rsa_taskstatus", this.GetLookUpDetailsbyText(service, activityStatus, "rsa_taskstatus", Guid.Empty).Id);

        //        service.Create(entempTasks);
        //        tracer.Trace("AIS quote task Created");

        //    }
        //    catch (Exception ex)
        //    {
        //        tracer.Trace("SetQuoteTaskFields-Error" + ex.Message.ToString());
        //        throw new InvalidPluginExecutionException(ex.Message);
        //    }
        //}

        /////<summary> Retrive Id by Name
        /////</summary>
        //private Entity GetLookUpDetailsbyText(IOrganizationService service, string pName, string entityName, Guid lob)
        //{
        //    try
        //    {
        //        var entity = new Entity(entityName);
        //        string fetchQuery = "<fetch mapping = 'logical'>";
        //        fetchQuery += "<entity name = '" + entityName + "'>";
        //        fetchQuery += "<attribute name='rsa_name' />";
        //        fetchQuery += "<filter type = 'and'>";
        //        fetchQuery += "<condition attribute = 'rsa_name' operator= 'eq' value = '" + pName + "' />";
        //        if (lob != Guid.Empty)
        //            fetchQuery += "<condition attribute = 'rsa_lineofbusiness' operator= 'eq' value = '" + lob + "' />";
        //        fetchQuery += "</filter>";
        //        fetchQuery += "</entity>";
        //        fetchQuery += "</fetch>";
        //        EntityCollection lobDetails = service.RetrieveMultiple(new FetchExpression(fetchQuery));
        //        if (lobDetails.Entities.Count > 0)
        //        {
        //            foreach (var entities in lobDetails.Entities)
        //            {
        //                entity = entities;
        //            }
        //        }
        //        return entity;
        //    }
        //    catch (Exception)
        //    {
        //        throw;
        //    }
        //}


        #endregion Private Subs / Functions
    }



    [DataContract]
    public class RouteOfSaleMapping
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public int AISROS { get; set; }
        [DataMember]
        public int? PolicyROS { get; set; }
        [DataMember]
        public int? QuoteROS { get; set; }
    }

    [DataContract]
    public class RouteOfSaleJSON
    {
        [DataMember]
        public List<RouteOfSaleMapping> RouteOfSaleMapping { get; set; }
    }

    [DataContract]
    public class AISMessageStatusMapping
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public int AISStatus { get; set; }
        [DataMember]
        public int PolicyStatus { get; set; }
        [DataMember]
        public int QuoteStatus { get; set; }
    }

    [DataContract]
    public class StatusJSON
    {
        [DataMember]
        public List<AISMessageStatusMapping> AISMessageStatusMapping { get; set; }
    }

    [DataContract]
    public class PolicyQuoteStatusMapping
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public int AISStatus { get; set; }
        [DataMember]
        public int PolicyStatus { get; set; }
        [DataMember]
        public int QuoteStatus { get; set; }
    }

    [DataContract]
    public class PQStatusJSON
    {
        [DataMember]
        public List<PolicyQuoteStatusMapping> PolicyQuoteStatusMapping { get; set; }
    }
}
