﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSA.CSI.CustomWorkFlows
{
    public class CaseTATCalculation : CodeActivity
    {
        [RequiredArgument]
        [ReferenceTarget("incident")]
        [Input("case")]
        public InArgument<EntityReference> CaseEntity { get; set; }

        TimeSpan ts_DefaultStartTime = new TimeSpan(09, 00, 00);
        TimeSpan ts_DefaultEndTime = new TimeSpan(17, 00, 00);

        protected override void Execute(CodeActivityContext executionContext)
        {
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.InitiatingUserId);
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();

            EntityReference caseId = CaseEntity.Get<EntityReference>(executionContext);
            Entity enCase = new Entity(caseId.LogicalName);
            //var Case = service.Retrieve(caseId.LogicalName, caseId.Id, new ColumnSet("title", "rsa_casetat", "rsa_casereceiveddate", "rsa_datetimeclosed", "rsa_status"));
            var Case = service.Retrieve(caseId.LogicalName, caseId.Id, new ColumnSet("title", "rsa_casetatdec", "rsa_casereceiveddate", "rsa_datetimeclosed", "rsa_status"));
            var caseStatus = Case.GetAttributeValue<EntityReference>("rsa_status").Name;

            tracingService.Trace("Case Status : " + caseStatus);
            tracingService.Trace("Case ID : " + caseId.Id);

            try
            {
                if (CaseEntity != null)
                {
                    if (caseStatus == "Closed")
                    {
                        //Case TAT Calculation
                        DateTime startDate = Case.GetAttributeValue<DateTime>("rsa_casereceiveddate");
                        DateTime endDate = Case.GetAttributeValue<DateTime>("rsa_datetimeclosed");
                        // endDate = ListHoliday(service, tracingService, endDate);
                        int? userTimezone = RetrieveCurrentUsersSettings(service);
                        tracingService.Trace("userTimezone" + userTimezone);
                        DateTime startDatetime = RetrieveLocalTimeFromUTCTime(startDate.ToUniversalTime(), userTimezone, service);
                        DateTime endDateTime = RetrieveLocalTimeFromUTCTime(endDate.ToUniversalTime(), userTimezone, service);

                        tracingService.Trace("UK Start Date Time: " + startDatetime);
                        tracingService.Trace("UK End Date Time : " + endDateTime);

                        DateTime validStartDate = ValidateStartDateTime(startDatetime, service, tracingService);
                        DateTime validEndDate = ValidateEndDateTime(endDateTime, service, tracingService);

                        tracingService.Trace("Valid Start Date : " + validStartDate);
                        tracingService.Trace("Valid End Date : " + validEndDate);

                        var turnAroundTime = TatCalculation(validStartDate, validEndDate, service, tracingService);

                        tracingService.Trace("Case TAT is : " + turnAroundTime);
                        //enCase["rsa_casetat"] = turnAroundTime;                       
                        //if (turnAroundTime.Length <= 10)
                        //{
                        //    enCase["rsa_casetat"] = turnAroundTime;
                        //}
                        //else
                        //{
                        //    tracingService.Trace("Case TAT exceeds the length of 10 provided in the field ");
                        //}
                        enCase["rsa_casetatdec"] = decimal.Round(Convert.ToDecimal(turnAroundTime), 2);
                        enCase.Id = Case.Id;
                        service.Update(enCase);
                    }
                    else
                    {
                        tracingService.Trace("Case is not closed");
                    }

                }
                else
                {
                    tracingService.Trace("Case Entity is null");
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        public int? RetrieveCurrentUsersSettings(IOrganizationService service)
        {
            var currentUserSettings = service.RetrieveMultiple(

                new QueryExpression("usersettings")
                {
                    ColumnSet = new ColumnSet("timezonecode"),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("systemuserid", ConditionOperator.EqualUserId)
                        }
                    },
                    NoLock = true

                }).Entities[0].ToEntity<Entity>();

            //return time zone code
            return (int?)currentUserSettings.Attributes["timezonecode"];
        }

        public DateTime RetrieveLocalTimeFromUTCTime(DateTime utcTime, int? timeZoneCode, IOrganizationService service)
        {
            if (!timeZoneCode.HasValue)
                return DateTime.Now;
            var request = new LocalTimeFromUtcTimeRequest
            {
                TimeZoneCode = timeZoneCode.Value,
                UtcTime = utcTime.ToUniversalTime()
            };
            var response = (LocalTimeFromUtcTimeResponse)service.Execute(request);
            return response.LocalTime;
        }

        public DateTime ValidateStartDateTime(DateTime validStartDate, IOrganizationService service, ITracingService tracer)
        {
            // StartDate validation
            if (validStartDate.TimeOfDay < ts_DefaultStartTime)
            {
                validStartDate = new DateTime(validStartDate.Year, validStartDate.Month, validStartDate.Day, 9, 0, 0);
            }
            if (validStartDate.TimeOfDay > ts_DefaultEndTime)
            {
                validStartDate = new DateTime(validStartDate.Year, validStartDate.Month, validStartDate.Day, 9, 0, 0).AddDays(1);
            }
            if (validStartDate.DayOfWeek == DayOfWeek.Saturday)
            {
                validStartDate = new DateTime(validStartDate.Year, validStartDate.Month, validStartDate.Day, 9, 0, 0).AddDays(2);
            }
            if (validStartDate.DayOfWeek == DayOfWeek.Sunday)
            {
                validStartDate = new DateTime(validStartDate.Year, validStartDate.Month, validStartDate.Day, 9, 0, 0).AddDays(1);
            }

            return validStartDate;
        }

        public DateTime ValidateEndDateTime(DateTime validEndDate, IOrganizationService service, ITracingService tracer)
        {
            // EndDate validaion
            if (validEndDate.TimeOfDay < ts_DefaultStartTime)
            {
                validEndDate = new DateTime(validEndDate.Year, validEndDate.Month, validEndDate.Day, 17, 0, 0).AddDays(-1);
            }
            if (validEndDate.TimeOfDay > ts_DefaultEndTime)
            {
                validEndDate = new DateTime(validEndDate.Year, validEndDate.Month, validEndDate.Day, 17, 0, 0);
            }
            if (validEndDate.DayOfWeek == DayOfWeek.Saturday)
            {
                validEndDate = new DateTime(validEndDate.Year, validEndDate.Month, validEndDate.Day, 17, 0, 0).AddDays(-1);
            }
            if (validEndDate.DayOfWeek == DayOfWeek.Sunday)
            {
                validEndDate = new DateTime(validEndDate.Year, validEndDate.Month, validEndDate.Day, 17, 0, 0).AddDays(-2);
            }
            return validEndDate;
        }

        public int CountValiddays(DateTime sd, DateTime ed, IOrganizationService service, ITracingService tracer)
        {
            //int holidayCount = ListHoliday(service, tracer,sd, ed);
            int weekendDays = 0;
            int totalDays = (ed.Date - sd.Date).Days;

            for (DateTime date = sd; date.Date <= ed.Date; date = date.AddDays(1))
            {
                if ((date.DayOfWeek == DayOfWeek.Saturday) || (date.DayOfWeek == DayOfWeek.Sunday))
                {
                    weekendDays++;
                }

            }
            // exclude holiday
            //totalDays = totalDays - holidayCount;
            return (totalDays - weekendDays - 1);
        }

        public string TatCalculation(DateTime startDate, DateTime endDate, IOrganizationService service, ITracingService tracing)
        {

            string turnAroundTime = string.Empty;
            int holidayCount = ListHoliday(service, tracing, startDate, endDate);

            if (endDate < startDate)
            {
                //turnAroundTime = "00:00:00";
                turnAroundTime = "00.00";
            }
            else
            {
                if (endDate.Date == startDate.Date)
                {
                    tracing.Trace("endDate.Date == startDate.Date");
                    if (holidayCount > 0)
                    {
                        tracing.Trace("holidayCount > 0");
                        //turnAroundTime = "00:00:00";
                        turnAroundTime = "00.00";
                    }
                    else
                    {
                        tracing.Trace("holidayCount <= 0");
                        tracing.Trace("Time: " + endDate.TimeOfDay + "-" + startDate.TimeOfDay + "=" + (endDate.TimeOfDay - startDate.TimeOfDay));
                        TimeSpan time = endDate.TimeOfDay - startDate.TimeOfDay;
                        //turnAroundTime = time.Hours + ":" + time.Minutes + ":" + time.Seconds;
                        turnAroundTime = Convert.ToString(time.TotalHours);
                    }
                }
                else
                {
                    var validDays = CountValiddays(startDate, endDate, service, tracing);
                    tracing.Trace("Valid days : " + validDays);
                    tracing.Trace("Time 1 " + ts_DefaultEndTime + " - " + startDate.TimeOfDay + " = " + (ts_DefaultEndTime - startDate.TimeOfDay));
                    tracing.Trace("Time 2 " + endDate.TimeOfDay + " - " + ts_DefaultStartTime + " = " + (endDate.TimeOfDay - ts_DefaultStartTime));

                    TimeSpan time = (ts_DefaultEndTime - startDate.TimeOfDay) + (endDate.TimeOfDay - ts_DefaultStartTime);
                    tracing.Trace("Time : " + time);

                    TimeSpan holidayTurnAroundTime = ListHolidayTime(service, tracing, startDate, endDate);
                    tracing.Trace("holidayTurnAroundTime : " + holidayTurnAroundTime);

                    tracing.Trace("holidayTurnAroundTime :" + holidayTurnAroundTime.Ticks);
                    // finalTime = time.Subtract(holidayTurnAroundTime);
                    int calHours = time.Hours + (8 * validDays);

                    tracing.Trace("calHours : " + calHours);
                    TimeSpan dtTimeSpan = new TimeSpan(calHours, time.Minutes, time.Seconds);
                    tracing.Trace("dtTimeSpan : " + dtTimeSpan);
                    tracing.Trace("dtTimeSpan : " + dtTimeSpan.Ticks);

                    tracing.Trace("TimeSpan.FromTicks(dtTimeSpan.Ticks - holidayTurnAroundTime.Ticks" + TimeSpan.FromTicks(dtTimeSpan.Ticks - holidayTurnAroundTime.Ticks));
                    TimeSpan finalTime = TimeSpan.FromTicks(dtTimeSpan.Ticks - holidayTurnAroundTime.Ticks);

                    tracing.Trace("Final Time : " + finalTime);
                    tracing.Trace("finalTime.TotalHours : " + finalTime.TotalHours);

                    //turnAroundTime = (Math.Floor(finalTime.TotalHours)) + ":" + finalTime.Minutes + ":" + finalTime.Seconds;
                    //tracing.Trace("turnAroundTime in min : " + turnAroundTime);
                    turnAroundTime = Convert.ToString(finalTime.TotalHours);
                    tracing.Trace("turnAroundTime : " + turnAroundTime);

                }
            }
            return turnAroundTime;
        }

        //TFS - 335
        public int ListHoliday(IOrganizationService service, ITracingService tracer, DateTime startDate, DateTime endDate)
        {
            try
            {
                tracer.Trace("holidayCount getting calculated");
                int holidayCount = 0;
                List<Entity> calendarRules = new List<Entity>();
                Entity businessClosureCalendar = null;
                QueryExpression holidayQuery = new QueryExpression("calendar") { NoLock = true };
                holidayQuery.Criteria.AddCondition("type", ConditionOperator.Equal, 2);
                EntityCollection businessClosureCalendars = service.RetrieveMultiple(holidayQuery);
                tracer.Trace("businessClosureCalendars.Entities.Count" + businessClosureCalendars.Entities.Count);
                if (businessClosureCalendars.Entities.Count > 0)
                {
                    businessClosureCalendar = businessClosureCalendars.Entities[0];

                    calendarRules = (businessClosureCalendar.GetAttributeValue<EntityCollection>("calendarrules")).Entities.ToList();
                    List<DateTime> holidays = calendarRules.Select(rule => rule.GetAttributeValue<DateTime>("starttime")).Where(date => date >= startDate.Date && date <= endDate.Date).ToList();
                    tracer.Trace("holidays" + holidays.Count());

                    holidayCount = holidays.Count();

                }
                return holidayCount;
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
        public TimeSpan ListHolidayTime(IOrganizationService service, ITracingService tracer, DateTime startDate, DateTime endDate)
        {
            try
            {
                int excludeDays = 0;
                string holidayturnAroundTime = string.Empty;
                int hrs = 0;
                int mins = 0;
                int secs = 0;
               
                TimeSpan ts = new TimeSpan();
                int? userTimezone = RetrieveCurrentUsersSettings(service);
                DateTime startDatetime = RetrieveLocalTimeFromUTCTime(startDate.ToUniversalTime(), userTimezone, service);
                DateTime endDateTime = RetrieveLocalTimeFromUTCTime(endDate.ToUniversalTime(), userTimezone, service);
                tracer.Trace("holidayCount getting calculated");
             
                List<Entity> calendarRules = new List<Entity>();
                Entity businessClosureCalendar = null;
                QueryExpression holidayQuery = new QueryExpression("calendar") { NoLock = true };
                holidayQuery.Criteria.AddCondition("type", ConditionOperator.Equal, 2);
                EntityCollection businessClosureCalendars = service.RetrieveMultiple(holidayQuery);
                tracer.Trace("businessClosureCalendars.Entities.Count" + businessClosureCalendars.Entities.Count);
                if (businessClosureCalendars.Entities.Count > 0)
                {
                    businessClosureCalendar = businessClosureCalendars.Entities[0];

                    calendarRules = (businessClosureCalendar.GetAttributeValue<EntityCollection>("calendarrules")).Entities.ToList();
                    List<DateTime> holidays = calendarRules.Select(rule => rule.GetAttributeValue<DateTime>("starttime")).Where(date => date >= startDate.Date && date <= endDate.Date).ToList();
                    tracer.Trace("holidays" + holidays.Count());

                    if (holidays.Count > 0)
                    {
                        if (holidays.Contains(startDate.Date))
                        {
                            tracer.Trace("holidays.Contains(startDate.Date)");
                            TimeSpan spanEnddt = ts_DefaultEndTime - startDate.TimeOfDay;
                            tracer.Trace("spanEnddt" + spanEnddt);
                            hrs = hrs + (spanEnddt.Hours);
                            tracer.Trace(" hrs = hrs + (spanEnddt.Hours)" + hrs);
                            mins = mins + (spanEnddt.Minutes);
                            tracer.Trace("mins = mins + (spanEnddt.Minutes)" + mins);

                            secs = secs + (spanEnddt.Seconds);
                            tracer.Trace("secs = secs + (spanEnddt.Seconds);" + secs);

                            excludeDays = excludeDays + 1;
                            tracer.Trace("excludeDays" + excludeDays);
                        }
                        if (holidays.Contains(endDate.Date))
                        {
                            TimeSpan spanEnddt = endDate.TimeOfDay - ts_DefaultStartTime;
                            tracer.Trace("spanEnddt" + spanEnddt);

                            hrs = hrs + (spanEnddt.Hours);
                            tracer.Trace(" hrs = hrs + (spanEnddt.Hours)" + hrs);

                            mins = mins + (spanEnddt.Minutes);
                            tracer.Trace("mins = mins + (spanEnddt.Minutes)" + mins);

                            secs = secs + (spanEnddt.Seconds);
                            tracer.Trace("secs = secs + (spanEnddt.Seconds);" + secs);

                            excludeDays = excludeDays + 1;
                            tracer.Trace("excludeDays" + excludeDays);

                        }
                    }
                    if (hrs > 0 || mins > 0 || secs > 0)
                    {
                        hrs = hrs + (holidays.Count - excludeDays) * 8;
                        tracer.Trace("  hrs = hrs + (holidays.Count - excludeDays) * 8" + hrs);

                        TimeSpan hhrsAddd = new TimeSpan(hrs, mins, secs);
                        ts = ts.Add(hhrsAddd);
                        tracer.Trace(" ts" + ts);
                    }
                    else
                    {   
                        hrs = holidays.Count * 8;
                        tracer.Trace(" hrs = holidays.Count * 8 " + hrs);

                        TimeSpan hhrsAddd = new TimeSpan(hrs, mins, secs);
                        ts = ts.Add(hhrsAddd);
                        tracer.Trace(" ts" + ts);

                    }

                }
                return ts;
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

    }
}
