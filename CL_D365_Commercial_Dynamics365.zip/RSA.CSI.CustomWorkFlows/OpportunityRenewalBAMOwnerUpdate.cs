﻿using Microsoft.Xrm.Sdk;
using System;
using System.ServiceModel;
using System.Activities;
using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;

namespace RSA.CSI.CustomWorkFlows
{
    public class OpportunityRenewalBAMOwnerUpdate : CodeActivity
    {
        #region Input Parameters
        [RequiredArgument]
        [ReferenceTarget("opportunity")]
        [Input("opportunity")]

        public InArgument<EntityReference> entity { get; set; }

        [ReferenceTarget("rsa_policy")]
        [Input("Policy")]
        public InArgument<EntityReference> policyEntity { get; set; }

        #endregion


        protected override void Execute(CodeActivityContext _executionContext)
        {
            IWorkflowContext _context = _executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = _executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService _service = serviceFactory.CreateOrganizationService(_context.InitiatingUserId);

            ITracingService _tracingService = _executionContext.GetExtension<ITracingService>();
            EntityReference Policy = null;
            Entity enPolicy = null;
            if (policyEntity != null)
            {
                _tracingService.Trace("Get Policy ID");
                Policy = policyEntity.Get<EntityReference>(_executionContext);
                enPolicy = _service.Retrieve(Policy.LogicalName, Policy.Id, new ColumnSet("rsa_plcode", "rsa_classofbusiness", "rsa_broker", "rsa_tradinghandlingsite"));
            }
            if (entity != null)
            {
                _tracingService.Trace("Retrived Opportunity Entity");
                // _tracingService.Trace("TaskManagementLogic=>CascadeTaskInfoToCase - eNTITYid of case" + entity.Id);
                EntityReference enOpportunity = entity.Get<EntityReference>(_executionContext);
                var Opportunity = _service.Retrieve(enOpportunity.LogicalName, enOpportunity.Id, new ColumnSet("rsa_closedate", "rsa_lineofbusiness"));
                Entity Oppo = new Entity(enOpportunity.LogicalName);
                if (enPolicy.Attributes.Contains("rsa_plcode") && ((EntityReference)enPolicy["rsa_plcode"]).Id != Guid.Empty
                        && enPolicy.Attributes.Contains("rsa_classofbusiness") && ((EntityReference)enPolicy["rsa_classofbusiness"]).Id != Guid.Empty
                        && enPolicy.Attributes.Contains("rsa_broker") && ((EntityReference)enPolicy["rsa_broker"]).Id != Guid.Empty)
                {
                    string plname = ((EntityReference)enPolicy["rsa_plcode"]).Name;
                    _tracingService.Trace("plname: " + plname);
                    string cobName = ((EntityReference)enPolicy["rsa_classofbusiness"]).Name;
                    _tracingService.Trace("cobName: " + cobName);
                    Guid brokerId = ((EntityReference)enPolicy["rsa_broker"]).Id;
                    _tracingService.Trace("brokerId: " + brokerId);

                    Guid BAMUser = this.getBAMUser(_service, _tracingService, plname, cobName, brokerId);
                    _tracingService.Trace("BAMUser: " + BAMUser);
                    if (BAMUser != Guid.Empty)
                    {
                        Oppo["rsa_bdaownerbam"] = new EntityReference("systemuser", BAMUser);
                        _tracingService.Trace("BAMUser is not empty ");
                    }
                    Guid opportunityOwnerId = Guid.Empty;
                    string policyRegion = string.Empty;
                    if (enPolicy.Attributes.Contains("rsa_tradinghandlingsite"))
                    {
                        policyRegion = Convert.ToString(enPolicy.FormattedValues["rsa_tradinghandlingsite"]);
                        _tracingService.Trace("policyRegion: " + policyRegion);
                    }
                    string lineofbusiness = string.Empty;
                    if (Opportunity.Attributes.Contains("rsa_lineofbusiness"))
                    {
                        lineofbusiness = Convert.ToString(((EntityReference)Opportunity.Attributes["rsa_lineofbusiness"]).Name);
                        _tracingService.Trace("lineofbusiness: " + lineofbusiness);
                    }
                    //strPolicyCOBName,LINE_OF_BUSINESS_GSL_RENEWAL_MARINE_LONDON,policyRegion
                    opportunityOwnerId = GetOpportunityOwnerDetails(_service, _tracingService, policyRegion, lineofbusiness, cobName, "Marine Renewal Opportunity Onwer");
                    _tracingService.Trace("opportunityOwnerId: " + opportunityOwnerId);

                    if (!opportunityOwnerId.Equals(Guid.Empty) && lineofbusiness.ToLowerInvariant().Contains("marine"))
                    {
                        _tracingService.Trace("Updating Marine owner");
                        Oppo["ownerid"] = new EntityReference("systemuser", opportunityOwnerId);
                    }
                    else
                    {
                        _tracingService.Trace("calling getuser function");
                        Entity enUser = getUser("Unassigned", _service);
                        _tracingService.Trace("Record reterieved " + enUser);
                        _tracingService.Trace("Record reterieved " + enUser.Id);
                        Guid userid = enUser.Id;
                        Oppo["ownerid"] = new EntityReference("systemuser", enUser.Id);
                        _tracingService.Trace("Updated unassigned - owner");
                    }
                    if (BAMUser != Guid.Empty && !lineofbusiness.ToLowerInvariant().Contains("marine"))
                    {
                        _tracingService.Trace("Updating Non-Marine owner");
                        Oppo["ownerid"] = new EntityReference("systemuser", BAMUser);
                    }
                    else
                    {
                        _tracingService.Trace("calling getuser function");
                        Entity enUser = getUser("Unassigned", _service);
                        _tracingService.Trace("Record reterieved " + enUser);
                        _tracingService.Trace("Record reterieved " + enUser.Id);
                        Guid userid = enUser.Id;
                        Oppo["ownerid"] = new EntityReference("systemuser", enUser.Id);
                        _tracingService.Trace("Updated unassigned - owner");
                    }

                }
                Oppo.Id = enOpportunity.Id;
                _service.Update(Oppo);
            }
            _tracingService.Trace("parent case has been updated.");
        }

        public Guid getBAMUser(IOrganizationService service, ITracingService tracingService, string plname, string cobName, Guid brokerId)
        {
            Guid userGuid = Guid.Empty;
            string BDMrole = string.Empty;
            var fetchXml = @"<fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>
                                <entity name='rsa_salesteamroles'>
                                <attribute name='rsa_salesteamrolesid'/>
                                <attribute name='rsa_name'/>
                                <attribute name='createdon'/>
                                <attribute name='rsa_salesmanagerrolename'/>
                                <attribute name='rsa_pl'/>
                                <attribute name='rsa_classofbusiness'/>
                                <attribute name='rsa_bdmrolename'/>
                                <order descending='false' attribute='rsa_name'/>
                                <link-entity name='rsa_pl' alias='aa' link-type='inner' to='rsa_pl' from='rsa_plid'>
                                <filter type='and'>
                                <condition attribute='rsa_name' value='{0}' operator='eq'/>
                                </filter>
                                </link-entity>
                                <link-entity name='rsa_classofbusiness' alias='ab' link-type='inner' to='rsa_classofbusiness' from='rsa_classofbusinessid'>
                                <filter type='and'>
                                <condition attribute='rsa_name' value='{1}' operator='eq'/>
                                </filter>
                                </link-entity>
                                </entity>
                                </fetch>";

            try
            {
                var enOwnerDetails = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, plname, cobName)));
                if (enOwnerDetails != null && enOwnerDetails.Entities.Count > 0)
                {
                    tracingService.Trace("BDMrole fetching");
                    BDMrole = enOwnerDetails[0].Attributes.Contains("rsa_bdmrolename") ? Convert.ToString(enOwnerDetails[0].Attributes["rsa_bdmrolename"]) : string.Empty;
                    tracingService.Trace("BDMrole:" + BDMrole);
                    if (BDMrole != string.Empty)
                    {
                        var fetchXmlBAMUser = @"<fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>
                                                    <entity name='connection'>
                                                    <attribute name='record2id'/>
                                                    <attribute name='record2roleid'/>
                                                    <attribute name='connectionid'/>
                                                    <order descending='false' attribute='record2id'/>
                                                    <filter type='and'>
                                                    <condition attribute='record1id' value='{0}' uitype='account' operator='eq'/>
                                                    </filter>
                                                    <link-entity name='connectionrole' alias='ae' link-type='inner' to='record2roleid' from='connectionroleid'>
                                                    <filter type='and'>
                                                    <condition attribute='name' value='{1}' operator='eq'/>
                                                    </filter>
                                                    </link-entity>
                                                    </entity>
                                                    </fetch>";

                        try
                        {
                            var BAMUserDetails = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXmlBAMUser, brokerId, BDMrole)));
                            if (BAMUserDetails != null && BAMUserDetails.Entities.Count > 0)
                            {
                                userGuid = BAMUserDetails[0].Attributes.Contains("record2id") ? ((EntityReference)BAMUserDetails[0].Attributes["record2id"]).Id : Guid.Empty;
                                tracingService.Trace("userGuid:" + userGuid.ToString());
                            }
                        }
                        catch (Exception ex)
                        {
                            tracingService.Trace("Exception while fetching BAMUserDetails in getBAMUser:" + ex.Message);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetching enOwnerDetails in getBAMUser:" + ex.Message);
            }
            return userGuid;
        }

        public Guid GetOpportunityOwnerDetails(IOrganizationService service, ITracingService tracingService, string region, string recordtypename, string class_of_business, string customName)
        {
            Guid userGuid = Guid.Empty;
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' no-lock='true'>
                    <entity name='rsa_customsetting'>
                        <attribute name='rsa_region' />
                            <attribute name = 'rsa_recordtypename' />
                            <attribute name='rsa_opportunityownerid' />
                            <attribute name='rsa_class_of_business' /> 
							<attribute name='rsa_user' /> 							
                        <filter type='and'>
							<condition attribute='rsa_region' value='{0}' operator='eq'/>
							<condition attribute='rsa_recordtypename' value='{1}' operator='eq'/>
							<condition attribute='rsa_class_of_business' value='{2}' operator='eq'/>
							<condition attribute = 'rsa_customsettingtypename' operator= 'like' value='{3}%' />
							</filter>                 
                    </entity>
                </fetch>";
            try
            {
                var enOwnerDetails = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, region, recordtypename, class_of_business, customName)));
                if (enOwnerDetails != null && enOwnerDetails.Entities.Count > 0)
                {
                    userGuid = enOwnerDetails[0].Attributes.Contains("rsa_user") ? ((EntityReference)enOwnerDetails[0].Attributes["rsa_user"]).Id : Guid.Empty;
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetching OpportunityOwnerDetails in GetOpportunityOwnerDetails:" + ex.Message);
            }
            return userGuid;
        }
        public Entity getUser(string name, IOrganizationService service)
        {
            try
            {
                var recordName = new Entity();
                QueryExpression query = new QueryExpression("systemuser");
                query.ColumnSet = new ColumnSet(new string[] { "firstname" });

                query.Criteria.AddCondition("firstname", ConditionOperator.Equal, name);
                query.NoLock = true;
                EntityCollection businessRecordTypes = service.RetrieveMultiple(query);
                if (businessRecordTypes != null && businessRecordTypes.Entities.Count > 0)
                {
                    recordName = businessRecordTypes.Entities[0];
                }
                return recordName;
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

    }

}
