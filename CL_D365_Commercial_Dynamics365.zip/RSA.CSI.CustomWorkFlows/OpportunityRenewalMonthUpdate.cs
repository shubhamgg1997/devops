﻿using Microsoft.Xrm.Sdk;
using System;
using System.ServiceModel;
using System.Activities;
using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;

namespace RSA.CSI.CustomWorkFlows
{
  public  class OpportunityRenewalMonthUpdate : CodeActivity
    {
     
        [RequiredArgument]
        [ReferenceTarget("opportunity")]
        [Input("opportunity")]
        public InArgument<EntityReference> entity { get; set; }

        protected override void Execute(CodeActivityContext _executionContext)
        {
            IWorkflowContext _context = _executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = _executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService _service = serviceFactory.CreateOrganizationService(_context.InitiatingUserId);

            ITracingService _tracingService = _executionContext.GetExtension<ITracingService>();
 
            if (entity != null)
            {
                // _tracingService.Trace("TaskManagementLogic=>CascadeTaskInfoToCase - eNTITYid of case" + entity.Id);
                EntityReference RelatedId = entity.Get<EntityReference>(_executionContext);
                var Opportunity = _service.Retrieve(RelatedId.LogicalName, RelatedId.Id, new ColumnSet("rsa_closedate"));

                if (Opportunity.Contains("rsa_closedate"))
                {
                    DateTime RenewalDate = Opportunity.GetAttributeValue<DateTime>("rsa_closedate");
                    int? Timezone = RetrieveCurrentUsersSettings(_service);
                    DateTime closeDate = RetrieveLocalTimeFromUTCTime(RenewalDate, Timezone, _service);
                    if (closeDate != DateTime.MinValue)
                    {
                        Entity Oppo = new Entity(RelatedId.LogicalName);
                        Oppo.Id = RelatedId.Id;
                        Oppo["rsa_opportunityrenewalmonth"] = closeDate.ToString("MMMM"); //bug 1862
                        _service.Update(Oppo);
                    }
                }                
            }
                _tracingService.Trace("parent case has been updated.");           
        }

        public int? RetrieveCurrentUsersSettings(IOrganizationService service)

        {

            var currentUserSettings = service.RetrieveMultiple(

                new QueryExpression("usersettings")

                {

                    ColumnSet = new ColumnSet("timezonecode"),

                    Criteria = new FilterExpression

                    {

                        Conditions =

                        {

                            new ConditionExpression("systemuserid", ConditionOperator.EqualUserId)

                        }

                    },
                    NoLock = true

                }).Entities[0].ToEntity<Entity>();

            //return time zone code

            return (int?)currentUserSettings.Attributes["timezonecode"];

        }


        ///

        ///  Retrive the local time from the UTC time.

        ///

        /// UTC Date time which needs to convert to Local DateTime

        /// TimeZoneCode

        /// IOrganizationService service

        ///

        public DateTime RetrieveLocalTimeFromUTCTime(DateTime utcTime, int? timeZoneCode, IOrganizationService service)

        {

            if (!timeZoneCode.HasValue)

                return DateTime.Now;

            var request = new LocalTimeFromUtcTimeRequest

            {

                TimeZoneCode = timeZoneCode.Value,

                UtcTime = utcTime.ToUniversalTime()

            };

            var response = (LocalTimeFromUtcTimeResponse)service.Execute(request);

            return response.LocalTime;

        }


    }

}
