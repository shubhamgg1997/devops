﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSA.CSI.CustomWorkFlows
{
    public class OpportunityLastYearPremium : CodeActivity
    {
        #region Input Parameters
        [RequiredArgument]
        [ReferenceTarget("rsa_policy")]
        [Input("Policy")]

        public InArgument<EntityReference> entity { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext _executionContext)
        {
            IWorkflowContext _context = _executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = _executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService _service = serviceFactory.CreateOrganizationService(_context.InitiatingUserId);

            ITracingService _tracingService = _executionContext.GetExtension<ITracingService>();

            if (entity != null)
            {
                _tracingService.Trace("Retrived policy Entity");

                EntityReference enPolicy = entity.Get<EntityReference>(_executionContext);
                GetRelatedOpportunity(_service, _tracingService, enPolicy.Id);

            }
        }

        public void GetRelatedOpportunity(IOrganizationService service, ITracingService tracingService, Guid policyId)
        {
            var fetchOpportunity = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' count='2'>
                                      <entity name='opportunity'>
                                        <attribute name='name' />
                                        <attribute name='opportunityid' />
                                        <attribute name='rsa_lineofbusiness' />
                                        <attribute name='createdon' />
                                        <attribute name='rsa_policyid' />
                                        <attribute name='rsa_expiringpremium' />
                                        <attribute name='rsa_rsaquotedpremium' />
                                        <order attribute='createdon' descending='true' />
                                        <filter type='and'>
                                          <condition attribute='rsa_policyid' operator='eq' uitype='rsa_policy' value='{0}' />
                                        </filter>
                                      </entity>
                                    </fetch>";
            try
            {
                var opptyDetails = service.RetrieveMultiple(new FetchExpression(String.Format(fetchOpportunity, policyId)));
                if (opptyDetails != null && opptyDetails.Entities.Count > 1)
                {
                    Entity enOpportunity = new Entity(opptyDetails.EntityName);
                    Money oppty1 = opptyDetails[1].Attributes.Contains("rsa_rsaquotedpremium") ? opptyDetails[1].GetAttributeValue<Money>("rsa_rsaquotedpremium") : new Money(0.00M);
                    Money oppty0 = opptyDetails[0].Attributes.Contains("rsa_expiringpremium") ? opptyDetails[0].GetAttributeValue<Money>("rsa_expiringpremium") : new Money(0.00M);

                    var opptyA1 = opptyDetails[1].Attributes.Contains("rsa_rsaquotedpremium") ? opptyDetails[1].GetAttributeValue<Money>("rsa_rsaquotedpremium").Value : 0.00M;
                    var opptyA0 = opptyDetails[0].Attributes.Contains("rsa_expiringpremium") ? opptyDetails[0].GetAttributeValue<Money>("rsa_expiringpremium").Value : 0.00M;

                    tracingService.Trace("Opportunity 0 :" + opptyA0);
                    tracingService.Trace("Opportunity 1 :" + opptyA1);

                    if (oppty0 != oppty1)
                    {
                        enOpportunity.Id = opptyDetails[0].Id;
                        enOpportunity["rsa_expiringpremium"] = opptyDetails[1].Attributes.Contains("rsa_rsaquotedpremium") ? opptyDetails[1].GetAttributeValue<Money>("rsa_rsaquotedpremium") : new Money(0.00M);
                        service.Update(enOpportunity);
                        tracingService.Trace("Updated Opportunity :" + enOpportunity.Id);
                    }
                    else
                    {
                        tracingService.Trace("Last Year's Premium has same value");
                    }
                }
                else
                {
                    tracingService.Trace("Opportunity Count is :" + opptyDetails.Entities.Count);
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetching:" + ex.Message);
            }
        }
          

        
    }
}
