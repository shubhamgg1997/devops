﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace RSA.CSI.CustomWorkFlows.Helper
{
    internal class Constants
    {
        //// Defect: 2098 : Atul Agrawal
        internal const string TRADE_CENTER_ISIE_OF_MAN = "866760010";
        internal const string COB_COMBINED = "Combined";
        internal const string COB_CONSTRUCTION = "Construction";
        internal const string COB_LIABILITY = "Liability";
        internal const string COB_MOTOR_FLEET = "Motor Fleet";
        internal const string COB_MOTOR_TRADE = "Motor Trade";
        internal const string COB_PROFIN_LONDON_AH = "ProFin London - A&H";
        internal const string COB_PROFIN_LONDDON_PI = "ProFin London - PI";
        internal const string COB_PROFIN_SCOTTISH_BOND = "ProFin - Scottish Bonds";
        internal const string COB_PROPERTY = "Property";
        internal const string COB_PROPERTY_OWNERS = "Property Owners";
        internal const string CASE_STATUS_TO_BE_QUOTED = "9398b842-f7e2-ea11-a816-000d3a64927d";
        internal const string CASE_STATUS_INITIAL_PROCESSING = "b396b842-f7e2-ea11-a816-000d3a64927d";
    }

    // Samiksha Dhakde - 01 July 2022
    // TFS-27 : Get Set for updated json for CaseRenewalStatus RSACustomlabel.
    public class NextStatus
    {
        [DataMember]
        public string StatusName { get; set; }
        [DataMember]
        public string StatusGUID { get; set; }
        [DataMember]
        public int StatusOrder { get; set; }

    }
    public class RenewalStatus
    {
        [DataMember]
        public string Classofbusiness { get; set; }
        [DataMember]
        public string CaseType { get; set; }
        [DataMember]
        public string DefaultStatusGUID { get; set; }
        [DataMember]
        public string DefaultStatus { get; set; }
        [DataMember]
        public List<NextStatus> NextStatus { get; set; }
    }
    // TFS27 Updation - End

    //public class RenewalStatus
    //{
    //    [DataMember]
    //    public string Classofbusiness { get; set; }
    //    [DataMember]
    //    public string CaseType { get; set; }
    //    [DataMember]
    //    public string StatusGUID { get; set; }
    //    [DataMember]
    //    public string Status { get; set; }
    //}

    //[DataContract]
    public class RSRootObject
    {
        [DataMember]
        public List<RenewalStatus> RenewalStatus { get; set; }
    }


}
