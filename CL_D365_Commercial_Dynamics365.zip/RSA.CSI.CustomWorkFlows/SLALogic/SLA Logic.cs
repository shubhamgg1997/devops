﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using Microsoft.Xrm.Sdk.Workflow;
namespace RSA.CSI.CustomWorkFlows     //entity= Case
{
    class SLA_Logic
    {
        public static DateTime GetABRTemplate(IWorkflowContext context, Entity entity, string name,IOrganizationService service, ITracingService tracer)
        {
            var ms = Stream.Null;
            try
            {
                DateTime endDate = DateTime.Now;
                Entity Case = entity;
                string caseTypeName = entity.GetAttributeValue<EntityReference>("rsa_casetype").Name;
                string ABRCondition = string.Empty;
                EntityReference OpportunityID = entity.Attributes.Contains("rsa_opportunityid") ? entity.GetAttributeValue<EntityReference>("rsa_opportunityid"):null;
                tracer.Trace("OpportunityID " + OpportunityID);
                string brokerPrimaryRef = string.Empty;
                bool dealBroker = false, dealBrokerApplicable = false;
                string productName = string.Empty;
                int reviewTypeCode = -1;
                tracer.Trace("Fetch the ABR Optionset Mapping from RSA Custom labels: ActivityBusinessRulesOptionset");

                //Sumegh Dhole : 16 Oct 2020 :  Retrieve Custom label for the getting the ABR multiselect optionset 
                QueryExpression ABRExpression = new QueryExpression("rsa_customlabel");
                ABRExpression.TopCount = 1;
                ABRExpression.NoLock = true;
                ABRExpression.ColumnSet = new ColumnSet(new string[] { "rsa_dependentoptionsetjson" });
                ABRExpression.Criteria = new FilterExpression();
                ABRExpression.Criteria.AddCondition("rsa_name", ConditionOperator.Equal, "ActivityBusinessRulesOptionset");
                EntityCollection abrCustomLabel = service.RetrieveMultiple(ABRExpression);

                string dependentOptionset = string.Empty;

                foreach (var item in abrCustomLabel.Entities)
                {
                    dependentOptionset = Convert.ToString(item.Attributes["rsa_dependentoptionsetjson"]);
                }

                tracer.Trace("Optionset Mapping retrieved: ActivityBusinessRulesOptionset");

                var abrOptionsetRoot = new ABROptionsetRoot();
                //var ms = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(dependentOptionset));
                //var ser = new DataContractJsonSerializer(abrOptionsetRoot.GetType());
                //abrOptionsetRoot = ser.ReadObject(ms) as ABROptionsetRoot;
                //ms.Close();
                //Remediation - 20/07/2022
                ms = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(dependentOptionset));
                var ser = new DataContractJsonSerializer(abrOptionsetRoot.GetType());
                abrOptionsetRoot = ser.ReadObject(ms) as ABROptionsetRoot;

                Incident objIncident = new Incident();
                tracer.Trace("Start building the fetch xml for activity business rules retrieval");

                string fetchQuery = "<fetch mapping = 'logical' distinct='true'>";
                fetchQuery += "<entity name = 'rsa_abrtask' >";
                fetchQuery += "<attribute name='rsa_name'/>";
                fetchQuery += "<attribute name='createdon'/>";
                fetchQuery += "<attribute name='rsa_subject'/>";
                fetchQuery += "<attribute name='rsa_pfactivitytype'/>";
                fetchQuery += "<attribute name='rsa_targetactivityrecordtype'/>";
                fetchQuery += "<attribute name='rsa_abrtaskid'/>";
                fetchQuery += "<attribute name='rsa_duedateunits'/>";
                fetchQuery += "<attribute name='rsa_duedateoffset'/>";
                fetchQuery += "<attribute name='rsa_duedatebasedon'/>";
                fetchQuery += "<attribute name='rsa_businesshourrequired'/>";
                fetchQuery += "<attribute name='rsa_businessdaysrequired'/>";
                fetchQuery += "<filter type = 'and' >";
                fetchQuery += "<condition attribute = 'statecode' value = '0' operator='eq'/>";
                fetchQuery += "<condition attribute = 'rsa_name' value = '" + name + "' operator = 'eq' />";
                fetchQuery += "</filter>";
                fetchQuery += "<link-entity name = 'rsa_activitybusinessrule' from = 'rsa_activitybusinessruleid' to = 'rsa_relatedto' link-type = 'inner' alias = 'ab'>";
               
               
               
                fetchQuery += "<filter type = 'and'>";




                ///Based on case type get the status value and process further.
                if (entity.Attributes.Contains("rsa_casetype"))
                {
                    string TriggerinObjectType = entity.GetAttributeValue<EntityReference>("rsa_casetype").Name;

                    #region commented
                    //EntityCollection statusVal = getStatusApplicable(tracer, entity.GetAttributeValue<EntityReference>("rsa_casetype").Id, service);//todo
                    //tracer.Trace("statusVal 66 : " + statusVal.Entities.Count);
                    //foreach (var status in statusVal.Entities)
                    //{
                    //    int statuscode = status.GetAttributeValue<int>("rsa_statuscode");
                    //    tracer.Trace("statuscode 69 : " + statuscode);
                    //    fetchQuery += "<condition attribute = 'rsa_status' operator='eq' value = '" + statuscode + "' />";






                    //    ABRCondition += "...." + "rsa_casetype  :" + objIncident.TriggerinObjectRecordType;
                    //    ABRMultiselect aBRTriggeringObjectType = abrOptionsetRoot.ABRMultiselect.Find(a => a.AttributeName.ToLower().Equals("rsa_triggeringobjectrecordtype"));
                    //    if (aBRTriggeringObjectType.Applicablevalues.Find(a => a.key.ToLower().Replace(" ", "").Equals(TriggerinObjectType.ToLower().Replace(" ", ""))) != null)
                    //    {
                    //        objIncident.TriggerinObjectRecordType = Convert.ToInt32(((Applicablevalue)aBRTriggeringObjectType.Applicablevalues.FirstOrDefault(a => a.key.ToLower().Replace(" ", "").Equals(TriggerinObjectType.ToLower().Replace(" ", "")))).Value);
                    //        tracer.Trace("TriggerinObjectRecordType ABR Optionset Map  " + objIncident.TriggerinObjectRecordType);

                    //        fetchQuery += "<condition attribute = 'rsa_triggeringobjectrecordtype' operator='contain-values'>";
                    //        fetchQuery += " <value>" + objIncident.TriggerinObjectRecordType + "</value>";
                    //        fetchQuery += "</condition>";

                    //    }
                    //    //bug 1492
                    //    else
                    //    {
                    //        tracer.Trace("when case type of case does not match with any of the ABR case types");
                    //        fetchQuery += "<condition attribute = 'rsa_triggeringobjectrecordtype' operator='contain-values'>";
                    //        fetchQuery += " <value>" + 0 + "</value>";
                    //        fetchQuery += "</condition>";
                    //    }
                    //}
                    #endregion
                    if (entity.Attributes.Contains("rsa_casenumber"))
                    {
                        tracer.Trace("Case Number " + entity.GetAttributeValue<string>("rsa_casenumber"));
                    }
                    else if (entity.Attributes.Contains("title"))
                    {
                        tracer.Trace("Case Number " + entity.GetAttributeValue<string>("title"));
                    }

                    // Set the condition for Apply R90 Conditions
                    if (entity.Attributes.Contains("rsa_applyr90conditions"))
                    {
                        fetchQuery += "<condition attribute = 'rsa_applyr90conditions' operator= 'eq' value = '" + entity.GetAttributeValue<bool>("rsa_applyr90conditions") + "' />";
                        tracer.Trace("rsa_applyr90conditions " + entity.GetAttributeValue<bool>("rsa_applyr90conditions"));
                        ABRCondition += "...." + "rsa_applyr90conditions :" + entity.GetAttributeValue<bool>("rsa_applyr90conditions");
                    }

                    //Defect id 1835 : duplicate ABR for the set of attributes. Only enforce fulfillment is varied. 
                    //Set the conditions for enforcefullfilment. If post fulfillment activities are provided then enforce post fullfillment
                    OptionSetValueCollection pfActivityType = new OptionSetValueCollection();
                    int pfvalue = 0;
                    bool noneRequired = true;
                    if (entity.Attributes.Contains("rsa_rsapolicyfulfilmentactivities") && !caseTypeName.Contains("EI&C MTA Case"))
                    {

                        pfActivityType = (OptionSetValueCollection)entity.Attributes["rsa_rsapolicyfulfilmentactivities"];
                        // Defect id 1413 ABR- CQE EML Form Task are not generating in CRM when None Required is also Selected in Post Fulfilment Activities
                        // Sumegh Dhole 28 April 2021 : If only none required or nothing selected then enforcepostfullfilment will be false else true. 
                        if (pfActivityType.Contains(new OptionSetValue(866760006)) && pfActivityType.Count == 1)
                        {
                            noneRequired = false;
                        }

                        foreach (var option in pfActivityType)
                        {
                            pfvalue = option.Value;
                        }
                        tracer.Trace("linepfvalue  " + pfvalue);
                    }
                    // Defect id 1413 ABR- CQE EML Form Task 
                    // if (entity.Attributes.Contains("rsa_rsapolicyfulfilmentactivities") && !caseTypeName.Contains("EI&C MTA Case") && (pfvalue!=866760006))
                    if (entity.Attributes.Contains("rsa_rsapolicyfulfilmentactivities") && !caseTypeName.Contains("EI&C MTA Case") && noneRequired)
                    {

                        tracer.Trace("line 89 ");
                        fetchQuery += "<filter type = 'or'>";
                        fetchQuery += "<condition attribute = 'rsa_enforcepostfulfillment' operator= 'eq' value = '0' />";
                        fetchQuery += "<condition attribute = 'rsa_enforcepostfulfillment' operator= 'eq' value = '1' />";
                        fetchQuery += "</filter>";
                        tracer.Trace("rsa_pfactivitytype : true");
                        ABRCondition += "...." + "rsa_rsapolicyfulfilmentactivities : true";
                    }
                    else
                    {
                        fetchQuery += "<condition attribute = 'rsa_enforcepostfulfillment' operator= 'eq' value = '0' />";
                        tracer.Trace("rsa_pfactivitytype : false");
                        ABRCondition += "...." + "rsa_rsapolicyfulfilmentactivities : false";
                    }


                    //Set the fetchxml condition for broker primary reference. 
                    if (entity.Contains("rsa_brokerprimaryreference") && entity.GetAttributeValue<string>("rsa_brokerprimaryreference") != null)
                    {
                        brokerPrimaryRef = entity.GetAttributeValue<string>("rsa_brokerprimaryreference");

                        tracer.Trace("Broker Primary Reference " + brokerPrimaryRef);
                        ABRCondition += "...." + "rsa_brokerprimaryreference : " + brokerPrimaryRef;
                    }
                    else
                    {
                        EntityReference brokerRef = entity.Attributes.Contains("rsa_account") ? (EntityReference)entity.Attributes["rsa_account"] : null;
                        if (brokerRef != null)
                        {
                            Entity accountRef = service.Retrieve("account", brokerRef.Id, new ColumnSet(new string[] { "rsa_primaryreference", "rsa_dealbroker" }));

                            brokerPrimaryRef = accountRef.Attributes.Contains("rsa_primaryreference") ? Convert.ToString(accountRef.Attributes["rsa_primaryreference"]) : string.Empty;
                            tracer.Trace("Broker Primary Reference " + brokerPrimaryRef);
                            dealBroker = accountRef.Attributes.Contains("rsa_dealbroker") ? (bool)accountRef.Attributes["rsa_dealbroker"] : false;
                            tracer.Trace("Deal Broker " + dealBroker);
                            dealBrokerApplicable = accountRef.Attributes.Contains("rsa_dealbroker") ? true : false;
                            ABRCondition += "...." + "rsa_brokerprimaryreference : " + brokerPrimaryRef;
                        }
                    }

                    if (brokerPrimaryRef != string.Empty)
                    {
                        //Get the broker primary reference value to compare and get the ABR. 
                        ABRMultiselect aBRBrokerPrimaryRef = abrOptionsetRoot.ABRMultiselect.Find(a => a.AttributeName.ToLower().Equals("rsa_brokerprimaryreference"));

                        if (aBRBrokerPrimaryRef.Applicablevalues.Find(a => a.key.ToLower().Replace(" ", "").Equals(brokerPrimaryRef.ToLower().Replace(" ", ""))) != null)
                        {
                            objIncident.BrokerPrimaryReference = Convert.ToInt32(((Applicablevalue)aBRBrokerPrimaryRef.Applicablevalues.FirstOrDefault(a => a.key.ToLower().Replace(" ", "").Equals(brokerPrimaryRef.ToLower().Replace(" ", "")))).Value);

                            tracer.Trace("Broker Primary Reference ABR Optionset Map " + objIncident.BrokerPrimaryReference);
                            fetchQuery += "<filter type = 'or'>";
                            fetchQuery += "<condition attribute = 'rsa_brokerprimaryreference' operator= 'null'/>";
                            fetchQuery += "<condition attribute = 'rsa_brokerprimaryreference' operator='contain-values'>";
                            fetchQuery += " <value>" + objIncident.BrokerPrimaryReference + "</value>";
                            fetchQuery += "</condition>";
                            fetchQuery += "</filter>";
                            ABRCondition += "...." + "rsa_brokerprimaryreference : " + objIncident.BrokerPrimaryReference;
                        }
                    }
                    else
                    {
                        fetchQuery += "<condition attribute = 'rsa_brokerprimaryreference' operator= 'null'/>";
                        ABRCondition += "...." + "rsa_brokerprimaryreference : null ";
                    }
                    //bug 1440 condition added for 3 case types for case reason.
                    if (entity.Attributes.Contains("rsa_casereasonrsa") && (caseTypeName.ToLower().Contains("query") || caseTypeName.ToLower().Contains("mid-term adjustment") || caseTypeName.ToLower().Contains("query - sme")))
                    {
                        objIncident.CaseReason = entity.GetAttributeValue<OptionSetValue>("rsa_casereasonrsa").Value;

                        tracer.Trace("Case Reason for 3 case types " + objIncident.CaseReason);
                        fetchQuery += "<filter type = 'or'>";
                        fetchQuery += "<condition attribute = 'rsa_casereason' operator= 'null'/>";
                        fetchQuery += "<condition attribute = 'rsa_casereason' operator='contain-values'>";
                        fetchQuery += " <value>" + objIncident.CaseReason + "</value>";
                        fetchQuery += "</condition>";
                        fetchQuery += "</filter>";
                        ABRCondition += "...." + "Case Reason  : " + objIncident.CaseReason;
                    }
                    //Set the case reason attribute value for comparison
                    //date:04022021 condition added whrn case reason is null.

                    else if (entity.Attributes.Contains("rsa_casereasonrsa") && (!caseTypeName.ToLower().Contains("query") || !caseTypeName.ToLower().Contains("mid-term adjustment") || !caseTypeName.ToLower().Contains("query - sme")))
                    {
                        objIncident.CaseReason = entity.GetAttributeValue<OptionSetValue>("rsa_casereasonrsa").Value;

                        tracer.Trace("Case Reason " + objIncident.CaseReason);
                        fetchQuery += "<filter type = 'and'>";
                        fetchQuery += "<condition attribute = 'rsa_casereason' operator='contain-values'>";
                        fetchQuery += " <value>" + objIncident.CaseReason + "</value>";
                        fetchQuery += "</condition>";
                        fetchQuery += "</filter>";
                        ABRCondition += "...." + "Case Reason  : " + objIncident.CaseReason;
                    }

                    else
                    {
                        fetchQuery += "<condition attribute = 'rsa_casereason' operator= 'null'/>";
                        ABRCondition += "...." + "rsa_casereason : null";
                    }

                    //Set the value of class of business and compare with product in activity business rules. 
                    string classOfBusinessName = string.Empty;
                    if (entity.Attributes.Contains("rsa_classofbusinessphoneenqid") && string.IsNullOrWhiteSpace(classOfBusinessName) && !caseTypeName.Contains("SME - RSA Online Referral"))
                    {
                        //  classOfBusinessId = ((EntityReference)entity.Attributes["rsa_classofbusinessphoneenqid"]).Id;
                        classOfBusinessName = ((EntityReference)entity.Attributes["rsa_classofbusinessphoneenqid"]).Name;
                        if (string.IsNullOrWhiteSpace(classOfBusinessName))
                        {
                            Entity cobEntity = service.Retrieve("rsa_classofbusiness", ((EntityReference)entity.Attributes["rsa_classofbusinessphoneenqid"]).Id, new ColumnSet(new string[] { "rsa_name" }));
                            classOfBusinessName = cobEntity.Attributes.Contains("rsa_name") ? Convert.ToString(cobEntity.Attributes["rsa_name"]) : string.Empty;
                        }
                        tracer.Trace("rsa_classofbusinessphoneenqid " + classOfBusinessName);
                    }
                    if (entity.Attributes.Contains("rsa_classofbusiness") && string.IsNullOrWhiteSpace(classOfBusinessName) && !caseTypeName.Contains("SME - RSA Online Referral"))
                    {
                        classOfBusinessName = Convert.ToString(entity.Attributes["rsa_classofbusiness"]);
                        tracer.Trace("rsa_classofbusiness " + classOfBusinessName);
                    }
                    if (entity.Attributes.Contains("rsa_classofbusinesssme") && string.IsNullOrWhiteSpace(classOfBusinessName) && !caseTypeName.Contains("SME - RSA Online Referral"))
                    {
                        classOfBusinessName = Convert.ToString(entity.Attributes["rsa_classofbusinesssme"]);
                        tracer.Trace("rsa_classofbusinesssme " + classOfBusinessName);
                    }

                    //Get the class of business, reviewtypecdoe and product from value from opportunity or Policy
                    if (entity.Attributes.Contains("rsa_opportunityid") && string.IsNullOrWhiteSpace(classOfBusinessName))
                    {
                        EntityReference opportunityId = entity.Attributes.Contains("rsa_opportunityid") ? (EntityReference)entity.Attributes["rsa_opportunityid"] : null;
                        if (opportunityId != null)
                        {
                            Entity Opportunity = service.Retrieve(opportunityId.LogicalName, opportunityId.Id, new ColumnSet(new string[] { "rsa_classofbusiness", "rsa_productid" }));
                            if (!caseTypeName.Contains("SME - RSA Online Referral"))
                            {
                                classOfBusinessName = Opportunity.Attributes.Contains("rsa_classofbusiness") ? ((EntityReference)Opportunity.Attributes["rsa_classofbusiness"]).Name : string.Empty;
                            } //Defect ID 1405 : ABR not working as product not retrieved. 
                            productName = Opportunity.Attributes.Contains("rsa_productid") ? ((EntityReference)Opportunity.Attributes["rsa_productid"]).Name : string.Empty;
                            tracer.Trace("rsa_classofbusiness from opportunity as not found from case " + classOfBusinessName);
                            tracer.Trace("Data Retrieved from Opportunity " + reviewTypeCode + ": " + classOfBusinessName + " : " + productName);
                        }
                    }
                    else if (entity.Attributes.Contains("rsa_policyid") && string.IsNullOrWhiteSpace(classOfBusinessName))
                    {
                        //Defect ID 1405 : ABR not working as product not retrieved. 
                        tracer.Trace("Get review type from policy  : " + ((EntityReference)entity.Attributes["rsa_policyid"]).Name);
                        //  if renewal type is not populated thru business rule then fetch from policy provided policy exists for case. 
                        Entity policyInfo = service.Retrieve("rsa_policy", ((EntityReference)entity.Attributes["rsa_policyid"]).Id, new ColumnSet(new string[] { "rsa_reviewtypecode", "rsa_productid", "rsa_classofbusiness" }));

                        reviewTypeCode = policyInfo.Attributes.Contains("rsa_reviewtypecode") ? ((OptionSetValue)policyInfo.Attributes["rsa_reviewtypecode"]).Value : -1;
                        if (!caseTypeName.Contains("SME - RSA Online Referral"))
                        {
                            classOfBusinessName = policyInfo.Attributes.Contains("rsa_classofbusiness") ? ((EntityReference)policyInfo.Attributes["rsa_classofbusiness"]).Name : string.Empty;
                        }
                        productName = policyInfo.Attributes.Contains("rsa_productid") ? ((EntityReference)policyInfo.Attributes["rsa_productid"]).Name : string.Empty;

                        tracer.Trace("Data Retrieved from Policy " + reviewTypeCode + " : " + classOfBusinessName + " : " + productName);
                    }
                    tracer.Trace("line 219" + classOfBusinessName);


                    if (classOfBusinessName != string.Empty)
                    {
                        ABRMultiselect aBRCoB = abrOptionsetRoot.ABRMultiselect.Find(a => a.AttributeName.ToLower().Equals("rsa_product"));
                        tracer.Trace("line 225" + classOfBusinessName.ToLower().Replace(" ", ""));

                        if (aBRCoB.Applicablevalues.Find(a => a.key.ToLower().Replace(" ", "").Equals(classOfBusinessName.ToLower().Replace(" ", ""))) != null)
                        {
                            objIncident.ClassofBusiness = Convert.ToInt32(((Applicablevalue)aBRCoB.Applicablevalues.FirstOrDefault(a => a.key.ToLower().Replace(" ", "").Equals(classOfBusinessName.ToLower().Replace(" ", "")))).Value);

                            tracer.Trace("Class of business/Product ABR Optionset Map  " + objIncident.ClassofBusiness);
                            fetchQuery += "<filter type = 'or'>";
                            fetchQuery += "<condition attribute = 'rsa_product' operator= 'null'/>";
                            fetchQuery += "<condition attribute = 'rsa_product' operator='contain-values'>";
                            fetchQuery += "<value>" + objIncident.ClassofBusiness + "</value>";
                            fetchQuery += "</condition>";
                            fetchQuery += "</filter>";
                            ABRCondition += "...." + "ClassofBusiness  : " + classOfBusinessName;
                        }
                        else
                        {
                            fetchQuery += "<condition attribute = 'rsa_product' operator= 'null'/>";//bug 1504 multiple task being created
                        }
                    }
                    else if (string.IsNullOrEmpty(classOfBusinessName))
                    {

                        fetchQuery += "<condition attribute = 'rsa_product' operator= 'null'/>"; //bug 1261 Case assign action - to be vetted
                    }

                    //Set the customer type value in the activity business rule
                    if (entity.Attributes.Contains("rsa_customertype"))
                    {
                        objIncident.CustomerType = entity.Attributes.Contains("rsa_customertype") ? entity.GetAttributeValue<OptionSetValue>("rsa_customertype").Value : -1;
                        tracer.Trace("rsa_customertype : " + objIncident.CustomerType);
                        fetchQuery += "<filter type='or'>";
                        fetchQuery += "<condition attribute = 'rsa_customertype' operator='contain-values'>";
                        fetchQuery += " <value>" + objIncident.CustomerType + "</value>";
                        fetchQuery += "</condition>";
                        fetchQuery += "<condition attribute = 'rsa_customertype' operator= 'null' /></filter>";
                        ABRCondition += "...." + "rsa_customertype  : " + objIncident.CustomerType;
                    }
                    else
                    {
                        fetchQuery += "<condition attribute = 'rsa_customertype' operator= 'null' />";
                        ABRCondition += "...." + "ClassofBusiness  : null ";
                    }

                    //Set value of deals case.
                    if (entity.Attributes.Contains("rsa_dealscase"))
                    {
                        objIncident.Dealscase = entity.GetAttributeValue<string>("rsa_dealscase").ToLower() == "yes" ? 1 : 0;
                        if (objIncident.Dealscase == 1)
                        {
                            tracer.Trace("Dealscase : " + objIncident.Dealscase);
                            //  fetchQuery += "<condition attribute = 'rsa_dealcase' operator= 'eq' value = '" + objIncident.Dealscase + "' />";
                            //Fix for 1894 : Sumegh Dhole : PGLS defect. Debit premium and the related tasks were not creating
                            fetchQuery += "<filter type='or'>";
                            fetchQuery += "<condition attribute = 'rsa_dealcase' operator= 'eq' value = '" + 1 + "' />";
                            fetchQuery += "<condition attribute = 'rsa_dealcase' operator= 'eq' value = '" + 0 + "' />";
                            fetchQuery += "</filter>";
                            ABRCondition += "...." + "rsa_dealscase  : " + objIncident.Dealscase;
                        }
                        else
                        {
                            fetchQuery += "<condition attribute = 'rsa_dealcase' operator= 'eq' value = '" + objIncident.Dealscase + "' />";
                        }
                    }
                    else
                    {
                        if (dealBrokerApplicable)
                        {
                            // fetchQuery += "<condition attribute = 'rsa_dealcase' operator= 'eq' value = '" + dealBroker + "' />";
                            //Fix for 1894 : Sumegh Dhole : PGLS defect. Debit premium and the related tasks were not creating
                            fetchQuery += "<filter type='or'>";
                            fetchQuery += "<condition attribute = 'rsa_dealcase' operator= 'eq' value = '" + 1 + "' />";
                            fetchQuery += "<condition attribute = 'rsa_dealcase' operator= 'eq' value = '" + 0 + "' />";
                            fetchQuery += "</filter>";
                            ABRCondition += "...." + "rsa_dealcase  : Deals case yes and no both";
                        }
                        else
                        {
                            fetchQuery += "<condition attribute = 'rsa_dealcase' operator= 'eq' value = '" + dealBroker + "' />";
                            ABRCondition += "...." + "rsa_dealcase  : " + dealBroker;
                        }
                    }

                    //Set the value of Key SME broker
                    if (entity.Attributes.Contains("rsa_keysmebroker"))
                    {
                        objIncident.KeySMEBroker = Convert.ToString(entity.Attributes["rsa_keysmebroker"]).ToLower().Equals("yes") ? 1 : 0;

                        tracer.Trace("rsa_keysmebroker : " + objIncident.KeySMEBroker);
                        fetchQuery += "<condition attribute = 'rsa_keysmebroker' operator= 'eq' value = '" + objIncident.KeySMEBroker + "' />";
                        ABRCondition += "...." + "rsa_keysmebroker  : " + objIncident.KeySMEBroker;
                    }

                    //Set the value of the product SME for comparison

                    if (entity.Contains("rsa_product_w"))
                    {
                        productName = entity.Attributes.Contains("rsa_product_w") ? Convert.ToString(entity.Attributes["rsa_product_w"]) : string.Empty;
                        tracer.Trace("rsa_product_w : " + productName);
                    }
                    if (entity.Contains("rsa_productsmev2") && string.IsNullOrWhiteSpace(productName))
                    {
                        productName = entity.Attributes.Contains("rsa_productsmev2") ? Convert.ToString(entity.Attributes["rsa_productsmev2"]) : string.Empty;
                        tracer.Trace("rsa_productsmev2 : " + productName);
                    }
                    if (entity.Contains("rsa_productlivechat") && string.IsNullOrWhiteSpace(productName))
                    {
                        productName = entity.Attributes.Contains("rsa_productlivechat") ? Convert.ToString(entity.Attributes["rsa_productlivechat"]) : string.Empty;
                        tracer.Trace("rsa_productlivechat : " + productName);
                    }
                    if (entity.Contains("rsa_productphoneenqid") && string.IsNullOrWhiteSpace(productName))
                    {
                        productName = entity.Attributes.Contains("rsa_productphoneenqid") ? ((EntityReference)entity.Attributes["rsa_productphoneenqid"]).Name : string.Empty;
                        if (string.IsNullOrWhiteSpace(productName))
                        {
                            Entity productEntity = service.Retrieve("rsa_product", ((EntityReference)entity.Attributes["rsa_productphoneenqid"]).Id, new ColumnSet(new string[] { "rsa_name" }));
                            productName = productEntity.Attributes.Contains("rsa_name") ? Convert.ToString(productEntity.Attributes["rsa_name"]) : string.Empty;
                        }
                        tracer.Trace("rsa_productphoneenqid : " + productName);
                    }
                    if (caseTypeName.ToLower().Contains("sme - imarket referral") && productName == string.Empty)
                    {
                        tracer.Trace("Inside sme - imarket referral ");
                        fetchQuery += "<filter type = 'and'>";
                        //fetchQuery += "<condition attribute = 'rsa_productsme' operator= 'null'/>";
                        fetchQuery += "<condition attribute = 'rsa_productsme' operator='contain-values'>";
                        fetchQuery += "<value>" + 0 + "</value>";
                        fetchQuery += "</condition>";
                        fetchQuery += "</filter>";
                        ABRCondition += "...." + "Productsme  : " + productName;
                    }
                    if (productName != string.Empty)
                    {
                        ABRMultiselect aBRProductsme = abrOptionsetRoot.ABRMultiselect.Find(a => a.AttributeName.ToLower().Equals("rsa_productsme"));
                        if (aBRProductsme.Applicablevalues.Find(a => a.key.ToLower().Replace(" ", "").Equals(productName.ToLower().Replace(" ", ""))) != null)
                        {
                            objIncident.Productsme = Convert.ToInt32(((Applicablevalue)aBRProductsme.Applicablevalues.FirstOrDefault(a => a.key.ToLower().Replace(" ", "").Equals(productName.ToLower().Replace(" ", "")))).Value);
                            tracer.Trace("ProductSME ABR Optionset Map  " + objIncident.Productsme);

                            // fetchQuery += "<condition attribute = 'rsa_productsme' operator='contain-values'>";
                            // fetchQuery += " <value>" + objIncident.Productsme + "</value>";
                            // fetchQuery += "</condition>";
                            if (caseTypeName.ToLower().Contains("sme - imarket referral"))
                            {
                                tracer.Trace("Inside sme - imarket referral ");
                                fetchQuery += "<filter type = 'and'>";
                                //fetchQuery += "<condition attribute = 'rsa_productsme' operator= 'null'/>";
                                fetchQuery += "<condition attribute = 'rsa_productsme' operator='contain-values'>";
                                fetchQuery += "<value>" + objIncident.Productsme + "</value>";
                                fetchQuery += "</condition>";
                                fetchQuery += "</filter>";
                                ABRCondition += "...." + "Productsme  : " + productName;
                            }
                            else if (!caseTypeName.ToLower().Contains("sme - imarket referral"))
                            {
                                fetchQuery += "<filter type = 'or'>";
                                fetchQuery += "<condition attribute = 'rsa_productsme' operator= 'null'/>";
                                fetchQuery += "<condition attribute = 'rsa_productsme' operator='contain-values'>";
                                fetchQuery += "<value>" + objIncident.Productsme + "</value>";
                                fetchQuery += "</condition>";
                                fetchQuery += "</filter>";
                                ABRCondition += "...." + "Productsme  : " + productName;
                            }

                        }
                        else
                        {
                            fetchQuery += "<condition attribute = 'rsa_productsme' operator= 'null'/>";
                            ABRCondition += "...." + "Productsme  : null";
                        }
                    }
                    //else
                    //{
                    //    fetchQuery += "<condition attribute = 'rsa_productsme' operator= 'null'/>";
                    //    ABRCondition += "...." + "Productsme  : null";
                    //}


                    //Set the value of the renewal review type
                    if (entity.Attributes.Contains("rsa_renewalreviewtype"))
                    {
                        string renewalReviewType = entity.GetAttributeValue<string>("rsa_renewalreviewtype");
                        tracer.Trace("rsa_renewalreviewtype : " + renewalReviewType);

                        ABRMultiselect aBRRenewalReviewType = abrOptionsetRoot.ABRMultiselect.Find(a => a.AttributeName.ToLower().Equals("rsa_renewalreviewtype"));
                        if (aBRRenewalReviewType.Applicablevalues.Find(a => a.key.ToLower().Replace(" ", "").Equals(renewalReviewType.Replace(" ", "").ToLower())) != null)
                        {
                            objIncident.RenewalReviewType = Convert.ToInt32(((Applicablevalue)aBRRenewalReviewType.Applicablevalues.FirstOrDefault(a => a.key.ToLower().Replace(" ", "").Equals(renewalReviewType.ToLower().Replace(" ", "")))).Value);
                            tracer.Trace("Renewal Review Type ABR Optionset Map  " + objIncident.RenewalReviewType);
                            fetchQuery += "<filter type = 'or'>";
                            fetchQuery += "<condition attribute = 'rsa_renewalreviewtype' operator= 'null'/>";
                            fetchQuery += "<condition attribute = 'rsa_renewalreviewtype' operator='contain-values'>";
                            fetchQuery += " <value>" + objIncident.RenewalReviewType + "</value>";
                            fetchQuery += "</condition>";
                            fetchQuery += "</filter>";
                            ABRCondition += "...." + "RenewalReviewType  : " + renewalReviewType;
                        }
                    }
                    else if (reviewTypeCode != -1)
                    {
                        tracer.Trace("Get review type Code  : " + reviewTypeCode);
                        fetchQuery += "<filter type = 'or'>";
                        fetchQuery += "<condition attribute = 'rsa_renewalreviewtype' operator= 'null'/>";
                        fetchQuery += "<condition attribute = 'rsa_renewalreviewtype' operator='contain-values'>";
                        fetchQuery += " <value>" + reviewTypeCode + "</value>";
                        fetchQuery += "</condition>";
                        fetchQuery += "</filter>";
                        ABRCondition += "...." + "RenewalReviewType  : " + reviewTypeCode;
                    }
                    else
                    {
                        fetchQuery += "<condition attribute = 'rsa_renewalreviewtype' operator= 'null'/>";
                        ABRCondition += "...." + "RenewalReviewType  : null";
                    }

                    //Set the value of traded 
                    if (entity.Attributes.Contains("rsa_traded"))
                    {
                        tracer.Trace("rsa_traded  : " + ((OptionSetValue)entity.Attributes["rsa_traded"]).Value);
                        objIncident.Traded = entity.GetAttributeValue<OptionSetValue>("rsa_traded").Value;
                        fetchQuery += "<filter type = 'or'>";
                        fetchQuery += "<condition attribute = 'rsa_traded' operator= 'null'/>";
                        fetchQuery += "<condition attribute = 'rsa_traded' operator='contain-values'>";
                        fetchQuery += " <value>" + objIncident.Traded + "</value>";
                        fetchQuery += "</condition>";
                        fetchQuery += "</filter>";
                        ABRCondition += "...." + "Traded  : " + objIncident.Traded;
                    }
                    else
                    {
                        fetchQuery += "<condition attribute = 'rsa_traded' operator= 'null'/>";
                        ABRCondition += "...." + "Traded  : null";
                    }

                    //Set the value of transaction type
                    if (entity.Attributes.Contains("rsa_transactiontypeid"))
                    {
                        string TransactionType = entity.GetAttributeValue<EntityReference>("rsa_transactiontypeid").Name;
                        if (String.IsNullOrWhiteSpace(TransactionType))
                        {
                            Entity transactionType = service.Retrieve("rsa_transactiontype", entity.GetAttributeValue<EntityReference>("rsa_transactiontypeid").Id, new ColumnSet(new string[] { "rsa_name" }));
                            TransactionType = transactionType.Attributes.Contains("rsa_name") ? Convert.ToString(transactionType.Attributes["rsa_name"]) : string.Empty;
                        }
                        tracer.Trace("TransactionType  : " + TransactionType);
                        ABRMultiselect aBRTransactionType = abrOptionsetRoot.ABRMultiselect.Find(a => a.AttributeName.ToLower().Equals("rsa_transactiontype"));
                        if (aBRTransactionType.Applicablevalues.Find(a => a.key.ToLower().Replace(" ", "").Equals(TransactionType.ToLower().Replace(" ", ""))) != null)
                        {
                            objIncident.TransactiontType = Convert.ToInt32(((Applicablevalue)aBRTransactionType.Applicablevalues.FirstOrDefault(a => a.key.ToLower().Replace(" ", "").Equals(TransactionType.ToLower().Replace(" ", "")))).Value);
                            tracer.Trace("Transaction Type ABR Optionset Map  " + objIncident.TransactiontType);
                            //Defect No 195 : Sumegh Dhole : handled condition for transaction type
                            fetchQuery += "<filter type='or'>";
                            fetchQuery += "<condition attribute = 'rsa_transactiontype' operator='contain-values'>";
                            fetchQuery += "<value>" + objIncident.TransactiontType + "</value>";
                            fetchQuery += "</condition>";
                            fetchQuery += "<condition attribute='rsa_transactiontype' operator='null'/></filter>";
                            ABRCondition += "...." + "TransactiontType  : " + TransactionType;
                        }
                    }
                    else
                    {
                        fetchQuery += "<condition attribute='rsa_transactiontype' operator='null'/>";
                        ABRCondition += "...." + "TransactiontType  :null";
                    }
                    #region  Status Check
                    //string statusName = string.Empty;
                    ////Set the value of status
                    //if (entity.Attributes.Contains("rsa_status"))
                    //{
                    //    statusName = ((EntityReference)entity.Attributes["rsa_status"]).Name;

                    //    if (string.IsNullOrWhiteSpace(statusName) || !string.IsNullOrEmpty(statusName))
                    //    {
                    //        Entity Status = service.Retrieve("rsa_status", entity.GetAttributeValue<EntityReference>("rsa_status").Id, new ColumnSet(new string[] { "rsa_name" }));
                    //        // string statusName = ((EntityReference)entity.Attributes["rsa_status"]).Name;
                    //        statusName = Status.Attributes.Contains("rsa_name") ? Convert.ToString(Status.Attributes["rsa_name"]) : string.Empty;
                    //        tracer.Trace("statusNameTest  : " + Convert.ToString(Status.Attributes["rsa_name"]));
                    //    }
                    //    tracer.Trace("statusId  : " + ((EntityReference)entity.Attributes["rsa_status"]).Id);
                    //    tracer.Trace("statusName  : " + statusName);

                    //    if (statusName != null && !string.IsNullOrEmpty(statusName))
                    //    {
                    //        ABRCondition += "...." + "rsa_status  :" + statusName;
                    //        ABRMultiselect aBRStatus = abrOptionsetRoot.ABRMultiselect.Find(a => a.AttributeName.ToLower().Equals("rsa_status"));

                    //        //throw new InvalidPluginExecutionException();
                    //        if (aBRStatus.Applicablevalues.Find(a => a.key.ToLower().Replace(" ", "").Equals(statusName.ToLower().Replace(" ", ""))) != null)
                    //        {
                    //            objIncident.Status = Convert.ToInt32(((Applicablevalue)aBRStatus.Applicablevalues.FirstOrDefault(a => a.key.ToLower().Replace(" ", "").Equals(statusName.ToLower().Replace(" ", "")))).Value);
                    //            tracer.Trace("Status ABR Optionset Map  " + objIncident.Status);
                    //            fetchQuery += "<condition attribute = 'rsa_status' operator='eq' value = '" + objIncident.Status + "' />";

                    //        }
                    //        if (statusName.Contains("No Longer Required") || statusName.Contains("Under Extension")) //Bug 1994, 1966 when status is no longer required and Under extension .hence No ABR Template.
                    //        {
                    //            fetchQuery += "<condition attribute = 'rsa_status' operator='eq' value = '0' />";
                    //            tracer.Trace("As the Status is no longer required hence No ABR Template");
                    //        }
                    //    }

                    //}


                   #endregion


                    //Set the value of Triggering object 

                    //Set the value of triggering object to case
                    fetchQuery += "<condition attribute = 'rsa_triggeringobject' operator= 'eq' value = '866760000' />";
                    tracer.Trace("rsa_triggeringobject  : " + "866760000");
                    ABRCondition += "...." + "rsa_triggeringobject  : Case";
                    //Set the value of promise 
                    objIncident.Promise = setPromiseNonPromise(service, entity, tracer);

                    if (objIncident.Promise != 0)
                    {
                        // objIncident.Promise = entity.GetAttributeValue<OptionSetValue>("rsa_promise").Value;
                        tracer.Trace("Promise  : " + objIncident.Promise);
                        fetchQuery += "<filter type = 'or'>";
                        //fetchQuery += "<condition attribute = 'rsa_promise' operator= 'null'/>"; //bug 1432 Promise value as null in or condition 
                        fetchQuery += "<condition attribute = 'rsa_promise' operator='contain-values'>";
                        fetchQuery += " <value>" + objIncident.Promise + "</value>"; //// date:14042021 for underwriting rationale.
                        fetchQuery += "</condition>";
                        fetchQuery += "</filter>";
                        ABRCondition += "...." + "rsa_promise  : " + objIncident.Promise;
                    }
                    else if (objIncident.Promise != 0 && !entity.Attributes.Contains("rsa_promise")) //promise
                    {
                        // objIncident.Promise = entity.GetAttributeValue<OptionSetValue>("rsa_promise").Value;
                        tracer.Trace("Promise  : " + objIncident.Promise);
                        fetchQuery += "<filter type = 'or'>";
                        fetchQuery += "<condition attribute = 'rsa_promise' operator= 'null'/>"; //bug 1810 Promise value as null in or condition 
                        fetchQuery += "<condition attribute = 'rsa_promise' operator='contain-values'>";
                        fetchQuery += " <value>" + objIncident.Promise + "</value>"; //// date:14042021 for underwriting rationale.
                        fetchQuery += "</condition>";
                        fetchQuery += "</filter>";
                        ABRCondition += "...." + "rsa_promise  : " + objIncident.Promise;
                    }
                    else if (objIncident.Promise == 0 && entity.Attributes.Contains("rsa_promise")) //non promise
                    {


                        if (objIncident.TriggerinObjectRecordType.Equals(866760008))
                        {
                            tracer.Trace("when case type is NB IOM bypassing Promise non promise condition ");
                        }
                        else
                        {
                            objIncident.Promise = entity.GetAttributeValue<OptionSetValue>("rsa_promise").Value;
                            tracer.Trace("Promise  : " + objIncident.Promise);
                            fetchQuery += "<filter type = 'or'>";
                            // fetchQuery += "<condition attribute = 'rsa_promise' operator= 'null'/>";
                            fetchQuery += "<condition attribute = 'rsa_promise' operator='contain-values'>";
                            fetchQuery += " <value>" + objIncident.Promise + "</value>";
                            fetchQuery += "</condition>";
                            fetchQuery += "</filter>";
                            ABRCondition += "...." + "rsa_promise  : " + objIncident.Promise;
                        }
                    }
                    else if (entity.Attributes.Contains("rsa_brokerpromise"))
                    {
                        string promiseValue = entity.GetAttributeValue<string>("rsa_brokerpromise");
                        tracer.Trace("Broker Promise  : " + promiseValue);
                        if (promiseValue.ToLower().Equals("promise"))
                        {
                            objIncident.Promise = 866760000;
                            ABRCondition += "...." + "rsa_promise  : Promise";
                        }
                        else
                        {
                            objIncident.Promise = 866760001;
                            ABRCondition += "...." + "rsa_promise  : Non-Promise";
                        }
                        tracer.Trace("Promise Check : ");
                        fetchQuery += "<filter type = 'or'>";
                        fetchQuery += "<condition attribute = 'rsa_promise' operator= 'null'/>";
                        fetchQuery += "<condition attribute = 'rsa_promise' operator='contain-values'>";
                        fetchQuery += " <value>" + objIncident.Promise + "</value>";
                        fetchQuery += "</condition>";
                        fetchQuery += "</filter>";

                    }
                    else
                    {
                        tracer.Trace(" final Promise  : ");
                        fetchQuery += "<condition attribute = 'rsa_promise' operator='null'/>";
                        ABRCondition += "...." + "rsa_promise  : null";
                    }

                    fetchQuery += "</filter>";
                    fetchQuery += "</link-entity>";
                    fetchQuery += "</entity>";
                    fetchQuery += "</fetch>";

                   
                    EntityCollection abrTaskCol = service.RetrieveMultiple(new FetchExpression(fetchQuery));
                    tracer.Trace("Count of ABR records retrieved: {0}", abrTaskCol.Entities.Count);
                    if (abrTaskCol.Entities.Count > 0)
                    {
                        endDate = SLACalculation(service, abrTaskCol.Entities[0], entity, OpportunityID.Id, tracer);
                    }

                   






                    //  List<string> ExistingABRNames = ListofTaskCreated(Case, task, tracer, service);
                    //   ExistingABRNames = ExistingABRNames.Select(s => s = s.Replace(" ", "")).ToList();
                    #region Commented
                    //foreach (var ABR in abrCol.Entities)
                    //{
                    //    Guid abrid = Guid.Parse(ABR.Id.ToString());
                    //    #region getTaskName
                    //    QueryExpression queryExp = new QueryExpression("rsa_abrtask");
                    //    queryExp.ColumnSet = new ColumnSet(new string[] { "rsa_subject" });
                    //    queryExp.Criteria.AddCondition("rsa_relatedto", ConditionOperator.Equal, abrid);
                    //    queryExp.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);
                    //    queryExp.NoLock = true;
                    //    EntityCollection en_ABRNames = service.RetrieveMultiple(queryExp);
                    //    if (en_ABRNames.Entities.Count > 0) {
                    //        foreach (var en in en_ABRNames.Entities)
                    //        {
                    //            string subject = en.GetAttributeValue<string>("rsa_subject");
                    //            list_ABRNames.Add((Convert.ToString(subject)));
                    //            list_ABRNames = list_ABRNames.Select(s => s = s.Replace(" ", "")).ToList();
                    //        }

                    //    }
                    //    #endregion
                    ////    if (list_ABRNames.Intersect(ExistingABRNames).Any())
                    //    //{
                    //    //    getABRTask(Case, service, tracer, abrid);
                    //    //}

                    //}
                    #endregion

                }
                return endDate;
            }
                           

            catch (Exception ex)
            {
                tracer.Trace("GetABRTemplate-Error" + ex.Message.ToString());
                throw new InvalidPluginExecutionException(ex.Message);
            }
            finally 
            {
                ms.Close();
            }
        }

        public static DateTime SLACalculation(IOrganizationService service, Entity task,Entity entityPostImage ,Guid opportunityId, ITracingService tracer)
        {
            #region//SLA CALCULATIONS
            decimal dueDateOffset = 0;
            int? userTimezone = RetrieveCurrentUsersSettings(service);
            DateTime LocalTime = RetrieveLocalTimeFromUTCTime(DateTime.UtcNow, userTimezone, service);
            tracer.Trace(" DateTime LocalTime" + LocalTime);
            DateTime UTCTimeFromLocalTime = RetrieveUTCTimeFromLocalTime(LocalTime, userTimezone, service);
            tracer.Trace(" UTCTimeFromLocalTimee" + UTCTimeFromLocalTime);
            string dueDateUnits = string.Empty;
            DateTime dt = DateTime.MinValue;
            string dueDateBasedOn = string.Empty;
            bool BusinessDaysRequired = false;
            bool businesshours = false;

            if (task.FormattedValues.Contains("rsa_duedateunits"))
            {
                dueDateUnits = task.FormattedValues["rsa_duedateunits"];
                tracer.Trace("Activities dueDateUnits is : {0}", dueDateUnits);
            }
            if (task.FormattedValues.Contains("rsa_duedatebasedon"))
            {
                dueDateBasedOn = task.FormattedValues["rsa_duedatebasedon"];
                tracer.Trace("Activities dueDateBasedOn is : {0}", dueDateBasedOn);
            }
            if (dueDateBasedOn.ToLower().Trim() == "case.created")
            {
                dt = entityPostImage.Attributes.Contains("createdon") && entityPostImage.GetAttributeValue<DateTime>("createdon") != null ? entityPostImage.GetAttributeValue<DateTime>("createdon") : DateTime.MinValue;
                dt = CreateNewDate(dt.Year, dt.Month, dt.Day, dt);
                dt = RetrieveLocalTimeFromUTCTime(dt, userTimezone, service);
                //dt = GetCasesDates(service, caseId, "createdon");
                tracer.Trace("case.created Activities dt is : {0}", dt);
            }
            else if (dueDateBasedOn.ToLower().Trim() == "case.case_received_date__c")
            {
                dt = entityPostImage.Attributes.Contains("rsa_casereceiveddate") && entityPostImage.GetAttributeValue<DateTime>("rsa_casereceiveddate") != null ? entityPostImage.GetAttributeValue<DateTime>("rsa_casereceiveddate") : DateTime.MinValue;
                dt = RetrieveLocalTimeFromUTCTime(dt, userTimezone, service);
                //dt = GetCasesDates(service, caseId, "rsa_casereceiveddate");
                tracer.Trace(" case.case_received_date__c Activities dt is : {0}", dt);
            }
            else if (dueDateBasedOn.ToLower().Trim() == "last day of month")
            {
                // int year = System.DateTime.Now.Year;
                int year = LocalTime.Year;
                //int month = System.DateTime.Now.Month + 1;
                int month = LocalTime.Month + 1;
                dt = new DateTime(year, month, System.DateTime.DaysInMonth(LocalTime.Year, month));
                tracer.Trace("last day of month Activities dt is : {0}", dt);
            }
            else if (dueDateBasedOn.ToLower().Trim() == "case.scheme_review_deadline__c")
            {
                dt = entityPostImage.Attributes.Contains("rsa_schemereviewdeadline") && entityPostImage.GetAttributeValue<DateTime>("rsa_schemereviewdeadline") != null ? entityPostImage.GetAttributeValue<DateTime>("rsa_schemereviewdeadline") : DateTime.MinValue;
                dt = RetrieveLocalTimeFromUTCTime(dt, userTimezone, service);
                //dt = GetCasesDates(service, caseId, "rsa_schemereviewdeadline");
                tracer.Trace("case.scheme_review_deadline__c Activities dt is : {0}", dt);
            }
            else if (dueDateBasedOn.ToLower().Trim() == "case.tech_nextcallduedate__c")
            {
                dt = entityPostImage.Attributes.Contains("rsa_technextcallduedate") && entityPostImage.GetAttributeValue<DateTime>("rsa_technextcallduedate") != null ? entityPostImage.GetAttributeValue<DateTime>("rsa_technextcallduedate") : DateTime.MinValue;
                dt = RetrieveLocalTimeFromUTCTime(dt, userTimezone, service);
                //dt = GetCasesDates(service, caseId, "rsa_technextcallduedate");
                tracer.Trace("case.tech_nextcallduedate__c Activities dt is : {0}", dt);
            }
            else if (dueDateBasedOn.ToLower().Trim() == "case.effective_date__c")
            {
                dt = entityPostImage.Attributes.Contains("rsa_effectivedate") && entityPostImage.GetAttributeValue<DateTime>("rsa_effectivedate") != null ? entityPostImage.GetAttributeValue<DateTime>("rsa_effectivedate") : DateTime.MinValue;
                dt = RetrieveLocalTimeFromUTCTime(dt, userTimezone, service);
                //dt = GetCasesDates(service, caseId, "rsa_effectivedate");
                tracer.Trace("case.effective_date__c Activities dt is : {0}", dt);
            }
            else if (dueDateBasedOn.ToLower().Trim() == "case.ais_task_due_date__c")
            {
                //dt = GetCasesDates(service, caseId, "rsa_aistaskduedate");
                dt = entityPostImage.Attributes.Contains("rsa_aistaskduedate") && entityPostImage.GetAttributeValue<DateTime>("rsa_aistaskduedate") != null ? entityPostImage.GetAttributeValue<DateTime>("rsa_aistaskduedate") : DateTime.MinValue;
                dt = RetrieveLocalTimeFromUTCTime(dt, userTimezone, service);
                tracer.Trace("case.ais_task_due_date__c Activities dt is : {0}", dt);
            }
            else if (dueDateBasedOn.ToLower().Trim() == "activity.created")
            {
                dt = LocalTime;
                // Not considering the initial date
                tracer.Trace("activity.created time  " + dt);


                tracer.Trace("activity.created Activities dt is : {0}", dt);
            }
            else if (dueDateBasedOn.ToLower().Trim() == "opportunity.closedate" && opportunityId != Guid.Empty)
            {
                dt = GetOpportunityDate(service, opportunityId, "rsa_closedate");
                tracer.Trace("dt       " + dt);
                dt = RetrieveLocalTimeFromUTCTime(dt, userTimezone, service);
                tracer.Trace("  RetrieveLocalTimeFromUTCTime   " + dt);

                tracer.Trace("opportunity.closedate Activities dt is : {0}", dt);
            }
            else if (dueDateBasedOn.ToLower().Trim() == "opportunity.closedate or end of month" && opportunityId != Guid.Empty)
            {
                dt = GetOpportunityDate(service, opportunityId, "rsa_closedate");
                dt = RetrieveLocalTimeFromUTCTime(dt, userTimezone, service);

                tracer.Trace("  RetrieveLocalTimeFromUTCTime   " + dt);
                tracer.Trace("opportunity.closedate or end of month Activities dt is : {0}", dt);
            }
            else
            {
                dt = LocalTime;
                tracer.Trace("Activities dt is : {0}", dt);
            }
            if (task.Attributes.Contains("rsa_businesshourrequired"))
            {
                businesshours = task.GetAttributeValue<bool>("rsa_businesshourrequired");
                tracer.Trace("Activities businesshours is : {0}", businesshours);
            }
            if (task.Attributes.Contains("rsa_businessdaysrequired"))
            {
                BusinessDaysRequired = task.GetAttributeValue<bool>("rsa_businessdaysrequired");
                tracer.Trace("Activities businesshours is : {0}", businesshours);
            }
            DateTime taskEndDate = LocalTime;
            DateTime taskStartDate = LocalTime;
            int defaultTime = 17;
            TimeSpan ts_DefaultTime = TimeSpan.FromHours(defaultTime);
            var timeSpandt = dt.TimeOfDay;
            double EndofBusinessHoursTime = 17.01;
            int startofBusinessHoursTime = 9;
            TimeSpan ts_EndofBusinessHoursTime = TimeSpan.FromHours(EndofBusinessHoursTime); // this is defined to use the time of day .that is 17 o clock.
            TimeSpan ts_StartofBusinessHoursTime = TimeSpan.FromHours(startofBusinessHoursTime);
            TimeSpan ts_DefaultStartTime = new TimeSpan(09, 00, 00);
            tracer.Trace("ts_EndofBusinessHoursTime   " + ts_EndofBusinessHoursTime);
            tracer.Trace("timeSpandt  " + timeSpandt);
            tracer.Trace("timeSpandt hour  " + timeSpandt.Hours);
            tracer.Trace("Business Hours  " + businesshours);
            tracer.Trace(" Business Days " + BusinessDaysRequired);

            if (!string.IsNullOrEmpty(dueDateUnits) && dueDateUnits.ToLower() == "days" && dt != null)
            {
                if (task.Attributes.Contains("rsa_duedateoffset"))
                {
                    dueDateOffset = task.GetAttributeValue<decimal>("rsa_duedateoffset"); //gives us the data from ABR task entity
                }
                //Sumegh Dhole 20 Oct 2020 : Check added if dt is always datetime.
                //Minvalue as the rsa_technextcallduedate is captured in pre activity create and its not calculated in the case record. 
                tracer.Trace("DT shortdate string  : {0} : {1}", dt.ToShortDateString(), Convert.ToDouble(dueDateOffset));
                tracer.Trace("Today shortdate  : {0}", DateTime.Today.ToShortDateString());
                if (dt != DateTime.MinValue && dt.ToShortDateString() == DateTime.Today.ToShortDateString() && dueDateOffset > 1)
                {

                    if (BusinessDaysRequired)   //this condition to be removed as records are configured as INCLUDE WEEKENDS
                    {
                        tracer.Trace(" Business Days  required 1534");
                        taskEndDate = CalculateBusinessDays(service, tracer, dt, Convert.ToInt32(dueDateOffset)); //initial date always

                        tracer.Trace("taskEndDate  " + taskEndDate);
                    }
                    else
                    {
                        tracer.Trace(" Business Days Not required");
                        tracer.Trace("taskEndDate line 1926 " + taskEndDate);
                        taskEndDate = dt.AddDays(Convert.ToDouble(dueDateOffset)); //

                        tracer.Trace("taskEndDate line 1540 " + taskEndDate);
                    }
                    if (businesshours)
                    {
                        tracer.Trace("inside hours business hours"); //timespandt is due date based on 
                        if (timeSpandt <= ts_EndofBusinessHoursTime && timeSpandt >= ts_StartofBusinessHoursTime) //within the business hrs.
                        {
                            tracer.Trace("inside hours business hours  " + timeSpandt.Hours); //printing the vlue of current businesshr

                            taskEndDate = dt.AddDays(Convert.ToDouble(dueDateOffset - 1)); //added te offset .from next line if it is grater than Busines hrs then we will subtract


                        }
                        else
                        {
                            tracer.Trace("if the dt is outside business hours");
                            if (timeSpandt > ts_EndofBusinessHoursTime)
                            {
                                dt = dt.AddDays(Convert.ToDouble(dueDateOffset)); ;//
                                tracer.Trace("when the due date based on is outside the end of  business hrs ");
                            }

                            //taskEndDate = CalculateBusinessDays(service, tracer, dt, Convert.ToInt32(dueDateOffset));//08062021
                        }
                        if (BusinessDaysRequired)
                        {
                            if (taskEndDate.DayOfWeek == DayOfWeek.Saturday)
                            {
                                taskEndDate = taskEndDate.AddDays(2);
                            }
                            else if (taskEndDate.DayOfWeek == DayOfWeek.Sunday)
                                taskEndDate = taskEndDate.AddDays(1);
                        }
                    }
                    tracer.Trace("Task End Date  : {0}", taskEndDate);
                }
                else if (dt != DateTime.MinValue && dt.ToShortDateString() == DateTime.Today.ToShortDateString() && dueDateOffset == 1)
                {
                    tracer.Trace("test1");

                    if (BusinessDaysRequired)
                    {
                        tracer.Trace(" Business Days  required 1568");
                        taskEndDate = CalculateBusinessDays(service, tracer, dt, Convert.ToInt32(dueDateOffset));

                    } //////this condition to be removed as records are configured as INCLUDE WEEKENDS

                    else
                    {
                        tracer.Trace(" Business Days  not  required 1975");
                        taskEndDate = dt.AddDays(Convert.ToDouble(dueDateOffset));
                    }
                    if (businesshours)
                    {
                        if (timeSpandt <= ts_EndofBusinessHoursTime)
                        {
                            taskEndDate = taskEndDate; //
                            if (BusinessDaysRequired)//this condition to be removed as records are configured as INCLUDE WEEKENDS   
                            {
                                if (taskEndDate.DayOfWeek == DayOfWeek.Saturday)
                                {
                                    taskEndDate = taskEndDate.AddDays(-1);
                                }
                                else if (taskEndDate.DayOfWeek == DayOfWeek.Sunday)
                                    taskEndDate = taskEndDate.AddDays(-2);
                            }
                            taskEndDate = taskEndDate.Date + ts_DefaultTime; //Added this to default the time to 6 o clock
                            tracer.Trace("taskEndDate when timeSpandt is less  than 5 " + taskEndDate);
                        }
                        else
                        {
                            taskEndDate = taskEndDate.AddDays(1);
                            tracer.Trace("taskEndDate when timeSpandt is greater  than 5    " + taskEndDate);
                        }

                    }


                    tracer.Trace("Task End Date  when offset is 1 : {0}", taskEndDate);
                }
                else if (dt != DateTime.MinValue && dt > DateTime.Today.AddDays(Convert.ToDouble(dueDateOffset)) && dt.AddDays(Convert.ToDouble(dueDateOffset)) >= DateTime.Now)
                {
                    if (dueDateOffset > 0)
                    {
                        tracer.Trace("test2");
                        tracer.Trace("BusinessDaysRequired " + BusinessDaysRequired);
                        if (BusinessDaysRequired)
                        {
                            tracer.Trace(" Business Days  required 1603");
                            taskEndDate = CalculateBusinessDays(service, tracer, dt, Convert.ToInt32(dueDateOffset)); //INCLUDES INITIAL DATE

                        }

                        else
                        {
                            tracer.Trace(" Business Days  not  required 1611");
                            taskEndDate = dt.AddDays(Convert.ToDouble(dueDateOffset));
                        }
                        if (businesshours)
                        {
                            if (timeSpandt.Hours <= EndofBusinessHoursTime)
                            {
                                taskEndDate = taskEndDate.AddDays(-1);  //8 

                                if (BusinessDaysRequired)
                                {
                                    if (taskEndDate.DayOfWeek == DayOfWeek.Saturday)
                                    {
                                        taskEndDate = taskEndDate.AddDays(-1);
                                    }
                                    else if (taskEndDate.DayOfWeek == DayOfWeek.Sunday)
                                        taskEndDate = taskEndDate.AddDays(-2);
                                }
                                tracer.Trace("taskEndDate when timeSpandt is less  than 5 " + taskEndDate);
                            }
                            else { taskEndDate = taskEndDate; }
                        }
                        else
                        {
                            taskEndDate = taskEndDate;
                            tracer.Trace("taskEndDate when timeSpandt is greater  than 5 " + taskEndDate);
                        }
                    }

                    else if (dueDateOffset < 0)
                    {
                        tracer.Trace("test3");
                        if (BusinessDaysRequired)
                        {
                            tracer.Trace(" Business Days  required 1634");
                            taskEndDate = CalculateBusinessDays(service, tracer, dt, Convert.ToInt32(dueDateOffset));

                        }

                        else
                        {
                            tracer.Trace("Business Days  not  required 1641");
                            taskEndDate = dt.AddDays(Convert.ToDouble(dueDateOffset));//Changes done
                            tracer.Trace("Business Days  not  required 2060" + taskEndDate);
                        }
                        if (businesshours)
                        {
                            if (timeSpandt <= ts_EndofBusinessHoursTime)
                            {
                                taskEndDate = taskEndDate.AddDays(-1);

                                if (BusinessDaysRequired)
                                {
                                    if (taskEndDate.DayOfWeek == DayOfWeek.Saturday)
                                    {
                                        taskEndDate = taskEndDate.AddDays(-1);
                                    }
                                    else if (taskEndDate.DayOfWeek == DayOfWeek.Sunday)
                                        taskEndDate = taskEndDate.AddDays(-2);
                                }
                                tracer.Trace("taskEndDate when timeSpandt is less  than 5 " + taskEndDate);
                            }
                            else { taskEndDate = taskEndDate; }

                        }
                        else
                        {
                            taskEndDate = taskEndDate;
                            tracer.Trace("taskEndDate when timeSpandt is greater  than 5 " + taskEndDate);
                        }

                    }
                    tracer.Trace("Task End Date  : {0}", taskEndDate);
                }
                else if (dt != DateTime.MinValue && dt < DateTime.Today.AddDays(Convert.ToDouble(dueDateOffset)) && dt.AddDays(Convert.ToDouble(dueDateOffset - 1)) >= DateTime.Now)
                {

                    if (dueDateOffset > 0)
                    {
                        if (BusinessDaysRequired)
                        {
                            tracer.Trace(" Business Days   required 1670");
                            taskEndDate = CalculateBusinessDays(service, tracer, dt, Convert.ToInt32(dueDateOffset));

                        }

                        else
                        {
                            tracer.Trace(" Business Days  not  required 1670");
                            taskEndDate = dt.AddDays(Convert.ToDouble(dueDateOffset));
                        }
                        if (businesshours)
                        {
                            if (timeSpandt.Hours <= EndofBusinessHoursTime)
                            {
                                taskEndDate = taskEndDate.AddDays(-1);

                                if (BusinessDaysRequired)
                                {
                                    if (taskEndDate.DayOfWeek == DayOfWeek.Saturday)
                                    {
                                        taskEndDate = taskEndDate.AddDays(-1);
                                    }
                                    else if (taskEndDate.DayOfWeek == DayOfWeek.Sunday)
                                        taskEndDate = taskEndDate.AddDays(-2);
                                }
                                tracer.Trace("taskEndDate when timeSpandt is less  than 5 " + taskEndDate);
                            }
                            else { taskEndDate = taskEndDate; }

                        }
                        else
                        {
                            taskEndDate = taskEndDate; //ADD a day
                            tracer.Trace("taskEndDate when timeSpandt is greater  than 5 " + taskEndDate);
                        }


                        tracer.Trace("Task End Date when dt is dt < DateTime.Today.AddDays(Convert.ToDouble(dueDateOffset) : {0}", taskEndDate);
                    }
                    else if (dueDateOffset < 0)
                    {

                        if (BusinessDaysRequired)
                        {
                            tracer.Trace(" Business Days   required 1703");
                            taskEndDate = CalculateBusinessDays(service, tracer, dt, Convert.ToInt32(dueDateOffset));

                        }

                        else
                        {
                            tracer.Trace(" Business Days Not  required 1703");
                            taskEndDate = dt.AddDays(Convert.ToDouble(dueDateOffset));
                        }
                        if (businesshours)
                        {
                            if (timeSpandt.Hours <= EndofBusinessHoursTime)
                            {
                                taskEndDate = taskEndDate.AddDays(-1);
                                if (BusinessDaysRequired)
                                {
                                    if (taskEndDate.DayOfWeek == DayOfWeek.Saturday)
                                    {
                                        taskEndDate = taskEndDate.AddDays(-1);
                                    }
                                    else if (taskEndDate.DayOfWeek == DayOfWeek.Sunday)
                                        taskEndDate = taskEndDate.AddDays(-2);
                                }
                                tracer.Trace("taskEndDate when timeSpandt is less  than 5 " + taskEndDate);
                            }
                            else { taskEndDate = taskEndDate; }

                        }
                        else
                        {
                            taskEndDate = taskEndDate;
                            tracer.Trace("taskEndDate when timeSpandt is greater  than 6 " + taskEndDate);
                        }

                        tracer.Trace("Task End Date when dueDateOffset < 0 anddt < DateTime.Today.AddDays(Convert.ToDouble(dueDateOffset)   : {0}", taskEndDate);
                    }


                    else
                    {
                        tracer.Trace("Task now Date : {0}", LocalTime);
                        //taskEndDate = DateTime.Now;
                        taskEndDate = LocalTime;
                    }
                    tracer.Trace("Activities dueDateUnits is : {0}", dueDateOffset);
                }
                if (taskEndDate != DateTime.MinValue)
                {
                    if (dueDateBasedOn.ToLower().Trim() == "opportunity.closedate or end of month")
                    {
                        if (taskEndDate.Month == dt.Month)
                        { //do nothing
                        }
                        else if (taskEndDate.Month != dt.Month || taskEndDate.Year != dt.Year)
                        {
                            var LastDayOfMonth = DateTime.DaysInMonth(dt.Year, dt.Month);
                            tracer.Trace("LastDayOfMonth  " + LastDayOfMonth);
                            taskEndDate = CreateNewDate(dt.Year, dt.Month, LastDayOfMonth, dt);
                            tracer.Trace("taskEndDate WHEN dueDateBased == opportunity.closedate or end of month:  " + taskEndDate);
                        }
                    }

                    taskEndDate = RevertBackToFriday(service, taskEndDate);
                    taskEndDate = taskEndDate.Date + ts_DefaultTime; //adding this to set the time to 5'o clock when unit is days
                    tracer.Trace("taskEndDate when   " + taskEndDate);
                }

            }
            // 
            if (!string.IsNullOrEmpty(dueDateUnits) && dueDateUnits.ToLower() == "hours")
            {
                //taskEndDate = Convert.ToDateTime(dt);

                dueDateOffset = task.GetAttributeValue<decimal>("rsa_duedateoffset");
                tracer.Trace("Activities dueDateUnits in hours : {0}", dueDateOffset); //gives us the value of ABR Task Due date Hrs 

                if (dt != DateTime.MinValue && dt.ToShortDateString() == DateTime.Today.ToShortDateString() && dueDateOffset > 0)
                {
                    if (businesshours)
                    {
                        tracer.Trace("inside hours business hours"); //timespandt is due date based on 
                        if (timeSpandt <= ts_EndofBusinessHoursTime && timeSpandt >= ts_StartofBusinessHoursTime) //within the business hrs.
                        {
                            tracer.Trace("inside hours business hours  " + timeSpandt.Hours); //printing the vlue of current businesshr

                            //  taskEndDate = dt.AddHours(Convert.ToDouble(dueDateOffset)); //added te offset .from next line if it is grater than Busines hrs then we will subtract
                            decimal hoursLeft = dueDateOffset;
                            if (dueDateOffset != 24)
                            {
                                for (int i = 1; i <= dueDateOffset; i++)  //   checking for 24 hrs now
                                {
                                    if (hoursLeft <= 0) { break; }

                                    tracer.Trace("hoursLeft line 2230   " + hoursLeft);
                                    taskEndDate = dt.AddHours(Convert.ToDouble(i));
                                    tracer.Trace("taskEndDate for loop   " + taskEndDate);
                                    if (taskEndDate.TimeOfDay < ts_EndofBusinessHoursTime) //changes done line 2209 2234
                                    {
                                        hoursLeft = hoursLeft - 1;
                                    }

                                    if (taskEndDate.TimeOfDay >= ts_EndofBusinessHoursTime && !(hoursLeft <= 0))
                                    {
                                    AFTER: taskEndDate = taskEndDate.AddDays(1);
                                        taskEndDate = taskEndDate.Date + ts_DefaultStartTime; //9 o clock
                                        tracer.Trace(" taskEndDate line 2244  " + taskEndDate);

                                        for (i = i; i <= dueDateOffset; i++)  //   checking for 24 hrs now
                                        {
                                            taskEndDate = taskEndDate.AddHours(Convert.ToDouble(1));
                                            tracer.Trace(" taskEndDate line 2248  " + taskEndDate);
                                            if (taskEndDate.TimeOfDay < ts_EndofBusinessHoursTime)
                                            {
                                                hoursLeft = hoursLeft - 1;
                                                tracer.Trace("hoursLeft when    " + hoursLeft);
                                            }
                                            if (taskEndDate.TimeOfDay > ts_EndofBusinessHoursTime && hoursLeft != 0) { tracer.Trace("i print    " + i); ; goto AFTER; }

                                        }
                                    }
                                    if (hoursLeft == 0)
                                    {
                                        break;
                                    }

                                }
                            }
                            else
                            {
                                taskEndDate = dt.AddHours(Convert.ToDouble(dueDateOffset));
                            }

                        }
                        else
                        {
                            tracer.Trace("if the dt is outside business hours");
                            if (timeSpandt > ts_EndofBusinessHoursTime)
                            {
                                dt = dt.AddDays(1);//
                                tracer.Trace("when the due date based on is outside the end of  business hrs ");
                            }


                            TimeSpan ts = new TimeSpan(09, 00, 00);
                            dt = dt.Date + ts; //9 o clock
                            taskEndDate = dt.AddHours(Convert.ToDouble(dueDateOffset));
                            tracer.Trace("end date 2288  " + taskEndDate);
                            if (taskEndDate.TimeOfDay >= ts_EndofBusinessHoursTime)
                            {
                                taskEndDate = taskEndDate.AddDays(1);
                                TimeSpan ts1 = new TimeSpan(09, 00, 00);
                                taskEndDate = taskEndDate.Date + ts1; //9 o clock
                                taskEndDate = taskEndDate.AddHours(Convert.ToDouble(dueDateOffset));
                                tracer.Trace("end date 2295  " + taskEndDate);
                            }

                            //taskEndDate = CalculateBusinessDays(service, tracer, dt, Convert.ToInt32(dueDateOffset));//08062021
                        }
                        if (BusinessDaysRequired)
                        {
                            if (taskEndDate.DayOfWeek == DayOfWeek.Saturday)
                            {
                                taskEndDate = taskEndDate.AddDays(2);
                            }
                            else if (taskEndDate.DayOfWeek == DayOfWeek.Sunday)
                                taskEndDate = taskEndDate.AddDays(1);
                        }
                    }
                    else
                    {
                        tracer.Trace("busineshours is false");
                        taskEndDate = dt.AddHours(Convert.ToDouble(dueDateOffset));
                    }
                    tracer.Trace("Activities taskEndDate is : {0}", taskEndDate);


                }
            }
            tracer.Trace(" Task start date and end date is - {0} & {1}", taskStartDate, taskEndDate);

            // //Fix for defect 88. Start date will not be greater than end date

            if (taskStartDate > taskEndDate && opportunityId != Guid.Empty)
            {
                //throw new InvalidPluginExecutionException(string.Format("Activity end date {4} depends on {0} and cannot be less than activity start date {3} as due date offset is : {1} {2} " , dueDateBasedOn ,dueDateOffset, dueDateUnits, taskStartDate,taskEndDate));
                //taskEndDate= taskStartDate ;
                if (taskEndDate.Hour >= EndofBusinessHoursTime)
                {
                    taskEndDate = taskEndDate.AddDays(1);
                    TimeSpan ts = new TimeSpan(09, 00, 00);
                    taskEndDate = taskEndDate.Date + ts; //9 o clock
                    taskEndDate = taskEndDate.AddHours(Convert.ToDouble(dueDateOffset));
                }

            }




            #endregion

            return taskEndDate;
        }
        private static DateTime GetCasesDates(IOrganizationService service, Guid caseId, string fieldName)
        {
            try
            {
                DateTime date = DateTime.MinValue;
                var oppLookup = service.Retrieve("incident", caseId, new ColumnSet("createdon"));
                if (oppLookup != null)
                {
                    date = Convert.ToDateTime(oppLookup.Attributes["createdon"]);
                }
                return date;
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        private static DateTime GetOpportunityDate(IOrganizationService service, Guid opportunityId, string fieldName)
        {
            try
            {
                DateTime date = DateTime.MinValue;
                var oppLookup = service.Retrieve("opportunity", opportunityId, new ColumnSet("" + fieldName + ""));
                if (oppLookup != null)
                {
                    date = Convert.ToDateTime(oppLookup.Attributes["" + fieldName + ""]);
                }
                return date;
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        public static DateTime CalculateBusinessDays(IOrganizationService service, ITracingService tracer, DateTime dt, int numberOfDays)
        {
            try
            {
                int offset = numberOfDays;


                var timeSpandt = dt.TimeOfDay;
                tracer.Trace("timeSpandt 2224 line " + timeSpandt);
                DateTime duedate = dt;
                //Defect id 2098 : Sumegh Dhole : Change for considering the due date offset if marked as negative 
                if (offset > 0)
                {
                    for (int i = 0; i < offset; i++)
                    {
                        duedate = duedate.AddDays(1);

                        if (duedate.DayOfWeek == DayOfWeek.Saturday || duedate.DayOfWeek == DayOfWeek.Sunday)
                        {
                            duedate = duedate.AddDays(2);
                        }
                    }
                }
                else
                {
                    for (int i = 0; i > offset; i--)
                    {
                        duedate = duedate.AddDays(-1);

                        if (duedate.DayOfWeek == DayOfWeek.Saturday || duedate.DayOfWeek == DayOfWeek.Sunday)
                        {
                            duedate = duedate.AddDays(-2);
                        }
                    }
                }

                return duedate;
            }

            catch (Exception ex)
            {
                tracer.Trace("CalculateBusinessDays-Error" + ex.Message.ToString());
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
        public static DateTime RevertBackToFriday(IOrganizationService service, DateTime taskEndDate)
        {
            try
            {
                switch (taskEndDate.DayOfWeek)
                {
                    case DayOfWeek.Saturday:
                        taskEndDate = taskEndDate.AddDays(-1);
                        break;
                    case DayOfWeek.Sunday:
                        taskEndDate = taskEndDate.AddDays(-2);
                        break;
                    default:
                        break;
                }


                return taskEndDate;
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
        public static DateTime CreateNewDate(int year, int month, int day, DateTime time)
        {
            return new DateTime(year, month, day, time.Hour, time.Minute, 0);
        }
        public static int? RetrieveCurrentUsersSettings(IOrganizationService service)

        {

            var currentUserSettings = service.RetrieveMultiple(

                new QueryExpression("usersettings")

                {

                    ColumnSet = new ColumnSet("timezonecode"),

                    Criteria = new FilterExpression

                    {

                        Conditions =

                        {

                            new ConditionExpression("systemuserid", ConditionOperator.EqualUserId)

                        }

                    },

                    NoLock = true

                }).Entities[0].ToEntity<Entity>();

            //return time zone code

            return (int?)currentUserSettings.Attributes["timezonecode"];

        }
        public static DateTime RetrieveLocalTimeFromUTCTime(DateTime utcTime, int? timeZoneCode, IOrganizationService service)

        {

            if (!timeZoneCode.HasValue)

                return DateTime.Now;

            var request = new LocalTimeFromUtcTimeRequest

            {

                TimeZoneCode = timeZoneCode.Value,

                UtcTime = utcTime.ToUniversalTime()

            };

            var response = (LocalTimeFromUtcTimeResponse)service.Execute(request);

            return response.LocalTime;

        }
        public static DateTime RetrieveUTCTimeFromLocalTime(DateTime localTime, int? timeZoneCode, IOrganizationService service)

        {

            if (!timeZoneCode.HasValue)

                return DateTime.Now;


            var request = new UtcTimeFromLocalTimeRequest

            {

                TimeZoneCode = timeZoneCode.Value,

                LocalTime = localTime

            };

            var response = (UtcTimeFromLocalTimeResponse)service.Execute(request);

            return response.UtcTime;

        }



        public static int setPromiseNonPromise(IOrganizationService service, Entity entity, ITracingService tracer)
        {
            int promiseValue = 0;
            EntityReference caseType = entity.Attributes.Contains("rsa_casetype") ? entity.GetAttributeValue<EntityReference>("rsa_casetype") : null;
            EntityReference opportunityId = entity.Attributes.Contains("rsa_opportunityid") ? entity.GetAttributeValue<EntityReference>("rsa_opportunityid") : null;
            EntityReference BrokerId = entity.Attributes.Contains("rsa_account") ? entity.GetAttributeValue<EntityReference>("rsa_account") : null;
            EntityReference policyId = entity.Attributes.Contains("rsa_policyid") ? entity.GetAttributeValue<EntityReference>("rsa_policyid") : null;
            EntityReference pandl = null;
            string promiseBroker = entity.Attributes.Contains("rsa_promisebroker") ? entity.GetAttributeValue<string>("rsa_promisebroker") : string.Empty;
            string promiseNewBusiness = null;
            string promiseRenewal = string.Empty;
            if (caseType != null)
            {
                tracer.Trace("case type found:" + caseType.Id);
                if (BrokerId != null)
                {
                    Entity BrokerData = service.Retrieve(BrokerId.LogicalName, BrokerId.Id, new ColumnSet(new string[] { "rsa_promisenewbusiness", "rsa_promiserenewal" }));
                    promiseNewBusiness = BrokerData.FormattedValues.ContainsKey("rsa_promisenewbusiness") ? BrokerData.FormattedValues["rsa_promisenewbusiness"] : null;
                    tracer.Trace("promise broker from broker value" + promiseNewBusiness);
                    promiseRenewal = BrokerData.FormattedValues.ContainsKey("rsa_promiserenewal") ? BrokerData.FormattedValues["rsa_promiserenewal"] : null;
                    tracer.Trace("promise renewal broker from broker value" + promiseRenewal);
                }



                if ((opportunityId != null && policyId != null) || (opportunityId != null && policyId == null))
                {
                    Entity opptyPl = service.Retrieve(opportunityId.LogicalName, opportunityId.Id, new ColumnSet(new string[] { "rsa_pandlid" }));
                    pandl = opptyPl.Attributes.Contains("rsa_pandlid") ? opptyPl.GetAttributeValue<EntityReference>("rsa_pandlid") : null;
                    tracer.Trace("pandl" + pandl);
                }
                else if (opportunityId == null && policyId != null)
                {
                    Entity policyPl = service.Retrieve(policyId.LogicalName, policyId.Id, new ColumnSet(new string[] { "rsa_plcode" }));
                    pandl = policyPl.Attributes.Contains("rsa_plcode") ? policyPl.GetAttributeValue<EntityReference>("rsa_plcode") : null;
                    tracer.Trace("pandl" + pandl);
                    //entity["rsa_pl_w"] = pandl.Name;
                }
                if (caseType.Name.ToLowerInvariant().Equals("new business") || caseType.Name.ToLowerInvariant().Equals("schemes - bordereaux"))
                {
                    tracer.Trace("case type name:" + caseType.Name);
                    if (promiseNewBusiness != null && pandl != null && promiseNewBusiness.ToLowerInvariant().Contains(pandl.Name.ToLowerInvariant()))
                    {
                        tracer.Trace("Promise about to set");
                        //entity["rsa_promise"] = new OptionSetValue(866760000);
                        promiseValue = 866760000;
                    }
                    else if (promiseNewBusiness != null && pandl != null && !promiseNewBusiness.ToLowerInvariant().Contains(pandl.Name.ToLowerInvariant()))
                    {
                        tracer.Trace("Non Promise about to set");
                        //entity["rsa_promise"] = new OptionSetValue(866760001);
                        promiseValue = 866760001;
                    }


                }
                else if (caseType.Name.ToLowerInvariant().Equals("renewal"))
                {
                    if (promiseRenewal != null && pandl != null && promiseRenewal.ToLowerInvariant().Contains(pandl.Name.ToLowerInvariant()))
                    {
                        tracer.Trace("Promise renewal about to set");
                        //enCaseTarget["rsa_promise"] = new OptionSetValue(866760000);
                        promiseValue = 866760000;
                    }
                    else if (promiseRenewal != null && pandl != null && !promiseRenewal.ToLowerInvariant().Contains(pandl.Name.ToLowerInvariant()))
                    {
                        tracer.Trace("Non Promise about to set 1");
                        //enCaseTarget["rsa_promise"] = new OptionSetValue(866760001);
                        promiseValue = 866760001;
                    }
                    else
                    {

                        tracer.Trace("Non Promise about to set 2");
                        //enCaseTarget["rsa_promise"] = new OptionSetValue(866760001);
                        promiseValue = 866760001;
                    }

                }
            }
            return promiseValue;
        }




        public static EntityCollection getStatusApplicable(ITracingService tracer,Guid Casetype,IOrganizationService service)
        {
            {
                QueryExpression exp = new QueryExpression("rsa_status");
                exp.NoLock = true;
                exp.ColumnSet = new ColumnSet(new string[] { "rsa_name","rsa_status", "rsa_statuscode" });
                exp.Criteria = new FilterExpression();
                exp.Criteria.AddCondition("rsa_casetype", ConditionOperator.Equal, Casetype);
              
                
                tracer.Trace("Retrieve Status");
                EntityCollection statusCollection = service.RetrieveMultiple(exp);
                tracer.Trace("Retieve opportunity Status Completed: " + statusCollection.Entities.Count);

                return statusCollection;
            }
        }
    public static  List<string> ListofTaskCreated(EntityReference Case,  Entity task, ITracingService tracer, IOrganizationService service) {
            EntityCollection existingTasks = null;
        if (task["regardingobjectid"] != null && ((EntityReference)task["regardingobjectid"]).LogicalName == "incident")
        {
            string Existing_Taak = "<fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>";
            Existing_Taak += "<entity name='task'>";
            Existing_Taak += "<attribute name='subject' />";
            Existing_Taak += "<attribute name='statecode' />";
            Existing_Taak += "<attribute name='prioritycode' />";
            Existing_Taak += "<attribute name='scheduledend' />";
            Existing_Taak += "<attribute name='createdby' />";
            Existing_Taak += "<attribute name='regardingobjectid' />";
            Existing_Taak += "<attribute name='activityid' />";
            Existing_Taak += "<attribute name='rsa_nextcallduedatetime' />";
            Existing_Taak += "<order descending='true' attribute='modifiedon' />";
            Existing_Taak += "<filter type='and'>";
            Existing_Taak += "<condition attribute='regardingobjectid' value='" + Case.Id + "' uitype='incident' uiname='' operator='eq' />"; //case id
            Existing_Taak += "<condition attribute='statuscode' value='5' operator='ne' />";
            Existing_Taak += "</filter>";
            Existing_Taak += "</entity>";
            Existing_Taak += "</fetch>";
            existingTasks = service.RetrieveMultiple(new FetchExpression(Existing_Taak));
            tracer.Trace("After RetrieveMultiple");
        }
            List<string> list_ExistingABRNames = new List<string>();
            if (existingTasks.Entities.Count > 0) {
                foreach (var en in existingTasks.Entities) {
                    string subject = en.GetAttributeValue<string>("subject");
                   list_ExistingABRNames.Add((Convert.ToString(subject)));
                } }

            return list_ExistingABRNames;
    } 
}
    public class Incident
    {
        public int Status { get; set; }//  rsa_Status
        public int TransactiontType { get; set; }  //rsa_transactiontype
        public int Promise { get; set; }//rsa_Promise d
        public int Traded { get; set; }//rsa_Traded  d
        public int Active { get; set; }//statecode
        public int CustomerType { get; set; }//rsa_CustomerType d        
        public bool EnforcePostFulfillment { get; set; }
        public int TriggerinObjectRecordType { get; set; }   //rsa_RecordType
        public int CaseReason { get; set; } //rsa_casereason na
        public int RenewalReviewType { get; set; } //rsa_RenewalReviewType d
        public int ClassofBusiness { get; set; } //rsa_ClassofBusiness d
        public bool ApplyR90conditions { get; set; }
        public int BrokerPrimaryReference { get; set; } //rsa_brokerprimaryreference
        public int Productsme { get; set; }
        public int KeySMEBroker { get; set; }
        public int Dealscase { get; set; }
    }
    public class Applicablevalue
    {
        [DataMember]
        public string key { get; set; }
        [DataMember]
        public string Value { get; set; }
    }
    [DataContract]
    public class ABRMultiselect
    {
        [DataMember]
        public string AttributeName { get; set; }
        [DataMember]
        public List<Applicablevalue> Applicablevalues { get; set; }
    }
    [DataContract]
    public class ABROptionsetRoot
    {
        [DataMember]
        public List<ABRMultiselect> ABRMultiselect { get; set; }
    }

}
