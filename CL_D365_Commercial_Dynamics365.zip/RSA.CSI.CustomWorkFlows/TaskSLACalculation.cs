﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using RSA.CSI.CustomWorkFlows.Helper;
using System;
using System.Activities;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;
using static RSA.CSI.CustomWorkFlows.Helper.Constants;

namespace RSA.CSI.CustomWorkFlows
{
    public class TaskSLACalculation : CodeActivity
    {
        [RequiredArgument]
        [ReferenceTarget("task")]
        [Input("task")]
        public InArgument<EntityReference> TaskEntity { get; set; }


        [ReferenceTarget("incident")]
        [Input("Case")]
        public InArgument<EntityReference>CaseEntity{ get; set; }
        protected override void Execute(CodeActivityContext _executionContext)
        {
            IWorkflowContext _context = _executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = _executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(_context.InitiatingUserId);
            ITracingService tracer = _executionContext.GetExtension<ITracingService>();
            EntityReference caseId = null;
            Entity en_Case= new Entity();
            Entity TaskEn = new Entity();
            string TaskName = string.Empty;
            EntityReference task = null;
            #region Get Input Parameters Value

            if (TaskEntity != null)
            {
                tracer.Trace("task New check");
                task = TaskEntity.Get<EntityReference>(_executionContext);
                tracer.Trace("task New" + task.Id);
                TaskEn = service.Retrieve(task.LogicalName, task.Id, new ColumnSet("subject"));
                tracer.Trace("TaskEn check  " + TaskEn.Attributes.Count);
                TaskName = TaskEn.GetAttributeValue<string>("subject");
                tracer.Trace("TaskName   " + TaskName);
            }


            //if (TaskEntity != null)
            //{
            //    task = TaskEntity.Get<EntityReference>(_executionContext);
            //    Guid taskid = task.Id;

            //    tracer.Trace("taskId   ", taskid.ToString());
            //    if (taskid != null)
            //    {
            //        TaskEn = service.Retrieve("task", taskid, new ColumnSet("regardingobjectid", "rsa_name"));
            //        TaskName = TaskEn.GetAttributeValue<string>("rsa_name");
            //        tracer.Trace("name  ", TaskName);
            //    }

            //}

            if (CaseEntity != null)
            {
               EntityReference ref_Case = CaseEntity.Get<EntityReference>(_executionContext);
                tracer.Trace("REF_Case   "+ ref_Case.Id);
                 en_Case = service.Retrieve(ref_Case.LogicalName, ref_Case.Id, new ColumnSet("rsa_status", "ownerid", "caseorigincode", "rsa_opportunityorigin", "rsa_keysmebroker", "rsa_dealscase", "rsa_dealcheck", "rsa_dealbroker", "rsa_customertype", "rsa_customername", "rsa_customerrsa", "rsa_casereceiveddate", "rsa_casereasonrsa", "rsa_brokerprimaryreference", "rsa_applyr90conditions", "rsa_brokercommitmentimage", "rsa_accountnumber", "accountid", "rsa_account", "rsa_branchaccount", "rsa_distributioncategory", "rsa_scheme", "rsa_classofbusinesssme",
"rsa_classofbusiness", "rsa_classofbusinessphoneenqid", "rsa_opportunityid",
"rsa_policyid", "rsa_casetype", "rsa_basepremiumrsa", "rsa_cobextranet", "rsa_clientname", "createdon",
"rsa_rsapolicyfulfilmentactivities", "rsa_productphoneenqid", "productid", "rsa_product_w", "rsa_productlivechat",
"rsa_productsmev2", "rsa_productholder", "rsa_promise", "rsa_promisebroker", "rsa_rsarecordtype", "rsa_renewalreviewtype",
"statecode", "rsa_transaction", "rsa_traded", "rsa_transactiontypeid"));

            }


            #endregion
            if (en_Case != null && !string.IsNullOrEmpty(TaskName))
            {
                DateTime TaskEndDate = SLA_Logic.GetABRTemplate(_context, en_Case, TaskName, service, tracer);
                tracer.Trace("TaskEndDate line 64  " + TaskEndDate);
               
                TaskEn["scheduledend"] = TaskEndDate;
                TaskEn["rsa_duedatetime"] = TaskEndDate;
                service.Update(TaskEn);
            }


        }
    }
}


