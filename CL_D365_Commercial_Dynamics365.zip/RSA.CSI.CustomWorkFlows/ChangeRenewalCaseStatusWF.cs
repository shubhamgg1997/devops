﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using RSA.CSI.CustomWorkFlows.Helper;
using System;
using System.Activities;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk.Messages;
using static RSA.CSI.CustomWorkFlows.Helper.Constants;


namespace RSA.CSI.CustomWorkFlows
{
    public class ChangeRenewalCaseStatusWF : CodeActivity
    {
        #region Input Parameters
        [ReferenceTarget("incident")]
        [Input("Case")]
        public InArgument<EntityReference> caseEntity { get; set; }

        [ReferenceTarget("rsa_classofbusiness")]
        [Input("Class of Business")]
        public InArgument<EntityReference> policyClassofBusiness { get; set; }

        [Input("Operations Handling Site")]
        [AttributeTarget("rsa_policy", "rsa_operationshandlingsite")]
        public InArgument<OptionSetValue> rsa_operationshandlingsite { get; set; }

        [ReferenceTarget("systemuser")]
        [Input("Case Owner")]
        public InArgument<EntityReference> caseOwner { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext _executionContext)
        {
            var ms = Stream.Null;
            try
            {
                IWorkflowContext _context = _executionContext.GetExtension<IWorkflowContext>();
                IOrganizationServiceFactory serviceFactory = _executionContext.GetExtension<IOrganizationServiceFactory>();
                IOrganizationService service = serviceFactory.CreateOrganizationService(_context.InitiatingUserId);

                ITracingService tracingService = _executionContext.GetExtension<ITracingService>();
                EntityReference caseId = null;
                EntityReference policyCOB = null;
                EntityReference renewalCaseOwner = null;
                int operationshandlingsite = int.MinValue;

                #region Get Input Parameters Value
                if (caseEntity != null)
                {
                    caseId = caseEntity.Get<EntityReference>(_executionContext);
                }

                if (policyClassofBusiness != null)
                {
                    policyCOB = policyClassofBusiness.Get<EntityReference>(_executionContext);
                }

                if (rsa_operationshandlingsite != null)
                {
                    operationshandlingsite = rsa_operationshandlingsite.Get<OptionSetValue>(_executionContext).Value;
                }

                if (caseOwner != null)
                {
                    renewalCaseOwner = caseOwner.Get<EntityReference>(_executionContext);
                }

                #endregion

                tracingService.Trace("Updating case status: " + caseId.Id.ToString());
                Entity enUpdateCase = new Entity(caseId.LogicalName, caseId.Id);

                if (renewalCaseOwner != null)
                {   //Modified on -05/05 ;Modified By-Nida;Details:defect 2511 : Unassigned has neen handled in ABR/Case hence commented 

                    //enUpdateCase["ownerid"] = renewalCaseOwner;
                    //tracingService.Trace("ownerid" + renewalCaseOwner.Name);
                }
                //////////////////////
                bool isIsieOfMan = false;
                if (operationshandlingsite != int.MinValue && operationshandlingsite.ToString() == TRADE_CENTER_ISIE_OF_MAN)
                {
                    tracingService.Trace("Trade Center is Isie of Man");
                    string strPolicyCOB = policyCOB.Name;
                    if (strPolicyCOB == COB_COMBINED || strPolicyCOB == COB_CONSTRUCTION || strPolicyCOB == COB_LIABILITY || strPolicyCOB == COB_MOTOR_FLEET ||
                        strPolicyCOB == COB_MOTOR_TRADE || strPolicyCOB == COB_PROFIN_LONDDON_PI || strPolicyCOB == COB_PROFIN_LONDON_AH || strPolicyCOB == COB_PROFIN_SCOTTISH_BOND ||
                        strPolicyCOB == COB_PROPERTY || strPolicyCOB == COB_PROPERTY_OWNERS)
                    {
                        tracingService.Trace("Isie of Man related Class of business found");
                        isIsieOfMan = true;
                        enUpdateCase["rsa_status"] = new EntityReference("rsa_status", new Guid(CASE_STATUS_TO_BE_QUOTED));
                        tracingService.Trace("Case Status set ad To be Quoted");
                    }
                }

                if (isIsieOfMan == false)
                {
                    tracingService.Trace("Other Trade Center");
                    //// Defect#: 2093, 2098: Atul Agrawal
                    QueryExpression ABRExpression = new QueryExpression("rsa_customlabel");
                    ABRExpression.TopCount = 1;
                    ABRExpression.NoLock = true;
                    ABRExpression.ColumnSet = new ColumnSet(new string[] { "rsa_dependentoptionsetjson" });
                    ABRExpression.Criteria = new FilterExpression();
                    ABRExpression.Criteria.AddCondition("rsa_name", ConditionOperator.Equal, "CaseRenewalStatus");
                    EntityCollection abrCustomLabel = service.RetrieveMultiple(ABRExpression);

                    string dependentOptionset = string.Empty;

                    foreach (var item in abrCustomLabel.Entities)
                    {
                        dependentOptionset = Convert.ToString(item.Attributes["rsa_dependentoptionsetjson"]);
                    }

                    //tracingService.Trace("Custom Label Mapping retrieved: CaseRenewalStatus" + dependentOptionset);

                    var objRSRoot = new RSRootObject();
                    //var ms = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(dependentOptionset));
                    //var ser = new DataContractJsonSerializer(objRSRoot.GetType());
                    //objRSRoot = ser.ReadObject(ms) as RSRootObject;
                    //ms.Close();
                    //Remediation - 20/07/2022
                    ms = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(dependentOptionset));
                    var ser = new DataContractJsonSerializer(objRSRoot.GetType());
                    objRSRoot = ser.ReadObject(ms) as RSRootObject;
                    tracingService.Trace("After Close");
                    if (objRSRoot != null)
                    {
                        if (objRSRoot.RenewalStatus != null)
                        
                        {
                            //Get the broker primary reference value to compare and get the ABR. 
                            RenewalStatus objRS = objRSRoot.RenewalStatus.Find(a => a.Classofbusiness.ToLower().Equals(policyCOB.Name.ToLower()));
                            //tracingService.Trace("Obj RS: " + objRS + " Policy COB: " + policyCOB.Name.ToLower());
                            if (objRS != null && objRS.NextStatus != null)
                            {
                                //Samiksha Dhakde - 01 July 2022
                                //TFS 27 - Setting next status of case generated from renewal generation

                                tracingService.Trace("Obj RS: " + objRS);
                                List<NextStatus> nextStatus = objRS.NextStatus;
                                foreach (NextStatus status in nextStatus)
                                {
                                    enUpdateCase["rsa_status"] = new EntityReference("rsa_status", new Guid(status.StatusGUID));
                                    tracingService.Trace("Case Status mapped with value : " + status.StatusGUID.ToString() + " - " + status.StatusName.ToString() + " - " + status.StatusOrder);
                                    service.Update(enUpdateCase);
                                }
                                // TFS 27 - END

                                ////Modified on -05/05 ;Modified By-Nida;Details:defect 2511 : Update status as per Json Sequence
                                //foreach (string item in objRS.StatusGUID)
                                //{                                   
                                //    enUpdateCase["rsa_status"] = new EntityReference("rsa_status", new Guid(item));
                                //    tracingService.Trace("Case Status mapped with value : " + item + " - " + objRS.Status.ToString());
                                //}
                                //enUpdateCase["rsa_status"] = new EntityReference("rsa_status", new Guid(objRS.StatusGUID)); //Commented by Samiksha
                                //tracingService.Trace("Case Status mapped with value : " + objRS.StatusGUID.ToString() + " - " + objRS.Status.ToString());  // Commented by Samiksha
                            }
                            else
                            {
                                //tracingService.Trace("ObjRS is null");
                                tracingService.Trace("ObjRS is null or COB does not have next status"); //Updated by Samiksha - TFS_27
                            }
                        }
                        else { tracingService.Trace("ObjRSRoot is null"); }

                    }
                    else
                    {
                        tracingService.Trace("objRSRoot is null");
                    }
                }

                //////////////////////
                service.Update(enUpdateCase);
                tracingService.Trace("Case Updated Successfully");
            }
            catch (Exception err)
            {
                throw new InvalidPluginExecutionException(err.Message);
            }
            finally 
            {
                ms.Close();
            }
        }

    }
}
