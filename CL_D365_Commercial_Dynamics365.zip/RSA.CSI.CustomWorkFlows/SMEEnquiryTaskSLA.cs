﻿using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;


namespace RSA.CSI.CustomWorkFlows
{
    public class SMEEnquiryTaskSLA : CodeActivity
    {
        [RequiredArgument]
        [ReferenceTarget("task")]
        [Input("task")]
        public InArgument<EntityReference> TaskEntity { get; set; }

        TimeSpan ts_DefaultStartTime = new TimeSpan(09, 00, 00);
        TimeSpan ts_DefaultEndTime = new TimeSpan(17, 00, 00);

        protected override void Execute(CodeActivityContext executionContext)
        {
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.InitiatingUserId);
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();

            EntityReference taskId = TaskEntity.Get<EntityReference>(executionContext);
            Entity enTask = new Entity(taskId.LogicalName);

            var task = service.Retrieve(taskId.LogicalName, taskId.Id, new ColumnSet("createdon", "rsa_duedatetime", "scheduledend", "regardingobjectid"));
            tracingService.Trace("Task Id : " + taskId.Id);
            

            try
            {
                if (TaskEntity != null)
                {
                    tracingService.Trace("Retrived Task Entity");
                    // SME Enquiry SLA Calculation
                    DateTime activityCreatedDate = task.GetAttributeValue<DateTime>("createdon");
                   
                    tracingService.Trace("UK Start time : " + activityCreatedDate);
                    
                    int? userTimezone = RetrieveCurrentUsersSettings(service);
                    tracingService.Trace("userTimezone" + userTimezone);
                    DateTime startDatetime = RetrieveLocalTimeFromUTCTime(activityCreatedDate.ToUniversalTime(), userTimezone, service);
                    
                    tracingService.Trace("UK Start time : " + startDatetime);
                   
                    DateTime validStartDate = ValidateStartDateTime(startDatetime, service, tracingService);
                   
                    tracingService.Trace("Start Date after validation : " + validStartDate);
                    
                    enTask["rsa_duedatetime"] = validStartDate.AddDays(7);
                    enTask["scheduledend"] = validStartDate.AddDays(7);
                    
                    enTask.Id = task.Id;
                    service.Update(enTask);

                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }

        }


        public int? RetrieveCurrentUsersSettings(IOrganizationService service)
        {
            var currentUserSettings = service.RetrieveMultiple(

                new QueryExpression("usersettings")
                {
                    ColumnSet = new ColumnSet("timezonecode"),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("systemuserid", ConditionOperator.EqualUserId)
                        }
                    },
                    NoLock = true
                }).Entities[0].ToEntity<Entity>();

            //return time zone code
            return (int?)currentUserSettings.Attributes["timezonecode"];
        }


        public DateTime RetrieveLocalTimeFromUTCTime(DateTime utcTime, int? timeZoneCode, IOrganizationService service)
        {
            if (!timeZoneCode.HasValue)
                return DateTime.Now;
            var request = new LocalTimeFromUtcTimeRequest
            {
                TimeZoneCode = timeZoneCode.Value,
                UtcTime = utcTime.ToUniversalTime()

            };
            var response = (LocalTimeFromUtcTimeResponse)service.Execute(request);
            return response.LocalTime;
        }

        // StartDate validation if outside business hours.
        public DateTime ValidateStartDateTime(DateTime validStartDate, IOrganizationService service, ITracingService tracer)
        {
            if (validStartDate.TimeOfDay < ts_DefaultStartTime)
            {
                validStartDate = new DateTime(validStartDate.Year, validStartDate.Month, validStartDate.Day, 9, 0, 0);
            }
            if (validStartDate.TimeOfDay > ts_DefaultEndTime)
            {
                validStartDate = new DateTime(validStartDate.Year, validStartDate.Month, validStartDate.Day, 9, 0, 0).AddDays(1);
            }
            if (validStartDate.DayOfWeek == DayOfWeek.Saturday)
            {
                validStartDate = new DateTime(validStartDate.Year, validStartDate.Month, validStartDate.Day, 9, 0, 0).AddDays(2);
            }
            if (validStartDate.DayOfWeek == DayOfWeek.Sunday)
            {
                validStartDate = new DateTime(validStartDate.Year, validStartDate.Month, validStartDate.Day, 9, 0, 0).AddDays(1);
            }
            return validStartDate;
        }
    }
}

       
