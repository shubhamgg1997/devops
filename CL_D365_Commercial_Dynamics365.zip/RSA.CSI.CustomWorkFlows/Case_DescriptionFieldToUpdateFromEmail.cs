﻿using Microsoft.Xrm.Sdk;
using System;
using System.ServiceModel;
using System.Activities;
using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using System.Text.RegularExpressions;
using System.Text;

namespace RSA.CSI.CustomWorkFlows
{
    public class Case_DescriptionFieldToUpdateFromEmail : CodeActivity
    {
        #region Input Parameters
        [RequiredArgument]
        [ReferenceTarget("incident")]
        [Input("case")]

        public InArgument<EntityReference> entity { get; set; }        

        #endregion


        protected override void Execute(CodeActivityContext _executionContext)
        {
            IWorkflowContext _context = _executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = _executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService _service = serviceFactory.CreateOrganizationService(_context.InitiatingUserId);

            ITracingService _tracingService = _executionContext.GetExtension<ITracingService>();            
            
            
            if (entity != null)
            {
                _tracingService.Trace("Retrived case Entity");
                
                EntityReference enCase = entity.Get<EntityReference>(_executionContext);
                
                Entity Case = new Entity(enCase.LogicalName);
                Guid caseGuid = enCase.Id;
                _tracingService.Trace("caseGuid: " + caseGuid);
                
                string  emailBody = GetEmailBody(_service, _tracingService, caseGuid);
                    _tracingService.Trace("emailBody: " + emailBody);
                //emailBody = Regex.Replace(emailBody, "<.*?>", String.Empty);
                
                if (!emailBody.Equals(string.Empty))
                {
                    emailBody = HtmlToPlainText(emailBody);
                    Case["description"] = emailBody;
                }
                        
                
                Case.Id = caseGuid;
                _service.Update(Case);
            }
            _tracingService.Trace("Case Description has been updated.");
        }

        public static string HtmlToPlainText(string HTMLCode)
        {
            //string text;
            HTMLCode = HTMLCode.Replace("\n", " ");

            // Remove tab spaces
            HTMLCode = HTMLCode.Replace("\t", " ");

            // Remove multiple white spaces from HTML
            HTMLCode = Regex.Replace(HTMLCode, "\\s+", " ");

            // Remove HEAD tag
            HTMLCode = Regex.Replace(HTMLCode, "<head.*?</head>", ""
                                , RegexOptions.IgnoreCase | RegexOptions.Singleline);

            // Remove any JavaScript
            HTMLCode = Regex.Replace(HTMLCode, "<script.*?</script>", ""
              , RegexOptions.IgnoreCase | RegexOptions.Singleline);

            // Replace special characters like &, <, >, " etc.
            StringBuilder sbHTML = new StringBuilder(HTMLCode);
            // Note: There are many more special characters, these are just
            // most common. You can add new characters in this arrays if needed
            string[] OldWords = {"&nbsp;", "&amp;", "&quot;", "&lt;",
   "&gt;", "&reg;", "&copy;", "&bull;", "&trade;","&#39;"};
            string[] NewWords = { " ", "&", "\"", "<", ">", "Â®", "Â©", "â€¢", "â„¢", "\'" };
            for (int i = 0; i < OldWords.Length; i++)
            {
                sbHTML.Replace(OldWords[i], NewWords[i]);
            }

            // Check if there are line breaks (<br>) or paragraph (<p>)
            sbHTML.Replace("<br>", "\n<br>");
            sbHTML.Replace("<br ", "\n<br ");
            sbHTML.Replace("<p ", "\n<p ");
            sbHTML.Replace("<br>", "");
            // Finally, remove all HTML tags and return plain text
            return System.Text.RegularExpressions.Regex.Replace(
              sbHTML.ToString(), "<[^>]*>", "");

            //return htmlString;
        }

        public string GetEmailBody(IOrganizationService service, ITracingService tracingService, Guid caseId)
        {            
            string emailBody = string.Empty;
            var fetchXml = @"<fetch distinct='true' mapping='logical' output-format='xml-platform' version='1.0' no-lock='true'>
					<entity name='email'>
					<attribute name='subject'/>
					<attribute name='regardingobjectid'/>
					<attribute name='statuscode'/>
					<attribute name='modifiedon'/>
					<attribute name='activityid'/>
					<attribute name='createdon'/>
					<attribute name='rsa_htmlbody'/>
					<attribute name='description'/>
					<order descending='false' attribute='createdon'/>
					<filter type='and'>
						<condition attribute='regardingobjectid' value='{0}' uitype='incident' operator='eq'/>
					</filter>
				</entity>
				</fetch>";
            try
            {
                var enEmailBody = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, caseId)));
                if (enEmailBody != null && enEmailBody.Entities.Count > 0)
                {
                    emailBody = enEmailBody[0].Attributes.Contains("description") ? Convert.ToString(enEmailBody[0].Attributes["description"]) : string.Empty;
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetching GetEmailBody in GetEmailBody:" + ex.Message);
            }
            return emailBody;
        }


    }

}
