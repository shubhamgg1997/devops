﻿using Microsoft.Xrm.Sdk;
using RSA.CSI.Plugins.Activities.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using RSA.CSI.Plugins.Activities.Logic;

namespace RSA.CSI.Plugins.Activities
{
    public class PreValidate : PluginBase
    {
        public PreValidate()
           : base(typeof(PreCreate))
        {
            base.RegisteredEvents.Add(new Tuple<int, string, string, Action<LocalPluginContext>>(10, "Create", "task", Execute));
        }

        protected void Execute(LocalPluginContext localContext)
        {
            #region Generate context, service & tracing service objects.
            if (localContext == null)
            {
                //throw new ArgumentNullException("localContext is null.");
                //Remediation - 15/07/2022
                throw new InvalidPluginExecutionException("localContext is null.");
            }
            IPluginExecutionContext context = localContext.PluginExecutionContext;
            IOrganizationService service = localContext.OrganizationService;
            ITracingService tracingService = localContext.TracingService;
            #endregion

            Entity entity;
            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                entity = (Entity)context.InputParameters["Target"];
                try
                {
                    if (entity.Attributes.Contains("rsa_duedatetime"))
                    {
                        tracingService.Trace("TaskLogic=>PreValidation() logic- Loaded.");
                        TaskManagementLogic task = new TaskManagementLogic(service, tracingService, entity,null,null, context.InitiatingUserId);
                        //task.PreValidation();
                        tracingService.Trace("TaskLogic=>PreValidation() logic- Unloaded.");
                        //throw new InvalidPluginExecutionException("You have set the Due Date/Time either on a weekend Or on a Bank Holiday. Please see that the Due Date should be a working day.");
                        
                    }
                }
                catch (InvalidPluginExecutionException ex)
                {
                    //throw new InvalidPluginExecutionException(ex.Message);
                    tracingService.Trace($"InvalidPluginExecutionException.Error:{ex.Message}");
                    //exception = ex;
                    throw new InvalidPluginExecutionException(ex.Message);
                }
                catch (Exception ex)
                {
                    tracingService.Trace($"Exception.Error:{ex.Message}");
                    //exception = ex;
                    //throw new Exception(ex.Message);
                    //Remediation - 15/07/2022
                    throw new InvalidPluginExecutionException(ex.Message);
                    //tracingService.Trace("An error occurred in Task.PreCreate plugin. Details: '{0}'", ex.Message);
                }
            }
        }
    }
}