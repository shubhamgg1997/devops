﻿using Microsoft.Xrm.Sdk;
using RSA.CSI.Plugins.Activities.Common;
using RSA.CSI.Plugins.Activities.Logic;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Crm.Sdk.Messages;


namespace RSA.CSI.Plugins.Activities
{
    public class PostUpdate : PluginBase
    {
        public PostUpdate()
            : base(typeof(PostUpdate))
        {
            base.RegisteredEvents.Add(new Tuple<int, string, string, Action<LocalPluginContext>>(40, "Update", "task", Execute));
        }

        protected void Execute(LocalPluginContext localContext)
        {
            #region Generate context, service & tracing service objects.
            if (localContext == null)
            {
                //throw new ArgumentNullException("localContext is null.");
                //Remediation - 14/07/2022
                throw new InvalidPluginExecutionException("localContext is null.");
            }
            IPluginExecutionContext context = localContext.PluginExecutionContext;
            IOrganizationService service = localContext.OrganizationService;
            ITracingService tracingService = localContext.TracingService;
            #endregion
            if (context.Depth > 1)
            {
                return;
            } 
            Entity entity;
            Entity preImage;
            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                tracingService.Trace("TaskManagementLogic=>PreUpdate logic- Loaded.");
                entity = (Entity)context.InputParameters["Target"];
                preImage = (Entity)context.PreEntityImages["Image"]; // bug 1439 Preimage is used
                try
                {
                    if (entity.LogicalName.ToLower() == "task")
                    {
                        if (entity.Attributes.Contains("rsa_status") || preImage.Attributes.Contains("rsa_status"))
                        {

                            int oTaskStatusPost = -1;
                            //oTaskStatusPost = ((OptionSetValue)entity.Attributes["rsa_status"]).Value;
                            oTaskStatusPost = entity.Attributes.Contains("rsa_status") ? entity.GetAttributeValue<OptionSetValue>("rsa_status").Value : 0;
                            TaskManagementLogic logic = new TaskManagementLogic(service, tracingService, entity,preImage, null, context.InitiatingUserId);
                                         //bug 1439 Preimage is used line 38 inorder to get the status value.Explicit calling of CascadeTaskInfoToCase in order to set the Current activity name based on Due date. 
                            bool bIsTaskPostCompleted = logic.IsTaskCompleted(oTaskStatusPost);
                            tracingService.Trace("bIsTaskPostCompleted: '{0}'", bIsTaskPostCompleted);
                            logic.PostUpdate(bIsTaskPostCompleted);
                          
                            //PostUpdateActivityNameOwner UpdateActivityNameOwner = new PostUpdateActivityNameOwner();                          
                            logic.CascadeTaskInfoToCase();
                        }
                    }
                }
                catch (InvalidPluginExecutionException ex)
                {
                    tracingService.Trace("An error occurred in InvalidPluginExecutionException.Task.PreUpdate plugin. Details: '{0}'", ex.Message);
                    throw new InvalidPluginExecutionException(ex.Message);
                }
                catch (Exception ex)
                {
                    tracingService.Trace("An error occurred in Exception.Task.PreUpdate plugin. Details: '{0}'", ex.Message);
                    throw new InvalidPluginExecutionException(ex.Message);
                }
                tracingService.Trace("TaskManagementLogic=>PreUpdate logic- Unloaded.");
            }
        }
      
    }
}




