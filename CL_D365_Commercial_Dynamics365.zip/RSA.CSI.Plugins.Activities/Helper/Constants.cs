﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSA.CSI.Plugins.Activities.Helper
{
    public static class Constants
    {
        public static readonly string TASK_PARENT_CASE_POLICY_QUERY = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' >
                                                    <entity name='incident' >
                                                        <attribute name='title' />
                                                        <attribute name='ticketnumber' />
                                                        <attribute name='createdon' />
                                                        <attribute name='incidentid' />
                                                        <attribute name='ownerid' />
                                                        <attribute name='rsa_status' />
                                                        <attribute name='rsa_pl' />
                                                        <attribute name='rsa_opportunityid' />
                                                        <attribute name='rsa_casetype' />
                                                        <attribute name='rsa_underwriterresponse' />
                                                        <order attribute='modifiedon' descending='true' />
                                                        <filter type='and' >
                                                            <condition attribute='incidentid' operator='eq' value='{0}' />
                                                        </filter>
                                                        <link-entity name='rsa_policy' from='rsa_policyid' to='rsa_policyid' link-type='inner' alias='pol' >
                                                            <attribute name='rsa_name' />
                                                            <attribute name='rsa_classofbusiness' />
                                                            <attribute name='rsa_productid' />
                                                            <attribute name='rsa_plcode' />
                                                            <attribute name='rsa_policysystemcode' />
                                                        </link-entity>
                                                        <link-entity name='rsa_status' from='rsa_statusid' to='rsa_status' link-type='outer' alias='rst' >
                                                            <attribute name='rsa_name' />
                                                        </link-entity>
                                                    </entity>
                                                </fetch>";


        public static readonly string TASK_OPPORTUNITY_QUERY = @"<fetch mapping='logical' version='1.0' output-format='xml-platform' distinct='false' >
                                                                    <entity name='incident'>
                                                                    <attribute name='title' />
                                                                    <attribute name='ticketnumber' />
                                                                    <attribute name='createdon' />
                                                                    <attribute name='incidentid' />
                                                                    <attribute name='caseorigincode' />
                                                                    <attribute name='rsa_opportunityid' />
                                                                    <order attribute='title' descending='false' />
                                                                    <filter type='and'>
                                                                    <condition attribute = 'incidentid' operator= 'eq' value='{0}' />
                                                                     </filter>   
                                                                    <link-entity name='opportunity' from='opportunityid' to='rsa_opportunityid' visible='false' link-type='outer' alias='opp'>
                                                                      <attribute name='rsa_typeofrisk' />
                                                                      <attribute name='rsa_risk' />
                                                                      <attribute name='rsa_closedate' />
                                                                      <attribute name='name' />
                                                                      <attribute name='rsa_totalgwp100pc' />
                                                                      <attribute name='rsa_policynumber' />
                                                                      <attribute name='rsa_policynumbers' />
                                                                      <attribute name='rsa_opportunitystage' />
                                                                      <attribute name='rsa_masterpolicynumber' />
                                                                      <attribute name='rsa_lineofbusiness' />
                                                                      <attribute name='transactioncurrencyid' />
                                                                      <attribute name='rsa_schemes' />
                                                                      <attribute name='rsa_commissionamount' />
                                                                    </link-entity>
                                                                  </entity>
                                                                </fetch>";

        public static readonly string QUEUE_QUERY = @"<fetch mapping='logical' top='1' version='1.0' distinct='false' output-format='xml-platform'>
                                                  <entity name='queue'>
                                                    <attribute name='name' />
                                                    <attribute name='emailaddress' />
                                                    <attribute name='queueid' />
                                                    <order descending='false' attribute='name' />
                                                    <filter type='and'>
                                                      <condition value='{0}' attribute='name' operator='eq' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";

        public static readonly string RSA_STATUS_RENEWAL_QUERY = @"<fetch version='1.0' top='1' output-format='xml-platform' mapping='logical' distinct='true' >
                                                                        <entity name='rsa_status' >
                                                                            <attribute name='rsa_name' />
                                                                            <attribute name='rsa_statusid' />
                                                                            <attribute name='createdon' />
                                                                            <order attribute='modifiedon' descending='true' />
                                                                            <filter type='and' >
                                                                                <condition value='%renewed%' attribute='rsa_name' operator='like' />
                                                                            </filter>
                                                                        </entity>
                                                                    </fetch>";

        public static readonly string TASK_CASE_STATUS_QUERY = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' >
                                                                    <entity name='incident' >
                                                                        <attribute name='title' />
                                                                        <attribute name='ticketnumber' />
                                                                        <attribute name='createdon' />
                                                                        <attribute name='incidentid' />
                                                                        <attribute name='ownerid' />
                                                                        <attribute name='rsa_status' />
                                                                        <attribute name='rsa_pl' />
                                                                        <attribute name='rsa_opportunityid' />
                                                                        <attribute name='rsa_casetype' />
                                                                        <attribute name='rsa_underwriterresponse' />
                                                                        <attribute name='rsa_previousqueue' />
                                                                        <order attribute='modifiedon' descending='true' />
                                                                        <filter type='and' >
                                                                            <condition attribute='incidentid' operator='eq' value='{0}' />
                                                                        </filter>
                                                                        <link-entity name='rsa_status' from='rsa_statusid' to='rsa_status' link-type='outer' alias='rst' >
                                                                            <attribute name='rsa_name' />
                                                                        </link-entity>
                                                                    </entity>
                                                                </fetch>";

        public static readonly string TASK_CASE_QUERY = @"<fetch mapping='logical' version='1.0' output-format='xml-platform' distinct='false' >
                                                            <entity name='task' >
                                                                <attribute name='subject' />
                                                                <attribute name='rsa_name' />
                                                                <attribute name='rsa_description' />
                                                                <attribute name='statecode' />
                                                                <attribute name='prioritycode' />
                                                                <attribute name='scheduledend' />
                                                                <attribute name='createdby' />
                                                                <attribute name='regardingobjectid' />
                                                                <attribute name='rsa_duedatetime' />
                                                                <attribute name='ownerid' />
                                                                <attribute name='rsa_promisenonpromise' />
                                                                <attribute name='rsa_nextcallduedatetime' />
                                                                <attribute name='rsa_warnafterdatetime' />
                                                                <attribute name='rsa_isclosed' />
                                                                <attribute name='activityid' />
                                                                <attribute name='createdon' />
                                                                <attribute name='modifiedon' />
                                                                <attribute name='rsa_queue' />
                                                                <order descending='true' attribute='modifiedon' />
                                                                <filter type='and' >
                                                                    <condition attribute='activityid' operator='eq' value='{0}' />
                                                                </filter>
                                                                <link-entity name='incident' from='incidentid' to='regardingobjectid' link-type='inner' alias='inc' >
                                                                    <attribute name='title' />
                                                                    <attribute name='ticketnumber' />
                                                                    <attribute name='rsa_nextactiondate' />
                                                                    <attribute name='rsa_nextactivityname' />
                                                                    <attribute name='ownerid' />
                                                                    <attribute name='rsa_technextcallduedate' />
                                                                    <attribute name='rsa_techtaskid' />
                                                                    <attribute name='rsa_warnafterdatetimeoncase' />
                                                                    <attribute name='incidentid' />
                                                                    <attribute name='createdon' />
                                                                </link-entity>
                                                            </entity>
                                                        </fetch>";

        public static readonly string TASK_NOTCOMPLETED_CASE_QUERY = @"<fetch distinct = 'false' mapping='logical' output-format='xml-platform' version='1.0'>
  <entity name = 'task'>
    <attribute name='subject' />
    <attribute name = 'statecode' />
    <attribute name='prioritycode' />
    <attribute name = 'scheduledend' />
    <attribute name = 'rsa_slastatus' />
    <attribute name='createdby' />
    <attribute name = 'regardingobjectid' />
    <attribute name = 'ownerid' />                        
    <attribute name='activityid' />
    <attribute name='rsa_queue' />
    <attribute name='rsa_duedatetime' />
    <order descending = 'false' attribute='scheduledend' />
    <filter type = 'and'>
    <condition attribute='statecode' value='1' operator='ne' />
    <condition attribute='statecode' value='2' operator='ne' />
    <condition attribute = 'regardingobjectid' value='{0}' operator='eq' uitype='incident' uiname='' />
    </filter>
    </entity>
    </fetch>";
    }
}
