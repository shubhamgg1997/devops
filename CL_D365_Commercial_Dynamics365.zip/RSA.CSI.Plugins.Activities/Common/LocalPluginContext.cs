﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.ServiceModel.Description;
using System.Text;
using System.Threading.Tasks;

namespace RSA.CSI.Plugins.Activities.Common
{
    public class LocalPluginContext
    {
        /// <summary>Gets the service provider.</summary>
        /// <value>The service provider.</value>
        public IServiceProvider ServiceProvider { get; }

        /// <summary>Gets or sets the organization service.</summary>
        /// <value>The organization service.</value>
        public IOrganizationService OrganizationService { get; private set; }

        /// <summary>Gets a context for the plugin execution.</summary>
        /// <value>The plugin execution context.</value>
        public IPluginExecutionContext PluginExecutionContext { get; }

        /// <summary>
        /// Use the tracing service to pash trace messages. The Trace location is configurable on the
        /// server.
        /// </summary>
        /// <value>The tracing service.</value>
        public ITracingService TracingService { get; }

        /// <summary>
        /// This method uses tje serviceProvider to create all needed sub services
        /// </summary>
        /// <param name="serviceProvider"></param>
        public LocalPluginContext(IServiceProvider serviceProvider)
        {
            ServiceProvider = serviceProvider;
            if (serviceProvider == null)               
                throw new InvalidPluginExecutionException(nameof(serviceProvider));
                //throw new ArgumentNullException(nameof(serviceProvider));
                //Remediation - 18/07/2022

            // Obtain the execution context service from the service provider.
            PluginExecutionContext = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

            // Obtain the tracing service from the service provider.
            TracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            // Obtain the Organization Service factory service from the service provider
            IOrganizationServiceFactory factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));

            // Use the factory to generate the Organization Service.
            OrganizationService = factory.CreateOrganizationService(PluginExecutionContext.UserId);
        }

        /// <summary>Creates organization service.</summary>
        /// <param name="serviceUrl">URL of the service.</param>
        /// <param name="userId">Identifier for the user.</param>
        /// <returns>The new organization service.</returns>
        /// Below function to be commented as its deprecated
        //protected IOrganizationService CreateOrganizationService(string serviceUrl, Guid? userId)
        //{
        //    var serviceCredentials = new ClientCredentials();
        //    serviceCredentials.Windows.ClientCredential = CredentialCache.DefaultNetworkCredentials;

        //    var serviceConfig = ServiceConfigurationFactory.CreateConfiguration<IOrganizationService>(new Uri(serviceUrl));
        //    var serviceProxy = new OrganizationServiceProxy(serviceConfig, serviceCredentials);
        //    serviceProxy.EnableProxyTypes();
        //    return serviceProxy;
        //}

        /// <summary>Use this method to trace a message.</summary>
        /// <param name="message">The message to write to the trace.</param>
        /// <param name="args">A variable-length parameters list containing arguments.</param>
        public void Trace(string message, params object[] args)
        {
            TracingService?.Trace(message, args);
        }

        /// <summary>
        /// Shortcut to the primary entity from the input
        /// </summary>
        public Entity PrimaryEntityFromInput
        {
            get
            {
                if (PluginExecutionContext.InputParameters.Contains("Target"))
                    return (Entity)PluginExecutionContext.InputParameters["Target"];
                return null;
            }
        }

        /// <summary>
        /// Shortcut to the primary entity reference from the input (Moniker)
        /// </summary>
        public EntityReference PrimaryEntityReferenceFromInput
        {
            get
            {
                // SetStateRequest
                if (PluginExecutionContext.InputParameters.Contains("EntityMoniker"))
                    return (EntityReference)PluginExecutionContext.InputParameters["EntityMoniker"];
                return null;
            }
        }

        //Shortcut to get the post image of the primary entity. This is useful for post-update messages
        public Entity PrimaryEntityPostImage
        {
            get
            {
                if (PluginExecutionContext.PostEntityImages.Contains(PluginExecutionContext.PrimaryEntityName) &&
                    PluginExecutionContext.PostEntityImages[PluginExecutionContext.PrimaryEntityName] != null)
                    return PluginExecutionContext.PostEntityImages[PluginExecutionContext.PrimaryEntityName];
                return null;
            }
        }

        //Shortcut to get the pre image of the primary entity.
        public Entity PrimaryEntityPreImage
        {
            get
            {
                if (PluginExecutionContext.PreEntityImages.Contains(PluginExecutionContext.PrimaryEntityName) &&
                    PluginExecutionContext.PreEntityImages[PluginExecutionContext.PrimaryEntityName] != null)
                    return PluginExecutionContext.PreEntityImages[PluginExecutionContext.PrimaryEntityName];
                return null;
            }
        }
    }
}

