﻿using Microsoft.Xrm.Sdk;
using RSA.CSI.Plugins.Activities.Common;
using RSA.CSI.Plugins.Activities.Logic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSA.CSI.Plugins.Activities
{
    public class PreDelete : PluginBase
    {
        /// <summary>
        /// PreDelete
        /// </summary>
        public PreDelete() 
            : base(typeof(PreDelete))
        {
            base.RegisteredEvents.Add(new Tuple<int, string, string, Action<LocalPluginContext>>(20, "Delete", "task", Execute));
        }

        /// <summary>
        /// Execute
        /// </summary>
        /// <param name="localContext"></param>
        private void Execute(LocalPluginContext localContext)
        {
            #region Generate context, service & tracing service objects.
            if (localContext == null)
            {
                //throw new ArgumentNullException("localContext is null.");
                //Remediation - 15/07/2022
                throw new InvalidPluginExecutionException("localContext is null.");
            }
            IPluginExecutionContext context = localContext.PluginExecutionContext;
            IOrganizationService service = localContext.OrganizationService;
            ITracingService tracingService = localContext.TracingService;
            #endregion

            //Guid gEntityId = Guid.Empty;
            Guid gLoggedInUserId = Guid.Empty;

            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is EntityReference && ((EntityReference)context.InputParameters["Target"]).LogicalName=="task")
            {
                EntityReference oEntityRef = (EntityReference)context.InputParameters["Target"];
                //gEntityId = EntityRef.Id;
                gLoggedInUserId = context.InitiatingUserId;
                try
                {
                    tracingService.Trace("TaskLogic=>PreDelete() logic- Loaded.");

                    string sDeleteRestrictedMessage = string.Empty;
                    bool bIsDeleteRestricted = true;

                    TaskManagementLogic logic = new TaskManagementLogic(service, tracingService, null, null,oEntityRef, context.InitiatingUserId);
                    logic.PreDelete(out sDeleteRestrictedMessage, out bIsDeleteRestricted);
                    if (bIsDeleteRestricted && !string.IsNullOrEmpty(sDeleteRestrictedMessage))
                    {
                        throw new InvalidPluginExecutionException(sDeleteRestrictedMessage + System.Environment.NewLine);
                    }
                    tracingService.Trace("TaskLogic=>PreDelete() logic- Unloaded.");
                }
                catch (InvalidPluginExecutionException ex)
                {
                    tracingService.Trace("An error occurred in InvalidPluginExecutionException.Task.PreDelete plugin. Details: '{0}'", ex.Message);
                    throw new InvalidPluginExecutionException(ex.Message);
                }
                catch (Exception ex)
                {
                    tracingService.Trace("An error occurred in Exception.Task.PreDelete plugin. Details: '{0}'", ex.Message);
                    //throw new Exception(ex.Message);
                    //Remediation - 15/07/2022
                    throw new InvalidPluginExecutionException(ex.Message);
                }
            }

        }
    }
}
