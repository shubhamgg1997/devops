﻿using Microsoft.Xrm.Sdk;
using RSA.CSI.Plugins.Activities.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using RSA.CSI.Plugins.Activities.Logic;

namespace RSA.CSI.Plugins.Activities
{
    public class PreCreate : PluginBase
    {
        public PreCreate()
            : base(typeof(PreCreate))
        {
            base.RegisteredEvents.Add(new Tuple<int, string, string, Action<LocalPluginContext>>(20, "Create", "task", Execute));
        }

        protected void Execute(LocalPluginContext localContext)
        {
            #region Generate context, service & tracing service objects.
            if (localContext == null)
            {
                //throw new ArgumentNullException("localContext is null.");
                //Remediation - 14/07/2022
                throw new InvalidPluginExecutionException("localContext is null.");
            }
            IPluginExecutionContext context = localContext.PluginExecutionContext;
            IOrganizationService service = localContext.OrganizationService;
            ITracingService tracingService = localContext.TracingService;
            #endregion

            Entity entity;
            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                entity = (Entity)context.InputParameters["Target"];
                try
                {
                    if (entity.LogicalName.ToLower() == "task" && entity.Attributes.Contains("regardingobjectid") &&
                        ((EntityReference)entity["regardingobjectid"]).LogicalName == "incident")
                    {
                        entity["rsa_casetotaskid"] = new EntityReference("incident", ((EntityReference)entity["regardingobjectid"]).Id);
                        tracingService.Trace("TaskLogic=>PreCreate() logic- Loaded.");
                        TaskManagementLogic task = new TaskManagementLogic(service, tracingService, entity,null ,null, context.InitiatingUserId);
                        task.PreCreate();
                        
                        tracingService.Trace("TaskLogic=>PreCreate() logic- Unloaded.");
                    }
                }
                catch (Exception ex)
                {
                    tracingService.Trace("An error occurred in Task.PreCreate plugin. Details: '{0}'", ex.Message);
                }
            }
        }
    }
}