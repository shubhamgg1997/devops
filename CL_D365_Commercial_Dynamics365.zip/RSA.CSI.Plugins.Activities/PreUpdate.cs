﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using RSA.CSI.Plugins.Activities.Common;
using RSA.CSI.Plugins.Activities.Logic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSA.CSI.Plugins.Activities
{
    public class PreUpdate : PluginBase
    {
        public PreUpdate()
            : base(typeof(PreUpdate))
        {
            base.RegisteredEvents.Add(new Tuple<int, string, string, Action<LocalPluginContext>>(20, "Update", "task", Execute));
        }

        protected void Execute(LocalPluginContext localContext)
        {
            #region Generate context, service & tracing service objects.
            if (localContext == null)
            {
                //throw new ArgumentNullException("localContext is null.");
                //Remediation - 15/07/2022
                throw new InvalidPluginExecutionException("localContext is null.");
            }
            IPluginExecutionContext context = localContext.PluginExecutionContext;
            IOrganizationService service = localContext.OrganizationService;
            ITracingService tracingService = localContext.TracingService;
            #endregion
            Entity entity;
            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                tracingService.Trace("TaskManagementLogic=>PreUpdate logic- Loaded.");
                entity = (Entity)context.InputParameters["Target"];
                try
                {
                    if (entity.LogicalName.ToLower() == "task")
                    {
                        //2353 : Close Activity - Tick Button 
                        int? userTimezone = RetrieveCurrentUsersSettings(service);
                        DateTime dt = DateTime.Now;
                        dt = RetrieveLocalTimeFromUTCTime(dt, userTimezone, service);

                        tracingService.Trace("Status : " + entity.Attributes.Contains("rsa_status").ToString());
                        tracingService.Trace("Status OOB: " + entity.Attributes.Contains("statecode").ToString());
                        if (entity.Attributes.Contains("statecode") && ((OptionSetValue)entity.Attributes["statecode"]).Value == 1)
                        {
                            entity["rsa_status"] = new OptionSetValue(866760004);
                            tracingService.Trace("Status is completed");
                            entity["ownerid"] = new EntityReference("systemuser", context.InitiatingUserId);
                            entity["rsa_activitycompleteddate"] = dt;
                        }

                        if (entity.Attributes.Contains("rsa_status"))
                        {
                            int oTaskStatusPost = -1;
                            oTaskStatusPost = ((OptionSetValue)entity.Attributes["rsa_status"]).Value;
                            tracingService.Trace("oTaskStatusPost: '{0}'", oTaskStatusPost.ToString());
                            TaskManagementLogic logic = new TaskManagementLogic(service, tracingService, entity,null, null, context.InitiatingUserId);
                            bool bIsTaskPostCompleted = logic.IsTaskCompleted(oTaskStatusPost);
                            tracingService.Trace("bIsTaskPostCompleted: '{0}'", bIsTaskPostCompleted);




                            string sPreUpdateFailedMessage = string.Empty;
                            bool bPreUpdateFailed = false;

                            logic.PreUpdate(bIsTaskPostCompleted, out sPreUpdateFailedMessage, out bPreUpdateFailed);
                            if (bPreUpdateFailed && !string.IsNullOrEmpty(sPreUpdateFailedMessage))
                            {
                                throw new InvalidPluginExecutionException(sPreUpdateFailedMessage + System.Environment.NewLine);
                            }

                        }
                    }
                    
                }
                catch (InvalidPluginExecutionException ex)
                {
                    tracingService.Trace("An error occurred in InvalidPluginExecutionException.Task.PreUpdate plugin. Details: '{0}'", ex.Message);
                    throw new InvalidPluginExecutionException(ex.Message);
                }
                catch (Exception ex)
                {
                    tracingService.Trace("An error occurred in Exception.Task.PreUpdate plugin. Details: '{0}'", ex.Message);
                    //throw new Exception(ex.Message);
                    //Remediation - 15/07/2022
                    throw new InvalidPluginExecutionException(ex.Message);
                }
                tracingService.Trace("TaskManagementLogic=>PreUpdate logic- Unloaded.");
            }
        }
        public DateTime RetrieveLocalTimeFromUTCTime(DateTime utcTime, int? timeZoneCode, IOrganizationService service)
        {
            if (!timeZoneCode.HasValue)
                return DateTime.Now;

            var request = new LocalTimeFromUtcTimeRequest
            {
                TimeZoneCode = timeZoneCode.Value,
                UtcTime = utcTime.ToUniversalTime()
            };

            var response = (LocalTimeFromUtcTimeResponse)service.Execute(request);
            return response.LocalTime;
        }

        public int? RetrieveCurrentUsersSettings(IOrganizationService service)
        {
            var currentUserSettings = service.RetrieveMultiple(
                new QueryExpression("usersettings")
                {
                    ColumnSet = new ColumnSet("timezonecode"),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("systemuserid", ConditionOperator.EqualUserId)
                        }
                    },
                    NoLock = true
                }).Entities[0].ToEntity<Entity>();
            //return time zone code
            return (int?)currentUserSettings.Attributes["timezonecode"];
        }

    }
}
