﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RSA.CSI.Plugins.Activities.Helper;
using Itenso.TimePeriod;
using static RSA.CSI.Plugins.Activities.Helper.Constants;

namespace RSA.CSI.Plugins.Activities.Logic
{
    #region TaskManagementLogic class
    /// <summary>
    /// TaskManagementLogic
    /// </summary>
    internal class TaskManagementLogic
    {
        #region Global variables
        /// <summary>
        /// Global variables
        /// </summary>
        private readonly IOrganizationService _service;
        private readonly ITracingService _tracingService;
        private Entity _eTaskOriginalObj;
        private Entity preImage;
        private Entity _eTaskNewObj;
        private readonly EntityReference _eTaskRef;
        private readonly Guid _gLoggedInUserId;

        private bool _bIsTaskCompleted = false;
        private Entity _eTaskOwner = new Entity();
        private Entity _eParentCase = new Entity();
        private String _sTicketNumber = string.Empty;

        private bool _bPreUpdateFailed = false;
        private string _sPreUpdateFailedMessage = string.Empty;
        private string _oAIS_Extension_Activity_Switch = string.Empty;
        private bool _bAIS_Extension_Activity_Switch = false;
        private bool _bTargetQueueId = false;
        private Guid _oTargetQueueId = Guid.Empty;
        #endregion Global variables

        #region Constructor
        /// <summary>
        /// TaskManagementLogic constructor
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="eTask"></param>
        /// <param name="eTaskRef"></param>
        public TaskManagementLogic(IOrganizationService service, ITracingService tracingService, Entity eTask, Entity preImage, EntityReference eTaskRef, Guid gLoggedInUserId)
        {
            _service = service;
            _tracingService = tracingService;
            _eTaskOriginalObj = eTask;
            preImage = preImage;
            _eTaskRef = eTaskRef;
            _gLoggedInUserId = gLoggedInUserId;
        }
        #endregion

        #region Public methods
        /// <summary>
        /// PreCreate
        /// </summary>
        public void PreCreate()
        {
            _tracingService.Trace("TaskManagementLogic=>PreCreate()- Loaded");
            try
            {
                if (_eTaskOriginalObj.Attributes.Contains("ownerid") && ((EntityReference)_eTaskOriginalObj["ownerid"]).Id != Guid.Empty)
                {
                    this.CascadeUserInfoToTask(((EntityReference)_eTaskOriginalObj["ownerid"]).Id);
                }
                string subject = _eTaskOriginalObj.Attributes.Contains("subject") ? _eTaskOriginalObj.GetAttributeValue<string>("subject") : string.Empty;
                _tracingService.Trace("Subject : - " + subject);
                EntityReference QueueName = _eTaskOriginalObj.Attributes.Contains("rsa_queue") ? _eTaskOriginalObj.GetAttributeValue<EntityReference>("rsa_queue") : null;
                _tracingService.Trace("QueueName : - " + QueueName);
                EntityReference en_Case = _eTaskOriginalObj.Attributes.Contains("regardingobjectid") ? _eTaskOriginalObj.GetAttributeValue<EntityReference>("regardingobjectid") : null;
                _tracingService.Trace("en_Case obj  " + en_Case.Id);
                Entity CaseDATE = _service.Retrieve(en_Case.LogicalName, en_Case.Id, new ColumnSet("rsa_casereceiveddate", "createdon"));
                DateTime CaseCreatedDate = CaseDATE.Attributes.Contains("createdon") ? CaseDATE.GetAttributeValue<DateTime>("createdon") : DateTime.MinValue;
                int? userTimezone = RetrieveCurrentUsersSettings(_service);
                CaseCreatedDate = RetrieveLocalTimeFromUTCTime(CaseCreatedDate, userTimezone, _service); //localtime fromUTC time
                _tracingService.Trace("CaseReceivedDate   " + CaseCreatedDate);
                EntityReference isABRTask = _eTaskOriginalObj.Attributes.Contains("rsa_abrtemplatename") ? _eTaskOriginalObj.GetAttributeValue<EntityReference>("rsa_abrtemplatename") : null;
                DateTime Duedate = _eTaskOriginalObj.Attributes.Contains("scheduledend") ? _eTaskOriginalObj.GetAttributeValue<DateTime>("scheduledend") : DateTime.MinValue;
                _tracingService.Trace("Duedate from task   " + Duedate);
                string sQuery = string.Format(Constants.TASK_CASE_STATUS_QUERY, ((EntityReference)_eTaskOriginalObj["regardingobjectid"]).Id);
                var ecCaseCollection = _service.RetrieveMultiple(new FetchExpression(sQuery));

                if (ecCaseCollection != null && ecCaseCollection.Entities.Count > 0)
                {
                    _eParentCase = ecCaseCollection[0];

                    this.ReactivateParentCase();

                    this.DefineTaskDueDateTime();

                }
                if (_eTaskOriginalObj != null && Duedate != DateTime.MinValue && isABRTask == null && Duedate.TimeOfDay == new TimeSpan(0, 0, 00))
                {
                    this.SetDueDateTime(Duedate);
                }

                if (subject.ToLowerInvariant().Equals("bpo initial processing") && isABRTask == null && CaseCreatedDate != DateTime.MinValue && QueueName != null)
                {
                    _tracingService.Trace("Calling BPO SLA MEthod");
                    this.BPOSLA(CaseCreatedDate, en_Case, QueueName, userTimezone);
                    //this.Set(CaseCreatedDate);
                }


            }
            catch (Exception ex)
            {
                _tracingService.Trace("An error occurred in Task.PreCreate plugin. Details: '{0}'", ex.Message);
            }

            _tracingService.Trace("TaskManagementLogic=>PreCreate()- Unloaded");
        }

        /// <summary>
        /// PostCreate
        /// </summary>
        /// <param name="bIsTaskCompleted"></param>
        public void PostCreate(bool bIsTaskCompleted, Entity entity)
        {
            _tracingService.Trace("TaskManagementLogic=>PostCreate()- Loaded");
            try
            {
                if (entity.LogicalName.ToLower() == "task" && entity.Attributes.Contains("regardingobjectid") &&
                       ((EntityReference)entity["regardingobjectid"]).LogicalName == "incident")
                {

                    _bIsTaskCompleted = bIsTaskCompleted;

                    this.SLATrackingAndMaintenance();
                    //this.ActivityTrackingAndMaintenance(eTask, service, tracingService);
                }
                if (entity.LogicalName.ToLower() == "task" && entity.Attributes.Contains("regardingobjectid") &&
                      ((EntityReference)entity["regardingobjectid"]).LogicalName == "opportunity")
                {
                    EntityReference oppo = entity.GetAttributeValue<EntityReference>("regardingobjectid");
                    Entity task = new Entity(entity.LogicalName);
                    task["rsa_opportunitytotaskid"] = new EntityReference(oppo.LogicalName, oppo.Id);
                    task.Id = entity.Id;
                    _service.Update(task);
                }

                // #region
                //2489 -
                //    if (_eTaskOriginalObj.LogicalName.ToLower() == "task" && _eTaskOriginalObj.Attributes.Contains("regardingobjectid") &&
                //                           ((EntityReference)_eTaskOriginalObj["regardingobjectid"]).LogicalName == "incident")
                //    {

                //        EntityReference encase = _eTaskOriginalObj.Attributes.Contains("regardingobjectid") ? _eTaskOriginalObj.GetAttributeValue<EntityReference>("regardingobjectid") : null;
                //        _tracingService.Trace("en_Case obj  " + encase.Id);
                //        string Activitystatus = _eTaskOriginalObj.FormattedValues.ContainsKey("statecode") ? _eTaskOriginalObj.FormattedValues["statecode"] : null;
                //        _tracingService.Trace(" Activitystatus closecase", Activitystatus);
                //        if (encase != null && !string.IsNullOrEmpty(Activitystatus) && !Activitystatus.Contains("Completed") && !Activitystatus.Contains("Canceled"))
                //        {

                //            var Ccase = _service.Retrieve(encase.LogicalName, encase.Id, new ColumnSet("rsa_status", "rsa_pl_w", "rsa_casetype", "rsa_previousqueue", "ownerid"));
                //            //if (Ccase.Attributes.Contains("rsa_status") && Ccase.Attributes.Contains("rsa_pl_w") && Ccase.Attributes.Contains("rsa_casetype") && Ccase.GetAttributeValue<EntityReference>("rsa_status").Name.ToLower().Contains("close")
                //            //    && (Ccase.GetAttributeValue<EntityReference>("rsa_casetype").Name.Equals("New Business") || Ccase.GetAttributeValue<EntityReference>("rsa_casetype").Name.Equals("Revised Renewal") || Ccase.GetAttributeValue<EntityReference>("rsa_casetype").Name.Equals("Renewal"))
                //            //    && Ccase.GetAttributeValue<string>("rsa_pl_w").Equals("Mid-Market"))
                //            if (Ccase.Attributes.Contains("rsa_status") && (Ccase.GetAttributeValue<EntityReference>("rsa_status").Name.ToLower().Equals("renewed")))
                //            {
                //                _tracingService.Trace("Case Status In");
                //                string statusName = ((EntityReference)Ccase.Attributes["rsa_status"]).Name;
                //                _tracingService.Trace("Status" + statusName);



                //                if ((Ccase.Attributes.Contains("rsa_casetype")) && (Ccase.GetAttributeValue<EntityReference>("rsa_casetype").Name.Equals("New Business")
                //                    || Ccase.GetAttributeValue<EntityReference>("rsa_casetype").Name.Equals("Revised Renewal")
                //                    || Ccase.GetAttributeValue<EntityReference>("rsa_casetype").Name.Equals("Renewal")))
                //                {
                //                    _tracingService.Trace(" before Status Update");
                //                    Ccase["rsa_status"] = new EntityReference(GetLookUpDetailsbyText(_service, "Re-Opened", "rsa_status", Ccase.GetAttributeValue<EntityReference>("rsa_casetype").Id).LogicalName,
                //                        GetLookUpDetailsbyText(_service, "Re-Opened", "rsa_status", Ccase.GetAttributeValue<EntityReference>("rsa_casetype").Id).Id);
                //                    _service.Update(Ccase);
                //                    _tracingService.Trace("Case updated");

                //                    //Queue Update
                //                    if ((Ccase.Attributes.Contains("ownerid")) && (Ccase.Attributes.Contains("rsa_previousqueue"))) //(Ccase.GetAttributeValue<EntityReference>("ownerid").Name.Equals("Unassigned ."))
                //                    {
                //                        _tracingService.Trace("Test Owner");
                //                        Guid previousQueue = ((EntityReference)Ccase.Attributes["rsa_previousqueue"]).Id;
                //                        _tracingService.Trace("previousQueue" + previousQueue);
                //                        if (previousQueue != Guid.Empty)
                //                            this.AddToQueue(encase.LogicalName, encase.Id, previousQueue);
                //                        _tracingService.Trace("Assign Queue Done");

                //                    }
                //                }

                //            }
                //        }
                //    }
                //}
            }
            catch (Exception ex)
            {
                _tracingService.Trace("An error occurred in Task.PostCreate plugin. Details: '{0}'", ex.Message);
            }

            _tracingService.Trace("TaskManagementLogic=>PostCreate()- Unloaded");
        }

        /// <summary>
        /// PreUpdate
        /// </summary>
        /// <param name="bIsTaskCompleted"></param>
        /// <param name="sPreUpdateFailedMessage"></param>
        /// <param name="bPreUpdateFailed"></param>
        public void PreUpdate(bool bIsTaskCompleted, out string sPreUpdateFailedMessage, out bool bPreUpdateFailed)
        {
            _tracingService.Trace("TaskManagementLogic=>PreUpdate()- Loaded");
            bPreUpdateFailed = _bPreUpdateFailed;
            sPreUpdateFailedMessage = _sPreUpdateFailedMessage;
            try
            {
                _tracingService.Trace("_bIsTaskCompleted: '{0}'", _bIsTaskCompleted);
                _bIsTaskCompleted = bIsTaskCompleted;
                _tracingService.Trace("_bIsTaskCompleted After: '{0}'", _bIsTaskCompleted);
                ColumnSet oTaskColumns = new ColumnSet("subject", "rsa_name", "rsa_description", "statecode", "prioritycode", "scheduledend", "createdby"
                                                        , "regardingobjectid", "rsa_duedatetime", "ownerid", "rsa_promisenonpromise"
                                                        , "rsa_isclosed", "activityid", "createdon", "rsa_tasktype", "rsa_recordtypename", "modifiedon"
                                                        , "rsa_status", "rsa_initialassignedtouser", "rsa_initialassignedtosite", "rsa_initialassignedtodivision"
                                                        , "rsa_initialassignedtoteam", "rsa_completedbyuser", "rsa_completedbysite", "rsa_completedbydivision"
                                                        , "rsa_completedbyteam", "rsa_activitydate", "rsa_activitydate", "rsa_nextcallduedatetime", "rsa_warnafterdatetime");

                _eTaskNewObj = _service.Retrieve("task", _eTaskOriginalObj.Id, oTaskColumns);
                if (_eTaskNewObj != null && _eTaskNewObj.Id != Guid.Empty)
                {
                    if (_eTaskNewObj.Attributes.Contains("ownerid") && ((EntityReference)_eTaskNewObj["ownerid"]).Id != Guid.Empty)
                    {
                        _tracingService.Trace("_eTask.Attributes.Contains('ownerid')");
                        /// <summary>
                        /// Needs to check below mappings and correct them wherever required.
                        /// <attributes>
                        /// task.rsa_completedbyuser = systemuser.fullname
                        /// task.rsa_completedbysite = systemuser.rsa_usersite
                        /// task.rsa_completedbydivision = systemuser.rsa_division
                        /// task.rsa_completedbyteam = systemuser.rsa_userteamlevel2
                        /// task.rsa_initialassignedtouser = systemuser.fullname
                        /// task.rsa_initialassignedtosite = systemuser.rsa_usersite
                        /// task.rsa_initialassignedtodivision = systemuser.rsa_division
                        /// task.rsa_initialassignedtoteam = systemuser.rsa_userteamlevel2
                        /// </attributes>
                        /// </summary>
                        this.CascadeUserInfoToTask(((EntityReference)_eTaskNewObj["ownerid"]).Id);
                    }
                    if (_bIsTaskCompleted)
                    {
                        _tracingService.Trace("_bIsTaskCompleted is true");
                        _tracingService.Trace("Calling ValidateActivityRecordType");
                        this.ValidateActivityRecordType();
                        if (_bPreUpdateFailed && !string.IsNullOrEmpty(_sPreUpdateFailedMessage))
                        {
                            bPreUpdateFailed = _bPreUpdateFailed;
                            sPreUpdateFailedMessage = _sPreUpdateFailedMessage;
                            return;
                        }
                        // this.AddAISExtensionsTask();
                        //this.AddQuoteDocumentsTask();
                    }
                }
            }
            catch (Exception ex)
            {
                _tracingService.Trace("An error occurred in Task.PreUpdate plugin. Details: '{0}'", ex.Message);
            }

            _tracingService.Trace("TaskManagementLogic=>PreUpdate()- Unloaded");
        }

        /// <summary>
        /// PostUpdate
        /// </summary>
        public void PostUpdate(bool bIsTaskCompleted)
        {
            _tracingService.Trace("TaskManagementLogic=>PostUpdate()- Loaded");
            try
            {
                _bIsTaskCompleted = bIsTaskCompleted;
                this.SLATrackingAndMaintenance();
                if (_bIsTaskCompleted && _eTaskNewObj.Attributes.Contains("rsa_name"))
                {
                    this.TaskOpportunityTracking();
                }
            }
            catch (Exception ex)
            {
                _tracingService.Trace("An error occurred in Task.PostUpdate plugin. Details: '{0}'", ex.Message);
            }

            _tracingService.Trace("TaskManagementLogic=>PostCreate()- Unloaded");
        }

        /// <summary>
        /// PreDelete
        /// </summary>
        /// <param name="sDeleteRestrictedMessage"></param>
        /// <param name="bIsDeleteRestricted"></param>
        public void PreDelete(out string sDeleteRestrictedMessage, out bool bIsDeleteRestricted)
        {
            _tracingService.Trace("TaskManagementLogic=>PreDelete()- Loaded");
            bIsDeleteRestricted = true;
            sDeleteRestrictedMessage = string.Empty;
            try
            {
                this.IsUserAuthorizeToDeleteTask(out sDeleteRestrictedMessage, out bIsDeleteRestricted);
            }
            catch (Exception ex)
            {
                _tracingService.Trace("An error occurred in Task.PreDelete plugin. Details: '{0}'", ex.Message);
            }
            _tracingService.Trace("TaskManagementLogic=>PreDelete()- Unloaded");
        }
        #endregion Public methods

        #region Private methods

        private void Set(DateTime dueDate)
        {
            int dueDateOffset = 5;
            CalendarDateAdd calendarDateAdd = new CalendarDateAdd();
            // use only weekdays
            calendarDateAdd.AddWorkingWeekDays();
            // setup working hours
            calendarDateAdd.WorkingHours.Add(new HourRange(new Time(09), new Time(17)));

            DateTime start = dueDate; // start date
            TimeSpan offset = TimeSpan.FromHours(dueDateOffset); // 5 hours

            DateTime? end = calendarDateAdd.Add(start, offset); // end date
            _tracingService.Trace("TaskManagementLogic=>(Set)- " + end);


        }

        public static DateTime CreateNewDate(int year, int month, int day, DateTime time)
        {
            return new DateTime(year, month, day, time.Hour, time.Minute, 0);
        }



        private void SetDueDateTime(DateTime dueDate)
        {
            _tracingService.Trace("TaskManagementLogic=>SetDueDateTime()- Loaded");
            try
            {
                _eTaskOriginalObj["rsa_duedatetime"] = dueDate.Date + new TimeSpan(17, 0, 0);

            }
            catch (Exception ex)
            {
                _tracingService.Trace("An error occurred in Task.SetDueDateTime plugin. Details: '{0}'", ex.Message);
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
        private void BPOSLA(DateTime CaseReceivedDate, EntityReference CaseID, EntityReference QueueName, int? userTimezone)
        {
            _tracingService.Trace("TaskManagementLogic=>BPOSLA()- Loaded");
            try
            {
                #region VariableDeclaration
                DateTime dt = CaseReceivedDate;
                double dueDateOffset = 00;
                if (QueueName.Name.Equals("BPO New Business"))
                {
                    dueDateOffset = 5;
                }
                if (QueueName.Name.Equals("BPO Existing Business") || QueueName.Name.Equals("BPO SME"))
                {
                    dueDateOffset = 1;
                }

                DateTime taskEndDate = DateTime.MinValue;
                bool businesshours = true;
                int increment = 1;
                bool BusinessDaysRequired = true;
                var timeSpandt = dt.TimeOfDay;
                double EndofBusinessHoursTime = 17;
                int startofBusinessHoursTime = 9;
                TimeSpan ts_EndofBusinessHoursTime = TimeSpan.FromHours(EndofBusinessHoursTime); // this is defined to use the time of day .that is 17 o clock.
                TimeSpan ts_StartofBusinessHoursTime = TimeSpan.FromHours(startofBusinessHoursTime);
                _tracingService.Trace("ts_EndofBusinessHoursTime   " + ts_EndofBusinessHoursTime);
                _tracingService.Trace("timeSpandt  " + timeSpandt);
                _tracingService.Trace("timeSpandt hour  " + timeSpandt.Hours);
                #endregion
                if (dt != DateTime.MinValue && dueDateOffset > 0)
                {
                    if (businesshours)
                    {
                        _tracingService.Trace("inside hours business hours"); //timespandt is due date based on 
                        _tracingService.Trace("inside hours business hours  " + timeSpandt.Hours); //printing the vlue of current businesshr

                        //  taskEndDate = dt.AddHours(Convert.ToDouble(dueDateOffset)); //added te offset .from next line if it is grater than Busines hrs then we will subtract
                        TimeSpan hoursLeft = new TimeSpan();
                        TimeSpan offset = TimeSpan.FromHours(dueDateOffset);
                        _tracingService.Trace("original offset   " + offset);

                        if (dt.Hour < ts_StartofBusinessHoursTime.TotalHours)
                        {
                            dt = dt.Date + ts_StartofBusinessHoursTime;
                            if (dt.AddHours(dueDateOffset).Date > dt.Date || dt.AddHours(dueDateOffset).TimeOfDay > ts_EndofBusinessHoursTime)
                            {
                                hoursLeft = ts_EndofBusinessHoursTime - dt.TimeOfDay;
                                taskEndDate = dt + hoursLeft;
                                offset = offset - hoursLeft;
                            }
                            else
                            {
                                taskEndDate = dt.AddHours(dueDateOffset);
                            }

                        }
                        if (dt.TimeOfDay >= ts_StartofBusinessHoursTime && dt.TimeOfDay < ts_EndofBusinessHoursTime)
                        {
                            if (dt.AddHours(dueDateOffset).Date > dt.Date || dt.AddHours(dueDateOffset).TimeOfDay > ts_EndofBusinessHoursTime)
                            {
                                hoursLeft = ts_EndofBusinessHoursTime - dt.TimeOfDay;
                                _tracingService.Trace("hoursLeft within Business Hour " + hoursLeft);

                                taskEndDate = dt + (hoursLeft);
                                _tracingService.Trace("taskEndDate ithin Business Hour  " + taskEndDate);

                                offset = offset - hoursLeft;
                                _tracingService.Trace("offset left when inside businesshrs New    " + offset);

                            }
                            else
                            {
                                taskEndDate = dt.AddHours(dueDateOffset);
                                _tracingService.Trace("taskEndDate    " + taskEndDate);

                            }
                        }

                        while (dt.TimeOfDay >= ts_EndofBusinessHoursTime || taskEndDate.TimeOfDay >= ts_EndofBusinessHoursTime)
                        {

                            _tracingService.Trace("  dt  " + dt);
                            taskEndDate = dt.Date.AddDays(increment) + ts_StartofBusinessHoursTime + offset;
                            _tracingService.Trace("taskEndDate New    " + taskEndDate);

                            offset = taskEndDate.TimeOfDay - ts_EndofBusinessHoursTime;
                            _tracingService.Trace("offset left when outside businessrs New    " + offset);
                            ++increment;
                            if (taskEndDate.TimeOfDay < ts_EndofBusinessHoursTime)
                            {
                                break;
                            }

                        }
                        _tracingService.Trace("taskEndDate New    " + taskEndDate);


                        if (BusinessDaysRequired)
                        {
                            if (taskEndDate.DayOfWeek == DayOfWeek.Saturday)
                            {
                                taskEndDate = taskEndDate.AddDays(2);
                            }
                            else if (taskEndDate.DayOfWeek == DayOfWeek.Sunday)
                                taskEndDate = taskEndDate.AddDays(1);
                        }

                        _tracingService.Trace("Activities taskEndDate is : {0}", taskEndDate);

                        if (taskEndDate != DateTime.MinValue)
                        {
                            // taskEndDate = RetrieveLocalTimeFromUTCTime(taskEndDate, userTimezone, _service);
                            _eTaskOriginalObj["scheduledend"] = taskEndDate;
                            _eTaskOriginalObj["rsa_duedatetime"] = taskEndDate;
                            _tracingService.Trace("Activities taskEndDate is updated : {0}", taskEndDate);
                            Entity en_Case = new Entity("incident");
                            en_Case.Id = CaseID.Id;
                            en_Case["rsa_nextactiondate"] = taskEndDate;
                            _tracingService.Trace("CASE updated : {0}", taskEndDate);
                            en_Case["rsa_nextactivityname"] = "BPO Initial Processing";
                            _tracingService.Trace("CASE updated : {0}", "BPO Initial Processing");

                            _service.Update(en_Case);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _tracingService.Trace("An error occurred in Task.BPOSLA plugin. Details: '{0}'", ex.Message);
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }






        /// <summary>
        /// CalculateBusinessHours
        /// </summary>
        /// <param name="numberOfDays"></param>
        /// <returns></returns>
        private DateTime CalculateBusinessHours(int numberOfDays)
        {
            _tracingService.Trace("TaskManagementLogic=>calculateBusinessHours()- Loaded");
            try
            {

                DateTime now = DateTime.Now;
                DateTime endDate = now.AddDays(numberOfDays);
                DayOfWeek endDate_Today = endDate.DayOfWeek;
                DayOfWeek now_Today = now.DayOfWeek;
                int count = 0;
                DateTime d1 = now.Date;
                DateTime d2 = endDate.Date;

                int wday = numberOfDays;
                int addedDays = 0;
                if (endDate_Today == DayOfWeek.Saturday)
                {
                    endDate = endDate.AddDays(2);
                    addedDays = 2;
                }
                if (endDate_Today == DayOfWeek.Sunday)
                {
                    endDate = endDate.AddDays(1);
                    addedDays = 1;
                }
                do
                {
                    if (now_Today == DayOfWeek.Saturday)
                    {
                        count++;
                    }
                    if (now_Today == DayOfWeek.Sunday)
                    {
                        count++;
                    }
                    now = now.AddDays(1);
                }
                while (now < endDate);
                endDate = endDate.AddDays(count - addedDays);

                _tracingService.Trace("TaskManagementLogic=>TaskOpportunityTracking()- Unloaded.");
                return endDate;

            }
            catch (Exception ex)
            {
                _tracingService.Trace("An error occurred in Task.CalculateBusinessHours plugin. Details: '{0}'", ex.Message);
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        /// <summary>
        /// CreateTaskBasedOnOpportunity
        /// </summary>
        /// <param name="numberOfDays"></param>
        /// <param name="taskSubject"></param>
        /// <param name="activityStatus"></param>
        private void CreateTaskBasedOnOpportunity(int numberOfDays, string taskSubject, string activityStatus)
        {
            _tracingService.Trace("TaskManagementLogic=>CreateTaskBasedOnOpportunity()- Loaded");
            try
            {
                //Retrieve "Primary" account type
                QueryExpression query = new QueryExpression("rsa_activitytype");
                query.NoLock = true;
                query.Criteria.AddCondition("rsa_name", ConditionOperator.Equal, "MARINE_NEW_RENEWAL");
                Entity taskType = _service.RetrieveMultiple(query).Entities.First();
                Entity oTaskEntity = new Entity(_eTaskNewObj.LogicalName);
                if (taskType != null)
                {
                    oTaskEntity["rsa_tasktype"] = new EntityReference("rsa_activitytype", taskType.Id);
                }
                oTaskEntity["ownerid"] = _eTaskNewObj["ownerid"];
                oTaskEntity["subject"] = taskSubject;
                oTaskEntity["rsa_name"] = taskSubject;
                oTaskEntity["rsa_activitydate"] = CalculateBusinessHours(numberOfDays);
                oTaskEntity["rsa_duedatetime"] = CalculateBusinessHours(numberOfDays);
                oTaskEntity["regardingobjectid"] = _eTaskNewObj["regardingobjectid"];
                Guid oTaskNewId = _service.Create(oTaskEntity);
                _tracingService.Trace("Task has been updated.");
            }
            catch (Exception ex)
            {
                _tracingService.Trace("An error occurred in Task.CascadeTaskInfoToToCase plugin. Details: '{0}'", ex.Message);
            }
            _tracingService.Trace("TaskManagementLogic=>CreateTaskBasedOnOpportunity()- Unloaded");
        }

        /// <summary>
        /// TaskOpportunityTracking
        /// </summary>
        private void TaskOpportunityTracking()
        {
            _tracingService.Trace("TaskManagementLogic=>TaskOpportunityTracking()- Loaded.");
            try
            {
                //Integer numberOfDays,String taskSubject, ID activityWhatId, ID activityOwner_ID, String activityStatus
                int numberOfDays = 0;
                string taskSubject = null, activityStatus = null;

                //_eTask = eTask;
                //string sQuery = this.PrepareTaskQueryTaskToCase(tracingService, eTask.Id);
                //_eTask = this.RetrieveMultiple(service, tracingService, sQuery) != null && this.RetrieveMultiple(service, tracingService, sQuery).Entities.Count > 0 ? this.RetrieveMultiple(service, tracingService, sQuery)[0] : null;
                if (_eTaskNewObj == null)
                {
                    _tracingService.Trace("unable to fetch _eTask with Id: '{0}'", _eTaskNewObj.Id);
                    _tracingService.Trace("TaskManagementLogic=>TaskOpportunityTracking()- Unloaded");
                    return;
                }
                if (_eTaskNewObj.Attributes.Contains("rsa_name") && _eTaskNewObj["rsa_name"].ToString().ToLower() == "prepare operations data entry instruction")
                {
                    //bool bIsTaskCompleted = this.IsTaskCompleted();
                    _tracingService.Trace("bIsTaskCompleted is '{0}'", _bIsTaskCompleted);
                    //if (_eTask["rsa_name"].ToString().ToLower() == "process new business policy (multiple policy quote)")
                    //{
                    EntityReference erParentCase = _eTaskNewObj.GetAttributeValue<EntityReference>("regardingobjectid");
                    string sMasterPolicyNumber = string.Empty;
                    string sPolicyNumbers = string.Empty;
                    string sPolicyNumber = string.Empty;

                    //_eTask.Id = new Guid(((AliasedValue)_eTask["regardingobjectid"]).Value.ToString());
                    Entity eOpporunity;
                    string soppQuery = string.Format(Constants.TASK_OPPORTUNITY_QUERY, erParentCase.Id);
                    EntityCollection ecOpporunity = _service.RetrieveMultiple(new FetchExpression(soppQuery)); //this.RetrieveMultiple(service, tracingService, soppQuery) != null && this.RetrieveMultiple(service, tracingService, soppQuery).Entities.Count > 0 ? this.RetrieveMultiple(service, tracingService, soppQuery)[0] : null;
                    if (ecOpporunity == null || ecOpporunity.Entities.Count < 1)
                    {
                        _tracingService.Trace("ecOpporunity is null or undefined.");
                        _tracingService.Trace("TaskManagementLogic=>TaskOpportunityTracking()- Unloaded");
                        return;
                    }
                    eOpporunity = ecOpporunity[0];

                    //if (eOpporunity == null) return;

                    string opportunityStage = string.Empty;
                    if (eOpporunity.Contains("opp.rsa_opportunitystage")
                        && ((EntityReference)((AliasedValue)eOpporunity["opp.rsa_opportunitystage"]).Value).Id != Guid.Empty)
                    {
                        opportunityStage = ((EntityReference)((AliasedValue)eOpporunity["opp.rsa_opportunitystage"]).Value).Name;
                    }
                    else
                    {
                        _tracingService.Trace("opportunityStage is null or undefined.");
                        _tracingService.Trace("TaskManagementLogic=>TaskOpportunityTracking()- Unloaded.");
                        return;
                    }


                    int sOpportunityschemes = 0;
                    //Guid oOpportunityRecordID = new Guid(((AliasedValue)eOpporunity["opp.rsa_lineofbusiness"]).Value.ToString().ToLower());
                    EntityReference oOpportunityRecordID = (EntityReference)((AliasedValue)eOpporunity.Attributes["opp.rsa_lineofbusiness"]).Value;

                    if (opportunityStage.ToLower() == "accepted"
                        && (oOpportunityRecordID.Name.ToLower() == "new business - marine europe" || oOpportunityRecordID.Name.ToLower() == "new business - marine london"))
                    {
                        if (eOpporunity.Attributes.Contains("opp.rsa_schemes") && !string.IsNullOrEmpty(eOpporunity["opp.rsa_schemes"].ToString()))
                            sOpportunityschemes = ((OptionSetValue)((AliasedValue)eOpporunity["opp.rsa_schemes"]).Value).Value;
                        if (eOpporunity.Attributes.Contains("opp.rsa_policynumbers"))
                            sPolicyNumbers = ((AliasedValue)eOpporunity["opp.rsa_policynumbers"]).Value.ToString();
                        if (String.IsNullOrEmpty(sPolicyNumbers) && eOpporunity.Attributes.Contains("opp.rsa_schemes") && sOpportunityschemes != 100000000)
                        {
                            throw new InvalidPluginExecutionException("'Add Policy Number(s) on Opportunity before closing this Task.");
                        }
                        if (String.IsNullOrEmpty(sPolicyNumbers) && (sOpportunityschemes != 866760000 || sOpportunityschemes != 866760001 || sOpportunityschemes != 100000000))
                        {   //taskList.add(OppTriggerOperations.setOpptyTaskFields(1,'Process New Business Policy (Single Policy Quote)',opptyTask.whatId,System.label.Marine_Task_User,'Unassigned'));
                            taskSubject = "Process New Business Policy(Single Policy Quote)";
                            numberOfDays = 1;
                        }

                        if (eOpporunity.Attributes.Contains("opp.rsa_masterpolicynumber"))
                            sMasterPolicyNumber = ((AliasedValue)eOpporunity["opp.rsa_masterpolicynumber"]).Value.ToString();
                        if (String.IsNullOrEmpty(sMasterPolicyNumber) && sOpportunityschemes == 100000000)
                        {
                            throw new InvalidPluginExecutionException("Add Master Policy Number on Opportunity before closing this Task.");
                        }
                        if (sOpportunityschemes == 866760000)
                        {  //taskList.add(OppTriggerOperations.setOpptyTaskFields(1,'Process New Business Cover',opptyTask.whatId,System.label.Marine_Task_User,'Unassigned'));
                            taskSubject = "Process New Business Cover";
                            numberOfDays = 1;
                        }
                        if (sOpportunityschemes == 866760001)
                        {   //taskList.add(OppTriggerOperations.setOpptyTaskFields(1,'Process New Business Scheme',opptyTask.whatId,System.label.Marine_Task_User,'Unassigned'));

                            taskSubject = "Process New Business Scheme";
                            numberOfDays = 1;
                        }
                        if (sOpportunityschemes == 100000000)
                        { //taskList.add(OppTriggerOperations.setOpptyTaskFields(1,'Process New Business Declaration',opptyTask.whatId,System.label.Marine_Task_User,'Unassigned'));
                            taskSubject = "Process New Business Declaration";
                            numberOfDays = 1;
                        }

                    }
                    else if (oOpportunityRecordID.Name.ToLower() == "renewal - marine london" || oOpportunityRecordID.Name.ToLower() == "renewal - marine europe")
                    {
                        if (opportunityStage.ToLower() == "renewed")
                        {
                            if (eOpporunity.Attributes.Contains("opp.rsa_policynumber"))
                                sPolicyNumber = ((AliasedValue)eOpporunity["opp.rsa_policynumber"]).Value.ToString();

                            if (String.IsNullOrEmpty(sPolicyNumber) && sOpportunityschemes != 100000000)
                            {
                                throw new InvalidPluginExecutionException("Add Policy Number on Opportunity before closing this Task.");
                            }
                            if (String.IsNullOrEmpty(sMasterPolicyNumber) && eOpporunity.Attributes.Contains("opp.rsa_schemes") && sOpportunityschemes == 100000000)
                            {
                                throw new InvalidPluginExecutionException("Add Master Policy Number on Opportunity before closing this Task.");
                            }
                            if (oOpportunityRecordID.Id.ToString() == "f5901d7d-b1c1-ea11-a812-000d3af010a3")
                            {//tempTask = OppTriggerOperations.setOpptyTaskFields(1, 'Process Renewal', opptyTask.whatId, System.label.Marine_Task_User, 'Unassigned');
                                taskSubject = "Process Renewal";
                                numberOfDays = 1;
                            }
                        }
                        if (opportunityStage.ToLower() == "Extended")
                        { //taskList.add(OppTriggerOperations.setOpptyTaskFields(1,'Process Extension',opptyTask.whatId,System.label.Marine_Task_User,'Unassigned'));
                            taskSubject = "Process Extension";
                            numberOfDays = 1;

                        }
                        if (opportunityStage.ToLower() == "Lapsed")
                        {
                            //taskList.add(OppTriggerOperations.setOpptyTaskFields(3, 'Process Lapse', opptyTask.whatId, System.label.Marine_Task_User, 'Unassigned'));
                            taskSubject = "Process Lapse";
                            numberOfDays = 3;

                        }
                        if (opportunityStage.ToLower() == "Non – Renewable")
                        {
                            //taskList.add(OppTriggerOperations.setOpptyTaskFields(3, 'Process Non–Renewable', opptyTask.whatId, System.label.Marine_Task_User, 'Unassigned'));
                            taskSubject = "Process Non–Renewable";
                            numberOfDays = 3;

                        }
                    }
                    this.CreateTaskBasedOnOpportunity(numberOfDays, taskSubject, activityStatus);

                    //}
                }
            }
            catch (Exception ex)
            {
                _tracingService.Trace("An error occurred in TaskManagementLogic.TaskOpportunityTracking plugin. Details: '{0}'", ex.Message);
            }
            _tracingService.Trace("TaskManagementLogic=>TaskOpportunityTracking()- Unloaded.");
        }

        /// <summary>
        /// AddQuoteDocumentsTask
        /// </summary>
        private void AddQuoteDocumentsTask()
        {
            _tracingService.Trace("TaskManagementLogic=>AddQuoteDocumentsTask()- Loaded.");
            try
            {
                if (_eParentCase.Id == Guid.Empty)
                {
                    string sQuery = string.Format(Constants.TASK_CASE_STATUS_QUERY, ((EntityReference)_eTaskNewObj["regardingobjectid"]).Id);
                    var ecCaseCollection = _service.RetrieveMultiple(new FetchExpression(sQuery));
                    if (ecCaseCollection != null && ecCaseCollection.Entities.Count > 0)
                    {
                        _eParentCase = ecCaseCollection[0];
                    }
                }

                if (_eParentCase.Id != Guid.Empty)
                {
                    if (!_bAIS_Extension_Activity_Switch)
                    {
                        object[] sKeyName = { "AIS_Extension_Activity_Switch" };
                        EntityCollection ecRSACustomLabels = this.GetCustomLabel(sKeyName);
                        if (ecRSACustomLabels != null && ecRSACustomLabels.Entities.Count > 0 && ecRSACustomLabels[0].Contains("rsa_values")
                            && !string.IsNullOrEmpty(ecRSACustomLabels[0]["rsa_values"].ToString()))
                        {
                            _oAIS_Extension_Activity_Switch = ecRSACustomLabels[0]["rsa_values"].ToString();
                            _bAIS_Extension_Activity_Switch = true;
                        }
                    }
                    //Defect id 1375 : Sumegh Dhole 23 April 2021 : Duplicate task were getting creating even after closing the task. 
                    if (_eParentCase.Attributes.Contains("pol.rsa_classofbusiness")
                           && ((EntityReference)((AliasedValue)_eParentCase.Attributes["pol.rsa_classofbusiness"]).Value).Name == "Combined"
                           && _eParentCase.Attributes.Contains("pol.rsa_productid")
                           && ((EntityReference)((AliasedValue)_eParentCase.Attributes["pol.rsa_productid"]).Value).Name == "Combined")
                    {
                        if (_oAIS_Extension_Activity_Switch.ToLower() == "true")
                        {
                            Entity oTaskEntity = new Entity(_eTaskNewObj.LogicalName);
                            oTaskEntity["rsa_recordtypename"] = _eTaskNewObj["rsa_recordtypename"];
                            oTaskEntity["rsa_tasktype"] = _eTaskNewObj["rsa_tasktype"];
                            oTaskEntity["ownerid"] = _eTaskNewObj["ownerid"];
                            oTaskEntity["subject"] = "Issue Quote Documents";
                            oTaskEntity["rsa_name"] = "Issue Quote Documents";
                            oTaskEntity["regardingobjectid"] = _eTaskNewObj["regardingobjectid"];
                            oTaskEntity["rsa_status"] = new OptionSetValue(866760000);
                            oTaskEntity["scheduledend"] = System.DateTime.Now.AddHours(24);
                            //newTask.Due_Date_Time__c = BusinessHours.add(bh.Id, system.now(), l);


                            Guid oTaskNewId = _service.Create(oTaskEntity);
                            if (!_bTargetQueueId)
                            {
                                string sQuery = string.Format(Constants.QUEUE_QUERY, "Automation");
                                var ecQueueColl = _service.RetrieveMultiple(new FetchExpression(sQuery));
                                if (ecQueueColl != null && ecQueueColl.Entities.Count > 0 && ecQueueColl[0] != null)
                                {
                                    _oTargetQueueId = ecQueueColl[0].Id;
                                    _bTargetQueueId = true;
                                }
                            }
                            if (_bTargetQueueId && _oTargetQueueId != Guid.Empty)
                                this.AddToQueue(oTaskEntity.LogicalName, oTaskNewId, _oTargetQueueId);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _tracingService.Trace("An error occurred in TaskManagementLogic.AddQuoteDocumentsTask plugin. Details: '{0}'", ex.Message);
            }
            _tracingService.Trace("TaskManagementLogic=>AddQuoteDocumentsTask()- Unloaded.");
        }

        /// <summary>
        /// AddToQueue
        /// </summary>
        /// <param name="sEntityName"></param>
        /// <param name="gEntityId"></param>
        /// <param name="oQueueId"></param>
        /// <returns></returns>
        private bool AddToQueue(string sEntityName, Guid gEntityId, Guid oQueueId)
        {
            _tracingService.Trace("Method TaskManagementLogic=>AddToQueue()- Loaded.");
            bool bCaseAllocationHappened = false;
            try
            {
                var reqAddToQueue = new AddToQueueRequest
                {
                    Target = new EntityReference(sEntityName, gEntityId),
                    DestinationQueueId = oQueueId
                };
                string responseName = _service.Execute(reqAddToQueue).ResponseName;
                if (!String.IsNullOrEmpty(responseName))
                {
                    _tracingService.Trace("'{0}' | '{1}' record has been added to '{2}' queue.", sEntityName, gEntityId, oQueueId);
                    bCaseAllocationHappened = true;
                }
            }
            catch (Exception ex)
            {
                _tracingService.Trace("An error occurred in TaskManagementLogic.AddToQueue plugin. Details: '{0}'", ex.Message);
            }

            _tracingService.Trace("Method TaskManagementLogic=>AddToQueue()- Unloaded.");
            return bCaseAllocationHappened;
        }

        /// <summary>
        /// AddAISExtensionsTask
        /// </summary>
        private void AddAISExtensionsTask()
        {
            _tracingService.Trace("TaskManagementLogic=>AddAISExtensionsTask()- Loaded.");
            try
            {
                if (_eParentCase.Id == Guid.Empty)
                {
                    string sQuery = string.Format(Constants.TASK_CASE_STATUS_QUERY, ((EntityReference)_eTaskNewObj["regardingobjectid"]).Id);
                    var ecCaseCollection = _service.RetrieveMultiple(new FetchExpression(sQuery));
                    if (ecCaseCollection != null && ecCaseCollection.Entities.Count > 0)
                    {
                        _eParentCase = ecCaseCollection[0];
                    }
                }

                if (_eParentCase.Id != Guid.Empty)
                {
                    if (!_bAIS_Extension_Activity_Switch)
                    {
                        object[] sKeyName = { "AIS_Extension_Activity_Switch" };
                        EntityCollection ecRSACustomLabels = this.GetCustomLabel(sKeyName);
                        if (ecRSACustomLabels != null && ecRSACustomLabels.Entities.Count > 0 && ecRSACustomLabels[0].Contains("rsa_values")
                            && !string.IsNullOrEmpty(ecRSACustomLabels[0]["rsa_values"].ToString()))
                        {
                            _oAIS_Extension_Activity_Switch = ecRSACustomLabels[0]["rsa_values"].ToString();
                            _bAIS_Extension_Activity_Switch = true;
                        }
                    }

                    if (_oAIS_Extension_Activity_Switch.ToLower() == "true")
                    {
                        string sPolCOBName = string.Empty;
                        string sPolProductName = string.Empty;

                        if (_eParentCase.Attributes.Contains("pol.rsa_classofbusiness")
                            && ((EntityReference)((AliasedValue)_eParentCase.Attributes["pol.rsa_classofbusiness"]).Value).Name == "Combined"
                            && _eParentCase.Attributes.Contains("pol.rsa_productid")
                            && ((EntityReference)((AliasedValue)_eParentCase.Attributes["pol.rsa_productid"]).Value).Name == "Combined")
                        {
                            Entity oTaskEntity = new Entity(_eTaskNewObj.LogicalName);
                            oTaskEntity["rsa_recordtypename"] = _eTaskNewObj["rsa_recordtypename"];
                            oTaskEntity["rsa_tasktype"] = _eTaskNewObj["rsa_tasktype"];
                            oTaskEntity["ownerid"] = _eTaskNewObj["ownerid"];
                            oTaskEntity["subject"] = "Add AIS Extensions";
                            oTaskEntity["rsa_name"] = "Add AIS Extensions";
                            oTaskEntity["regardingobjectid"] = _eTaskNewObj["regardingobjectid"];
                            oTaskEntity["rsa_status"] = new OptionSetValue(866760000);
                            oTaskEntity["scheduledend"] = System.DateTime.Now.AddHours(24);

                            Guid oTaskNewId = _service.Create(oTaskEntity);

                            if (!_bTargetQueueId)
                            {
                                string sQuery = string.Format(Constants.QUEUE_QUERY, "Automation");
                                var ecQueueColl = _service.RetrieveMultiple(new FetchExpression(sQuery)); //this.RetrieveMultiple(service, tracingService, sQuery);
                                if (ecQueueColl != null && ecQueueColl.Entities.Count > 0 && ecQueueColl[0] != null)
                                {
                                    _oTargetQueueId = ecQueueColl[0].Id;
                                    _bTargetQueueId = true;
                                }
                            }
                            if (_bTargetQueueId && _oTargetQueueId != Guid.Empty)
                                this.AddToQueue(oTaskEntity.LogicalName, oTaskNewId, _oTargetQueueId);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _tracingService.Trace("An error occurred in TaskManagementLogic.AddAISExtensionsTask plugin. Details: '{0}'", ex.Message);
            }
            _tracingService.Trace("TaskManagementLogic=>AddAISExtensionsTask()- Unloaded.");
        }

        /// <summary>
        /// ValidateActivityRecordType
        /// </summary>
        private void ValidateActivityRecordType()
        {
            _tracingService.Trace("TaskManagementLogic=>ValidateActivityRecordType()- Loaded.");
            try
            {
                _tracingService.Trace("_eParentCase.Id:" + _eParentCase.Id.ToString());
                if (_eParentCase.Id == Guid.Empty)
                {
                    _tracingService.Trace("_eParentCase.Id is empty");
                    string sQuery = string.Format(Constants.TASK_PARENT_CASE_POLICY_QUERY, ((EntityReference)_eTaskNewObj["regardingobjectid"]).Id);
                    var ecCaseCollection = _service.RetrieveMultiple(new FetchExpression(sQuery));
                    _tracingService.Trace("ecCaseCollection Count:" + ecCaseCollection.Entities.Count.ToString());
                    if (ecCaseCollection != null && ecCaseCollection.Entities.Count > 0)
                    {
                        _eParentCase = ecCaseCollection[0];
                        _tracingService.Trace("_eParentCase.Id in assigned");
                    }
                }
                _tracingService.Trace("_eParentCase.Id in assigned and checking empty");
                if (_eParentCase.Id != Guid.Empty)
                {
                    _tracingService.Trace("_eParentCase.Id contains data");
                    if (_eTaskNewObj.Attributes.Contains("rsa_tasktype"))
                    {
                        _tracingService.Trace("rsa_tasktype contains data");
                        string sCaseType = string.Empty;
                        string sUnderwriterResponse = string.Empty;
                        string sPnLCode = string.Empty;
                        string sPolicyNumber = string.Empty;
                        string sPolicySystem = string.Empty;
                        string caseRecordType = string.Empty;
                        //if (_eParentCase.Attributes.Contains("rsa_casetype") && !string.IsNullOrEmpty(_eParentCase.GetAttributeValue<EntityReference>("rsa_casetype").Name))
                        //    sCaseType = _eParentCase.GetAttributeValue<EntityReference>("rsa_casetype").Name;

                        if (!string.IsNullOrEmpty(_eTaskNewObj.GetAttributeValue<EntityReference>("rsa_tasktype").Name))
                            sCaseType = _eTaskNewObj.GetAttributeValue<EntityReference>("rsa_tasktype").Name;

                        _tracingService.Trace("sCaseType" + sCaseType);

                        if (!string.IsNullOrEmpty(_eParentCase.GetAttributeValue<EntityReference>("rsa_casetype").Name))
                            caseRecordType = _eParentCase.GetAttributeValue<EntityReference>("rsa_casetype").Name;

                        _tracingService.Trace("caseRecordType" + caseRecordType);


                        if (_eParentCase.Attributes.Contains("rsa_underwriterresponse") && !string.IsNullOrEmpty(_eParentCase["rsa_underwriterresponse"].ToString()))
                            sUnderwriterResponse = _eParentCase["rsa_underwriterresponse"].ToString();

                        _tracingService.Trace("sUnderwriterResponse" + sUnderwriterResponse);

                        if (_eParentCase.Attributes.Contains("pol.rsa_plcode") && !string.IsNullOrEmpty(((EntityReference)((AliasedValue)_eParentCase.Attributes["pol.rsa_plcode"]).Value).Name))
                            sPnLCode = ((EntityReference)((AliasedValue)_eParentCase.Attributes["pol.rsa_plcode"]).Value).Name;

                        if (_eParentCase.Attributes.Contains("pol.rsa_policysystemcode") && !string.IsNullOrEmpty(_eParentCase.FormattedValues["pol.rsa_policysystemcode"]))
                            sPolicySystem = _eParentCase.FormattedValues["pol.rsa_policysystemcode"];

                        if (_eParentCase.Attributes.Contains("pol.rsa_name") && !string.IsNullOrEmpty(_eParentCase["pol.rsa_name"].ToString()))
                            sPolicyNumber = ((AliasedValue)_eParentCase["pol.rsa_name"]).Value.ToString();

                        if (sCaseType == "Process Query" && sUnderwriterResponse == string.Empty && (caseRecordType.Equals("SME - Accounts New") || caseRecordType.Equals("SME - Accounts")))
                        //bug 2003 -  This condition should only be triggered for Case type sme - accounts.
                        {
                            string sMessage = "Please complete Underwriter Response field on the case." + System.Environment.NewLine;
                            _tracingService.Trace(sMessage);

                            _bPreUpdateFailed = true;
                            _sPreUpdateFailedMessage = sMessage;

                            return;
                        }
                        else if (sCaseType == "Debit Premium" && sPnLCode == "Mid-Market" && (sPolicyNumber == string.Empty || sPolicySystem == string.Empty))
                        {
                            string sMessage = "Please complete Policy Number and Policy System fields on the opportunity record and in the external rating engine." + System.Environment.NewLine;
                            _tracingService.Trace(sMessage);

                            _bPreUpdateFailed = true;
                            _sPreUpdateFailedMessage = sMessage;

                            return;
                        }
                    }
                }
            }
            catch (InvalidPluginExecutionException ex)
            {
                _tracingService.Trace("An error occurred in Task.PreUpdate plugin. Details: '{0}'", ex.Message);
                throw new InvalidPluginExecutionException(ex.Message + System.Environment.NewLine);
            }
            catch (Exception ex)
            {
                _tracingService.Trace("An error occurred in Exception.Task.PreUpdate plugin. Details: '{0}'", ex.Message);
                throw new Exception(ex.Message + System.Environment.NewLine);
            }
            _tracingService.Trace("TaskManagementLogic=>ValidateActivityRecordType()- Unloaded.");
        }

        /// <summary>
        /// DefineTaskDueDateTime
        /// </summary>
        private void DefineTaskDueDateTime()
        {
            _tracingService.Trace("TaskManagementLogic=>DefineTaskDueDateTime()- Loaded.");
            try
            {
                object[] oKeys = { "Case_Record_Types_to_Apply_Exclusion_of_Activities", "Activities_To_Exclude", "Case_Types_To_Change_Due_Date" };
                EntityCollection ecRSACustomLabels = this.GetCustomLabel(oKeys);

                if (ecRSACustomLabels == null && ecRSACustomLabels.Entities.Count < 1)
                {
                    _tracingService.Trace("ecRSACustomLabels is null or undefined.");
                    return;
                }

                string sCRTApplyExclusionOfAct = string.Empty;
                string sActivitiesToExclude = string.Empty;
                string sCTToChangeDueDate = string.Empty;

                Entity eCRTApplyExclusionOfAct = ecRSACustomLabels.Entities.First(x => x["rsa_name"].ToString() == "Case_Record_Types_to_Apply_Exclusion_of_Activities");
                Entity eActivitiesToExclude = ecRSACustomLabels.Entities.First(x => x["rsa_name"].ToString() == "Activities_To_Exclude");
                Entity eCTToChangeDueDate = ecRSACustomLabels.Entities.First(x => x["rsa_name"].ToString() == "Case_Types_To_Change_Due_Date");
                //var eCRTApplyExclusionOfAct = from label in ecRSACustomLabels.Entities
                //                               where label["rsa_name"].ToString() == "Case_Record_Types_to_Apply_Exclusion_of_Activities"
                //                               select label;

                //var eActivitiesToExclude = from label in ecRSACustomLabels.Entities
                //                            where label["rsa_name"].ToString() == "Activities_To_Exclude"
                //                            select label;

                //var eCTToChangeDueDate = from label in ecRSACustomLabels.Entities
                //                          where label["rsa_name"].ToString() == "Case_Types_To_Change_Due_Date"
                //                          select label;

                if (eCRTApplyExclusionOfAct != null && eCRTApplyExclusionOfAct.Contains("rsa_values"))
                {
                    sCRTApplyExclusionOfAct = eCRTApplyExclusionOfAct["rsa_values"].ToString();
                }
                if (eActivitiesToExclude != null && eActivitiesToExclude.Contains("rsa_values"))
                {
                    sActivitiesToExclude = eActivitiesToExclude["rsa_values"].ToString();
                }
                if (eCTToChangeDueDate != null && eCTToChangeDueDate.Contains("rsa_values"))
                {
                    sCTToChangeDueDate = eCTToChangeDueDate["rsa_values"].ToString();
                }

                if (sCRTApplyExclusionOfAct == string.Empty || sActivitiesToExclude == string.Empty || sCTToChangeDueDate == string.Empty)
                {
                    _tracingService.Trace("Either of vCase_Record_Types_to_Apply_Exclusion_of_Activities, vActivities_To_Exclude and vCase_Types_To_Change_Due_Date is null or undefined.");
                    _tracingService.Trace("TaskManagementLogic=>DefineTaskDueDateTime()- Unloaded");
                    return;
                }

                //<condition value="CSI Activity Template" attribute="rsa_recordtypename" operator="eq" />
                //if (tsk1.WhatId != null && String.valueOf(tsk1.WhatId).substring(0, 3) == '500' && !(tsk1.RecordTypeName__c.equals('CSI Activity Template')))
                if (_eTaskOriginalObj.Attributes.Contains("rsa_recordtypename") && _eTaskOriginalObj["rsa_recordtypename"].ToString().ToLower() == "csi activity template")
                {
                    //if(tsk1.Subject!= null && CaseMap.get(tsk1.WhatId).P_L__c != null && CaseMap.get(tsk1.WhatId).P_L__c == 'Mid-Market')    
                    if (_eParentCase.Attributes.Contains("rsa_pl") && _eParentCase["rsa_pl"].ToString().ToLower() == "mid-market")
                    {
                        //if(Label.Case_Record_Types_to_Apply_Exclusion_of_Activities.contains(CaseMap.get(tsk1.WhatId).RecordTypeId))
                        if (_eParentCase.Attributes.Contains("rsa_recordtypename") && sCRTApplyExclusionOfAct.Contains(_eParentCase["rsa_recordtypename"].ToString()))
                        {
                            //if(!(Label.Activities_To_Exclude.contains(tsk1.Subject) && Label.Case_Types_To_Change_Due_Date.contains(CaseMap.get(tsk1.WhatId).RecordTypeId)))
                            if (!(_eTaskOriginalObj.Attributes.Contains("rsa_name") && sActivitiesToExclude.Contains(_eTaskOriginalObj["rsa_name"].ToString()))
                                && (_eParentCase.Attributes.Contains("rsa_recordtypename") && sCTToChangeDueDate.Contains(_eParentCase["rsa_recordtypename"].ToString())))
                            {
                                //if (tsk1.Due_Date_Time__c != null)
                                if (_eTaskOriginalObj.Attributes.Contains("rsa_duedatetime") && _eTaskOriginalObj["rsa_duedatetime"] != null)
                                {
                                    //tsk1.Due_Date_Time__c = DateTime.newInstance(tsk1.Due_Date_Time__c.date(),Time.newInstance(18,0,0,0));
                                    DateTime dtDueDateTime = ((DateTime)_eTaskOriginalObj["rsa_duedatetime"]);
                                    _eTaskOriginalObj["rsa_duedatetime"] = new DateTime(dtDueDateTime.Year, dtDueDateTime.Month, dtDueDateTime.Day, 18, 0, 0, 0);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _tracingService.Trace("An error occurred in TaskManagementLogic.DefineTaskDueDateTime plugin. Details: '{0}'", ex.Message);
            }
            _tracingService.Trace("TaskManagementLogic=>DefineTaskDueDateTime()- Unloaded.");
        }

        /// <summary>
        /// ReactivateParentCase
        /// </summary>
        private void ReactivateParentCase()
        {
            _tracingService.Trace("TaskManagementLogic=>CheckAndReactivateCase()- Loaded.");
            try
            {
                if (_eParentCase.Contains("ticketnumber") && !string.IsNullOrEmpty(_eParentCase["ticketnumber"].ToString()))
                    _sTicketNumber = _eParentCase["ticketnumber"].ToString();
                _tracingService.Trace("Parent Case : '{0}' has been identified.", _sTicketNumber);
                if (_eParentCase.Attributes.Contains("rsa_status") &&
                    (((AliasedValue)_eParentCase["rst.rsa_name"]).Value.ToString().ToLower().Contains("complete") || ((AliasedValue)_eParentCase["rst.rsa_name"]).Value.ToString().ToLower().Contains("close")))
                {
                    _tracingService.Trace("Parent Case : '{0}' is inactive.", _sTicketNumber);
                    _tracingService.Trace("Fetching relevant 'Renewal' status record.");
                    string sStatusQuery = Constants.RSA_STATUS_RENEWAL_QUERY;
                    var ecStatusCollection = _service.RetrieveMultiple(new FetchExpression(sStatusQuery)); //this.RetrieveMultiple(service, tracingService, sStatusQuery);
                    if (ecStatusCollection != null && ecStatusCollection.Entities.Count > 0)
                    {
                        _tracingService.Trace("'{0}' | '{1}' status has been fetched.", ecStatusCollection.Entities[0].Contains("rsa_name") ? ecStatusCollection.Entities[0]["rsa_name"].ToString() : string.Empty, ecStatusCollection.Entities[0].Id);
                        _tracingService.Trace("Re-activating the parent Case : '{0}'.", _sTicketNumber);
                        Entity eParentCaseUpdate = new Entity(_eParentCase.LogicalName);
                        eParentCaseUpdate.Id = _eParentCase.Id;

                        //2489 : Bubun : Case to be marked as renewed for below case types else reopened
                        if ((_eParentCase.Attributes.Contains("rsa_casetype")) && (!_eParentCase.GetAttributeValue<EntityReference>("rsa_casetype").Name.Equals("New Business")
                                && !_eParentCase.GetAttributeValue<EntityReference>("rsa_casetype").Name.Equals("Revised Renewal")
                                && !_eParentCase.GetAttributeValue<EntityReference>("rsa_casetype").Name.Equals("Renewal")))
                        {
                            eParentCaseUpdate["rsa_status"] = new EntityReference("rsa_status", ecStatusCollection.Entities[0].Id);
                        }
                        else
                        {
                            Entity StatusInfo = GetLookUpDetailsbyText(_service, "Re-Opened", "rsa_status", _eParentCase.GetAttributeValue<EntityReference>("rsa_casetype").Id);
                            eParentCaseUpdate["rsa_status"] = new EntityReference(StatusInfo.LogicalName, StatusInfo.Id);
                            _tracingService.Trace("Case Status" + StatusInfo.Id);

                            //Queue Update
                            if ((_eParentCase.Attributes.Contains("ownerid")) && (_eParentCase.Attributes.Contains("rsa_previousqueue"))) //(Ccase.GetAttributeValue<EntityReference>("ownerid").Name.Equals("Unassigned ."))
                            {
                                _tracingService.Trace("Test Owner");
                                Guid previousQueue = ((EntityReference)_eParentCase.Attributes["rsa_previousqueue"]).Id;
                                _tracingService.Trace("previousQueue" + previousQueue);
                                if (previousQueue != Guid.Empty)
                                    this.AddToQueue(_eParentCase.LogicalName, eParentCaseUpdate.Id, previousQueue);
                                _tracingService.Trace("Assign Queue Done");

                            }
                        }
                        _service.Update(eParentCaseUpdate);
                        _tracingService.Trace("Parent Case : '{0}' has been activated.", _sTicketNumber);
                    }
                }
                else
                {
                    _tracingService.Trace("Parent Case : '{0}' is active.", _sTicketNumber);
                }
            }
            catch (Exception ex)
            {
                _tracingService.Trace("An error occurred in TaskManagementLogic.CheckAndReactivateCase plugin. Details: '{0}'", ex.Message);
            }
            _tracingService.Trace("TaskManagementLogic=>CheckAndReactivateCase()- Unloaded.");
        }

        /// <summary>
        /// IsTaskCompleted
        /// </summary>
        /// <param name="iTaskStatus"></param>
        /// <returns></returns>
        internal bool IsTaskCompleted(int iTaskStatus)
        {
            _tracingService.Trace("TaskManagementLogic=>IsTaskCompleted()- Loaded.");
            bool bIsTaskCompleted = false;
            try
            {
                var values = Enum.GetValues(typeof(Task_rsa_Status_Completed)).Cast<Task_rsa_Status_Completed>();
                foreach (int item in Enum.GetValues(typeof(Task_rsa_Status_Completed)))
                {
                    if (iTaskStatus == item)
                    {
                        bIsTaskCompleted = true;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                _tracingService.Trace("An error occurred in TaskManagementLogic.PrepareTaskQuery plugin. Details: '{0}'", ex.Message);
            }

            _tracingService.Trace("TaskManagementLogic=>IsTaskCompleted()- Unloaded.");
            return bIsTaskCompleted;
        }

        /// <summary>
        /// SLATrackingAndMaintenance
        /// </summary>
        private void SLATrackingAndMaintenance()
        {
            _tracingService.Trace("TaskManagementLogic=>SLATrackingAndMaintenance()- Loaded");
            try
            {

                _tracingService.Trace("Cascading Data into PostCreate ");
                string sQuery = string.Format(Constants.TASK_CASE_QUERY, _eTaskOriginalObj.Id);
                EntityCollection ecTaskCOllection = _service.RetrieveMultiple(new FetchExpression(sQuery));
                if (ecTaskCOllection != null || ecTaskCOllection.Entities.Count > 0)
                    _eTaskNewObj = ecTaskCOllection[0];
                
                this.CascadeTaskInfoToCase();
                if (_eTaskNewObj == null || _eTaskNewObj.Id == Guid.Empty)
                {
                    _tracingService.Trace("unable to fetch _eTask with Id: '{0}'", _eTaskOriginalObj.Id);
                    _tracingService.Trace("TaskManagementLogic=>SLATrackingAndMaintenance()- Unloaded");
                    return;
                }

                bool bCaseToBeUpdated = false;
                /// <summary>
                /// inc.rsa_nextactiondate has to be changed on Incident according to new task.rsa_duedatetime. 
                /// </summary>
                if (_eTaskNewObj.Attributes.Contains("rsa_duedatetime"))
                {
                    _tracingService.Trace("_eTask.Attributes.Contains('rsa_duedatetime')");
                    if (!_eTaskNewObj.Attributes.Contains("inc.rsa_nextactiondate") ||
                        (_eTaskNewObj.Attributes.Contains("inc.rsa_nextactiondate")
                        && Convert.ToDateTime(((AliasedValue)_eTaskNewObj["inc.rsa_nextactiondate"]).Value.ToString()) >= Convert.ToDateTime(_eTaskNewObj["rsa_duedatetime"].ToString())))
                    {
                        bCaseToBeUpdated = true;
                        _tracingService.Trace("_eTask.inc.rsa_nextactiondate>=_eTask.rsa_duedatetime");
                    }
                }

                /// <summary>
                /// inc.ownerid has to be changed on Incident according to new task.ownerid. 
                /// </summary>
                if (!bCaseToBeUpdated && _eTaskNewObj.Attributes.Contains("ownerid") && _eTaskNewObj.Attributes.Contains("inc.ownerid")
                    && ((EntityReference)_eTaskNewObj.Attributes["ownerid"]).Id != ((EntityReference)((AliasedValue)_eTaskNewObj.Attributes["inc.ownerid"]).Value).Id)
                {
                    bCaseToBeUpdated = true;
                    _tracingService.Trace("_eTask.inc.ownerid!=_eTask.ownerid");
                }
                _tracingService.Trace("_bIsTaskCompleted is line 993'{0}'", _bIsTaskCompleted);
                ///20052021 Check

                //var eCase = new Guid(((AliasedValue)_eTaskNewObj["inc.incidentid"]).Value.ToString());

                //  this.CascadeTaskInfoToCase();

                ///20052021
                _tracingService.Trace("_bIsTaskCompleted '{0}'", bCaseToBeUpdated);
                if (bCaseToBeUpdated)
                {
                    if (!_bIsTaskCompleted)
                    {
                        _tracingService.Trace("Inside if !_bIsTaskCompleted && bCaseToBeUpdated");
                        //var eCase = new Guid(((AliasedValue)_eTaskNewObj["inc.incidentid"]).Value.ToString());
                       
                        _tracingService.Trace("Inside if !_bIsTaskCompleted && bCaseToBeUpdated >> calling from PostUpdateActivityNameOwner");
                        this.CascadeTaskInfoToCase();
                    }

                    if (_bIsTaskCompleted)//if (_bIsTaskCompleted && _eTaskNewObj.Attributes.Contains("rsa_promisenonpromise") && _eTaskNewObj["rsa_promisenonpromise"].ToString().ToLower() == "promise")
                    {
                        bool bToBeUpdated = false;
                        Entity eCase = new Entity("incident");
                        eCase.Id = new Guid(((AliasedValue)_eTaskNewObj["inc.incidentid"]).Value.ToString());
                        if (_eTaskNewObj.Attributes.Contains("rsa_nextcallduedatetime"))
                        {
                            eCase["rsa_technextcallduedate"] = _eTaskNewObj["rsa_nextcallduedatetime"];
                            _tracingService.Trace("eCase['rsa_technextcallduedate'] = _eTask['rsa_nextcallduedatetime']");
                            bToBeUpdated = true;
                        }
                        {
                            eCase["rsa_techtaskid"] = _eTaskNewObj.Id.ToString().Substring(0, 18);
                            _tracingService.Trace("eCase['rsa_techtaskid'] = _eTask.Id.ToString().Substring(0, 18)");
                            bToBeUpdated = true;
                        }
                        if (_eTaskNewObj.Attributes.Contains("subject"))
                        {
                            //  eCase["rsa_nextactivityname"] = _eTaskNewObj["subject"];
                            bToBeUpdated = true;
                        }
                        if (_eTaskNewObj.Attributes.Contains("rsa_name"))
                        {
                            //eCase["rsa_nextactivityname"] = _eTaskNewObj["rsa_name"]; //Radhakrishna N:INC2211190 - 25TH Jul 2022 
                            bToBeUpdated = true;
                        }

                        if (bToBeUpdated)
                        {
                            _service.Update(eCase);
                            _tracingService.Trace("eCase has been updated.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _tracingService.Trace("An error occurred in Task.SLATrackingAndMaintenance plugin. Details: '{0}'", ex.Message);
            }

            _tracingService.Trace("TaskManagementLogic=>SLATrackingAndMaintenance()- Unloaded");
        }

        /// <summary>
        /// CascadeUserInfoToTask
        /// </summary>
        /// <param name="gOwnerId"></param>
        private void CascadeUserInfoToTask(Guid gOwnerId)
        {
            _tracingService.Trace("TaskManagementLogic=>CascadeUserInfoToTask()- Loaded");
            try
            {
                ColumnSet csUser = new ColumnSet("fullname", "businessunitid", "systemuserid", "rsa_userteamlevel2", "rsa_division", "rsa_usersite");
                _eTaskOwner = _service.Retrieve("systemuser", gOwnerId, csUser);
                if (_eTaskOwner != null && _eTaskOwner.Id != Guid.Empty)
                {
                    _tracingService.Trace("Task owner: '{0}' with Id: '{1}' has been fetched successfully.", _eTaskOwner["fullname"].ToString(), gOwnerId.ToString());

                    if (_eTaskOriginalObj.Attributes.Contains("rsa_status"))
                    {
                        int oTaskStatus = -1;
                        oTaskStatus = ((OptionSetValue)_eTaskOriginalObj.Attributes["rsa_status"]).Value;
                        _bIsTaskCompleted = this.IsTaskCompleted(oTaskStatus);
                    }

                    if (!_bIsTaskCompleted)
                    {
                        _tracingService.Trace("Executing non-completed Task insert logic.");

                        if (_eTaskOwner.Contains("fullname") && _eTaskOwner["fullname"] != null)
                            _eTaskOriginalObj["rsa_initialassignedtouser"] = _eTaskOwner["fullname"].ToString();

                        if (_eTaskOwner.Contains("rsa_division") && _eTaskOwner["rsa_division"] != null)
                            _eTaskOriginalObj["rsa_initialassignedtodivision"] = new OptionSetValue(((OptionSetValue)(_eTaskOwner["rsa_division"])).Value);
                        if (_eTaskOwner.Contains("rsa_usersite") && _eTaskOwner["rsa_usersite"] != null)
                            _eTaskOriginalObj["rsa_initialassignedtosite"] = new OptionSetValue(((OptionSetValue)(_eTaskOwner["rsa_usersite"])).Value);
                        /*
                        if (_eTaskOwner.Contains("rsa_userteamlevel2") && _eTaskOwner["rsa_userteamlevel2"] != null)
                            _eTask["rsa_initialassignedtoteam"] = new OptionSetValue(((OptionSetValue)(_eTaskOwner["rsa_userteamlevel2"])).Value);
                        */
                    }
                    else
                    {
                        _tracingService.Trace("Executing completed Task insert logic.");

                        if (_eTaskOwner.Contains("fullname") && _eTaskOwner["fullname"] != null)
                            _eTaskOriginalObj["rsa_completedbyuser"] = _eTaskOwner["fullname"].ToString();
                        if (_eTaskOwner.Contains("rsa_division") && _eTaskOwner["rsa_division"] != null)
                            _eTaskOriginalObj["rsa_completedbydivision"] = new OptionSetValue(((OptionSetValue)(_eTaskOwner["rsa_division"])).Value);
                        if (_eTaskOwner.Contains("rsa_usersite") && _eTaskOwner["rsa_usersite"] != null)
                            _eTaskOriginalObj["rsa_completedbysite"] = new OptionSetValue(((OptionSetValue)(_eTaskOwner["rsa_usersite"])).Value);
                        /*
                        if (_eTaskOwner.Contains("rsa_userteamlevel2") && _eTaskOwner["rsa_userteamlevel2"] != null)
                            _eTask["rsa_completedbyteam"] = new OptionSetValue(((OptionSetValue)(_eTaskOwner["rsa_userteamlevel2"])).Value);
                        */
                    }

                    if (_eTaskOriginalObj.Attributes.Contains("scheduledend") && _eTaskOriginalObj["scheduledend"] != null)
                    {
                        _eTaskOriginalObj["rsa_activitydate"] = _eTaskOriginalObj["scheduledend"];
                    }
                    else if (_eTaskOriginalObj.Attributes.Contains("rsa_duedatetime") && _eTaskOriginalObj["rsa_duedatetime"] != null)
                    {
                        _eTaskOriginalObj["rsa_activitydate"] = _eTaskOriginalObj["rsa_duedatetime"];
                    }
                }
                else
                {
                    _tracingService.Trace("Task owner: '{0}' could not be fetched.", gOwnerId);
                }
            }
            catch (Exception ex)
            {
                _tracingService.Trace("An error occurred in TaskManagementLogic.CascadeUserInfoToTask plugin. Details: '{0}'", ex.Message);
            }

            _tracingService.Trace("TaskManagementLogic=>CascadeUserInfoToTask()- Unloaded");
        }

        public static Entity GetLookUpDetailsbyText(IOrganizationService service, string pName, string entityName, Guid casetype)
        {
            try
            {
                var entity = new Entity(entityName);
                string fetchQuery = "<fetch mapping = 'logical'>";
                fetchQuery += "<entity name = '" + entityName + "'>";
                fetchQuery += "<attribute name='rsa_name' />";
                fetchQuery += "<filter type = 'and'>";
                fetchQuery += "<condition attribute = 'rsa_name' operator= 'eq' value = '" + pName + "' />";
                if (casetype != Guid.Empty)
                    fetchQuery += "<condition attribute = 'rsa_casetype' operator= 'eq' value = '" + casetype + "' />";
                fetchQuery += "</filter>";
                fetchQuery += "</entity>";
                fetchQuery += "</fetch>";
                EntityCollection lobDetails = service.RetrieveMultiple(new FetchExpression(fetchQuery));
                if (lobDetails.Entities.Count > 0)
                {
                    foreach (var entities in lobDetails.Entities)
                    {
                        entity = entities;
                    }
                }
                return entity;
            }
            catch (Exception)
            {
                throw;
            }
        }


        /// <summary>
        /// CascadeTaskInfoToCase
        /// 
        /// 
        /// </summary>
        public void CascadeTaskInfoToCase()
        {
            _tracingService.Trace("TaskManagementLogic=>CascadeTaskInfoToCase()- Loaded");
            try
            {
                //20052021 bug 1439

                Entity entity = new Entity("incident");
                Entity _enTaskFromCase = null;
                _tracingService.Trace("reached 1156");
                //Defect id 1962 1995 &  : Sumegh Dhole Updated source code for the object reference error : ISV code fix
                entity.Id = ((AliasedValue)_eTaskNewObj["inc.incidentid"]) != null ? ((AliasedValue)_eTaskNewObj["inc.incidentid"]).Value != null ? new Guid(((AliasedValue)_eTaskNewObj["inc.incidentid"]).Value.ToString()) : Guid.Empty : Guid.Empty;
                //entity.Id = new Guid(((AliasedValue)_eTaskNewObj["inc.incidentid"]).Value.ToString());
                _tracingService.Trace("reached 1160");
                if (entity.Id != Guid.Empty)
                {
                    _tracingService.Trace("TaskManagementLogic=>CascadeTaskInfoToCase - eNTITYid of case" + entity.Id);
                    string sQuery = string.Format(Constants.TASK_NOTCOMPLETED_CASE_QUERY, entity.Id);
                    EntityCollection CaseTaskCOllection = _service.RetrieveMultiple(new FetchExpression(sQuery));
                    _tracingService.Trace("TaskManagementLogic=>CascadeTaskInfoToCase - Tasks  of case" + CaseTaskCOllection.Entities.Count);
                    if (CaseTaskCOllection != null && CaseTaskCOllection.Entities.Count > 0)
                    {
                        //TFS 2037: Quote Work Up task should take priority if Due date is same for Motor Fleet COB
                        _enTaskFromCase = CaseTaskCOllection.Entities[0];
                        DateTime minDueDateTime = _enTaskFromCase.Attributes.Contains("rsa_duedatetime") ? _enTaskFromCase.GetAttributeValue<DateTime>("rsa_duedatetime") : DateTime.MinValue;
                        _tracingService.Trace("MinDueDate" + minDueDateTime);
                        var Case = _service.Retrieve(entity.LogicalName, entity.Id, new ColumnSet("rsa_classofbusiness"));
                        var COB = Case.GetAttributeValue<string>("rsa_classofbusiness");
                        _tracingService.Trace("COB" + COB);
                        foreach (var en in CaseTaskCOllection.Entities)
                        {
                            if (en.GetAttributeValue<DateTime>("rsa_duedatetime").Equals(minDueDateTime) && en.GetAttributeValue<string>("subject").Equals("Quote Work Up") && COB.Equals("Motor Fleet"))
                            {
                                _enTaskFromCase = en;
                                _tracingService.Trace("Success");
                                break;
                            }
                            //_enTaskFromCase = en;
                            //_tracingService.Trace("TaskManagementLogic=>CascadeTaskInfoToCase Task from case retreived");
                            //break;
                        }
                        if (_enTaskFromCase != null)
                        {
                            string taskSubject = _enTaskFromCase.Attributes.Contains("subject") ? _enTaskFromCase.GetAttributeValue<string>("subject") : string.Empty;
                            DateTime Duedate = _enTaskFromCase.Attributes.Contains("rsa_duedatetime") ? _enTaskFromCase.GetAttributeValue<DateTime>("rsa_duedatetime") : DateTime.MinValue;
                            EntityReference owner = _enTaskFromCase.Attributes.Contains("ownerid") ? _enTaskFromCase.GetAttributeValue<EntityReference>("ownerid") : null;
                            EntityReference taskQueue = _enTaskFromCase.Attributes.Contains("rsa_queue") ? _enTaskFromCase.GetAttributeValue<EntityReference>("rsa_queue") : null;

                            if (taskQueue != null && taskQueue.Id != Guid.Empty)
                            {
                                _tracingService.Trace("TaskQueue" + taskQueue.Name);
                                entity["rsa_currentactivityqueue"] = new EntityReference(taskQueue.LogicalName, taskQueue.Id);
                            }
                            else
                            {
                                _tracingService.Trace("Task Queue is empty");
                                entity["rsa_currentactivityqueue"] = null;
                            }

                            if (owner != null && owner.Id != Guid.Empty)
                            {
                                _tracingService.Trace("owner" + owner.Name);
                                entity["rsa_activityownerid"] = new EntityReference(owner.LogicalName, owner.Id);
                            }
                            if (Duedate != DateTime.MinValue)
                            {
                                //Current Activity Due Date should have thevalue of least due date time of Open tasks
                                _tracingService.Trace("Due date when task is not completed");
                                entity["rsa_nextactiondate"] = Duedate; //bug 1849 Due date not copied to next call due date field(CASE)
                            }
                            if (taskSubject != null)
                            {
                                _tracingService.Trace("taskSubject " + taskSubject);

                                entity["rsa_nextactivityname"] = taskSubject; //20052021 bug 1439
                            }
                            if (_eTaskNewObj.Attributes.Contains("rsa_duedatetime"))
                                // entity["rsa_nextactiondate"] = _eTaskNewObj["rsa_duedatetime"];
                                //if (_eTaskNewObj.Attributes.Contains("subject"))
                                entity["rsa_nextactivityname"] = taskSubject; //20052021 bug 1439
                                                                              //if (_eTaskNewObj.Attributes.Contains("rsa_name"))
                                                                              //entity["rsa_nextactivityname"] = _eTaskNewObj["rsa_name"];//Radhakrishna N:INC2211190 - 25TH Jul 2022
                                                                              //if (_eTaskNewObj.Attributes.Contains("ownerid"))
                                                                              //entity["ownerid"] = _eTaskNewObj["ownerid"];
                            if (_eTaskNewObj.Attributes.Contains("rsa_warnafterdatetime"))
                                entity["rsa_warnafterdatetimeoncase"] = _eTaskNewObj["rsa_warnafterdatetime"];


                            DateTime Duedateoftask = _eTaskNewObj.Attributes.Contains("scheduledend") ? _eTaskNewObj.GetAttributeValue<DateTime>("scheduledend") :
                               preImage.Attributes.Contains("scheduledend") ? preImage.GetAttributeValue<DateTime>("scheduledend") :
                                DateTime.MinValue;
                            _tracingService.Trace("reached 1193");

                            int? userTimeZone = RetrieveCurrentUsersSettings(_service);
                            Duedate = RetrieveLocalTimeFromUTCTime(Duedate, userTimeZone, _service);

                            if (Duedate != DateTime.MinValue)
                            {

                                _eTaskNewObj["rsa_duedatetime"] = Duedate;

                                //_service.Update(_eTaskNewObj);//

                            }

                            _service.Update(entity);
                        }
                    }

                    _tracingService.Trace("parent case has been updated.");
                }
            }
            catch (Exception ex)
            {
                _tracingService.Trace("An error occurred in Task.CascadeTaskInfoToCase plugin. Details: '{0}'", ex.Message);
            }
            _tracingService.Trace("TaskManagementLogic=>CascadeTaskInfoToCase()- Unloaded");
        }
        public int? RetrieveCurrentUsersSettings(IOrganizationService service)

        {

            var currentUserSettings = service.RetrieveMultiple(

                new QueryExpression("usersettings")

                {

                    ColumnSet = new ColumnSet("timezonecode"),

                    Criteria = new FilterExpression

                    {

                        Conditions =

                        {

                            new ConditionExpression("systemuserid", ConditionOperator.EqualUserId)

                        }

                    },
                    NoLock = true

                }).Entities[0].ToEntity<Entity>();

            //return time zone code

            return (int?)currentUserSettings.Attributes["timezonecode"];

        }


        ///

        ///  Retrive the local time from the UTC time.

        ///

        /// UTC Date time which needs to convert to Local DateTime

        /// TimeZoneCode

        /// IOrganizationService service

        ///

        public DateTime RetrieveLocalTimeFromUTCTime(DateTime utcTime, int? timeZoneCode, IOrganizationService service)

        {

            if (!timeZoneCode.HasValue)

                //return DateTime.Now;
                return DateTime.UtcNow;

            var request = new LocalTimeFromUtcTimeRequest

            {

                TimeZoneCode = timeZoneCode.Value,
                //02/09/2022: Task completion error
                UtcTime = utcTime.ToUniversalTime()
                //Remediation - 22/07/2022
                //UtcTime = utcTime

            };

            var response = (LocalTimeFromUtcTimeResponse)service.Execute(request);

            return response.LocalTime;

        }


        ///

        ///  Retrive the UTC DateTime from Local Date time format.

        ///

        /// Local Date time which needs to convert to UTC

        /// TimeZoneCode

        /// IOrganizationService service

        ///

        public DateTime RetrieveUTCTimeFromLocalTime(DateTime localTime, int? timeZoneCode, IOrganizationService service)

        {

            if (!timeZoneCode.HasValue)

                return DateTime.Now;


            var request = new UtcTimeFromLocalTimeRequest

            {

                TimeZoneCode = timeZoneCode.Value,

                LocalTime = localTime

            };

            var response = (UtcTimeFromLocalTimeResponse)service.Execute(request);

            return response.UtcTime;

        }

        /// <summary>
        /// GetCustomLabel
        /// </summary>
        /// <param name="sKeyName"></param>
        /// <returns></returns>
        private EntityCollection GetCustomLabel(object[] sKeyName)
        {
            _tracingService.Trace("TaskManagementLogic=>GetCustomLabel()- Loaded.");
            EntityCollection ecRSACustomLabels = new EntityCollection();
            try
            {
                QueryExpression query = new QueryExpression
                {
                    Distinct = false,
                    EntityName = "rsa_customlabel",
                    ColumnSet = new ColumnSet("rsa_name", "rsa_values", "rsa_shortdescription", "rsa_categories"),
                    Criteria =
                    {
                        Filters =
                        {
                            new FilterExpression
                            {
                                FilterOperator = LogicalOperator.And,
                                Conditions =
                                {
                                    new ConditionExpression("rsa_name", ConditionOperator.In, sKeyName),
                                },
                            },
                        }
                    },
                    NoLock = true
                };

                #region Code commented during performance testing.
                /*
                var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='rsa_customlabel'>
                                <attribute name='rsa_values' />
                                <attribute name='rsa_shortdescription' />
                                <attribute name='rsa_categories' />  
                                <filter type='and'>
                                  <condition attribute='rsa_name' operator='eq' value='{0}' />
                                </filter>
                              </entity>
                            </fetch>";
                var entityCustomLevel = _service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, sKeyName)));
                */
                #endregion
                ecRSACustomLabels = _service.RetrieveMultiple(query);
            }
            catch (Exception ex)
            {
                _tracingService.Trace("An error occurred in TaskManagementLogic.GetCustomLabel plugin. Details: '{0}'", ex.Message);
            }

            _tracingService.Trace("TaskManagementLogic=>GetCustomLabel()- Unloaded.");
            return ecRSACustomLabels;
        }

        /// <summary>
        /// GetUserRoles
        /// </summary>
        /// <param name="ecUserRoles"></param>
        private void GetUserRoles(out EntityCollection ecUserRoles)
        {
            _tracingService.Trace("Method TaskManagementLogic=>GetUserRoles()- Loaded.");
            ecUserRoles = new EntityCollection();
            try
            {
                var fetch = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' >
                                <entity name='systemuserroles' >
                                    <attribute name='systemuserid' />
                                    <attribute name='roleid' />
                                    <filter type='and' >
                                        <condition attribute='systemuserid' operator='eq' value='{0}' />
                                    </filter>
                                    <link-entity name='systemuser' from='systemuserid' to='systemuserid' link-type='inner' alias='user' >
                                        <attribute name='fullname' />
                                    </link-entity>
                                    <link-entity name='role' from='roleid' to='roleid' link-type='inner' alias='role' >
                                        <attribute name='name' />
                                        <attribute name='roleid' />
                                    </link-entity>
                                </entity>
                            </fetch>";

                fetch = string.Format(fetch, _gLoggedInUserId);
                ecUserRoles = _service.RetrieveMultiple(new FetchExpression(fetch));
            }
            catch (Exception ex)
            {
                _tracingService.Trace("An error occurred in TaskManagementLogic.GetUserRoles plugin. Details: '{0}'", ex.Message);
            }
            _tracingService.Trace("Method TaskManagementLogic=>GetUserRoles()- Unloaded.");
        }

        /// <summary>
        /// IsUserAuthorizeToDeleteTask
        /// </summary>
        /// <param name="sDeleteRestrictedMessage"></param>
        /// <param name="bIsDeleteRestricted"></param>
        private void IsUserAuthorizeToDeleteTask(out string sDeleteRestrictedMessage, out bool bIsDeleteRestricted)
        {
            _tracingService.Trace("TaskManagementLogic=>IsUserAuthorizeToDeleteTask()- Loaded");
            bIsDeleteRestricted = true;
            sDeleteRestrictedMessage = string.Empty;
            try
            {
                _tracingService.Trace("gLoggedInUserId: '{0}'", _gLoggedInUserId);
                string sUserName = _service.Retrieve("systemuser", _gLoggedInUserId, new ColumnSet("fullname"))["fullname"].ToString();
                string sCL0015Profiles = string.Empty;

                object[] RSACustomeLabel = { "CL0015" };
                EntityCollection ecRSACustomLabels = this.GetCustomLabel(RSACustomeLabel);
                if (ecRSACustomLabels != null && ecRSACustomLabels.Entities.Count > 0 && ecRSACustomLabels[0].Contains("rsa_values")
                    && !string.IsNullOrEmpty(ecRSACustomLabels[0]["rsa_values"].ToString()))
                {
                    sCL0015Profiles = ecRSACustomLabels[0]["rsa_values"].ToString();
                }

                if (!string.IsNullOrEmpty(sCL0015Profiles))
                {
                    _tracingService.Trace("sCL0015Profiles: '{0}'", sCL0015Profiles);
                    EntityCollection ecUserRoles = new EntityCollection();
                    this.GetUserRoles(out ecUserRoles);
                    if (ecUserRoles != null && ecUserRoles.Entities.Count > 0)
                    {
                        _tracingService.Trace("Roles Count: '{0}'", ecUserRoles.Entities.Count);
                        foreach (Entity role in ecUserRoles.Entities)
                        {
                            if (sCL0015Profiles.ToLower().Contains(((AliasedValue)role["role.name"]).Value.ToString().ToLower()))
                            {
                                _tracingService.Trace("1 matching role found. Setting bIsDeleteRestricted = false");
                                bIsDeleteRestricted = false;
                                break;
                            }
                        }
                        if (bIsDeleteRestricted)
                        {
                            sDeleteRestrictedMessage = string.Format("The user '{0}' does not have the requisite permission to delete this Activity record." + System.Environment.NewLine, sUserName);
                        }
                        else
                        {
                            sDeleteRestrictedMessage = string.Empty;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _tracingService.Trace("An error occurred in Task.IsUserAuthorizeToDeleteTask plugin. Details: '{0}'", ex.Message);
            }
            _tracingService.Trace("TaskManagementLogic=>IsUserAuthorizeToDeleteTask()- Unloaded");
        }
        #endregion Private methods
    }
    #endregion

    #region Enums
    /// <summary>
    /// Task_rsa_Status_Completed
    /// </summary>
    public enum Task_rsa_Status_Completed
    {
        Completed = 866760004,
        CompletedFollowUp = 866760005,
        CompletedHandedBack = 866760006,
        CompletedReferred = 100000000,
        CompletedAutomated = 866760012,
        CompletedNoActionRequired = 866760013,
        CompletedActionsRequired = 866760014,
    }
    #endregion Enums
}