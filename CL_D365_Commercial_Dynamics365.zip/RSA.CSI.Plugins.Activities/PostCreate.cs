﻿using Microsoft.Xrm.Sdk;
using RSA.CSI.Plugins.Activities.Common;
using RSA.CSI.Plugins.Activities.Logic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSA.CSI.Plugins.Activities
{
    public class PostCreate : PluginBase
    {
        public PostCreate()
            : base(typeof(PostCreate))
        {
            base.RegisteredEvents.Add(new Tuple<int, string, string, Action<LocalPluginContext>>(40, "Create", "task", Execute));
        }

        protected void Execute(LocalPluginContext localContext)
        {
            #region Generate context, service & tracing service objects.
            if (localContext == null)
            {
                //throw new ArgumentNullException("localContext is null.");
                //Remediation - 14/07/2022
                throw new InvalidPluginExecutionException("localContext is null.");
            }
            IPluginExecutionContext context = localContext.PluginExecutionContext;
            IOrganizationService service = localContext.OrganizationService;
            ITracingService tracingService = localContext.TracingService;
            #endregion
           
            Entity entity;
            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                entity = (Entity)context.InputParameters["Target"];
                try
                {
                    if (entity.LogicalName.ToLower() == "task" && entity.Attributes.Contains("regardingobjectid") &&
                        ((EntityReference)entity["regardingobjectid"]).LogicalName == "incident")
                    {
                        tracingService.Trace("TaskLogic=>PostCreate() logic- Loaded.");
                        int oTaskStatusPost = -1;

                        if (entity.Attributes.Contains("rsa_status"))
                            oTaskStatusPost = ((OptionSetValue)entity.Attributes["rsa_status"]).Value;
                        TaskManagementLogic logic = new TaskManagementLogic(service, tracingService, entity, null, null, context.InitiatingUserId);
                        bool bIsTaskPreCompleted = logic.IsTaskCompleted(oTaskStatusPost);
                        logic.PostCreate(bIsTaskPreCompleted,entity);

                        tracingService.Trace("TaskLogic=>PostCreate() logic- Unloaded.");
                    }
                }
                catch (Exception ex)
                {
                    tracingService.Trace("An error occurred in Task.PostCreate plugin. Details: '{0}'", ex.Message);
                }

            }
            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                entity = (Entity)context.InputParameters["Target"];
                if (entity.LogicalName.ToLower() == "task" && entity.Attributes.Contains("regardingobjectid") &&
                        ((EntityReference)entity["regardingobjectid"]).LogicalName == "opportunity")
                {
                    TaskManagementLogic logic = new TaskManagementLogic(service, tracingService, entity, null, null, context.InitiatingUserId);
                    logic.PostCreate(true,entity);
                }
            }
        }
    }
}
