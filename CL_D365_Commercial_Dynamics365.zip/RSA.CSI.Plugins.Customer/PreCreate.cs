﻿using Microsoft.Xrm.Sdk;
using RSA.CSI.Plugins.Customer.Logic;
using RSA.CSI.Plugins.Customer.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSA.CSI.Plugins.Customer
{
    public class PreCreate : PluginBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PreCreate"/> class.
        /// </summary>
        public PreCreate()
            : base(typeof(PreCreate))
        {
            RegisteredEvents.Add(new Tuple<int, string, string, Action<LocalPluginContext>>(20, "Create", "rsa_customer", ExecuteCustomerPreCreate));
        }

        /// <summary>
        /// Start Validating the record when the regsiterd event occurs
        /// </summary>
        /// <param name="localContext"></param>
        protected void ExecuteCustomerPreCreate(LocalPluginContext localContext)
        {
            #region Generic block of Context null checking and service creation block

            if (localContext == null)
            {
                //throw new ArgumentNullException("localContext");
                //Remediation - 19/07/2022
                throw new InvalidPluginExecutionException("localContext");
            }
            IPluginExecutionContext context = localContext.PluginExecutionContext;
            IOrganizationService service = localContext.OrganizationService;
            ITracingService tracingService = localContext.TracingService;
            #endregion Generic block of Context null checking and service creation block  

            #region Get Input Parameters

            if (context.InputParameters["Target"] != null && (Entity)context.InputParameters["Target"] != null)
            {
                try
                {
                    #region PostImage
                    //rsa_opportunity
                    //rsa_newpolicynumber
                    //rsa_name
                    //rsa_premium
                    //rsa_policysystemcode
                    #endregion

                    //Target Entity
                    var entityCustomerTarget = context.InputParameters["Target"] as Entity;
                    tracingService.Trace("Calling Execute Method()");
                   // var entityCustomerPreImage = context.PreEntityImages["PreImage"] as Entity;
                    if (context.Depth > 1)
                    {
                        tracingService.Trace("Plugin depth is greater than 1, hence RETURN: " + context.Depth);
                        return;
                    }
                  //  tracingService.Trace("Pre Image attribute(s) count: " + entityCustomerPreImage.Attributes.Count);
                    PreCreateLogic customerPreUpdate = new PreCreateLogic(service, tracingService, entityCustomerTarget, context.InitiatingUserId);
                    customerPreUpdate.Execute();
                }
                catch (Exception ex)
                {
                    tracingService.Trace("Exception: " + ex.Message);
                    throw new InvalidPluginExecutionException("ExecuteCustomerPreCreatePlugin: " + ex.Message);
                }
            }
            else
            {
                tracingService.Trace("Target is null in PreCreate");
                throw new InvalidPluginExecutionException("Target is null in PreCreate");
            }

            #endregion  Get Input Parameters
        }       

    }
}
