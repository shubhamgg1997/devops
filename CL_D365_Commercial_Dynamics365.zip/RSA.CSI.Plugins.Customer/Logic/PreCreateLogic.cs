﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSA.CSI.Plugins.Customer.Logic
{
    internal class PreCreateLogic
    {
        IOrganizationService service = null;
        ITracingService tracingService = null;
        Entity enCustomerTarget = null;
        Guid guidCallingUserId = Guid.Empty;
        Entity enCustomerPreImage = null;

        #region Constructor 
        internal PreCreateLogic(IOrganizationService cService, ITracingService cTracingService, Entity cEnCustomerTarget, Guid cGuidCallingUserId)
        {
            service = cService;
            tracingService = cTracingService;
            enCustomerTarget = cEnCustomerTarget;
            //enCustomerPreImage = cEntityCustomerPreImage;
            guidCallingUserId = cGuidCallingUserId;
        }
        #endregion Constructor

        internal void Execute()
        {
            bool flag = false;
            OptionSetValueCollection dataOriginNew = new OptionSetValueCollection();
            // OptionSetValueCollection dataOriginOld = new OptionSetValueCollection();
            if (enCustomerTarget.Attributes.Contains("rsa_dataorigin"))
            {
                dataOriginNew = (OptionSetValueCollection)enCustomerTarget.Attributes["rsa_dataorigin"];
                tracingService.Trace("Data origin " + dataOriginNew);
            }
            //if (enCustomerPreImage.Attributes.Contains("rsa_dataorigin"))
            //{
            //    dataOriginOld = (OptionSetValueCollection)enCustomerPreImage.Attributes["rsa_dataorigin"];
            //}
            if (dataOriginNew != null && dataOriginNew.Count > 0)
            {
                foreach (var options in dataOriginNew)
                {
                    if (options.Value == 866760000)
                    {
                        flag = true;
                        break;
                    }

                }
            }
            //if (dataOriginOld != null && dataOriginNew.Count > 0 && flag == false)
            //{
            //    enCustomerTarget["rsa_dataorigin"] = enCustomerPreImage["rsa_dataorigin"];
            //}
            tracingService.Trace("Start user role check ");
            string[] securityRoles = { "Data Migration", "CSI Integration", "System Administrator", "System Admin Hard Delete" };
            bool userHasRoles = UserHasRole(guidCallingUserId, securityRoles);
            if (!userHasRoles)
            {
                enCustomerTarget["rsa_enduserupdate"] = true;
            }
            tracingService.Trace("Start user role check completed ");
            if (enCustomerTarget.Attributes.Contains("rsa_rsaexternalid"))
            {
                string extid = Convert.ToString(enCustomerTarget.Attributes["rsa_rsaexternalid"]);
                tracingService.Trace("External Id from package " + extid);
            }
                var customerName = string.Empty;
            //2688 :Sumegh Dhole : object reference error while policy upload
            if (enCustomerTarget.Attributes.Contains("rsa_name"))
            {
                //2688 :Sumegh Dhole : object reference error while policy upload
                customerName = Convert.ToString(enCustomerTarget.Attributes["rsa_name"]);
                // customerName = enCustomerTarget.Attributes["rsa_name"]).ToString();
            }
            else if (enCustomerPreImage.Attributes.Contains("rsa_name"))
            {
                //2688 :Sumegh Dhole : object reference error while policy upload
                customerName = Convert.ToString(enCustomerPreImage.Attributes["rsa_name"]);
                //customerName = enCustomerPreImage.Attributes["rsa_name"].ToString();
            }

            tracingService.Trace("Customer Name  " + customerName);
            string strCustomerKeyword = string.Empty;
            string customerNameBigrams = string.Empty;
            string strCustomerNameStripped = RSA.CSI.Plugins.Case.Helper.StringUtilities.TrimString(customerName);
            tracingService.Trace("Customer Name Stripped " + strCustomerNameStripped);
            enCustomerTarget["rsa_companynamestripped"] = strCustomerNameStripped;
            if (!String.IsNullOrEmpty(strCustomerNameStripped))
            {
                strCustomerKeyword = RSA.CSI.Plugins.Case.Helper.StringUtilities.GetKeyWords(strCustomerNameStripped);
                tracingService.Trace("strCustomerKeyword: " + strCustomerKeyword);
                enCustomerTarget["rsa_rsacustomerkeyword"] = strCustomerKeyword;
                customerNameBigrams = RSA.CSI.Plugins.Case.Helper.DiceCoefficient.GetBigramString(strCustomerNameStripped);
                tracingService.Trace("customerNameBigrams: " + customerNameBigrams);
                enCustomerTarget["rsa_rsacustomernamebigrams"] = customerNameBigrams;
                if (enCustomerTarget.Attributes.Contains("rsa_keywordprefix3"))
                    enCustomerTarget["rsa_rsakeywordprefix3value"] = enCustomerTarget["rsa_keywordprefix3"];
                //else if(enCustomerPreImage.Attributes.Contains("rsa_keywordprefix3"))
                //    enCustomerTarget["rsa_rsakeywordprefix3value"] = enCustomerPreImage["rsa_keywordprefix3"];
                tracingService.Trace("Customer Name strCustomerKeyword " + strCustomerKeyword);
            }

            string strClientPostCode = string.Empty;
            if (enCustomerTarget.Attributes.Contains("rsa_rsapostalcode"))
            {
                //2688 :Sumegh Dhole : object reference error while policy upload
                strClientPostCode = Convert.ToString(enCustomerTarget.Attributes["rsa_rsapostalcode"]);
                // strClientPostCode = enCustomerTarget.Attributes["rsa_rsapostalcode"].ToString();
            }
            //else if (enCustomerPreImage.Attributes.Contains("rsa_rsapostalcode"))
            //    strClientPostCode = enCustomerPreImage.Attributes["rsa_rsapostalcode"].ToString();
            string externalID = customerName + ":" + strClientPostCode;
            tracingService.Trace("externalID : " + externalID);

            enCustomerTarget["rsa_rsaexternalid"] = externalID;

            EntityCollection enColCustomer = this.getColCustomerDetails(externalID);

            if (enColCustomer != null && enColCustomer.Entities.Count > 0)
            {
                tracingService.Trace("Stage is Accepted so throwing Error");
                string postalCode = enColCustomer.Entities[0].Attributes.Contains("rsa_rsapostalcode") ? enColCustomer.Entities[0].GetAttributeValue<string>("rsa_rsapostalcode") : string.Empty;
                throw new Exception("Duplicate Customer exists for the same Postal Code: ID " + postalCode + " created by " + ((EntityReference)enColCustomer.Entities[0].Attributes["createdby"]).Name.ToString() + " " + enColCustomer.Entities[0].Attributes["createdon"].ToString());
            }


        }

        private EntityCollection getColCustomerDetails(string externalID)
        {
            var enColCustomer = new EntityCollection(null);
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='rsa_customer'>
                                <attribute name='rsa_name' />
                                <attribute name='rsa_customerid' />
                                <attribute name='rsa_rsapostalcode' />
                                <attribute name='rsa_rsaexternalid' />
                                <attribute name='createdon' />
                                <attribute name='createdby' />
                                <order attribute='rsa_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='rsa_rsaexternalid' operator='eq' value='{0}'/>
                                </filter>
                              </entity>
                            </fetch>";
            try
            {
                enColCustomer = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, externalID.ToLower())));
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception in getColCustomerDetails: " + ex.Message);
            }
            return enColCustomer;
        }

        private bool UserHasRole(Guid userID, string[] roleNames)
        {
            bool hasRole = false;
            foreach (var rolename in roleNames)
            {
                QueryExpression qe = new QueryExpression("systemuserroles");
                qe.Criteria.AddCondition("systemuserid", ConditionOperator.Equal, userID);
                qe.NoLock = true;
                LinkEntity link = qe.AddLink("role", "roleid", "roleid", JoinOperator.Inner);
                link.LinkCriteria.AddCondition("name", ConditionOperator.Equal, rolename);
                EntityCollection results = service.RetrieveMultiple(qe);
                hasRole = results.Entities.Count > 0;
                if (hasRole)
                    break;
            }
            return hasRole;
        }

    }
}
