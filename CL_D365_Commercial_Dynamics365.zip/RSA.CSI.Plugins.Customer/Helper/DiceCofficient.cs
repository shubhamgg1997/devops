﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSA.CSI.Plugins.Case.Helper
{
    public static class DiceCoefficient
    {
        public static double DiceCoefficientAlgo(string stOne, string stTwo)
        {
            HashSet<string> nx = BuildBigramSet(stOne);
            HashSet<string> ny = BuildBigramSet(stTwo);

            HashSet<string> intersection = new HashSet<string>(nx);
            intersection.IntersectWith(ny);

            double dbOne = intersection.Count;
            return (2 * dbOne) / (nx.Count + ny.Count);

        }

        public static HashSet<string> BuildBigramSet(string input)
        {
            HashSet<string> bigrams = new HashSet<string>();

            for (int i = 0; i < input.Length - 1; i++)
            {
                bigrams.Add(input.Substring(i, 2));
            }
            return bigrams;
        }

        public static String GetBigramString(String name)
        {
            List<string> bigramList = new List<string>();
            if (!String.IsNullOrEmpty(name))
            {
                // Calls the splitIntoBigrams() method of DiceCoefficient class to get the bi grams of a name 
                //which is an input parameter to the method. 
                bigramList.Add(DiceCoefficient.SplitIntoBigrams(name));
            }
            return StringUtilities.ListToString(bigramList.ToArray(), ";");
        }

        public static String SplitIntoBigrams(String s)
        {
            List<String> bigrams = new List<String>();
            if (s.Length < 2)
            {
                bigrams.Add(s);
            }
            else
            {
                for (int i = 0; i < s.Length - 1; i++)
                {
                    bigrams.Add(s.Substring(i, 2));
                }
            }
            return String.Join(";", bigrams.ToArray()).ToLower();
        }    
      
    }
}