﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace WorkbenchCaseStatusUpdate
{
    public class Casestatus : IPlugin

    {

        public void Execute(IServiceProvider serviceProvider)

        {



            // Obtain the tracing service

            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));



            // Obtain the execution context from the service provider. 

            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));

            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            string CaseId = ""; string caseStatus = ""; string casetype = "";

            Guid userId = Guid.Empty;

            try

            {

                // Plug-in business logic goes here. 


                casetype = context.InputParameters["CaseType"].ToString();
                CaseId = context.InputParameters["CaseId"].ToString();

                caseStatus = context.InputParameters["CaseStatus"].ToString();

                Entity Caserec = service.Retrieve("incident", new Guid(CaseId), new ColumnSet("rsa_opportunityid"));

                tracingService.Trace("CaseId" + CaseId);

                tracingService.Trace("caseStatus" + caseStatus + "caseStatus.ToLower " + caseStatus.ToLower());

                if (Caserec.Attributes.Contains("rsa_opportunityid"))

                {

                    Guid OppId = Caserec.GetAttributeValue<EntityReference>("rsa_opportunityid").Id;

                    if (caseStatus.ToLower() == "diverted")

                    {

                        string underWriter = string.Empty;

                        string outcomereasoncode = context.InputParameters["Outcomereasoncode"].ToString();

                        string outcomeCommentary = context.InputParameters["OutcomeCommentary"].ToString();

                        string OutcomeDatetime = context.InputParameters["OutcomeDatetime"].ToString();

                        if (context.InputParameters["Underwriter"] != null)

                            underWriter = context.InputParameters["Underwriter"].ToString();

                        tracingService.Trace("outcomereasoncode" + outcomereasoncode);      //opp

                        tracingService.Trace("outcomeCommentary" + outcomeCommentary);      //opp

                        tracingService.Trace("OutcomeDatetime" + OutcomeDatetime);

                        tracingService.Trace("underWriter" + underWriter);

                        //tracingService.Trace("CaseId" + CaseId);

                        if (underWriter != null)

                        {

                            userId = getSystemUser(underWriter, service, tracingService);

                        }



                        tracingService.Trace("Opportunity Record Id=" + OppId);

                        Entity Opportunityrec = new Entity("opportunity");

                        Opportunityrec.Id = OppId;
                        if (userId != Guid.Empty)
                            updateOpportunityowner(service, tracingService, userId, OppId);
                        Opportunityrec["rsa_opportunitydescription"] = outcomeCommentary;

                        Entity Outcomereason = getOutcome(outcomereasoncode, service, tracingService);

                        if (Outcomereason.Id != null)

                        {

                            Opportunityrec["rsa_outcomereasonid"] = new EntityReference("rsa_outcomereason", Outcomereason.Id);

                        }



                        Entity statusreason = GetStatusReason(outcomereasoncode, service, tracingService);





                        Opportunityrec["rsa_outcomedate"] = Convert.ToDateTime(OutcomeDatetime);

                        service.Update(Opportunityrec);

                        tracingService.Trace("Opportunity Record is updated");

                        // }





                        Entity Case = new Entity("incident");

                        Case.Id = new Guid(CaseId);

                        if (statusreason.Id != null)

                        {

                            Case["rsa_statusreason"] = new EntityReference(statusreason.LogicalName, new Guid("a5202ed1-faaf-f011-bbd3-000d3a86b82a"));

                        }

                        Case["rsa_status"] = new EntityReference("rsa_status", new Guid("1796b842-f7e2-ea11-a816-000d3a64927d"));



                        // = new EntityReference("systemuser", userId);

                        //Case["rsa_quotedeadline"] = Convert.ToDateTime(OutcomeDatetime);

                        service.Update(Case);

                        tracingService.Trace("userId != Guid.Empty)" + userId + "CaseID=" + CaseId);

                        if (userId != Guid.Empty)

                            updatecaseowner(service, tracingService, userId, new Guid(CaseId));

                        tracingService.Trace("Case Record is updated");

                        updatecasestatusclose(service, tracingService, new Guid(CaseId));

                    }



                    // TO Be Quoted

                    else if (caseStatus.ToLower() == "to be quoted")

                    {

                        string underWriter = string.Empty;

                        string BrokerTargetPremium = context.InputParameters["BrokerTargetPremium"].ToString();

                        string Quotedeadlinedate = context.InputParameters["Quotedeadlinedate"].ToString();

                        tracingService.Trace("BrokerTargetPremium" + BrokerTargetPremium);      //opp

                        tracingService.Trace("Quotedeadlinedate" + Quotedeadlinedate);      //opp

                        if (context.InputParameters["Underwriter"] != null)

                            underWriter = context.InputParameters["Underwriter"].ToString();

                        if (underWriter != null)

                        {

                            userId = getSystemUser(underWriter, service, tracingService);

                        }

                        Entity Opp = new Entity("opportunity");

                        Opp.Id = OppId;

                        Opp["rsa_targetpremium"] = Convert.ToDecimal(BrokerTargetPremium);
                        if (userId != Guid.Empty)
                            updateOpportunityowner(service, tracingService, userId, OppId);
                        service.Update(Opp);

                        tracingService.Trace("Opportunity Record is updated");

                        Entity Case = new Entity("incident");

                        Case.Id = new Guid(CaseId);

                        Case["rsa_quotedeadline"] = Convert.ToDateTime(Quotedeadlinedate);

                        Case["rsa_status"] = new EntityReference("rsa_status", new Guid("8d98b842-f7e2-ea11-a816-000d3a64927d"));



                        //Case["rsa_quotedeadline"] = Convert.ToDateTime(OutcomeDatetime);

                        service.Update(Case);

                        if (userId != Guid.Empty)

                            updatecaseowner(service, tracingService, userId, new Guid(CaseId));

                        tracingService.Trace("Case status to be quoted is updated");



                    }



                    //Accepted

                    else if (caseStatus.ToLower() == "accepted")

                    {

                        string underWriter = string.Empty;

                        string BrokerTargetPremium = context.InputParameters["BrokerTargetPremium"].ToString();

                        string Quotedeadlinedate = context.InputParameters["Quotedeadlinedate"].ToString();

                        tracingService.Trace("BrokerTargetPremium" + BrokerTargetPremium);      //opp

                        tracingService.Trace("Quotedeadlinedate" + Quotedeadlinedate);      //opp

                        if (context.InputParameters["Underwriter"] != null)

                            underWriter = context.InputParameters["Underwriter"].ToString();
                        string PolicyNumber = string.Empty;
                        if (context.InputParameters["PolicyNumber"] != null)

                            PolicyNumber = context.InputParameters["PolicyNumber"].ToString();
                        string LongTermAgreement = string.Empty;
                        if (context.InputParameters["LongTermAgreement"] != null)

                            LongTermAgreement = context.InputParameters["LongTermAgreement"].ToString();
                        string BaseCommission = string.Empty;
                        if (context.InputParameters["BaseCommission"] != null)

                            BaseCommission = context.InputParameters["BaseCommission"].ToString();
                        string ISB = string.Empty;
                        if (context.InputParameters["ISB"] != null)

                            ISB = context.InputParameters["ISB"].ToString();
                        
                        string WorkTransfer = string.Empty;
                        if (context.InputParameters["WorkTransfer"] != null)

                            WorkTransfer = context.InputParameters["WorkTransfer"].ToString();

                        string ProfitShare = string.Empty;
                        if (context.InputParameters["ProfitShare"] != null)

                            ProfitShare = context.InputParameters["ProfitShare"].ToString();

                        string TotalRemuneration = string.Empty;
                        if (context.InputParameters["TotalRemuneration"] != null)

                            TotalRemuneration = context.InputParameters["TotalRemuneration"].ToString();

                        string RSALineSize = string.Empty;
                        if (context.InputParameters["RSALineSize"] != null)

                            RSALineSize = context.InputParameters["RSALineSize"].ToString();

                        if (underWriter != null)

                        {

                            userId = getSystemUser(underWriter, service, tracingService);

                        }

                        Guid ExistingInsuereMainId = Guid.Empty;

                        string ActualPremium = string.Empty;

                        if (context.InputParameters["ActualPremium"] != null)

                            ActualPremium = context.InputParameters["ActualPremium"].ToString();



                        string TechnicalPremium = string.Empty;

                        if (context.InputParameters["TechnicalPremium"] != null)

                            TechnicalPremium = context.InputParameters["TechnicalPremium"].ToString();



                        string ExistingInsurer = string.Empty;

                        if (context.InputParameters["ExistingInsurer"] != null)

                        {

                            ExistingInsurer = context.InputParameters["ExistingInsurer"].ToString();

                            ExistingInsuereMainId = getExistinginsurer(ExistingInsurer, service, tracingService);

                        }

                        string HoldingAgent = string.Empty;

                        if (context.InputParameters["HoldingAgent"] != null)

                            HoldingAgent = context.InputParameters["HoldingAgent"].ToString();



                        string ExpiryPremium = string.Empty;

                        if (context.InputParameters["ExpiryPremium"] != null)

                            ExpiryPremium = context.InputParameters["ExpiryPremium"].ToString();



                        string CrisisManagementCover = string.Empty;

                        if (context.InputParameters["CrisisManagementCover"] != null)

                            CrisisManagementCover = context.InputParameters["CrisisManagementCover"].ToString();



                        string CrisisManagementCoverAmount = string.Empty;

                        if (context.InputParameters["CrisisManagementCoverAmount"] != null)

                            CrisisManagementCoverAmount = context.InputParameters["CrisisManagementCoverAmount"].ToString();



                        string DateTermsRequiredbyBrokerCustomer = string.Empty;

                        if (context.InputParameters["DateTermsRequiredbyBrokerCustomer"] != null)

                            DateTermsRequiredbyBrokerCustomer = context.InputParameters["DateTermsRequiredbyBrokerCustomer"].ToString();



                        string DateTermsIssuedtoBrokerCustomer = string.Empty;

                        if (context.InputParameters["DateTermsIssuedtoBrokerCustomer"] != null)

                            DateTermsIssuedtoBrokerCustomer = context.InputParameters["DateTermsIssuedtoBrokerCustomer"].ToString();



                        string DateTermsAgreedwithBrokerCustomer = string.Empty;

                        if (context.InputParameters["DateTermsAgreedwithBrokerCustomer"] != null)

                            DateTermsAgreedwithBrokerCustomer = context.InputParameters["DateTermsAgreedwithBrokerCustomer"].ToString();



                        string LeadFollow = string.Empty;

                        if (context.InputParameters["LeadFollow"] != null)

                            LeadFollow = context.InputParameters["LeadFollow"].ToString();



                        string PostFulfilmentActivities = string.Empty;

                        if (context.InputParameters["PostFulfilmentActivities"] != null)

                            PostFulfilmentActivities = context.InputParameters["PostFulfilmentActivities"].ToString();



                        Guid OppExtension = getOpportunityExtension(OppId.ToString(), service, tracingService);



                        Entity Opportunityrec = new Entity("opportunity");

                        Opportunityrec.Id = OppId;
                        if (userId != Guid.Empty)
                            updateOpportunityowner(service, tracingService, userId, OppId);

                        //Broker Target Premium

                        Opportunityrec["rsa_targetpremium"] = Convert.ToDecimal(BrokerTargetPremium);

                        //RSA Quotede Premium

                        Opportunityrec["rsa_rsaquotedpremium"] = new Money(Convert.ToDecimal(ActualPremium));



                        //Gross RSA 100% Technical Price

                        Opportunityrec["rsa_opptytechnicalprice_dc"] = Convert.ToDecimal(TechnicalPremium);

                        //Long term Agreement
                        if (LongTermAgreement != null)
                        {
                            Opportunityrec["rsa_longtermagreements"] = new OptionSetValue(Convert.ToInt32(LongTermAgreement));
                        }

                        //Policy Number
                        if (PolicyNumber != null)
                        {
                            Opportunityrec["rsa_policynumber"] = PolicyNumber;                           
                        }

                        //BaseCommission
                        if (BaseCommission != null)
                        {
                            Opportunityrec["rsa_ci_basecommission"] = Convert.ToDecimal(BaseCommission);
                        }

                        //ISB
                        if (ISB != null)
                        {
                            Opportunityrec["rsa_cl_isb"] = Convert.ToDecimal(ISB);
                        }


                        //Work Transfer
                        if (WorkTransfer != null)
                        {
                            Opportunityrec["rsa_worktransferpercentage"] = Convert.ToDecimal(WorkTransfer);
                        }

                        //Profit Share
                        if (ProfitShare != null)
                        {
                            Opportunityrec["rsa_profitsharepercentage"] = Convert.ToDecimal(ProfitShare);
                        }

                        //Total Remuneration
                        if (TotalRemuneration != null)
                        {
                            Opportunityrec["rsa_totalremunerationpercentage_ci"] = Convert.ToDecimal(TotalRemuneration);
                        }


                        //RSA Line Size
                        if (RSALineSize != null)
                        {
                            Opportunityrec["rsa_rsalinesize"] = Convert.ToDecimal(RSALineSize);
                            Opportunityrec["rsa_rsalinesize_dc"] = Convert.ToDecimal(RSALineSize);
                        }

                        //if

                        //Crisismanagement cover

                        Opportunityrec["rsa_crisismanagementcover"] = new OptionSetValue(Convert.ToInt32(CrisisManagementCover));

                        //Crisismanagement cover amount

                        Opportunityrec["rsa_crisismanagementcoveramount_dc"] = Convert.ToDecimal(CrisisManagementCoverAmount);



                        if (ExistingInsuereMainId != Guid.Empty)

                        {

                            //Existing Insuerer

                            Opportunityrec["rsa_existinginsurerid"] = new EntityReference("rsa_existinginsurer", ExistingInsuereMainId);//Convert.ToDecimal(BrokerTargetPremium);

                        }

                        //Holding Agent

                        Opportunityrec["rsa_holdingagent"] = new OptionSetValue(Convert.ToInt32(HoldingAgent));// new OptionSetValue(Convert.ToInt32(HoldingAgent));

                        //Exipary premium

                      Guid  Opportunitystageid= getstageId(null, service, tracingService);
                        Opportunityrec["rsa_opportunitystage"] = new EntityReference("rsa_opportunitystage", Opportunitystageid);




                        Opportunityrec["rsa_rsaexpirypremium"] = Convert.ToDecimal(ExpiryPremium);





                        service.Update(Opportunityrec);

                        tracingService.Trace("Opportunity Record is updated");

                        //

                        //

                        if (OppExtension != Guid.Empty)

                        {

                            Entity OpportunityExtenrec = new Entity("rsa_extensionopportunity");

                            OpportunityExtenrec.Id = OppExtension;

                            //Broker Target Premium

                            OpportunityExtenrec["rsa_leadfollow"] = new OptionSetValue(Convert.ToInt32(LeadFollow));

                            OpportunityExtenrec["rsa_datetermsrequiredbybrokercustomer"] = Convert.ToDateTime(DateTermsRequiredbyBrokerCustomer);

                            OpportunityExtenrec["rsa_datetermsissuedtobrokercustomer"] = Convert.ToDateTime(DateTermsIssuedtoBrokerCustomer);

                            OpportunityExtenrec["rsa_datetermsagreedwithcustomerbroker"] = Convert.ToDateTime(DateTermsAgreedwithBrokerCustomer);



                            service.Update(OpportunityExtenrec);

                        }

                        tracingService.Trace("Opportunity Extesnion Record is updated");

                        Entity Case = new Entity("incident");

                        Case.Id = new Guid(CaseId);

                        Case["rsa_quotedeadline"] = Convert.ToDateTime(Quotedeadlinedate);

                        if (PostFulfilmentActivities != string.Empty)

                        {



                            OptionSetValueCollection activities = new OptionSetValueCollection();

                            string originalString = PostFulfilmentActivities;



                            // Split the string using a comma as the delimiter

                            string[] substrings = originalString.Split(',');



                            // Display the substrings

                            foreach (var substring in substrings)

                            {

                                activities.Add(new OptionSetValue(Convert.ToInt32(substring)));

                                //Console.WriteLine(substring);

                                tracingService.Trace("Case status" + substring);

                            }







                            Case["rsa_rsapolicyfulfilmentactivities"] = activities;

                        }

                        Case["rsa_status"] = new EntityReference("rsa_status", new Guid("3d98b842-f7e2-ea11-a816-000d3a64927d"));



                        //Case["rsa_quotedeadline"] = Convert.ToDateTime(OutcomeDatetime);

                        service.Update(Case);

                        if (userId != Guid.Empty)

                            updatecaseowner(service, tracingService, userId, new Guid(CaseId));

                        tracingService.Trace("Case status to be Accepted is updated");

                        if(PolicyNumber!= string.Empty && PolicyNumber != "")
                        {
                            updatecasestatusclose(service, tracingService, new Guid(CaseId));
                        }

                    }



                    //Quoted

                    else if (caseStatus.ToLower() == "quoted")

                    {

                        string underWriter = string.Empty;

                        string BrokerTargetPremium = context.InputParameters["BrokerTargetPremium"].ToString();

                        string Quotedeadlinedate = context.InputParameters["Quotedeadlinedate"].ToString();

                        tracingService.Trace("BrokerTargetPremium" + BrokerTargetPremium);      //opp

                        tracingService.Trace("Quotedeadlinedate" + Quotedeadlinedate);      //opp

                        if (context.InputParameters["Underwriter"] != null)

                            underWriter = context.InputParameters["Underwriter"].ToString();

                        if (underWriter != null)

                        {

                            userId = getSystemUser(underWriter, service, tracingService);

                        }

                        string ActualPremium = string.Empty;

                        Guid ExistingInsuereMainId = Guid.Empty;

                        if (context.InputParameters["ActualPremium"] != null)

                            ActualPremium = context.InputParameters["ActualPremium"].ToString();



                        string TechnicalPremium = string.Empty;

                        if (context.InputParameters["TechnicalPremium"] != null)

                            TechnicalPremium = context.InputParameters["TechnicalPremium"].ToString();



                        string ExistingInsurer = string.Empty;

                        if (context.InputParameters["ExistingInsurer"] != null)

                        {

                            ExistingInsurer = context.InputParameters["ExistingInsurer"].ToString();

                            ExistingInsuereMainId = getExistinginsurer(ExistingInsurer, service, tracingService);

                        }

                        string HoldingAgent = string.Empty;

                        if (context.InputParameters["HoldingAgent"] != null)

                            HoldingAgent = context.InputParameters["HoldingAgent"].ToString();



                        string ExpiryPremium = string.Empty;

                        if (context.InputParameters["ExpiryPremium"] != null)

                            ExpiryPremium = context.InputParameters["ExpiryPremium"].ToString();



                        Entity Opportunityrec = new Entity("opportunity");

                        Opportunityrec.Id = OppId;
                        if(userId!=Guid.Empty)
                            updateOpportunityowner(service,tracingService,userId,OppId);
                        //Broker Target Premium

                        Opportunityrec["rsa_targetpremium"] = Convert.ToDecimal(BrokerTargetPremium);

                        //RSA Quotede Premium

                        Opportunityrec["rsa_rsaquotedpremium"] = new Money(Convert.ToDecimal(ActualPremium));



                        //Gross RSA 100% Technical Price

                        Opportunityrec["rsa_opptytechnicalprice_dc"] = Convert.ToDecimal(TechnicalPremium);



                        //Existing Insuerer

                        if (ExistingInsuereMainId != Guid.Empty)

                        {

                            //Existing Insuerer

                            Opportunityrec["rsa_existinginsurerid"] = new EntityReference("rsa_existinginsurer", ExistingInsuereMainId);//Convert.ToDecimal(BrokerTargetPremium);

                        }

                        //Holding Agent

                        Opportunityrec["rsa_holdingagent"] = new OptionSetValue(Convert.ToInt32(HoldingAgent));

                        //Exipary premium

                        Opportunityrec["rsa_rsaexpirypremium"] = Convert.ToDecimal(ExpiryPremium);





                        service.Update(Opportunityrec);

                        tracingService.Trace("Opportunity Record is updated");





                        Entity Case = new Entity("incident");

                        Case.Id = new Guid(CaseId);

                        Case["rsa_quotedeadline"] = Convert.ToDateTime(Quotedeadlinedate);

                        Case["rsa_status"] = new EntityReference("rsa_status", new Guid("1b98b842-f7e2-ea11-a816-000d3a64927d"));



                        //Case["rsa_quotedeadline"] = Convert.ToDateTime(OutcomeDatetime);

                        service.Update(Case);

                        if (userId != Guid.Empty)

                            updatecaseowner(service, tracingService, userId, new Guid(CaseId));

                        tracingService.Trace("Case status to be quoted is updated");

                    }



                    //Not Taken up

                    else if (caseStatus.ToLower() == "not taken up")

                    {

                        string outcomereasoncode = context.InputParameters["Outcomereasoncode"].ToString();

                        tracingService.Trace("outcomereasoncode" + outcomereasoncode);

                        Entity Opportunityrec = new Entity("opportunity");

                        Opportunityrec.Id = OppId;



                        Entity Outcomereason = getOutcome(outcomereasoncode, service, tracingService);

                        if (Outcomereason.Id != null)

                        {

                            Opportunityrec["rsa_outcomereasonid"] = new EntityReference("rsa_outcomereason", Outcomereason.Id);

                        }
                        Opportunityrec["rsa_opportunitystage"] = new EntityReference("rsa_opportunitystage",new Guid("9268b0a2-30e2-ea11-a816-000d3a64927d"));
                        

                        service.Update(Opportunityrec);

                        tracingService.Trace("Opportunity Record is updated");





                        Entity Case = new Entity("incident");

                        Case.Id = new Guid(CaseId);

                        Case["rsa_status"] = new EntityReference("rsa_status", new Guid("2f95b842-f7e2-ea11-a816-000d3a64927d"));
                        Case["rsa_statusreason"] = new EntityReference("rsa_statusreason", new Guid("9cbe3693-f167-f011-bec2-002248c7787e"));
                        service.Update(Case);

                        tracingService.Trace("userId != Guid.Empty)" + userId + "CaseID=" + CaseId);
                        updatecasestatusclose(service, tracingService, new Guid(CaseId));

                    }

                    //Quoted
                    else if (caseStatus.ToLower() == "quoted" && casetype == "Renewal")

                    {

                        string underWriter = string.Empty;
                        string EmailId = context.InputParameters["EmailId"].ToString();
                        string Quotedeadlinedate = context.InputParameters["Quotedeadlinedate"].ToString();
                        string RenewalPropensity = (int)context.InputParameters["RenewalPropensity"];
                        string Quotenumber = context.InputParameters["Quotenumber"].ToString();
                        string Terrorismpremium = context.InputParameters["Terrorismpremium"].ToString();
                        string Tyelyr = context.InputParameters["Tyelyr"];
                        string Originalppm = (int)context.InputParameters["Originalppm"];
                        
                        tracingService.Trace("Quotedeadlinedate" + Quotedeadlinedate);      //opp

                        if (context.InputParameters["Underwriter"] != null) 

                            underWriter = context.InputParameters["Underwriter"].ToString();

                        if (underWriter != null)

                        {

                            userId = getSystemUser(underWriter, service, tracingService);

                        }
                        if (string.IsNullOrWhiteSpace(EmailId))
                        EmailId = "SrvAcc.PowerUp.unassigned_nonprod@rsagroup.onmicrosoft.com";

                        Guid ownerId = getSystemUser(EmailId, service, tracingService);


                        string ActualPremium = string.Empty;

                        Guid ExistingInsuereMainId = Guid.Empty;

                        if (context.InputParameters["ActualPremium"] != null)

                            ActualPremium = context.InputParameters["ActualPremium"].ToString();



                        string TechnicalPremium = string.Empty;

                        if (context.InputParameters["TechnicalPremium"] != null)

                            TechnicalPremium = context.InputParameters["TechnicalPremium"].ToString();



                        string ExistingInsurer = string.Empty;

                        if (context.InputParameters["ExistingInsurer"] != null)

                        {

                            ExistingInsurer = context.InputParameters["ExistingInsurer"].ToString();

                            ExistingInsuereMainId = getExistinginsurer(ExistingInsurer, service, tracingService);

                        }


                        Entity Opportunityrec = new Entity("opportunity");

                        Opportunityrec.Id = OppId;
                        if(userId!=Guid.Empty)
                            updateOpportunityowner(service,tracingService,userId,OppId);

                        
                        if (RenewalPropensity!= null) Opportunityrec["rsa_brokercommitment"] = new OptionSetValue(RenewalPropensity); 
                        //RSA Quotede Premium
                        Opportunityrec["rsa_rsaquotedpremium"] = new Money(Convert.ToDecimal(ActualPremium));
                        Opportunityrec["rsa_terrorismpremium"] = Convert.ToDecimal(Terrorismpremium);
                        if (Tyelyr != null) Opportunityrec["rsa_tyelyrgbp"] = Convert.ToDecimal(Tyelyr);


                        //Gross RSA 100% Technical Price

                        Opportunityrec["rsa_opptytechnicalprice_dc"] = Convert.ToDecimal(TechnicalPremium);
                        Opportunityrec["rsa_quotenumber"] = Quotenumber;
                        if (Originalppm!= null) Opportunityrec["rsa_originalppm"] = new OptionSetValue(Originalppm); 


                        //Existing Insuerer
                        if (ExistingInsuereMainId != Guid.Empty)

                        {

                            //Existing Insuerer

                            Opportunityrec["rsa_existinginsurerid"] = new EntityReference("rsa_existinginsurer", ExistingInsuereMainId);

                        }
                        
                        service.Update(Opportunityrec);

                        tracingService.Trace("Opportunity Record is updated");

                        Entity Case = new Entity("incident");

                        Case.Id = new Guid(CaseId);

                        Case["rsa_quotedeadline"] = Convert.ToDateTime(Quotedeadlinedate);

                        Case["rsa_status"] = new EntityReference("rsa_status", new Guid("2198b842-f7e2-ea11-a816-000d3a64927d")); 

                        service.Update(Case);

                        if (userId != Guid.Empty)

                            updatecaseowner(service, tracingService, userId, new Guid(CaseId));

                        tracingService.Trace("Case status to be quoted is updated");

                    }
                    //Renewal Terms not Required
                    
                    if (caseStatus.ToLower() == "renewal terms not required" && casetype=="Renewal")
                    {
                        string underWriter = string.Empty;
                        string EmailId = context.InputParameters["EmailId"].ToString();

                        string outcomereasoncode = context.InputParameters["Outcomereasoncode"].ToString();

                        if (context.InputParameters["Underwriter"] != null)

                            underWriter = context.InputParameters["Underwriter"].ToString();

                        tracingService.Trace("outcomereasoncode" + outcomereasoncode);      //opp

                        tracingService.Trace("underWriter" + underWriter);
                        if (underWriter != null)
                        {

                            userId = getSystemUser(underWriter, service, tracingService);

                        }

                        if (string.IsNullOrWhiteSpace(EmailId))
                            EmailId = "SrvAcc.PowerUp.unassigned_nonprod@rsagroup.onmicrosoft.com";

                        Guid ownerId = getSystemUser(EmailId, service, tracingService);

                        tracingService.Trace("Opportunity Record Id=" + OppId);

                        Entity Opportunityrec = new Entity("opportunity");

                        Opportunityrec.Id = OppId;
                        if (userId != Guid.Empty)
                            updateOpportunityowner(service, tracingService, userId, OppId);

                        Entity Outcomereason = getOutcome(outcomereasoncode, service, tracingService);

                        if (Outcomereason.Id != null)

                        {

                            Opportunityrec["rsa_outcomereasonid"] = new EntityReference("rsa_outcomereason", Outcomereason.Id);

                        }

                        Entity statusreason = GetStatusReason(outcomereasoncode, service, tracingService);

                        service.Update(Opportunityrec);

                        tracingService.Trace("Opportunity Record is updated");
                       
                        Entity Case = new Entity("incident");

                        Case.Id = new Guid(CaseId);

                        if (statusreason.Id != null)

                        {

                            Case["rsa_statusreason"] = new EntityReference(statusreason.LogicalName, new Guid("6263b9e2-d037-eb11-bf6e-000d3a7ec625"));

                        }

                        Case["rsa_status"] = new EntityReference("rsa_status", new Guid("c197b842-f7e2-ea11-a816-000d3a64927d")); 

                        service.Update(Case);

                        tracingService.Trace("userId != Guid.Empty)" + userId + "CaseID=" + CaseId);

                        if (userId != Guid.Empty)

                            updatecaseowner(service, tracingService, userId, new Guid(CaseId));

                        tracingService.Trace("Case Record is updated");

                        updatecasestatusclose(service, tracingService, new Guid(CaseId));

                    }

                    // Renewal Terms not offered
                    else if (caseStatus.ToLower() == "renewal terms not offered" && casetype == "Renewal") 
                    {
                        tracingService.Trace("Processing Renewal terms not offered logic");

                        string EmailId = context.InputParameters["EmailId"].ToString();

                        // if user unassigned
                        if (string.IsNullOrWhiteSpace(EmailId))
                            EmailId = "SrvAcc.PowerUp.unassigned_nonprod@rsagroup.onmicrosoft.com";

                        Guid ownerId = getSystemUser(EmailId, service, tracingService);

                        // UPDATE OPPORTUNITY

                        Entity opp = new Entity("opportunity");
                        opp.Id = OppId;

                        service.Update(opp);

                        if (ownerId != Guid.Empty)
                            updateOpportunityowner(service, tracingService, ownerId, OppId);

                        // UPDATE CASE (MSD side)

                        Entity caseRec = new Entity("incident");
                        caseRec.Id = new Guid(CaseId);

                        caseRec["rsa_status"] = new EntityReference("rsa_status", new Guid("dd95b842-f7e2-ea11-a816-000d3a64927d"));

                        service.Update(caseRec);

                        if (ownerId != Guid.Empty)
                            updatecaseowner(service, tracingService, ownerId, new Guid(CaseId)); 

                        tracingService.Trace("Renewal terms not offered processing completed");
                    }


                    // To Be Quoted
                    else if (caseStatus.ToLower() == "to be quoted" && casetype == "Renewal") 
                    {
                        tracingService.Trace("Processing To Be Quoted logic");

                        string EmailId = context.InputParameters["EmailId"].ToString();
                        string Quotedeadlinedate = context.InputParameters["Quotedeadlinedate"].ToString();
                        tracingService.Trace("Quotedeadlinedate" + Quotedeadlinedate);      //opp

                        
                        // if user unassigned
                        if (string.IsNullOrWhiteSpace(EmailId))
                            EmailId = "SrvAcc.PowerUp.unassigned_nonprod@rsagroup.onmicrosoft.com";

                        Guid ownerId = getSystemUser(EmailId, service, tracingService);

                        // UPDATE OPPORTUNITY

                        Entity opp = new Entity("opportunity");
                        opp.Id = OppId;

                        service.Update(opp);

                        if (ownerId != Guid.Empty)
                            updateOpportunityowner(service, tracingService, ownerId, OppId);

                        // UPDATE CASE (MSD side)

                        Entity caseRec = new Entity("incident");
                        caseRec.Id = new Guid(CaseId);
                        
                        caseRec["rsa_quotedeadline"] = Convert.ToDateTime(Quotedeadlinedate);
                        caseRec["rsa_status"] = new EntityReference("rsa_status", new Guid("9398b842-f7e2-ea11-a816-000d3a64927d"));

                        service.Update(caseRec);

                        if (ownerId != Guid.Empty)
                            updatecaseowner(service, tracingService, ownerId, new Guid(CaseId)); 

                        tracingService.Trace("To Be Quoted processing completed");
                    }



                    //Renewed
                    else if (caseStatus.ToLower() == "renewed" && casetype == "Renewal")  

                    {

                        string underWriter = string.Empty;
                        string EmailId = context.InputParameters["EmailId"].ToString();

                        string Quotedeadlinedate = context.InputParameters["Quotedeadlinedate"].ToString();
                        string DateLTAExpires = context.InputParameters["DateLTAExpires"].ToString();

                        string RatePlanTarget = context.InputParameters["RatePlanTarget"].ToString();
                        string ContractCertaintyReasonforFailure = context.InputParameters["ContractCertaintyReasonforFailure"];
                        string WordingType = context.InputParameters["WordingType"];
                        string Tyelyr = context.InputParameters["Tyelyr"];
                        string LongTermAgreement = context.InputParameters["LongTermAgreement"];

                        tracingService.Trace("Quotedeadlinedate" + Quotedeadlinedate);      //opp

                        string Originalppm = (int)context.InputParameters["Originalppm"];
                        string MethodofPayment = (int)context.InputParameters["MethodofPayment"];
                        string RenewalPropensity = (int)context.InputParameters["RenewalPropensity"];

                        if (context.InputParameters["Underwriter"] != null)
                            underWriter = context.InputParameters["Underwriter"].ToString();

                        string BaseCommission = string.Empty;
                        if (context.InputParameters["BaseCommission"] != null)
                            BaseCommission = context.InputParameters["BaseCommission"].ToString();

                        string ISB = string.Empty;
                        if (context.InputParameters["ISB"] != null)
                            ISB = context.InputParameters["ISB"].ToString();
                        
                        string WorkTransfer = string.Empty;
                        if (context.InputParameters["WorkTransfer"] != null)
                            WorkTransfer = context.InputParameters["WorkTransfer"].ToString();

                        string ProfitShare = string.Empty;
                        if (context.InputParameters["ProfitShare"] != null)
                            ProfitShare = context.InputParameters["ProfitShare"].ToString();

                        string TotalRemuneration = string.Empty;
                        if (context.InputParameters["TotalRemuneration"] != null)
                            TotalRemuneration = context.InputParameters["TotalRemuneration"].ToString();
                        
                        string Terrorismpremium = context.InputParameters["Terrorismpremium"].ToString();

                        string RSALineSize = string.Empty;
                        if (context.InputParameters["RSALineSize"] != null)
                            RSALineSize = context.InputParameters["RSALineSize"].ToString();

                        if (underWriter != null)
                        {

                            userId = getSystemUser(underWriter, service, tracingService);

                        }

                        Guid ExistingInsuereMainId = Guid.Empty;


                         if (string.IsNullOrWhiteSpace(EmailId))
                            EmailId = "SrvAcc.PowerUp.unassigned_nonprod@rsagroup.onmicrosoft.com";

                        Guid ownerId = getSystemUser(EmailId, service, tracingService);


                        string ActualPremium = string.Empty;

                        if (context.InputParameters["ActualPremium"] != null)

                            ActualPremium = context.InputParameters["ActualPremium"].ToString();

                        string TechnicalPremium = string.Empty;

                        if (context.InputParameters["TechnicalPremium"] != null)

                            TechnicalPremium = context.InputParameters["TechnicalPremium"].ToString();

                        string ExistingInsurer = string.Empty;

                        if (context.InputParameters["ExistingInsurer"] != null)

                        {

                            ExistingInsurer = context.InputParameters["ExistingInsurer"].ToString();

                            ExistingInsuereMainId = getExistinginsurer(ExistingInsurer, service, tracingService);

                        }
                        
                        string CrisisManagementCover = string.Empty;

                        if (context.InputParameters["CrisisManagementCover"] != null)

                            CrisisManagementCover = context.InputParameters["CrisisManagementCover"].ToString();

                        string CrisisManagementCoverAmount = string.Empty;

                        if (context.InputParameters["CrisisManagementCoverAmount"] != null)

                            CrisisManagementCoverAmount = context.InputParameters["CrisisManagementCoverAmount"].ToString();

                        string DateTermsRequiredbyBrokerCustomer = string.Empty;

                        if (context.InputParameters["DateTermsRequiredbyBrokerCustomer"] != null)

                            DateTermsRequiredbyBrokerCustomer = context.InputParameters["DateTermsRequiredbyBrokerCustomer"].ToString();



                        string DateTermsIssuedtoBrokerCustomer = string.Empty;

                        if (context.InputParameters["DateTermsIssuedtoBrokerCustomer"] != null)

                            DateTermsIssuedtoBrokerCustomer = context.InputParameters["DateTermsIssuedtoBrokerCustomer"].ToString();



                        string DateTermsAgreedwithBrokerCustomer = string.Empty;

                        if (context.InputParameters["DateTermsAgreedwithBrokerCustomer"] != null)

                            DateTermsAgreedwithBrokerCustomer = context.InputParameters["DateTermsAgreedwithBrokerCustomer"].ToString();



                        string LeadFollow = string.Empty;

                        if (context.InputParameters["LeadFollow"] != null)

                            LeadFollow = context.InputParameters["LeadFollow"].ToString();



                        string PostFulfilmentActivities = string.Empty;

                        if (context.InputParameters["PostFulfilmentActivities"] != null)

                            PostFulfilmentActivities = context.InputParameters["PostFulfilmentActivities"].ToString();



                        Guid OppExtension = getOpportunityExtension(OppId.ToString(), service, tracingService);



                        Entity Opportunityrec = new Entity("opportunity");

                        Opportunityrec.Id = OppId;
                        if (userId != Guid.Empty)
                            updateOpportunityowner(service, tracingService, userId, OppId);


                        //RSA Quotede Premium

                        Opportunityrec["rsa_rsaquotedpremium"] = new Money(Convert.ToDecimal(ActualPremium));



                        //Gross RSA 100% Technical Price

                        Opportunityrec["rsa_opptytechnicalprice_dc"] = Convert.ToDecimal(TechnicalPremium);



                        //BaseCommission
                        if (BaseCommission != null)
                        {
                            Opportunityrec["rsa_ci_basecommission"] = Convert.ToDecimal(BaseCommission);
                        }

                        //ISB
                        if (ISB != null)
                        {
                            Opportunityrec["rsa_cl_isb"] = Convert.ToDecimal(ISB);
                        }


                        //Work Transfer
                        if (WorkTransfer != null)
                        {
                            Opportunityrec["rsa_worktransferpercentage"] = Convert.ToDecimal(WorkTransfer);
                        }

                        //Profit Share
                        if (ProfitShare != null)
                        {
                            Opportunityrec["rsa_profitsharepercentage"] = Convert.ToDecimal(ProfitShare);
                        }

                        //Total Remuneration
                        if (TotalRemuneration != null)
                        {
                            Opportunityrec["rsa_totalremunerationpercentage_ci"] = Convert.ToDecimal(TotalRemuneration);
                        }


                        //RSA Line Size
                        if (RSALineSize != null)
                        {
                            Opportunityrec["rsa_rsalinesize"] = Convert.ToDecimal(RSALineSize);
                            Opportunityrec["rsa_rsalinesize_dc"] = Convert.ToDecimal(RSALineSize);
                        }

                        if (Originalppm!= null) Opportunityrec["rsa_originalppm"] = new OptionSetValue(Originalppm); 
                        if (ContractCertaintyReasonforFailure!= null) Opportunityrec["rsa_quoteccreasonforfailure"] = new OptionSetValue(ContractCertaintyReasonforFailure); 
                        if (WordingType!= null) Opportunityrec["rsa_wordingtype"] = new OptionSetValue(WordingType); 
                        if (MethodofPayment!= null) Opportunityrec["rsa_methodofpayment"] = new OptionSetValue(MethodofPayment); 
                        if (Tyelyr != null) Opportunityrec["rsa_tyelyrgbp"] = Convert.ToDecimal(Tyelyr);
                        if (LongTermAgreement!= null) Opportunityrec["rsa_longtermagreements"] = new OptionSetValue(LongTermAgreement); 
                        if(DateLTAExpires!=null) Opportunityrec["rsa_contractdurationyears"] = Convert.ToDateTime(DateLTAExpires);
                        if (RenewalPropensity!= null) Opportunityrec["rsa_brokercommitment"] = new OptionSetValue(RenewalPropensity); 



                        

                        //Crisismanagement cover

                        Opportunityrec["rsa_crisismanagementcover"] = new OptionSetValue(Convert.ToInt32(CrisisManagementCover));

                        //Crisismanagement cover amount

                        Opportunityrec["rsa_crisismanagementcoveramount_dc"] = Convert.ToDecimal(CrisisManagementCoverAmount);

                        Opportunityrec["rsa_terrorismpremium"] = Convert.ToDecimal(Terrorismpremium);

                        Opportunityrec["rsa_rateplantarget"] = Convert.ToDecimal(RatePlanTarget);




                        if (ExistingInsuereMainId != Guid.Empty)

                        {
                            //Existing Insuerer
                            Opportunityrec["rsa_existinginsurerid"] = new EntityReference("rsa_existinginsurer", ExistingInsuereMainId);
                        }                    

                        //Exipary premium

                      Guid  Opportunitystageid= getstageId(null, service, tracingService);
                        Opportunityrec["rsa_opportunitystage"] = new EntityReference("rsa_opportunitystage", Opportunitystageid);

                        service.Update(Opportunityrec);

                        tracingService.Trace("Opportunity Record is updated");


                        if (OppExtension != Guid.Empty)

                        {

                            Entity OpportunityExtenrec = new Entity("rsa_extensionopportunity");

                            OpportunityExtenrec.Id = OppExtension;

                            //Broker Target Premium

                            OpportunityExtenrec["rsa_leadfollow"] = new OptionSetValue(Convert.ToInt32(LeadFollow));

                            OpportunityExtenrec["rsa_datetermsrequiredbybrokercustomer"] = Convert.ToDateTime(DateTermsRequiredbyBrokerCustomer);

                            OpportunityExtenrec["rsa_datetermsissuedtobrokercustomer"] = Convert.ToDateTime(DateTermsIssuedtoBrokerCustomer);

                            OpportunityExtenrec["rsa_datetermsagreedwithcustomerbroker"] = Convert.ToDateTime(DateTermsAgreedwithBrokerCustomer);



                            service.Update(OpportunityExtenrec);

                        }

                        tracingService.Trace("Opportunity Extesnion Record is updated");

                        Entity Case = new Entity("incident");

                        Case.Id = new Guid(CaseId);

                        Case["rsa_quotedeadline"] = Convert.ToDateTime(Quotedeadlinedate);

                        if (PostFulfilmentActivities != string.Empty)

                        {



                            OptionSetValueCollection activities = new OptionSetValueCollection();

                            string originalString = PostFulfilmentActivities;



                            // Split the string using a comma as the delimiter

                            string[] substrings = originalString.Split(',');



                            // Display the substrings

                            foreach (var substring in substrings)

                            {

                                activities.Add(new OptionSetValue(Convert.ToInt32(substring)));

                                //Console.WriteLine(substring);

                                tracingService.Trace("Case status" + substring);

                            }


                            Case["rsa_rsapolicyfulfilmentactivities"] = activities;

                        }

                        Case["rsa_status"] = new EntityReference("rsa_status", new Guid("3798b842-f7e2-ea11-a816-000d3a64927d"));




                        service.Update(Case);

                        if (userId != Guid.Empty)

                            updatecaseowner(service, tracingService, userId, new Guid(CaseId));

                        tracingService.Trace("Case status to be Accepted is updated");

                        if(PolicyNumber!= string.Empty && PolicyNumber != "")
                        {
                            updatecasestatusclose(service, tracingService, new Guid(CaseId));
                        }

                    }    


                    // Under Extension
                    else if (caseStatus.ToLower() == "under extension" && casetype == "Renewal") 
                    {
                        tracingService.Trace("Processing Renewal Under Extension logic");


                        string Quotedeadlinedate = context.InputParameters["Quotedeadlinedate"].ToString();
                        string AgreedExtensionDate = context.InputParameters["AgreedExtensionDate"].ToString();
                        string AgreedExtensionDate = context.InputParameters["AgreedExtensionDate"].ToString();
                        string EmailId = context.InputParameters["EmailId"].ToString();


                        // if user unassigned
                        if (string.IsNullOrWhiteSpace(EmailId))
                            EmailId = "SrvAcc.PowerUp.unassigned_nonprod@rsagroup.onmicrosoft.com";

                        Guid ownerId = getSystemUser(EmailId, service, tracingService);


                        // UPDATE OPPORTUNITY

                        Entity opp = new Entity("opportunity");
                        opp.Id = OppId;

                        service.Update(opp);

                        if (ownerId != Guid.Empty)
                            updateOpportunityowner(service, tracingService, ownerId, OppId);


                        // UPDATE CASE (MSD side)

                        Entity caseRec = new Entity("incident");
                        caseRec.Id = new Guid(CaseId);

                        if (!string.IsNullOrEmpty(Quotedeadlinedate))
                            caseRec["rsa_quotedeadline"] = Convert.ToDateTime(Quotedeadlinedate);

                        if (!string.IsNullOrEmpty(AgreedExtensionDate))
                            caseRec["rsa_agreedextensiondate"] = Convert.ToDateTime(AgreedExtensionDate);

                        caseRec["rsa_status"] = new EntityReference("rsa_status", new Guid("b098b842-f7e2-ea11-a816-000d3a64927d"));

                        service.Update(caseRec);

                        if (ownerId != Guid.Empty)
                            updatecaseowner(service, tracingService, ownerId, new Guid(CaseId));


                        tracingService.Trace("Renewal Under Extension processing completed");
                    }


                    // Lapsed
                    else if (caseStatus.ToLower() == "lapsed" && casetype == "Renewal")  
                    {
                        string underWriter = string.Empty;
                        string EmailId = context.InputParameters["EmailId"].ToString();
                        string Quotenumber = context.InputParameters["Quotenumber"].ToString();
                        string Quotedeadlinedate = context.InputParameters["Quotedeadlinedate"].ToString();
                        string Tyelyr = context.InputParameters["Tyelyr"];
                        tracingService.Trace("Quotedeadlinedate" + Quotedeadlinedate);      //opp
                        string Originalppm = (int)context.InputParameters["Originalppm"];
                        string RenewalPropensity = (int)context.InputParameters["RenewalPropensity"];
                        if (context.InputParameters["Underwriter"] != null)
                            underWriter = context.InputParameters["Underwriter"].ToString();                        
                        string Terrorismpremium = context.InputParameters["Terrorismpremium"].ToString();
                        if (underWriter != null)
                        {
                            userId = getSystemUser(underWriter, service, tracingService);
                        }

                        Guid ExistingInsuereMainId = Guid.Empty;


                         if (string.IsNullOrWhiteSpace(EmailId))
                            EmailId = "SrvAcc.PowerUp.unassigned_nonprod@rsagroup.onmicrosoft.com";

                        Guid ownerId = getSystemUser(EmailId, service, tracingService);


                        string ActualPremium = string.Empty;

                        if (context.InputParameters["ActualPremium"] != null)

                            ActualPremium = context.InputParameters["ActualPremium"].ToString();

                        string TechnicalPremium = string.Empty;

                        if (context.InputParameters["TechnicalPremium"] != null)

                            TechnicalPremium = context.InputParameters["TechnicalPremium"].ToString();

                        string OutcomeInsurer = string.Empty;

                        if (context.InputParameters["OutcomeInsurer"] != null)
                        {
                            OutcomeInsurer = context.InputParameters["OutcomeInsurer"].ToString();

                            OutcomeInsuereMainId = getOutcomeinsurer(OutcomeInsurer, service, tracingService);
                        }


                        Guid OppExtension = getOpportunityExtension(OppId.ToString(), service, tracingService);

                        Entity Opportunityrec = new Entity("opportunity");

                        Opportunityrec.Id = OppId;
                        if (userId != Guid.Empty)
                            updateOpportunityowner(service, tracingService, userId, OppId);

                        Opportunityrec["rsa_rsaquotedpremium"] = new Money(Convert.ToDecimal(ActualPremium));
                        Opportunityrec["rsa_opptytechnicalprice_dc"] = Convert.ToDecimal(TechnicalPremium);
                     
                        if (Originalppm!= null) Opportunityrec["rsa_originalppm"] = new OptionSetValue(Originalppm); 

                        if (Tyelyr != null) Opportunityrec["rsa_tyelyrgbp"] = Convert.ToDecimal(Tyelyr);

                        if (RenewalPropensity!= null) Opportunityrec["rsa_brokercommitment"] = new OptionSetValue(RenewalPropensity); 


                        Opportunityrec["rsa_terrorismpremium"] = Convert.ToDecimal(Terrorismpremium);
                        Opportunityrec["rsa_quotenumber"] = Quotenumber;

                        if (ExistingInsuereMainId != Guid.Empty)
                        {
                            //Outcome Insuerer
                            Opportunityrec["rsa_outcomeinsurer"] = new EntityReference("rsa_existinginsurer", ExistingInsuereMainId);
                        }        
           
                      Guid  Opportunitystageid= getstageId(null, service, tracingService);
                        Opportunityrec["rsa_opportunitystage"] = new EntityReference("rsa_opportunitystage", Opportunitystageid);

                        service.Update(Opportunityrec);

                        tracingService.Trace("Opportunity Record is updated");

                        if (OppExtension != Guid.Empty)

                        {

                            Entity OpportunityExtenrec = new Entity("rsa_extensionopportunity");

                            OpportunityExtenrec.Id = OppExtension;



                            service.Update(OpportunityExtenrec);

                        }

                        tracingService.Trace("Opportunity Extesnion Record is updated");

                        Entity Case = new Entity("incident");

                        Case.Id = new Guid(CaseId);

                        Case["rsa_quotedeadline"] = Convert.ToDateTime(Quotedeadlinedate);

                        Case["rsa_status"] = new EntityReference("rsa_status", new Guid("ee96b842-f7e2-ea11-a816-000d3a64927d"));    
 



                        service.Update(Case);

                        if (userId != Guid.Empty)

                            updatecaseowner(service, tracingService, userId, new Guid(CaseId));

                        tracingService.Trace("Case status to be Accepted is updated");

                        if(PolicyNumber!= string.Empty && PolicyNumber != "")
                        {
                            updatecasestatusclose(service, tracingService, new Guid(CaseId));
                        }

                    }               



                    Entity PushupIntegration = new Entity("rsa_powerupintegrationlog");

                    PushupIntegration["rsa_actions"] = "Update";

                    PushupIntegration["rsa_caserecord"] = new EntityReference("incident", new Guid(CaseId));

                    PushupIntegration["rsa_integrationstatus"] = new OptionSetValue(866760000);

                    PushupIntegration["rsa_direction"] = new OptionSetValue(866760000);



                    //var useremail = RSA_PowerUp_MSD_User@uk.rsagroup.com;



                    //Guid userGuid = getSystemUser(useremail, service, tracingService);

                    //if (userGuid != Guid.Empty)

                    //    PushupIntegration["rsa_initiatedby"] = new EntityReference("systemuser", userGuid);

                    // PushupIntegration["rsa_initiatedby"] = new EntityReference("systemuser", userId);

                    PushupIntegration["rsa_description"] = "CaseId: " + CaseId + " \n caseStatus: " + caseStatus;

                    PushupIntegration["rsa_name"] = "Powerup Integration is successful " + DateTime.UtcNow;

                    service.Create(PushupIntegration);

                    if (caseStatus.ToLower() == "diverted" || caseStatus.ToLower() == "to be quoted" || caseStatus.ToLower() == "quoted" || caseStatus.ToLower() == "accepted" || caseStatus.ToLower() == "not taken up")

                        context.OutputParameters["CRMCaseId"] = "Successfully case status " + caseStatus.ToLower() + " is updated";

                }

            }



            catch (Exception ex)

            {



                ExecuteMultipleRequest multipleRequest = new ExecuteMultipleRequest()

                {

                    // Create an empty organization request collection.

                    Requests = new OrganizationRequestCollection(),

                    Settings = new ExecuteMultipleSettings()

                    {

                        ContinueOnError = true,

                        ReturnResponses = false

                    }

                };

                Entity PushupIntegration = new Entity("rsa_powerupintegrationlog");

                PushupIntegration["rsa_actions"] = "Update";

                PushupIntegration["rsa_caserecord"] = new EntityReference("incident", new Guid(CaseId));

                PushupIntegration["rsa_integrationstatus"] = new OptionSetValue(866760000);

                PushupIntegration["rsa_direction"] = new OptionSetValue(866760000);

                PushupIntegration["rsa_errordescription"] = ex.Message;

                // SIT c1f7a045-db3e-ef11-a316-6045bdc15315    //UAT    e883f9b3-da3e-ef11-a316-000d3ad6977a

                // var useremail = RSA_PowerUp_MSD_User@uk.rsagroup.com;



                //Guid userGuid= getSystemUser(useremail, service, tracingService);

                // if(userGuid!=Guid.Empty)

                //     PushupIntegration["rsa_initiatedby"] = new EntityReference("systemuser", userGuid);

                PushupIntegration["rsa_description"] = "CaseId: " + CaseId + "\n caseStatus: " + caseStatus;

                PushupIntegration["rsa_name"] = "Error in Powerup Integration - " + DateTime.UtcNow;

                //service.Create(PushupIntegration);

                context.OutputParameters["CRMCaseId"] = "Error in case status " + caseStatus.ToLower() + " is updated";

                CreateRequest request = new CreateRequest();

                request.Target = PushupIntegration;



                multipleRequest.Requests.Add(request);



                service.Execute(multipleRequest);

                //Entity errorLog

                throw new InvalidPluginExecutionException("An error occurred in FollowUpPlugin " + ex.Message, ex);

            }



        }

        public Entity getOutcome(string name, IOrganizationService service, ITracingService tracingService)

        {

            try

            {

                var recordName = new Entity();

                var Outcomefetch = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +

     "<entity name='rsa_outcomereason'>" +

       "<attribute name='rsa_name' />" +

       "<attribute name='createdon' />" +

       "<attribute name='rsa_description' />" +

       "<attribute name='rsa_outcomereasonid' />" +

       "<attribute name='rsa_stage' />" +

       "<attribute name='rsa_opportunitystage' />" +

       "<attribute name='rsa_lineofbusiness' />" +

       "<order attribute='rsa_name' descending='false' />" +

       "<filter type='and'>" +

         "<condition attribute='rsa_name' operator='eq' value='" + name + "' />" +

         "<condition attribute='rsa_lineofbusiness' operator='eq' uiname='New Business' uitype='rsa_lineofbusiness' value='{B48E584F-13E2-EA11-A818-000D3A649469}' />" +

         "<condition attribute='rsa_stagename' operator='like' value='%Diverted%' />" +

       "</filter>" +

     "</entity>" +

   "</fetch>";

                EntityCollection ec = service.RetrieveMultiple(new FetchExpression(Outcomefetch));

                tracingService.Trace("Outcomefetch Record Id=" + ec.Entities.Count);

                if (ec.Entities.Count > 0)

                {

                    recordName = ec.Entities[0];

                }

                return recordName;

            }

            catch (Exception ex)

            {



                throw new InvalidPluginExecutionException(ex.Message);

            }

        }



        public Entity GetStatusReason(string name, IOrganizationService service, ITracingService tracingService)

        {

            var statusrecordName = new Entity();

            var fetchStatus = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +

  "<entity name='rsa_statusreason'>" +

    "<attribute name='rsa_name' />" +

    "<attribute name='createdon' />" +

    "<attribute name='rsa_status' />" +

    "<attribute name='rsa_casetype' />" +

    "<attribute name='rsa_statusreasonid' />" +

    "<order attribute='rsa_name' descending='false' />" +

    "<filter type='and'>";

            if (name == "Clients do not buy this insurance/cover" || name == "Unacceptable wording")

            {

                fetchStatus += "<condition attribute='rsa_name' operator='eq' value='Lack of Product Fit' />";

            }

            else if (name == "Premium uncompetitive")

            {

                fetchStatus += "<condition attribute='rsa_name' operator='eq' value='Not Profitable Enough For RSA' />";

            }



            else if (name == "Unattractive trade or occupation")

            {

                fetchStatus += "<condition attribute='rsa_name' operator='eq' value='Unattractive trade/occupation' />";

            }

            else

            {

                fetchStatus += "<condition attribute='rsa_name' operator='eq' value='" + name + "' />";

            }

            fetchStatus += "<condition attribute='statecode' operator='eq' value='0' />" +

      "<condition attribute='rsa_casetype' operator='eq' uiname='New Business' uitype='rsa_casetype' value='{48AA1262-F6E2-EA11-A818-000D3A649F51}' />" +

      "<condition attribute='rsa_status' operator='eq' uiname='' uitype='rsa_status' value='{1796B842-F7E2-EA11-A816-000D3A64927D}' />" +

    "</filter>" +

  "</entity>" +

"</fetch>";

            EntityCollection ec = service.RetrieveMultiple(new FetchExpression(fetchStatus));

            tracingService.Trace("Status reason Record Id=" + ec.Entities.Count);

            if (ec.Entities.Count > 0)

            {

                statusrecordName = ec.Entities[0];

            }

            return statusrecordName;

        }



        public Guid getSystemUser(string name, IOrganizationService service, ITracingService tracingService)

        {

            Guid UserId = Guid.Empty;

            var fetchUser = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +

  "<entity name='systemuser'>" +

    "<attribute name='fullname' />" +

    "<attribute name='businessunitid' />" +

    "<attribute name='title' />" +

    "<attribute name='address1_telephone1' />" +

    "<attribute name='positionid' />" +

    "<attribute name='systemuserid' />" +

    "<order attribute='fullname' descending='false' />" +

    "<filter type='and'>" +

      "<condition attribute='internalemailaddress' operator='eq' value='" + name + "' />" +

    "</filter>" +

  "</entity>" +

"</fetch>";

            EntityCollection ec = service.RetrieveMultiple(new FetchExpression(fetchUser));

            tracingService.Trace("User Record is =" + ec.Entities.Count);

            if (ec.Entities.Count > 0)

            {

                UserId = ec.Entities[0].Id;



            }

            return UserId;

        }



        public Guid getExistinginsurer(string name, IOrganizationService service, ITracingService tracingService)

        {

            Guid ExistingInsuerId = Guid.Empty;

            var fetchUser = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +

  "<entity name='rsa_existinginsurer'>" +

    "<attribute name='rsa_name' />" +

    "<attribute name='createdon' />" +

    "<attribute name='rsa_description' />" +

    "<attribute name='rsa_existinginsurerid' />" +

    "<order attribute='rsa_name' descending='false' />" +

    "<filter type='and'>" +

      "<condition attribute='rsa_name' operator='eq' value='" + WebUtility.HtmlEncode(name) + "' />" +

    "</filter>" +

  "</entity>" +

"</fetch>";

            EntityCollection ec = service.RetrieveMultiple(new FetchExpression(fetchUser));

            tracingService.Trace("User Record is =" + ec.Entities.Count);

            if (ec.Entities.Count > 0)

            {

                ExistingInsuerId = ec.Entities[0].Id;



            }

            return ExistingInsuerId;

        }



        public void updatecaseowner(IOrganizationService service, ITracingService tracingService, Guid userGuid, Guid caseId)

        {

            AssignRequest assignRequest = new AssignRequest

            {

                Assignee = new EntityReference("systemuser", userGuid),

                Target = new EntityReference("incident", caseId)

            };

            service.Execute(assignRequest);

        }

        public void updateOpportunityowner(IOrganizationService service, ITracingService tracingService, Guid userGuid, Guid opportunityId)

        {

            AssignRequest assignRequest = new AssignRequest

            {

                Assignee = new EntityReference("systemuser", userGuid),

                Target = new EntityReference("opportunity", opportunityId)

            };

            service.Execute(assignRequest);

        }

        public void updatecasestatusclose(IOrganizationService service, ITracingService tracingService, Guid caseId)

        {

            var activitiesfetch = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +

  "<entity name='task'>" +

    "<attribute name='subject' />" +

    "<attribute name='statecode' />" +

    "<attribute name='prioritycode' />" +

    "<attribute name='scheduledend' />" +

    "<attribute name='createdby' />" +

    "<attribute name='regardingobjectid' />" +

    "<attribute name='activityid' />" +

    "<order attribute='subject' descending='false' />" +

    "<filter type='and'>" +

      "<condition attribute='rsa_status' operator='ne' value='866760004' />" +

      "<condition attribute='regardingobjectid' operator='eq' uiname='00097919' uitype='incident' value='{" + caseId + "}' />" +

    "</filter>" +

  "</entity>" +

"</fetch>";

            EntityCollection ec = service.RetrieveMultiple(new FetchExpression(activitiesfetch));

            tracingService.Trace("task reason Record Id=" + ec.Entities.Count);

            if (ec.Entities.Count > 0)

            {

                foreach (Entity ent in ec.Entities)

                {

                    tracingService.Trace("task reason Record Id=" + ent.Id);

                    ent["rsa_status"] = new OptionSetValue(866760004);//Close status

                    service.Update(ent);

                }

            }

            closecase(service, tracingService, caseId);



        }



        public void closecase(IOrganizationService service, ITracingService tracingService, Guid caseId)

        {

            Entity Case = new Entity("incident");

            Case.Id = caseId;



            Case["rsa_status"] = new EntityReference("rsa_status", new Guid("0598b842-f7e2-ea11-a816-000d3a64927d"));//Close status

            service.Update(Case);

        }





        public Guid getOpportunityExtension(string name, IOrganizationService service, ITracingService tracingService)

        {

            Guid OpportunityextensionId = Guid.Empty;

            var fetchUser = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +

  "<entity name='opportunity'>" +

    "<attribute name='name' />" +

    "<attribute name='customerid' />" +

    "<attribute name='estimatedvalue' />" +

    "<attribute name='statuscode' />" +

    "<attribute name='opportunityid' />" +

    "<attribute name='rsa_opportunityextensionid' />" +

    "<order attribute='name' descending='false' />" +

    "<filter type='and'>" +

      "<condition attribute='opportunityid' operator='eq' uiname='' uitype='opportunity' value='" + name + "' />" +

    "</filter>" +

  "</entity>" +

"</fetch>";

            EntityCollection ec = service.RetrieveMultiple(new FetchExpression(fetchUser));

            tracingService.Trace("Opportunity extension Record is =" + ec.Entities.Count);

            if (ec.Entities.Count > 0)

            {

                if (ec.Entities[0].Attributes.Contains("rsa_opportunityextensionid"))

                    OpportunityextensionId = ec.Entities[0].GetAttributeValue<EntityReference>("rsa_opportunityextensionid").Id;



            }

            return OpportunityextensionId;

        }



        private int GetOptionsSetValueForLabel(IOrganizationService service, string entityName, string attributeName, string selectedLabel)

        {



            RetrieveAttributeRequest retrieveAttributeRequest = new

            RetrieveAttributeRequest

            {

                EntityLogicalName = entityName,

                LogicalName = attributeName,

                RetrieveAsIfPublished = true

            };

            // Execute the request.

            RetrieveAttributeResponse retrieveAttributeResponse = (RetrieveAttributeResponse)service.Execute(retrieveAttributeRequest);

            // Access the retrieved attribute.

            Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata retrievedPicklistAttributeMetadata = (Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata)

            retrieveAttributeResponse.AttributeMetadata;// Get the current options list for the retrieved attribute.

            OptionMetadata[] optionList = retrievedPicklistAttributeMetadata.OptionSet.Options.ToArray();

            int selectedOptionValue = 0;

            foreach (OptionMetadata oMD in optionList)

            {

                if (oMD.Label.LocalizedLabels[0].Label.ToString().ToLower() == selectedLabel.ToLower())

                {

                    selectedOptionValue = oMD.Value.Value;

                    break;

                }

            }

            return selectedOptionValue;

        }


        public Guid getstageId(string name, IOrganizationService service, ITracingService tracingService)

        {

            Guid stageId = Guid.Empty;

            var fetchOpportunityStage = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
  "<entity name='rsa_opportunitystage'>" +
    "<attribute name='rsa_name' />" +
    "<attribute name='createdon' />" +
    "<attribute name='rsa_lineofbusiness' />" +
    "<attribute name='rsa_opportunitystageid' />" +
    "<attribute name='rsa_stagecode' />" +
    "<attribute name='rsa_description' />" +
    "<order attribute='rsa_name' descending='false' />" +
    "<filter type='and'>" +
      "<condition attribute='rsa_name' operator='eq' value='Accepted' />" +
    "</filter>" +
    "<link-entity name='rsa_lineofbusiness' from='rsa_lineofbusinessid' to='rsa_lineofbusiness' link-type='inner' alias='ab'>" +
      "<filter type='and'>" +
        "<condition attribute='rsa_name' operator='eq' value='New Business' />" +
      "</filter>" +
    "</link-entity>" +
  "</entity>" +
"</fetch>";

            EntityCollection ec = service.RetrieveMultiple(new FetchExpression(fetchOpportunityStage));

            tracingService.Trace("fetchOpportunityStage Record is =" + ec.Entities.Count);

            if (ec.Entities.Count > 0)

            {

                stageId = ec.Entities[0].Id;



            }

            return stageId;

        }



    }
}