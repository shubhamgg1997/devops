﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoNumberField
{
    public class CreateAutoNumberField : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {

            // Obtain the tracing service
            ITracingService tracingService =
            (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            // Obtain the execution context from the service provider.  
            IPluginExecutionContext context = (IPluginExecutionContext)
                serviceProvider.GetService(typeof(IPluginExecutionContext));

            // The InputParameters collection contains all the data passed in the message request.  
            if (context.InputParameters.Contains("Target") &&
                context.InputParameters["Target"] is Entity)
            {
                // Obtain the target entity from the input parameters.  
                Entity entity = (Entity)context.InputParameters["Target"];

                // Obtain the organization service reference which you will need for  
                // web service calls.  
                IOrganizationServiceFactory serviceFactory =
                    (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
                tracingService.Trace("Before Try");
                try
                {
                    tracingService.Trace("CP 0");
                    //var entityName = entity.FormattedValues["rsa_entityname"].ToString();
                    string entityName = entity.FormattedValues.ContainsKey("rsa_entityname") ? entity.FormattedValues["rsa_entityname"].ToLowerInvariant() : null;
                    tracingService.Trace("CP 1");
                    var autoNumberFormat = entity.GetAttributeValue<string>("rsa_autonumberformat");
                    tracingService.Trace("CP 2");
                    var logicalNameOfField = entity.GetAttributeValue<string>("rsa_logicalname");
                    tracingService.Trace("CP 3");
                    var schemaNameOfField = entity.GetAttributeValue<string>("rsa_schemaname");
                    tracingService.Trace("CP 4");
                    var displayNameOfField = entity.GetAttributeValue<string>("rsa_displayname");
                    tracingService.Trace("CP 5");
                    var maxLength = entity.GetAttributeValue<int>("rsa_maxlength");
                    tracingService.Trace("CP 6");
                    var description = entity.GetAttributeValue<string>("rsa_description");
                    tracingService.Trace("CP 7");
                    var seedValue = entity.GetAttributeValue<int>("rsa_seedvalue");
                    tracingService.Trace("CP 8");
                    //var operation = entity.FormattedValues["rsa_operation"].ToString();
                    //int operationValue = entity.GetAttributeValue<OptionSetValue>("rsa_operation").Value;
                    string operationValue = entity.FormattedValues.ContainsKey("rsa_operation") ? entity.FormattedValues["rsa_operation"].ToLowerInvariant() : null;
                    tracingService.Trace("Data stored in the variables");


                    //Create AutoNumber Attribute
                    CreateAttributeRequest widgetSerialNumberAttributeRequest = new CreateAttributeRequest
                    {
                        // EntityName = "name", //Client Name has logical name as name
                        EntityName = entityName,
                        Attribute = new StringAttributeMetadata
                        {
                            AutoNumberFormat = autoNumberFormat,
                            LogicalName = logicalNameOfField,
                            SchemaName = schemaNameOfField,
                            RequiredLevel = new AttributeRequiredLevelManagedProperty(AttributeRequiredLevel.None),
                            MaxLength = maxLength, // The MaxLength defined for the string attribute must be greater than the length of the AutoNumberFormat value, that is, it should be able to fit in the generated value.
                            DisplayName = new Label(displayNameOfField, 1033),
                            Description = new Label(description, 1033),
                        }


                    };
                    service.Execute(widgetSerialNumberAttributeRequest);
                    tracingService.Trace("Field is created");

                    SetAutoNumberSeedRequest req = new SetAutoNumberSeedRequest();
                    req.EntityName = entityName;
                    req.AttributeName = logicalNameOfField;
                    req.Value = seedValue;
                    service.Execute(req);
                    tracingService.Trace("Seed Value Changed");
                    
                
                }
                catch (Exception ex)
                {
                    tracingService.Trace("AutoNumbering: {0}", ex.Message);
                    throw;
                }
            }
        }
    }
}
