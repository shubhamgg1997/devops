﻿
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoNumberField
{
    public class UpdateAutoNumberField : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {

            // Obtain the tracing service
            ITracingService tracingService =
            (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            // Obtain the execution context from the service provider.  
            IPluginExecutionContext context = (IPluginExecutionContext)
                serviceProvider.GetService(typeof(IPluginExecutionContext));

            // The InputParameters collection contains all the data passed in the message request.  
            if (context.InputParameters.Contains("Target") &&
                context.InputParameters["Target"] is Entity)
            {
                // Obtain the target entity from the input parameters.  
                //Entity entity = (Entity)context.InputParameters["Target"];

                Entity entity = (Entity)context.PreEntityImages["PreImage"];
                Entity postentity = (Entity)context.PostEntityImages["PostImage"];

                // Obtain the organization service reference which you will need for  
                // web service calls.  
                IOrganizationServiceFactory serviceFactory =
                    (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
                tracingService.Trace("Before Try");
                try
                {
                    tracingService.Trace("CP 0");
                    //var entityName = entity.FormattedValues["rsa_entityname"].ToString();
                    string entityName = entity.FormattedValues.ContainsKey("rsa_entityname") ? entity.FormattedValues["rsa_entityname"].ToLowerInvariant() : null;
                    tracingService.Trace("CP 1");
                    var logicalNameOfField = entity.GetAttributeValue<string>("rsa_logicalname");
                    tracingService.Trace("CP 2");
                    var newSeedValue = postentity.GetAttributeValue<int>("rsa_seedvalue");
                    //var oldSeedValue = entity.GetAttributeValue<int>("rsa_seedvalue");
                    tracingService.Trace("CP 3");
                    string operationValue = entity.FormattedValues.ContainsKey("rsa_operation") ? entity.FormattedValues["rsa_operation"].ToLowerInvariant():
                        postentity.FormattedValues.ContainsKey("rsa_operation") ? postentity.FormattedValues["rsa_operation"].ToLowerInvariant() : null;
                    tracingService.Trace("Data stored in the variables" + operationValue);

                    //On Update message 
                    if (operationValue == "update seed")
                    {
                        SetAutoNumberSeedRequest req = new SetAutoNumberSeedRequest();
                        req.EntityName = entityName;
                        req.AttributeName = logicalNameOfField;
                        req.Value = newSeedValue;
                        service.Execute(req);
                        tracingService.Trace("Seed Value Changed");
                    }
                }
                catch (Exception ex)
                {
                    tracingService.Trace("AutoNumbering: {0}", ex.Message);
                    throw;
                }
            }
        }
    }
}