﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Activities;
using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;

namespace MultiselectCustomWorkflow
{

    public class GetMultiselctOptionSetValue : CodeActivity
    {

        /*
       [RequiredArgument]
       [Input("Schema Name")]
       public InArgument schemaName { get; set; }

       [RequiredArgument]
       [Input("Compare Value")]
       public InArgument compareValue { get; set; }



      [Input("Entity Name")]
      public InArgument<string> entityName { get; set; }

      [Input("Compare Value")]
      public InArgument<string> compareValue { get; set; }
      */


        [Output("Output")]
        public OutArgument<string> output { get; set; }


        protected override void Execute(CodeActivityContext _executionContext)
        {
            IWorkflowContext _context = _executionContext.GetExtension<IWorkflowContext>();
            //IOrganizationServiceFactory serviceFactory = _executionContext.GetExtension<IOrganizationServiceFactory>();
            //IOrganizationService service = serviceFactory.CreateOrganizationService(_context.PrimaryEntityId);

            //input : EntityReference ; Requestentity
            //Input : Entity Name
            //Input // MultipleselectoptionsetAttibute NamSchememe
            //Input : Applicable value : Value to comaper 

            if (_context.InputParameters.Contains("Target") && _context.InputParameters["Target"] is Entity)
            {
                Entity entity = (Entity)_context.InputParameters["Target"];
                if (entity.Attributes.Contains("rsa_businessarearequesting"))
                {
                    OptionSetValueCollection coll = (OptionSetValueCollection)entity.Attributes["rsa_businessarearequesting"];
                    foreach (OptionSetValue item in coll)
                    {

                        if (item.Value.Equals(866760007))
                        {
                            // set ouput parameters as true. 
                            this.output.Set(_executionContext, "true");
                            break;
                        }
                       
                    }
                }

            }



            // Entity  rec = service.Retrieve("rsa_request",_context.PrimaryEntityId, new ColumnSet(new string[] {"rsa_businessarearequesting"}));
            // OptionSetValueCollection coll = rec.Attributes.Contains("rsa_businessarearequesting") ? (OptionSetValueCollection)rec.Attributes["rsa_businessarearequesting"] :null ;




        }


    }
}
