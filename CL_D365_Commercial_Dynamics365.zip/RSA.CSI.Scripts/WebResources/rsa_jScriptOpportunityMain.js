// JavaScript source code
// JavaScript source code
// JavaScript source code
//Date: 27-10-2021
/* Change Summary for April 2022 Release 1 */
/* Last Modified By: Bubun Bhandari*/
/* Summary of Changes: Remove Debug Code,add Xrm.Navigation.openAlertDialog instead of Xrm.Utility.alertDialog,Remove Xrm.Page and add Xrm.Utility.getGlobalContext() instead of Xrm.Page*/
/* - Reason for Change: Unexpected 'debugger' statement,Xrm.Utility.alertDialog,Xrm.Page use in code-MS Code Review  */
/* - Function name -  */

"use strict";
var tfs1095OppTypes;

var RSA = window.RSA || { __namespace: true, __typeName: "RSA" };
RSA.D365CRM = RSA.D365CRM || { __namespace: true, __typeName: "RSA.D365CRM" };
RSA.D365CRM.Opportunity = RSA.D365CRM.Opportunity || { __namespace: true, __typeName: "RSA.D365CRM.Opportunity" };
RSA.D365CRM.Opportunity.Main = RSA.D365CRM.Opportunity.Main || ({
    FormType: {
        Create: 1,
        Update: 2,
        ReadOnly: 3,
        Disabled: 4,
        BulkEdit: 6
    },
    OnLoad: function (executionContext) {
        var formContext = executionContext.getFormContext();
        //RSA.D365CRM.Opportunity.Main.TriggerChangeOnLoadOfForm(executionContext);    
        RSA.D365CRM.Opportunity.Main.AddPresearchOutcome(executionContext);
        if (formContext.ui.getFormType() === RSA.D365CRM.Opportunity.Main.FormType.Create) {
            RSA.D365CRM.Opportunity.Main.Lock(executionContext);
            RSA.D365CRM.Opportunity.Main.OutcomeReason(executionContext);
        }
        else if (formContext.ui.getFormType() === RSA.D365CRM.Opportunity.Main.FormType.Update) {
            RSA.D365CRM.Opportunity.Main.Lock(executionContext);
            //DM fix 31 May 2021 : Incorrect UI layout : Sumegh Dhole 
            RedirectAccordingToLOB(executionContext, "onload");
        }
        else if (formContext.ui.getFormType() === RSA.D365CRM.Opportunity.Main.FormType.Disabled) {
            RSA.D365CRM.Opportunity.Main.Lock(executionContext);
        }
        else if (formContext.ui.getFormType() === RSA.D365CRM.Opportunity.Main.FormType.BulkEdit) {
            RSA.D365CRM.Opportunity.Main.Lock(executionContext);
        }
        RSA.D365CRM.Opportunity.Main.BrokerTargetPremiumGBPMandatory(executionContext);
        //   RSA.D365CRM.Opportunity.Main.BrokerUpdate(executionContext); // Update broker per policy
        RSA.D365CRM.Opportunity.Main.UpdatePPPMRequirement(executionContext);
        RSA.D365CRM.Opportunity.Main.MakeFieldsMandatoryBasedOnOptyStage(executionContext);

    },

    ShowhideFields: function (executionContext) {

        var formContext = executionContext.getFormContext();
        if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
            var recordTypeName = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
            if (recordTypeName === "GSL - New Business" || recordTypeName === "GSL - Renewal") {

                if (formContext.getAttribute("rsa_pandlid").getValue() !== null) {
                    var pandlname = formContext.getAttribute("rsa_pandlid").getValue()[0].name;
                    if (pandlname === "GSL - Profin" || pandlname === "Engineering") {
                        formContext.getControl("rsa_nextrenewaldate").setVisible(false);
                        formContext.getControl("rsa_pygwpinclfrontinggbp").setVisible(false);
                        formContext.getControl("rsa_cynetpremiumgbp").setVisible(false);
                        //formContext.getControl("rsa_actualtri").setVisible(false);
                        formContext.getControl("rsa_policylengthcal").setVisible(false);
                        formContext.getControl("rsa_profitsharepc").setVisible(false);
                        formContext.getControl("rsa_pygwp100exgrossupsandterrorismpc").setVisible(false);
                        formContext.getControl("rsa_pygwprsashareexgrossupsandterrorismpc").setVisible(false);
                        formContext.getControl("rsa_pycaptivepremiumpc").setVisible(false);
                        formContext.getControl("rsa_pyinternalreinsurancepc").setVisible(false);
                        formContext.getControl("rsa_pycoinsurancepc").setVisible(false);
                        formContext.getControl("rsa_pygwpinclfrontingpc").setVisible(false);
                        formContext.getControl("rsa_pyterrorismpremiumpc").setVisible(false);
                        formContext.getControl("rsa_cygwp100exgrossupsandterrorismpc").setVisible(false);
                        formContext.getAttribute("rsa_cyrsashare").controls.get(0).setVisible(false);
                        formContext.getControl("rsa_cyrsashare").setVisible(false);
                        formContext.getControl("rsa_cygwprsashareexgrossupsandterrorismpc").setVisible(false);
                        //formContext.getControl("rsa_cycaptivepremiumpc").setVisible(false);
                        //formContext.getControl("rsa_rsainternalreinsurance").setVisible(false);
                        formContext.getControl("rsa_cygwpinclfrontingpc").setVisible(false);
                        formContext.getControl("rsa_basecommission").setVisible(false);
                        //formContext.getControl("rsa_basecommissionpc").setVisible(false); -- rename

                        formContext.getControl("rsa_worktransferfee").setVisible(false);
                        formContext.getControl("rsa_worktransferfeepc").setVisible(false);
                        //formContext.getControl("rsa_overriderdeductionspc").setVisible(false);
                        //formContext.getControl("rsa_overrideradditionspc").setVisible(false);
                        formContext.getControl("rsa_fximpactonexpiringpremium").setVisible(false);
                        formContext.getControl("rsa_pyexchangerate").setVisible(false);
                        formContext.getControl("rsa_pyexchangerate").setVisible(false);
                        formContext.getControl("rsa_pygwp100gbp").setVisible(false);
                        formContext.getControl("rsa_pygwprsashareexgrossupsandterrorismgbp").setVisible(false);
                        formContext.getControl("rsa_pyterrorismpremiumgbp").setVisible(false);
                        formContext.getControl("rsa_profitsharegbp").setVisible(false);
                        formContext.getControl("rsa_linesharechangepercent").setVisible(false);
                        formContext.getControl("rsa_linesharechange").setVisible(false);
                        formContext.getControl("rsa_exposurechangepercent").setVisible(false);
                        formContext.getControl("rsa_exposurechange").setVisible(false);
                        formContext.getControl("rsa_tyelyrgbp").setVisible(false);
                        formContext.getControl("rsa_cygwp100gbp").setVisible(false);
                        formContext.getControl("rsa_cyrsashare").setVisible(false);
                        formContext.getControl("rsa_cygwprsashareexgrossupsandterrorismgbp").setVisible(false);
                        formContext.getControl("rsa_cygwpinclfrontinggbp").setVisible(false);
                        formContext.getControl("rsa_cyfacreinsurancegbp").setVisible(false);
                        //formContext.getControl("rsa_basecommissiongbp").setVisible(false);
                        formContext.getControl("rsa_worktransferfeegbp").setVisible(false);
                        //formContext.getControl("rsa_overrideradditionsgbp").setVisible(false);
                        //formContext.getControl("rsa_overriderdeductionsgbp").setVisible(false);
                        formContext.getControl("rsa_profitshare").setVisible(false);
                        formContext.getControl("rsa_cycoinsurancecoreinsurance").setVisible(false);
                        formContext.getControl("rsa_pycoinsurancecoreinsurance").setVisible(false);
                        // formContext.getControl("rsa_rsacycaptivepremiumgbp").setVisible(false);
                        // formContext.getControl("rsa_exposurechange_dc").setVisible(true);
                        //formContext.getAttribute("rsa_nextrenewaldate").setRequiredLevel("none");
                        formContext.getAttribute("rsa_profitsharepc").setRequiredLevel("none");
                        //formContext.getAttribute("rsa_cygwp100exgrossupsandterrorismpc").setRequiredLevel("none");
                        //formContext.getAttribute("rsa_cygwprsashareexgrossupsandterrorismpc").setRequiredLevel("none");
                        //formContext.getAttribute("rsa_cycaptivepremiumpc").setRequiredLevel("none");
                        //formContext.getAttribute("rsa_rsainternalreinsurance").setRequiredLevel("none");
                        //formContext.getAttribute("rsa_basecommissionpc").setRequiredLevel("none");
                        //formContext.getAttribute("rsa_worktransferfeepc").setRequiredLevel("none");
                        //formContext.getAttribute("rsa_overriderdeductionspc").setRequiredLevel("none");
                        //formContext.getAttribute("rsa_overrideradditionspc").setRequiredLevel("none");
                        formContext.getAttribute("rsa_profitshare").setRequiredLevel("none");
                        //formContext.getAttribute("rsa_cycoinsurancecoreinsurance").setRequiredLevel("none");
                    }
                    else {
                        // New Changed as per New Mockup screen for GSL NB form
                        if (recordTypeName === "GSL - New Business") {
                            formContext.getControl("rsa_pygwp100exgrossupsandterrorismpc").setVisible(false);
                            formContext.getControl("rsa_pyrsashare").setVisible(false);
                            formContext.getControl("rsa_pygwprsashareexgrossupsandterrorismpc").setVisible(false);
                            formContext.getControl("rsa_pycaptivepremiumpc").setVisible(false);
                            formContext.getControl("rsa_pycaptivepremiumgbp").setVisible(false);
                            formContext.getControl("rsa_pyinternalreinsurancepc").setVisible(false);
                            formContext.getControl("rsa_pyinternalreinsurancegbp").setVisible(false);
                            formContext.getControl("rsa_pycoinsurancepc").setVisible(false);
                            formContext.getControl("rsa_pycoinsurancegbp").setVisible(false);
                            formContext.getControl("rsa_pycoinsurancecoreinsurance").setVisible(false);
                            formContext.getControl("rsa_pygwpinclfrontingpc").setVisible(false);
                            formContext.getControl("rsa_pygwpinclfrontinggbp").setVisible(false);
                            formContext.getControl("rsa_pyterrorismpremiumpc").setVisible(false);
                            formContext.getControl("rsa_fximpactonexpiringpremium").setVisible(false);
                            formContext.getControl("rsa_pyexchangerate").setVisible(false);
                            formContext.getControl("rsa_pygwp100gbp").setVisible(false);
                            formContext.getControl("rsa_pygwprsashareexgrossupsandterrorismgbp").setVisible(false);
                            formContext.getControl("rsa_pyterrorismpremiumgbp").setVisible(false);
                            formContext.getControl("rsa_linesharechangepercent").setVisible(false);
                            formContext.getControl("rsa_linesharechange").setVisible(false);
                            formContext.getControl("rsa_exposurechange").setVisible(false);
                            formContext.getControl("rsa_exposurechangepercent").setVisible(false);
                            formContext.getControl("rsa_tyelyrgbp").setVisible(false);
                            //formContext.getControl("rsa_actualtri").setVisible(false);
                            formContext.getControl("rsa_cygwpexgrossupsterrorismgbp").setVisible(false);

                        }
                        else {
                            formContext.getControl("rsa_pygwp100exgrossupsandterrorismpc").setVisible(true);
                            formContext.getControl("rsa_pyrsashare").setVisible(true);
                            formContext.getControl("rsa_pygwprsashareexgrossupsandterrorismpc").setVisible(true);
                            formContext.getControl("rsa_pycaptivepremiumpc").setVisible(true);
                            formContext.getControl("rsa_pycaptivepremiumgbp").setVisible(true);
                            formContext.getControl("rsa_pyinternalreinsurancepc").setVisible(true);
                            formContext.getControl("rsa_pyinternalreinsurancegbp").setVisible(true);
                            formContext.getControl("rsa_pycoinsurancepc").setVisible(true);
                            formContext.getControl("rsa_pycoinsurancegbp").setVisible(true);
                            formContext.getControl("rsa_pycoinsurancecoreinsurance").setVisible(true);
                            formContext.getControl("rsa_pygwpinclfrontingpc").setVisible(true);
                            formContext.getControl("rsa_pygwpinclfrontinggbp").setVisible(true);
                            formContext.getControl("rsa_pyterrorismpremiumpc").setVisible(true);
                            formContext.getControl("rsa_fximpactonexpiringpremium").setVisible(true);
                            formContext.getControl("rsa_pyexchangerate").setVisible(true);
                            formContext.getControl("rsa_pygwp100gbp").setVisible(true);
                            formContext.getControl("rsa_pygwprsashareexgrossupsandterrorismgbp").setVisible(true);
                            formContext.getControl("rsa_pyterrorismpremiumgbp").setVisible(true);
                            formContext.getControl("rsa_linesharechangepercent").setVisible(true);
                            formContext.getControl("rsa_linesharechange").setVisible(true);
                            formContext.getControl("rsa_exposurechange").setVisible(true);
                            formContext.getControl("rsa_exposurechangepercent").setVisible(true);
                            formContext.getControl("rsa_tyelyrgbp").setVisible(true);
                            formContext.getControl("rsa_actualtri").setVisible(true);
                            //formContext.getControl("rsa_cygwpexgrossupsterrorismgbp").setVisible(true);

                        }

                        //  formContext.getControl("rsa_rsacycaptivepremiumgbp").setVisible(true);
                        // formContext.getControl("rsa_exposurechange_dc").setVisible(true);
                        formContext.getControl("rsa_nextrenewaldate").setVisible(true);
                        // formContext.getControl("rsa_actualtri").setVisible(true);
                        formContext.getControl("rsa_policylengthcal").setVisible(true);
                        formContext.getControl("rsa_profitsharepc").setVisible(true);
                        formContext.getControl("rsa_cynetpremiumgbp").setVisible(true);

                        formContext.getControl("rsa_cygwp100exgrossupsandterrorismpc").setVisible(true);
                        formContext.getControl("rsa_cyrsashare").setVisible(true);
                        formContext.getControl("rsa_cygwprsashareexgrossupsandterrorismpc").setVisible(true);
                        //formContext.getControl("rsa_cycaptivepremiumpc").setVisible(true);
                        //formContext.getControl("rsa_rsainternalreinsurance").setVisible(true);
                        formContext.getControl("rsa_cygwpinclfrontingpc").setVisible(true);
                        formContext.getControl("rsa_basecommission").setVisible(true);
                        //formContext.getControl("rsa_basecommissionpc").setVisible(true); -- rename

                        formContext.getControl("rsa_worktransferfee").setVisible(true);
                        formContext.getControl("rsa_worktransferfeepc").setVisible(true);
                        //formContext.getControl("rsa_overriderdeductionspc").setVisible(true);
                        //formContext.getControl("rsa_overrideradditionspc").setVisible(true);

                        formContext.getControl("rsa_profitsharegbp").setVisible(true);

                        formContext.getControl("rsa_cygwp100gbp").setVisible(true);
                        formContext.getControl("rsa_cyrsashare").setVisible(true);
                        formContext.getControl("rsa_cygwprsashareexgrossupsandterrorismgbp").setVisible(true);
                        formContext.getControl("rsa_cygwpinclfrontinggbp").setVisible(true);
                        formContext.getControl("rsa_cyfacreinsurancegbp").setVisible(true);
                        //formContext.getControl("rsa_basecommissiongbp").setVisible(true);
                        formContext.getControl("rsa_worktransferfeegbp").setVisible(true);
                        // formContext.getControl("rsa_overrideradditionsgbp").setVisible(true);
                        //formContext.getControl("rsa_overriderdeductionsgbp").setVisible(true);
                        formContext.getControl("rsa_profitshare").setVisible(true);
                        formContext.getControl("rsa_cycoinsurancecoreinsurance").setVisible(true);


                        //formContext.getAttribute("rsa_nextrenewaldate").setRequiredLevel("required");
                        //formContext.getAttribute("rsa_profitsharepc").setRequiredLevel("required");
                        //formContext.getAttribute("rsa_cygwp100exgrossupsandterrorismpc").setRequiredLevel("required");
                        //formContext.getAttribute("rsa_cygwprsashareexgrossupsandterrorismpc").setRequiredLevel("required");
                        //formContext.getAttribute("rsa_cycaptivepremiumpc").setRequiredLevel("required");
                        //formContext.getAttribute("rsa_rsainternalreinsurance").setRequiredLevel("required");
                        //formContext.getAttribute("rsa_basecommissionpc").setRequiredLevel("required");
                        //formContext.getAttribute("rsa_worktransferfeepc").setRequiredLevel("required");
                        //formContext.getAttribute("rsa_overriderdeductionspc").setRequiredLevel("required");
                        //formContext.getAttribute("rsa_overrideradditionspc").setRequiredLevel("required");
                        //formContext.getAttribute("rsa_profitshare").setRequiredLevel("required");
                        //formContext.getAttribute("rsa_cycoinsurancecoreinsurance").setRequiredLevel("required");
                    }


                }
                else {

                    formContext.getControl("rsa_nextrenewaldate").setVisible(false);
                    //formContext.getControl("rsa_actualtri").setVisible(false);
                    formContext.getControl("rsa_policylengthcal").setVisible(false);
                    formContext.getControl("rsa_profitsharepc").setVisible(false);
                    formContext.getControl("rsa_pygwp100exgrossupsandterrorismpc").setVisible(false);
                    formContext.getControl("rsa_pygwprsashareexgrossupsandterrorismpc").setVisible(false);
                    formContext.getControl("rsa_pycaptivepremiumpc").setVisible(false);
                    formContext.getControl("rsa_pyinternalreinsurancepc").setVisible(false);
                    formContext.getControl("rsa_pycoinsurancepc").setVisible(false);
                    formContext.getControl("rsa_pygwpinclfrontingpc").setVisible(false);
                    formContext.getControl("rsa_pyterrorismpremiumpc").setVisible(false);
                    formContext.getControl("rsa_cygwp100exgrossupsandterrorismpc").setVisible(false);
                    formContext.getControl("rsa_cyrsashare").setVisible(false);
                    formContext.getControl("rsa_cynetpremiumgbp").setVisible(false);
                    formContext.getControl("rsa_cygwprsashareexgrossupsandterrorismpc").setVisible(false);
                    //formContext.getControl("rsa_cycaptivepremiumpc").setVisible(false);
                    //formContext.getControl("rsa_rsainternalreinsurance").setVisible(false);
                    formContext.getControl("rsa_cygwpinclfrontingpc").setVisible(false);
                    formContext.getControl("rsa_basecommission").setVisible(false);
                    //formContext.getControl("rsa_basecommissionpc").setVisible(false); -- rename

                    formContext.getControl("rsa_worktransferfee").setVisible(false);
                    formContext.getControl("rsa_worktransferfeepc").setVisible(false);
                    //formContext.getControl("rsa_overriderdeductionspc").setVisible(false);
                    //formContext.getControl("rsa_overrideradditionspc").setVisible(false);
                    formContext.getControl("rsa_fximpactonexpiringpremium").setVisible(false);
                    formContext.getControl("rsa_pyexchangerate").setVisible(false);
                    formContext.getControl("rsa_pygwp100gbp").setVisible(false);
                    formContext.getControl("rsa_pygwprsashareexgrossupsandterrorismgbp").setVisible(false);
                    formContext.getControl("rsa_pyterrorismpremiumgbp").setVisible(false);
                    formContext.getControl("rsa_profitsharegbp").setVisible(false);
                    formContext.getControl("rsa_linesharechangepercent").setVisible(false);
                    formContext.getControl("rsa_linesharechange").setVisible(false);
                    formContext.getControl("rsa_exposurechangepercent").setVisible(false);
                    formContext.getControl("rsa_exposurechange").setVisible(false);
                    formContext.getControl("rsa_tyelyrgbp").setVisible(false);
                    formContext.getControl("rsa_cygwp100gbp").setVisible(false);
                    formContext.getControl("rsa_cyrsashare").setVisible(false);
                    formContext.getControl("rsa_cygwprsashareexgrossupsandterrorismgbp").setVisible(false);
                    formContext.getControl("rsa_cygwpinclfrontinggbp").setVisible(false);
                    formContext.getControl("rsa_cyfacreinsurancegbp").setVisible(false);
                    //formContext.getControl("rsa_basecommissiongbp").setVisible(false);
                    formContext.getControl("rsa_worktransferfeegbp").setVisible(false);
                    //formContext.getControl("rsa_overrideradditionsgbp").setVisible(false);
                    //formContext.getControl("rsa_overriderdeductionsgbp").setVisible(false);
                    formContext.getControl("rsa_profitshare").setVisible(false);
                    formContext.getControl("rsa_cycoinsurancecoreinsurance").setVisible(false);
                    formContext.getControl("rsa_pycoinsurancecoreinsurance").setVisible(false);

                    //formContext.getAttribute("rsa_nextrenewaldate").setRequiredLevel("none");
                    formContext.getAttribute("rsa_profitsharepc").setRequiredLevel("none");
                    //formContext.getAttribute("rsa_cygwp100exgrossupsandterrorismpc").setRequiredLevel("none");
                    //formContext.getAttribute("rsa_cygwprsashareexgrossupsandterrorismpc").setRequiredLevel("none");
                    //formContext.getAttribute("rsa_cycaptivepremiumpc").setRequiredLevel("none");
                    //formContext.getAttribute("rsa_rsainternalreinsurance").setRequiredLevel("none");
                    //formContext.getAttribute("rsa_basecommissionpc").setRequiredLevel("none");
                    //formContext.getAttribute("rsa_worktransferfeepc").setRequiredLevel("none");
                    //formContext.getAttribute("rsa_overriderdeductionspc").setRequiredLevel("none");
                    //formContext.getAttribute("rsa_overrideradditionspc").setRequiredLevel("none");
                    formContext.getAttribute("rsa_profitshare").setRequiredLevel("none");
                    //formContext.getAttribute("rsa_cycoinsurancecoreinsurance").setRequiredLevel("none");

                }
                // formContext.getAttribute("rsa_prospecttype").setRequiredLevel("required"); (Hiding the field for TFS 453 on all forms)
                //	formContext.getAttribute("rsa_longtermagreements").setRequiredLevel("required");	
                //formContext.getAttribute("rsa_contractdurationyears").setRequiredLevel("required");
                formContext.getAttribute("rsa_expirydate").setRequiredLevel("required");
                // formContext.getAttribute("rsa_riskmanagementbursarypc").setRequiredLevel("required");
                //formContext.getAttribute("rsa_feesadditionaltopremiumgsl1").setRequiredLevel("required");
                //formContext.getAttribute("rsa_riskengineeringfee").setRequiredLevel("required");
                //formContext.getAttribute("rsa_cycoinsurancepc").setRequiredLevel("required");
                //formContext.getAttribute("rsa_cyterrorismpremiumpc").setRequiredLevel("required");
                //formContext.getAttribute("rsa_tripercentpc").setRequiredLevel("required");
                // formContext.getAttribute("rsa_cyfacri").setRequiredLevel("required");
                //formContext.getAttribute("rsa_rsaexternalreinsuranceinclpanelpc").setRequiredLevel("required");


            }
            else {
                formContext.getControl("rsa_nextrenewaldate").setVisible(true);
                //formContext.getControl("rsa_actualtri").setVisible(true);
                formContext.getControl("rsa_policylengthcal").setVisible(true);
                formContext.getControl("rsa_profitsharepc").setVisible(true);
                formContext.getControl("rsa_pygwp100exgrossupsandterrorismpc").setVisible(true);
                formContext.getControl("rsa_pygwprsashareexgrossupsandterrorismpc").setVisible(true);
                //formContext.getControl("rsa_pycaptivepremiumpc").setVisible(true);
                formContext.getControl("rsa_pyinternalreinsurancepc").setVisible(true);
                formContext.getControl("rsa_pycoinsurancepc").setVisible(true);
                formContext.getControl("rsa_pygwpinclfrontingpc").setVisible(true);
                formContext.getControl("rsa_pyterrorismpremiumpc").setVisible(true);
                formContext.getControl("rsa_cygwp100exgrossupsandterrorismpc").setVisible(true);
                formContext.getControl("rsa_cyrsashare").setVisible(true);
                formContext.getControl("rsa_cynetpremiumgbp").setVisible(true);
                formContext.getControl("rsa_cygwprsashareexgrossupsandterrorismpc").setVisible(true);
                //formContext.getControl("rsa_cycaptivepremiumpc").setVisible(true);
                //formContext.getControl("rsa_rsainternalreinsurance").setVisible(true);
                formContext.getControl("rsa_cygwpinclfrontingpc").setVisible(true);
                formContext.getControl("rsa_basecommission").setVisible(true);
                //formContext.getControl("rsa_basecommissionpc").setVisible(true); -- rename

                formContext.getControl("rsa_worktransferfee").setVisible(true);
                formContext.getControl("rsa_worktransferfeepc").setVisible(true);
                //formContext.getControl("rsa_overriderdeductionspc").setVisible(true);
                //formContext.getControl("rsa_overrideradditionspc").setVisible(true);
                formContext.getControl("rsa_fximpactonexpiringpremium").setVisible(true);
                formContext.getControl("rsa_pyexchangerate").setVisible(true);
                formContext.getControl("rsa_pygwp100gbp").setVisible(true);
                formContext.getControl("rsa_pygwprsashareexgrossupsandterrorismgbp").setVisible(true);
                formContext.getControl("rsa_pyterrorismpremiumgbp").setVisible(true);
                formContext.getControl("rsa_profitsharegbp").setVisible(true);
                formContext.getControl("rsa_linesharechangepercent").setVisible(true);
                formContext.getControl("rsa_linesharechange").setVisible(true);
                formContext.getControl("rsa_exposurechangepercent").setVisible(true);
                //formContext.getControl("rsa_exposurechange").setVisible(false);
                formContext.getControl("rsa_tyelyrgbp").setVisible(true);
                formContext.getControl("rsa_cygwp100gbp").setVisible(true);
                formContext.getControl("rsa_cyrsashare").setVisible(true);
                formContext.getControl("rsa_cygwprsashareexgrossupsandterrorismgbp").setVisible(true);
                formContext.getControl("rsa_cygwpinclfrontinggbp").setVisible(true);
                formContext.getControl("rsa_cyfacreinsurancegbp").setVisible(true);
                //formContext.getControl("rsa_basecommissiongbp").setVisible(true);
                formContext.getControl("rsa_worktransferfeegbp").setVisible(true);
                //formContext.getControl("rsa_overrideradditionsgbp").setVisible(true);
                //formContext.getControl("rsa_overriderdeductionsgbp").setVisible(true);
                formContext.getControl("rsa_profitshare").setVisible(true);
                formContext.getControl("rsa_cycoinsurancecoreinsurance").setVisible(true);
                formContext.getControl("rsa_pycoinsurancecoreinsurance").setVisible(true);

                //formContext.getAttribute("rsa_nextrenewaldate").setRequiredLevel("required");
                formContext.getAttribute("rsa_profitsharepc").setRequiredLevel("required");
                //formContext.getAttribute("rsa_cygwp100exgrossupsandterrorismpc").setRequiredLevel("required");
                //formContext.getAttribute("rsa_cygwprsashareexgrossupsandterrorismpc").setRequiredLevel("required");
                //formContext.getAttribute("rsa_cycaptivepremiumpc").setRequiredLevel("required");
                //formContext.getAttribute("rsa_rsainternalreinsurance").setRequiredLevel("required");
                //formContext.getAttribute("rsa_basecommissionpc").setRequiredLevel("required");
                //formContext.getAttribute("rsa_worktransferfeepc").setRequiredLevel("required");
                //formContext.getAttribute("rsa_overriderdeductionspc").setRequiredLevel("required");
                //formContext.getAttribute("rsa_overrideradditionspc").setRequiredLevel("required");
                formContext.getAttribute("rsa_profitshare").setRequiredLevel("required");
                //formContext.getAttribute("rsa_cycoinsurancecoreinsurance").setRequiredLevel("required");
                //formContext.getAttribute("rsa_tripercentpc").setRequiredLevel("required");
                // formContext.getAttribute("rsa_cyfacri").setRequiredLevel("required");
                //formContext.getAttribute("rsa_rsaexternalreinsuranceinclpanelpc").setRequiredLevel("required");
            }
        }
    },

    RatingSegmentPosition1: function (executionContext) {


        try {
            Qawsjkl24
            var formContext = executionContext.getFormContext();
            if (formContext.ui.getFormType() === 1) {
                return;
            }
            var recordId = formContext.data.entity.getId();

            var recordTypeName, opptyStage, ratingSegmentPosition, manufacturingStatus;

            if (formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined" && formContext.getAttribute("rsa_opportunitystage") !== null && formContext.getAttribute("rsa_opportunitystage") !== "undefined") {

                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    recordTypeName = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                }

                if (formContext.getAttribute("rsa_opportunitystage").getValue() !== null) {
                    opptyStage = formContext.getAttribute("rsa_opportunitystage").getValue()[0].name;
                }
                var globalContext = Xrm.Utility.getGlobalContext();
                var req = new XMLHttpRequest();
                // req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v9.1/rsa_extensionopportunities?$select=rsa_ratingsegmentposition&$filter=_rsa_opportunity_value eq " + recordId, false);
                req.open("GET", globalContext.getClientUrl() + "/api/data/v9.1/rsa_extensionopportunities?$select=rsa_ratingsegmentposition,rsa_manufacturingstatus&$filter=_rsa_opportunity_value eq " + recordId, false);
                req.setRequestHeader("OData-MaxVersion", "4.0");
                req.setRequestHeader("OData-Version", "4.0");
                req.setRequestHeader("Accept", "application/json");
                req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                req.onreadystatechange = function () {
                    if (this.readyState === 4) {
                        req.onreadystatechange = null;
                        if (this.status === 200) {
                            var results = JSON.parse(this.response);
                            for (var i = 0; i < results.value.length; i++) {
                                ratingSegmentPosition = results.value[i]["rsa_ratingsegmentposition"];
                                manufacturingStatus = results.value[i]["rsa_manufacturingstatus"];
                            }
                        } else {
                            //Xrm.Utility.alertDialog(this.statusText);
                            Xrm.Navigation.openAlertDialog(this.statusText);
                        }
                    }
                };
                req.send();


                if (recordTypeName === "Renewal - Motor" && (opptyStage === "Lapsed" || opptyStage === "Renewed" || opptyStage === "Quoted") && ratingSegmentPosition === null) {
                    localStorage['OpportunityStage'] = opptyStage;
                    formContext.ui.setFormNotification("Rating Segment Position must be input into Opportunity Extension before saving record ", "ERROR", "3000");
                    executionContext.getEventArgs().preventDefault();
                }
                else {

                    formContext.ui.clearFormNotification("3000");
                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "RatingSegmentPosition -" + err.message });
        }
    },



    MandatoryfieldsForOpportunityExtension: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            var recordTypeName, opptyStage;
            if (formContext.ui.getFormType() === 1) {
                return;
            }
            if (formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined" && formContext.getAttribute("rsa_distribution") !== null && formContext.getAttribute("rsa_ratingsegmentposition") !== "undefined") {

                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    recordTypeName = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                }

                /* if (window.parent.window[1] !== "undefined" && window.parent.window[1] !== null && window.parent.window[1].Xrm.Page.getAttribute("rsa_opportunitystage") !== "undefined" && window.parent.window[1].Xrm.Page.getAttribute("rsa_opportunitystage") !== null) {
                    opptyStage = window.parent.window[1].Xrm.Page.getAttribute("rsa_opportunitystage").getValue()[0].name;
                } */

                if (localStorage['OpportunityStage'] !== null) {

                    opptyStage = localStorage['OpportunityStage'];

                    if (recordTypeName === "Renewal - Motor" && (opptyStage === "Accepted" || opptyStage === "Renewed") && formContext.getAttribute("rsa_distribution").getValue() === null) {
                        formContext.getControl("rsa_distribution").setNotification("Please Select the value in Distribution", 101);
                        formContext.getAttribute("rsa_distribution").setRequiredLevel("required");
                    }
                    else {
                        formContext.getControl("rsa_distribution").clearNotification(101);
                        formContext.getAttribute("rsa_distribution").setRequiredLevel("none");
                    }
                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "RatingSegmentPositionForOpportunityExtension -" + err.message });
        }
    },

    FilterlookupOutcomereason: function (executionContext) {

        try {

            var formContext = executionContext.getFormContext();
            var formitem = formContext.ui.formSelector.getCurrentItem().getId();

            if (formitem == "c5ad6ca5-76d2-479e-a075-448934bd38fa" || formitem == "9b257cc7-8ffb-4f60-bc44-9adc27d402f9") {
                if ((formContext.getAttribute("rsa_opportunitystage").getValue() !== null) && (formContext.getAttribute("rsa_opportunitystage").getValue()[0]['name'] == "Diverted")) {


                    if (formContext.getAttribute("rsa_lineofbusiness") !== "undefined") {



                        if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                            var recordTypeName = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                            var Cobname = formContext.getAttribute("rsa_classofbusiness").getValue()[0].name;
                            if (recordTypeName == "New Business") {
                                if (Cobname !== "ProFin London - PI" && Cobname !== "ProFin Regions - PI") {

                                    if (formContext.getAttribute("rsa_outcomereasonid") !== "undefined") {
                                        var fetchxml = "<filter type='and'> <condition attribute='rsa_outcomereasonid' operator='not-in'> <value uiname='Limitï¿½ Basisï¿½ AGGï¿½ plusï¿½ Reinstatements' uitype='rsa_outcomereason'>{B8231018-D96C-EE11-9AE7-0022481B5A9B}</value><value uiname='Limitï¿½ Basisï¿½ AOC' uitype='rsa_outcomereason'>{058D2500-D96C-EE11-9AE7-0022481B5A9B}</value><value uiname='Limitsï¿½ ofï¿½ Indemnity' uitype='rsa_outcomereason'>{FE80F609-E06C-EE11-9AE7-0022481B5A9B}</value><value uiname='Financialï¿½ Stability' uitype='rsa_outcomereason'>{9E561730-D96C-EE11-9AE7-0022481B5A9B}</value><value uiname='Contractï¿½ Limits' uitype='rsa_outcomereason'>{25E16142-D96C-EE11-9AE7-0022481B5A9B}</value><value uiname='Manufacturing' uitype='rsa_outcomereason'>{85A88A5A-D96C-EE11-9AE7-0022481B5A9B}</value><value uiname='Riskï¿½ Management' uitype='rsa_outcomereason'>{9A14CB72-D96C-EE11-9AE7-0022481B5A9B}</value><value uiname='Highï¿½ volumeï¿½ ofï¿½ Subï¿½ Contractedï¿½ work' uitype='rsa_outcomereason'>{07E80D8B-D96C-EE11-9AE7-0022481B5A9B}</value><value uiname='Geography' uitype='rsa_outcomereason'>{4B18F99C-D96C-EE11-9AE7-0022481B5A9B}</value><value uiname='Feeï¿½ Income/Turnover' uitype='rsa_outcomereason'>{CB117EBB-D96C-EE11-9AE7-0022481B5A9B}</value><value uiname='Overseasï¿½ Work' uitype='rsa_outcomereason'>{2046A4D3-D96C-EE11-9AE7-0022481B5A9B}</value><value uiname='Renewableï¿½ Energy' uitype='rsa_outcomereason'>{EC8E9FEB-D96C-EE11-9AE7-0022481B5A9B}</value></condition></filter>";
                                        formContext.getControl("rsa_outcomereasonid").addCustomFilter(fetchxml);
                                    }
                                }

                            }
                        }

                    }

                }
            }
        }


        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "Outcome Reaosn -" + err.message });
        }

    },



    OnSave: function (executionContext) {

        //Modified On - 09/07/2022;Nida; CR 1243,1778 - commented as part of change request
        //RSA.D365CRM.Opportunity.Main.TriggerChangeOnLoadOfForm(executionContext);
        RSA.D365CRM.Opportunity.Main.ExpiryDateFieldValidation(executionContext);
        RSA.D365CRM.Opportunity.Main.MandatoryCheckDescriptionField(executionContext);
        RSA.D365CRM.Opportunity.Main.ValidationCreateOpportunityForNextYearIfNTUField(executionContext);
        RSA.D365CRM.Opportunity.Main.MandatoryCheckLexisNexis(executionContext);
        RSA.D365CRM.Opportunity.Main.ValidateMultiplePolicyNumberNeeded(executionContext);
        RSA.D365CRM.Opportunity.Main.CalculateRSAPremiumGoCPC(executionContext);
        RSA.D365CRM.Opportunity.Main.QuoteNumber(executionContext);
        RSA.D365CRM.Opportunity.Main.SetRenewalMonth(executionContext);
        RSA.D365CRM.Opportunity.Main.SetPolicyLength(executionContext);
        RSA.D365CRM.Opportunity.Main.OpportunityFormID(executionContext);
        RSA.D365CRM.Opportunity.Main.ValidateSMEdealsproduct(executionContext);
        RSA.D365CRM.Opportunity.Main.ValidateBalanceSheetandNetTurnover(executionContext);
        RSA.D365CRM.Opportunity.Main.MandatoryCheckAreAllEndtsPresent(executionContext);
        RSA.D365CRM.Opportunity.Main.MandatoryCheckBrokerExpectationsDiscussionHistory(executionContext);
        RSA.D365CRM.Opportunity.Main.MandatoryCheckCoverSpreadsheetUpdatedField(executionContext);
        RSA.D365CRM.Opportunity.Main.MandatoryCheckHasCurrentYearEPIbeenCheckedUpdateField(executionContext);
        RSA.D365CRM.Opportunity.Main.MandatoryCheckHRC(executionContext);
        RSA.D365CRM.Opportunity.Main.MandatoryCheckIPT(executionContext);
        RSA.D365CRM.Opportunity.Main.MandatoryCheckIsExpiringEPIAccurate(executionContext);
        RSA.D365CRM.Opportunity.Main.ROIDatenotgreaterthantoday(executionContext);
        RSA.D365CRM.Opportunity.Main.ROIDatenotgreaterthantodayfordocs(executionContext);
        //RSA.D365CRM.Opportunity.Main.rsa_Commission100PC(executionContext);
        RSA.D365CRM.Opportunity.Main.rsa_commissioncalcpc(executionContext);
        RSA.D365CRM.Opportunity.Main.rsa_cynetpremiumpc(executionContext);
        RSA.D365CRM.Opportunity.Main.rsa_distancefromtechnicalpricepc(executionContext);
        RSA.D365CRM.Opportunity.Main.rsa_quotedindicator(executionContext);
        RSA.D365CRM.Opportunity.Main.rsa_riskengineeringfeegbp(executionContext);
        RSA.D365CRM.Opportunity.Main.rsa_rsagrossgwppc(executionContext);
        RSA.D365CRM.Opportunity.Main.rsa_rsanetgwppc(executionContext);
        RSA.D365CRM.Opportunity.Main.rsa_rsapremiumgocpc(executionContext);
        RSA.D365CRM.Opportunity.Main.rsa_rsapremiumnetofcommissionripc(executionContext);
        RSA.D365CRM.Opportunity.Main.rsa_rsapremiumnocpc(executionContext);
        RSA.D365CRM.Opportunity.Main.rsa_technicalpricegoc(executionContext);
        RSA.D365CRM.Opportunity.Main.rsa_technicalpricegocpc(executionContext);
        RSA.D365CRM.Opportunity.Main.rsa_technicalpricenoc(executionContext);
        RSA.D365CRM.Opportunity.Main.rsa_technicalpricenocpc(executionContext);
        RSA.D365CRM.Opportunity.Main.rsa_divertindicator(executionContext);
        RSA.D365CRM.Opportunity.Main.rsa_commissionrsapremiumpc(executionContext);
        RSA.D365CRM.Opportunity.Main.rsa_cygwpexgrossupsterrorismpc(executionContext);
        RSA.D365CRM.Opportunity.Main.RSA_GWP_PC(executionContext);
        RSA.D365CRM.Opportunity.Main.GetTotalPremiumAmount(executionContext);
        //RSA.D365CRM.Opportunity.Main.MandatoryCheckTotalGWP100PCField(executionContext);
        RSA.D365CRM.Opportunity.Main.QuotedPremiumAlert(executionContext);
        RSA.D365CRM.Opportunity.Main.AllowOnlyNumbers(executionContext);
        RSA.D365CRM.Opportunity.Main.commission_mandatory_profin(executionContext);
        RSA.D365CRM.Opportunity.Main.RSAQuotedPremiumCheckForAllRenewals(executionContext);

        //Date: 14-11-2024
        /* Change Summary for CR-421 , CR-422 
            Modified By : Mohit 
            Summary of Changes : call SLUnderwriterFieldForRealEstateNBRenewal function on save of form
        */
        RSA.D365CRM.Opportunity.Main.SLUnderwriterFieldForRealEstateNBRenewal(executionContext);

        RSA.D365CRM.Opportunity.Main.MandatoryForRenewal(executionContext);
        // RSA.D365CRM.Opportunity.Main.MandatoryfieldsForOpportunityExtension(executionContext);
        RSA.D365CRM.Opportunity.Main.RatingSegmentPosition(executionContext);
        RSA.D365CRM.Opportunity.Main.BrokerTargetPremiumGBPMandatory(executionContext);
        RSA.D365CRM.Opportunity.Main.UpdatePPPMRequirement(executionContext);
        RSA.D365CRM.Opportunity.Main.MakeFieldsMandatoryBasedOnOptyStage(executionContext);
    },


    //Author : Chandani Vaishnani
    //Date_Created : 16 July 2020
    //This Function Mandatory Check for Cover Spreadsheet Updated Field for certain condition
    //Cover_spreadsheet_updated_LM
    MandatoryCheckCoverSpreadsheetUpdatedField: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined" && formContext.getAttribute("rsa_coverspreadsheetupdated") !== null && formContext.getAttribute("rsa_coverspreadsheetupdated") !== "undefined" && formContext.getAttribute("rsa_opportunitystage") !== null && formContext.getAttribute("rsa_opportunitystage") !== "undefined") {
                var lineOfBusiness, salesStage;
                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    lineOfBusiness = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                }
                var coverSpreadSheetUpdated = formContext.getAttribute("rsa_coverspreadsheetupdated").getValue();
                if (formContext.getAttribute("rsa_opportunitystage").getValue() !== null) {
                    salesStage = formContext.getAttribute("rsa_opportunitystage").getValue()[0].name;
                }

                if ((lineOfBusiness === "New Business - Marine London" || lineOfBusiness === "Renewal - Marine London") && coverSpreadSheetUpdated === null && (salesStage === "Accepted" || salesStage === "Renewed")) {
                    //formContext.getControl("rsa_coverspreadsheetupdated").setNotification("Please enter the value as Opportunity Stage is Accepted / renewed", 200);
                    formContext.getAttribute("rsa_coverspreadsheetupdated").setRequiredLevel("required");
                }
                else {
                    //formContext.getControl("rsa_coverspreadsheetupdated").clearNotification(200);
                    formContext.getAttribute("rsa_coverspreadsheetupdated").setRequiredLevel("none");
                }
            }
        } catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "MandatoryCheckCoverSpreadsheetUpdatedField -" + err.message });
        }
    },
    //Author : Sagar Chaudhari
    //Date_Created : SEp 2022 
    //This function for associated Email Cases on subgrid

    /* Change Summary for GDPR Nov 2022 Release*/
    /* Last Modified By: Shreya Diwate*/
    /* Summary of Changes: Lock the GDPR Fields */

    /* - Function name - LockFields */
    LockFields: function (executionContext, recordId) {

        try {
            var rsa_anonymizationstatus;
            var formContext = executionContext.getFormContext();

            var req = new XMLHttpRequest();
            req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v9.1/rsa_extensionopportunities(" + recordId + ")?$select=rsa_anonymizationstatus", true);
            req.setRequestHeader("OData-MaxVersion", "4.0");
            req.setRequestHeader("OData-Version", "4.0");
            req.setRequestHeader("Accept", "application/json");
            req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
            req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            req.onreadystatechange = function () {
                if (this.readyState === 4) {
                    req.onreadystatechange = null;
                    if (this.status === 200) {
                        var result = JSON.parse(this.response);
                        var rsa_anonymizationstatus = result["rsa_anonymizationstatus"];

                        if (rsa_anonymizationstatus === 866760002) {

                            if (formContext.getAttribute("rsa_riskpostcode") !== null && formContext.getAttribute("rsa_riskpostcode") !== undefined)
                                formContext.getControl("rsa_riskpostcode").setDisabled(true);
                            if (formContext.getAttribute("rsa_riskname") !== null && formContext.getAttribute("rsa_riskname") !== undefined)
                                formContext.getControl("rsa_riskname").setDisabled(true);


                        }

                    } else {

                    }



                }
            };
            req.send();
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "GDPR -" + err.message });
        }
    },


    //Author : Raghav MLV 
    //Date_Created : Oct 2023 

    AddPresearchOutcome: function (executionContext) {

        try {

            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_outcomereasonid") !== null) {
                var attribute = formContext.getControl("rsa_outcomereasonid");
                attribute.addPreSearch(RSA.D365CRM.Opportunity.Main.FilterlookupOutcomereason);
            }


        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "Outcome Reaosn -" + err.message });
        }
    },


    //Ragahv MLV 


    //Author : Chandani Vaishnani
    //Date_Created : 16 July 2020
    //This Function Mandatory Check for Has current year EPI been checked&update Field for certain condition
    //Has_current_year_EPI_been_checked_upd_LM
    MandatoryCheckHasCurrentYearEPIbeenCheckedUpdateField: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined" && formContext.getAttribute("rsa_hascurrentyearepibeencheckedupdate") !== null && formContext.getAttribute("rsa_hascurrentyearepibeencheckedupdate") !== "undefined" && formContext.getAttribute("rsa_opportunitystage") !== null && formContext.getAttribute("rsa_opportunitystage") !== "undefined") {
                var lineOfBusiness, salesStage;
                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    lineOfBusiness = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                }
                var hasCurrentYearEPIBeenCheckedUpdate = formContext.getAttribute("rsa_hascurrentyearepibeencheckedupdate").getValue();
                if (formContext.getAttribute("rsa_opportunitystage").getValue() !== null) {
                    salesStage = formContext.getAttribute("rsa_opportunitystage").getValue()[0].name;
                }

                if (lineOfBusiness === "Renewal - Marine London" && hasCurrentYearEPIBeenCheckedUpdate === null && salesStage === "Renewed") {
                    //formContext.getControl("rsa_hascurrentyearepibeencheckedupdate").setNotification("Please enter the value as Opportunity stage is accepted or renewed", 201);
                    formContext.getAttribute("rsa_hascurrentyearepibeencheckedupdate").setRequiredLevel("required");
                }
                else {
                    //formContext.getControl("rsa_hascurrentyearepibeencheckedupdate").clearNotification(201);
                    formContext.getAttribute("rsa_hascurrentyearepibeencheckedupdate").setRequiredLevel("none");
                }
            }
        } catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "MandatoryCheckHasCurrentYearEPIbeenCheckedUpdateField -" + err.message });
        }
    },

    //Author : Chandani Vaishnani
    //Date_Created : 16 July 2020
    //This Function Mandatory Check for Input into rating tool? Field for certain condition
    //Input_into_rating_tool_Mand_LM
    MandatoryCheckInputIntoRatingToolField: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_inputintoratingtool") !== null && formContext.getAttribute("rsa_inputintoratingtool") !== "undefined" && formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined" && formContext.getAttribute("rsa_opportunitystage") !== null && formContext.getAttribute("rsa_opportunitystage") !== "undefined") {
                var lineOfBusiness, salesStage;
                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    lineOfBusiness = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                }
                var inputIntoRatingTool = formContext.getAttribute("rsa_inputintoratingtool").getValue();
                if (formContext.getAttribute("rsa_opportunitystage").getValue() !== null) {
                    salesStage = formContext.getAttribute("rsa_opportunitystage").getValue()[0].name;
                }

                if ((lineOfBusiness === "New Business - Marine London" || lineOfBusiness === "Renewal - Marine London") && inputIntoRatingTool === null && (salesStage === "Renewed" || salesStage === "Accepted")) {
                    //formContext.getControl("rsa_inputintoratingtool").setNotification("Please enter the value as Opportunity Stage is Accepted / renewed", 202);
                    formContext.getAttribute("rsa_inputintoratingtool").setRequiredLevel("required");
                }
                else {
                    //formContext.getControl("rsa_inputintoratingtool").clearNotification(202);
                    formContext.getAttribute("rsa_inputintoratingtool").setRequiredLevel("none");
                }
            }
        } catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "MandatoryCheckInputIntoRatingToolField -" + err.message });
        }
    },

    //Author : Chandani Vaishnani
    //Date_Created : 16 July 2020
    //This Function Mandatory Check for 100% Technical Price (PC) Field for certain condition
    //Marine_100_Technical_Price_PC_mandatory
    MandatoryCheck100TechnicalPricePCField: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined" && formContext.getAttribute("rsa_100technicalpricepc") !== null && formContext.getAttribute("rsa_100technicalpricepc") !== "undefined" && formContext.getAttribute("rsa_opportunitystage") !== null && formContext.getAttribute("rsa_opportunitystage") !== "undefined") {
                var recordTypeName, salesStage;
                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    recordTypeName = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                }
                var technicalPricePC100 = formContext.getAttribute("rsa_100technicalpricepc").getValue();
                if (formContext.getAttribute("rsa_opportunitystage").getValue() !== null) {
                    salesStage = formContext.getAttribute("rsa_opportunitystage").getValue()[0].name;
                }

                if ((recordTypeName.indexOf("Marine") !== -1) && technicalPricePC100 === null && (salesStage === "Renewed" || salesStage === "Accepted" || salesStage === "Extended" || salesStage === "Quoted")) {
                    //formContext.getControl("rsa_100technicalpricepc").setNotification("100% Technical Price (PC) : You must enter a value.", 203);
                    formContext.getAttribute("rsa_100technicalpricepc").setRequiredLevel("required");
                }
                else {
                    //formContext.getControl("rsa_100technicalpricepc").clearNotification(203);
                    formContext.getAttribute("rsa_100technicalpricepc").setRequiredLevel("none");
                }
            }
        } catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "MandatoryCheck100TechnicalPricePCField -" + err.message });
        }
    },

    //Author : Chandani Vaishnani
    //Date_Created : 16 July 2020
    //This Function Validation for Expiry Date Field for certain condition
    //MARINE_London_Expiry_Date_Mandatory
    ExpiryDateFieldValidation: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined" && formContext.getAttribute("rsa_expirydatemarine") !== null && formContext.getAttribute("rsa_expirydatemarine") !== "undefined" && formContext.getAttribute("rsa_closedate") !== null && formContext.getAttribute("rsa_closedate") !== "undefined" && formContext.getAttribute("rsa_opportunitystage") !== null && formContext.getAttribute("rsa_opportunitystage") !== "undefined") {
                var expiryDateMarineDate = new Date();
                var closeDateDate = new Date();
                var recordTypeName = null, salesStage = null;
                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    recordTypeName = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                }
                var expiryDateMarine = formContext.getAttribute("rsa_expirydatemarine").getValue();


                var closeDate = formContext.getAttribute("rsa_closedate").getValue();

                if (formContext.getAttribute("rsa_opportunitystage").getValue() !== null) {
                    salesStage = formContext.getAttribute("rsa_opportunitystage").getValue()[0].name;
                }


                if ((((recordTypeName.indexOf("Renewal") === -1) && (recordTypeName.indexOf("Regional") === -1)) && (recordTypeName.indexOf("Marine") !== -1) && (salesStage === "Quoted" || salesStage === "Accepted") && expiryDateMarine === null) || ((recordTypeName.indexOf("Renewal") !== -1) && (recordTypeName.indexOf("Marine") !== -1) && (salesStage === "Renewed") && expiryDateMarine === null) || ((recordTypeName.indexOf("Marine") !== -1) && (expiryDateMarine !== null) && (closeDate !== null) && (expiryDateMarine < closeDate))) {
                    formContext.getControl("rsa_expirydatemarine").setNotification("Expiry Date: Expiry Date value cannot be blank, and cannot be less than Renewal Date.", 204);
                }
                else {
                    formContext.getControl("rsa_expirydatemarine").clearNotification(204);
                }
            }
        } catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "ExpiryDateFieldValidation -" + err.message });
        }
    },

    //Author : Chandani Vaishnani
    //Date_Created : 16 July 2020
    //This Function Mandatory Check for Description Field for certain condition
    //MARINE_Opportunity_Description_Required
    MandatoryCheckDescriptionField: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined" && formContext.getAttribute("description") !== null && formContext.getAttribute("description") !== "undefined") {
                var recordTypeName;
                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    recordTypeName = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                }
                var description = formContext.getAttribute("description").getValue();

                if ((recordTypeName.indexOf("Marine") !== -1) && ((recordTypeName.indexOf("London") !== -1) || (recordTypeName.indexOf("Europe") !== -1)) && description === null) {
                    //formContext.getControl("description").setNotification("Opportunity Description: You must enter a value.", 205);
                    formContext.getAttribute("description").setRequiredLevel("required");
                }
                else {
                    //formContext.getControl("description").clearNotification(205);
                    formContext.getAttribute("description").setRequiredLevel("none");
                }
            }
        } catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "MandatoryCheckDescriptionField -" + err.message });
        }
    },

    //Author : Chandani Vaishnani
    //Date_Created : 17 July 2020
    //This Function Mandatory Check for Policy System Field for certain condition
    //Marine_Policy_System_mandatory
    MandatoryCheckPolicySystemField: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined" && formContext.getAttribute("rsa_policynumber") !== null && formContext.getAttribute("rsa_policynumber") !== "undefined" && formContext.getAttribute("rsa_policysystem") !== null && formContext.getAttribute("rsa_policysystem") !== "undefined") {
                var recordTypeName;
                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    recordTypeName = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                }
                var policyNumbers = formContext.getAttribute("rsa_policynumber").getValue();
                var policySystem = formContext.getAttribute("rsa_policysystem").getValue();

                if (((recordTypeName.indexOf("Marine") !== -1) && (recordTypeName.indexOf("Renewal") !== -1) && policyNumbers !== null && policySystem === null) || ((recordTypeName.indexOf("Renewal") === -1) && (recordTypeName.indexOf("Marine") !== -1) && policyNumbers !== null && policySystem === null)) {
                    //formContext.getControl("rsa_policysystem").setNotification("Policy System : Please select a value.", 206);
                    formContext.getAttribute("rsa_policysystem").setRequiredLevel("required");
                }
                else {
                    //formContext.getControl("rsa_policysystem").clearNotification(206);
                    formContext.getAttribute("rsa_policysystem").setRequiredLevel("none");
                }
            }

        } catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "MandatoryCheckPolicySystemField -" + err.message });
        }
    },

    //Author : Chandani Vaishnani
    //Date_Created : 17 July 2020
    //This Function Mandatory Check for Date Terms Agreed Field for certain condition
    //Marine_Quote_Contract_Certainty_Required
    MandatoryCheckDateTermsAgreedField: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined" && formContext.getAttribute("rsa_quotecontractcertainty") !== null && formContext.getAttribute("rsa_quotecontractcertainty") !== "undefined" && formContext.getAttribute("rsa_opportunitystage") !== null && formContext.getAttribute("rsa_opportunitystage") !== "undefined") {
                var recordTypeName, salesStage;
                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    recordTypeName = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                }
                var dateTermsAgreed = formContext.getAttribute("rsa_quotecontractcertainty").getValue();
                if (formContext.getAttribute("rsa_opportunitystage").getValue() !== null) {
                    salesStage = formContext.getAttribute("rsa_opportunitystage").getValue()[0].name;
                }

                if (dateTermsAgreed === null && (salesStage === "Accepetd" || salesStage === "Renewed") && (recordTypeName.indexOf("New") !== -1 || recordTypeName.indexOf("Renewal") !== -1) && recordTypeName.indexOf("Marine") !== -1 && recordTypeName.indexOf("Regional") !== -1) {
                    //formContext.getControl("rsa_datetermsagreed").setNotification("Date Terms Agreed : You must enter a value.", 207);
                    formContext.getAttribute("rsa_quotecontractcertainty").setRequiredLevel("required");
                }
                else {
                    //formContext.getControl("rsa_datetermsagreed").clearNotification(207);
                    formContext.getAttribute("rsa_quotecontractcertainty").setRequiredLevel("none");
                }
            }
        } catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "MandatoryCheckDateTermsAgreedField -" + err.message });
        }
    },

    //Author : Chandani Vaishnani
    //Date_Created : 17 July 2020
    //This Function checks Validation for Create Opportunity For Next Year If NTU for certain condition
    //Marine_Quote_Dont_Quote
    ValidationCreateOpportunityForNextYearIfNTUField: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_createopportunityfornextyearifntu") !== null && formContext.getAttribute("rsa_createopportunityfornextyearifntu") !== "undefined" && formContext.getAttribute("rsa_nonrenewable") !== null && formContext.getAttribute("rsa_nonrenewable") !== "undefined" && formContext.getAttribute("rsa_donotquote") !== null && formContext.getAttribute("rsa_donotquote") !== "undefined" && formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined") {
                var createOpportunityForNextYearIfNTU = formContext.getAttribute("rsa_createopportunityfornextyearifntu").getValue();
                var nonRenewable = formContext.getAttribute("rsa_nonrenewable").getValue();
                var doNotQuote = formContext.getAttribute("rsa_donotquote").getValue();
                var recordTypeName;
                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    recordTypeName = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                }

                if (((createOpportunityForNextYearIfNTU === true && nonRenewable === true) || (createOpportunityForNextYearIfNTU === true && doNotQuote === true)) && recordTypeName.indexOf('Marine') !== -1) {
                    formContext.getControl("rsa_createopportunityfornextyearifntu").setNotification("'Create Opportunity For Next Year If NTU' field is ticked but the Opportunity is Non-Renewable or marked as 'Do Not Quote", 208);
                }
                else {
                    formContext.getControl("rsa_createopportunityfornextyearifntu").clearNotification(208);
                }
            }
        } catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "ValidationCreateOpportunityForNextYearIfNTUField -" + err.message });
        }
    },

    //Author : Chandani Vaishnani
    //Date_Created : 17 July 2020
    //This Function Mandatory Check for Total GWP 100% (PC) Field for certain condition
    //also for rsa quoted premium mandatory check as  0 values are prepopulated.so a simple user alert is given
    //Marine_Total_GWP_100_PC_mandatory
    MandatoryCheckTotalGWP100PCField: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_opportunitystage") !== null && formContext.getAttribute("rsa_opportunitystage") !== "undefined" && formContext.getAttribute("rsa_totalgwp100pc") !== null && formContext.getAttribute("rsa_totalgwp100pc") !== "undefined" && formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined" && formContext.getAttribute("rsa_rsaquotedpremium") !== null && formContext.getAttribute("rsa_rsaquotedpremium") !== "undefined") {
                var stage;
                if (formContext.getAttribute("rsa_opportunitystage").getValue() !== null) {
                    stage = formContext.getAttribute("rsa_opportunitystage").getValue()[0].name;
                }
                var quotedPremium;
                if (formContext.getAttribute("rsa_opportunitystage").getValue() !== null) { quotedPremium = formContext.getAttribute("rsa_rsaquotedpremium").getValue(); }
                var totalGWP100PC = formContext.getAttribute("rsa_totalgwp100pc").getValue();
                var recordTypeName;
                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    recordTypeName = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                }
                //Quoted:866760005, Accepted:866760019, Extended :866760052, Renewed: 866760022, Indication:866760011
                if (((stage === "Quoted" || stage === "Accepted" || stage === "Renewed" || stage === "Extended") && recordTypeName.indexOf('Marine') !== -1) || (stage === "Indication" && recordTypeName.indexOf('Marine') !== -1 && recordTypeName.indexOf('Europe') !== -1)) {
                    //formContext.getControl("rsa_totalgwp100pc").setNotification("Print Total GWP 100% (PC) : You must enter a value.", 209);
                    formContext.getAttribute("rsa_totalgwp100pc").setRequiredLevel("required");
                    if (totalGWP100PC === 0) {
                        alert("Please confirm the values in below fields \n" + "Total GWP 100% (PC)")
                    }
                }
                else {
                    //formContext.getControl("rsa_totalgwp100pc").clearNotification(209);
                    formContext.getAttribute("rsa_totalgwp100pc").setRequiredLevel("none");
                }

            }



        }

        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "MandatoryCheckTotalGWP100PCField -" + err.message });
        }
    },

    QuotedPremiumAlert: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_opportunitystage") !== null && formContext.getAttribute("rsa_opportunitystage") !== "undefined" && formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined" && formContext.getAttribute("rsa_rsaquotedpremium") !== "undefined" && formContext.getAttribute("rsa_rsaquotedpremium") !== null) {
                var stage;
                if (formContext.getAttribute("rsa_opportunitystage").getValue() !== null) {
                    stage = formContext.getAttribute("rsa_opportunitystage").getValue()[0].name;
                }
                var quotedPremium;
                if (formContext.getAttribute("rsa_rsaquotedpremium").getValue() !== null) { quotedPremium = formContext.getAttribute("rsa_rsaquotedpremium").getValue(); }

                var recordTypeName;
                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    recordTypeName = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                }


                if ((recordTypeName !== "New Business - Real Estate" && recordTypeName !== "Renewal - Real Estate" && recordTypeName !== "GSL - New Business" && recordTypeName !== "GSL - Renewal" && recordTypeName !== "New Business - Marine Europe" && recordTypeName !== "New Business - Marine London" && recordTypeName !== "New Business - Marine Regional" && recordTypeName !== "Renewal - Marine Europe" && recordTypeName !== "Renewal - Marine London" && recordTypeName !== "Renewal - Marine Regional")
                    && (quotedPremium === null || quotedPremium === 0) && (stage === "Quoted" || stage === "Accepted" || stage === "Not Taken Up")) {
                    formContext.getAttribute("rsa_rsaquotedpremium").setRequiredLevel("required");
                    if (quotedPremium == 0) {
                        alert("Please confirm the values in below fields \n" + "RSA Quoted Premium")
                    }
                }
                else { formContext.getAttribute("rsa_rsaquotedpremium").setRequiredLevel("none"); }
            }

            //RSA.D365CRM.Opportunity.Main.UpdatePPPMRequirement(executionContext);
        }

        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "QuotedPremiumAlert -" + err.message });
        }
    },

    commission_mandatory_profin: function (executionContext) {

        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_opportunitystage") !== null && formContext.getAttribute("rsa_opportunitystage") !== "undefined" && formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined" && formContext.getAttribute("rsa_commission") !== "undefined" && formContext.getAttribute("rsa_commission") !== null && formContext.getAttribute("rsa_pandlid") !== "undefined" && formContext.getAttribute("rsa_pandlid") !== null) {

                var pandl;
                if (formContext.getAttribute("rsa_pandlid").getValue() !== null) {
                    pandl = formContext.getAttribute("rsa_pandlid").getValue()[0].name;
                }
                var commission;
                if (formContext.getAttribute("rsa_commission").getValue() !== null) { commission = formContext.getAttribute("rsa_commission").getValue(); }

                var stage;
                if (formContext.getAttribute("rsa_opportunitystage").getValue() !== null) {
                    stage = formContext.getAttribute("rsa_opportunitystage").getValue()[0].name;
                }

                if ((commission === null || commission === 0) && (stage === "Accepted" || stage === "Renewed") && pandl === "GSL - Profin") {
                    formContext.getAttribute("rsa_commission").setRequiredLevel("required");
                    if (commission == 0) {
                        alert("Please confirm the values in below fields \n" + "Commission")
                    }
                }
                else { formContext.getAttribute("rsa_commission").setRequiredLevel("none"); }
            }
        }

        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "commission_mandatory_profin -" + err.message });
        }
    },


    //Author : Sumegh Dhole
    //Date_Created : 31 July 2020
    //This Function Mandatory Check for policy features value for the Marine London LOB
    //Policy_features__c
    PolicyFeaturesMandLMField: function (executionContext) {

        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_opportunitystage") !== null && formContext.getAttribute("rsa_opportunitystage") !== "undefined" && formContext.getAttribute("rsa_policyfeatures") !== null && formContext.getAttribute("rsa_policyfeatures") !== "undefined" && formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined") {
                var stage;
                if (formContext.getAttribute("rsa_opportunitystage").getValue() !== null) {
                    stage = formContext.getAttribute("rsa_opportunitystage").getValue()[0].name;
                }
                var policyFeaturesMand = formContext.getAttribute("rsa_policyfeatures").getValue();
                var recordTypeName;
                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    recordTypeName = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                }
                //Quoted:866760005, Accepted:866760019, Extended :866760052, Renewed: 866760022, Indication:866760011
                if (policyFeaturesMand === null && (stage === "Accepted" || stage === "Renewed") && recordTypeName.toLowerCase().indexOf('london') !== -1) {
                    formContext.getAttribute("rsa_policyfeatures").setRequiredLevel("required");
                }
                else {
                    formContext.getAttribute("rsa_policyfeatures").setRequiredLevel("none");
                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "PolicyFeaturesMandLMField -" + err.message });
        }
    },

    //Author : Chandani Vaishnani
    //Date_Created : 22 July 2020
    //This Function Mandatory Check Policy CC Reason for Failure field for certain condition
    //Enter_Reason_for_Policy_CC_Failure
    MandatoryCheckPolicyCCReasonforFailure: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_policycontractcertainty").getValue() !== null && formContext.getAttribute("rsa_policycontractcertainty") !== null && formContext.getAttribute("rsa_policycontractcertainty") !== "undefined" && formContext.getAttribute("rsa_closedate") !== null && formContext.getAttribute("rsa_closedate") !== "undefined" && formContext.getAttribute("rsa_opportunitystage") !== null && formContext.getAttribute("rsa_opportunitystage") !== "undefined" && formContext.getAttribute("rsa_policyccreasonforfailure") !== null && formContext.getAttribute("rsa_policyccreasonforfailure") !== "undefined" && formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined") {
                var stage = null, recordTypeName = null;
                var policyContractCertainty = new Date();
                var closeDate = new Date();
                var newDate = new Date();
                if (formContext.getAttribute("rsa_policycontractcertainty").getValue() !== null) {
                    policyContractCertainty = new Date(formContext.getAttribute("rsa_policycontractcertainty").getValue());
                }
                if (formContext.getAttribute("rsa_closedate").getValue() !== null) {
                    closeDate = new Date(formContext.getAttribute("rsa_closedate").getValue());

                    newDate = new Date(
                        closeDate.getFullYear(),
                        closeDate.getMonth(),
                        closeDate.getDate() + 20
                    );
                }

                if (formContext.getAttribute("rsa_opportunitystage").getValue() !== null) {
                    stage = formContext.getAttribute("rsa_opportunitystage").getValue()[0].name;
                }
                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    recordTypeName = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                }
                var policyCCReasonforFailures = formContext.getAttribute("rsa_policyccreasonforfailure").getValue();

                //Modified on:25/05/2022, Modified By: Lavanya CP, Updated below code line for CR-1225 (stage === "Accepted" || stage === "Renewed")
                if (formContext.getAttribute("rsa_policycontractcertainty").getValue() !== null && formContext.getAttribute("rsa_closedate").getValue() !== null && (policyContractCertainty >= newDate) && (stage === "Accepted" || stage === "Renewed") && policyCCReasonforFailures === null && recordTypeName.indexOf('Marine') !== -1) {


                    //formContext.getControl("rsa_policyccreasonforfailure").setNotification("Policy CC Reason for Failure : Enter the reason for failure.", 101);
                    formContext.getAttribute("rsa_policyccreasonforfailure").setRequiredLevel("required");
                }
                else {
                    //formContext.getControl("rsa_policyccreasonforfailure").clearNotification(101);
                    formContext.getAttribute("rsa_policyccreasonforfailure").setRequiredLevel("none");
                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "MandatoryCheckPolicyCCReasonforFailure -" + err.message });
        }
    },

    //Author : Chandani Vaishnani
    //Date_Created : 22 July 2020
    //This Function Mandatory Check Quote CC Reason for Failure field for certain condition
    //Enter_Reason_for_Quote_CC_Failure
    MandatoryCheckQuoteCCReasonforFailure: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_quotecontractcertainty") !== null && formContext.getAttribute("rsa_quotecontractcertainty") !== "undefined" && formContext.getAttribute("rsa_closedate") !== null && formContext.getAttribute("rsa_closedate") !== "undefined" && formContext.getAttribute("rsa_quoteccreasonforfailure") !== null && formContext.getAttribute("rsa_quoteccreasonforfailure") !== "undefined" && formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined") {
                var recordTypeName = null;
                //var quoteContractCertainty = new Date();
                // var closeDate = new Date();
                if (formContext.getAttribute("rsa_quotecontractcertainty").getValue() !== null) {
                    var quoteContractCertainty = formContext.getAttribute("rsa_quotecontractcertainty").getValue();
                }
                if (formContext.getAttribute("rsa_closedate").getValue() !== null) {
                    var closeDate = (formContext.getAttribute("rsa_closedate").getValue());
                }


                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    recordTypeName = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                }
                var quoteCCReasonforFailure = formContext.getAttribute("rsa_quoteccreasonforfailure").getValue();

                if ((quoteContractCertainty > closeDate) && quoteCCReasonforFailure === null && recordTypeName.indexOf('Marine') !== -1) {
                    //formContext.getControl("rsa_quoteccreasonforfailure").setNotification("Quote CC Reason for Failure : Enter the reason for failure.", 101);
                    formContext.getAttribute("rsa_quoteccreasonforfailure").setRequiredLevel("required");
                }
                else {
                    //formContext.getControl("rsa_quoteccreasonforfailure").clearNotification(101);
                    formContext.getAttribute("rsa_quoteccreasonforfailure").setRequiredLevel("none");
                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "MandatoryCheckQuoteCCReasonforFailure -" + err.message });
        }
    },

    //Author : Chandani Vaishnani
    //Date_Created : 24 July 2020
    //This Function Mandatory Check AAD record field for certain condition
    //AAD_record_LM
    MandatoryCheckAADRecord: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_aadrecord") !== null && formContext.getAttribute("rsa_aadrecord") !== "undefined" && formContext.getAttribute("rsa_opportunitystage") !== null && formContext.getAttribute("rsa_opportunitystage") !== "undefined" && formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined") {
                var lineOfBusiness = null, stage = null;

                if (formContext.getAttribute("rsa_opportunitystage").getValue() !== null) {
                    stage = formContext.getAttribute("rsa_opportunitystage").getValue()[0].name;
                }

                var aADRecord = formContext.getAttribute("rsa_aadrecord").getValue();

                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    lineOfBusiness = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                }
                //Line of Business = New_Business_Marine_london :(New Business - Marine London), Renewal_Marine_London: (F5901D7D-B1C1-EA11-A812-000D3AF010A3)
                //Stage = Accepted, Renewed
                if ((lineOfBusiness === "New Business - Marine London" || lineOfBusiness === "Renewal - Marine London") && aADRecord === null && (stage === "Accepted" || stage === "Renewed")) {
                    formContext.getAttribute("rsa_aadrecord").setRequiredLevel("required");
                }
                else {
                    formContext.getAttribute("rsa_aadrecord").setRequiredLevel("none");
                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "MandatoryCheckAADRecord -" + err.message });
        }
    },

    //Author : Chandani Vaishnani
    //Date_Created : 24 July 2020
    //This Function Mandatory Check Are all Endts present? field for certain condition
    //Are_all_Endts_present_mand_LM
    MandatoryCheckAreAllEndtsPresent: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_areallendtspresent") !== null && formContext.getAttribute("rsa_areallendtspresent") !== "undefined" && formContext.getAttribute("rsa_opportunitystage") !== null && formContext.getAttribute("rsa_opportunitystage") !== "undefined" && formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined") {
                var lineOfBusiness = null, stage = null;

                if (formContext.getAttribute("rsa_opportunitystage").getValue() !== null) {
                    stage = formContext.getAttribute("rsa_opportunitystage").getValue()[0].name;
                }
                var areAllEndtsPresent = formContext.getAttribute("rsa_areallendtspresent").getValue();

                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    //lineOfBusiness = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                    lineOfBusiness = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                }
                //Line of Business = New_Business_Marine_london :(New Business - Marine London), Renewal_Marine_London: (F5901D7D-B1C1-EA11-A812-000D3AF010A3)
                //Stage = Accepted, Renewed
                if ((lineOfBusiness === "New Business - Marine London" || lineOfBusiness === "Renewal - Marine London") && areAllEndtsPresent === null && (stage === "Accepted" || stage === "Renewed")) {
                    formContext.getAttribute("rsa_areallendtspresent").setRequiredLevel("required");
                }
                else {
                    formContext.getAttribute("rsa_areallendtspresent").setRequiredLevel("none");
                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "MandatoryCheckAreAllEndtsPresent -" + err.message });
        }
    },

    //Author : Chandani Vaishnani
    //Date_Created : 24 July 2020
    //This Function Mandatory Check Broker expectations & discussion history field for certain condition
    //Broker_Exp_Mandatory_LM
    MandatoryCheckBrokerExpectationsDiscussionHistory: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_brokerexpectationsdiscussionhistory") !== null && formContext.getAttribute("rsa_brokerexpectationsdiscussionhistory") !== "undefined" && formContext.getAttribute("rsa_opportunitystage") !== null && formContext.getAttribute("rsa_opportunitystage") !== "undefined" && formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined") {
                var lineOfBusiness = null, stage = null;

                if (formContext.getAttribute("rsa_opportunitystage").getValue() !== null) {
                    stage = formContext.getAttribute("rsa_opportunitystage").getValue()[0].name;
                }
                var brokerExpectationsDiscussionHistory = formContext.getAttribute("rsa_brokerexpectationsdiscussionhistory").getValue();

                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    lineOfBusiness = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                }
                //Line of Business = New_Business_Marine_london :(New Business - Marine London), Renewal_Marine_London: (F5901D7D-B1C1-EA11-A812-000D3AF010A3)
                //Stage = Accepted, Renewed
                if ((lineOfBusiness === "New Business - Marine London" || lineOfBusiness === "Renewal - Marine London") && brokerExpectationsDiscussionHistory === null && (stage === "Accepted" || stage === "Renewed")) {
                    formContext.getAttribute("rsa_brokerexpectationsdiscussionhistory").setRequiredLevel("required");
                }
                else {
                    formContext.getAttribute("rsa_brokerexpectationsdiscussionhistory").setRequiredLevel("none");
                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "MandatoryCheckBrokerExpectationsDiscussionHistory -" + err.message });
        }
    },

    //Author : Chandani Vaishnani
    //Date_Created : 24 July 2020
    //This Function Mandatory Check Exposures Applicable field for certain condition
    //Exposures_Applicable
    MandatoryCheckExposuresApplicable: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_exposures") !== null && formContext.getAttribute("rsa_exposures") !== "undefined" && formContext.getAttribute("rsa_opportunitystage") !== null && formContext.getAttribute("rsa_opportunitystage") !== "undefined" && formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined") {
                var lineOfBusiness = null, stage = null;

                if (formContext.getAttribute("rsa_opportunitystage").getValue() !== null) {
                    stage = formContext.getAttribute("rsa_opportunitystage").getValue()[0].name;
                }
                var exposures = formContext.getAttribute("rsa_exposures").getValue();

                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    //lineOfBusiness = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                    lineOfBusiness = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                }
                //Line of Business = New_Business_Marine_london :(New Business - Marine London), Renewal_Marine_London: (F5901D7D-B1C1-EA11-A812-000D3AF010A3)
                //Stage = Accepted, Renewed
                if ((lineOfBusiness === "New Business - Marine London" || lineOfBusiness === "Renewal - Marine London") && exposures === null && (stage === "Accepted" || stage === "Renewed")) {
                    formContext.getAttribute("rsa_exposures").setRequiredLevel("required");
                }
                else {
                    formContext.getAttribute("rsa_exposures").setRequiredLevel("none");
                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "MandatoryCheckExposuresApplicable -" + err.message });
        }
    },

    //Author : Chandani Vaishnani
    //Date_Created : 24 July 2020
    //This Function Mandatory Check HRC field for certain condition
    //HRC_Mand_LM
    MandatoryCheckHRC: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_hrc") !== null && formContext.getAttribute("rsa_hrc") !== "undefined" && formContext.getAttribute("rsa_opportunitystage") !== null && formContext.getAttribute("rsa_opportunitystage") !== "undefined" && formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined") {
                var lineOfBusiness = null, stage = null;

                if (formContext.getAttribute("rsa_opportunitystage").getValue() !== null) {
                    stage = formContext.getAttribute("rsa_opportunitystage").getValue()[0].name;
                }
                var hrc = formContext.getAttribute("rsa_hrc").getValue();

                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    lineOfBusiness = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                }
                //Line of Business = New_Business_Marine_london :(New Business - Marine London), Renewal_Marine_London: (F5901D7D-B1C1-EA11-A812-000D3AF010A3)
                //Stage = Accepted, Renewed
                if ((lineOfBusiness === "New Business - Marine London" || lineOfBusiness === "Renewal - Marine London") && hrc === null && (stage === "Accepted" || stage === "Renewed")) {
                    formContext.getAttribute("rsa_hrc").setRequiredLevel("required");
                }
                else {
                    formContext.getAttribute("rsa_hrc").setRequiredLevel("none");
                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "MandatoryCheckHRC -" + err.message });
        }
    },

    //Author : Chandani Vaishnani
    //Date_Created : 24 July 2020
    //This Function Mandatory Check IPT field for certain condition
    //IPT_Validation_rule
    MandatoryCheckIPT: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_ipt") !== null && formContext.getAttribute("rsa_ipt") !== "undefined" && formContext.getAttribute("rsa_synergybranch") !== null && formContext.getAttribute("rsa_synergybranch") !== "undefined" && formContext.getAttribute("rsa_opportunitystage") !== null && formContext.getAttribute("rsa_opportunitystage") !== "undefined" && formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined") {
                var lineOfBusiness = null, stage = null;

                if (formContext.getAttribute("rsa_opportunitystage").getValue() !== null) {
                    stage = formContext.getAttribute("rsa_opportunitystage").getValue()[0].name;
                }
                var ipt = formContext.getAttribute("rsa_ipt").getValue();
                var synergyBranch = formContext.getAttribute("rsa_synergybranch").getValue();
                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    lineOfBusiness = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                }
                //Line of Business = New_Business_Marine_london :(New Business - Marine London), Renewal_Marine_London: (F5901D7D-B1C1-EA11-A812-000D3AF010A3)
                //Stage = Accepted, Renewed
                if ((lineOfBusiness === "New Business - Marine London" || lineOfBusiness === "Renewal - Marine London") && synergyBranch === 866760002 && ipt === null && (stage === "Accepted" || stage === "Renewed")) {
                    formContext.getAttribute("rsa_ipt").setRequiredLevel("required");
                }
                else {
                    formContext.getAttribute("rsa_ipt").setRequiredLevel("none");
                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "MandatoryCheckIPT -" + err.message });
        }
    },

    //Author : Chandani Vaishnani
    //Date_Created : 27 July 2020
    //This Function Mandatory Check Is expiring EPI accurate field for certain condition
    //Is_expiring_EPI_accurate_LM
    MandatoryCheckIsExpiringEPIAccurate: function (executionContext) {
        try {

            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_isexpiringepiaccurate") !== null && formContext.getAttribute("rsa_isexpiringepiaccurate") !== "undefined" && formContext.getAttribute("rsa_opportunitystage") !== null && formContext.getAttribute("rsa_opportunitystage") !== "undefined" && formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined") {
                var lineOfBusiness = null, stage = null;

                if (formContext.getAttribute("rsa_opportunitystage").getValue() !== null) {
                    stage = formContext.getAttribute("rsa_opportunitystage").getValue()[0].name;
                }
                var isExpiringEPIAccurate = formContext.getAttribute("rsa_isexpiringepiaccurate").getValue();

                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    lineOfBusiness = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                }
                //Line of Business = Renewal_Marine_London: (Renewal - Marine London)
                //Stage =  Renewed
                if (lineOfBusiness === "Renewal - Marine London" && isExpiringEPIAccurate === null && stage === "Renewed") {
                    formContext.getAttribute("rsa_isexpiringepiaccurate").setRequiredLevel("required");
                }
                else {
                    formContext.getAttribute("rsa_isexpiringepiaccurate").setRequiredLevel("none");
                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "MandatoryCheckIsExpiringEPIAccurate -" + err.message });
        }
    },

    //Author : Chandani Vaishnani
    //Date_Created : 27 July 2020
    //This Function Mandatory Check Leader(s) field for certain condition
    //Leader_Mandatory_Accepted
    MandatoryCheckLeader: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_leader") !== null && formContext.getAttribute("rsa_leader") !== "undefined" && formContext.getAttribute("rsa_opportunitystage") !== null && formContext.getAttribute("rsa_opportunitystage") !== "undefined" && formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined") {
                var lineOfBusiness = null, stage = null;

                if (formContext.getAttribute("rsa_opportunitystage").getValue() !== null) {
                    stage = formContext.getAttribute("rsa_opportunitystage").getValue()[0].name;
                }
                var leader = formContext.getAttribute("rsa_leader").getValue();

                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    lineOfBusiness = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                }
                //Line of Business = New_Business_Marine_london :(New Business - Marine London)
                //Stage =  Renewed
                if (lineOfBusiness === "New Business - Marine London" && leader === null && stage === "Accepted") {
                    formContext.getAttribute("rsa_leader").setRequiredLevel("required");
                }
                else {
                    formContext.getAttribute("rsa_leader").setRequiredLevel("none");
                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "MandatoryCheckLeader -" + err.message });
        }
    },


    //Author : Nida Mulla
    //Date_Created: 29 July 2020
    //This Function Mandatory Check Leader(s) field for certain condition
    //Leader_Mandatory_Renewed
    MandatoryCheckLeaderForRenewal: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_leader") !== null && formContext.getAttribute("rsa_leader") !== "undefined" && formContext.getAttribute("rsa_opportunitystage") !== null && formContext.getAttribute("rsa_opportunitystage") !== "undefined" && formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined") {
                var lineOfBusiness = null, stage = null;

                if (formContext.getAttribute("rsa_opportunitystage").getValue() !== null) {
                    stage = formContext.getAttribute("rsa_opportunitystage").getValue()[0].name;
                }
                var leader = formContext.getAttribute("rsa_leader").getValue();

                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    lineOfBusiness = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                }
                //Line of Business = Renewal_Marine_London :(f5901d7d-b1c1-ea11-a812-000d3af010a3)
                //Stage =  Renewed
                if (lineOfBusiness === "Renewal - Marine London" && leader === null && stage === "Renewed") {
                    formContext.getAttribute("rsa_leader").setRequiredLevel("required");
                }
                else {
                    formContext.getAttribute("rsa_leader").setRequiredLevel("none");
                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "MandatoryCheckLeaderForRenewal -" + err.message });
        }
    },

    //Author : Nida Mulla
    //Date_Created: 29 July 2020
    //This Function Mandatory Check LexisNexis field for certain condition
    //Lexis_Nexis_Mand_LM


    MandatoryCheckLexisNexis: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_lexisnexis") !== null && formContext.getAttribute("rsa_lexisnexis") !== "undefined" && formContext.getAttribute("rsa_opportunitystage") !== null && formContext.getAttribute("rsa_opportunitystage") !== "undefined" && formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined") {
                var lineOfBusiness = null, stage = null;

                if (formContext.getAttribute("rsa_opportunitystage").getValue() !== null) {
                    stage = formContext.getAttribute("rsa_opportunitystage").getValue()[0].name;
                }
                var lexisNexis = formContext.getAttribute("rsa_lexisnexis").getValue();

                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    lineOfBusiness = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                }
                //Line of Business = New_Business_Marine_london :(New Business - Marine London);Renewal_Marine_London :(f5901d7d-b1c1-ea11-a812-000d3af010a3)
                //Stage =  Renewed
                if ((lineOfBusiness === "New Business - Marine London" || lineOfBusiness === "Renewal - Marine London") && (stage === "Accepted" || stage === "Renewed") && lexisNexis === null) {
                    formContext.getAttribute("rsa_lexisnexis").setRequiredLevel("required");
                }
                else {
                    formContext.getAttribute("rsa_lexisnexis").setRequiredLevel("none");
                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "MandatoryCheckLexisNexis -" + err.message });
        }
    },



    ValidateMultiplePolicyNumberNeeded: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined") {
                var lineOfBusiness = null, stage = null;
                var policyNumbers = formContext.getAttribute("rsa_policynumbers");
                //var policyNumber = formContext.getAttribute("rsa_policynumber");
                var policySystem = formContext.getAttribute("rsa_policysystem");
                var coverSchema = formContext.getAttribute("rsa_schemes");


                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    lineOfBusiness = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                    //Line of Business = New Business - Marine Regional :(New Business - Marine Regional)New Business - Marine Regional
                    if (lineOfBusiness === "New Business - Marine Regional" && policySystem !== null && policySystem !== "undefined" && policySystem.getValue() !== null
                        && policyNumbers !== null && policyNumbers !== "undefined") {
                        if (policyNumbers.getValue() === null) {

                            formContext.getAttribute("rsa_policynumbers").setRequiredLevel("required");
                            formContext.getControl("rsa_policynumbers").setNotification("You must enter a value.", 1111);
                        }
                        else {
                            formContext.getAttribute("rsa_policynumbers").setRequiredLevel("none");
                            formContext.getControl("rsa_policynumbers").clearNotification(1111);
                        }
                    }
                    //Line of Business = New Business - Marine Europe :(New Business - Marine Europe)
                    if (lineOfBusiness === "New Business - Marine Europe" && policySystem !== null && policySystem !== "undefined" && policySystem.getValue() !== null
                        && policyNumbers !== null && policyNumbers !== "undefined" && coverSchema !== null && coverSchema !== "undefined") {
                        if (policyNumbers.getValue() === null && coverSchema.getValue() === 100000000) {
                            formContext.getAttribute("rsa_policynumbers").setRequiredLevel("required");
                            formContext.getControl("rsa_policynumbers").setNotification("You must enter a value.", 1111);
                        }
                        else {
                            formContext.getAttribute("rsa_policynumbers").setRequiredLevel("none");
                            formContext.getControl("rsa_policynumbers").clearNotification(1111);
                        }
                    }
                    //Line of Business = New Business - Marine London :(New Business - Marine London)
                    if (lineOfBusiness === "New Business - Marine London" && policyNumbers !== null && policyNumbers !== "undefined"
                        && policySystem !== null && policySystem !== "undefined") {
                        if (policyNumbers.getValue() === null && policySystem.getValue() !== null
                            && coverSchema !== null && coverSchema !== "undefined" && coverSchema.getValue() === 100000000) {
                            formContext.getAttribute("rsa_policynumbers").setRequiredLevel("required");
                            formContext.getControl("rsa_policynumbers").setNotification("You must enter a value.", 1111);
                        }
                        else {
                            formContext.getAttribute("rsa_policynumbers").setRequiredLevel("none");
                            formContext.getControl("rsa_policynumbers").clearNotification(1111);
                        }
                    }
                }
            }
        }

        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "ValidateMultiplePolicyNumberNeeded -" + err.message });
        }
    },


    CalculateRSAPremiumGoCPC: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();

            if (formContext.getAttribute("rsa_totalgwp100pc") !== null && formContext.getAttribute("rsa_totalgwp100pc") !== "undefined"
                && formContext.getAttribute("rsa_rsapremiumgocpc") !== null && formContext.getAttribute("rsa_rsapremiumgocpc") !== "undefined"
                && formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined") {

                var lineOfBusiness = null;

                var totalGWP100Pc = formContext.getAttribute("rsa_totalgwp100pc").getValue();

                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    lineOfBusiness = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                }
                //Line of Business = New Business - Marine Regional :(New Business - Marine Regional)New Business - Marine Regional

                if (lineOfBusiness === "New Business - Marine Regional") {
                    formContext.getAttribute("rsa_rsapremiumgocpc").setValue(totalGWP100Pc);
                }
                else {
                    //formContext.getAttribute("rsa_rsapremiumgocpc").setValue();
                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "CalculateRSAPremiumGoCPC-" + err.message });
        }
    },


    //Author : Pooja Raje
    //Date_Created : 04 July 2020
    //This Function for Quote Number can only contain alphanumeric characters
    //Quote_Number_field

    QuoteNumber: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined" && formContext.getAttribute("rsa_quotenumber") !== null && formContext.getAttribute("rsa_quotenumber") !== "undefined" && formContext.getAttribute("rsa_100benchmarkpremium_dc") !== null && formContext.getAttribute("rsa_quotenumber") !== null) {

                var lineOfBusiness = null;

                var quotenumber = formContext.getAttribute("rsa_quotenumber").getValue();

                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    lineOfBusiness = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                }
                //Line of Business = New Business - Real Estate{New Business - Real Estate}, Renewal - Real Estate{Renewal - Real Estate}
                var pattern = /[a-zA-Z0-9_+-]*$/;
                if (quotenumber !== null && quotenumber.match(pattern) === IsNull && (lineOfBusiness === "New Business - Real Estate" || lineOfBusiness === "Renewal - Real Estate")) {
                    if (formContext.getAttribute("rsa_100benchmarkpremium_dc") !== null && formContext.getAttribute("rsa_100benchmarkpremium_dc") !== undefined) {
                        formContext.getControl("rsa_100benchmarkpremium_dc").setNotification("Quote Number can only contain alphanumeric characters", 777);
                    }
                }
                else {
                    if (formContext.getAttribute("rsa_100benchmarkpremium_dc") !== null && formContext.getAttribute("rsa_100benchmarkpremium_dc") !== undefined) {
                        formContext.getControl("rsa_100benchmarkpremium_dc").clearNotification(777);
                    }
                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "QuoteNumberValidation-" + err.message });
        }
    },


    //IF ((Office % + SBC % + Tradespeople % + Commercial Vehicle % + Minifleet % + Shop %) > 1 )
    //THEN Show error message "SME deals product cannot be more than 100% when all added together "

    //Author : Sujeet Pandey
    //Date_Created :  4 August 2020
    //This function simply adds the field values  and checks if they are greater than 1
    //SME_Deals_100_Max
    ValidateSMEdealsproduct: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_office") !== null && formContext.getAttribute("rsa_office") !== "undefined"
                && formContext.getAttribute("rsa_sbc") !== null
                && formContext.getAttribute("rsa_sbc") !== "undefined"
                && formContext.getAttribute("rsa_tradespeople") !== null
                && formContext.getAttribute("rsa_tradespeople") !== "undefined"
                && formContext.getAttribute("rsa_commercialvehicle") !== null
                && formContext.getAttribute("rsa_commercialvehicle") !== "undefined"
                && formContext.getAttribute("rsa_minifleet") !== null
                && formContext.getAttribute("rsa_minifleet") !== "undefined"
                && formContext.getAttribute("rsa_shop") !== null
                && formContext.getAttribute("rsa_shop") !== "undefined") {

                var office, SBC, tradesPeople, commercialVehicle, minifleet, shop;

                office = formContext.getAttribute("rsa_office").getValue() / 100;
                SBC = formContext.getAttribute("rsa_sbc").getValue() / 100;
                tradesPeople = formContext.getAttribute("rsa_tradespeople").getValue() / 100;
                commercialVehicle = formContext.getAttribute("rsa_commercialvehicle").getValue() / 100;
                minifleet = formContext.getAttribute("rsa_minifleet").getValue() / 100;
                shop = formContext.getAttribute("rsa_shop").getValue() / 100;

                if ((office + SBC + tradesPeople + commercialVehicle + minifleet + shop) > 1) {
                    formContext.getControl("rsa_commercialvehicle").setNotification("SME deals product cannot be more than 100% when all added together.", 65);
                    //Xrm.Navigation.openAlertDialog({ "SME deals product cannot be more than 100% when all added together"});
                    //alert("SME deals product cannot be more than 100% when all added together");
                }

                else {
                    formContext.getControl("rsa_commercialvehicle").clearNotification(65);
                }

            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "ValidateSMEdealsproduct -" + err.message });
        }
    },

    //Author : Nida
    //Date_Created :  5 August 2020
    //This function to Validate Null Validation for Underwriter/Trader
    //MidMarket_UnderwriterTrader_Mandatory

    ValidateMidMarketUnderwriterTrader: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined") {
                var lineOfBusiness = null;
                var underwriterTrader = formContext.getAttribute("rsa_secondaryowner");
                var targetCustomer = formContext.getAttribute("rsa_targetcustomer");
                var pL = formContext.getAttribute("rsa_pandlid");
                var lineOfBusinessArray = ["3ee02690-c360-466d-aeda-abf9c7198c86", "3ee02690-c360-466d-aeda-abf9c7198c86", "d46c5317-2129-413c-9238-ce33fad33b00", "0234fc11-277d-469f-a5ed-1d38cb6b7af7", "efd71837-ac16-4927-81a6-36317d62a8e4", "f9d976c6-9886-460d-8b61-2b77df22cd6a"];
                var hasValue = null;
                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    lineOfBusiness = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                    hasValue = lineOfBusinessArray.includes(lineOfBusiness, 0);
                    if (lineOfBusiness === "New Business" && underwriterTrader !== null && underwriterTrader !== "undefined"
                        && targetCustomer !== null && targetCustomer !== "undefined" && targetCustomer.getValue() === '1'
                        && pL !== null && pL !== "undefined" && pL.getValue()[0].name === 'Mid-Market') {
                        if (underwriterTrader.getValue() === null) {

                            formContext.getAttribute("rsa_secondaryowner").setRequiredLevel("required");
                            formContext.getControl("rsa_secondaryowner").setNotification("Please complete the Underwriter/Trader field.", 654);
                        }
                        else {
                            formContext.getAttribute("rsa_secondaryowner").setRequiredLevel("none");
                            formContext.getControl("rsa_secondaryowner").clearNotification(654);
                        }
                    }

                    else if (hasValue === true && underwriterTrader !== null && underwriterTrader !== "undefined" &&
                        formContext.getAttribute("rsa_opportunitystage") !== null && formContext.getAttribute("rsa_opportunitystage") !== "undefined") {
                        var salesStage = formContext.getAttribute("rsa_opportunitystage").getValue()[0].name;
                        if (underwriterTrader.getValue() === null && (salesStage === "In View" || salesStage === "Not Taken Up" || salesStage === "Non ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Å“ Renewable" || salesStage === "Lapsed" || salesStage === "No Longer Required")) {

                            formContext.getAttribute("rsa_secondaryowner").setRequiredLevel("required");
                            formContext.getControl("rsa_secondaryowner").setNotification("Please complete the Underwriter/Trader field.", 655);
                        }
                        else {
                            formContext.getAttribute("rsa_secondaryowner").setRequiredLevel("none");
                            formContext.getControl("rsa_secondaryowner").clearNotification(655);
                        }
                    }

                    else return;
                }
            }
        }

        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "ValidateMultiplePolicyNumberNeeded -" + err.message });
        }
    },

    //Author : Prachi Paunikar
    //Date_Created : 04 August 2020
    //Function for setting value of Renewal month
    SetRenewalMonth: function (executionContext) {

        try {
            var formContext = executionContext.getFormContext();
            var closeDate = formContext.getAttribute("rsa_closedate").getValue();
            if (formContext.getAttribute("rsa_opportunityrenewalmonth") !== null && formContext.getAttribute("rsa_opportunityrenewalmonth") !== "undefined") {
                /* if (closeDate !== null) {

                    var closeDateMonth = closeDate.getMonth() + 1;
                    if (closeDateMonth === 1 || closeDateMonth === "Jan") {
                        formContext.getAttribute("rsa_opportunityrenewalmonth").setValue("January");
                    }
                    if (closeDateMonth === 2 || closeDateMonth === "Feb") {
                        formContext.getAttribute("rsa_opportunityrenewalmonth").setValue("February");
                    }
                    if (closeDateMonth === 3 || closeDateMonth === "Mar") {
                        formContext.getAttribute("rsa_opportunityrenewalmonth").setValue("March");
                    }
                    if (closeDateMonth === 4 || closeDateMonth === "Apr") {
                        formContext.getAttribute("rsa_opportunityrenewalmonth").setValue("April");
                    }
                    if (closeDateMonth === 5 || closeDateMonth === "May") {
                        formContext.getAttribute("rsa_opportunityrenewalmonth").setValue("May");
                    }
                    if (closeDateMonth === 6 || closeDateMonth === "Jun") {
                        formContext.getAttribute("rsa_opportunityrenewalmonth").setValue("June");
                    }
                    if (closeDateMonth === 7 || closeDateMonth === "Jul") {
                        formContext.getAttribute("rsa_opportunityrenewalmonth").setValue("July");
                    }
                    if (closeDateMonth === 8 || closeDateMonth === "Aug") {
                        formContext.getAttribute("rsa_opportunityrenewalmonth").setValue("August");
                    }
                    if (closeDateMonth === 9 || closeDateMonth === "Sep") {
                        formContext.getAttribute("rsa_opportunityrenewalmonth").setValue("September");
                    }
                    if (closeDateMonth === 10 || closeDateMonth === "Oct") {
                        formContext.getAttribute("rsa_opportunityrenewalmonth").setValue("October");
                    }
                    if (closeDateMonth === 11 || closeDateMonth === "Nov") {
                        formContext.getAttribute("rsa_opportunityrenewalmonth").setValue("November");
                    }
                    if (closeDateMonth === 12 || closeDateMonth === "Dec") {
                        formContext.getAttribute("rsa_opportunityrenewalmonth").setValue("December");
                    }
                } */
            }
        }
        catch (e) {

            Xrm.Navigation.openAlertDialog({ text: "Error Message for Renewal Month : " + e.message });
        }
    },

    //Policy Length - rsa_policylength
    SetPolicyLength: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            var renewalDate = null, expiryDate = null;
            if (formContext.getAttribute("rsa_closedate") !== null && formContext.getAttribute("rsa_closedate") !== undefined)
                renewalDate = formContext.getAttribute("rsa_closedate").getValue();
            if (formContext.getAttribute("rsa_expirydate") !== null && formContext.getAttribute("rsa_expirydate") !== undefined)
                expiryDate = formContext.getAttribute("rsa_expirydate").getValue();
            if (renewalDate !== null && expiryDate !== null) {

                // Assuming expiryDate and renewalDate are Date objects

                const millisecondsInDay = 24 * 60 * 60 * 1000; // Number of milliseconds in a day
                const expiryTimestamp = expiryDate.getTime();
                const renewalTimestamp = renewalDate.getTime();
                const policyLengthInDays = (expiryTimestamp - renewalTimestamp) / millisecondsInDay;

                // Convert days to months (assuming 30 days per month)
                const policyLengthInMonths = Math.round(policyLengthInDays / 30);

                /* let months;
               months = (expiryDate.getFullYear() - renewalDate.getFullYear()) * 12;
               months -= renewalDate.getMonth();
               months += expiryDate.getMonth();
               var policyLength = months <= 0 ? 0 : months; */
                if (Xrm.Page.getAttribute("rsa_policylengthcal") !== null)
                    Xrm.Page.getAttribute("rsa_policylengthcal").setValue(policyLengthInMonths);
            }
        }
        catch (e) {

            Xrm.Navigation.openAlertDialog({ text: "Error Message for Policy Length : " + e.message });
        }
    },

    //totalamount - rsa_rsaquotedpremium
    GetTotalPremiumAmount: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var lineOfBusinessObj = formContext.getAttribute('rsa_lineofbusiness');

        if (lineOfBusinessObj !== null && lineOfBusinessObj !== undefined) {
            var lineOfBusinessObjValue = lineOfBusinessObj.getValue();
            if (lineOfBusinessObjValue !== null && lineOfBusinessObjValue !== undefined && lineOfBusinessObjValue[0] !== null && lineOfBusinessObjValue[0] !== undefined) {

                var lineOfBusinessText = lineOfBusinessObjValue[0].name;

                if (lineOfBusinessText === 'New Business - Schemes & Deals') {
                    var firstYearPremium = formContext.getAttribute('rsa_year1premiuminyear').getValue();
                    var secondYearPremium = formContext.getAttribute('rsa_rsayear2premium').getValue();//
                    var thirdYearPremium = formContext.getAttribute('rsa_rsayear3premium').getValue();
                    var forthYearPremium = formContext.getAttribute('rsa_rsayear4premium').getValue();
                    var fifthYearPremium = formContext.getAttribute('rsa_rsayear5premium').getValue();
                    var sixYearPremium = formContext.getAttribute('rsa_rsayear6premium').getValue();

                    var totalAmountOfPremium = parseFloat(firstYearPremium) + parseFloat(secondYearPremium) + parseFloat(thirdYearPremium) + parseFloat(forthYearPremium) + parseFloat(fifthYearPremium) + parseFloat(sixYearPremium);
                    formContext.getAttribute('rsa_rsaquotedpremium').setValue(totalAmountOfPremium);

                }
            }
        }
    },

    //Author : Prachi Paunikqar
    //Date_Created : 09 September 2020
    //This Function set form ID into opportunity form ID field of Opportunity
    OpportunityFormID: function (executionContext) {
        /* try {
            var formContext = executionContext.getFormContext();
            var formId = formContext.ui.formSelector.getCurrentItem().getId();
            if (formContext.getAttribute("rsa_opportunityformid") !== null && formContext.getAttribute("rsa_opportunityformid") !== "undefined") {
                formContext.getAttribute("rsa_opportunityformid").setValue(formId);
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "OpportunityFormID -" + err.message });
        } */

    },


    // Author : Prachi Paunikar
    //Date_Created : 10 September 2020
    // This Function opens the correct form while opening the existing records
    LoadingExistingRecord: function (executionContext) {
        /* try {
            var formContext = executionContext.getFormContext();
         
            if (formContext.getAttribute("rsa_opportunityformid") !== null && formContext.getAttribute("rsa_opportunityformid") !== "undefined" && (formContext.ui.getFormType() === 2 || formContext.ui.getFormType() === 4|| formContext.ui.getFormType() === 3)) {
                if (formContext.getAttribute("rsa_opportunityformid").getValue() !== null && formContext.getAttribute("rsa_opportunityformid").getValue() !== "undefined") {
                    var opportunityFormID = formContext.getAttribute("rsa_opportunityformid").getValue();
                    var formId = formContext.ui.formSelector.getCurrentItem().getId();
                    if (formId !== opportunityFormID.toLowerCase() && opportunityFormID !== null) {
                        formContext.ui.formSelector.items.get(opportunityFormID.toLowerCase()).navigate();
                    }
                }
                RSA.D365CRM.Opportunity.Main.Lock(executionContext);
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "LoadingExistingRecord -" + err.message });
        } */
    },
    /////
    ///Formaula fields 
    /////Commission 100% (PC)	rsa_Commission100PC    Total_GWP_100_PC__c * Commission_PC__c   rsa_totalgwp100pc 
    ///rsa_commissionpc

    rsa_Commission100PC: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined" && formContext.getAttribute("rsa_commission100pc") !== null && formContext.getAttribute("rsa_commission100pc") !== "undefined" && formContext.getAttribute("rsa_totalgwp100pc") !== null && formContext.getAttribute("rsa_totalgwp100pc") !== "undefined" && formContext.getAttribute("rsa_commissionpc") !== null && formContext.getAttribute("rsa_commissionpc") !== "undefined") {
                var Commission100PC = formContext.getAttribute("rsa_commission100pc");

                if ((formContext.getAttribute("rsa_totalgwp100pc").getValue() !== null) && (formContext.getAttribute("rsa_commissionpc").getValue() !== null)) {
                    //formContext.getAttribute("rsa_totalgwp100pc").getValue() * (formContext.getAttribute("rsa_commissionpc").getValue();
                    Commission100PC.setValue((formContext.getAttribute("rsa_totalgwp100pc").getValue()) * (formContext.getAttribute("rsa_commissionpc").getValue()));
                }

            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "rsa_Commission100PC -" + err.message });
        }
    },

    //////Commission (PC)   rsa_commissioncalcpc
    ////(Total_GWP_100_PC__c/100)* Commission_PC__c)*100     rsa_totalgwp100pc
    ////rsa_commissionpc     ((Total_GWP_100_PC__c/100)* Commission_PC__c)*100
    rsa_commissioncalcpc: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined" && formContext.getAttribute("rsa_commissioncalcpc") !== null && formContext.getAttribute("rsa_commissioncalcpc") !== "undefined" && formContext.getAttribute("rsa_totalgwp100pc") !== null && formContext.getAttribute("rsa_totalgwp100pc") !== "undefined" && formContext.getAttribute("rsa_commissionpc") !== null && formContext.getAttribute("rsa_commissionpc") !== "undefined") {
                var CommissionPC = formContext.getAttribute("rsa_commissioncalcpc");

                if ((formContext.getAttribute("rsa_totalgwp100pc").getValue() !== null) && (formContext.getAttribute("rsa_commissionpc").getValue() !== null)) {
                    //formContext.getAttribute("rsa_totalgwp100pc").getValue() * (formContext.getAttribute("rsa_commissionpc").getValue();
                    CommissionPC.setValue(((formContext.getAttribute("rsa_totalgwp100pc").getValue()) / 100) * ((formContext.getAttribute("rsa_commissionpc").getValue()) * 100));
                }

            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "rsa_Commission100PC -" + err.message });
        }
    },

    //cy net premium (pc)	rsa_cynetpremiumpc
    ///CY_GWP_ex_Gross_Ups_Terrorism_PC__c - CY_FAC_RI__c - RSA_External_Reinsurance_incl_Panel_PC__c
    //CY GWP (ex Gross-Ups & Terrorism) (PC)	rsa_cygwpexgrossupsterrorismpc
    //RSA External Reinsurance incl Panel (PC)	rsa_rsaexternalreinsuranceinclpanelpc
    rsa_cynetpremiumpc: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined"
                && formContext.getAttribute("rsa_cygwpexgrossupsterrorismpc") !== null && formContext.getAttribute("rsa_cygwpexgrossupsterrorismpc") !== "undefined"
                && formContext.getAttribute("rsa_rsaexternalreinsuranceinclpanelpc") !== null && formContext.getAttribute("rsa_rsaexternalreinsuranceinclpanelpc") !== "undefined"
                && formContext.getAttribute("rsa_cynetpremiumpc") !== null && formContext.getAttribute("rsa_cynetpremiumpc") !== "undefined") {
                var cynetpremiumpc = formContext.getAttribute("rsa_cynetpremiumpc");

                if ((formContext.getAttribute("rsa_cygwpexgrossupsterrorismpc").getValue() !== null) && (formContext.getAttribute("rsa_rsaexternalreinsuranceinclpanelpc").getValue() !== null)) {
                    //formContext.getAttribute("rsa_totalgwp100pc").getValue() * (formContext.getAttribute("rsa_commissionpc").getValue();
                    cynetpremiumpc.setValue((formContext.getAttribute("rsa_cygwpexgrossupsterrorismpc").getValue()) - (formContext.getAttribute("rsa_rsaexternalreinsuranceinclpanelpc").getValue()));
                }

            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "cynetpremiumpc -" + err.message });
        }
    },

    //distance from technical price (pc)	rsa_distancefromtechnicalpricepc
    //(Total_GWP_100_PC__c - Technical_Price_GoC_PC__c)
    //Total GWP 100% (PC)	rsa_totalgwp100pc
    //Technical Price GoC (PC)	rsa_technicalpricegocpc
    rsa_distancefromtechnicalpricepc: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_distancefromtechnicalpricepc") !== null && formContext.getAttribute("rsa_distancefromtechnicalpricepc") !== "undefined"
                && formContext.getAttribute("rsa_totalgwp100pc") !== null && formContext.getAttribute("rsa_totalgwp100pc") !== "undefined"
                && formContext.getAttribute("rsa_technicalpricegocpc") !== null && formContext.getAttribute("rsa_technicalpricegocpc") !== "undefined") {
                var distancefromtechnicalpricepc = formContext.getAttribute("rsa_distancefromtechnicalpricepc");

                if ((formContext.getAttribute("rsa_totalgwp100pc").getValue() !== null) && (formContext.getAttribute("rsa_technicalpricegocpc").getValue() !== null)) {
                    //formContext.getAttribute("rsa_totalgwp100pc").getValue() * (formContext.getAttribute("rsa_commissionpc").getValue();
                    distancefromtechnicalpricepc.setValue((formContext.getAttribute("rsa_totalgwp100pc").getValue()) - (formContext.getAttribute("rsa_technicalpricegocpc").getValue()));
                }

            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "distancefromtechnicalpricepc -" + err.message });
        }
    },

    ///Quoted Indicator  	rsa_quotedindicator
    ///Opportunity Stage	rsa_opportunitystage
    rsa_quotedindicator: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined"
                && formContext.getAttribute("rsa_quotedindicator") !== null && formContext.getAttribute("rsa_quotedindicator") !== "undefined"
                && formContext.getAttribute("rsa_opportunitystage") !== null && formContext.getAttribute("rsa_opportunitystage") !== "undefined") {
                var quotedindicator = formContext.getAttribute("rsa_quotedindicator");
                var opptystage = formContext.getAttribute("rsa_opportunitystage").getValue();
                if ((formContext.getAttribute("rsa_opportunitystage").getValue() !== null) && (opptystage[0].name == "Quoted")) {

                    quotedindicator.setValue(1);
                }
                else { quotedindicator.setValue(0); }

            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "distancefromtechnicalpricepc -" + err.message });
        }
    },
    //risk engineering fee (gbp)	rsa_riskengineeringfeegbp

    //Risk_Engineering_Fee_PC__c / Exchange_Rate_GSL_c__c
    //Risk Engineering Fee (PC)	rsa_riskengineeringfee
    //Exchange Rate	rsa_exchangerategslc
    rsa_riskengineeringfeegbp: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined"
                && formContext.getAttribute("rsa_riskengineeringfeegbp") !== null && formContext.getAttribute("rsa_riskengineeringfeegbp") !== "undefined"
                && formContext.getAttribute("rsa_riskengineeringfee") !== null && formContext.getAttribute("rsa_riskengineeringfee") !== "undefined"
                && formContext.getAttribute("rsa_exchangerategslc") !== null && formContext.getAttribute("rsa_exchangerategslc") !== "undefined") {
                var riskengineeringfeegbp = formContext.getAttribute("rsa_riskengineeringfeegbp");
                if ((formContext.getAttribute("rsa_riskengineeringfee").getValue() !== null) && (formContext.getAttribute("rsa_exchangerategslc").getValue() !== null)) {
                    riskengineeringfeegbp.setValue((formContext.getAttribute("rsa_riskengineeringfee").getValue()) / (formContext.getAttribute("rsa_exchangerategslc").getValue()));
                }

            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "riskengineeringfeegbp -" + err.message });
        }
    },
    //rsa gross gwp (pc)	rsa_rsagrossgwppc
    //IF(CONTAINS( (Record_Type_Name__c),"Regional"),( Total_GWP_100_PC__c),(Total_GWP_100_PC__c * Written_Line_PC__c * Order_PC__c * Signing_PC__c))
    //Total GWP 100% (PC)	rsa_totalgwp100pc
    //Written Line %	rsa_writtenlinepc
    //Order %	rsa_orderpc
    //Signing % (PC)	rsa_signingpc
    rsa_rsagrossgwppc: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined"
                && formContext.getAttribute("rsa_rsagrossgwppc") !== null && formContext.getAttribute("rsa_rsagrossgwppc") !== "undefined"
                && formContext.getAttribute("rsa_totalgwp100pc") !== null && formContext.getAttribute("rsa_totalgwp100pc") !== "undefined"
                && formContext.getAttribute("rsa_writtenlinepc") !== null && formContext.getAttribute("rsa_writtenlinepc") !== "undefined"
                && formContext.getAttribute("rsa_orderpc") !== null && formContext.getAttribute("rsa_orderpc") !== "undefined"
                && formContext.getAttribute("rsa_signingpc") !== null && formContext.getAttribute("rsa_signingpc") !== "undefined") {
                var rsagrossgwppc = formContext.getAttribute("rsa_rsagrossgwppc");

                var lob = formContext.getAttribute("rsa_lineofbusiness").getValue();
                if ((lob[0].name.indexOf("Regional") !== -1) && formContext.getAttribute("rsa_totalgwp100pc").getValue() !== null) {
                    rsagrossgwppc.setValue(formContext.getAttribute("rsa_totalgwp100pc").getValue());
                }
                else if (formContext.getAttribute("rsa_totalgwp100pc").getValue() !== null && formContext.getAttribute("rsa_writtenlinepc").getValue() !== null && formContext.getAttribute("rsa_orderpc").getValue() !== null && formContext.getAttribute("rsa_signingpc").getValue() !== null) {
                    rsagrossgwppc.setValue(formContext.getAttribute("rsa_totalgwp100pc").getValue() * formContext.getAttribute("rsa_writtenlinepc").getValue() * formContext.getAttribute("rsa_orderpc").getValue() * formContext.getAttribute("rsa_signingpc").getValue());
                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "distancefromtechnicalpricepc -" + err.message });
        }
    },
    //rsa net gwp (pc)	rsa_rsanetgwppc
    //( Total_GWP_100_PC__c - Commission_Calc_PC__c )
    //rsa_totalgwp100pc 
    //Commission (PC)	rsa_commissioncalcpc
    rsa_rsanetgwppc: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined"
                && formContext.getAttribute("rsa_totalgwp100pc") !== null && formContext.getAttribute("rsa_totalgwp100pc") !== "undefined"
                && formContext.getAttribute("rsa_commissioncalcpc") !== null && formContext.getAttribute("rsa_commissioncalcpc") !== "undefined"
                && formContext.getAttribute("rsa_rsanetgwppc") !== null && formContext.getAttribute("rsa_rsanetgwppc") !== "undefined") {
                var rsanetgwppc = formContext.getAttribute("rsa_rsanetgwppc");
                if (formContext.getAttribute("rsa_totalgwp100pc").getValue() !== null && formContext.getAttribute("rsa_commissioncalcpc").getValue() !== null) {
                    rsanetgwppc.setValue(formContext.getAttribute("rsa_totalgwp100pc").getValue()) - (formContext.getAttribute("rsa_commissioncalcpc").getValue());
                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "distancefromtechnicalpricepc -" + err.message });
        }
    },
    //rsa premium goc (pc)	rsa_rsapremiumgocpc
    //
    rsa_rsapremiumgocpc: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined" && formContext.getAttribute("rsa_rsapremiumgocpc") !== null && formContext.getAttribute("rsa_rsapremiumgocpc") !== "undefined") {
                var lob = formContext.getAttribute("rsa_lineofbusiness").getValue();
                var rsapremiumgocpc = formContext.getAttribute("rsa_rsapremiumgocpc");
                if (rsapremiumgocpc !== null && rsapremiumgocpc.getValue() !== null) {
                    if ((lob !== null) && (formContext.getAttribute("rsa_totalgwp100pc") !== null && formContext.getAttribute("rsa_totalgwp100pc").getValue() !== null) && ((lob[0].name == "New Business - Marine Regional") || (lob[0].name == "Renewal - Marine Regional"))) {
                        rsapremiumgocpc.setValue(formContext.getAttribute("rsa_totalgwp100pc").getValue());
                    }
                    if (lob[0].name == "Renewal - Marine London" || lob[0].name == "Renewal - Marine Europe" || lob[0].name == "New Business - Marine London" || lob[0].name == "New Business - Marine Europe") {
                        {
                            //INC2293136: Calculation correction .added * 0.000001 in the below formula
                            if (formContext.getAttribute("rsa_totalgwp100pc") !== null && formContext.getAttribute("rsa_totalgwp100pc").getValue() !== null && formContext.getAttribute("rsa_totalgwp100pc") !== "undefined" && formContext.getAttribute("rsa_writtenlinepc") !== null && formContext.getAttribute("rsa_writtenlinepc") !== "undefined" && formContext.getAttribute("rsa_orderpc") !== null && formContext.getAttribute("rsa_orderpc") !== "undefined" && formContext.getAttribute("rsa_signedpc") !== null && formContext.getAttribute("rsa_signedpc") !== "undefined") {
                                rsapremiumgocpc.setValue(formContext.getAttribute("rsa_totalgwp100pc").getValue() * formContext.getAttribute("rsa_writtenlinepc").getValue() * formContext.getAttribute("rsa_orderpc").getValue() * formContext.getAttribute("rsa_signedpc").getValue() * 0.000001);
                            }
                        }
                    }

                    else { rsapremiumgocpc.setValue(0); }
                }
            }
        }


        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "rsa_rsapremiumgocpc-" + err.message });
        }
    },
    //rsa premium noc & ri (pc)	rsa_rsapremiumnetofcommissionripc
    //IF( CONTAINS(Record_Type_Name__c , 'Marine'), (RSA_Premium_NoC_PC__c - RSA_External_Reinsurance_incl_Panel_PC__c),0)
    //RSA Premium NoC(PC)	rsa_rsapremiumnocpc
    //RSA External Reinsurance incl Panel (PC)	rsa_rsaexternalreinsuranceinclpanelpc
    rsa_rsapremiumnetofcommissionripc: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined"
                && formContext.getAttribute("rsa_rsapremiumnocpc") !== null && formContext.getAttribute("rsa_rsapremiumnocpc") !== "undefined"
                && formContext.getAttribute("rsa_rsaexternalreinsuranceinclpanelpc") !== null && formContext.getAttribute("rsa_rsaexternalreinsuranceinclpanelpc") !== "undefined"
                && formContext.getAttribute("rsa_rsapremiumnetofcommissionripc") !== null && formContext.getAttribute("rsa_rsapremiumnetofcommissionripc") !== "undefined") {
                var rsapremiumnetofcommissionripc = formContext.getAttribute("rsa_rsapremiumnetofcommissionripc");

                var lob = formContext.getAttribute("rsa_lineofbusiness").getValue();
                if ((lob[0].name.indexOf("Marine") !== -1)) {
                    rsapremiumnetofcommissionripc.setValue(formContext.getAttribute("rsa_rsapremiumnocpc").getValue() - formContext.getAttribute("rsa_rsaexternalreinsuranceinclpanelpc").getValue());
                }
                else { rsapremiumnetofcommissionripc.setValue(0); }
            }
        }

        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "rsa_rsapremiumnetofcommissionripc -" + err.message });
        }
    },

    //rsa premium noc (pc)	rsa_rsapremiumnocpc
    //Commission (PC)	rsa_commissioncalcpc
    //RSA Premium GoC (PC)	rsa_rsapremiumgocpc
    //RSA Share Commission (PC)	rsa_commissionrsapremiumpc

    rsa_rsapremiumnocpc: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined"
                && formContext.getAttribute("rsa_rsapremiumnocpc") !== null && formContext.getAttribute("rsa_rsapremiumnocpc") !== "undefined") {
                var lob = formContext.getAttribute("rsa_lineofbusiness").getValue();
                var rsapremiumnocpc = formContext.getAttribute("rsa_rsapremiumnocpc");
                if ((lob !== null) && formContext.getAttribute("rsa_totalgwp100pc") !== null && formContext.getAttribute("rsa_totalgwp100pc").getValue() !== null && formContext.getAttribute("rsa_totalgwp100pc") !== "undefined" && formContext.getAttribute("rsa_commissioncalcpc") !== null && formContext.getAttribute("rsa_commissioncalcpc").getValue() !== null && formContext.getAttribute("rsa_commissioncalcpc") !== "undefined") {
                    if ((lob[0].name == "New Business - Marine Regional") || (lob[0].name == "Renewal - Marine Regional")) {
                        rsapremiumnocpc.setValue(formContext.getAttribute("rsa_totalgwp100pc").getValue() - formContext.getAttribute("rsa_commissioncalcpc").getValue());
                    }
                }
                else if (lob[0].name == "Renewal - Marine London" || lob[0].name == "Renewal - Marine Europe" || lob[0].name == "New Business - Marine London" || lob[0].name == "New Business - Marine Europe") {
                    {
                        if (formContext.getAttribute("rsa_rsapremiumgocpc") !== null && formContext.getAttribute("rsa_totalgwp100pc").getValue() !== null
                            && formContext.getAttribute("rsa_rsapremiumgocpc") !== "undefined"
                            && formContext.getAttribute("rsa_commissionrsapremiumpc") !== null
                            && formContext.getAttribute("rsa_commissionrsapremiumpc").getValue() !== null
                            && formContext.getAttribute("rsa_commissionrsapremiumpc") !== "undefined"
                            && formContext.getAttribute("rsa_commissioncalcpc") !== null
                            && formContext.getAttribute("rsa_commissioncalcpc").getValue() !== null
                            && formContext.getAttribute("rsa_commissioncalcpc") !== "undefined") {
                            rsapremiumnocpc.setValue(formContext.getAttribute("rsa_commissionrsapremiumpc").getValue() - formContext.getAttribute("rsa_commissioncalcpc").getValue());
                        }
                    }
                }
                else { rsapremiumnocpc.setValue(0); }

            }

        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "rsapremiumnocpc-" + err.message });
        }
    },

    //technical price goc	rsa_technicalpricegoc
    //iF(OR(Technical_Price_GoC_PC__c = 0, Exchange_Rate__c = 0), 0, Technical_Price_GoC_PC__c / Exchange_Rate__c)
    ////Technical Price GoC (PC)	rsa_technicalpricegocpc
    //Exchange Rate	rsa_exchangerate
    rsa_technicalpricegoc: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_technicalpricegoc") !== null && formContext.getAttribute("rsa_technicalpricegoc") !== "undefined"
                && formContext.getAttribute("rsa_technicalpricegocpc") !== null && formContext.getAttribute("rsa_technicalpricegocpc") !== "undefined"
                && formContext.getAttribute("rsa_exchangerate") !== null && formContext.getAttribute("rsa_exchangerate") !== "undefined") {
                var technicalpricegoc = formContext.getAttribute("rsa_technicalpricegoc");
                if (formContext.getAttribute("rsa_exchangerate").getValue() == 0 || formContext.getAttribute("rsa_technicalpricegocpc").getValue() == 0) {
                    technicalpricegoc.setValue(0);
                }
                else {
                    technicalpricegoc.setValue(formContext.getAttribute("rsa_technicalpricegocpc").getValue() / formContext.getAttribute("rsa_exchangerate").getValue());
                }
            }
        }

        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "rsa_technicalpricegoc -" + err.message });
        }
    },

    //technical price goc (pc)	rsa_technicalpricegocpc
    //Tech Price Gross or Net of Comm (PC)	rsa_tpgrossornetofcomm
    //rsa_100technicalpricepc
    //rsa_technicalpricenocpc
    //rsa_commissionpc
    rsa_technicalpricegocpc: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined"
                && formContext.getAttribute("rsa_technicalpricegocpc") !== null && formContext.getAttribute("rsa_technicalpricegocpc") !== "undefined"
                && formContext.getAttribute("rsa_tpgrossornetofcomm") !== null && formContext.getAttribute("rsa_tpgrossornetofcomm") !== "undefined"
                && formContext.getAttribute("rsa_100technicalpricepc") !== null && formContext.getAttribute("rsa_100technicalpricepc") !== "undefined"
                && formContext.getAttribute("rsa_commissionpc") !== null && formContext.getAttribute("rsa_commissionpc") !== "undefined"
                && formContext.getAttribute("rsa_technicalpricenocpc") !== null && formContext.getAttribute("rsa_technicalpricenocpc") !== "undefined") {

                var technicalpricegocpc = formContext.getAttribute("rsa_technicalpricegocpc");
                var tpgrossornetofcomm = formContext.getAttribute("rsa_tpgrossornetofcomm").getText();
                var commissionpc = formContext.getAttribute("rsa_commissionpc").getValue();
                var technicalpricenocpc = formContext.getAttribute("rsa_technicalpricenocpc").getValue();
                if (tpgrossornetofcomm == "Gross") {
                    technicalpricegocpc.setValue(formContext.getAttribute("rsa_100technicalpricepc").getValue());
                }
                else {
                    technicalpricegocpc.setValue(((technicalpricenocpc / 100) - (commissionpc * 100) * 100));
                }
            }
        }

        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "rsa_technicalpricegocpc -" + err.message });
        }
    },
    //technical price noc	rsa_technicalpricenoc
    ////Exchange Rate	rsa_exchangerate
    //technical price noc (pc)	rsa_technicalpricenocpc

    rsa_technicalpricenoc: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (
                formContext.getAttribute("rsa_technicalpricenoc") !== null && formContext.getAttribute("rsa_technicalpricenoc") !== "undefined"
                && formContext.getAttribute("rsa_technicalpricenocpc") !== null && formContext.getAttribute("rsa_technicalpricenocpc") !== "undefined"
                && formContext.getAttribute("rsa_exchangerate") !== null && formContext.getAttribute("rsa_exchangerate") !== "undefined") {
                var technicalpricenoc = formContext.getAttribute("rsa_technicalpricenoc").getValue();
                var exchangerate = formContext.getAttribute("rsa_exchangerate").getValue();
                var technicalpricenocpc = formContext.getAttribute("rsa_technicalpricenocpc").getValue();
                if (technicalpricenocpc == null) {
                    technicalpricenoc.setValue(0);
                }
                else if (exchangerate = null || exchangerate == 0) {
                    technicalpricenoc.setValue(0);
                }
                else {
                    technicalpricenoc.setValue(technicalpricenocpc / exchangerate);
                }
            }
        }

        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "rsa_technicalpricenoc -" + err.message });
        }
    },
    //technical price noc (pc)	rsa_technicalpricenocpc
    //Tech Price Gross or Net of Comm (PC)	rsa_tpgrossornetofcomm
    //rsa_commission
    rsa_technicalpricenocpc: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_technicalpricenocpc") !== null && formContext.getAttribute("rsa_technicalpricenocpc") !== "undefined"
                && formContext.getAttribute("rsa_tpgrossornetofcomm") !== null && formContext.getAttribute("rsa_tpgrossornetofcomm") !== "undefined"
                && formContext.getAttribute("rsa_100technicalpricepc") !== null && formContext.getAttribute("rsa_100technicalpricepc") !== "undefined"
                && formContext.getAttribute("rsa_commissionpc") !== null && formContext.getAttribute("rsa_commissionpc") !== "undefined") {

                var technicalpricenocpc = formContext.getAttribute("rsa_technicalpricenocpc");
                var tpgrossornetofcomm = formContext.getAttribute("rsa_tpgrossornetofcomm").getText();
                var commissionpc = formContext.getAttribute("rsa_commissionpc").getValue();
                var technicalpricepc = formContext.getAttribute("rsa_100technicalpricepc").getValue();
                if (tpgrossornetofcomm == "Net") {
                    technicalpricenocpc.setValue(technicalpricepc);
                }
                else {
                    technicalpricenocpc.setValue(technicalpricepc * (1 - commissionpc));
                }
            }
        }

        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "rsa_technicalpricenocpc -" + err.message });
        }
    },
    //divert indicator	rsa_divertindicator
    rsa_divertindicator: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_divertindicator") !== null && formContext.getAttribute("rsa_divertindicator") !== "undefined"
                && formContext.getAttribute("rsa_opportunitystage") !== null && formContext.getAttribute("rsa_opportunitystage") !== "undefined") {
                var divertindicator = formContext.getAttribute("rsa_divertindicator");
                var opptystage = formContext.getAttribute("rsa_opportunitystage").getValue();
                if ((formContext.getAttribute("rsa_opportunitystage").getValue() !== null) && (opptystage[0].name == "Diverted")) {

                    divertindicator.setValue(1);
                }
                else { divertindicator.setValue(0); }

            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "rsa_divertindicator -" + err.message });
        }
    },
    //RSA_Premium_GoC_PC__c * Commission_PC__c
    //rsa share commission (pc)	rsa_commissionrsapremiumpc  /////
    // RSA Premium GoC(PC)	rsa_rsapremiumgocpc
    //rsa_commissionpc

    rsa_commissionrsapremiumpc: function (executionContext) {
        try {
            //INC2293136: Calculation correct /100 added to the formula
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_commissionrsapremiumpc") != null && formContext.getAttribute("rsa_commissionrsapremiumpc") !== "undefined"
                && formContext.getAttribute("rsa_commissionpc") != null && formContext.getAttribute("rsa_commissionpc") !== "undefined"
                && formContext.getAttribute("rsa_rsapremiumgocpc") != null && formContext.getAttribute("rsa_rsapremiumgocpc") !== "undefined") {
                var commissionrsapremiumpc = formContext.getAttribute("rsa_commissionrsapremiumpc");
                commissionrsapremiumpc.setValue(formContext.getAttribute("rsa_rsapremiumgocpc").getValue() * formContext.getAttribute("rsa_commissionpc").getValue() / 100);
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "rsa_commissionrsapremiumpc-" + err.message });
        }
    },
    //CY GWP (ex Gross-Ups & Terrorism) (PC)	rsa_cygwpexgrossupsterrorismpc
    //GWP_incl_Fronting_PC__c - RSA_Captive_Premium_PC__c - RSA_Internal_Reinsurance_PC__c - CY_Coinsurance_PC__c
    //((rsa_gwpinclfrontingpc - rsa_rsacaptivepremiumpc) - rsa_rsainternalreinsurance) - rsa_cycoinsurancepc
    rsa_cygwpexgrossupsterrorismpc: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_cygwpexgrossupsterrorismpc") != null && formContext.getAttribute("rsa_cygwpexgrossupsterrorismpc") !== "undefined"
                && formContext.getAttribute("rsa_gwpinclfrontingpc") != null && formContext.getAttribute("rsa_gwpinclfrontingpc") !== "undefined"
                && formContext.getAttribute("rsa_rsacaptivepremiumpc") != null && formContext.getAttribute("rsa_rsacaptivepremiumpc") !== "undefined"
                && formContext.getAttribute("rsa_rsainternalreinsurance") != null && formContext.getAttribute("rsa_rsainternalreinsurance") !== "undefined"
                && formContext.getAttribute("rsa_cycoinsurancepc") != null && formContext.getAttribute("rsa_cycoinsurancepc") !== "undefined") {
                var cygwpexgrossupsterrorismpc = formContext.getAttribute("rsa_cygwpexgrossupsterrorismpc");
                cygwpexgrossupsterrorismpc.setValue(formContext.getAttribute("rsa_gwpinclfrontingpc").getValue() - formContext.getAttribute("rsa_rsacaptivepremiumpc").getValue() - formContext.getAttribute("rsa_rsainternalreinsurance").getValue() - formContext.getAttribute("rsa_cycoinsurancepc").getValue());
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "rsa_cygwpexgrossupsterrorismpc-" + err.message });
        }
    },
    Lock: function (executionContext) {
        // RSA.D365CRM.Opportunity.Main.genericLock(executionContext, "rsa_commission100pc", true);
        RSA.D365CRM.Opportunity.Main.genericLock(executionContext, "rsa_commissioncalcpc", true);
        RSA.D365CRM.Opportunity.Main.genericLock(executionContext, "rsa_commissionrsapremiumpc", true);
        RSA.D365CRM.Opportunity.Main.genericLock(executionContext, "rsa_cygwpexgrossupsterrorismpc", true);
        RSA.D365CRM.Opportunity.Main.genericLock(executionContext, "rsa_cygwpexgrossupsterrorismpc", true);
        RSA.D365CRM.Opportunity.Main.genericLock(executionContext, "rsa_cynetpremiumpc", true);
        RSA.D365CRM.Opportunity.Main.genericLock(executionContext, "rsa_distancefromtechnicalpricepc", true);
        RSA.D365CRM.Opportunity.Main.genericLock(executionContext, "rsa_divertindicator", true);
        RSA.D365CRM.Opportunity.Main.genericLock(executionContext, "rsa_quotedindicator", true);
        RSA.D365CRM.Opportunity.Main.genericLock(executionContext, "rsa_riskengineeringfeegbp", true);
        RSA.D365CRM.Opportunity.Main.genericLock(executionContext, "rsa_rsagrossgwppc", true);
        RSA.D365CRM.Opportunity.Main.genericLock(executionContext, "rsa_rsanetgwppc", true);
        RSA.D365CRM.Opportunity.Main.genericLock(executionContext, "rsa_rsapremiumgocpc", true);
        RSA.D365CRM.Opportunity.Main.genericLock(executionContext, "rsa_rsapremiumnetofcommissionripc", true);
        RSA.D365CRM.Opportunity.Main.genericLock(executionContext, "rsa_rsapremiumnocpc", true);
        RSA.D365CRM.Opportunity.Main.genericLock(executionContext, "rsa_technicalpricegoc", true);
        RSA.D365CRM.Opportunity.Main.genericLock(executionContext, "rsa_technicalpricegocpc", true);
        RSA.D365CRM.Opportunity.Main.genericLock(executionContext, "rsa_technicalpricenoc", true);
        RSA.D365CRM.Opportunity.Main.genericLock(executionContext, "rsa_technicalpricenocpc", true);
    },
    genericLock: function (executionContext, fieldname, lock) {
        var formContext = executionContext.getFormContext();
        var fieldObj = formContext.getControl(fieldname);

        if (fieldObj != null) {

            fieldObj.setDisabled(lock);

        }

    },
    //Author : Prachi Paunikar
    //Date_Created : 02 Nov 2020
    //ROI_Date_not_greater_than_today
    ROIDatenotgreaterthantoday: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined" && formContext.getAttribute("rsa_dateinstructionsreceived") !== null && formContext.getAttribute("rsa_dateinstructionsreceived") !== "undefined") {
                var dateInstructionReceivedDate = new Date();
                var recordTypeName = null, salesStage = null;
                var today = Date.now();
                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    recordTypeName = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                }
                var dateInstructionReceived = formContext.getAttribute("rsa_dateinstructionsreceived");
                if (dateInstructionReceived !== null) {
                    dateInstructionReceivedDate = new Date(dateInstructionReceived.getValue());
                }



                if (recordTypeName === "New Business - ROI" && dateInstructionReceivedDate > today) {
                    formContext.getControl("rsa_dateinstructionsreceived").setNotification("Date cannot be greater than today's date", 204);
                }
                else {
                    formContext.getControl("rsa_dateinstructionsreceived").clearNotification(204);
                }
            }
        } catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "ROIDatenotgreaterthantoday -" + err.message });
        }
    },

    //Author : Prachi Paunikar
    //Date_Created : 02 Nov 2020
    //ROI_Date_not_greater_than_today_for_docs
    ROIDatenotgreaterthantodayfordocs: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined" && formContext.getAttribute("rsa_datedocumentsissued") !== null && formContext.getAttribute("rsa_datedocumentsissued") !== "undefined") {
                var dateDocumentsIssuedDate = new Date();
                var recordTypeName = null, salesStage = null;
                var today = Date.now();
                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    recordTypeName = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                }
                var dateDocumentsIssued = formContext.getAttribute("rsa_datedocumentsissued");
                if (dateDocumentsIssued !== null) {
                    dateDocumentsIssuedDate = new Date(dateDocumentsIssued.getValue());
                }



                if (recordTypeName === "New Business - ROI" && dateDocumentsIssuedDate > today) {
                    formContext.getControl("rsa_datedocumentsissued").setNotification("Documents issued cannot be greater than Today's date.", 204);
                }
                else {
                    formContext.getControl("rsa_datedocumentsissued").clearNotification(204);
                }
            }
        } catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "ROIDatenotgreaterthantodayfordocs -" + err.message });
        }
    },

    //Author : Prachi Paunikar
    //Date_Created : 02 Nov 2020
    ProductClass: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            var cobID;


            var globalContext = Xrm.Utility.getGlobalContext();
            if (formContext.getAttribute("rsa_classofbusiness").getValue() !== null) {
                cobID = formContext.getAttribute("rsa_classofbusiness").getValue()[0].id;
                var req = new XMLHttpRequest();
                // req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v9.1/rsa_productclasses?$select=_rsa_classofbusinessid_value,_rsa_lineofbusiness_value,rsa_name,_rsa_pl_value&$filter=_rsa_classofbusinessid_value eq " + cobID, false);
                req.open("GET", globalContext.getClientUrl() + "/api/data/v9.1/rsa_productclasses?$select=_rsa_classofbusinessid_value,_rsa_lineofbusiness_value,rsa_name,_rsa_pl_value&$filter=_rsa_classofbusinessid_value eq " + cobID, false);
                req.setRequestHeader("OData-MaxVersion", "4.0");
                req.setRequestHeader("OData-Version", "4.0");
                req.setRequestHeader("Accept", "application/json");
                req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                req.onreadystatechange = function () {
                    if (this.readyState === 4) {
                        req.onreadystatechange = null;
                        if (this.status === 200) {
                            var results = JSON.parse(this.response);

                            if (results.value.length === 0) {
                                formContext.getAttribute("rsa_productclassid").setRequiredLevel("none");

                            }
                            else {
                                formContext.getAttribute("rsa_productclassid").setRequiredLevel("required");
                            }

                        } else {
                            //Xrm.Utility.alertDialog(this.statusText);
                            Xrm.Navigation.openAlertDialog(this.statusText);
                        }
                    }
                };
                req.send();

            }
            else {
                formContext.getAttribute("rsa_productclassid").setRequiredLevel("none");
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: " ProductClass -" + err.message });
        }
    },


    RSA_GWP_PC: function (executionContext) {
        try {
            /* var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_totalgwp100gsl") !== null && formContext.getAttribute("rsa_totalgwp100gsl") !== "undefined" && formContext.getAttribute("rsa_rsasharegsl") !== null && formContext.getAttribute("rsa_rsasharegsl") !== "undefined" && formContext.getAttribute("rsa_rsagwppc") !== null && formContext.getAttribute("rsa_rsagwppc") !== "undefined") {

                var RSAGWPPC, GWP100PC, RSAShare;


                if (formContext.getAttribute("rsa_totalgwp100gsl").getValue() !== null) {
                    GWP100PC = formContext.getAttribute("rsa_totalgwp100gsl").getValue();
                }

                if (formContext.getAttribute("rsa_totalgwp100gsl").getValue() === "undefined" || formContext.getAttribute("rsa_totalgwp100gsl").getValue() === null) {
                    GWP100PC = 1;
                }

                if (formContext.getAttribute("rsa_rsasharegsl").getValue() !== null) {
                    RSAShare = formContext.getAttribute("rsa_rsasharegsl").getValue() / 100;
                }

                if (formContext.getAttribute("rsa_rsasharegsl").getValue() === "undefined" || formContext.getAttribute("rsa_rsasharegsl").getValue() === null) {
                    RSAShare = 1;
                }

                RSAGWPPC = RSAShare * GWP100PC;

                if (formContext.getAttribute("rsa_rsasharegsl").getValue() === null && formContext.getAttribute("rsa_totalgwp100gsl").getValue() === null)
                    RSAGWPPC = 0;

                formContext.getAttribute("rsa_rsagwppc").setValue(RSAGWPPC);

            } */
        } catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "RSA GWP (PC) -" + err.message });
        }
    },

    ExpiryDate: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_expirydatemarine") !== null && formContext.getAttribute("rsa_expirydatemarine") !== undefined && formContext.getAttribute("rsa_closedate") !== null && formContext.getAttribute("rsa_closedate") !== undefined) {
                var renewalDate, lineOfBusiness;
                // var timeOffset = Xrm.Utility.getGlobalContext().userSettings.getTimeZoneOffsetMinutes();
                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    lineOfBusiness = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                }
                if (formContext.getAttribute("rsa_closedate") !== null && formContext.getAttribute("rsa_closedate") !== undefined) {
                    if (formContext.getAttribute("rsa_closedate").getValue() !== null && formContext.getAttribute("rsa_closedate").getValue() !== undefined && lineOfBusiness !== "New Business - Marine London") {
                        renewalDate = new Date(formContext.getAttribute("rsa_closedate").getValue());

                        var newDate = new Date(
                            renewalDate.getFullYear() + 1,
                            renewalDate.getMonth(),
                            renewalDate.getDate() - 1

                        );

                        newDate.setMinutes(newDate.getMinutes() + 400);


                        formContext.getAttribute("rsa_expirydatemarine").setValue(newDate);

                    }

                }




            }

        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "ExpiryDate -" + err.message });
        }
    },

    MandatoryCheckTPGrossORnetofcomm: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_opportunitystage") !== null && formContext.getAttribute("rsa_opportunitystage") !== "undefined" && formContext.getAttribute("rsa_totalgwp100pc") !== null && formContext.getAttribute("rsa_totalgwp100pc") !== "undefined" && formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined") {
                var stage;
                if (formContext.getAttribute("rsa_opportunitystage").getValue() !== null) {
                    stage = formContext.getAttribute("rsa_opportunitystage").getValue()[0].name;
                }
                var tpgrossornetofcomm = formContext.getAttribute("rsa_tpgrossornetofcomm").getValue();
                var recordTypeName;
                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    recordTypeName = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                }
                //Quoted:866760005, Accepted:866760019, Extended :866760052, Renewed: 866760022, Indication:866760011
                if (tpgrossornetofcomm === null && stage === "Quoted") {
                    //formContext.getControl("rsa_totalgwp100pc").setNotification("Print Total GWP 100% (PC) : You must enter a value.", 209);
                    formContext.getAttribute("rsa_tpgrossornetofcomm").setRequiredLevel("required");
                }
                else {
                    //formContext.getControl("rsa_totalgwp100pc").clearNotification(209);
                    formContext.getAttribute("rsa_tpgrossornetofcomm").setRequiredLevel("none");
                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "MandatoryCheckTPGrossORnetofcomm -" + err.message });
        }
    },

    //Author : Prachi Paunikar
    //Date_Created : 29 Dec 2020
    CountOutcomeReason: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            var stageid, count;
            if (formContext.getAttribute("rsa_outcomereasonid") === null)
                return;
            if (formContext.ui.getFormType() === 1 && formContext.getAttribute("rsa_opportunitystage").getValue() === null)
                formContext.getControl("rsa_outcomereasonid").setDisabled(true);
            var globalContext = Xrm.Utility.getGlobalContext();
            if (formContext.getAttribute("rsa_opportunitystage").getValue() !== null && formContext.getAttribute("rsa_outcomereasonid") !== null) {
                stageid = formContext.getAttribute("rsa_opportunitystage").getValue()[0].id.replace(/[{}]/g, '');
                var req = new XMLHttpRequest();
                //req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v9.1/rsa_outcomereasons?$select=_rsa_lineofbusiness_value,_rsa_stage_value&$filter=_rsa_stage_value eq " + stageid, false);
                req.open("GET", globalContext.getClientUrl() + "/api/data/v9.1/rsa_outcomereasons?$select=_rsa_lineofbusiness_value,_rsa_stage_value&$filter=_rsa_stage_value eq " + stageid, false);
                req.setRequestHeader("OData-MaxVersion", "4.0");
                req.setRequestHeader("OData-Version", "4.0");
                req.setRequestHeader("Accept", "application/json");
                req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                req.onreadystatechange = function () {
                    if (this.readyState === 4) {
                        req.onreadystatechange = null;
                        if (this.status === 200) {
                            var results = JSON.parse(this.response);

                            count = results.value.length;

                        } else {
                            // Xrm.Utility.alertDialog(this.statusText);
                            Xrm.Navigation.openAlertDialog(this.statusText);
                        }
                    }
                };
                req.send();
                return count;

            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: " Outcome Reason -" + err.message });
        }
    },

    OutcomeReason: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            var getCount;
            if (formContext.getAttribute("rsa_outcomereasonid") === null)
                return;
            if (formContext.ui.getFormType() === 1 && formContext.getAttribute("rsa_opportunitystage").getValue() === null) {
                formContext.getControl("rsa_outcomereasonid").setDisabled(true);
                formContext.getAttribute("rsa_outcomereasonid").setValue(null);
            }
            if (formContext.getAttribute("rsa_opportunitystage").getValue() !== null && formContext.getAttribute("rsa_outcomereasonid") !== null) {
                getCount = RSA.D365CRM.Opportunity.Main.CountOutcomeReason(executionContext);
                if (getCount !== 0)
                    formContext.getControl("rsa_outcomereasonid").setDisabled(false);
                //formContext.getAttribute("rsa_outcomereasonid").setValue(null);
                else
                    formContext.getControl("rsa_outcomereasonid").setDisabled(true);
                formContext.getAttribute("rsa_outcomereasonid").setValue(null);
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: " Outcome Reason -" + err.message });
        }
    },




    CheckNDARoleForNDAField: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_nda") !== null && formContext.getAttribute("rsa_nda") !== undefined) {
                var roles = Xrm.Utility.getGlobalContext().userSettings.securityRoles;

                if (roles === null)
                    return false;
                var hasRole = false;
                roles.forEach(function (item) {
                    if (item === "ff4d4095-fc61-eb11-a812-000d3ada7d72")
                        hasRole = true;
                });

                if (hasRole === true) {
                    formContext.getControl("rsa_nda").setVisible(true);
                }
                else {
                    formContext.getControl("rsa_nda").setVisible(false);
                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "CheckNDARoleForNDAField -" + err.message });
        }
    },

    AllowOnlyNumbers: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_rsaatlasclientid") !== undefined && formContext.getAttribute("rsa_rsaatlasclientid") !== null && formContext.getAttribute("rsa_rsaatlasclientid").getValue() !== undefined && formContext.getAttribute("rsa_rsaatlasclientid").getValue() !== null) {

                var atlasclientid = formContext.getAttribute("rsa_rsaatlasclientid").getValue();
                {
                    var rexp = /^[0-9]*$/;
                    if (!atlasclientid.match(rexp)) {
                        formContext.getControl("rsa_rsaatlasclientid").setNotification("Please enter the numeric value", 200);
                    }
                    else {
                        formContext.getControl("rsa_rsaatlasclientid").clearNotification(200);
                    }
                }
            }
            if (formContext.getAttribute("rsa_rsapolicylimitpc") !== undefined && formContext.getAttribute("rsa_rsapolicylimitpc") !== null && formContext.getAttribute("rsa_rsapolicylimitpc").getValue() !== undefined && formContext.getAttribute("rsa_rsapolicylimitpc").getValue() !== null) {

                var policylimitpc = formContext.getAttribute("rsa_rsapolicylimitpc").getValue();
                {
                    var rexp = /^[0-9]*$/;
                    if (!policylimitpc.match(rexp)) {
                        formContext.getControl("rsa_rsapolicylimitpc").setNotification("Please enter the numeric value", 201);
                    }
                    else {
                        formContext.getControl("rsa_rsapolicylimitpc").clearNotification(201);
                    }
                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "AllowOnlyNumbers -" + err.message });
        }
    },


    TriggerChangeOnLoadOfForm: function (executionContext) {
        try {


            var formContext = executionContext.getFormContext();
            var recordId = formContext.data.entity.getId().replace('{', '').replace('}', ''); // get records id to pass the GDPR lockfield function
            RSA.D365CRM.Opportunity.Main.LockFields(executionContext, recordId);

            var globalContext = Xrm.Utility.getGlobalContext();
            var req = new XMLHttpRequest();
            req.open("GET", globalContext.getClientUrl() + "/api/data/v9.1/rsa_customlabels?$select=rsa_dependentoptionsetjson&$filter=rsa_name eq 'OpportunityNumberToPercentConversion'", false);
            // req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v9.1/rsa_customlabels?$select=rsa_dependentoptionsetjson&$filter=rsa_name eq 'OpportunityNumberToPercentConversion'", false);
            req.setRequestHeader("OData-MaxVersion", "4.0");
            req.setRequestHeader("OData-Version", "4.0");
            req.setRequestHeader("Accept", "application/json");
            req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
            req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            req.onreadystatechange = function () {
                if (this.readyState === 4) {
                    req.onreadystatechange = null;
                    if (this.status === 200) {
                        var results = JSON.parse(this.response);
                        for (var i = 0; i < results.value.length; i++) {
                            var rsa_dependentoptionsetjson = results.value[i]["rsa_dependentoptionsetjson"];
                            var NumberToPercent = JSON.parse(results.value[i]["rsa_dependentoptionsetjson"]).NumberToPercent;

                            for (var j = 0; j < NumberToPercent.length; j++) {

                                var schemaName = NumberToPercent[j].SchemaName;

                                if (formContext.getAttribute(schemaName) !== null && formContext.getAttribute(schemaName) !== undefined) {
                                    //formContext.getAttribute(schemaName).addOnChange(RSA.D365CRM.Opportunity.Main.ConvertNumberToPercent);
                                    if (formContext.getAttribute(schemaName).getIsDirty()) {
                                        RSA.D365CRM.Opportunity.Main.ConvertNumberToPercent(executionContext, schemaName);
                                    }
                                    else {
                                        //Do Nothing
                                    }
                                }
                            }

                        }
                    } else {
                        //Xrm.Utility.alertDialog(this.statusText);
                        Xrm.Navigation.openAlertDialog(this.statusText);
                    }
                }
            };
            req.send();


        } catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "TriggerChangeOnLoadOfForm -" + err.message });
        }
    },

    ConvertNumberToPercent: function (executionContext, fieldName) {
        try {
            var formContext = executionContext.getFormContext();
            //var fieldName = executionContext.getEventSource().getName();

            if (formContext.getAttribute(fieldName) !== null && formContext.getAttribute(fieldName) !== "undefined" && formContext.getAttribute(fieldName).getValue() !== null && formContext.getAttribute(fieldName).getValue() !== "undefined") {

                //Get Number field value and divide it by 100
                var fieldValueinPercent = formContext.getAttribute(fieldName).getValue() / 100;

                //Set Percentage value in same field
                formContext.getAttribute(fieldName).setValue(fieldValueinPercent);

            }
        } catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "ConvertNumberToPercent -" + err.message });
        }
    },


    RSAQuotedPremiumCheckForAllRenewals: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();

            var recordTypeName, quotedPremium, opptyStage;

            if (formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined" && formContext.getAttribute("rsa_opportunitystage") !== null & formContext.getAttribute("rsa_opportunitystage") !== "undefined") {

                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    recordTypeName = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                }

                if (formContext.getAttribute("rsa_opportunitystage").getValue() !== null) {
                    opptyStage = formContext.getAttribute("rsa_opportunitystage").getValue()[0].name;
                }

                if (((recordTypeName.indexOf("Renewal") !== -1) || (recordTypeName.indexOf("New Business") !== -1)) && (opptyStage === "Lapsed" || opptyStage === "Renewed" || opptyStage === "Quoted")) {
                    if (formContext.getAttribute("rsa_rsaquotedpremium") !== null) {
                        if (formContext.getAttribute("rsa_rsaquotedpremium").getValue() === null) {
                            formContext.ui.clearFormNotification("2312");
                            formContext.ui.clearFormNotification("2369");
                            formContext.getAttribute("rsa_rsaquotedpremium").setRequiredLevel("required");
                        }


                        else {
                            let a = formContext.getAttribute("rsa_rsaquotedpremium") !== null ? formContext.getAttribute("rsa_rsaquotedpremium").getValue() : 1;
                            let b = formContext.getAttribute("rsa_commission") !== null ? formContext.getAttribute("rsa_commission").getValue() : 1;
                            if (((recordTypeName.indexOf("Renewal") !== -1) || (recordTypeName.indexOf("New Business") !== -1)) && (opptyStage === "Lapsed" || opptyStage === "Renewed" || opptyStage === "Quoted") && (a === 0)) {
                                formContext.ui.setFormNotification("Please confirm the values in RSA Quoted Premium field  . ", "INFO", "2312");
                            }
                            else {
                                formContext.ui.clearFormNotification("2312");

                            }
                            if (((recordTypeName.indexOf("Renewal") !== -1) || (recordTypeName.indexOf("New Business") !== -1)) && (opptyStage === "Quoted") && (b === 0)) {
                                formContext.ui.setFormNotification("Please confirm the values in Commission % . ", "INFO", "2369");
                            }
                            else {
                                formContext.ui.clearFormNotification("2369");
                                //updated 
                            }
                        }
                    }
                }
            }
        } catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "RSAQuotedPremiumCheckForAllRenewals -" + err.message });
        }
    },

    //Date: 14-11-2024
    /* Change Summary for CR-421 , CR-422 
    Modified By : Mohit 
    Summary of Changes : set Notification if value is 0
    Function Name : SLUnderwriterFieldForRealEstateNBRenewal
    */

    SLUnderwriterFieldForRealEstateNBRenewal: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            var oppRecordTypeName, oppStageName, pAndL, classOfBusiness;
            if (formContext.getAttribute("rsa_pandlid") !== null) {
                if (formContext.getAttribute("rsa_pandlid").getValue() !== null) {
                    pAndL = formContext.getAttribute("rsa_pandlid").getValue()[0].name;
                }
            }
            if (formContext.getAttribute("rsa_classofbusiness") !== null) {
                if (formContext.getAttribute("rsa_classofbusiness").getValue() !== null) {
                    classOfBusiness = formContext.getAttribute("rsa_classofbusiness").getValue()[0].name;
                }
            }

            if (formContext.getAttribute("rsa_lineofbusiness") !== null) {

                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    oppRecordTypeName = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                }
            }
            if (formContext.getAttribute("rsa_opportunitystage") !== null) {
                if (formContext.getAttribute("rsa_opportunitystage").getValue() !== null) {
                    oppStageName = formContext.getAttribute("rsa_opportunitystage").getValue()[0].name;
                }
            }
            let commissionUnderlying = formContext.getAttribute("rsa_commissionunderlying") !== null ? formContext.getAttribute("rsa_commissionunderlying").getValue() : 1;
            let workTransfer = formContext.getAttribute("rsa_worktransfer1") !== null ? formContext.getAttribute("rsa_worktransfer1").getValue() : 1;
            let riskManagementBursary = formContext.getAttribute("rsa_rsariskmanagementbursary_dc") !== null ? formContext.getAttribute("rsa_rsariskmanagementbursary_dc").getValue() : 1;
            let potentialProfitShare = formContext.getAttribute("rsa_potentialprofitshare_dc") !== null ? formContext.getAttribute("rsa_potentialprofitshare_dc").getValue() : 1;
            let terrorismCommissionrsaShare = formContext.getAttribute("rsa_terrorismcommissionrsashare") !== null ? formContext.getAttribute("rsa_terrorismcommissionrsashare").getValue() : 1;

            if (
                ((oppRecordTypeName === "New Business - Real Estate") && (oppStageName === "Accepted") && (pAndL === "GSL - Real Estate")) ||
                ((oppRecordTypeName === "Renewal - Real Estate") && (oppStageName === "Renewed") && (pAndL === "GSL - Real Estate"))
            ) {
                if ((classOfBusiness === "Real Estate - Combined") ||
                    (classOfBusiness === "Real Estate - Contract Works") ||
                    (classOfBusiness === "Real Estate - Liability") ||
                    (classOfBusiness === "Real Estate - Property Owners") ||
                    (classOfBusiness === "Real Estate - Property")
                ) {

                    if (commissionUnderlying === 0) {
                        formContext.ui.setFormNotification("Please confirm the values in Commission Underlying % field  . ", "INFO", "commissionunderlying");
                    } else {
                        formContext.ui.clearFormNotification("commissionunderlying");
                    }
                    if (workTransfer === 0) {
                        formContext.ui.setFormNotification("Please confirm the values in work Transfer % field  . ", "INFO", "workTransfer");
                    } else {
                        formContext.ui.clearFormNotification("workTransfer");
                    }
                    if (riskManagementBursary === 0) {
                        formContext.ui.setFormNotification("Please confirm the values in Risk Management Bursary - Â£ field  . ", "INFO", "riskManagementBursary");
                    } else {
                        formContext.ui.clearFormNotification("riskManagementBursary");
                    }
                    if (potentialProfitShare === 0) {
                        formContext.ui.setFormNotification("Please confirm the values in Potential Profit Share Â£ field  . ", "INFO", "potentialProfitShare");
                    } else {
                        formContext.ui.clearFormNotification("potentialProfitShare");
                    }
                    if (terrorismCommissionrsaShare === 0) {
                        formContext.ui.setFormNotification("Please confirm the values in Terrorism Commission % (RSA Share) field  . ", "INFO", "terrorismCommissionrsaShare");
                    } else {
                        formContext.ui.clearFormNotification("terrorismCommissionrsaShare");
                    }
                } else {
                    formContext.ui.clearFormNotification("commissionunderlying");
                    formContext.ui.clearFormNotification("workTransfer");
                    formContext.ui.clearFormNotification("riskManagementBursary");
                    formContext.ui.clearFormNotification("potentialProfitShare");
                    formContext.ui.clearFormNotification("terrorismCommissionrsaShare");
                }
            } else {
                formContext.ui.clearFormNotification("commissionunderlying");
                formContext.ui.clearFormNotification("workTransfer");
                formContext.ui.clearFormNotification("riskManagementBursary");
                formContext.ui.clearFormNotification("potentialProfitShare");
                formContext.ui.clearFormNotification("terrorismCommissionrsaShare");
            }
        } catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "SLUnderwriterFieldForRealEstateNBRenewal -" + err.message });
        }
    },






    MandatoryForRenewal: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();

            var recordTypeName, opptyStage;
            // Samiksha Dhakde: 08/09/2022
            // CR:2159 Hiding of currency symbol: Replacing currency field to decimal field: rsa_technicalprice to rsa_opptytechnicalprice_dc.
            if (formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined" && formContext.getAttribute("rsa_thisyrsexplastyrsrates") !== null && formContext.getAttribute("rsa_thisyrsexplastyrsrates") !== "undefined" && formContext.getAttribute("rsa_opptytechnicalprice_dc") !== null && formContext.getAttribute("rsa_opptytechnicalprice_dc") !== "undefined" && formContext.getAttribute("rsa_opportunitystage") !== null & formContext.getAttribute("rsa_opportunitystage") !== "undefined") {

                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    recordTypeName = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                }

                if (formContext.getAttribute("rsa_opportunitystage").getValue() !== null) {
                    opptyStage = formContext.getAttribute("rsa_opportunitystage").getValue()[0].name;
                }


                //This Yrs Exp @ Last Yrs Rates
                if (recordTypeName.indexOf("Renewal") !== -1 && (opptyStage === "Lapsed" || opptyStage === "Renewed" || opptyStage === "Quoted") && formContext.getAttribute("rsa_thisyrsexplastyrsrates").getValue() === null) {
                    formContext.ui.clearFormNotification("2314");
                    formContext.getAttribute("rsa_thisyrsexplastyrsrates").setRequiredLevel("required");
                }
                else {
                    if (recordTypeName.indexOf("Renewal") !== -1 && (opptyStage === "Lapsed" || opptyStage === "Renewed" || opptyStage === "Quoted") && formContext.getAttribute("rsa_thisyrsexplastyrsrates").getValue() === 0) {
                        formContext.ui.setFormNotification("Please confirm the values in This Yrs Exp @ Last Yrs Rates field. ", "INFO", "2314");
                    }
                    else {
                        formContext.ui.clearFormNotification("2314");
                    }
                }

                //Gross RSA 100% Technical Price
                // Samiksha Dhakde: 08/09/2022
                // CR:2159 Hiding of currency symbol: Replacing currency field to decimal field: rsa_technicalprice to rsa_opptytechnicalprice_dc.
                if (recordTypeName.indexOf("Renewal") !== -1 && (opptyStage === "Lapsed" || opptyStage === "Renewed" || opptyStage === "Quoted") && formContext.getAttribute("rsa_opptytechnicalprice_dc").getValue() === null) {
                    formContext.ui.clearFormNotification("2315");
                    formContext.getAttribute("rsa_opptytechnicalprice_dc").setRequiredLevel("required");
                }
                else {
                    if (recordTypeName.indexOf("Renewal") !== -1 && (opptyStage === "Lapsed" || opptyStage === "Renewed" || opptyStage === "Quoted") && formContext.getAttribute("rsa_opptytechnicalprice_dc").getValue() === 0) {
                        formContext.ui.setFormNotification("Please confirm the values in Gross RSA 100% Technical Price field. ", "INFO", "2315");
                    }
                    else {
                        formContext.ui.clearFormNotification("2315");
                    }
                }

            }
        } catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "MandatoryForRenewal -" + err.message });
        }
    },

    LondonPercentFields: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();

            var recordTypeName, opptyStage;

            if (formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined" && formContext.getAttribute("rsa_opportunitystage") !== null && formContext.getAttribute("rsa_opportunitystage") !== "undefined" && formContext.getAttribute("rsa_opportunitystage").getValue() !== null && formContext.getAttribute("rsa_writtenlinepc") !== null && formContext.getAttribute("rsa_writtenlinepc") !== "undefined" && formContext.getAttribute("rsa_orderpc") !== null && formContext.getAttribute("rsa_orderpc") !== "undefined") {

                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    recordTypeName = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                }

                if (formContext.getAttribute("rsa_opportunitystage").getValue() !== null) {
                    opptyStage = formContext.getAttribute("rsa_opportunitystage").getValue()[0].name;
                }

                //Written Line %
                if (recordTypeName.indexOf("Marine London") !== -1 && (opptyStage === "Accepted" || opptyStage === "Renewed" || opptyStage === "Quoted") && formContext.getAttribute("rsa_writtenlinepc").getValue() === null) {
                    formContext.ui.clearFormNotification("2320");
                    formContext.getControl("rsa_writtenlinepc").setNotification("You must enter a value.", "2317");
                }
                else {

                    if (formContext.getAttribute("rsa_writtenlinepc").getValue() < 0 || formContext.getAttribute("rsa_writtenlinepc").getValue() > 100) {
                        formContext.getControl("rsa_writtenlinepc").clearNotification("2317");
                        formContext.getControl("rsa_writtenlinepc").setNotification("Please enter a value greater than 0 and less than or equal to 100.", "2320");
                    }
                    else if (recordTypeName.indexOf("Marine London") !== -1 && (opptyStage === "Accepted" || opptyStage === "Renewed" || opptyStage === "Quoted") && formContext.getAttribute("rsa_writtenlinepc").getValue() === 0) {
                        formContext.getControl("rsa_writtenlinepc").clearNotification("2317");
                        formContext.getControl("rsa_writtenlinepc").clearNotification("2320");
                        formContext.ui.setFormNotification("Please confirm the values in Written Line %. ", "INFO", "2316");
                    }
                    else {
                        formContext.ui.clearFormNotification("2316");
                        formContext.getControl("rsa_writtenlinepc").clearNotification("2317");
                        formContext.getControl("rsa_writtenlinepc").clearNotification("2320");
                    }
                }

                //Order %
                if (recordTypeName.indexOf("Marine London") !== -1 && (opptyStage === "Accepted" || opptyStage === "Renewed" || opptyStage === "Quoted") && formContext.getAttribute("rsa_orderpc").getValue() === null) {
                    formContext.ui.clearFormNotification("2318");
                    formContext.getControl("rsa_orderpc").setNotification("You must enter a value.", "2319");
                }
                else {

                    if (formContext.getAttribute("rsa_orderpc").getValue() < 0 || formContext.getAttribute("rsa_orderpc").getValue() > 100) {
                        formContext.ui.clearFormNotification("2318");
                        formContext.getControl("rsa_orderpc").clearNotification("2319");
                        formContext.getControl("rsa_orderpc").setNotification("Please enter a value greater than 0 and less than or equal to 100.", "2321");
                    }
                    else if (recordTypeName.indexOf("Marine London") !== -1 && (opptyStage === "Accepted" || opptyStage === "Renewed" || opptyStage === "Quoted") && formContext.getAttribute("rsa_orderpc").getValue() === 0) {
                        formContext.getControl("rsa_orderpc").clearNotification("2319");
                        formContext.getControl("rsa_orderpc").clearNotification("2321");
                        formContext.ui.setFormNotification("Please confirm the values in Order %. ", "INFO", "2318");
                    }
                    else {
                        formContext.ui.clearFormNotification("2318");
                        formContext.getControl("rsa_orderpc").clearNotification("2319");
                        formContext.getControl("rsa_orderpc").clearNotification("2321");
                    }
                }

                //Estimated Signing %
                if (recordTypeName.indexOf("Marine London") !== -1 && (opptyStage === "Accepted" || opptyStage === "Renewed" || opptyStage === "Quoted") && formContext.getAttribute("rsa_signedpc").getValue() === null) {
                    formContext.ui.clearFormNotification("2323");
                    formContext.getControl("rsa_signedpc").setNotification("You must enter a value.", "2322");
                }
                else {

                    if (formContext.getAttribute("rsa_signedpc").getValue() < 0 || formContext.getAttribute("rsa_signedpc").getValue() > 100) {
                        formContext.ui.clearFormNotification("2323");
                        formContext.getControl("rsa_signedpc").clearNotification("2322");
                        formContext.getControl("rsa_signedpc").setNotification("Please enter a value greater than 0 and less than or equal to 100.", "2324");
                    }
                    else if (recordTypeName.indexOf("Marine London") !== -1 && (opptyStage === "Accepted" || opptyStage === "Renewed" || opptyStage === "Quoted") && formContext.getAttribute("rsa_signedpc").getValue() === 0) {
                        formContext.getControl("rsa_signedpc").clearNotification("2322");
                        formContext.getControl("rsa_signedpc").clearNotification("2324");
                        formContext.ui.setFormNotification("Please confirm the values in Estimated Signed %. ", "INFO", "2323");
                    }
                    else {
                        formContext.ui.clearFormNotification("2323");
                        formContext.getControl("rsa_signedpc").clearNotification("2322");
                        formContext.getControl("rsa_signedpc").clearNotification("2324");
                    }
                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "LondonPercentFields -" + err.message });
        }
    },

    RatingSegmentPosition: function (executionContext) {

        try {
            var formContext = executionContext.getFormContext();
            if (formContext.ui.getFormType() === 1) {
                return;
            }
            var recordId = formContext.data.entity.getId();

            var recordTypeName, opptyStage, ratingSegmentPosition;
            var rsa_distribution = null, distributionMethod = null, customerType = null, methodOfPayment = null, insuredsCountryOfDomicile = null, fullValuePrimaryxolQuotashare = null, annualProject = null, wordingType = null, datetermsRequiredByBrokerCustomer = null, datetermsIssuedToBrokerCustomer = null, manufacturingStatus = null, leadFollow = null;

            if (formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined" && formContext.getAttribute("rsa_opportunitystage") !== null && formContext.getAttribute("rsa_opportunitystage") !== "undefined") {

                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    recordTypeName = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                }

                if (formContext.getAttribute("rsa_opportunitystage").getValue() !== null) {
                    opptyStage = formContext.getAttribute("rsa_opportunitystage").getValue()[0].name;
                }
                localStorage['OpportunityStage'] = opptyStage;
                localStorage['recordTypeName'] = recordTypeName;
                var globalContext = Xrm.Utility.getGlobalContext();
                var req = new XMLHttpRequest();
                // req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v9.1/rsa_extensionopportunities?$select=rsa_ratingsegmentposition&$filter=_rsa_opportunity_value eq " + recordId, false);
                req.open("GET", globalContext.getClientUrl() + "/api/data/v9.1/rsa_extensionopportunities?$select=rsa_ratingsegmentposition,rsa_distribution,rsa_distributionmethod,rsa_customertype,rsa_methodofpayment,_rsa_insuredscountryofdomicile_value,rsa_fullvalueprimaryxolquotashare,rsa_annualproject,rsa_wordingtype,rsa_datetermsrequiredbybrokercustomer,rsa_datetermsissuedtobrokercustomer,rsa_manufacturingstatus,rsa_leadfollow&$filter=_rsa_opportunity_value eq " + recordId, false);
                req.setRequestHeader("OData-MaxVersion", "4.0");
                req.setRequestHeader("OData-Version", "4.0");
                req.setRequestHeader("Accept", "application/json");
                req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                req.onreadystatechange = function () {
                    if (this.readyState === 4) {
                        req.onreadystatechange = null;
                        if (this.status === 200) {
                            var results = JSON.parse(this.response);
                            for (var i = 0; i < results.value.length; i++) {
                                ratingSegmentPosition = results.value[i]["rsa_ratingsegmentposition"];
                                rsa_distribution = results.value[i]["rsa_distribution"];
                                distributionMethod = results.value[i]["rsa_distributionmethod"];
                                customerType = results.value[i]["rsa_customertype"];
                                methodOfPayment = results.value[i]["rsa_methodofpayment"];
                                insuredsCountryOfDomicile = results.value[i]["_rsa_insuredscountryofdomicile_value"];
                                fullValuePrimaryxolQuotashare = results.value[i]["rsa_fullvalueprimaryxolquotashare"];
                                annualProject = results.value[i]["rsa_annualproject"];
                                wordingType = results.value[i]["rsa_wordingtype"];
                                datetermsRequiredByBrokerCustomer = results.value[i]["rsa_datetermsrequiredbybrokercustomer"];
                                datetermsIssuedToBrokerCustomer = results.value[i]["rsa_datetermsissuedtobrokercustomer"];
                                //datetermsAgreedWithCustomerBroker = results.value[i]["rsa_datetermsagreedwithcustomerbroker"];
                                //productName = results.value[i]["rsa_productname"];
                                manufacturingStatus = results.value[i]["rsa_manufacturingstatus"];
                                leadFollow = results.value[i]["rsa_leadfollow"];

                            }
                        } else {
                            //Xrm.Utility.alertDialog(this.statusText);
                            Xrm.Navigation.openAlertDialog(this.statusText);
                        }
                    }
                };
                req.send();


                /*  if (recordTypeName === "Renewal - Motor" && (opptyStage === "Lapsed" || opptyStage === "Renewed" || opptyStage === "Quoted") && ratingSegmentPosition === null) {
                      localStorage['OpportunityStage'] = opptyStage;
                      formContext.ui.setFormNotification("Rating Segment Position must be input into Opportunity Extension before saving record ", "ERROR", "3000");
                      executionContext.getEventArgs().preventDefault();
                  }
                  else {
                      // localStorage['OpportunityStage'] = '';
                      formContext.ui.clearFormNotification("3000");
                  }*/

                if ((recordTypeName == "GSL - New Business" || recordTypeName === "GSL - Renewal"
                    || recordTypeName === "New Business - Marine London"
                    || recordTypeName === "New Business - Real Estate"
                    || recordTypeName === "Renewal - Marine London"
                    || recordTypeName === "Renewal - Real Estate")
                    && (opptyStage === "Renewed" || opptyStage === "Accepted") && rsa_distribution === null) {
                    localStorage['OpportunityStage'] = opptyStage;
                    formContext.ui.setFormNotification("Distribution must be input into Opportunity Extension before saving record ", "ERROR", "101");
                    executionContext.getEventArgs().preventDefault();


                } else {

                    formContext.ui.clearFormNotification("101");
                }
                /* if ((recordTypeName === "Renewal - Motor" || recordTypeName == "GSL - New Business" || recordTypeName === "Computer (eï¿½Traded) New Business" || recordTypeName === "Computer (eï¿½Traded) Renewal" || recordTypeName === "ESI" || recordTypeName === "Extension New Business" || recordTypeName === "GSL - Renewal" || recordTypeName === "New Business" || recordTypeName === "New Business - Marine London" || recordTypeName === "New Business - Marine Regional" || recordTypeName === "New Business - Real Estate" || recordTypeName === "New Business - Schemes & Deals" || recordTypeName === "Renewal" || recordTypeName === "Renewal - Marine London" || recordTypeName === "Renewal - Marine Regional" || recordTypeName === "Renewal - Profin" || recordTypeName === "Renewal - Real Estate" || recordTypeName === "Renewal - SME" || recordTypeName === "SME Deals") && (opptyStage === "Renewed" || opptyStage === "Accepted") && distributionMethod === null) {
                     localStorage['OpportunityStage'] = opptyStage;
                     formContext.ui.setFormNotification("Distribution Method must be input into Opportunity Extension before saving record ", "ERROR", "102");
                     executionContext.getEventArgs().preventDefault();
 
 
                 } else {
 
                     formContext.ui.clearFormNotification("102");
                 }*/

                if ((recordTypeName == "GSL - New Business" || recordTypeName === "GSL - Renewal"
                    || recordTypeName === "New Business - Marine London"
                    || recordTypeName === "New Business - Real Estate"
                    || recordTypeName === "Renewal - Marine London"
                    || recordTypeName === "Renewal - Real Estate")
                    && (opptyStage === "Renewed" || opptyStage === "Accepted") && customerType === null) {
                    localStorage['OpportunityStage'] = opptyStage;
                    formContext.ui.setFormNotification("CustomerType must be input into Opportunity Extension before saving record ", "ERROR", "103");
                    executionContext.getEventArgs().preventDefault();


                } else {

                    formContext.ui.clearFormNotification("103");
                }
                /* if ((recordTypeName === "Renewal - Motor" || recordTypeName == "GSL - New Business" || recordTypeName === "Computer (eï¿½Traded) New Business" || recordTypeName === "Computer (eï¿½Traded) Renewal" || recordTypeName === "ESI" || recordTypeName === "Extension New Business" || recordTypeName === "GSL - Renewal" || recordTypeName === "New Business" || recordTypeName === "New Business - Marine London" || recordTypeName === "New Business - Marine Regional" || recordTypeName === "New Business - Real Estate" || recordTypeName === "New Business - Schemes & Deals" || recordTypeName === "Renewal" || recordTypeName === "Renewal - Marine London" || recordTypeName === "Renewal - Marine Regional" || recordTypeName === "Renewal - Profin" || recordTypeName === "Renewal - Real Estate" || recordTypeName === "Renewal - SME" || recordTypeName === "SME Deals") && (opptyStage === "Renewed" || opptyStage === "Accepted") && methodOfPayment === null) {
                     localStorage['OpportunityStage'] = opptyStage;
                     formContext.ui.setFormNotification("Method of Payment must be input into Opportunity Extension before saving record ", "ERROR", "104");
                     executionContext.getEventArgs().preventDefault();
 
 
                 } else {
 
                     formContext.ui.clearFormNotification("104");
                 }
                 if ((recordTypeName === "Renewal - Motor" || recordTypeName == "GSL - New Business" || recordTypeName === "Computer (eï¿½Traded) New Business" || recordTypeName === "Computer (eï¿½Traded) Renewal" || recordTypeName === "ESI" || recordTypeName === "Extension New Business" || recordTypeName === "GSL - Renewal" || recordTypeName === "New Business" || recordTypeName === "New Business - Marine London" || recordTypeName === "New Business - Marine Regional" || recordTypeName === "New Business - Real Estate" || recordTypeName === "New Business - Schemes & Deals" || recordTypeName === "Renewal" || recordTypeName === "Renewal - Marine London" || recordTypeName === "Renewal - Marine Regional" || recordTypeName === "Renewal - Profin" || recordTypeName === "Renewal - Real Estate" || recordTypeName === "Renewal - SME" || recordTypeName === "SME Deals") && (opptyStage === "Renewed" || opptyStage === "Accepted") && insuredsCountryOfDomicile === null) {
                     localStorage['OpportunityStage'] = opptyStage;
                     formContext.ui.setFormNotification("Insured's Country of Domicile be input into Opportunity Extension before saving record ", "ERROR", "105");
                     executionContext.getEventArgs().preventDefault();
 
 
                 } else {
 
                     formContext.ui.clearFormNotification("105");
                 }*/

                if ((recordTypeName == "GSL - New Business" || recordTypeName === "GSL - Renewal"
                    || recordTypeName === "New Business - Marine London"
                    || recordTypeName === "New Business - Real Estate"
                    || recordTypeName === "Renewal - Marine London"
                    || recordTypeName === "Renewal - Real Estate")
                    && (opptyStage === "Renewed" || opptyStage === "Accepted") && fullValuePrimaryxolQuotashare === null) {
                    localStorage['OpportunityStage'] = opptyStage;
                    formContext.ui.setFormNotification("Full Value / Primary / XOL / Quotashare be input into Opportunity Extension before saving record ", "ERROR", "106");
                    executionContext.getEventArgs().preventDefault();


                } else {

                    formContext.ui.clearFormNotification("106");
                }
                if ((recordTypeName == "GSL - New Business" || recordTypeName === "GSL - Renewal"
                    || recordTypeName === "New Business - Marine London"
                    || recordTypeName === "New Business - Real Estate"
                    || recordTypeName === "Renewal - Marine London"
                    || recordTypeName === "Renewal - Real Estate")
                    && (opptyStage === "Renewed" || opptyStage === "Accepted") && annualProject === null) {
                    localStorage['OpportunityStage'] = opptyStage;
                    formContext.ui.setFormNotification("Annual / Project be input into Opportunity Extension before saving record ", "ERROR", "107");
                    executionContext.getEventArgs().preventDefault();


                } else {

                    formContext.ui.clearFormNotification("107");
                }
                if ((recordTypeName == "GSL - New Business" || recordTypeName === "GSL - Renewal"
                    || recordTypeName === "New Business - Marine London"
                    || recordTypeName === "New Business - Real Estate"
                    || recordTypeName === "Renewal - Marine London"
                    || recordTypeName === "Renewal - Real Estate")
                    && (opptyStage === "Renewed" || opptyStage === "Accepted") && wordingType === null) {
                    localStorage['OpportunityStage'] = opptyStage;
                    formContext.ui.setFormNotification("Wording Type be input into Opportunity Extension before saving record ", "ERROR", "108");
                    executionContext.getEventArgs().preventDefault();


                } else {

                    formContext.ui.clearFormNotification("108");
                }
                if ((recordTypeName === "Renewal - Motor" || recordTypeName == "GSL - New Business" || recordTypeName === "Computer (eï¿½Traded) New Business" || recordTypeName === "Computer (eï¿½Traded) Renewal" || recordTypeName === "ESI" || recordTypeName === "Extension New Business" || recordTypeName === "GSL - Renewal" || recordTypeName === "New Business" || recordTypeName === "New Business - Marine London" || recordTypeName === "New Business - Marine Regional" || recordTypeName === "New Business - Real Estate" || recordTypeName === "New Business - Schemes & Deals" || recordTypeName === "Renewal" || recordTypeName === "Renewal - Marine London" || recordTypeName === "Renewal - Marine Regional" || recordTypeName === "Renewal - Profin" || recordTypeName === "Renewal - Real Estate" || recordTypeName === "Renewal - SME" || recordTypeName === "SME Deals") && (opptyStage === "Renewed" || opptyStage === "Accepted") && datetermsRequiredByBrokerCustomer === null) {
                    localStorage['OpportunityStage'] = opptyStage;
                    formContext.ui.setFormNotification("Date Terms Required by Broker/Customer be input into Opportunity Extension before saving record ", "ERROR", "109");
                    executionContext.getEventArgs().preventDefault();


                } else {

                    formContext.ui.clearFormNotification("109");
                }
                if ((recordTypeName === "Renewal - Motor" || recordTypeName == "GSL - New Business" || recordTypeName === "Computer (eï¿½Traded) New Business" || recordTypeName === "Computer (eï¿½Traded) Renewal" || recordTypeName === "ESI" || recordTypeName === "Extension New Business" || recordTypeName === "GSL - Renewal" || recordTypeName === "New Business" || recordTypeName === "New Business - Marine London" || recordTypeName === "New Business - Marine Regional" || recordTypeName === "New Business - Real Estate" || recordTypeName === "New Business - Schemes & Deals" || recordTypeName === "Renewal" || recordTypeName === "Renewal - Marine London" || recordTypeName === "Renewal - Marine Regional" || recordTypeName === "Renewal - Profin" || recordTypeName === "Renewal - Real Estate" || recordTypeName === "Renewal - SME" || recordTypeName === "SME Deals") && (opptyStage === "Renewed" || opptyStage === "Accepted") && datetermsIssuedToBrokerCustomer === null) {
                    localStorage['OpportunityStage'] = opptyStage;
                    formContext.ui.setFormNotification("Date Terms Issued to Broker/Customer be input into Opportunity Extension before saving record ", "ERROR", "110");
                    executionContext.getEventArgs().preventDefault();


                } else {

                    formContext.ui.clearFormNotification("110");
                }

                if ((recordTypeName == "GSL - New Business" || recordTypeName === "GSL - Renewal"
                    || recordTypeName === "New Business - Marine London"
                    || recordTypeName === "New Business - Real Estate"
                    || recordTypeName === "Renewal - Marine London"
                    || recordTypeName === "Renewal - Real Estate")
                    && (opptyStage === "Renewed" || opptyStage === "Accepted") && manufacturingStatus === null) {
                    localStorage['OpportunityStage'] = opptyStage;
                    formContext.ui.setFormNotification("Manufacturing Status be input into Opportunity Extension before saving record ", "ERROR", "113");
                    executionContext.getEventArgs().preventDefault();


                } else {

                    formContext.ui.clearFormNotification("113");
                }
                if ((recordTypeName === "Renewal - Motor" || recordTypeName == "GSL - New Business" || recordTypeName === "Computer (eï¿½Traded) New Business" || recordTypeName === "Computer (eï¿½Traded) Renewal" || recordTypeName === "ESI" || recordTypeName === "Extension New Business" || recordTypeName === "GSL - Renewal" || recordTypeName === "New Business" || recordTypeName === "New Business - Marine London" || recordTypeName === "New Business - Marine Regional" || recordTypeName === "New Business - Real Estate" || recordTypeName === "New Business - Schemes & Deals" || recordTypeName === "Renewal" || recordTypeName === "Renewal - Marine London" || recordTypeName === "Renewal - Marine Regional" || recordTypeName === "Renewal - Profin" || recordTypeName === "Renewal - Real Estate" || recordTypeName === "Renewal - SME" || recordTypeName === "SME Deals") && (opptyStage === "Renewed" || opptyStage === "Accepted") && leadFollow === null) {
                    localStorage['OpportunityStage'] = opptyStage;
                    formContext.ui.setFormNotification("Lead/Follow be input into Opportunity Extension before saving record ", "ERROR", "114");
                    executionContext.getEventArgs().preventDefault();


                } else {

                    formContext.ui.clearFormNotification("114");
                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "RatingSegmentPosition -" + err.message });
        }
    },

    RatingSegmentPositionForOpportunityExtension: function (executionContext) {

        try {
            var formContext = executionContext.getFormContext();
            var recordTypeName, opptyStage;
            if (formContext.ui.getFormType() === 1) {
                return;
            }
            if (formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined" && formContext.getAttribute("rsa_ratingsegmentposition") !== null && formContext.getAttribute("rsa_ratingsegmentposition") !== "undefined") {

                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {
                    recordTypeName = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
                }

                /* if (window.parent.window[1] !== "undefined" && window.parent.window[1] !== null && window.parent.window[1].Xrm.Page.getAttribute("rsa_opportunitystage") !== "undefined" && window.parent.window[1].Xrm.Page.getAttribute("rsa_opportunitystage") !== null) {
                    opptyStage = window.parent.window[1].Xrm.Page.getAttribute("rsa_opportunitystage").getValue()[0].name;
                } */

                if (localStorage['OpportunityStage'] !== null) {

                    opptyStage = localStorage['OpportunityStage'];
                    // recordTypeName = localStorage["recordTypeName"];
                    /*  if (recordTypeName === "Renewal - Motor" && (opptyStage === "Lapsed" || opptyStage === "Renewed" || opptyStage === "Quoted") && formContext.getAttribute("rsa_ratingsegmentposition").getValue() === null) {
                          formContext.getControl("rsa_ratingsegmentposition").setNotification("Please enter the value in Rating Segment Position", 3001);
                          formContext.getAttribute("rsa_ratingsegmentposition").setRequiredLevel("required");
                      }
                      else {
                          formContext.getControl("rsa_ratingsegmentposition").clearNotification(3001);
                          formContext.getAttribute("rsa_ratingsegmentposition").setRequiredLevel("none");
                      }*/

                    //New Modifications of OpportunityExtention Fields Mandatory
                    //comment start
                    /* if ((recordTypeName == "GSL - New Business" || recordTypeName === "GSL - Renewal"
                         || recordTypeName === "New Business - Marine London"
                         || recordTypeName === "New Business - Real Estate"
                         || recordTypeName === "Renewal - Marine London"
                         || recordTypeName === "Renewal - Real Estate")
                         && (opptyStage === "Renewed" || opptyStage === "Accepted") && formContext.getAttribute("rsa_manufacturingstatus").getValue() === null) {
 
                         // formContext.getControl("rsa_manufacturingstatus").setNotification("Please enter the value in Manufacturingstatus", 3002);
                         formContext.getAttribute("rsa_manufacturingstatus").setRequiredLevel("required");
                     }
                     else {
 
                         //formContext.getControl("rsa_manufacturingstatus").clearNotification(3002);
                         //formContext.getAttribute("rsa_manufacturingstatus").setRequiredLevel("none");
                     }
                     //if ((recordTypeName == "GSL - New Business" || recordTypeName === "GSL - Renewal"
                     //    || recordTypeName === "New Business - Marine London"
                     //    || recordTypeName === "New Business - Real Estate"
                     //    || recordTypeName === "Renewal - Marine London"
                     //    || recordTypeName === "Renewal - Real Estate")
                     //    && (opptyStage === "Renewed" || opptyStage === "Accepted") && formContext.getAttribute("rsa_distribution").getValue() === null) {
 
                     //    // formContext.getControl("rsa_distribution").setNotification("Please enter the value in Distribution", 3003);
                     //    formContext.getAttribute("rsa_distribution").setRequiredLevel("required");
                     //}
                     //else {
                     //    // formContext.getControl("rsa_distribution").clearNotification(3003);
                     //   // formContext.getAttribute("rsa_distribution").setRequiredLevel("none");
                     //}
                     if ((recordTypeName == "GSL - New Business" || recordTypeName === "GSL - Renewal"
                         || recordTypeName === "New Business - Marine London"
                         || recordTypeName === "New Business - Real Estate"
                         || recordTypeName === "Renewal - Marine London"
                         || recordTypeName === "Renewal - Real Estate")
                         && (opptyStage === "Renewed" || opptyStage === "Accepted") && formContext.getAttribute("rsa_customertype").getValue() === null) {
 
                         //formContext.getControl("rsa_customertype").setNotification("Please enter the value in Customer Type", 3004);
                         formContext.getAttribute("rsa_customertype").setRequiredLevel("required");
                     }
                     else {
                         //formContext.getControl("rsa_customertype").clearNotification(3004);
                         //formContext.getAttribute("rsa_customertype").setRequiredLevel("none");
                     }
                     if ((recordTypeName == "GSL - New Business" || recordTypeName === "GSL - Renewal"
                         || recordTypeName === "New Business - Marine London"
                         || recordTypeName === "New Business - Real Estate"
                         || recordTypeName === "Renewal - Marine London"
                         || recordTypeName === "Renewal - Real Estate")
                         && (opptyStage === "Renewed" || opptyStage === "Accepted") && formContext.getAttribute("rsa_fullvalueprimaryxolquotashare").getValue() === null) {
 
                         // formContext.getControl("rsa_fullvalueprimaryxolquotashare").setNotification("Please enter the value in Full Value/Primary/XOL/QuoteShare", 3005);
                         formContext.getAttribute("rsa_fullvalueprimaryxolquotashare").setRequiredLevel("required");
                     }
                     else {
                         //formContext.getControl("rsa_fullvalueprimaryxolquotashare").clearNotification(3005);
                        // formContext.getAttribute("rsa_fullvalueprimaryxolquotashare").setRequiredLevel("none");
                     }
                     if ((recordTypeName == "GSL - New Business" || recordTypeName === "GSL - Renewal"
                         || recordTypeName === "New Business - Marine London"
                         || recordTypeName === "New Business - Real Estate"
                         || recordTypeName === "Renewal - Marine London"
                         || recordTypeName === "Renewal - Real Estate")
                         && (opptyStage === "Renewed" || opptyStage === "Accepted") && formContext.getAttribute("rsa_annualproject").getValue() === null) {
 
                         // formContext.getControl("rsa_annualproject").setNotification("Please Select the Annual/Project  ", 3006);
                         formContext.getAttribute("rsa_annualproject").setRequiredLevel("required");
                     }
                     else {
                         //formContext.getControl("rsa_annualproject").clearNotification(3006);
                        // formContext.getAttribute("rsa_annualproject").setRequiredLevel("none");
                     }
                     if ((recordTypeName == "GSL - New Business" || recordTypeName === "GSL - Renewal"
                         || recordTypeName === "New Business - Marine London"
                         || recordTypeName === "New Business - Real Estate"
                         || recordTypeName === "Renewal - Marine London"
                         || recordTypeName === "Renewal - Real Estate")
                         && (opptyStage === "Renewed" || opptyStage === "Accepted") && formContext.getAttribute("rsa_wordingtype").getValue() === null) {
 
                         //formContext.getControl("rsa_wordingtype").setNotification("Please enter the value in WordingType", 3007);
                         formContext.getAttribute("rsa_wordingtype").setRequiredLevel("required");
                     }
                     else {
                         //formContext.getControl("rsa_wordingtype").clearNotification(3007);
                        // formContext.getAttribute("rsa_wordingtype").setRequiredLevel("none");
                     }*///comment end 
                    //Product name mandatory
                    /*  var wardType = formContext.getAttribute("rsa_wordingtype").getValue();
                      if ((recordTypeName == "GSL - New Business" || recordTypeName === "GSL - Renewal"
                          || recordTypeName === "New Business - Marine London"
                          || recordTypeName === "New Business - Real Estate"
                          || recordTypeName === "Renewal - Marine London"
                          || recordTypeName === "Renewal - Real Estate")
                          && (opptyStage === "Renewed" || opptyStage === "Accepted") && formContext.getAttribute("rsa_wordingtype").getValue() === null) {
                          if (wardType === 866760001) {
                              //formContext.getAttribute("rsa_productname").setRequiredLevel("required");
                              formContext.getControl("rsa_productname").setNotification("Please enter the value in Product Name", 3008);
                              formContext.getAttribute("rsa_productname").setRequiredLevel("required");
                          }
  
                          else {
                              //formContext.getAttribute("rsa_productname").setRequiredLevel("none");
                              formContext.getControl("rsa_productname").clearNotification(3008);
                              formContext.getAttribute("rsa_productname").setRequiredLevel("none");
                          }
  
  
                      }*/

                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "RatingSegmentPositionForOpportunityExtension -" + err.message });
        }
    },

    //Author : Rohan Goel
    //Date_Created : Feb 2023
    //This function for associated TFS-1095

    /* - Function name - BrokerUpdate */

    BrokerUpdate: function (executionContext) {
        var formContext = executionContext.getFormContext();
        formContext.ui.clearFormNotification("Broker warning");
        RSA.D365CRM.Opportunity.Main.GetOppTypes();
        var oppType = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
        var policyAttribute = formContext.getAttribute("rsa_policyid");

        if (policyAttribute != null && tfs1095OppTypes.includes(oppType) && oppType != "Renewal - Marine Regional") {
            if (policyAttribute.getValue() != null) {
                formContext.getControl("parentaccountid").setDisabled(true);
            }
            policyAttribute.addOnChange(RSA.D365CRM.Opportunity.Main.AutoPopulateBroker);
        }
    },

    AutoPopulateBroker: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var oppType = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
        var policyAttribute = formContext.getAttribute("rsa_policyid");
        var policyId = "";
        formContext.ui.clearFormNotification("Broker warning");

        if (policyAttribute != null && policyAttribute.getValue() != null) {
            policyId = RSA.D365CRM.Opportunity.Main.ConvertGuid(policyAttribute.getValue()[0]["id"]);
            formContext.getControl("parentaccountid").setDisabled(true);
        }

        else {
            formContext.getControl("parentaccountid").setDisabled(false);
            return;
        }

        if (oppType.includes("New Business")) {

            var globalContext = Xrm.Utility.getGlobalContext();

            var req = new XMLHttpRequest();
            req.open("GET", globalContext.getClientUrl() + "/api/data/v9.1/rsa_policies(" + policyId + ")?$select=_rsa_broker_value", true);
            req.setRequestHeader("OData-MaxVersion", "4.0");
            req.setRequestHeader("OData-Version", "4.0");
            req.setRequestHeader("Accept", "application/json");
            req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
            req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            req.onreadystatechange = function () {
                if (this.readyState === 4) {
                    req.onreadystatechange = null;
                    if (this.status === 200) {
                        var result = JSON.parse(this.response);
                        var brokerId = result["_rsa_broker_value"] ? result["_rsa_broker_value"] : null;
                        var brokerName = result["_rsa_broker_value@OData.Community.Display.V1.FormattedValue"] ? result["_rsa_broker_value@OData.Community.Display.V1.FormattedValue"] : null;

                        if (!brokerId) {
                            formContext.getAttribute("parentaccountid").setValue(null);
                        }
                        else {
                            formContext.getAttribute("parentaccountid").setValue([{ id: brokerId, name: brokerName, entityType: "account" }]);
                        }

                        formContext.ui.setFormNotification("Broker updated as per the policy tagged to it.", "WARNING", "Broker warning");

                    } else {
                        Xrm.Utility.alertDialog(this.statusText);
                    }
                }
            };
            req.send();

        }
    },

    GetOppTypes: function () {

        var globalContext = Xrm.Utility.getGlobalContext();

        var req = new XMLHttpRequest();
        req.open("GET", globalContext.getClientUrl() + "/api/data/v9.1/rsa_customlabels(99314ABB-F0B4-ED11-B597-0022481B5F75)?$select=rsa_dependentoptionsetjson", false);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    var result = JSON.parse(this.response);
                    tfs1095OppTypes = JSON.parse(result["rsa_dependentoptionsetjson"])["Opportunity Types"];
                } else {
                    Xrm.Utility.alertDialog(this.statusText);
                }
            }
        };

        req.send();

    },

    //Author : Rohan Goel
    //Date_Created : May 2023
    //This function for associated TFS-334

    ValidateBalanceSheetandNetTurnover: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var balanceSheet = formContext.getAttribute("rsa_balancesheets");
        var netTurnover = formContext.getAttribute("rsa_netturnovers");

        if (balanceSheet != null && netTurnover != null) {
            var balanceSheetValue = balanceSheet.getValue();
            var netTurnoverValue = netTurnover.getValue();


            if (balanceSheetValue && !RSA.D365CRM.Opportunity.Main.ValidateInteger(balanceSheetValue)) {
                formContext.ui.setFormNotification("Balance Sheet: Enter a value greater than 0", "ERROR", "3002");
                executionContext.getEventArgs().preventDefault();
            }

            else if (netTurnoverValue && !RSA.D365CRM.Opportunity.Main.ValidateInteger(netTurnoverValue)) {
                formContext.ui.setFormNotification("Net Turnover: Enter a value greater than 0", "ERROR", "3002");
                executionContext.getEventArgs().preventDefault();
            }

            else {
                formContext.ui.clearFormNotification("3002");
            }
        }
    },

    ValidateInteger: function (n) {
        return /^\d+$/.test(n);
    },

    ConvertGuid: function (str) {
        if (str) {
            str = str.replace(/[{}]/g, '');
            str = str.toUpperCase();
        }
        return str;
    },
    // Hiding opportunities fields for all mentioned forms as per TFS 453
    //Author : Ankita Vaidya
    //Date_Created : April 2024
    //This function for associated TFS-453/

    Hidefieldsonopportunity: function (executionContext) {

        var formContext = executionContext.getFormContext();
        if (formContext.getAttribute("rsa_lineofbusiness").getValue() != null) {
            var recordTypeName = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
        }
        if (formContext.getAttribute("rsa_lineofbusiness").getValue() != null && (recordTypeName === "New Business" ||
            recordTypeName === "Extension New Business" || recordTypeName === "New Business - Marine London" ||
            recordTypeName === "New Business - Marine Regional" || recordTypeName === "New Business - Real Estate" ||
            recordTypeName === "New Business - Schemes & Deals" || recordTypeName === "SME Deals" ||
            recordTypeName === "Renewal" || recordTypeName === "Renewal - Marine London" || recordTypeName === "Renewal - Marine Regional" ||
            recordTypeName === "Renewal - Motor" || recordTypeName === "Renewal - Profin" || recordTypeName === "Renewal - Real Estate" ||
            recordTypeName === "Renewal - SME")) {

            //RSA.D365CRM.Opportunity.Main.HideAttribute(formContext, "rsa_prospecttype");
            RSA.D365CRM.Opportunity.Main.HideAttribute(formContext, "rsa_termsacceptancedate");
            RSA.D365CRM.Opportunity.Main.HideAttribute(formContext, "rsa_quotecontractcertainty");
            RSA.D365CRM.Opportunity.Main.HideAttribute(formContext, "rsa_quoteccreasonforfailure");
            RSA.D365CRM.Opportunity.Main.HideAttribute(formContext, "rsa_policyccreasonforfailure");
            //RSA.D365CRM.Opportunity.Main.HideAttribute(formContext, "rsa_houserefno");
            RSA.D365CRM.Opportunity.Main.HideAttribute(formContext, "rsa_leadversusfollow");
            RSA.D365CRM.Opportunity.Main.HideAttribute(formContext, "rsa_doesbrokerissuedocumentation");
            RSA.D365CRM.Opportunity.Main.HideAttribute(formContext, "rsa_annualproject");
            RSA.D365CRM.Opportunity.Main.HideAttribute(formContext, "rsa_policycontractcertainty");

        }
        else if (formContext.getAttribute("rsa_lineofbusiness").getValue() != null && (recordTypeName === "GSL - New Business" || recordTypeName === "GSL - Renewal")) {
            // RSA.D365CRM.Opportunity.Main.HideAttribute(formContext, "rsa_prospecttype");
            RSA.D365CRM.Opportunity.Main.HideAttribute(formContext, "rsa_termsacceptancedate");
            RSA.D365CRM.Opportunity.Main.HideAttribute(formContext, "rsa_quotecontractcertainty");
            RSA.D365CRM.Opportunity.Main.HideAttribute(formContext, "rsa_quoteccreasonforfailure");
            RSA.D365CRM.Opportunity.Main.HideAttribute(formContext, "rsa_policyccreasonforfailure");
            //RSA.D365CRM.Opportunity.Main.HideAttribute(formContext, "rsa_houserefno");
            RSA.D365CRM.Opportunity.Main.HideAttribute(formContext, "rsa_leadversusfollow");
            RSA.D365CRM.Opportunity.Main.HideAttribute(formContext, "rsa_doesbrokerissuedocumentation");
            RSA.D365CRM.Opportunity.Main.HideAttribute(formContext, "rsa_annualproject");
            RSA.D365CRM.Opportunity.Main.HideAttribute(formContext, "rsa_policycontractcertainty");
            //RSA.D365CRM.Opportunity.Main.HideAttribute(formContext, "rsa_rsacycaptivepremiumgbp");
            //  RSA.D365CRM.Opportunity.Main.HideAttribute(formContext, "rsa_exposurechange_dc");

        }

    },



    HideAttribute: function (formContext, attributeName) {
        //var formContext = executionContext.getFormContext();
        if (formContext.getControl(attributeName)) {
            formContext.getControl(attributeName).setVisible(false);
        }
    },
    // TFS -154 - make broker target premium field mandatory on the basis of prospect type option set values
    // 02/08/2024 - Updated by Saikumar
    BrokerTargetPremiumGBPMandatory: function (executionContext) {

        var formContext = executionContext.getFormContext();
        var recordTypeName, funnelStage = null, OptOrigin = null;
        if (formContext.getAttribute("rsa_lineofbusiness").getValue() != null && formContext.getAttribute("rsa_lineofbusiness").getValue() != undefined) {
            recordTypeName = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
            if (formContext.getAttribute("rsa_funnelstage") != null && formContext.getAttribute("rsa_funnelstage").getValue() != null && formContext.getAttribute("rsa_funnelstage").getValue() != undefined)
                funnelStage = formContext.getAttribute("rsa_funnelstage").getValue();
            if (formContext.getAttribute("rsa_opportunityorigin") != null && formContext.getAttribute("rsa_opportunityorigin").getValue() != null)
                OptOrigin = formContext.getAttribute("rsa_opportunityorigin").getValue();
            if ((recordTypeName == "GSL - New Business" || recordTypeName === "New Business"
                || recordTypeName === "New Business - Marine London"
                || recordTypeName === "New Business - Real Estate"
                || recordTypeName === "New Business - Marine Regional"
                || recordTypeName === "EI&C New Business"
                || recordTypeName === "New Business - Schemes & Deals")
                && ((funnelStage != null && (funnelStage === 866760001 || funnelStage === 866760002)) || (OptOrigin != null && OptOrigin === 866760000))) {


                formContext.getAttribute("rsa_targetpremium").setRequiredLevel("required");
                if (formContext.getAttribute("rsa_targetpremium").getValue() == 0.00) {
                    formContext.ui.setFormNotification("Broker Target Premium value is 0.00", "INFO", "232");
                }
            }
            else {

                if (formContext.getAttribute("rsa_targetpremium") != null) {
                    formContext.getAttribute("rsa_targetpremium").setRequiredLevel("none");
                    formContext.ui.clearFormNotification("232");
                }
            }
        }
    },
    // TFS 113 - Make Underwriter Validate PPM field mandatory on the basis of opty stages for 4 forms
    // 02/08/2024 - Updated by Ankita Vaidya
    UpdatePPPMRequirement: function (executionContext) {

        var formContext = executionContext.getFormContext();
        var recordTypeName = null;
        var IsValidatePPMRequired = "none";
        if (formContext.getAttribute("rsa_validatedppm") === null) return;
        if (formContext.getAttribute("rsa_lineofbusiness").getValue() != null) {
            recordTypeName = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
            var opportunitystage = null;
            if (formContext.getAttribute("rsa_opportunitystage").getValue() != null) {
                opportunitystage = formContext.getAttribute("rsa_opportunitystage").getValue()[0].name;
            }
            if (recordTypeName === "Renewal - Isle of Man" || recordTypeName === "Renewal" || recordTypeName === "Renewal - Profin") {
                if (["Lapsed", "Renewed", "Quoted"].includes(opportunitystage)) {
                    IsValidatePPMRequired = ("required");
                }
            }
        }
        formContext.getAttribute("rsa_validatedppm").setRequiredLevel(IsValidatePPMRequired);
    },
    // TFS 235 - Make fields Last Yearâ€™s Premium(rsa_expiringpremium), Gross RSA 100% Technical Price(rsa_opptytechnicalprice_dc) mandatory on the basis of opty stages
    // 27/sep/2024 - by Hanumantha
    MakeFieldsMandatoryBasedOnOptyStage: function (executionContext) {
        debugger;
        var formContext = executionContext.getFormContext();
        var recordTypeName = null;
        var classOfBusiness = null;
        var opportunitystage = null;

        if (formContext.getAttribute("rsa_classofbusiness") != null) {
            if (formContext.getAttribute("rsa_classofbusiness").getValue() != null && formContext.getAttribute("rsa_classofbusiness").getValue() != undefined) {
                classOfBusiness = formContext.getAttribute("rsa_classofbusiness").getValue()[0].name;
            }
            if (formContext.getAttribute("rsa_lineofbusiness").getValue() != null && formContext.getAttribute("rsa_lineofbusiness").getValue() != undefined) {
                recordTypeName = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
            }
            if (formContext.getAttribute("rsa_opportunitystage").getValue() != null && formContext.getAttribute("rsa_opportunitystage").getValue() != undefined) {
                opportunitystage = formContext.getAttribute("rsa_opportunitystage").getValue()[0].name;
            }
            var validClassOfBusiness = ["Combined", "Liability", "Motor Fleet", "Property", "Property Owners", "Blocks Of Flats",
                "Construction", "Engineering", "Renewable Energy"];

            if (opportunitystage === "Quoted" && validClassOfBusiness.includes(classOfBusiness)) {
                if (recordTypeName === "New Business") {
                    if (formContext.getAttribute("rsa_opptytechnicalprice_dc") != null) {
                        formContext.getAttribute("rsa_opptytechnicalprice_dc").setRequiredLevel("required");
                    }
                } else if (recordTypeName === "Renewal") {
                    if (formContext.getAttribute("rsa_expiringpremium") != null) {
                        if (formContext.getAttribute("rsa_expiringpremium").getValue() === 0) {
                            formContext.getAttribute("rsa_expiringpremium").setValue(null);
                        }
                        formContext.getAttribute("rsa_expiringpremium").setRequiredLevel("required");
                    }
                }
            } else {
                if (formContext.getAttribute("rsa_opptytechnicalprice_dc") != null) {
                    formContext.getAttribute("rsa_opptytechnicalprice_dc").setRequiredLevel("none");
                }
                if (formContext.getAttribute("rsa_expiringpremium") != null) {
                    formContext.getAttribute("rsa_expiringpremium").setRequiredLevel("none");
                }
            }


        }
    },



// TFS 443 - Make rsa_productname field show/hide, mandatory/non-mandatory on the basis of opty stage/COBs

// 04/feb/2024 - by Hanumantha

MakeProductNameMandatoryBasedOnOptyStage: function (executionContext) {

    var formContext = executionContext.getFormContext();

    var recordTypeName = null;

    var classOfBusiness = null;

    var opportunitystage = null;



    if (formContext.getAttribute("rsa_classofbusiness") != null && formContext.getAttribute("rsa_lineofbusiness") != null && formContext.getAttribute("rsa_classofbusiness").getValue() != "undefined" && formContext.getAttribute("rsa_lineofbusiness").getValue() != "undefined") {



        if (formContext.getAttribute("rsa_lineofbusiness").getValue() != null && formContext.getAttribute("rsa_lineofbusiness").getValue() != "undefined") {

            recordTypeName = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;

        }



        if (recordTypeName === "New Business" || recordTypeName === "Renewal" || recordTypeName === "Renewal - Profin") {



            if (formContext.getAttribute("rsa_classofbusiness").getValue() != null && formContext.getAttribute("rsa_classofbusiness").getValue() != "undefined") {

                classOfBusiness = formContext.getAttribute("rsa_classofbusiness").getValue()[0].name;

            }



            if (formContext.getAttribute("rsa_opportunitystage").getValue() != null && formContext.getAttribute("rsa_opportunitystage").getValue() != "undefined") {

                opportunitystage = formContext.getAttribute("rsa_opportunitystage").getValue()[0].name;

            }



            var validClassOfBusiness = ["ProFin London - D&O", "ProFin Regions - D&O"];



            if (formContext.getControl("rsa_productname") != null) {



                if (validClassOfBusiness.includes(classOfBusiness)) {



                    formContext.getControl("rsa_productname").setVisible(true);



                    if (opportunitystage != null) {

                        if (opportunitystage === "In Play" || opportunitystage === "Renewal Work Up" || opportunitystage === "Initial Processing") {

                            formContext.getAttribute("rsa_productname").setRequiredLevel("none");

                            formContext.getControl("rsa_productname").clearNotification();

                        }

                        else {



                            if (formContext.getAttribute("rsa_productname").getValue() === null) {

                                formContext.getAttribute("rsa_productname").setRequiredLevel("required");

                                formContext.getControl("rsa_productname").setNotification("Please select the value in Product Name");

                            }

                            else if (formContext.getAttribute("rsa_productname").getValue() != null) {

                                formContext.getAttribute("rsa_productname").setRequiredLevel("required");

                                formContext.getControl("rsa_productname").clearNotification();

                            }

                            else {



                                formContext.getControl("rsa_productname").clearNotification();

                            }

                        }

                    }

                }

                else {

                    formContext.getAttribute("rsa_productname").setRequiredLevel("none");

                    formContext.getAttribute("rsa_productname").setValue(null);

                    formContext.getControl("rsa_productname").setVisible(false);

                }

            }



        }

    }

},

//Author : Hanumantha

//Date_Created : 17 Feb 2025

//This Function Mandatory Check for This Year's Exposure, Exposure Type, Last Year's Exposure, This Year's RSA % Fields for certain condition    

    MandatoryCheckProfinFields: function (executionContext) {

        try {

            var formContext = executionContext.getFormContext();

            if (formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== "undefined" && formContext.getAttribute("rsa_quotecontractcertainty") !== null && formContext.getAttribute("rsa_quotecontractcertainty") !== "undefined" && formContext.getAttribute("rsa_opportunitystage") !== null && formContext.getAttribute("rsa_opportunitystage") !== "undefined") {

                var recordTypeName, salesStage, classOfBusiness;

                if (formContext.getAttribute("rsa_lineofbusiness").getValue() !== null) {

                    recordTypeName = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;

                }

                var dateTermsAgreed = formContext.getAttribute("rsa_quotecontractcertainty").getValue();

                if (formContext.getAttribute("rsa_opportunitystage").getValue() !== null) {

                    salesStage = formContext.getAttribute("rsa_opportunitystage").getValue()[0].name;

                }



                if (formContext.getAttribute("rsa_classofbusiness").getValue() != null && formContext.getAttribute("rsa_classofbusiness").getValue() != "undefined") {



                    classOfBusiness = formContext.getAttribute("rsa_classofbusiness").getValue()[0].name;



                    var validClassOfBusiness = ["ProFin London - D&O", "ProFin Regions - D&O", "ProFin London - Charities", "ProFin Regions - Charities", "ProFin London - PI", "ProFin Regions - PI",

                        "ProFin London - Crime", "ProFin Regions - Crime", "ProFin London - PTL", "ProFin Regions - PTL", "ProFin London - EPL", "ProFin Regions - EPL"];



                    if ((salesStage === "Accepted" || salesStage === "Renewed") && validClassOfBusiness.includes(classOfBusiness)) {



                        if (formContext.getControl("rsa_thisyearsexposure") != null) {



                            if (formContext.getAttribute("rsa_thisyearsexposure").getValue() === null || formContext.getAttribute("rsa_thisyearsexposure").getValue() == 0.00) {

                                formContext.getAttribute("rsa_thisyearsexposure").setRequiredLevel("required");

                                formContext.getControl("rsa_thisyearsexposure").setNotification("Please complete the This Year's Exposure field.");

                            } else {

                                formContext.getAttribute("rsa_thisyearsexposure").setRequiredLevel("required");

                                formContext.getControl("rsa_thisyearsexposure").clearNotification();

                            }

                        }



                        if (formContext.getControl("rsa_exposuretype") != null) {



                            if (formContext.getAttribute("rsa_exposuretype").getValue() === null) {

                                formContext.getAttribute("rsa_exposuretype").setRequiredLevel("required");

                                formContext.getControl("rsa_exposuretype").setNotification("Please complete the Exposure Type field.");

                            } else {

                                formContext.getAttribute("rsa_exposuretype").setRequiredLevel("required");

                                formContext.getControl("rsa_exposuretype").clearNotification();

                            }

                        }



                        if (formContext.getControl("rsa_lastyearsexposure") != null) {



                            if (formContext.getAttribute("rsa_lastyearsexposure").getValue() === null || formContext.getAttribute("rsa_lastyearsexposure").getValue() == 0.00) {

                                formContext.getAttribute("rsa_lastyearsexposure").setRequiredLevel("required");

                                formContext.getControl("rsa_lastyearsexposure").setNotification("Please complete the Last Year's Exposure field.");

                            } else {

                                formContext.getAttribute("rsa_lastyearsexposure").setRequiredLevel("required");

                                formContext.getControl("rsa_lastyearsexposure").clearNotification();

                            }

                        }



                        if (formContext.getControl("rsa_thisyearsrsa") != null) {



                            if (formContext.getAttribute("rsa_thisyearsrsa").getValue() === null || formContext.getAttribute("rsa_thisyearsrsa").getValue() == 0.0000) {

                                formContext.getAttribute("rsa_thisyearsrsa").setRequiredLevel("required");

                                formContext.getControl("rsa_thisyearsrsa").setNotification("Please complete the This Year RSA % field.");

                            } else {

                                formContext.getAttribute("rsa_thisyearsrsa").setRequiredLevel("required");

                                formContext.getControl("rsa_thisyearsrsa").clearNotification();

                            }

                        }

                    }

                    else {

                        if (formContext.getControl("rsa_thisyearsexposure") != null) {

                            formContext.getAttribute("rsa_thisyearsexposure").setRequiredLevel("none");

                            formContext.getControl("rsa_thisyearsexposure").clearNotification();

                        }



                        if (formContext.getControl("rsa_exposuretype") != null) {

                            formContext.getAttribute("rsa_exposuretype").setRequiredLevel("none");

                            formContext.getControl("rsa_exposuretype").clearNotification();

                        }



                        if (formContext.getControl("rsa_lastyearsexposure") != null) {

                            formContext.getAttribute("rsa_lastyearsexposure").setRequiredLevel("none");

                            formContext.getControl("rsa_lastyearsexposure").clearNotification();

                        }



                        if (formContext.getControl("rsa_thisyearsrsa") != null) {

                            formContext.getAttribute("rsa_thisyearsrsa").setRequiredLevel("none");

                            formContext.getControl("rsa_thisyearsrsa").clearNotification();

                        }

                    }

                }



            }

        } catch (err) {

            Xrm.Navigation.openAlertDialog({ text: "MandatoryCheckProfinFields -" + err.message });



        }
    }


});