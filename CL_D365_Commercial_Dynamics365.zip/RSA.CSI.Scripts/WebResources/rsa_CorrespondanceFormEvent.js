﻿var RSA = RSA || {};
RSA.D365CRM = RSA.D365CRM || {};
RSA.D365CRM.Correspondence = RSA.D365CRM.Correspondence || {};
RSA.D365CRM.Correspondence.OwnerWarning = (function () {
    var originalOwnerId = null;
    var originalOwnerName = null;
    var allowSaveAfterConfirm = false;
    function OwnerOnLoad(executionContext) {
        var formContext = executionContext.getFormContext();
        var owner = formContext.getAttribute("ownerid").getValue();
        if (owner && owner.length > 0) {
            originalOwnerId = owner[0].id.replace("{", "").replace("}", "");
            originalOwnerName = owner[0].name;
        }
    }

    function OwnerOnChange(executionContext) {
        var formContext = executionContext.getFormContext();
        var ownerAttr = formContext.getAttribute("ownerid");
        if (!ownerAttr) return;
        var newOwner = ownerAttr.getValue();
        if (!newOwner || !originalOwnerId) {
            return;
        }
        if (originalOwnerName === "unassigned user") return;
        if (originalOwnerId === newOwner[0].id.replace("{", "").replace("}", "")) {
            return;
        }
        var confirmStrings = {
            title: "Owner Already Assigned",
            text:
                "This record is already assigned to " +
                originalOwnerName +
                ".\nDo you want to reassign it?",
            confirmButtonLabel: "Yes",
            cancelButtonLabel: "Cancel"

        };

        var confirmOptions = { height: 200, width: 450, defaultButton:2 };

        Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions)
            .then(function (result) {
                if (!result.confirmed) {
                    ownerAttr.setValue([{

                        id: originalOwnerId,

                        name: originalOwnerName,

                        entityType: "systemuser"

                    }]);

                } else {                    
                    originalOwnerId = newOwner[0].id.replace("{", "").replace("}", "");
                    originalOwnerName = newOwner[0].name;

                }

            });
    }
    function OwnerOnSave(executionContext) {
        var formContext = executionContext.getFormContext();
        var eventArgs = executionContext.getEventArgs();

        var saveMode = eventArgs.getSaveMode();
        if (saveMode === 70) return;
        if (allowSaveAfterConfirm) {
            allowSaveAfterConfirm = false;
            return;
        }
        var ownerAttr = formContext.getAttribute("ownerid");
        if (!ownerAttr || !originalOwnerId) return;
        if (originalOwnerName === "unassigned user") return;
        var newOwner = ownerAttr.getValue();
        if (newOwner && newOwner.length > 0 &&
            newOwner[0].id.replace("{", "").replace("}", "") !== originalOwnerId) {
            executionContext.getEventArgs().preventDefault();
            var confirmStrings = {
                title: "Owner Already Assigned",
                text:
                    "This record is already assigned to " +
                    originalOwnerName +
                    ".\nDo you want to reassign it?",
                confirmButtonLabel: "Yes",
                cancelButtonLabel: "Cancel"

            };

            var confirmOptions = { height: 200, width: 450, defaultButton: 2 };
            Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions)
                .then(function (result) {
                if (result.confirmed) {
                    originalOwnerId = newOwner[0].id.replace("{", "").replace("}", "");
                    originalOwnerName = newOwner[0].name;
                    allowSaveAfterConfirm = true;
                    formContext.data.save();
                }
            });
        }
    }
    return {
        OwnerOnLoad: OwnerOnLoad,
        OwnerOnSave: OwnerOnSave,
        OwnerOnChange: OwnerOnChange
    };
})();