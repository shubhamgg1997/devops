// JavaScript source code
//Date : 27 Oct 2020
"use strict()";

var tfs1095CaseTypes;

var RSA = window.RSA || { __namespace: true, __typeName: "RSA" };
RSA.D365CRM = RSA.D365CRM || { __namespace: true, __typeName: "RSA.D365CRM" };
RSA.D365CRM.Case = RSA.D365CRM.Case || { __namespace: true, __typeName: "RSA.D365CRM.Case" };
RSA.D365CRM.Case.Main = RSA.D365CRM.Case.Main || ({
    FormType: {
        Create: 1,
        Update: 2,
        ReadOnly: 3,
        Disabled: 4,
        BulkEdit: 6
    },
    OnLoad: function (executionContext) {
        var formContext = executionContext.getFormContext();



        //RSA.D365CRM.Case.Main.StatusReason(executionContext);


        if (formContext.ui.getFormType() === RSA.D365CRM.Case.Main.FormType.Create) {
            RSA.D365CRM.Case.Main.UpdateOpenActivityIsMine(executionContext);


        }
        else if (formContext.ui.getFormType() === RSA.D365CRM.Case.Main.FormType.Update) {

        }
        else if (formContext.ui.getFormType() === RSA.D365CRM.Case.Main.FormType.Disabled) {

        }
        else if (formContext.ui.getFormType() === RSA.D365CRM.Case.Main.FormType.BulkEdit) {

        }
        RSA.D365CRM.Case.Main.RetriveOpportunityData(executionContext);
        RSA.D365CRM.Case.Main.RetrivePolicyData(executionContext);
        RSA.D365CRM.Case.Main.CaseDependentOptionset(executionContext);
        RSA.D365CRM.Case.Main.AssociatedEmailCases(executionContext);
        RSA.D365CRM.Case.Main.BrokerUpdate(executionContext); // Update broker based on policy
        var recordId = formContext.data.entity.getId().replace('{', '').replace('}', ''); // get records id to pass the GDPR lockfield function
        RSA.D365CRM.Case.Main.LockFields(executionContext, recordId);


    },

    OnSave: function (executionContext) {

        RSA.D365CRM.Case.Main.TriggerChangeOnLoadOfForm(executionContext);
        RSA.D365CRM.Case.Main.EICpostfulfilmentactivities(executionContext);
        RSA.D365CRM.Case.Main.MandatoryCheckQuoteDeadlineField(executionContext);
        RSA.D365CRM.Case.Main.SurveyRequestDetailsnSectionCheck(executionContext);
        RSA.D365CRM.Case.Main.SMETRILogRequired(executionContext);
        RSA.D365CRM.Case.Main.TRILogSectionRequired(executionContext);
        RSA.D365CRM.Case.Main.RenewalCantCloseUnlessOutcomeReached(executionContext);
        RSA.D365CRM.Case.Main.EPromiseCantCloseWhenInPlay(executionContext);
        //RSA.D365CRM.Case.Main.OnlyOneCasePerOpportunityValidation(executionContext);
        RSA.D365CRM.Case.Main.CompletedStatusbeforeMTACaseClosed(executionContext);
        RSA.D365CRM.Case.Main.CaseStatusValidation(executionContext);
        RSA.D365CRM.Case.Main.CSIRequiredFieldsRateRetentionInspec(executionContext);
        RSA.D365CRM.Case.Main.CSIRequiredRSAPremium(executionContext);
        RSA.D365CRM.Case.Main.CSIRequiredRSAPremiumePromise(executionContext);
        RSA.D365CRM.Case.Main.NBCantCloseUnlessOutcomeReached(executionContext);
        RSA.D365CRM.Case.Main.ProFinPIMandatoryValidation(executionContext);
        RSA.D365CRM.Case.Main.CSIRequiredFieldsRateRetentionProFin(executionContext);
        RSA.D365CRM.Case.Main.CSIRequiredFieldsRateRetentionMotor(executionContext);
        RSA.D365CRM.Case.Main.CSIRequiredFieldsRateRetentionStndrd(executionContext);
        RSA.D365CRM.Case.Main.EnterExistingInsurerReactive(executionContext);
        RSA.D365CRM.Case.Main.CaseStatusReopen(executionContext);
        RSA.D365CRM.Case.Main.EnterHoldingAgentReactive(executionContext);
        RSA.D365CRM.Case.Main.EnterPolicyNumberonOpp(executionContext);
        RSA.D365CRM.Case.Main.ExpiryPremiumMidMarket(executionContext);
        //RSA.D365CRM.Case.Main.EnterPolicyNumberonOpp(executionContext);
        RSA.D365CRM.Case.Main.IfOppisNotTakenUporLapsedValidation(executionContext);
        RSA.D365CRM.Case.Main.TechnicalPriceGSLRegionalCERE(executionContext);
        RSA.D365CRM.Case.Main.CalculateCaseAge(executionContext);
        RSA.D365CRM.Case.Main.TechnicalPrice(executionContext);
        RSA.D365CRM.Case.Main.EnterTargetPremiumReactive(executionContext);
        RSA.D365CRM.Case.Main.CSIRequiredpostfulfilmentactivities(executionContext);
        // RSA.D365CRM.Case.Main.CaseFormID(executionContext);
        RSA.D365CRM.Case.Main.EnterOtherInsurerReactive(executionContext);
        RSA.D365CRM.Case.Main.CrisisManagmentCoverNB(executionContext);
        //RSA.D365CRM.Case.Main.SME_EnquiryReason_LicenseLevel_Required(executionContext);
        //RSA.D365CRM.Case.Main.SaveAndClose(executionContext);

    },

    OnChange: function (executionContext) {
        RSA.D365CRM.Case.Main.ExpiryPremiumMidMarket(executionContext);
        RSA.D365CRM.Case.Main.IfOppisNotTakenUporLapsedValidation(executionContext);
        RSA.D365CRM.Case.Main.TechnicalPriceGSLRegionalCERE(executionContext);
        RSA.D365CRM.Case.Main.TechnicalPrice(executionContext);
        RSA.D365CRM.Case.Main.EnterTargetPremiumReactive(executionContext);
        RSA.D365CRM.Case.Main.CaseStatusValidation(executionContext);
        //RSA.D365CRM.Case.Main.OnlyOneCasePerOpportunityValidation
    },


    //Author : Chandani Vaishnani
    //Date : 18 July 2020
    //This Function Mandatory Check for 'Quote Deadline' Field for certain condition
    MandatoryCheckQuoteDeadlineField: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_opportunityid") !== null && formContext.getAttribute("rsa_casetype") !== null && formContext.getAttribute("rsa_quotedeadline") !== null) {
                var status = null, caseType = null, pl, opportunityData;
                if (formContext.getAttribute("rsa_status").getValue() !== null) {
                    status = formContext.getAttribute("rsa_status").getValue()[0].name.toUpperCase();
                }
                if (formContext.getAttribute("rsa_casetype").getValue() !== null) {
                    caseType = formContext.getAttribute("rsa_casetype").getValue()[0].name;
                }


                if (formContext.getAttribute("rsa_opportunityid").getValue() !== null) {
                    //opportunityId = RSA.D365CRM.Case.Main.ConvertGuid(formContext.getAttribute("rsa_opportunityid").getValue()[0].id);
                    if (RSA.D365CRM.Case.Main.opportunityData !== null) {
                        opportunityData = RSA.D365CRM.Case.Main.opportunityData;
                    }
                    else {
                        opportunityData = RSA.D365CRM.Case.Main.RetriveOpportunityData(executionContext);
                    }

                    if (opportunityData.hasOwnProperty("_rsa_pandlid_value")) {
                        pl = opportunityData["_rsa_pandlid_value@OData.Community.Display.V1.FormattedValue"];
                    }
                }
                var quoteDeadline = formContext.getAttribute("rsa_quotedeadline").getValue();
                //Quoted:866760005, Accepted:866760019, Extended :866760052, Renewed: 866760022, Indication:866760011
                if ((caseType === "New Business" || caseType === "Renewal") && pl === "Mid-Market" && status === "TO BE QUOTED" && quoteDeadline === null) {
                    formContext.getControl("rsa_quotedeadline").setNotification("Please complete 'Quote Deadline'.", 201);
                }
                else {
                    formContext.getControl("rsa_quotedeadline").clearNotification(201);
                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "MandatoryCheckQuoteDeadlineField -" + err.message });
        }
    },

    //sp
    SME_EnquiryReason_LicenseLevel_Required: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_outcomereasonid") !== null && formContext.getAttribute("rsa_licenselevelrequiredtoauthorise") !== null && formContext.getAttribute("rsa_casetype") !== null) {
                var status = null, caseType = null;
                if (formContext.getAttribute("rsa_status").getValue() !== null) {
                    status = formContext.getAttribute("rsa_status").getValue()[0].name;
                }
                if (formContext.getAttribute("rsa_casetype").getValue() !== null) {
                    caseType = formContext.getAttribute("rsa_casetype").getValue()[0].name;
                }
                var outcomereason = formContext.getAttribute("rsa_outcomereasonid").getValue();
                var licenselevelrequiredtoauthorise = formContext.getAttribute("rsa_licenselevelrequiredtoauthorise").getValue();
                if ((caseType === "SME - iMarket Referral" || caseType === "SME Deals - Imarket Migration" || caseType === "SME - VEF" || caseType === "SME - Declaration" || caseType === "SME - Powerplace Referral" || caseType === "SME - RSA Online Referral" || caseType === "SME - Renewal Review" || caseType === "SME - Phone Enquiry" || caseType === "SME - Email Enquiry" || caseType === "SME - EDI Phone Enquiry" || caseType === "SME - Deals Enquiry" || caseType === "SME Deals - Phone Enquiry") && status === "Closed" && outcomereason === null && licenselevelrequiredtoauthorise === null) {
                    formContext.getControl("rsa_outcomereasonid").setNotification("Please Complete the 'Enquiry Reason' and 'License Level required' before closing the case'.", 201);
                }
                else {
                    formContext.getControl("rsa_outcomereasonid").clearNotification(201);
                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "SME_EnquiryReason_LicenseLevel_Required -" + err.message });
        }
    },
    //sp
    //Author : Chandani Vaishnani
    //Date : 18 July 2020
    //This Function Mandatory Check for 'Survey Request Details' section for certain condition
    SurveyRequestDetailsnSectionCheck: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_casetype") !== null && formContext.getAttribute("rsa_reasonforsurvey") !== null && formContext.getAttribute("rsa_previoussurveycompleted") !== null && formContext.getAttribute("rsa_customercontactname") !== null && formContext.getAttribute("rsa_customercontactposition") !== null && formContext.getAttribute("rsa_customercontactphoneno") !== null && formContext.getAttribute("rsa_brokercontactname") !== null && formContext.getAttribute("rsa_brokercontacttelephone") !== null && formContext.getAttribute("rsa_riskaddress") !== null) {
                var status = null, caseType = null;
                if (formContext.getAttribute("rsa_status").getValue() !== null) {
                    status = formContext.getAttribute("rsa_status").getValue()[0].name;
                }
                if (formContext.getAttribute("rsa_casetype").getValue() !== null) {
                    caseType = formContext.getAttribute("rsa_casetype").getValue()[0].name;

                }
                var asPerSurveyTool = formContext.getAttribute("rsa_aspersurveytool").getValue();
                var reasonForSurvey = formContext.getAttribute("rsa_reasonforsurvey").getValue();
                var previousSurveyCompleted = formContext.getAttribute("rsa_previoussurveycompleted").getValue();
                var customerContactName = formContext.getAttribute("rsa_customercontactname").getValue();
                var customerContactPosition = formContext.getAttribute("rsa_customercontactposition").getValue();
                var customerContactTelephone = formContext.getAttribute("rsa_customercontactphoneno").getValue();
                var brokercContactName = formContext.getAttribute("rsa_brokercontactname").getValue();
                var brokerContactTelephone = formContext.getAttribute("rsa_brokercontacttelephone").getValue();
                var riskAddress = formContext.getAttribute("rsa_riskaddress").getValue();
                // CaseType ==="SME - Survey" && Status === "Request Survey"
                if (caseType === "sme - survey" && status === "Request Survey" && (asPerSurveyTool === null || reasonForSurvey === null || previousSurveyCompleted === null || customerContactName === null || customerContactPosition === null || customerContactTelephone === null || brokercContactName === null || brokerContactTelephone === null || riskAddress === null)) {

                    formContext.getControl("rsa_status").setNotification("Please fully complete the 'Survey Request Details' section below before changing status to 'Request Survey'.", 202);
                }
                else {
                    formContext.getControl("rsa_status").clearNotification(202);
                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "SurveyRequestDetailsnSectionCheck -" + err.message });
        }
    },
    //Author : Chandani Vaishnani
    //Date : 18 July 2020
    //This Function Mandatory Check for complete the TRI Log below (Expiry Premium, Agreed By, Brief Rationale, System Raised Renewal Premium, Agreed Renewal Premium) for certain condition
    SMETRILogRequired: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_casetype") !== null && formContext.getAttribute("rsa_outcomereasonid") && formContext.getAttribute("rsa_rsaexpirypremium") !== null && formContext.getAttribute("rsa_agreedbyid") !== null && formContext.getAttribute("rsa_briefrationale") !== null && formContext.getAttribute("rsa_systemraisedrenewalpremium") !== null && formContext.getAttribute("rsa_agreedrenewalpremium") !== null) {
                var status = null, caseType = null, outcomeReason = null;
                if (formContext.getAttribute("rsa_status").getValue() !== null) {
                    status = formContext.getAttribute("rsa_status").getValue()[0].name;
                }
                if (formContext.getAttribute("rsa_casetype").getValue() !== null) {
                    caseType = formContext.getAttribute("rsa_casetype").getValue()[0].name;
                }
                if (formContext.getAttribute("rsa_outcomereasonid").getValue() !== null) {
                    outcomeReason = formContext.getAttribute("rsa_outcomereasonid").getValue()[0].id;
                }
                var expiryPremium = formContext.getAttribute("rsa_rsaexpirypremium").getValue();
                var agreedBy = formContext.getAttribute("rsa_agreedbyid").getValue();
                var briefRationale = formContext.getAttribute("rsa_briefrationale").getValue();
                var systemRaisedRenewalPremium = formContext.getAttribute("rsa_systemraisedrenewalpremium").getValue();
                var agreedRenewalPremium = formContext.getAttribute("rsa_agreedrenewalpremium").getValue();

                //caseType = SME - iMarket Referral , SME - Powerplace Referral, SME - RSA Online Referral, SME - Renewal Review, SME Deals - Imarket Migration, SME - Phone Enquiry, SME - Email Enquiry, SME Deals - Phone Enquiry
                //Outcome Reason= Price - Renewal TRI Agreed, Override - Both TRI and Terms - Code Used
                if ((caseType === "SME - iMarket Referral" || caseType === "SME - Powerplace Referral" || caseType === "SME - RSA Online Referral" || caseType === "SME - Renewal Review" || caseType === "SME Deals - Imarket Migration" || caseType === "SME - Phone Enquiry" || caseType === "SME - Email Enquiry" || caseType === "SME Deals - Phone Enquiry") && status === "Closed (Closed)" && (outcomeReason === '{E0DF0196-26C7-EA11-A812-000D3AF01AEA}' || outcomeReason === '{DADF0196-26C7-EA11-A812-000D3AF01AEA}') && (expiryPremium === null || agreedBy === null || briefRationale === null || systemRaisedRenewalPremium === null || agreedRenewalPremium === null)) {
                    formContext.getControl("rsa_status").setNotification("Please complete the TRI Log below (Expiry Premium, Agreed By, Brief Rationale, System Raised Renewal Premium, Agreed Renewal Premium).", 203);
                }
                else {
                    formContext.getControl("rsa_status").clearNotification(203);
                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "SMETRILogRequired -" + err.message });
        }
    },
    //Author : Chandani Vaishnani
    //Date : 18 July 2020
    //This Function Mandatory Check for complete the TRI Log below (Expiry Premium, Agreed By, Brief Rationale, System Raised Renewal Premium, Agreed Renewal Premium) for certain condition
    TRILogSectionRequired: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            var classOfBusiness;
            if (formContext.getAttribute("rsa_hasthepolicybeenextended") !== null && formContext.getAttribute("rsa_casetype") !== null && formContext.getAttribute("rsa_status") && formContext.getAttribute("rsa_claimsincelastrenewal") !== null && formContext.getAttribute("rsa_classofbusinessphoneenqid") !== null && formContext.getAttribute("rsa_classofbusinessphoneenqid") !== undefined) {
                var hasThePolicyBeenExtended = formContext.getAttribute("rsa_hasthepolicybeenextended").getValue();
                var status = null, caseType = null;
                if (formContext.getAttribute("rsa_status").getValue() !== null) {
                    status = formContext.getAttribute("rsa_status").getValue()[0].name;
                }
                if (formContext.getAttribute("rsa_casetype").getValue() !== null) {
                    caseType = formContext.getAttribute("rsa_casetype").getValue()[0].name;
                }
                var claimSinceLastRenewal = formContext.getAttribute("rsa_claimsincelastrenewal").getValue();

                if (formContext.getAttribute("rsa_classofbusinessphoneenqid").getValue() !== null) {
                    classOfBusiness = formContext.getAttribute("rsa_classofbusinessphoneenqid").getValue()[0].id;
                }

                //Status === Lapsed || Declined to renew
                //Case Type === Revised_Renewal || Renewal || Mid_Term_Adjustmen
                //Class of Business===ProFin Regions - PI || ProFin London - PI
                if (hasThePolicyBeenExtended === false && claimSinceLastRenewal === false && (status === "Lapsed" || status === "Decline to Renew") && (caseType === "Revised Renewal" || caseType === "Renewal" || caseType === "Mid-Term Adjustment") && (classOfBusiness === "{A4C10B81-F6C7-EA11-A812-000D3AF01AEA}" || classOfBusiness === "{94C10B81-F6C7-EA11-A812-000D3AF01AEA}")) {
                    formContext.getControl("rsa_status").setNotification("Please complete the TRI Log below (Expiry Premium, Agreed By, Brief Rationale, System Raised Renewal Premium, Agreed Renewal Premium).", 203);
                }
                else {
                    formContext.getControl("rsa_status").clearNotification(203);
                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "TRILogSectionRequired -" + err.message });
        }
    },

    //Author : Chandani Vaishnani
    //Date : 31 July 2020
    //This Function Mandatory Check Input Effective Date for certain condition
    //Validation_Four_Blue_Prism
    InputEffectiveDateRequired: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_hasthepolicybeenextended") !== null && formContext.getAttribute("rsa_hasthepolicybeenextended") !== undefined && formContext.getAttribute("rsa_casetype") !== null && formContext.getAttribute("rsa_casetype") !== undefined && formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_status") !== undefined && formContext.getAttribute("rsa_claimsincelastrenewal") !== null && formContext.getAttribute("rsa_claimsincelastrenewal") !== undefined && formContext.getAttribute("rsa_classofbusinessphoneenqid") !== null && formContext.getAttribute("rsa_classofbusinessphoneenqid") !== undefined && formContext.getAttribute("rsa_inputeffectivedate") !== null && formContext.getAttribute("rsa_inputeffectivedate") !== undefined) {
                var hasThePolicyBeenExtended = formContext.getAttribute("rsa_hasthepolicybeenextended").getValue();
                var caseType, status, classOfBusiness;
                if (formContext.getAttribute("rsa_casetype").getValue() !== null) {
                    caseType = formContext.getAttribute("rsa_casetype").getValue()[0].name;
                }
                if (formContext.getAttribute("rsa_status").getValue() !== null) {
                    status = formContext.getAttribute("rsa_status").getValue()[0].name;
                }

                var claimSinceLastRenewal = formContext.getAttribute("rsa_claimsincelastrenewal").getValue();
                if (formContext.getAttribute("rsa_classofbusinessphoneenqid").getValue() !== null) {
                    classOfBusiness = formContext.getAttribute("rsa_classofbusinessphoneenqid").getValue()[0].name;
                }

                var inputEffectiveDate = formContext.getAttribute("rsa_inputeffectivedate").getValue();

                //Status === Lapsed || Declined to renew
                //Case Type === Revised_Renewal || Renewal || Mid_Term_Adjustmen
                //Class of Business===ProFin Regions - PI || ProFin London - PI
                if (inputEffectiveDate === null && hasThePolicyBeenExtended === false && claimSinceLastRenewal === false && (status === "Lapsed" || status === "Decline to Renew") && (caseType === "Revised Renewal" || caseType === "Renewal" || caseType === "Mid-Term Adjustment") && (classOfBusiness === "ProFin Regions - PI" || classOfBusiness === "ProFin London - PI")) {
                    //formContext.getControl("rsa_status").setNotification("Please complete the TRI Log below (Expiry Premium, Agreed By, Brief Rationale, System Raised Renewal Premium, Agreed Renewal Premium).", 203);
                    formContext.getAttribute("rsa_inputeffectivedate").setRequiredLevel("required");
                }
                else {
                    //formContext.getControl("rsa_status").clearNotification(203);
                    formContext.getAttribute("rsa_inputeffectivedate").setRequiredLevel("none");
                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "InputEffectiveDateRequired -" + err.message });
        }
    },

    //Author : Chandani Vaishnani
    //Date : 20 July 2020
    //This Function Mandatory Check for the case cannot be closed until the status has been updated to 'Renewed', 'Lapsed' or 'Decline to Renew'.
    RenewalCantCloseUnlessOutcomeReached: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_status") !== undefined && formContext.getAttribute("rsa_casetype") !== null && formContext.getAttribute("rsa_casetype") !== undefined && formContext.getAttribute("rsa_opportunityid") !== null && formContext.getAttribute("rsa_opportunityid") !== undefined) {
                var status = null, caseType = null, opportunityId, Stage, lineOfBusiness, opportunityData;
                if (formContext.getAttribute("rsa_status").getValue() !== null) {
                    status = formContext.getAttribute("rsa_status").getValue()[0].name;
                }
                if (formContext.getAttribute("rsa_casetype").getValue() !== null) {
                    caseType = formContext.getAttribute("rsa_casetype").getValue()[0].name;
                }
                var systemuserId = RSA.D365CRM.Case.Main.ConvertGuid(Xrm.Utility.getGlobalContext().userSettings.userId);
                if (RSA.D365CRM.Case.Main.opportunityData !== null) {
                    opportunityData = RSA.D365CRM.Case.Main.opportunityData;
                }
                else {
                    opportunityData = RSA.D365CRM.Case.Main.RetriveOpportunityData(executionContext);
                }

                if (opportunityData.hasOwnProperty("_rsa_lineofbusiness_value")) {
                    lineOfBusiness = opportunityData["_rsa_lineofbusiness_value"];
                }
                if (opportunityData.hasOwnProperty("rsa_stage")) {
                    Stage = opportunityData["rsa_stage"];
                }
                //Modified Date: 8/10/2020
                //Chandani Vaishnani
                /*if (formContext.getAttribute("rsa_opportunityid").getValue() !== null && RSA.D365CRM.Case.Main.RetriveOpportunityStageLOB(opportunityId, "LOB") !== undefined && RSA.D365CRM.Case.Main.RetriveOpportunityStageLOB(opportunityId, "LOB") !== null && RSA.D365CRM.Case.Main.RetriveOpportunityStageLOB(opportunityId, "stage") !== null && RSA.D365CRM.Case.Main.RetriveOpportunityStageLOB(opportunityId, "stage") !== undefined) {
                    opportunityId = RSA.D365CRM.Case.Main.ConvertGuid(formContext.getAttribute("rsa_opportunityid").getValue()[0].id);
                    Stage = RSA.D365CRM.Case.Main.RetriveOpportunityStageLOB(opportunityId, "stage");
                    lineOfBusiness = RSA.D365CRM.Case.Main.RetriveOpportunityStageLOB(opportunityId, "LOB").toUpperCase();
                }*/

                var division = RSA.D365CRM.Case.Main.RetriveUserDivison(systemuserId);


                //CaseType = Renewal
                //Stage =Renewed:866760022, Lapsed: 866760023, Decline to Renew :866760026

                if (division !== '866760003' && status === "Closed (Closed)" && (caseType === "Renewal") && (Stage !== 866760022 || Stage !== 866760023 || Stage !== 866760026) && lineOfBusiness !== "{FF901D7D-B1C1-EA11-A812-000D3AF010A3}") {
                    formContext.getControl("rsa_status").setNotification("The case cannot be closed until the status has been updated to 'Renewed', 'Lapsed' or 'Decline to Renew'.", 204);
                }
                else {

                    formContext.getControl("rsa_status").clearNotification(204);
                }
            }

        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "RenewalCantCloseUnlessOutcomeReached -" + err.message });
        }
    },

    //Author : Chandani Vaishnani
    //Date : 31 July 2020
    //This Function for Formula field Base_Premium__c
    BasePremiumFormula: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_casetype") !== null && formContext.getAttribute("rsa_casetype") !== undefined && formContext.getAttribute("rsa_opportunityid") !== null && formContext.getAttribute("rsa_opportunityid") !== undefined && formContext.getAttribute("rsa_policyid") !== null && formContext.getAttribute("rsa_policyid") !== undefined && formContext.getAttribute("rsa_basepremiumrsa") !== null && formContext.getAttribute("rsa_basepremiumrsa") !== undefined) {
                var caseType, policy, opportunityId;
                if (formContext.getAttribute("rsa_casetype").getValue() !== null) {
                    caseType = formContext.getAttribute("rsa_casetype").getValue()[0].name;
                }

                if (caseType === "Renewal" || caseType === "Mid-Term Adjustment" || caseType === "Query" || caseType === "Revised Renewal") {
                    //Policy__r.Premium__c
                    if (formContext.getAttribute("rsa_policyid").getValue() !== null) {
                        policy = RSA.D365CRM.Case.Main.ConvertGuid(formContext.getAttribute("rsa_policyid").getValue()[0].id);
                        var req = new XMLHttpRequest();
                        var globalContext = Xrm.Utility.getGlobalContext();
                        var ClientUrl = globalContext.getClientUrl();
                        req.open("GET", ClientUrl + "/api/data/v9.1/rsa_policies(" + policy + ")?$select=rsa_premium", true);
                        req.setRequestHeader("OData-MaxVersion", "4.0");
                        req.setRequestHeader("OData-Version", "4.0");
                        req.setRequestHeader("Accept", "application/json");
                        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                        req.onreadystatechange = function () {
                            if (this.readyState === 4) {
                                req.onreadystatechange = null;
                                if (this.status === 200) {
                                    var result = JSON.parse(this.response);
                                    var premium = result["rsa_premium"];
                                    formContext.getAttribute("rsa_basepremiumrsa").setValue(premium);
                                    //var rsa_premium_formatted = result["rsa_premium@OData.Community.Display.V1.FormattedValue"];
                                } else {
                                    Xrm.Navigation.openAlertDialog({ text: "BasePremiumFormula" + this.statusText });
                                }
                            }
                        };
                        req.send();
                    }

                }
                else if (caseType === "New Business") {
                    if (formContext.getAttribute("rsa_opportunityid").getValue() !== null) {
                        opportunityId = RSA.D365CRM.Case.Main.ConvertGuid(formContext.getAttribute("rsa_opportunityid").getValue()[0].id);
                        var targetPremium = RSA.D365CRM.Case.Main.RetriveOpportunityStageLOB(opportunityId, "TargetPremium");
                        if (targetPremium === 0 || targetPremium === null) {
                            var calculatedPremium = RSA.D365CRM.Case.Main.RetriveOpportunityStageLOB(opportunityId, "CalculatedPremium");
                            if (calculatedPremium !== null) {
                                if (calculatedPremium === '866760000') {
                                    formContext.getAttribute("rsa_basepremiumrsa").setValue(1000.00);
                                }
                                else if (calculatedPremium === '866760001') {
                                    formContext.getAttribute("rsa_basepremiumrsa").setValue(5000.00);
                                }
                                else if (calculatedPremium === '866760002') {
                                    formContext.getAttribute("rsa_basepremiumrsa").setValue(5000.01);
                                }
                                else if (calculatedPremium === '866760003') {
                                    formContext.getAttribute("rsa_basepremiumrsa").setValue(10000.00);
                                } else if (calculatedPremium === '866760004') {
                                    formContext.getAttribute("rsa_basepremiumrsa").setValue(15000.00);
                                } else if (calculatedPremium === '866760005') {
                                    formContext.getAttribute("rsa_basepremiumrsa").setValue(15000.01);
                                } else if (calculatedPremium === '866760006') {
                                    formContext.getAttribute("rsa_basepremiumrsa").setValue(25000.00);
                                } else if (calculatedPremium === '866760007') {
                                    formContext.getAttribute("rsa_basepremiumrsa").setValue(50000.00);
                                } else if (calculatedPremium === '866760008') {
                                    formContext.getAttribute("rsa_basepremiumrsa").setValue(100000.00);
                                } else if (calculatedPremium === '866760009') {
                                    formContext.getAttribute("rsa_basepremiumrsa").setValue(250000.00);
                                } else if (calculatedPremium === '866760010') {
                                    formContext.getAttribute("rsa_basepremiumrsa").setValue(500000.00);
                                } else if (calculatedPremium === '866760011') {
                                    formContext.getAttribute("rsa_basepremiumrsa").setValue(1000000.00);
                                } else if (calculatedPremium === '866760012') {
                                    formContext.getAttribute("rsa_basepremiumrsa").setValue(1000000.01);
                                }
                            }
                        }
                        else {
                            formContext.getAttribute("rsa_basepremiumrsa").setValue(targetPremium);
                        }

                    }
                }
                else {

                }
            }

        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "BasePremiumFormula -" + err.message });
        }
    },

    // //Author : Chandani Vaishnani
    // //Date : 03 August 2020
    // //This Function RSA Quoted Premium must be populated on the opportunity before moving the case to any of these status 'Quoted', 'Accepted', 'Not Taken Up', 'Renewed', 'Lapsed'.
    // //CSI_Required_RSA_Premium

    /* Change Summary for April 2022 Release 1 */
    /* Last Modified By: Shreya Diwate*/
    /* Summary of Changes: Replace Xrm.Page.context with Execution Xrm.Utility.getGlobalContext*/
    /* - Reason for Change:Xrm.Page.context deprecated API*/
    /* - Function name -  CSIRequiredRSAPremium */

    CSIRequiredRSAPremium: function (executionContext) {
        try {

            var globalContext = Xrm.Utility.getGlobalContext();
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_status") !== undefined && formContext.getAttribute("rsa_casetype") !== null && formContext.getAttribute("rsa_casetype") !== undefined && formContext.getAttribute("rsa_opportunityid") !== null && formContext.getAttribute("rsa_opportunityid") !== undefined && formContext.getAttribute("rsa_opportunityid").getValue() !== null) {
                var casetype, opportunityid, casestatus, pl;
                if (formContext.getAttribute("rsa_casetype").getValue() !== null) {
                    casetype = formContext.getAttribute("rsa_casetype").getValue()[0].name;
                }
                if (formContext.getAttribute("rsa_status").getValue() !== null) {
                    casestatus = formContext.getAttribute("rsa_status").getValue()[0].name;
                }


                if (formContext.getAttribute("rsa_opportunityid").getValue() !== null) {
                    opportunityId = RSA.D365CRM.Case.Main.ConvertGuid(formContext.getAttribute("rsa_opportunityid").getValue()[0].id);
                }

                //var amount = rsa.d365crm.case.main.retriveopportunitystagelob(opportunityid, "amount");
                var req = new XMLHttpRequest();

                /*req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v9.1/opportunities(" + opportunityId + ")?$select=_rsa_pandlid_value,rsa_rsaquotedpremium", false);*/

                req.open("GET", globalContext.getClientUrl() + "/api/data/v9.1/opportunities(" + opportunityId + ")?$select=_rsa_pandlid_value,rsa_rsaquotedpremium", false);

                req.setRequestHeader("OData-MaxVersion", "4.0");
                req.setRequestHeader("OData-Version", "4.0");
                req.setRequestHeader("Accept", "application/json");
                req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                req.onreadystatechange = function () {
                    if (this.readyState === 4) {
                        req.onreadystatechange = null;
                        if (this.status === 200) {
                            var result = JSON.parse(this.response);
                            pl = result["_rsa_pandlid_value@OData.Community.Display.V1.FormattedValue"];
                            var amount = result["rsa_rsaquotedpremium"];
                            if (amount !== undefined && pl !== undefined) {
                                // renewal: renewal, new business: new business, ei&c renewal: ei&c renewal case, ei&c new business: 066dd87c-57bc-ea11-a812-000d3af01a07
                                if ((casestatus === "Quoted" || casestatus === "Accepted" || casestatus === "Not Taken Up" || casestatus === "Renewed" || casestatus === "Lapsed") && (pl !== "GSL - Real Estate") && (amount === null || amount === 0) && (casetype === "Renewal" || casetype === "New Business" || casetype === "EI&C Renewal Case" || casetype === "EI&C New Business")) {
                                    formContext.getControl("rsa_status").setNotification("RSA Quoted Premium must be populated on the opportunity before moving the case to any of these status 'Quoted', 'Accepted', 'Not Taken Up', 'Renewed', 'Lapsed'.", 211);
                                }
                                else {
                                    formContext.getControl("rsa_status").clearNotification(211);
                                }
                            }
                        }
                    }
                };
                req.send();
            }

        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "CSIRequiredRSAPremium -" + err.message });
        }
    },

    //Author : Chandani Vaishnani
    //Date : 03 August 2020
    //This Function RSA Quoted Premium must be populated on the opportunity before moving the case status to 'Accepted' or 'Not Taken Up'
    //CSI_Required_RSA_Premium_ePromise
    CSIRequiredRSAPremiumePromise: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            var amount;
            if (formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_status") !== undefined && formContext.getAttribute("rsa_casetype") !== null && formContext.getAttribute("rsa_casetype") !== undefined && formContext.getAttribute("rsa_opportunityid") !== null && formContext.getAttribute("rsa_opportunityid") !== undefined) {
                var caseType, opportunityId, status;
                if (formContext.getAttribute("rsa_casetype").getValue() !== null) {
                    caseType = formContext.getAttribute("rsa_casetype").getValue()[0].name;
                }
                if (formContext.getAttribute("rsa_status").getValue() !== null) {
                    status = formContext.getAttribute("rsa_status").getValue()[0].name;
                }

                if (formContext.getAttribute("rsa_opportunityid").getValue() !== null) {
                    opportunityId = RSA.D365CRM.Case.Main.ConvertGuid(formContext.getAttribute("rsa_opportunityid").getValue()[0].id);
                    amount = RSA.D365CRM.Case.Main.RetriveOpportunityStageLOB(opportunityId, "Amount");
                }

                // New_Business_ePromise: New_Business_ePromise
                if (amount !== undefined) {
                    if ((status === "Accepted" || status === "Not Taken Up") && (amount === null || amount === '0') && caseType === "ePromise") {
                        //formContext.getAttribute("rsa_rsaquotedpremium").setRequiredLevel("required");
                        formContext.getControl("rsa_status").setNotification("RSA Quoted Premium must be populated on the opportunity before moving the case status to 'Accepted' or 'Not Taken Up'", 212);
                    }
                    else {
                        //formContext.getAttribute("rsa_rsaquotedpremium").setRequiredLevel("none");
                        formContext.getControl("rsa_status").clearNotification(212);
                    }
                }
            }

        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "CSIRequiredRSAPremiumePromise -" + err.message });
        }
    },

    //Author : Chandani Vaishnani
    //Date : 03 August 2020
    //This Function for All Rate and Retention fields should be populated on the opportunity before moving the case to status 'Renewed' or 'Lapsed
    //CSI_RequiredFields_Rate_Retention_Inspec
    CSIRequiredFieldsRateRetentionInspec: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_status") !== undefined && formContext.getAttribute("rsa_casetype") !== null && formContext.getAttribute("rsa_casetype") !== undefined && formContext.getAttribute("rsa_opportunityid") !== null && formContext.getAttribute("rsa_opportunityid") !== undefined) {
                var caseType, opportunityId, status, ratePlanTarget, technicalPrice, classofBusiness;
                if (formContext.getAttribute("rsa_casetype").getValue() !== null) {
                    caseType = formContext.getAttribute("rsa_casetype").getValue()[0].name;
                }
                if (formContext.getAttribute("rsa_status").getValue() !== null) {
                    status = formContext.getAttribute("rsa_status").getValue()[0].name;
                }

                if (formContext.getAttribute("rsa_opportunityid").getValue() !== null) {
                    opportunityId = RSA.D365CRM.Case.Main.ConvertGuid(formContext.getAttribute("rsa_opportunityid").getValue()[0].id);
                    ratePlanTarget = RSA.D365CRM.Case.Main.RetriveOpportunityStageLOB(opportunityId, "ratePlanTarget");
                    technicalPrice = RSA.D365CRM.Case.Main.RetriveOpportunityStageLOB(opportunityId, "technicalPrice");
                    classofBusiness = RSA.D365CRM.Case.Main.RetriveOpportunityStageLOB(opportunityId, "COB");
                }

                // EI_C_Renewal: 086DD87C-57BC-EA11-A812-000D3AF01A07
                if ((status === "Renewed" || status === "Status" || status === "Lapsed") && (ratePlanTarget === null || technicalPrice === null) && classofBusiness === "Inspection" && caseType === "EI&C Renewal Case") {
                    //formContext.getAttribute("rsa_rsaquotedpremium").setRequiredLevel("required");
                    formContext.getControl("rsa_status").setNotification("All Rate and Retention fields should be populated on the opportunity before moving the case to status 'Renewed' or 'Lapsed'", 213);
                }
                else {
                    //formContext.getAttribute("rsa_rsaquotedpremium").setRequiredLevel("none");
                    formContext.getControl("rsa_status").clearNotification(213);
                }
            }

        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "CSIRequiredFieldsRateRetentionInspec -" + err.message });
        }
    },

    //Author : Chandani Vaishnani
    //Date : 04 Aug 2020
    //This Generic Function is for Retriving data for Opportunity
    opportunityData: {},
    RetriveOpportunityData: function (executionContext) {
        var formContext = executionContext.getFormContext();
        //var opportunityData;
        try {
            if (formContext.getAttribute("rsa_opportunityid") !== null && formContext.getAttribute("rsa_opportunityid") !== undefined) {
                if (formContext.getAttribute("rsa_opportunityid").getValue() !== null) {
                    var opportunityId = RSA.D365CRM.Case.Main.ConvertGuid(formContext.data.entity.attributes.get("rsa_opportunityid").getValue()[0].id);
                    var req = new XMLHttpRequest();
                    var globalContext = Xrm.Utility.getGlobalContext();
                    var ClientUrl = globalContext.getClientUrl();
                    // Samiksha Dhakde: 08/09/2022
                    // CR:2159 Hiding of currency symbol: Replacing currency field to decimal field: rsa_technicalprice to rsa_opptytechnicalprice_dc.
                    req.open("GET", ClientUrl + "/api/data/v8.2/opportunities(" + opportunityId + ")?$select=_rsa_lineofbusiness_value,rsa_stage,rsa_crisismanagementcover,rsa_calcutatedpremium,rsa_targetpremium,_rsa_opportunitystage_value,rsa_rsaquotedpremium,_rsa_case_value,_rsa_classofbusiness_value,rsa_rateplantarget,rsa_grossrsa100technicalpricegsl_dc,_rsa_pandlid_value,rsa_exposuretype,rsa_lastyearsexposure,rsa_thisyearsexposure,rsa_thisyrsexplastyrsrates,_rsa_existinginsurerid_value,rsa_holdingagent,rsa_otherinsurer,rsa_policynumber,rsa_policysystem,_rsa_opportunitystage_value,rsa_rsaexpirypremium,_rsa_pandlid_value,rsa_premiumlostfor,_rsa_outcomeinsurer_value,rsa_grossrsa100technicalpricegsl_dc,rsa_opportunityformid,rsa_opptytechnicalprice_dc", false);
                    req.setRequestHeader("OData-MaxVersion", "4.0");
                    req.setRequestHeader("OData-Version", "4.0");
                    req.setRequestHeader("Accept", "application/json");
                    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                    req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                    req.onreadystatechange = function () {
                        if (this.readyState === 4) {
                            req.onreadystatechange = null;
                            if (this.status === 200) {
                                RSA.D365CRM.Case.Main.opportunityData = JSON.parse(this.response);

                            } else {
                                Xrm.Navigation.openAlertDialog({ text: "RetriveOpportunityData " + this.statusText });
                            }
                        }
                    };
                    req.send();

                    return RSA.D365CRM.Case.Main.opportunityData;
                }
            }
        } catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "RetriveOpportunityValues -" + err.message });
        }
    },

    //Author : Chandani Vaishnani
    //Date : 04 August 2020
    //This Function for All Rate and Retention fields should be populated on the opportunity before moving the case to status 'Renewed' or 'Lapsed'
    //CSI_RequiredFields_Rate_Retention_Motor
    CSIRequiredFieldsRateRetentionMotor: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_status") !== undefined && formContext.getAttribute("rsa_casetype") !== null && formContext.getAttribute("rsa_casetype") !== undefined && formContext.getAttribute("rsa_opportunityid") !== null && formContext.getAttribute("rsa_opportunityid") !== undefined) {
                var caseType, opportunityId, status, ratePlanTarget, technicalPrice, classofBusiness, thisYrsExpLastYrsRates, pl, opportunityData;
                if (formContext.getAttribute("rsa_casetype").getValue() !== null) {
                    caseType = formContext.getAttribute("rsa_casetype").getValue()[0].name;
                }
                if (formContext.getAttribute("rsa_status").getValue() !== null) {
                    status = formContext.getAttribute("rsa_status").getValue()[0].name;
                }

                if (formContext.getAttribute("rsa_opportunityid").getValue() !== null) {
                    //opportunityId = RSA.D365CRM.Case.Main.ConvertGuid(formContext.getAttribute("rsa_opportunityid").getValue()[0].id);
                    if (RSA.D365CRM.Case.Main.opportunityData !== null) {
                        opportunityData = RSA.D365CRM.Case.Main.opportunityData;
                    }
                    else {
                        opportunityData = RSA.D365CRM.Case.Main.RetriveOpportunityData(executionContext);
                    }
                    //var opportunityData = RSA.D365CRM.Case.Main.RetriveOpportunityData(opportunityId);
                    if (opportunityData.hasOwnProperty("rsa_rateplantarget")) {
                        ratePlanTarget = opportunityData["rsa_rateplantarget"];
                    }
                    if (opportunityData.hasOwnProperty("rsa_grossrsa100technicalpricegsl_dc")) {
                        technicalPrice = opportunityData["rsa_grossrsa100technicalpricegsl_dc"];
                    }
                    if (opportunityData.hasOwnProperty("_rsa_classofbusiness_value")) {
                        classofBusiness = opportunityData["_rsa_classofbusiness_value@OData.Community.Display.V1.FormattedValue"];
                    }
                    if (opportunityData.hasOwnProperty("_rsa_pandlid_value")) {
                        pl = opportunityData["_rsa_pandlid_value@OData.Community.Display.V1.FormattedValue"];
                    }
                    if (opportunityData.hasOwnProperty("rsa_thisyrsexplastyrsrates")) {
                        thisYrsExpLastYrsRates = opportunityData["rsa_thisyrsexplastyrsrates"];
                    }
                }

                // Renewal: Renewal
                if ((status === "Renewed" || status === "Lapsed") && (thisYrsExpLastYrsRates === null || ratePlanTarget === null || technicalPrice === null) && pl === "Mid-Market" && (classofBusiness === "Motor Fleet" || classofBusiness === "Motor Trade") && caseType === "Renewal") {
                    formContext.getControl("rsa_status").setNotification("All Rate and Retention fields should be populated on the opportunity before moving the case to status 'Renewed' or 'Lapsed'", 214);
                    //formContext.ui.setFormNotification("All Rate and Retention fields should be populated on the opportunity before moving the case to status 'Renewed' or 'Lapsed'", "ERROR", 214);
                }
                else {
                    formContext.getControl("rsa_status").clearNotification(214);
                    //formContext.ui.clearFormNotification(214);
                }
            }

        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "CSIRequiredFieldsRateRetentionMotor -" + err.message });
        }
    },

    //Author : Chandani Vaishnani
    //Date : 04 August 2020
    //This Function for All Rate and Retention fields should be populated on the Opportunity before moving the case to status 'Renewed' or 'Lapsed'.
    //CSI_RequiredFields_Rate_Retention_ProFin
    CSIRequiredFieldsRateRetentionProFin: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_status") !== undefined && formContext.getAttribute("rsa_casetype") !== null && formContext.getAttribute("rsa_casetype") !== undefined && formContext.getAttribute("rsa_opportunityid") !== null && formContext.getAttribute("rsa_opportunityid") !== undefined) {
                var caseType, status, ratePlanTarget, technicalPrice, classofBusiness, thisYrsExpLastYrsRates, pl, exposureType, lastYearsExposure, thisYearsExposure, opportunityformid, opportunityData;
                if (formContext.getAttribute("rsa_casetype").getValue() !== null) {
                    caseType = formContext.getAttribute("rsa_casetype").getValue()[0].name;
                }
                if (formContext.getAttribute("rsa_status").getValue() !== null) {
                    status = formContext.getAttribute("rsa_status").getValue()[0].name;
                }

                if (formContext.getAttribute("rsa_opportunityid").getValue() !== null) {
                    //opportunityId = RSA.D365CRM.Case.Main.ConvertGuid(formContext.getAttribute("rsa_opportunityid").getValue()[0].id);
                    if (RSA.D365CRM.Case.Main.opportunityData !== null) {
                        opportunityData = RSA.D365CRM.Case.Main.opportunityData;
                    }
                    else {
                        opportunityData = RSA.D365CRM.Case.Main.RetriveOpportunityData(executionContext);
                    }
                    //var opportunityData = RSA.D365CRM.Case.Main.RetriveOpportunityData(opportunityId);
                    if (opportunityData.hasOwnProperty("rsa_opportunityformid")) {
                        opportunityformid = opportunityData["rsa_opportunityformid"];
                    }
                    if (opportunityData.hasOwnProperty("rsa_rateplantarget")) {
                        ratePlanTarget = opportunityData["rsa_rateplantarget"];
                    }
                    if (opportunityData.hasOwnProperty("rsa_grossrsa100technicalpricegsl_dc")) {
                        technicalPrice = opportunityData["rsa_grossrsa100technicalpricegsl_dc"];
                    }
                    if (opportunityData.hasOwnProperty("_rsa_classofbusiness_value")) {
                        classofBusiness = opportunityData["_rsa_classofbusiness_value@OData.Community.Display.V1.FormattedValue"];
                    }
                    if (opportunityData.hasOwnProperty("_rsa_pandlid_value")) {
                        pl = opportunityData["_rsa_pandlid_value@OData.Community.Display.V1.FormattedValue"];
                    }
                    if (opportunityData.hasOwnProperty("rsa_thisyrsexplastyrsrates")) {
                        thisYrsExpLastYrsRates = opportunityData["rsa_thisyrsexplastyrsrates"];
                    }
                    if (opportunityData.hasOwnProperty("rsa_exposuretype")) {
                        exposureType = opportunityData["rsa_exposuretype"];
                    }
                    if (opportunityData.hasOwnProperty("rsa_lastyearsexposure")) {
                        lastYearsExposure = opportunityData["rsa_lastyearsexposure"];
                    }
                    if (opportunityData.hasOwnProperty("rsa_thisyearsexposure")) {
                        thisYearsExposure = opportunityData["rsa_thisyearsexposure"];
                    }
                }

                // Renewal: Renewal
                if (opportunityformid == "D0ADE15B-928E-411B-B7B5-C61E6A622282" || opportunityformid == "3A5926FC-A933-4265-9690-C74D16836E77" || opportunityformid == "7E440BC5-BF43-4311-B809-A1CE41E89F12" || opportunityformid == "D411E332-5124-4784-AA12-284D9F1E6DAA" || opportunityformid == "186277DE-2FAC-47C4-80D8-299F58C649A3" || opportunityformid == "313DE63B-D18B-4F16-B6DA-EA0AB932B53C" || opportunityformid == "194912D6-8A03-4466-82FB-9E0674CB4ABC") {
                    if ((status === "Renewed" || status === "Lapsed") && (thisYrsExpLastYrsRates === null || ratePlanTarget === null || technicalPrice === null) && pl === "GSL - Profin" && (classofBusiness === "ProFin London - Libel" || classofBusiness === "ProFin London - A&H" || classofBusiness === "ProFin Regions - A&H" || classofBusiness === "ProFin Regions - Libel" || classofBusiness === "ProFin London - EPL" || classofBusiness === "ProFin Regions - EPL" || classofBusiness === "ProFin London - D&O" || classofBusiness === "ProFin Regions - D&O" || classofBusiness === "ProFin Regions - Crime" || classofBusiness === "ProFin London - Crime" || classofBusiness === "ProFin Regions - PI" || classofBusiness === "ProFin London - Bonds" || classofBusiness === "ProFin London - Charities" || classofBusiness === "ProFin Regions - Charities" || classofBusiness === "ProFin London - Legal Indemnity" || classofBusiness === "ProFin London - Contingency" || classofBusiness === "ProFin - Scottish Bonds" || classofBusiness === "ProFin London - PI") && caseType === "Renewal") {
                        formContext.getControl("rsa_status").setNotification("All Rate and Retention fields should be populated on the Opportunity before moving the case to status 'Renewed' or 'Lapsed'", 215);
                        //formContext.ui.setFormNotification("All Rate and Retention fields should be populated on the Opportunity before moving the case to status 'Renewed' or 'Lapsed'", "ERROR", 215);
                    }
                    else {
                        formContext.getControl("rsa_status").clearNotification(215);
                        //formContext.ui.clearFormNotification(215);
                    }
                }

                if (opportunityformid == "E76DEC3C-E2BC-43DA-8F00-339214D38F1F" || opportunityformid == "175959FB-7152-41EB-8D84-86152341AD79") {
                    if ((status === "Renewed" || status === "Lapsed") && (thisYrsExpLastYrsRates === null || exposureType === null || thisYearsExposure === null || ratePlanTarget === null || technicalPrice === null || lastYearsExposure === null) && pl === "GSL - Profin" && (classofBusiness === "ProFin London - Libel" || classofBusiness === "ProFin London - A&H" || classofBusiness === "ProFin Regions - A&H" || classofBusiness === "ProFin Regions - Libel" || classofBusiness === "ProFin London - EPL" || classofBusiness === "ProFin Regions - EPL" || classofBusiness === "ProFin London - D&O" || classofBusiness === "ProFin Regions - D&O" || classofBusiness === "ProFin Regions - Crime" || classofBusiness === "ProFin London - Crime" || classofBusiness === "ProFin Regions - PI" || classofBusiness === "ProFin London - Bonds" || classofBusiness === "ProFin London - Charities" || classofBusiness === "ProFin Regions - Charities" || classofBusiness === "ProFin London - Legal Indemnity" || classofBusiness === "ProFin London - Contingency" || classofBusiness === "ProFin - Scottish Bonds" || classofBusiness === "ProFin London - PI") && caseType === "Renewal") {
                        formContext.getControl("rsa_status").setNotification("All Rate and Retention fields should be populated on the Opportunity before moving the case to status 'Renewed' or 'Lapsed'", 215);
                        //formContext.ui.setFormNotification("All Rate and Retention fields should be populated on the Opportunity before moving the case to status 'Renewed' or 'Lapsed'", "ERROR", 215);
                    }
                    else {
                        formContext.getControl("rsa_status").clearNotification(215);
                        //formContext.ui.clearFormNotification(215);
                    }
                }
            }

        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "CSIRequiredFieldsRateRetentionProFin -" + err.message });
        }
    },

    //Author : Chandani Vaishnani
    //Date : 04 August 2020
    //This Function for All Rate and Retention fields should be populated on the opportunity before moving the case to status 'Renewed' or 'Lapsed'.
    //CSI_RequiredFields_Rate_Retention_Stndrd
    CSIRequiredFieldsRateRetentionStndrd: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_status") !== undefined && formContext.getAttribute("rsa_casetype") !== null && formContext.getAttribute("rsa_casetype") !== undefined && formContext.getAttribute("rsa_opportunityid") !== null && formContext.getAttribute("rsa_opportunityid") !== undefined) {
                var caseType, status, ratePlanTarget, technicalPrice, classofBusiness, thisYrsExpLastYrsRates, opportunityData;
                if (formContext.getAttribute("rsa_casetype").getValue() !== null) {
                    caseType = formContext.getAttribute("rsa_casetype").getValue()[0].name;
                }
                if (formContext.getAttribute("rsa_status").getValue() !== null) {
                    status = formContext.getAttribute("rsa_status").getValue()[0].name;
                }

                if (formContext.getAttribute("rsa_opportunityid").getValue() !== null) {
                    //opportunityId = RSA.D365CRM.Case.Main.ConvertGuid(formContext.getAttribute("rsa_opportunityid").getValue()[0].id);
                    if (RSA.D365CRM.Case.Main.opportunityData !== null) {
                        opportunityData = RSA.D365CRM.Case.Main.opportunityData;
                    }
                    else {
                        opportunityData = RSA.D365CRM.Case.Main.RetriveOpportunityData(executionContext);
                    }
                    //var opportunityData = RSA.D365CRM.Case.Main.RetriveOpportunityData(opportunityId);
                    if (opportunityData.hasOwnProperty("rsa_rateplantarget")) {
                        ratePlanTarget = opportunityData["rsa_rateplantarget"];
                    }
                    if (opportunityData.hasOwnProperty("rsa_grossrsa100technicalpricegsl_dc")) {
                        technicalPrice = opportunityData["rsa_grossrsa100technicalpricegsl_dc"];
                    }
                    if (opportunityData.hasOwnProperty("_rsa_classofbusiness_value")) {
                        classofBusiness = opportunityData["_rsa_classofbusiness_value@OData.Community.Display.V1.FormattedValue"];
                    }
                    if (opportunityData.hasOwnProperty("rsa_thisyrsexplastyrsrates")) {
                        thisYrsExpLastYrsRates = opportunityData["rsa_thisyrsexplastyrsrates"];
                    }
                }

                // Renewal: Renewal
                if ((status === "Renewed" || status === "Lapsed") && (thisYrsExpLastYrsRates === null || ratePlanTarget === null || technicalPrice === null) && (classofBusiness === "Liability" || classofBusiness === "Combined" || classofBusiness === "Property Owners" || classofBusiness === "Property" || classofBusiness === "Construction" || classofBusiness === "Engineering" || classofBusiness === "Renewable Energy") && caseType === "Renewal") {
                    //formContext.getAttribute("totalamount").setRequiredLevel("required");
                    formContext.getControl("rsa_status").setNotification("All Rate and Retention fields should be populated on the opportunity before moving the case to status 'Renewed' or 'Lapsed'", 216);
                }
                else {
                    //formContext.getAttribute("totalamount").setRequiredLevel("none");
                    formContext.getControl("rsa_status").clearNotification(216);
                }
            }

        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "CSIRequiredFieldsRateRetentionStndrd -" + err.message });
        }
    },

    //Author : Chandani Vaishnani
    //Date : 04 August 2020
    //This Function for Existing Insurer field must be populated on the opportunity before moving the case to status 'Quoted'.
    //Enter_Existing_Insurer_Reactive
    EnterExistingInsurerReactive: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_status") !== undefined && formContext.getAttribute("rsa_opportunityid") !== null && formContext.getAttribute("rsa_opportunityid") !== undefined) {
                var status, existingInsurer, pl, lineOfBusiness, opportunityData;
                //pl = formContext.getAttribute("rsa_pl").getValue();
                if (formContext.getAttribute("rsa_status").getValue() !== null) {
                    status = formContext.getAttribute("rsa_status").getValue()[0].name;
                }

                if (formContext.getAttribute("rsa_opportunityid").getValue() !== null) {
                    //opportunityId = RSA.D365CRM.Case.Main.ConvertGuid(formContext.getAttribute("rsa_opportunityid").getValue()[0].id);
                    if (RSA.D365CRM.Case.Main.opportunityData !== null) {
                        opportunityData = RSA.D365CRM.Case.Main.opportunityData;
                    }
                    else {
                        opportunityData = RSA.D365CRM.Case.Main.RetriveOpportunityData(executionContext);
                    }
                    //var opportunityData = RSA.D365CRM.Case.Main.RetriveOpportunityData(opportunityId);
                    if (opportunityData.hasOwnProperty("_rsa_existinginsurerid_value")) {
                        existingInsurer = opportunityData["_rsa_existinginsurerid_value"];
                    }
                    if (opportunityData.hasOwnProperty("_rsa_lineofbusiness_value")) {
                        lineOfBusiness = opportunityData["_rsa_lineofbusiness_value@OData.Community.Display.V1.FormattedValue"];
                    }
                    if (opportunityData.hasOwnProperty("_rsa_pandlid_value")) {
                        pl = opportunityData["_rsa_pandlid_value@OData.Community.Display.V1.FormattedValue"];
                    }
                }

                // Renewal: Renewal
                if (status === "Quoted" && existingInsurer === null && (lineOfBusiness === "New Business" || lineOfBusiness === "New Business - Real Estate" || lineOfBusiness === "New Business - Schemes & Deals") && pl !== "GSL - Real Estate") {
                    //formContext.getAttribute("totalamount").setRequiredLevel("required");
                    formContext.getControl("rsa_opportunityid").setNotification("Existing Insurer field must be populated on the opportunity before moving the case to status 'Quoted'", 217);
                }
                else {
                    //formContext.getAttribute("totalamount").setRequiredLevel("none");
                    formContext.getControl("rsa_opportunityid").clearNotification(217);
                }
            }

        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "EnterExistingInsurerReactive -" + err.message });
        }
    },

    //Author : Chandani Vaishnani
    //Date : 05 August 2020
    //This Function for 'Holding Agent' field must be populated on the opportunity before moving the case to status 'Quoted'.
    //Enter_Other_Insurer_Reactive
    EnterOtherInsurerReactive: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            var opportunityData;
            if (formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_status") !== undefined && formContext.getAttribute("rsa_opportunityid") !== null && formContext.getAttribute("rsa_opportunityid") !== undefined) {
                var status, lineOfBusiness, existingInsurer, otherInsurer, pl;
                //pl = formContext.getAttribute("rsa_pl").getValue();
                if (formContext.getAttribute("rsa_status").getValue() !== null) {
                    status = formContext.getAttribute("rsa_status").getValue()[0].name;
                }

                if (formContext.getAttribute("rsa_opportunityid").getValue() !== null) {
                    //opportunityId = RSA.D365CRM.Case.Main.ConvertGuid(formContext.getAttribute("rsa_opportunityid").getValue()[0].id);
                    if (RSA.D365CRM.Case.Main.opportunityData !== null && RSA.D365CRM.Case.Main.opportunityData !== undefined) {
                        opportunityData = RSA.D365CRM.Case.Main.opportunityData;
                    }
                    else {
                        opportunityData = RSA.D365CRM.Case.Main.RetriveOpportunityData(executionContext);
                    }
                    //var opportunityData = RSA.D365CRM.Case.Main.RetriveOpportunityData(opportunityId);
                    if (opportunityData.hasOwnProperty("_rsa_existinginsurerid_value")) {
                        existingInsurer = opportunityData["_rsa_existinginsurerid_value@OData.Community.Display.V1.FormattedValue"];
                    }
                    if (opportunityData.hasOwnProperty("rsa_otherinsurer")) {
                        otherInsurer = opportunityData["rsa_otherinsurer"];
                    }
                    if (opportunityData.hasOwnProperty("_rsa_lineofbusiness_value")) {
                        lineOfBusiness = opportunityData["_rsa_lineofbusiness_value@OData.Community.Display.V1.FormattedValue"];
                    }
                    if (opportunityData.hasOwnProperty("_rsa_pandlid_value")) {
                        pl = opportunityData["_rsa_pandlid_value@OData.Community.Display.V1.FormattedValue"];
                    }
                }

                // Opportunity LineOfBusiness: NewBusiness :DB901D7D-B1C1-EA11-A812-000D3AF010A3, New Business Schemes&Deals: ED901D7D-B1C1-EA11-A812-000D3AF010A3
                if (status === "Quoted" && existingInsurer === "Other" && otherInsurer === null && (lineOfBusiness === "New Business" || lineOfBusiness === "New Business - Schemes & Deals") && pl !== "GSL - Real Estate") {
                    formContext.getControl("rsa_status").setNotification("'Other Insurer' field must be populated on the opportunity before moving the case to status 'Quoted'.", 219);
                }
                else {
                    formContext.getControl("rsa_status").clearNotification(219);
                }
            }

        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "EnterOtherInsurerReactive -" + err.message });
        }
    },

    //Author : Chandani Vaishnani
    //Date : 05 August 2020
    //This Function for Policy Number and Policy System must be completed on the Opportunity
    //Enter_Policy_Number_on_Opp
    EnterPolicyNumberonOpp: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_status") !== undefined && formContext.getAttribute("rsa_opportunityid") !== null && formContext.getAttribute("rsa_opportunityid") !== undefined) {
                var status, lineOfBusiness, policyNumber, policySystem, salesStage, opportunityData;

                if (formContext.getAttribute("rsa_status").getValue() !== null) {
                    status = formContext.getAttribute("rsa_status").getValue()[0].name;
                }

                if (formContext.getAttribute("rsa_opportunityid").getValue() !== null) {
                    //opportunityId = RSA.D365CRM.Case.Main.ConvertGuid(formContext.getAttribute("rsa_opportunityid").getValue()[0].id);
                    if (RSA.D365CRM.Case.Main.opportunityData !== null) {
                        opportunityData = RSA.D365CRM.Case.Main.opportunityData;
                    }
                    else {
                        opportunityData = RSA.D365CRM.Case.Main.RetriveOpportunityData(executionContext);
                    }
                    //var opportunityData = RSA.D365CRM.Case.Main.RetriveOpportunityData(opportunityId);
                    if (opportunityData.hasOwnProperty("rsa_policynumber")) {
                        policyNumber = opportunityData["rsa_policynumber"];
                    }
                    if (opportunityData.hasOwnProperty("rsa_policysystem")) {
                        policySystem = opportunityData["rsa_policysystem"];
                    }
                    if (opportunityData.hasOwnProperty("_rsa_opportunitystage_value")) {
                        salesStage = opportunityData["_rsa_opportunitystage_value@OData.Community.Display.V1.FormattedValue"];
                    }
                    if (opportunityData.hasOwnProperty("_rsa_lineofbusiness_value")) {
                        //lineOfBusiness = opportunityData["_rsa_lineofbusiness_value"].toUpperCase();
                        lineOfBusiness = opportunityData["_rsa_lineofbusiness_value@OData.Community.Display.V1.FormattedValue"];
                    }
                }

                // Opportunity LineOfBusiness: NewBusinessRealEstate :E9901D7D-B1C1-EA11-A812-000D3AF010A3, Renewal RealEstate: FF901D7D-B1C1-EA11-A812-000D3AF010A3
                if (status === "Closed" && (policyNumber === null || policySystem === null) && salesStage === "Accepted" && (lineOfBusiness !== "New Business - Real Estate" || lineOfBusiness !== "Renewal - Real Estate")) {
                    formContext.getControl("rsa_status").setNotification("Policy Number and Policy System must be completed on the Opportunity", 220);
                }
                else {
                    formContext.getControl("rsa_status").clearNotification(220);
                }
            }

        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "EnterPolicyNumberonOpp -" + err.message });
        }
    },

    //Author : Chandani Vaishnani
    //Date : 05 August 2020
    //This Function for 'Holding Agent' field must be populated on the opportunity before moving the case to status 'Quoted'.
    //Enter_Holding_Agent_Reactive
    EnterHoldingAgentReactive: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_status") !== undefined && formContext.getAttribute("rsa_opportunityid") !== null && formContext.getAttribute("rsa_opportunityid") !== undefined) {
                var status, holdingAgent, lineOfBusiness, opportunityData;

                if (formContext.getAttribute("rsa_status").getValue() !== null) {
                    status = formContext.getAttribute("rsa_status").getValue()[0].name;
                }

                if (formContext.getAttribute("rsa_opportunityid").getValue() !== null) {
                    //opportunityId = RSA.D365CRM.Case.Main.ConvertGuid(formContext.getAttribute("rsa_opportunityid").getValue()[0].id);
                    if (RSA.D365CRM.Case.Main.opportunityData !== null) {
                        opportunityData = RSA.D365CRM.Case.Main.opportunityData;
                    }
                    else {
                        opportunityData = RSA.D365CRM.Case.Main.RetriveOpportunityData(executionContext);
                    }
                    //var opportunityData = RSA.D365CRM.Case.Main.RetriveOpportunityData(opportunityId);
                    if (opportunityData.hasOwnProperty("rsa_holdingagent")) {
                        holdingAgent = opportunityData["rsa_holdingagent"];
                    }
                    if (opportunityData.hasOwnProperty("_rsa_lineofbusiness_value")) {
                        lineOfBusiness = opportunityData["_rsa_lineofbusiness_value@OData.Community.Display.V1.FormattedValue"];
                    }
                }

                // Opportunity LineOfBusiness: NewBusiness :DB901D7D-B1C1-EA11-A812-000D3AF010A3, Schemes&Deals: ED901D7D-B1C1-EA11-A812-000D3AF010A3
                if (status === "Quoted" && holdingAgent === null && (lineOfBusiness === "New Business" || lineOfBusiness === "New Business - Schemes & Deals")) {
                    formContext.getControl("rsa_opportunityid").setNotification("'Holding Agent' field must be populated on the opportunity before moving the case to status 'Quoted'.", 218);
                }
                else {
                    formContext.getControl("rsa_opportunityid").clearNotification(218);
                }
            }

        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "EnterHoldingAgentReactive -" + err.message });
        }
    },

    //Author : Chandani Vaishnani
    //Date : 20 July 2020
    //This Generic Function is for Retriving Division for User
    RetriveUserDivison: function (UserId) {
        try {
            var division;
            var req = new XMLHttpRequest();
            var globalContext = Xrm.Utility.getGlobalContext();
            var ClientUrl = globalContext.getClientUrl();
            req.open("GET", ClientUrl + "/api/data/v8.2/systemusers(" + UserId + ")?$select=rsa_division", false);
            req.setRequestHeader("OData-MaxVersion", "4.0");
            req.setRequestHeader("OData-Version", "4.0");
            req.setRequestHeader("Accept", "application/json");
            req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
            req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            req.onreadystatechange = function () {
                if (this.readyState === 4) {
                    req.onreadystatechange = null;
                    if (this.status === 200) {
                        var result = JSON.parse(this.response);
                        division = result["rsa_division"];

                        //var rsa_division_formatted = result["rsa_division@OData.Community.Display.V1.FormattedValue"];
                    } else {
                        Xrm.Navigation.openAlertDialog({ text: "RetriveUserDivison " + this.statusText });
                    }
                }
            };
            req.send();
            return division;
        } catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "RetriveUserDivison -" + err.message });
        }
    },


    //Author : Chandani Vaishnani
    //Date : 20 July 2020
    //This Generic Function is for Retriving Stage and LOB for Opportunity
    RetriveOpportunityStageLOB: function (opportunityId, attributeName) {
        try {
            var attValue;
            var req = new XMLHttpRequest();
            var globalContext = Xrm.Utility.getGlobalContext();
            var ClientUrl = globalContext.getClientUrl();
            req.open("GET", ClientUrl + "/api/data/v8.2/opportunities(" + opportunityId + ")?$select=_rsa_lineofbusiness_value,rsa_crisismanagementcover,rsa_calcutatedpremium,rsa_targetpremium,_rsa_opportunitystage_value,rsa_rsaquotedpremium,_rsa_case_value,_rsa_classofbusiness_value,rsa_rateplantarget,rsa_grossrsa100technicalpricegsl_dc,rsa_quotenumber", false);
            req.setRequestHeader("OData-MaxVersion", "4.0");
            req.setRequestHeader("OData-Version", "4.0");
            req.setRequestHeader("Accept", "application/json");
            req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
            req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            req.onreadystatechange = function () {
                if (this.readyState === 4) {
                    req.onreadystatechange = null;
                    if (this.status === 200) {
                        var result = JSON.parse(this.response);
                        var stage = result["rsa_stage"];
                        var lineOfBusiness = result["_rsa_lineofbusiness_value"];
                        var crisismanagementcover = result["rsa_crisismanagementcover"];
                        var opportunitystagevalue = result["_rsa_opportunitystage_value"];
                        var opportunitystagevalueformatted = result["_rsa_opportunitystage_value@OData.Community.Display.V1.FormattedValue"];
                        var _rsa_case_value = result["_rsa_case_value"];
                        var _rsa_case_value_formatted = result["_rsa_case_value@OData.Community.Display.V1.FormattedValue"];
                        var _rsa_case_value_lookuplogicalname = result["_rsa_case_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                        if (attributeName === "LOB") {
                            attValue = lineOfBusiness;
                        }
                        else if (attributeName === "crisesManagement") {
                            attValue = crisismanagementcover;
                        }
                        else if (attributeName === "CalculatedPremium") {
                            attValue = result["rsa_calcutatedpremium"];
                        } else if (attributeName === "TargetPremium") {
                            attValue = result["rsa_targetpremium"];
                        }
                        else if (attributeName === "OpportunityStage") {
                            attValue = result["_rsa_opportunitystage_value"];
                        }
                        else if (attributeName === "Amount") {
                            attValue = result["rsa_rsaquotedpremium"];
                        }
                        else if (attributeName === "OpportunityCase") {
                            attValue = _rsa_case_value_formatted;
                        } else if (attributeName === "ratePlanTarget") {
                            attValue = result["rsa_rateplantarget"];
                        } else if (attributeName === "technicalPrice") {
                            attValue = result["rsa_grossrsa100technicalpricegsl_dc"];
                        } else if (attributeName === "COB") {
                            attValue = result["_rsa_classofbusiness_value@OData.Community.Display.V1.FormattedValue"];
                        } else if (attributeName === "OpportunityStageName") {
                            attValue = opportunitystagevalueformatted;
                        } else if (attributeName === "QuoteNumber") {
                            attValue = result["rsa_quotenumber"];
                        }

                    } else {

                        Xrm.Navigation.openAlertDialog({ text: "RetriveOpportunityStageLOB" + this.statusText + attributeName });
                    }
                }
            };
            req.send();

            return attValue;
        } catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "RetriveOpportunityValues -" + err.message });
        }
    },

    //Author : Chandani Vaishnani
    //Date : 03 August 2020
    //This Function Mandatory Check for The case cannot be closed until the status has been updated to 'Completed'
    //Completed_Status_before_MTA_Case_Closed
    CompletedStatusbeforeMTACaseClosed: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_status") !== undefined && formContext.getAttribute("rsa_casetype") !== null && formContext.getAttribute("rsa_casetype") !== undefined && formContext.getAttribute("rsa_policyid") !== null && formContext.getAttribute("rsa_policyid") !== undefined) {
                var caseType, policy, status;
                if (formContext.getAttribute("rsa_casetype").getValue() !== null) {
                    caseType = formContext.getAttribute("rsa_casetype").getValue()[0].name;
                }
                if (formContext.getAttribute("rsa_status").getValue() !== null) {
                    status = formContext.getAttribute("rsa_status").getValue()[0].name;
                }
                if (formContext.getAttribute("rsa_policyid").getValue() !== null) {
                    policy = RSA.D365CRM.Case.Main.ConvertGuid(formContext.getAttribute("rsa_policyid").getValue()[0].id);
                    if (status === "Closed (Closed)" && status !== "Completed" && status !== "Re-Opened" && caseType === "Mid-Term Adjustment") {
                        var req = new XMLHttpRequest();
                        var globalContext = Xrm.Utility.getGlobalContext();
                        var ClientUrl = globalContext.getClientUrl();
                        req.open("GET", ClientUrl + "/api/data/v9.1/rsa_policies(" + policy + ")?$select=_rsa_plcode_value", true);
                        req.setRequestHeader("OData-MaxVersion", "4.0");
                        req.setRequestHeader("OData-Version", "4.0");
                        req.setRequestHeader("Accept", "application/json");
                        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                        req.onreadystatechange = function () {
                            if (this.readyState === 4) {
                                req.onreadystatechange = null;
                                if (this.status === 200) {
                                    var result = JSON.parse(this.response);
                                    var plcode = result["_rsa_plcode_value@OData.Community.Display.V1.FormattedValue"];
                                    if (plcode !== "GSL - Real Estate") {
                                        formContext.getControl("rsa_status").setNotification("The case cannot be closed until the status has been updated to 'Completed'", 210);
                                    }
                                    else {
                                        formContext.getControl("rsa_status").clearNotification(210);
                                    }
                                } else {
                                    Xrm.Navigation.openAlertDialog({ text: "CompletedStatusbeforeMTACaseClosed " + this.statusText });
                                }
                            }
                        };
                        req.send();
                    }
                }
            }

        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "CompletedStatusbeforeMTACaseClosed-" + err.message });
        }
    },
    //Author : Nida Mulla
    //Date : 21 July 2020
    //This  Function is for Retriving crises management Cover Opportunity for null Validation

    /* Change Summary for April 2022 Release 1 */
    /* Last Modified By: Shreya Diwate*/
    /* Summary of Changes: Replace Xrm.Utility.alertDialog(this.responseText) with Xrm.Navigation.openAlertDialog */
    /* - Reason for Change: Xrm.Utility.alertDialog(this.responseText)' uses a deprecated API*/
    /* - Function name - CrisisManagmentCoverNB */

    /* Change Summary for April 2022 Release 1 */
    /* Last Modified By: Shreya Diwate*/
    /* Summary of Changes: Replace Xrm.Page.context with Execution Xrm.Utility.getGlobalContext*/
    /* - Reason for Change:Xrm.Page.context deprecated API*/
    /* - Function name - CrisisManagmentCoverNB */

    CrisisManagmentCoverNB: function (executionContext) {
        try {
            var bool;
            var i;
            var globalContext = Xrm.Utility.getGlobalContext();
            var formContext = executionContext.getFormContext();
            var crisisManagement;
            if (formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_casetype") !== null && formContext.getAttribute("rsa_opportunityid") !== null && formContext.getAttribute("rsa_classofbusiness") !== null && formContext.getAttribute("rsa_opportunityid") !== null && formContext.getAttribute("rsa_status").getValue() !== undefined && formContext.getAttribute("rsa_casetype").getValue() !== undefined && formContext.getAttribute("rsa_opportunityid").getValue() !== undefined && formContext.getAttribute("rsa_classofbusiness").getValue() !== undefined && formContext.getAttribute("rsa_opportunityid").getValue() !== undefined && formContext.getAttribute("rsa_status").getValue() !== null && formContext.getAttribute("rsa_casetype").getValue() !== null && formContext.getAttribute("rsa_opportunityid").getValue() !== null && formContext.getAttribute("rsa_classofbusiness").getValue() !== null && formContext.getAttribute("rsa_opportunityid").getValue() !== null) {
                var status = formContext.getAttribute("rsa_status").getValue()[0].name;
                var caseType = formContext.getAttribute("rsa_casetype").getValue()[0].name;
                var classOfBuisness = formContext.getAttribute("rsa_classofbusiness").getValue();
                var opportunityId = RSA.D365CRM.Case.Main.ConvertGuid(formContext.getAttribute("rsa_opportunityid").getValue()[0].id);
                if (opportunityId !== null) {
                    var req = new XMLHttpRequest();
                    /*req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v9.1/opportunities(" + opportunityId + ")?$select=rsa_crisismanagementcover", false);*/

                    req.open("GET", globalContext.getClientUrl() + "/api/data/v9.1/opportunities(" + opportunityId + ")?$select=rsa_crisismanagementcover", false);

                    req.setRequestHeader("OData-MaxVersion", "4.0");
                    req.setRequestHeader("OData-Version", "4.0");
                    req.setRequestHeader("Accept", "application/json");
                    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                    req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                    req.onreadystatechange = function () {
                        if (this.readyState === 4) {
                            req.onreadystatechange = null;
                            if (this.status === 200) {
                                var result = JSON.parse(this.response);
                                crisisManagement = result["rsa_crisismanagementcover"];
                                //var crisesManagement = RSA.D365CRM.Case.Main.RetriveOpportunityStageLOB(opportunityId, "crisesManagement");
                                var classOfBusinessArray = ["Liability", "Combined", "Real Estate - Property Owners", "Real Estate - Property", "Real Estate - Liability", "Real Estate - Combined", "Real Estate - Motor"];
                                //var hasClassOfBusiness = classOfBusinessArray.includes(classOfBuisness[0].name, 0);
                                for (i = 0; i <= classOfBusinessArray.length; i++) {
                                    if (classOfBusinessArray[i] === classOfBuisness) {
                                        bool = true;
                                    }
                                }

                                //CaseType = Renewal
                                //Stage =Renewed:866760022, Lapsed: 866760023, Decline to Renew :866760026

                                if (status === "Accepted" && caseType !== "New Business - Isle Of Man" && bool === true && crisisManagement === null) {
                                    formContext.getControl("rsa_opportunityid").setNotification("Crisis Management cover must be completed on the opportunity when the status is set as 'Accepted'", 901);
                                }
                                else {

                                    formContext.getControl("rsa_opportunityid").clearNotification(901);
                                }
                                if (status === "Renewed" && caseType !== "Renewal - Isle of Man" && bool === true && crisisManagement ===
                                    null) {
                                    formContext.getControl("rsa_opportunityid").setNotification("Crisis Management cover must be completed on the opportunity when the status is set as 'Renewed'", 902);
                                }
                                else {

                                    formContext.getControl("rsa_opportunityid").clearNotification(902);
                                }
                            } else {
                                //Xrm.Utility.alertDialog(this.statusText);
                                Xrm.Navigation.openAlertDialog(this.statusText);
                            }
                        }
                    };
                    req.send();
                }

            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "CrisisManagmentCoverNB -" + err.message });
        }
    },

    //Author : Nida Mulla
    //Date : 3 Aug 2020
    //This  Function is to Validate EPromise Cant Close When InPlay

    /* Change Summary for April 2022 Release 1 */
    /* Last Modified By: Shreya Diwate*/
    /* Summary of Changes: Replace Xrm.Utility.alertDialog(this.responseText) with Xrm.Navigation.openAlertDialog */
    /* - Reason for Change: Xrm.Utility.alertDialog(this.responseText)' uses a deprecated API*/
    /* - Function name - EPromiseCantCloseWhenInPlay */

    /* Change Summary for April 2022 Release 1 */
    /* Last Modified By: Shreya Diwate*/
    /* Summary of Changes: Replace Xrm.Page.context with Execution Xrm.Utility.getGlobalContext*/
    /* - Reason for Change:Xrm.Page.context deprecated API*/
    /* - Function name - EPromiseCantCloseWhenInPlay */

    EPromiseCantCloseWhenInPlay: function (executionContext) {
        try {
            var globalContext = Xrm.Utility.getGlobalContext();
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_casetype") !== null && formContext.getAttribute("rsa_opportunityid") !== null &&
                formContext.getAttribute("rsa_status").getValue() !== null && formContext.getAttribute("rsa_casetype").getValue() !== null && formContext.getAttribute("rsa_opportunityid").getValue() !== null &&
                formContext.getAttribute("rsa_status").getValue() !== undefined && formContext.getAttribute("rsa_casetype").getValue() !== undefined && formContext.getAttribute("rsa_opportunityid").getValue() !== undefined) {

                var status = null, caseType = null;
                status = formContext.getAttribute("rsa_status").getValue()[0].name;
                caseType = formContext.getAttribute("rsa_casetype").getValue()[0].name;

                var opportunityId = RSA.D365CRM.Case.Main.ConvertGuid(formContext.getAttribute("rsa_opportunityid").getValue()[0].id);


                if (opportunityId !== null) {
                    var req = new XMLHttpRequest();
                    /*req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v9.1/opportunities(" + opportunityId + ")?$select=_rsa_opportunitystage_value", true);*/

                    req.open("GET", globalContext.getClientUrl() + "/api/data/v9.1/opportunities(" + opportunityId + ")?$select=_rsa_opportunitystage_value", true);

                    req.setRequestHeader("OData-MaxVersion", "4.0");
                    req.setRequestHeader("OData-Version", "4.0");
                    req.setRequestHeader("Accept", "application/json");
                    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                    req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                    req.onreadystatechange = function () {
                        if (this.readyState === 4) {
                            req.onreadystatechange = null;
                            if (this.status === 200) {
                                var result = JSON.parse(this.response);
                                var _rsa_opportunitystage_value = result["_rsa_opportunitystage_value"];
                                var _rsa_opportunitystage_value_formatted = result["_rsa_opportunitystage_value@OData.Community.Display.V1.FormattedValue"];
                                var _rsa_opportunitystage_value_lookuplogicalname = result["_rsa_opportunitystage_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                                if (status === "Closed" && (caseType === "ePromise") && (_rsa_opportunitystage_value_formatted === "In Play")) {
                                    formContext.getControl("rsa_status").setNotification("The case cannot be closed until the status has been updated to 'Accepted', 'Not Taken Up' or 'Diverted'", 204);
                                }
                                else {

                                    formContext.getControl("rsa_status").clearNotification(204);
                                }
                            } else {
                                //Xrm.Utility.alertDialog(this.statusText);
                                Xrm.Navigation.openAlertDialog(this.statusText);
                            }
                        }
                    };
                    req.send();
                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "EPromiseCantCloseWhenInPlay -" + err.message });
        }
    },


    /* Change Summary for April 2022 Release 1 */
    /* Last Modified By: Shreya Diwate*/
    /* Summary of Changes: Replace Xrm.Page.context with Execution Xrm.Utility.getGlobalContext*/
    /* - Reason for Change:Xrm.Page.context deprecated API*/
    /* - Function name - OnlyOneCasePerOpportunityValidation */

    //function to Validate Opportunity Case Linkage

    OnlyOneCasePerOpportunityValidation: function (executionContext) {
        try {
            var globalContext = Xrm.Utility.getGlobalContext();
            var formContext = executionContext.getFormContext();
            var opportunityCase, opportunityId;
            if (formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_casetype") !== null && formContext.getAttribute("rsa_opportunityid") !== null &&
                formContext.getAttribute("rsa_status").getValue() !== null && formContext.getAttribute("rsa_casetype").getValue() !== null && formContext.getAttribute("rsa_opportunityid").getValue() !== null &&
                formContext.getAttribute("rsa_status").getValue() !== undefined && formContext.getAttribute("rsa_casetype").getValue() !== undefined && formContext.getAttribute("rsa_opportunityid").getValue() !== undefined) {
                if (formContext.getAttribute("rsa_status").getValue() !== null) {
                    status = formContext.getAttribute("rsa_status").getValue()[0].name;
                }
                if (formContext.getAttribute("rsa_opportunityid").getValue() !== null) {
                    opportunityId = RSA.D365CRM.Case.Main.ConvertGuid(formContext.getAttribute("rsa_opportunityid").getValue()[0].id);

                    var req = new XMLHttpRequest();
                    /*req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v9.1/opportunities(" + opportunityId + ")?$select=_rsa_case_value", true);*/
                    req.open("GET", globalContext.getClientUrl() + "/api/data/v9.1/opportunities(" + opportunityId + ")?$select=_rsa_case_value", true);
                    req.setRequestHeader("OData-MaxVersion", "4.0");
                    req.setRequestHeader("OData-Version", "4.0");
                    req.setRequestHeader("Accept", "application/json");
                    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                    req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                    req.onreadystatechange = function () {
                        if (this.readyState === 4) {
                            req.onreadystatechange = null;
                            if (this.status === 200) {
                                var result = JSON.parse(this.response);
                                var _rsa_case_value = result["_rsa_case_value"];
                                var _rsa_case_value_formatted = result["_rsa_case_value@OData.Community.Display.V1.FormattedValue"];
                                var _rsa_case_value_lookuplogicalname = result["_rsa_case_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                                if (_rsa_case_value !== null && _rsa_case_value !== undefined) {
                                    opportunityCase = _rsa_case_value;
                                    if (opportunityCase !== null && opportunityCase !== undefined) { opportunityCase.toUpperCase(); }


                                    if (opportunityId !== null && opportunityCase !== null && opportunityId !== undefined && opportunityCase !== undefined) {
                                        formContext.getControl("rsa_opportunityid").setNotification("opportunity is already linked to a Case", 1115);
                                    }
                                }
                                else {

                                    formContext.getControl("rsa_opportunityid").clearNotification(1115);
                                }



                            }
                        }
                    };
                    req.send();

                }
            }
        }

        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "OnlyOneCasePerOpportunityValidation -" + err.message });
        }
    },



    ////////////////
    //function to Validate Opportunity for Case before status Update
    CaseStatusValidation: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_casetype") !== null && formContext.getAttribute("rsa_opportunityid") !== null &&
                formContext.getAttribute("rsa_status").getValue() !== null && formContext.getAttribute("rsa_casetype").getValue() !== null &&
                formContext.getAttribute("rsa_status").getValue() !== undefined && formContext.getAttribute("rsa_casetype").getValue() !== undefined) {

                var status = null, caseType = null, opportunityId = null;
                status = formContext.getAttribute("rsa_status").getValue()[0].name;
                caseType = formContext.getAttribute("rsa_casetype").getValue()[0].name;
                opportunityId = formContext.getAttribute("rsa_opportunityid").getValue();

                // Case Type: New Buisness :New Business
                // Renewal:166DD87C-57BC-EA11-A812-000D3AF01A07

                if (opportunityId === null && (status === "Initial Processing" || status === "Closed") && (caseType === "New Business" || caseType === "Renewal")) {
                    formContext.getControl("rsa_opportunityid").clearNotification(1116);
                    formContext.getAttribute("rsa_opportunityid").setRequiredLevel("none");

                }

                else if (opportunityId !== null) {
                    formContext.getControl("rsa_opportunityid").clearNotification(1116);
                    formContext.getAttribute("rsa_opportunityid").setRequiredLevel("none");
                }

                else if (caseType === "New Business" || caseType === "Renewal") {
                    formContext.getControl("rsa_opportunityid").setNotification("An Opportunity must be created in order to move the Case Status beyond 'Initial Processing'", 1116);
                    formContext.getAttribute("rsa_opportunityid").setRequiredLevel("required");
                }
            }

        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "CaseStatusValidation -" + err.message });
        }
    },

    //function to Validate Opportunity for Case before status Update
    NBCantCloseUnlessOutcomeReached: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_casetype") !== null && formContext.getAttribute("rsa_opportunityid") !== null &&
                formContext.getAttribute("rsa_status").getValue() !== null && formContext.getAttribute("rsa_casetype").getValue() !== null && formContext.getAttribute("rsa_opportunityid").getValue() !== null &&
                formContext.getAttribute("rsa_status").getValue() !== undefined && formContext.getAttribute("rsa_casetype").getValue() !== undefined && formContext.getAttribute("rsa_opportunityid").getValue() !== undefined) {
                var status = null, caseType = null;
                status = formContext.getAttribute("rsa_status").getValue()[0].name;
                caseType = formContext.getAttribute("rsa_casetype").getValue()[0].name;
                var systemuserId = RSA.D365CRM.Case.Main.ConvertGuid(Xrm.Utility.getGlobalContext().userSettings.userId);
                var opportunityId = RSA.D365CRM.Case.Main.ConvertGuid(formContext.getAttribute("rsa_opportunityid").getValue()[0].id);

                var division = RSA.D365CRM.Case.Main.RetriveUserDivison(systemuserId);
                var stageName = RSA.D365CRM.Case.Main.RetriveOpportunityStageLOB(opportunityId, "OpportunityStageName");

                //CaseType = New_Business,New_Business_Isle_Of_Man.
                //Stage =Renewed:866760022, Lapsed: 866760023, Decline to Renew :866760026
                // Opportunity.salesstage !== "Accepted"|| "Not Taken Up"||"Other"||"Diverted

                if (division !== '866760003' && status === "Closed" && (caseType === "New Business" || caseType === "New Business - Isle Of Man") && (stageName !== "Accepted" && stageName !== "Not Taken Up" && stageName !== "Other" && stageName !== "Diverted" && stageName !== "No Longer Required" && stageName !== "Redirect to SME")) {
                    formContext.getControl("rsa_status").setNotification("The case cannot be closed until the status has been updated to 'Accepted', 'Not Taken Up' or 'Diverted'.", 1117);
                }
                else {

                    formContext.getControl("rsa_status").clearNotification(1117);
                }
            }

        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "NBCantCloseUnlessOutcomeReached -" + err.message });
        }
    },

    //function to Validate fields  for Case before status Updated
    ProFinPIMandatoryValidation: function (executionContext) {
        try {
            //Case Type : all profin type
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_status") !== undefined && formContext.getAttribute("rsa_status").getValue() !== null && formContext.getAttribute("rsa_status").getValue() !== undefined && formContext.getAttribute("rsa_classofbusinessphoneenqid") !== null && formContext.getAttribute("rsa_classofbusinessphoneenqid") !== undefined && formContext.getAttribute("rsa_opportunityid") !== null && formContext.getAttribute("rsa_opportunityid") !== undefined && formContext.getAttribute("rsa_classofbusinessphoneenqid").getValue() !== null && formContext.getAttribute("rsa_classofbusinessphoneenqid").getValue() !== undefined) {
                var status = formContext.getAttribute("rsa_status").getValue()[0].name;
                var classOfBusiness = formContext.getAttribute("rsa_classofbusinessphoneenqid").getValue()[0].name;
                var opportunityId = RSA.D365CRM.Case.Main.ConvertGuid(formContext.getAttribute("rsa_opportunityid").getValue()[0].id);
                // Retrive QuoteNumber
                if (formContext.getAttribute("rsa_feesto") === null || formContext.getAttribute("rsa_rsadas") === null) return;

                var QuoteNumber = RSA.D365CRM.Case.Main.RetriveOpportunityStageLOB(opportunityId, "QuoteNumber");
                var FeesTO = formContext.getAttribute("rsa_feesto").getValue();
                var DAS = formContext.getAttribute("rsa_rsadas").getValue();

                //Status === Quoted
                //Class of Business === ProFin Regions - PI || ProFin London - PI

                if ((FeesTO === null || DAS === null || QuoteNumber === null) && status === "Quoted" && (classOfBusiness === "ProFin Regions - PI" || classOfBusiness === "ProFin London - PI")) {
                    formContext.getControl("rsa_status").setNotification("When the status has been moved to Quoted, Fees TO, DAS  on the Case  and Quote Number  on the Opportunity  must be completed", 1118);
                    formContext.getAttribute("rsa_feesto").setRequiredLevel("required");
                    formContext.getAttribute("rsa_rsadas").setRequiredLevel("required");
                }
                else {
                    formContext.getControl("rsa_status").clearNotification(1118);
                    formContext.getAttribute("rsa_feesto").setRequiredLevel("none");
                    formContext.getAttribute("rsa_rsadas").setRequiredLevel("required");
                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "ProFinPIMandatoryValidation -" + err.message });
        }
    },

    //function to Validate Case Status Based on case Type  
    CaseStatusReopen: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_casetype") !== null &&
                formContext.getAttribute("rsa_status").getValue() !== null && formContext.getAttribute("rsa_casetype").getValue() !== null &&
                formContext.getAttribute("rsa_status").getValue() !== undefined && formContext.getAttribute("rsa_casetype").getValue() !== undefined) {
                var caseTypeArray = ["SME - Powerplace Referral", "SME - RSA Online Referral", "SME - Renewal Review", "SME - Phone Enquiry", "SME - Email Enquiry", "SME - EDI Enquiry", "SME - EDI Referral", "SME - Live Chat", "SME - MID Update", "SME - Survey", "SME - eTraded Enquiry", "{}"];

                formContext = executionContext.getFormContext();
                var status = formContext.getAttribute("rsa_status").getValue()[0].name;
                var caseType = formContext.getAttribute("rsa_casetype").getValue()[0].name;
                //var hasValue = caseTypeArray.includes(caseType, 0);
                var hasValue = (caseTypeArray.indexOf(caseType) !== -1);
                if (status === "Closed (Closed)" && hasValue === true) {
                    formContext.getControl("rsa_status").setNotification("Case status must be 'Re-Opened' if the case has already been closed.", 1119);
                }
                else {
                    formContext.getControl("rsa_status").clearNotification(1119);
                }
            }

        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "CaseStatusReopen-" + err.message });
        }
    },


    ValidationBluePrism: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_casetype") !== null &&
                formContext.getAttribute("rsa_status").getValue() !== null && formContext.getAttribute("rsa_casetype").getValue() !== null &&
                formContext.getAttribute("rsa_status").getValue() !== undefined && formContext.getAttribute("rsa_casetype").getValue() !== undefined &&
                formContext.getAttribute("rsa_classofbusinessphoneenqid") !== null && formContext.getAttribute("rsa_classofbusinessphoneenqid").getValue() !== null) {

                formContext = executionContext.getFormContext();
                var status = formContext.getAttribute("rsa_status").getValue()[0].name;
                var caseType = formContext.getAttribute("rsa_casetype").getValue()[0].name;
                var classOfBuisness = formContext.getAttribute("rsa_classofbusinessphoneenqid").getValue()[0].name;
                var hasThePolicyBeenExtended = formContext.getAttribute("rsa_hasthepolicybeenextended");
                var claimSinceLastRenewal = formContext.getAttribute("rsa_claimsincelastrenewal");
                var inputEffectiveDate = formContext.getAttribute("rsa_inputeffectivedate");
                var timeOnRisk = formContext.getAttribute("rsa_timeonrisk");

                if ((status === "Lapsed" || status === "Declined to renew") && (caseType === "Revised Renewal" || caseType === "Revised Renewal - Profin" || caseType === "Case Layout" || caseType === "MTA" || caseType === "MTA Admin" || caseType === "Renewal") && (classOfBuisness !== null && classOfBuisness === "ProFin Regions - PI" || classOfBuisness === "ProFin London - PI")) {
                    //if (inputEffectiveDate !== null && inputEffectiveDate !== undefined)
                    //{
                    //    if (inputEffectiveDate.getValue() === null && hasThePolicyBeenExtended !== null && hasThePolicyBeenExtended.getValue() === false && claimSinceLastRenewal !== null && claimSinceLastRenewal.getValue() === false ) {
                    //        formContext.getControl("rsa_inputeffectivedate").setNotification("Please complete the Input Effective Date", 10);
                    //    }
                    //    else {
                    //        formContext.getControl("rsa_inputeffectivedate").clearNotification(10);
                    //    }
                    //}
                    if (timeOnRisk !== null && timeOnRisk !== undefined) {
                        if (timeOnRisk.getValue() === null && inputEffectiveDate !== null && inputEffectiveDate.getValue() === null && hasThePolicyBeenExtended !== null && hasThePolicyBeenExtended.getValue() === '866760001' && claimSinceLastRenewal !== null && claimSinceLastRenewal.getValue() === '866760001') {
                            formContext.getControl("rsa_timeonrisk").setNotification("Please complete the Input Effective Date and Input Time on Risk", 11);
                        }
                        else {
                            formContext.getControl("rsa_timeonrisk").clearNotification(11);
                        }

                        if (timeOnRisk.getValue() === null && inputEffectiveDate !== null && inputEffectiveDate.getValue() === null && hasThePolicyBeenExtended !== null && hasThePolicyBeenExtended.getValue() === '866760001' && claimSinceLastRenewal !== null && claimSinceLastRenewal.getValue() === '866760000') {
                            formContext.getControl("rsa_timeonrisk").setNotification("Please complete the Input Effective Date and Input Time on Risk", 12);
                            formContext.getControl("rsa_inputeffectivedate").setNotification("Please complete the Input Effective Date and Input Time on Risk", 15);
                        }
                        else {
                            formContext.getControl("rsa_timeonrisk").clearNotification(12);
                            formContext.getControl("rsa_inputeffectivedate").clearNotification(15);
                        }
                        if (timeOnRisk.getValue() === null && inputEffectiveDate !== null && inputEffectiveDate.getValue() === null && hasThePolicyBeenExtended !== null && hasThePolicyBeenExtended.getValue() === '866760000' && claimSinceLastRenewal !== null && claimSinceLastRenewal.getValue() === '866760001') {
                            formContext.getControl("rsa_timeonrisk").setNotification("Please complete the Input Effective Date and Input Time on Risk", 13);
                            formContext.getControl("rsa_inputeffectivedate").setNotification("Please complete the Input Effective Date and Input Time on Risk", 16);
                        }
                        else {
                            formContext.getControl("rsa_timeonrisk").clearNotification(13);
                            formContext.getControl("rsa_inputeffectivedate").clearNotification(16);

                        }
                    }
                    if (hasThePolicyBeenExtended !== null && claimSinceLastRenewal !== null) {
                        if (hasThePolicyBeenExtended.getValue() === null && claimSinceLastRenewal.getValue() === null) {
                            formContext.getControl("rsa_claimsincelastrenewal").setNotification(" Please complete the Claim Since Last Renewal Field and Has the Policy been extended field", 14);
                        }
                        else {
                            formContext.getControl("rsa_claimsincelastrenewal").clearNotification(14);
                        }
                    }
                }
            }

        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "ValidationBluePrism -" + err.message });
        }
    },

    //Author : Nida Mulla
    //Date : 7 Aug 2020
    //function to Validate Expiry Premium for Opportunity 
    ExpiryPremiumMidMarket: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_casetype") !== null && formContext.getAttribute("rsa_opportunityid") !== null && formContext.getAttribute("rsa_status").getValue() !== null && formContext.getAttribute("rsa_casetype").getValue() !== null && formContext.getAttribute("rsa_opportunityid").getValue() !== null && formContext.getAttribute("rsa_status").getValue() !== undefined && formContext.getAttribute("rsa_casetype").getValue() !== undefined && formContext.getAttribute("rsa_opportunityid").getValue() !== undefined) {
                var status, caseType, opportunityExpiryPremium, Pl, opportunityData;
                status = formContext.getAttribute("rsa_status").getValue()[0].name.toUpperCase();
                caseType = formContext.getAttribute("rsa_casetype").getValue()[0].name;

                if (formContext.getAttribute("rsa_opportunityid").getValue() !== null) {
                    if (RSA.D365CRM.Case.Main.opportunityData !== null) {
                        opportunityData = RSA.D365CRM.Case.Main.opportunityData;
                    }
                    else {
                        opportunityData = RSA.D365CRM.Case.Main.RetriveOpportunityData(executionContext);
                    }
                    if (opportunityData.hasOwnProperty("rsa_rsaexpirypremium")) {
                        opportunityExpiryPremium = opportunityData["rsa_rsaexpirypremium"];
                    }
                    if (opportunityData.hasOwnProperty("_rsa_pandlid_value")) {
                        Pl = opportunityData["_rsa_pandlid_value@OData.Community.Display.V1.FormattedValue"];
                    }
                }

                //CaseType = New_Business
                //RSA_ PL = Mid Market
                //Stage =In Play-3B31F275-DCD0-EA11-A813-000D3A7F2292
                //status = To Be Quoted

                if (status === "TO BE QUOTED" && caseType === "New Business" && Pl === "Mid-Market" && opportunityExpiryPremium === null && formContext.getAttribute("rsa_opportunityid").getValue() !== null) {
                    formContext.getControl("rsa_opportunityid").setNotification(" 'Expiry Premium' must be completed on the opportunity before moving the status to 'To Be Quoted'", 1119);


                }
                else {

                    formContext.getControl("rsa_opportunityid").clearNotification(1119);

                }
            }

        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "ExpiryPremiumMidMarket -" + err.message });
        }
    },
    /* Change Summary for April 2022 Release 1 */
    /* Last Modified By: Shreya Diwate*/
    /* Summary of Changes: Remove Debug Code*/
    /* - Reason for Change: Unexpected 'debugger' statement */
    /* - Function name - IfOppisNotTakenUporLapsedValidation */

    /* Change Summary for April 2022 Release 1 */
    /* Last Modified By: Shreya Diwate*/
    /* Summary of Changes: Replace Xrm.Utility.alertDialog(this.responseText) with Xrm.Navigation.openAlertDialog */
    /* - Reason for Change: Xrm.Utility.alertDialog(this.responseText)' uses a deprecated API*/
    /* - Function name - IfOppisNotTakenUporLapsedValidation */


    /* Change Summary for April 2022 Release 1 */
    /* Last Modified By: Shreya Diwate*/
    /* Summary of Changes: Replace Xrm.Page.context with Execution Xrm.Utility.getGlobalContext*/
    /* - Reason for Change:Xrm.Page.context deprecated API*/
    /* - Function name - IfOppisNotTakenUporLapsedValidation */

    //function to Validate  Premium Lost For, Outcome Insurer for Opportunity

    IfOppisNotTakenUporLapsedValidation: function (executionContext) {
        //debugger;
        try {
            var globalContext = Xrm.Utility.getGlobalContext();
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_status").getValue() !== null && formContext.getAttribute("rsa_status").getValue() !== undefined && formContext.getAttribute("rsa_casetype") !== null && formContext.getAttribute("rsa_casetype").getValue() !== null && formContext.getAttribute("rsa_casetype").getValue() !== undefined && formContext.getAttribute("rsa_opportunityid") !== null && formContext.getAttribute("rsa_opportunityid").getValue() !== null && formContext.getAttribute("rsa_opportunityid").getValue() !== undefined && formContext.getAttribute("rsa_statusreason") !== null && formContext.getAttribute("rsa_statusreason").getValue() !== null && formContext.getAttribute("rsa_statusreason").getValue() !== undefined) {
                //var opportunityStage, Premiumlostfor, OutcomeInsurer, Pl, opportunityData;
                var casestatus = formContext.getAttribute("rsa_status").getValue()[0].name;
                var statusReason = formContext.getAttribute("rsa_statusreason").getValue()[0].name;

                var opportunityId = RSA.D365CRM.Case.Main.ConvertGuid(formContext.getAttribute("rsa_opportunityid").getValue()[0].id);

                //alert("Hi");

                var req = new XMLHttpRequest();
                /*req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v9.1/opportunities(" + opportunityId + ")?$select=_rsa_opportunitystage_value,_rsa_outcomeinsurer_value,_rsa_pandlid_value,rsa_premiumlostfor", true);*/

                req.open("GET", globalContext.getClientUrl() + "/api/data/v9.1/opportunities(" + opportunityId + ")?$select=_rsa_opportunitystage_value,_rsa_outcomeinsurer_value,_rsa_pandlid_value,rsa_premiumlostfor", true);

                req.setRequestHeader("OData-MaxVersion", "4.0");
                req.setRequestHeader("OData-Version", "4.0");
                req.setRequestHeader("Accept", "application/json");
                req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                req.onreadystatechange = function () {
                    if (this.readyState === 4) {
                        req.onreadystatechange = null;
                        if (this.status === 200) {
                            var result = JSON.parse(this.response);
                            var _rsa_opportunitystage_value = result["_rsa_opportunitystage_value"];
                            var _rsa_opportunitystage_value_formatted = result["_rsa_opportunitystage_value@OData.Community.Display.V1.FormattedValue"];
                            var _rsa_opportunitystage_value_lookuplogicalname = result["_rsa_opportunitystage_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                            var _rsa_outcomeinsurer_value = result["_rsa_outcomeinsurer_value"];
                            var _rsa_outcomeinsurer_value_formatted = result["_rsa_outcomeinsurer_value@OData.Community.Display.V1.FormattedValue"];
                            var _rsa_outcomeinsurer_value_lookuplogicalname = result["_rsa_outcomeinsurer_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                            var _rsa_pandlid_value = result["_rsa_pandlid_value"];
                            var _rsa_pandlid_value_formatted = result["_rsa_pandlid_value@OData.Community.Display.V1.FormattedValue"];
                            var _rsa_pandlid_value_lookuplogicalname = result["_rsa_pandlid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                            var rsa_premiumlostfor = result["rsa_premiumlostfor"];
                            var rsa_premiumlostfor_formatted = result["rsa_premiumlostfor@OData.Community.Display.V1.FormattedValue"];

                            if (casestatus === "Closed" && formContext.getAttribute("rsa_opportunityid").getValue() !== null && (_rsa_opportunitystage_value_formatted === "Not Taken Up" || _rsa_opportunitystage_value_formatted === "Lapsed") && (statusReason !== "Broker Lost Control" || statusReason !== "Insurance no longer required" || statusReason !== "Broker not appointed") && _rsa_pandlid_value_formatted !== "GSL - Real Estate" && _rsa_outcomeinsurer_value === null && rsa_premiumlostfor === null) {
                                formContext.getControl("rsa_opportunityid").setNotification("The following values on the Opportunity must be completed before the case can be Closed: Premium Lost For, Outcome Insurer", 1120);
                            }
                            else {
                                formContext.getControl("rsa_opportunityid").clearNotification(1120);
                            }

                        } else {
                            //Xrm.Utility.alertDialog(this.statusText);
                            Xrm.Navigation.openAlertDialog(this.statusText);
                        }
                    }
                };
                req.send();
            }

        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "IfOppisNotTakenUporLapsedValidation -" + err.message });
        }
    },

    //function to Validate  Technical Price for Opportunity
    TechnicalPriceGSLRegionalCERE: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_status").getValue() !== null && formContext.getAttribute("rsa_status").getValue() !== undefined && formContext.getAttribute("rsa_casetype") !== null && formContext.getAttribute("rsa_casetype").getValue() !== null && formContext.getAttribute("rsa_casetype").getValue() !== undefined && formContext.getAttribute("rsa_opportunityid") !== null) {
                var status, caseType, Pl, technicalPrice, opportunityData;

                status = formContext.getAttribute("rsa_status").getValue()[0].name;
                caseType = formContext.getAttribute("rsa_casetype").getValue()[0].name;

                if (formContext.getAttribute("rsa_opportunityid").getValue() !== null) {
                    if (RSA.D365CRM.Case.Main.opportunityData !== null) {
                        opportunityData = RSA.D365CRM.Case.Main.opportunityData;
                    }
                    else {
                        opportunityData = RSA.D365CRM.Case.Main.RetriveOpportunityData(executionContext);
                    }

                    // Samiksha Dhakde: 08/09/2022
                    // CR:2159 Hiding of currency symbol: Replacing currency field to decimal field: rsa_technicalprice to rsa_opptytechnicalprice_dc.
                    if (opportunityData.hasOwnProperty("rsa_opptytechnicalprice_dc")) {
                        technicalPrice = opportunityData["rsa_opptytechnicalprice_dc"];
                    }

                    if (opportunityData.hasOwnProperty("_rsa_pandlid_value")) {
                        Pl = opportunityData["_rsa_pandlid_value@OData.Community.Display.V1.FormattedValue"];
                    }
                }
                if ((status === "Quoted" || status === "Accepted" || status === "Not Taken Up") && (caseType === "New Business" || caseType === "Renewal") && Pl === "GSL - Regional CE&RE" && technicalPrice === null && formContext.getAttribute("rsa_opportunityid").getValue() !== null) {
                    formContext.getControl("rsa_opportunityid").setNotification("technical Price must be populated on the opportunity before moving   the case to any of these status 'Quoted', 'Accepted', 'Not Taken Up'", 1121);
                }
                else {
                    formContext.getControl("rsa_opportunityid").clearNotification(1121);
                }
            }

        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "TechnicalPriceGSLRegionalCERE -" + err.message });
        }
    },

    //function to Validate  Technical Price and Class of Buisness for Opportunity
    TechnicalPrice: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_status").getValue() !== null
                && formContext.getAttribute("rsa_status").getValue() !== undefined && formContext.getAttribute("rsa_casetype") !== null
                && formContext.getAttribute("rsa_casetype").getValue() !== null && formContext.getAttribute("rsa_casetype").getValue() !== undefined
                && formContext.getAttribute("rsa_opportunityid") !== null && formContext.getAttribute("rsa_classofbusiness") !== null && formContext.getAttribute("rsa_classofbusiness").getValue() !== null) {
                var status, caseType, Pl, technicalPrice, classOfBuisness, opportunityData;

                status = formContext.getAttribute("rsa_status").getValue()[0].name;
                caseType = formContext.getAttribute("rsa_casetype").getValue()[0].name;
                classOfBuisness = formContext.getAttribute("rsa_classofbusiness").getValue();

                if (formContext.getAttribute("rsa_opportunityid").getValue() !== null) {
                    if (RSA.D365CRM.Case.Main.opportunityData !== null) {
                        opportunityData = RSA.D365CRM.Case.Main.opportunityData;
                    }
                    else {
                        opportunityData = RSA.D365CRM.Case.Main.RetriveOpportunityData(executionContext);
                    }
                    // Samiksha Dhakde: 08/09/2022
                    // CR:2159 Hiding of currency symbol: Replacing currency field to decimal field: rsa_technicalprice to rsa_opptytechnicalprice_dc.
                    if (opportunityData.hasOwnProperty("rsa_opptytechnicalprice_dc")) {
                        technicalPrice = opportunityData["rsa_opptytechnicalprice_dc"];
                    }

                    if (opportunityData.hasOwnProperty("_rsa_pandlid_value")) {
                        Pl = opportunityData["_rsa_pandlid_value@OData.Community.Display.V1.FormattedValue"];
                    }
                }
                if ((status === "Quoted" || status === "Accepted" || status === "Not Taken Up" || status === "Renewed" || status === "Lapsed") && (caseType === "New Business" || caseType === "Renewal") && (Pl === "GSL - Profin" || classOfBuisness === "Motor Fleet") && technicalPrice === null && formContext.getAttribute("rsa_opportunityid").getValue() !== null) {
                    formContext.getControl("rsa_opportunityid").setNotification("Technical Price must be populated on the opportunity  before moving the case to any of these status 'Quoted', 'Accepted', 'Not Taken Up', 'Renewed', 'Lapsed'.", 1122);
                }
                else {
                    formContext.getControl("rsa_opportunityid").clearNotification(1122);
                }

            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "TechnicalPrice -" + err.message });
        }
    },



    //function to Validate  Technical Price for Opportunity
    EnterTargetPremiumReactive: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_status").getValue() !== null && formContext.getAttribute("rsa_status").getValue() !== "undefined" && formContext.getAttribute("rsa_casetype") !== null && formContext.getAttribute("rsa_casetype").getValue() !== null && formContext.getAttribute("rsa_casetype").getValue() !== "undefined" && formContext.getAttribute("rsa_opportunityid") !== null) {
                var Pl, TargetPremium, opportunityRecordType, opportunityData;

                var status = formContext.getAttribute("rsa_status").getValue()[0].name;
                if (formContext.getAttribute("rsa_opportunityid").getValue() !== null) {
                    if (RSA.D365CRM.Case.Main.opportunityData !== null) {
                        opportunityData = RSA.D365CRM.Case.Main.opportunityData;
                    }
                    else {
                        opportunityData = RSA.D365CRM.Case.Main.RetriveOpportunityData(executionContext);
                    }
                    if (opportunityData.hasOwnProperty("_rsa_lineofbusiness_value")) {
                        opportunityRecordType = opportunityData["_rsa_lineofbusiness_value@OData.Community.Display.V1.FormattedValue"]
                    }

                    if (opportunityData.hasOwnProperty("rsa_targetpremium")) {
                        TargetPremium = opportunityData["rsa_targetpremium"];
                    }
                    if (opportunityData.hasOwnProperty("_rsa_pandlid_value")) {
                        Pl = opportunityData["_rsa_pandlid_value@OData.Community.Display.V1.FormattedValue"];
                    }
                }
                if (opportunityRecordType !== undefined && opportunityRecordType !== null && Pl !== undefined && Pl !== null && TargetPremium !== undefined) {
                    //opportunityRecordType = RSA.D365CRM.Case.Main.ConvertGuid(opportunityRecordType).toUpperCase();

                    if (status === "Quoted" && (opportunityRecordType === "New Business" || opportunityRecordType === "New Business - Real Estate" || opportunityRecordType === "New Business - Schemes & Deals") && Pl !== "GSL - Real Estate" && TargetPremium === null && formContext.getAttribute("rsa_opportunityid").getValue() !== null) {

                        formContext.getControl("rsa_opportunityid").setNotification("Target Premium' field must be populated on the opportunity before moving the case to status 'Quoted'.", 1123);
                    }
                    else {
                        formContext.getControl("rsa_opportunityid").clearNotification(1123);
                    }
                }
            }

        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "EnterTargetPremiumReactive -" + err.message });
        }
    },

    //Author : Nida Mulla
    //Date : 8 Aug 2020
    //This Generic Function is for Retriving data for Policy
    policyData: {},
    RetrivePolicyData: function (executionContext) {
        var formContext = executionContext.getFormContext();
        //var opportunityData;
        try {
            if (formContext.getAttribute("rsa_policyid") !== null && formContext.getAttribute("rsa_policyid") !== undefined) {
                if (formContext.getAttribute("rsa_policyid").getValue() !== null) {
                    var policyId = RSA.D365CRM.Case.Main.ConvertGuid(formContext.getAttribute("rsa_policyid").getValue()[0].id);
                    var req = new XMLHttpRequest();
                    var globalContext = Xrm.Utility.getGlobalContext();
                    var ClientUrl = globalContext.getClientUrl();
                    req.open("GET", ClientUrl + "/api/data/v8.2/rsa_policies(" + policyId + ")?$select=_rsa_plcode_value", true);
                    req.setRequestHeader("OData-MaxVersion", "4.0");
                    req.setRequestHeader("OData-Version", "4.0");
                    req.setRequestHeader("Accept", "application/json");
                    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                    req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                    req.onreadystatechange = function () {
                        if (this.readyState === 4) {
                            req.onreadystatechange = null;
                            if (this.status === 200) {
                                RSA.D365CRM.Case.Main.opportunityData = JSON.parse(this.response);

                            } else {
                                Xrm.Navigation.openAlertDialog({ text: "RetrivePolicyData" + this.statusText });
                            }
                        }
                    };
                    req.send();

                    return RSA.D365CRM.Case.Main.policyData;
                }
            }
        } catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "RetriveOpportunityValues -" + err.message });
        }
    },
    /*
        //function to Validate  P&L for Policy
        CSIRequiredpostfulfilmentactivities: function(executionContext) {
            try {
                var formContext = executionContext.getFormContext();
                if (formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_status").getValue() !== null && formContext.getAttribute("rsa_status").getValue() !== undefined
                    && formContext.getAttribute("rsa_casetype") !== null && formContext.getAttribute("rsa_casetype").getValue() !== null && formContext.getAttribute("rsa_casetype").getValue() !== undefined
                    && formContext.getAttribute("rsa_policyid") !== null && formContext.getAttribute("rsa_policyfulfilmentactivities") !== null) {
                    var caseReason = null;
                    var status = formContext.getAttribute("rsa_status").getValue()[0].name;
                    if (formContext.getAttribute("rsa_policyid").getValue() !== null) {
                        if (RSA.D365CRM.Case.Main.opportunityData !== null) {
                            policyData = RSA.D365CRM.Case.Main.policyData;
                        }
                        else {
                            policyData = RSA.D365CRM.Case.Main.RetrivePolicyData(executionContext);
                        }
                        if (policyData.hasOwnProperty("_rsa_lineofbusiness_value")) {
                            Pl = policyData["_rsa_plcode_value@OData.Community.Display.V1.FormattedValue"];
                        }
    
                    }
                    var policyFulfilmentActivities = formContext.getAttribute("rsa_policyfulfilmentactivities").getValue();
                    var caseType = formContext.getAttribute("rsa_casetype").getValue()[0].id;
    
                    if (((status === "Accepted" && caseType === "New Business") || (status === "Renewed" && caseType === "Renewal")
                        || (status === "Completed" && caseType === "MTA" && Pl !== "GSL - Real Estate" &&
                            (formContext.getAttribute("rsa_casereasonrsa") !== null && formContext.getAttribute("rsa_casereasonrsa").getValue() !== null && formContext.getAttribute("rsa_casereasonrsa").getValue() !== undefined && caseReason === 866760028 || caseReason === 866760027))
                        || (status === "Renewed" && caseType === "Revised Renewal")) &&
                        policyFulfilmentActivities === null) {
                        formContext.getControl("rsa_rsapolicyfulfilmentactivities").setNotification("At least one post fulfilment activity must be selected.", 1124);
                        formContext.getAttribute("rsa_rsapolicyfulfilmentactivities").setRequiredLevel("required");
                    }
                    else {
                        formContext.getControl("rsa_rsapolicyfulfilmentactivities").clearNotification(1124);
                        formContext.getAttribute("rsa_rsapolicyfulfilmentactivities").setRequiredLevel("none");
                    }
                }
    
            }
            catch (err) {
                Xrm.Navigation.openAlertDialog({ text: "CSIRequiredpostfulfilmentactivities -" + err.message });
            }
        },
    */

    //EI_C_post_fulfilment_activities
    //SP
    EICpostfulfilmentactivities: function (ExecutionContext) {
        try {
            var formContext = ExecutionContext.getFormContext();
            var caseTypeName, statusName;
            if (formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_status") !== "undefined" && formContext.getAttribute("rsa_casetype") !== null && formContext.getAttribute("rsa_casetype") !== "undefined" && formContext.getAttribute("rsa_rsapolicyfulfilmentactivities") !== null && formContext.getAttribute("rsa_rsapolicyfulfilmentactivities") !== "undefined" && formContext.getAttribute("rsa_rsapolicyfulfilmentactivities") !== null) {

                if (formContext.getAttribute("rsa_casetype").getValue() !== null) {
                    caseTypeName = formContext.getAttribute("rsa_casetype").getValue()[0].name;

                }
                if (formContext.getAttribute("rsa_status").getValue() !== null) {
                    statusName = formContext.getAttribute("rsa_status").getValue()[0].name;
                }



                if (statusName === "Accepted" && caseTypeName === "EI&C New Business" && formContext.getAttribute("rsa_rsapolicyfulfilmentactivities").getValue() === null) {
                    formContext.getControl("rsa_rsapolicyfulfilmentactivities").setNotification("At least one post fulfilment activity must be selected.", 999);
                    formContext.getAttribute("rsa_rsapolicyfulfilmentactivities").setRequiredLevel("required");
                }

                else if (statusName === "Renewed" && caseTypeName === "EI&C Renewal Case" && formContext.getAttribute("rsa_rsapolicyfulfilmentactivities").getValue() === null) {
                    formContext.getControl("rsa_rsapolicyfulfilmentactivities").setNotification("At least one post fulfilment activity must be selected.", 999);
                    formContext.getAttribute("rsa_rsapolicyfulfilmentactivities").setRequiredLevel("required");
                }

                else if (statusName === "Completed" && caseTypeName === "EI&C MTA Case" && formContext.getAttribute("rsa_rsapolicyfulfilmentactivities").getValue() === null) {
                    formContext.getControl("rsa_rsapolicyfulfilmentactivities").setNotification("At least one post fulfilment activity must be selected.", 999);
                    formContext.getAttribute("rsa_rsapolicyfulfilmentactivities").setRequiredLevel("required");
                }
                else {
                    formContext.getControl("rsa_rsapolicyfulfilmentactivities").clearNotification(999);
                    formContext.getAttribute("rsa_rsapolicyfulfilmentactivities").setRequiredLevel("none");
                }

            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "EI_C_post_fulfilment_activities-" + err.message });
        }
    },
    //Author : Prachi Paunikar

    CSIRequiredpostfulfilmentactivities: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            var caseTypeName, statusName, casereason, policyData, Pl;
            if (formContext.getAttribute("rsa_status") !== IsNull && formContext.getAttribute("rsa_status") !== undefined && formContext.getAttribute("rsa_casetype") !== IsNull && formContext.getAttribute("rsa_casetype") !== undefined && formContext.getAttribute("rsa_rsapolicyfulfilmentactivities") !== IsNull && formContext.getAttribute("rsa_rsapolicyfulfilmentactivities") !== undefined && formContext.getAttribute("rsa_rsapolicyfulfilmentactivities") !== null) {
                if (formContext.getAttribute("rsa_casetype").getValue() === null) {
                    return;

                }

                if (formContext.getAttribute("rsa_casetype").getValue() !== null) {
                    caseTypeName = formContext.getAttribute("rsa_casetype").getValue()[0].name;

                }
                if (formContext.getAttribute("rsa_status").getValue() !== null) {
                    statusName = formContext.getAttribute("rsa_status").getValue()[0].name;
                }



                if (statusName === "Accepted" && caseTypeName === "New Business" && formContext.getAttribute("rsa_rsapolicyfulfilmentactivities").getValue() === null) {
                    formContext.getControl("rsa_rsapolicyfulfilmentactivities").setNotification("At least one post fulfilment activity must be selected.", 1124);
                    formContext.getAttribute("rsa_rsapolicyfulfilmentactivities").setRequiredLevel("required");
                }

                else if (statusName === "Renewed" && caseTypeName === "Renewal" && formContext.getAttribute("rsa_rsapolicyfulfilmentactivities").getValue() === null) {
                    formContext.getControl("rsa_rsapolicyfulfilmentactivities").setNotification("At least one post fulfilment activity must be selected.", 1124);
                    formContext.getAttribute("rsa_rsapolicyfulfilmentactivities").setRequiredLevel("required");
                }

                else if (statusName === "Renewed" && caseTypeName === "Revised Renewal" && formContext.getAttribute("rsa_rsapolicyfulfilmentactivities").getValue() === null) {
                    formContext.getControl("rsa_rsapolicyfulfilmentactivities").setNotification("At least one post fulfilment activity must be selected.", 1124);
                    formContext.getAttribute("rsa_rsapolicyfulfilmentactivities").setRequiredLevel("required");
                }

                else if (caseTypeName === "Mid-Term Adjustment") {
                    if (formContext.getAttribute("rsa_rsapolicyfulfilmentactivities") !== null && formContext.getAttribute("rsa_rsapolicyfulfilmentactivities") !== undefined && formContext.getAttribute("rsa_casereasonrsa") !== null && formContext.getAttribute("rsa_casereasonrsa") !== undefined && formContext.getAttribute("rsa_policyid") !== null && formContext.getAttribute("rsa_policyid") !== undefined) {
                        if (formContext.getAttribute("rsa_casereasonrsa").getValue() !== null) {
                            casereason = formContext.getAttribute("rsa_casereasonrsa").getValue();
                        }

                        if (formContext.getAttribute("rsa_policyid").getValue() !== null) {

                            policyData = RSA.D365CRM.Case.Main.ConvertGuid(formContext.getAttribute("rsa_policyid").getValue()[0].id);
                            if (statusName === "Completed" && caseTypeName === "Mid-Term Adjustment" && (casereason === 866760027 || casereason === 866760028)) {
                                var req = new XMLHttpRequest();
                                var globalContext = Xrm.Utility.getGlobalContext();
                                var ClientUrl = globalContext.getClientUrl();
                                req.open("GET", ClientUrl + "/api/data/v9.1/rsa_policies(" + policyData + ")?$select=_rsa_plcode_value", true);
                                req.setRequestHeader("OData-MaxVersion", "4.0");
                                req.setRequestHeader("OData-Version", "4.0");
                                req.setRequestHeader("Accept", "application/json");
                                req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                                req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                                req.onreadystatechange = function () {
                                    if (this.readyState === 4) {
                                        req.onreadystatechange = null;
                                        if (this.status === 200) {
                                            var result = JSON.parse(this.response);
                                            var plcode = result["_rsa_plcode_value@OData.Community.Display.V1.FormattedValue"];
                                            if (plcode !== "GSL - Real Estate" && formContext.getAttribute("rsa_rsapolicyfulfilmentactivities").getValue() === null) {
                                                formContext.getControl("rsa_rsapolicyfulfilmentactivities").setNotification("At least one post fulfilment activity must be selected.", 1124);
                                                formContext.getAttribute("rsa_rsapolicyfulfilmentactivities").setRequiredLevel("required");
                                            }
                                            else if (formContext.getAttribute("rsa_rsapolicyfulfilmentactivities").getValue() !== null) {
                                                formContext.getControl("rsa_rsapolicyfulfilmentactivities").clearNotification(1124);
                                                formContext.getAttribute("rsa_rsapolicyfulfilmentactivities").setRequiredLevel("none");
                                            }
                                        } else {
                                            Xrm.Navigation.openAlertDialog({ text: "CompletedStatusbeforeMTACaseClosed " + this.statusText });
                                        }
                                    }
                                };
                                req.send();
                            }
                        }



                    }

                }




                else {
                    formContext.getControl("rsa_rsapolicyfulfilmentactivities").clearNotification(1124);
                    formContext.getAttribute("rsa_rsapolicyfulfilmentactivities").setRequiredLevel("none");
                }

            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "CSIRequiredpostfulfilmentactivities -" + err.message });
        }
    },
    //Author : Chandani Vaishnani
    //Date : 08 August 2020
    //This Function for Calculate the Case Age
    //Case_Age__c
    CalculateCaseAge: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_status") !== undefined && formContext.getAttribute("rsa_caseagersa") !== null && formContext.getAttribute("rsa_caseagersa") !== undefined) {
                var status, startDate, endDate;
                if (formContext.getAttribute("rsa_status").getValue() !== null) {
                    status = formContext.getAttribute("rsa_status").getValue()[0].name;
                }
                if (formContext.getAttribute("rsa_datetimeopened") !== null && formContext.getAttribute("rsa_datetimeopened") !== undefined) {
                    if (formContext.getAttribute("rsa_datetimeopened").getValue() !== null) {
                        startDate = new Date(formContext.getAttribute("rsa_datetimeopened").getValue());
                    }
                    else {
                        startDate = new Date();
                    }
                }
                else {
                    startDate = new Date();

                }
                if (status.indexOf("Closed") !== -1) {
                    if (formContext.getAttribute("rsa_datetimeclosed") !== null && formContext.getAttribute("rsa_datetimeclosed") !== undefined) {
                        if (formContext.getAttribute("rsa_datetimeclosed").getValue() !== null) {
                            endDate = new Date(formContext.getAttribute("rsa_datetimeclosed").getValue());
                        }
                        else {
                            endDate = new Date();
                        }
                    }
                }
                else {

                    endDate = new Date();
                }
                var caseAge = RSA.D365CRM.Case.Main.CalculateBusinessDays(startDate, endDate);
                formContext.getAttribute("rsa_caseagersa").setValue(caseAge);

            }

        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "CalculateCaseAge -" + err.message });
        }
    },

    //Author : Chandani Vaishnani
    //Date : 08 August 2020
    //This Generic Function for Calculate the Business Days
    CalculateBusinessDays: function (startDate, endDate) {
        var count = 0;
        var curDate = startDate;
        while (curDate <= endDate) {
            var dayOfWeek = curDate.getDay();
            if (!((dayOfWeek === 6) || (dayOfWeek === 0)))
                count++;
            curDate.setDate(curDate.getDate() + 1);
        }
        return count;
    },


    //Author : Shreya Diwate
    //Date : 10 August 2020 
    //Function for updating Open Activity Is Mine

    UpdateOpenActivityIsMine: function (executionContext) {


        try {

            var formContext = executionContext.getFormContext();

            var ownerId = formContext.getAttribute("ownerid").getValue()[0].name;
            var ownerId50 = ownerId.substring(0, 50);
            if (formContext.getAttribute("rsa_openactivityowners") !== null && formContext.getAttribute("rsa_openactivityowners") !== undefined) {
                var openActivityOwners = formContext.getAttribute("rsa_openactivityowners").getValue();
                if (openActivityOwners === ownerId50) {

                    formContext.getAttribute("rsa_openactivityismine").setValue("True");
                }
                else {
                    formContext.getAttribute("rsa_openactivityismine").setValue("False");
                }
            }
        }
        catch (e) {

            Xrm.Navigation.openAlertDialog({ text: "Error Message for Open Activity Is Mine : " + e.message });
        }

    },

    //Author : Shreya Diwate
    //Date : 10 August 2020 
    //Function for updating Is Open Activity My Teams 

    UpdateIsOpenActivityMyTeams: function (executionContext) {


        try {

            var formContext = executionContext.getFormContext();
            var isopenActivitymyTeams = formContext.getAttribute("rsa_isopenactivitymyteams").getValue();
            var openActivityTeams = formContext.getAttribute("rsa_openactivityteams ").getValue();
            var openActivityTeams2 = formContext.getAttribute("rsa_openactivityteams2").getValue();
            var systemuserId = RSA.D365CRM.Case.Main.ConvertGuid(Xrm.Utility.getGlobalContext().userSettings.userId);
            var req = new XMLHttpRequest();
            var globalContext = Xrm.Utility.getGlobalContext();
            var ClientUrl = globalContext.getClientUrl();
            req.open("GET", ClientUrl + "/api/data/v9.1/systemusers(" + systemuserId + ")?$select=_rsa_userteamlevel2_value", true);
            req.setRequestHeader("OData-MaxVersion", "4.0");
            req.setRequestHeader("OData-Version", "4.0");
            req.setRequestHeader("Accept", "application/json");
            req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
            req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            req.onreadystatechange = function () {
                if (this.readyState === 4) {
                    req.onreadystatechange = null;
                    if (this.status === 200) {
                        var result = JSON.parse(this.response);
                        var _rsa_userteamlevel2_value = result["_rsa_userteamlevel2_value"];
                        var _rsa_userteamlevel2_value_formatted = result["_rsa_userteamlevel2_value@OData.Community.Display.V1.FormattedValue"];
                        var _rsa_userteamlevel2_value_lookuplogicalname = result["_rsa_userteamlevel2_value@Microsoft.Dynamics.CRM.lookuplogicalname"];

                        var userTeamLevel250 = _rsa_userteamlevel2_value_formatted.substring(0, 50);

                        if (_rsa_userteamlevel2_value_formatted === null) {
                            formContext.getAttribute("rsa_openactivityismine").setValue("False");
                        }
                        else {
                            if ((rsa_openactivityteams === userTeamLevel250) && (rsa_openactivityteams2 === userTeamLevel250)) {
                                formContext.getAttribute("rsa_openactivityismine").setValue("True");

                            }
                            else {
                                formContext.getAttribute("rsa_openactivityismine").setValue("False");
                            }

                        }

                    }


                    else {
                        Xrm.Navigation.openAlertDialog({ text: "UpdateIsOpenActivityMyTeams" + this.statusText });
                    }
                }
            };
            req.send();

        }
        catch (e) {

            Xrm.Navigation.openAlertDialog({ text: "Error Message for Open Activity My Teams  : " + e.message });
        }

    },
    //Author : Prachi Paunikqar
    //Date : 09 September 2020
    //This Function sets form ID of Case  form to a Field named CaseformId
    CaseFormID: function (executionContext) {
        /* try {
            var formContext = executionContext.getFormContext();
            var formId = formContext.ui.formSelector.getCurrentItem().getId();

            if (formContext.getAttribute("rsa_caseformid") !== null && formContext.getAttribute("rsa_caseformid") !== undefined) {

                formContext.getAttribute("rsa_caseformid").setValue(formId);
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "rsa_caseformid -" + err.message });
        } */

    },

    //Author : Prachi Paunikar
    //Date : 10 September 2020
    //This Function opens the correct form while opening the existing records
    LoadingExistingRecord: function (executionContext) {
        RedirectAccordingToCaseType(executionContext, "onload");
        /* debugger;
                try {
                    //RSA.D365CRM.Case.Main.OnLoadCaseType(executionContext);
                    var formContext = executionContext.getFormContext();
                    if (formContext.getAttribute("rsa_caseformid") !== null && formContext.getAttribute("rsa_caseformid") !== undefined && formContext.ui.getFormType() === 2) {
                        if (formContext.getAttribute("rsa_caseformid").getValue() !== null && formContext.getAttribute("rsa_caseformid").getValue() !== undefined) {
                            var caseFormID = formContext.getAttribute("rsa_caseformid").getValue();
                            var formId = formContext.ui.formSelector.getCurrentItem().getId();
                            if (formId.toLowerCase() !== caseFormID.toLowerCase()) {
                                formContext.ui.formSelector.items.get(caseFormID.toLowerCase()).navigate();
                            }
                        }
                        
                        if (formContext.getAttribute("rsa_caseformid").getValue() === null)
                        {
                            RedirectAccordingToCaseType(executionContext, "onchange")
                        }
                    }
                }
        
                catch (err) {
                    Xrm.Navigation.openAlertDialog({ text: "LoadingExistingRecord -" + err.message });
                } */
    },
    //Author : Shreya Diwate
    //Date : 21 September 2020
    //This Function Option set to Option set filtering


    CaseDependentOptionset: function (executionContext) {
        try {

            var formContext = executionContext.getFormContext();
            var caseType = formContext.getAttribute("rsa_casetype");
            if (caseType !== null && caseType != undefined && caseType.getValue() !== null && caseType.getValue() != undefined) {
                //var caseTypeID = RSA.D365CRM.Case.Main.ConvertGuid(caseType.getValue()[0].id);
                var caseTypeID = formContext.data.entity.attributes.get('rsa_casetype').getValue()[0].id;
                var req = new XMLHttpRequest();
                var globalContext = Xrm.Utility.getGlobalContext();
                var ClientUrl = globalContext.getClientUrl();

                req.open("GET", ClientUrl + "/api/data/v9.1/rsa_customlabels?$select=rsa_categories,rsa_customlabelid,_rsa_casetype_value,rsa_dependentoptionsetjson&$filter=_rsa_casetype_value eq " + caseTypeID, true);

                req.setRequestHeader("OData-MaxVersion", "4.0");
                req.setRequestHeader("OData-Version", "4.0");
                req.setRequestHeader("Accept", "application/json");
                req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                req.onreadystatechange = function () {
                    if (this.readyState === 4) {
                        req.onreadystatechange = null;
                        if (this.status === 200) {
                            var results = JSON.parse(this.response);
                            for (var i = 0; i < results.value.length; i++) {
                                var rsa_categories = results.value[i]["rsa_categories"];
                                var rsa_customlabelid = results.value[i]["rsa_customlabelid"];
                                var rsa_dependentoptionsetjson = results.value[i]["rsa_dependentoptionsetjson"];
                                var OptionSetObj = JSON.parse(results.value[i]["rsa_dependentoptionsetjson"]).ParentFieldDependency[0].OptionSet;
                                var lookupObj = JSON.parse(results.value[i]["rsa_dependentoptionsetjson"]).ParentFieldDependency[0].LookUp;
                                //JSON.parse(results.value[i]["rsa_dependentoptionsetjson"].ParentFieldDependency[0].Childs[0].ApplicableValue)
                                //JSON.parse(results.value[i]["rsa_dependentoptionsetjson"]).ParentFieldDependency[0].Childs[0].DependentField


                                for (var i = 0; i < OptionSetObj.length; i++) {

                                    var DependentField = OptionSetObj[i].DependentField;
                                    var ApplicableValue = OptionSetObj[i].ApplicableValue;
                                    var splitValue = ApplicableValue.split(",");
                                    var defaultValue = OptionSetObj[i].DefaultValue;

                                    if (formContext.getAttribute(DependentField) !== null && formContext.getAttribute(DependentField) !== undefined) {
                                        //var OptionSetValues = Xrm.Page.getAttribute(DependentField).getOptions();
                                        var OptionSetValues = formContext.getAttribute(DependentField).getOptions();

                                        for (var k = 0; k < OptionSetValues.length; k++) {
                                            if (splitValue.indexOf(OptionSetValues[k].value.toString()) === -1) {
                                                formContext.getControl(DependentField).removeOption(OptionSetValues[k].value);
                                            }
                                        }
                                        //Set  defualt Value for Option set 
                                        //***Please don't remove the condition***
                                        if (formContext.ui.getFormType() === 1) {

                                            /* Change Summary for July 2022 Release 1 */
                                            /* Last Modified By: Jyoti Bhosale*/
                                            /* Summary of Changes: Add below if condition for clone case */
                                            /* - Reason for Change: On Case clone button click Case reason field is not geting clone */
                                            /* - Function name - CaseDependentOptionset */
                                            if (formContext.getAttribute(DependentField).getValue() !== null && formContext.getAttribute(DependentField).getValue() !== undefined) {
                                                //Do not bind data
                                            }
                                            else {
                                                formContext.getAttribute(DependentField).setValue(defaultValue);
                                            }
                                        }
                                    }

                                }
                                for (var i = 0; i < lookupObj.length; i++) {

                                    var lookupDependentField = lookupObj[i].lookupDependentField;
                                    var Entity = lookupObj[i].lookupDefaultValue.Entity;
                                    if (Entity === undefined) {
                                        Entity = "rsa_status";
                                    }
                                    var GUID = lookupObj[i].lookupDefaultValue.GUID;
                                    var StatusName = lookupObj[i].lookupDefaultValue.StatusName;


                                    var lookupDefaultValue = lookupObj[i].lookupDefaultValue.rsa_statusname;
                                    if (formContext.getAttribute(lookupDependentField) !== null && formContext.getAttribute(lookupDependentField) !== undefined) {
                                        //Set  defualt Value for Option set 
                                        //formContext.getAttribute(lookupDependentField).setValue(lookupDefaultValue);
                                        //***Please don't remove the condition***
                                        if (formContext.ui.getFormType() === 1) {
                                            formContext.getAttribute(lookupDependentField).setValue([{ id: GUID, name: StatusName, entityType: Entity }]);
                                        }
                                    }
                                }

                            }

                        }
                        else {
                            Xrm.Navigation.openAlertDialog({ text: "DependentOptionset : " + this.statusText });
                        }
                    }
                };
                req.send();

            }

        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: " Option set value -" + err.message });
        }

    },

    /* Change Summary for April 2022 Release 1 */
    /* Last Modified By: Shreya Diwate*/
    /* Summary of Changes: Replace Xrm.Utility.alertDialog(this.responseText) with Xrm.Navigation.openAlertDialog */
    /* - Reason for Change: Xrm.Utility.alertDialog(this.responseText)' uses a deprecated API*/
    /* - Function name - CloseStatus */

    /* Change Summary for April 2022 Release 1 */
    /* Last Modified By: Shreya Diwate*/
    /* Summary of Changes: Replace Xrm.Page.context with Execution Xrm.Utility.getGlobalContext*/
    /* - Reason for Change:Xrm.Page.context deprecated API*/
    /* - Function name -  CloseStatus */

    CloseStatus: function (executionContext) {
        try {
            var globalContext = Xrm.Utility.getGlobalContext();
            var formContext = executionContext.getFormContext();
            var caseType = formContext.data.entity.attributes.get('rsa_casetype').getValue()[0].name;
            var caseTypeId = formContext.data.entity.attributes.get('rsa_casetype').getValue()[0].id;
            var fetchQuery = "<fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>" +
                "<entity name='rsa_status'>" +
                "<attribute name='rsa_name'/>" +
                "<attribute name='createdon'/>" +
                "<attribute name='rsa_casetype'/>" +
                "<attribute name='rsa_statusid'/>" +
                "<order descending='false' attribute='rsa_name'/>" +
                "<filter type='and'>" +
                "<condition attribute='rsa_name' value='Closed' operator='like'/>" +
                "<condition attribute='rsa_casetype' value='" + caseTypeId + "' operator='eq' uitype='rsa_casetype'/>" +
                "</filter>" +
                "</entity>" +
                "</fetch>";


            var req = new XMLHttpRequest();
            /*req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v9.1/rsa_statuses?fetchXml=" + encodeURIComponent(fetchQuery), true);*/
            req.open("GET", globalContext.getClientUrl() + "/api/data/v9.1/rsa_statuses?fetchXml=" + encodeURIComponent(fetchQuery), true);
            req.setRequestHeader("OData-MaxVersion", "4.0");
            req.setRequestHeader("OData-Version", "4.0");
            req.setRequestHeader("Accept", "application/json");
            req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
            req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            req.onreadystatechange = function () {
                if (this.readyState === 4) {
                    req.onreadystatechange = null;
                    if (this.status === 200) {
                        var result = JSON.parse(this.response);
                        var statusName = result.value[0]["rsa_name"];
                        var statusId = result.value[0]["rsa_statusid"];

                        formContext.getAttribute("rsa_status").setValue([{ id: statusId, name: statusName, entityType: "rsa_status" }]);
                    } else {
                        //Xrm.Utility.alertDialog(this.statusText);
                        Xrm.Navigation.openAlertDialog(this.statusText);
                    }
                }
            };
            req.send();
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: " Close Status -" + err.message });
        }
    },

    //Author : Pooja Raje
    //Date : 22 November 2020
    //Function for setting value of LOB on load

    /* Change Summary for April 2022 Release 1 */
    /* Last Modified By: Shreya Diwate*/
    /* Summary of Changes: Remove Debug Code*/
    /* - Reason for Change: Unexpected 'debugger' statement */
    /* - Function name - OnLoadCaseType */

    OnLoadCaseType: function (executionContext) {
        var formContext = executionContext.getFormContext();
        //debugger;
        try {


            var caseTypeName, caseTypeId;

            var formId = formContext.ui.formSelector.getCurrentItem().getId().toUpperCase().replace(/[{}]/g, '');

            var fetchXmlQuery = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                "<entity name='rsa_formlayoutmapping'>" +
                "<attribute name='rsa_formlayoutmappingid' />" +
                "<attribute name='rsa_name' />" +
                "<attribute name='rsa_casetype' />" +
                "<attribute name='rsa_form' />" +
                "<order attribute='rsa_name' descending='false' />" +
                "<link-entity name='rsa_formlayout' from='rsa_formlayoutid' to='rsa_form' link-type='inner' alias='ae'>" +
                "<attribute name='rsa_formid'/>" +
                "<filter type='and'>" +
                "<condition attribute='rsa_formid' operator='eq' value= '" + formId + "'/>" +
                "<condition attribute='rsa_entityname' operator='eq' value='866760001' />" +
                "</filter>" +
                "</link-entity>" +
                "</entity>" +
                "</fetch>";

            var req = new XMLHttpRequest();
            var globalContext = Xrm.Utility.getGlobalContext();
            var ClientUrl = globalContext.getClientUrl();
            req.open("GET", ClientUrl + "/api/data/v9.1/rsa_formlayoutmappings?fetchXml=" + encodeURIComponent(fetchXmlQuery), true);
            req.setRequestHeader("Prefer", 'odata.include-annotations="*"');
            req.onreadystatechange = function () {
                if (this.readyState === 4) {
                    req.onreadystatechange = null;
                    if (this.status === 200) {
                        var results = JSON.parse(this.response);
                        if (results.value.length > 0) {
                            formId = results.value[0]["ae.rsa_formid"];
                            caseTypeName = results.value[0]["_rsa_casetype_value@OData.Community.Display.V1.FormattedValue"];
                            caseTypeId = results.value[0]["_rsa_casetype_value"];
                            // If value of LOB exists then skip this function
                            if (formContext.getAttribute("rsa_casetype") !== null && formContext.getAttribute("rsa_casetype") !== undefined) {
                                if (formContext.getAttribute("rsa_casetype").getValue() === null && formContext.getAttribute("rsa_casetype").getValue() !== undefined) {

                                    formContext.getAttribute("rsa_casetype").setValue([{ id: caseTypeId, name: caseTypeName, entityType: "rsa_casetype" }]);
                                }
                            }


                            // LOBDependentOptionset(executionContext, caseTypeId);
                        }
                    }
                    else {
                        Xrm.Navigation.openAlertDialog({ text: "OnLoadCaseType " + this.statusText });
                    }
                }
            };
            req.send();

        }

        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "OnLoadCaseType -" + err.message });
        }
    },
    //load Opportunity data in case 
    /* Change Summary for April 2022 Release 1 */
    /* Last Modified By: Shreya Diwate*/
    /* Summary of Changes: Replace Xrm.Utility.alertDialog(this.responseText) with Xrm.Navigation.openAlertDialog */
    /* - Reason for Change: Xrm.Utility.alertDialog(this.responseText)' uses a deprecated API*/
    /* - Function name - SETOpportunityData*/

    /* Change Summary for April 2022 Release 1 */
    /* Last Modified By: Shreya Diwate*/
    /* Summary of Changes: Replace Xrm.Page.context with Execution Xrm.Utility.getGlobalContext*/
    /* - Reason for Change:Xrm.Page.context deprecated API*/
    /* - Function name - SETOpportunityData */

    SETOpportunityData: function (executionContext) {
        try {
            var globalContext = Xrm.Utility.getGlobalContext();
            var formContext = executionContext.getFormContext();

            if (formContext.getAttribute("rsa_opportunityid").getValue() !== null) {
                var opportunityId = RSA.D365CRM.Case.Main.ConvertGuid(formContext.getAttribute("rsa_opportunityid").getValue()[0].id);


                var req = new XMLHttpRequest();
                /*req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v9.1/opportunities(" + opportunityId + ")?$select=_rsa_classofbusiness_value,_rsa_productid_value", true);*/

                req.open("GET", globalContext.getClientUrl() + "/api/data/v9.1/opportunities(" + opportunityId + ")?$select=_rsa_classofbusiness_value,_rsa_productid_value", true);

                req.setRequestHeader("OData-MaxVersion", "4.0");
                req.setRequestHeader("OData-Version", "4.0");
                req.setRequestHeader("Accept", "application/json");
                req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                req.onreadystatechange = function () {
                    if (this.readyState === 4) {
                        req.onreadystatechange = null;
                        if (this.status === 200) {
                            var result = JSON.parse(this.response);
                            var _rsa_classofbusiness_value = result["_rsa_classofbusiness_value"];
                            var _rsa_classofbusiness_value_formatted = result["_rsa_classofbusiness_value@OData.Community.Display.V1.FormattedValue"];
                            var _rsa_classofbusiness_value_lookuplogicalname = result["_rsa_classofbusiness_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                            var _rsa_productid_value = result["_rsa_productid_value"];
                            var _rsa_productid_value_formatted = result["_rsa_productid_value@OData.Community.Display.V1.FormattedValue"];
                            var _rsa_productid_value_lookuplogicalname = result["_rsa_productid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];

                            if (_rsa_classofbusiness_value_formatted != null && _rsa_productid_value_formatted != null) {
                                formContext.getAttribute("rsa_classofbusiness").setValue(_rsa_classofbusiness_value_formatted);
                                formContext.getAttribute("rsa_product_w").setValue(_rsa_productid_value_formatted);
                            }

                        } else {
                            //Xrm.Utility.alertDialog(this.statusText);
                            Xrm.Navigation.openAlertDialog(this.statusText);
                        }
                    }
                };
                req.send();
            }
            else {
                formContext.getAttribute("rsa_classofbusiness").setValue(null);
                formContext.getAttribute("rsa_product_w").setValue(null);
            }

        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "SETOpportunityData -" + err.message });
        }
    },


    //Case feedback validation on feedback notes. 
    FeedbackLength: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            var feedbacklength = formContext.getAttribute("rsa_feedbacknotes").getValue();
            if (feedbacklength.length < 25) {
                formContext.getControl("rsa_feedbacknotes").setNotification("Please provide more detailed feedback.", 210);
            }
            else {
                formContext.getControl("rsa_feedbacknotes").clearNotification(210);
            }
        }

        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "FeedbackLength: " + err.message });
        }
    },

    //Author : Prachi Paunikar
    //Date_Created : 29 Dec 2020
    //This function unlocks Status Reason when Status reason has data depending on Status

    /* Change Summary for April 2022 Release 1 */
    /* Last Modified By: Shreya Diwate*/
    /* Summary of Changes: Replace Xrm.Utility.alertDialog(this.responseText) with Xrm.Navigation.openAlertDialog */
    /* - Reason for Change: Xrm.Utility.alertDialog(this.responseText)' uses a deprecated API*/
    /* - Function name - StatusReason */

    /* Change Summary for April 2022 Release 1 */
    /* Last Modified By: Shreya Diwate*/
    /* Summary of Changes: Replace Xrm.Page.context with Execution Xrm.Utility.getGlobalContext*/
    /* - Reason for Change:Xrm.Page.context deprecated API*/
    /* - Function name - StatusReason */

    StatusReason: function (executionContext) {
        try {
            var globalContext = Xrm.Utility.getGlobalContext();
            var formContext = executionContext.getFormContext();
            var statusid;
            var statusName

            if (formContext.getAttribute("rsa_statusreason") === null)
                return;

            else if (formContext.getAttribute("rsa_status").getValue() !== null && formContext.getAttribute("rsa_statusreason") !== null) {
                statusid = formContext.getAttribute("rsa_status").getValue()[0].id.replace(/[{}]/g, '');
                statusName = formContext.getAttribute("rsa_status").getValue()[0].name;
                if (statusName === "Diverted" || statusName === "Lapsed" || statusName === "No Longer Required" || statusName === "Not Taken Up") {
                    var req = new XMLHttpRequest();
                    /*req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v9.1/rsa_statusreasons?$select=_rsa_casetype_value,rsa_name,_rsa_status_value&$filter=_rsa_status_value eq " + statusid, false);*/

                    req.open("GET", globalContext.getClientUrl() + "/api/data/v9.1/rsa_statusreasons?$select=_rsa_casetype_value,rsa_name,_rsa_status_value&$filter=_rsa_status_value eq " + statusid, false);

                    req.setRequestHeader("OData-MaxVersion", "4.0");
                    req.setRequestHeader("OData-Version", "4.0");
                    req.setRequestHeader("Accept", "application/json");
                    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                    req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                    req.onreadystatechange = function () {
                        if (this.readyState === 4) {
                            req.onreadystatechange = null;
                            if (this.status === 200) {
                                var results = JSON.parse(this.response);

                                if (results.value.length === 0) {


                                } else {
                                    formContext.getControl("rsa_statusreason").setDisabled(false);
                                    formContext.getAttribute("rsa_statusreason").setRequiredLevel("required");
                                }

                            } else {
                                //Xrm.Utility.alertDialog(this.statusText);
                                Xrm.Navigation.openAlertDialog(this.statusText);
                            }
                        }
                    };
                    req.send();

                }
            }
            else {
                formContext.getControl("rsa_statusreason").setDisabled(true);
                formContext.getAttribute("rsa_statusreason").setRequiredLevel("none");
                formContext.getAttribute("rsa_statusreason").setValue(null);
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: " Status Reason -" + err.message });
        }
    },

    /* Change Summary for April 2022 Release 1 */
    /* Last Modified By: Shreya Diwate*/
    /* Summary of Changes: Replace Xrm.Utility.alertDialog(this.responseText) with Xrm.Navigation.openAlertDialog */
    /* - Reason for Change: Xrm.Utility.alertDialog(this.responseText)' uses a deprecated API*/
    /* - Function name - TriggerChangeOnLoadOfForm */

    /* Change Summary for April 2022 Release 1 */
    /* Last Modified By: Shreya Diwate*/
    /* Summary of Changes: Replace Xrm.Page.context with Execution Xrm.Utility.getGlobalContext*/
    /* - Reason for Change:Xrm.Page.context deprecated API*/
    /* - Function name - TriggerChangeOnLoadOfForm*/

    TriggerChangeOnLoadOfForm: function (executionContext) {
        try {

            var globalContext = Xrm.Utility.getGlobalContext();
            var formContext = executionContext.getFormContext();
            var req = new XMLHttpRequest();
            /*req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v9.1/rsa_customlabels?$select=rsa_dependentoptionsetjson&$filter=rsa_name eq 'CaseNumberToPercentConversion'", false);*/

            req.open("GET", globalContext.getClientUrl() + "/api/data/v9.1/rsa_customlabels?$select=rsa_dependentoptionsetjson&$filter=rsa_name eq 'CaseNumberToPercentConversion'", false);

            req.setRequestHeader("OData-MaxVersion", "4.0");
            req.setRequestHeader("OData-Version", "4.0");
            req.setRequestHeader("Accept", "application/json");
            req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
            req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            req.onreadystatechange = function () {
                if (this.readyState === 4) {
                    req.onreadystatechange = null;
                    if (this.status === 200) {
                        var results = JSON.parse(this.response);
                        for (var i = 0; i < results.value.length; i++) {
                            var rsa_dependentoptionsetjson = results.value[i]["rsa_dependentoptionsetjson"];
                            var NumberToPercent = JSON.parse(results.value[i]["rsa_dependentoptionsetjson"]).NumberToPercent;

                            for (var j = 0; j < NumberToPercent.length; j++) {

                                var schemaName = NumberToPercent[j].SchemaName;

                                if (formContext.getAttribute(schemaName) !== null && formContext.getAttribute(schemaName) !== undefined) {
                                    //formContext.getAttribute(schemaName).addOnChange(RSA.D365CRM.Case.Main.ConvertNumberToPercent);
                                    RSA.D365CRM.Case.Main.ConvertNumberToPercent(executionContext, schemaName);
                                }
                            }

                        }
                    } else {
                        //Xrm.Utility.alertDialog(this.statusText);
                        Xrm.Navigation.openAlertDialog(this.statusText);
                    }
                }
            };
            req.send();


        } catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "TriggerChangeOnLoadOfForm -" + err.message });
        }
    },

    //Author : Pooja Raje
    //Date_Created : 10 Nov 2021
    //This function for associated Email Cases on subgrid

    /* Change Summary for April 2022 Release 1 */
    /* Last Modified By: Shreya Diwate*/
    /* Summary of Changes: Remove Debug Code*/
    /* - Reason for Change: Unexpected 'debugger' statement */
    /* - Function name - AssociatedEmailCases */

    AssociatedEmailCases: function (executionContext) {
        //debugger;
        try {
            var formContext = executionContext.getFormContext();
            var casereceivedateGE, casereceivedateLT;
            var hours, minutes, minutesLT, month, date = '00';
            var subgrid = formContext.getControl('AssociatedEmailCases');
            if (subgrid === null) {
                return;
            }
            var subjectControl = formContext.getAttribute("rsa_subject");
            var casereceivedateControl = formContext.getAttribute("rsa_casereceiveddate");
            if (subjectControl != null && casereceivedateControl != null) {
                var casereceivedatetime = casereceivedateControl.getValue();
                var subject = subjectControl.getValue();
                var format = /[&<>"']+/;
                if (format.test(subject)) {
                    var map = {
                        '&': '&#038;',
                        '<': '&lt;',
                        '>': '&gt;',
                        '"': '&#34;',
                        "'": '&#039;'
                    };
                    subject = subject.replace(/[&<>"']/g, function (m) { return map[m]; });
                }
                //else {

                if (casereceivedatetime != null) {
                    hours = casereceivedatetime.getUTCHours();
                    minutes = casereceivedatetime.getUTCMinutes();
                    minutesLT = casereceivedatetime.getUTCMinutes() + 1;
                    //var seconds = casereceivedatetime.getUTCSeconds();
                    if (hours < 10)
                        hours = "0" + hours;
                    if (minutes < 10) {
                        minutes = "0" + minutes;
                    }
                    if (minutesLT < 10) {
                        minutesLT = "0" + minutesLT;
                    }
                    month = casereceivedatetime.getMonth() + 1;
                    date = casereceivedatetime.getDate();
                    if (month < 10)
                        month = "0" + month;
                    if (date < 10)
                        date = "0" + date;


                    casereceivedateGE = casereceivedatetime.getFullYear() + '-' + month + '-' + date + 'T' + hours + ':' + minutes + ':00';
                    casereceivedateLT = casereceivedatetime.getFullYear() + '-' + month + '-' + date + 'T' + hours + ':' + minutesLT + ':00';
                }
                else {
                    casereceivedateGE = null;
                    casereceivedateLT = null;
                }
                var fetchEmailSubject = "<filter type='and'>" +
                    "<condition attribute='rsa_subject' operator='eq' value='" + subject + "' />" +
                    "<condition attribute='rsa_casereceiveddate' operator='ge' value='" + casereceivedateGE + "' />" +
                    "<condition attribute='rsa_casereceiveddate' operator='le' value='" + casereceivedateLT + "' />" +
                    //	"<condition attribute='description' operator='eq' value='" + description + "' />" +
                    "</filter>";

                subgrid.setFilterXml(fetchEmailSubject);
                subgrid.refresh();
                //}
                //}
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "AssociatedEmailCases -" + err.message });
        }
    },

    //Author : Sagar Chaudhari
    //Date_Created : SEp 2022 
    //This function for associated Email Cases on subgrid

    /* Change Summary for GDPR Nov 2022 Release*/
    /* Last Modified By: Shreya Diwate*/
    /* Summary of Changes: Lock the GDPR Fields */

    /* - Function name - LockFields */
    LockFields: function (executionContext, recordId) {
        //debugger;
        try {
            var rsa_anonymizationstatus;
            var formContext = executionContext.getFormContext();

            var req = new XMLHttpRequest();
            req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v9.1/incidents(" + recordId + ")?$select=rsa_anonymizationstatus", true);
            req.setRequestHeader("OData-MaxVersion", "4.0");
            req.setRequestHeader("OData-Version", "4.0");
            req.setRequestHeader("Accept", "application/json");
            req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
            req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            req.onreadystatechange = function () {
                if (this.readyState === 4) {
                    req.onreadystatechange = null;
                    if (this.status === 200) {
                        var result = JSON.parse(this.response);
                        var rsa_anonymizationstatus = result["rsa_anonymizationstatus"];

                        if (rsa_anonymizationstatus === 866760002) {
                            if (formContext.getAttribute("rsa_originemailaddress") !== null && formContext.getAttribute("rsa_originemailaddress") !== undefined)
                                formContext.getControl("rsa_originemailaddress").setDisabled(true);
                            if (formContext.getAttribute("rsa_toaddress") !== null && formContext.getAttribute("rsa_toaddress") !== undefined)
                                formContext.getControl("rsa_toaddress").setDisabled(true);
                            if (formContext.getAttribute("rsa_contactfax") !== null && formContext.getAttribute("rsa_contactfax") !== undefined)
                                formContext.getControl("rsa_contactfax").setDisabled(true);
                            if (formContext.getAttribute("rsa_contactmobile") !== null && formContext.getAttribute("rsa_contactmobile") !== undefined)
                                formContext.getControl("rsa_contactmobile").setDisabled(true);
                            if (formContext.getAttribute("rsa_contactphone") !== null && formContext.getAttribute("rsa_contactphone") !== undefined)
                                formContext.getControl("rsa_contactphone").setDisabled(true);
                            if (formContext.getAttribute("rsa_clientname") !== null && formContext.getAttribute("rsa_clientname") !== undefined)
                                formContext.getControl("rsa_clientname").setDisabled(true);
                            if (formContext.getAttribute("rsa_customercontactname") !== null && formContext.getAttribute("rsa_customercontactname") !== undefined)
                                formContext.getControl("rsa_customercontactname").setDisabled(true);
                            if (formContext.getAttribute("rsa_customercontactposition") !== null && formContext.getAttribute("rsa_customercontactposition") !== undefined)
                                formContext.getControl("rsa_customercontactposition").setDisabled(true);
                            if (formContext.getAttribute("rsa_customername") !== null && formContext.getAttribute("rsa_customername") !== undefined)
                                formContext.getControl("rsa_customername").setDisabled(true);
                            if (formContext.getAttribute("rsa_customerphonenumber1") !== null && formContext.getAttribute("rsa_customerphonenumber1") !== undefined)
                                formContext.getControl("rsa_customerphonenumber1").setDisabled(true);
                            if (formContext.getAttribute("rsa_customerphysicaladdress") !== null && formContext.getAttribute("rsa_customerphysicaladdress") !== undefined)
                                formContext.getControl("rsa_customerphysicaladdress").setDisabled(true);
                            if (formContext.getAttribute("rsa_customerpostcode") !== null && formContext.getAttribute("rsa_customerpostcode") !== undefined)
                                formContext.getControl("rsa_customerpostcode").setDisabled(true);
                            if (formContext.getAttribute("rsa_riskaddress") !== null && formContext.getAttribute("rsa_riskaddress") !== undefined)
                                formContext.getControl("rsa_riskaddress").setDisabled(true);


                        }

                    } else {

                    }



                }
            };
            req.send();
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "GDPR -" + err.message });
        }
    },

    ConvertNumberToPercent: function (executionContext, fieldName) {
        try {
            var formContext = executionContext.getFormContext();
            //var fieldName = executionContext.getEventSource().getName();

            if (formContext.getAttribute(fieldName) !== null && formContext.getAttribute(fieldName) !== "undefined" && formContext.getAttribute(fieldName).getValue() !== null && formContext.getAttribute(fieldName).getValue() !== "undefined") {

                //Get Number field value and divide it by 100
                var fieldValueinPercent = formContext.getAttribute(fieldName).getValue() / 100;

                //Set Percentage value in same field
                formContext.getAttribute(fieldName).setValue(fieldValueinPercent);

            }
        } catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "ConvertNumberToPercent -" + err.message });
        }
    },


    //Author : Rohan Goel
    //Date_Created : Feb 2023
    //This function for associated TFS-1095

    /* - Function name - BrokerUpdate */

    BrokerUpdate: function (executionContext) {
        var formContext = executionContext.getFormContext();
        formContext.ui.clearFormNotification("Broker warning");
        RSA.D365CRM.Case.Main.GetCaseTypes();
        var caseType = formContext.getAttribute("rsa_casetype").getValue()[0].name;
        var policyAttribute = formContext.getAttribute("rsa_policyid");

        if (policyAttribute != null && tfs1095CaseTypes.includes(caseType)) {  
            if (policyAttribute.getValue() != null) {
                formContext.getControl("rsa_account").setDisabled(true);
            }
            policyAttribute.addOnChange(RSA.D365CRM.Case.Main.AutoPopulateBroker);
        }
    },

    AutoPopulateBroker: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var caseType = formContext.getAttribute("rsa_casetype").getValue()[0].name;
        var policyAttribute = formContext.getAttribute("rsa_policyid");
        var policyId = "";
        formContext.ui.clearFormNotification("Broker warning");

        if (policyAttribute != null && policyAttribute.getValue() != null) {
            policyId = RSA.D365CRM.Case.Main.ConvertGuid(policyAttribute.getValue()[0]["id"]);
            formContext.getControl("rsa_account").setDisabled(true);
        }

        else {
            formContext.getControl("rsa_account").setDisabled(false);
            return;
        }

        if (caseType.includes("New Business")) {

            var globalContext = Xrm.Utility.getGlobalContext();

            var req = new XMLHttpRequest();
            req.open("GET", globalContext.getClientUrl() + "/api/data/v9.1/rsa_policies(" + policyId + ")?$select=_rsa_broker_value", true);
            req.setRequestHeader("OData-MaxVersion", "4.0");
            req.setRequestHeader("OData-Version", "4.0");
            req.setRequestHeader("Accept", "application/json");
            req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
            req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            req.onreadystatechange = function () {
                if (this.readyState === 4) {
                    req.onreadystatechange = null;
                    if (this.status === 200) {
                        var result = JSON.parse(this.response);
                        var brokerId = result["_rsa_broker_value"] ? result["_rsa_broker_value"] : null;
                        var brokerName = result["_rsa_broker_value@OData.Community.Display.V1.FormattedValue"] ? result["_rsa_broker_value@OData.Community.Display.V1.FormattedValue"] : null;

                        if (!brokerId) {
                            formContext.getAttribute("rsa_account").setValue(null);
                        }
                        else {
                            formContext.getAttribute("rsa_account").setValue([{ id: brokerId, name: brokerName, entityType: "account" }]);
                        }

                        formContext.ui.setFormNotification("Broker updated as per the policy tagged to it.", "WARNING", "Broker warning");

                    } else {
                        Xrm.Utility.alertDialog(this.statusText);
                    }
                }
            };
            req.send();

        }
    },

    GetCaseTypes: function () {

        var globalContext = Xrm.Utility.getGlobalContext();

        var req = new XMLHttpRequest();
        req.open("GET", globalContext.getClientUrl() + "/api/data/v9.1/rsa_customlabels(99314ABB-F0B4-ED11-B597-0022481B5F75)?$select=rsa_dependentoptionsetjson", false);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    var result = JSON.parse(this.response);
                    tfs1095CaseTypes = JSON.parse(result["rsa_dependentoptionsetjson"])["Case Types"];
                } else {
                    Xrm.Utility.alertDialog(this.statusText);
                }
            }
        };

        req.send();

    },




    // SaveAndClose: function(executionContext) {
    // try {
    // var formContext = executionContext.getFormContext();
    // if (executionContext.getEventArgs().getSaveMode() === 2) {
    // var count = 0;
    // var index = 0;
    // var attributes = {};
    // var formContext = executionContext.getFormContext();
    // formContext.data.entity.attributes.forEach(function(attribute, index) {
    // if (attribute.getRequiredLevel() == "required" && attribute.getValue() === null) {

    // count = count + 1;

    // }


    // }

    // );
    // if(count == 0){
    // Xrm.Navigation.navigateTo({
    // pageType: "entitylist",
    // entityName: "incident"
    // }).then(
    // function(result) {
    // },
    // function(error) {
    // //Error
    // }
    // );

    // }
    // else{
    // executionContext.getEventArgs().preventDefault(); 

    // }

    // }
    // } catch (err) {
    // Xrm.Navigation.openAlertDialog({
    // text: "SaveAndClose -" + err.message
    // });
    // }

    // },




    ConvertGuid: function (str) {
        if (str) {
            str = str.replace(/[{}]/g, '');
            str = str.toUpperCase();
        }
        return str;
    }


});