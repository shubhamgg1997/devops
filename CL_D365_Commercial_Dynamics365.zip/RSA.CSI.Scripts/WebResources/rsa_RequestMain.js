//Author : Pooja Raje
//This Function Open the Page According to Request Type
var formId, requestrecordtypeName, requestrecordtypeId;
function RedirectToPageLayoutBasedOnRequestType(PrimaryControl, key) {
	var securityMap = new Array();
		var req = new XMLHttpRequest();
        var globalContext = Xrm.Utility.getGlobalContext();
        var ClientUrl = globalContext.getClientUrl();
		
				req.open("GET", ClientUrl + "/api/data/v9.1/rsa_customlabels?$select=rsa_dependentoptionsetjson,rsa_name&$filter=rsa_name eq 'SecurityRole'", false);
                req.setRequestHeader("OData-MaxVersion", "4.0");
                req.setRequestHeader("OData-Version", "4.0");
                req.setRequestHeader("Accept", "application/json");
                req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                req.onreadystatechange = function () {
                    if (this.readyState === 4) {
                        req.onreadystatechange = null;
                       if (this.status === 200) {
                            var results = JSON.parse(this.response);
                            for (var i = 0; i < results.value.length; i++) {
                                var rsa_categories = results.value[i]["rsa_categories"];
                                var rsa_dependentoptionsetjson = results.value[i]["rsa_dependentoptionsetjson"];
                                var SecurityRoleMapping = JSON.parse(results.value[i]["rsa_dependentoptionsetjson"]).SecurityRoleMapping;
								var roles = Xrm.Utility.getGlobalContext().userSettings.securityRoles;
								
								  for(var i=0; i < roles.length; i++ ){
									var GUID = Xrm.Utility.getGlobalContext().userSettings.securityRoles[i];
									SecurityRoleMapping.forEach(function (item) {
									if(item.SecurityRoleGUID.toLowerCase() == GUID.toLowerCase())
										securityMap.push(item.SecurityRoleValue);
									});
								}
							}
						}
                        else {
                            Xrm.Navigation.openAlertDialog({ text: "Get Security Role Mapping: " + this.statusText });
                        }
                    }
                };
                req.send();
				
				var securityRoleMappingStr = ''; 
				for(var k=0; k < securityMap.length; k++){
					securityRoleMappingStr += "<value>" + securityMap[k] + "</value>"
				}

    var fetchXmlQuery = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
        "<entity name='rsa_formlayoutmapping'>" +
        "<attribute name='rsa_formlayoutmappingid' />" +
        "<attribute name='rsa_name' />" +
        "<attribute name='rsa_requestrecordtype' />" +    
        "<attribute name='rsa_form' />" +
        "<order attribute='rsa_name' descending='false' />" +
		"<filter type='and'>" +
        "<condition attribute='rsa_formidentifier' operator='eq' value='" + key + "' />" +
		"<condition attribute='rsa_securityrolemapping' operator='contain-values'>" + securityRoleMappingStr +
		"</condition></filter>" + 
        "<link-entity name='rsa_formlayout' from='rsa_formlayoutid' to='rsa_form' link-type='inner' alias='ae'>" +
        "<attribute name='rsa_formid'/>" +
        "<filter type='and'>" +
        "<condition attribute='rsa_entityname' operator='eq' value='866760004' />" +
        "</filter>" +
        "</link-entity>" +
        "</entity>" +
        "</fetch>";
		

    var req = new XMLHttpRequest();
    var globalContext = Xrm.Utility.getGlobalContext();
    var ClientUrl = globalContext.getClientUrl();
    req.open("GET", ClientUrl + "/api/data/v9.1/rsa_formlayoutmappings?fetchXml=" + encodeURIComponent(fetchXmlQuery), true);
    req.setRequestHeader("Prefer", 'odata.include-annotations="*"');
    req.onreadystatechange = function () {
        if (this.readyState === 4) {
            req.onreadystatechange = null;
            if (this.status === 200) {
                var results = JSON.parse(this.response);
                if (results.value.length > 0) {
                    formId = results.value[0]["ae.rsa_formid"];
                    requestrecordtypeName = results.value[0]["_rsa_requestrecordtype_value@OData.Community.Display.V1.FormattedValue"];
                    requestrecordtypeId = results.value[0]["_rsa_requestrecordtype_value"];
					

                    if (formId !== null) {
                        var entityFormOptions = {};
                        entityFormOptions["entityName"] = "rsa_request";
                        entityFormOptions["formId"] = formId;

                        var formParameters = {};
                        if (requestrecordtypeName !== null && requestrecordtypeId !== null) {
                            formParameters["rsa_requestrecordtype"] = requestrecordtypeId;
                            formParameters["rsa_requestrecordtypename"] = requestrecordtypeName;
                            formParameters["rsa_requestrecordtypetype"] = "rsa_requestrecordtype";
	
                        }

                        // Open the form.
                        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
                             function (success) {
                                 //console.log(success);
                             },
                             function (error) {
                                 //console.log(error);
                             });
						// if(formId==formContext.ui.formSelector.getCurrentItem().getId()){
							// return;
						// }
						//formContext.ui.formSelector.items.get(formId).navigate();
                    }
                }
            } else {
                Xrm.Navigation.openAlertDialog(this.statusText);
            }
        }
    };
    req.send();
}


//This Function Option set to Option set filtering
   function RequestDependentOptionset(executionContext,requestrecordtypeId) {
        try {				
			var formContext = executionContext.getFormContext();
			if(formContext.getAttribute("rsa_requestrecordtype").getValue() == null && formContext.getAttribute("rsa_requestrecordtype").getValue() == undefined)
			{
				return;
			}
                       /*  var requestrecordtypeId  = formContext.getAttribute("rsa_requestrecordtype").getValue()[0].id; */
						
			if (requestrecordtypeId !== null && requestrecordtypeId !== undefined) {
			    var req = new XMLHttpRequest();
                var globalContext = Xrm.Utility.getGlobalContext();
                var ClientUrl = globalContext.getClientUrl();
		
				req.open("GET", ClientUrl + "/api/data/v9.1/rsa_customlabels?$select=rsa_categories,rsa_customlabelid,_rsa_requestrecordtype_value,rsa_dependentoptionsetjson&$filter=_rsa_requestrecordtype_value eq " + requestrecordtypeId , true);
                req.setRequestHeader("OData-MaxVersion", "4.0");
                req.setRequestHeader("OData-Version", "4.0");
                req.setRequestHeader("Accept", "application/json");
                req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                req.onreadystatechange = function () {
                    if (this.readyState === 4) {
                        req.onreadystatechange = null;
                        if (this.status === 200) {
                            var results = JSON.parse(this.response);
                            for (var i = 0; i < results.value.length; i++) {
                                var rsa_categories = results.value[i]["rsa_categories"];
                                var rsa_customlabelid = results.value[i]["rsa_customlabelid"];
                                var rsa_dependentoptionsetjson = results.value[i]["rsa_dependentoptionsetjson"];
                                var OptionSet = JSON.parse(results.value[i]["rsa_dependentoptionsetjson"]).ParentFieldDependency[0].OptionSet;
								var LookUp = JSON.parse(results.value[i]["rsa_dependentoptionsetjson"]).ParentFieldDependency[0].LookUp;
								
								
                                
                                for (var i = 0; i < OptionSet.length; i++) {

                                    var DependentField = OptionSet[i].DependentField;
                                    var ApplicableValue = OptionSet[i].ApplicableValue;
									var DefaultValue = OptionSet[i].DefaultValue;
                                    var splitValue = ApplicableValue.split(",");

                                    if (formContext.getAttribute(DependentField) !== null && formContext.getAttribute(DependentField) !== undefined) {
                                        var OptionSetValues = formContext.getAttribute(DependentField).getOptions();

                                        for (var k = 0; k < OptionSetValues.length; k++) {
                                            if (splitValue.indexOf(OptionSetValues[k].value.toString()) === -1) {
                                                formContext.getControl(DependentField).removeOption(OptionSetValues[k].value);
                                            }
											

                                        }
										if(DefaultValue !== null && DefaultValue !== undefined)
										{
										if (formContext.ui.getFormType() === 1) {
                                            formContext.getAttribute(DependentField).setValue(defaultValue);
                                        }
										}
                                    }

                                }

						//Set the default value of the lookup 	
    							if(LookUp.length > 0)	{
								for (var i = 0; i < LookUp.length; i++) {
                                    var lookupDependentField = LookUp[i].lookupDependentField;
									var Entity = LookUp[i].lookupDefaultValue.Entity; 
								    var GUID = LookUp[i].lookupDefaultValue.GUID; 
									var StatusName = LookUp[i].lookupDefaultValue.StatusName;
									
                                    var lookupDefaultValue = LookUp[i].lookupDefaultValue.rsa_statusname;
                                    if (formContext.getAttribute(lookupDependentField) !== null && formContext.getAttribute(lookupDependentField) !== undefined) {
                                       //Set  defualt Value for Option set 
                                        //formContext.getAttribute(lookupDependentField).setValue([{ id: GUID, name: StatusName, entityType: Entity}]);
										if (formContext.ui.getFormType() === 1) {
                                            formContext.getAttribute(lookupDependentField).setValue([{ id: GUID, name: StatusName, entityType: Entity }]);
                                        }
									}

									}
								}
							}
						}
						
                        else {
                            Xrm.Navigation.openAlertDialog({ text: "RequestDependentOptionset : " + this.statusText });
                        }
                    }
                };
                req.send();

				}
			}
			
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: " Option set value -" + err.message });
        }
    }
	
	//Function for setting value of Request Type on load
	
/* Change Summary for April 2022 Release 1 */
/* Last Modified By: Shreya Diwate*/
/* Summary of Changes: Remove Debug Code*/
/* - Reason for Change: Unexpected 'debugger' statement */
/* - Function name - OnLoadRequest */

function OnLoadRequest(excecutionContext) {
    //debugger;
    try {
		var formContext = excecutionContext.getFormContext();
		LoadingExistingRecord(excecutionContext);
	
        var formId = formContext.ui.formSelector.getCurrentItem().getId().toUpperCase().replace(/[{}]/g, '');

        var fetchXmlQuery = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
            "<entity name='rsa_formlayoutmapping'>" +
            "<attribute name='rsa_formlayoutmappingid' />" +
            "<attribute name='rsa_name' />" +
            "<attribute name='rsa_requestrecordtype' />" +
            "<attribute name='rsa_form' />" +
            "<order attribute='rsa_name' descending='false' />" +
            "<link-entity name='rsa_formlayout' from='rsa_formlayoutid' to='rsa_form' link-type='inner' alias='ae'>" +
            "<attribute name='rsa_formid'/>" +
            "<filter type='and'>" +
            "<condition attribute='rsa_formid' operator='eq' value= '" + formId + "'/>" +
            "<condition attribute='rsa_entityname' operator='eq' value='866760004' />" +
            "</filter>" +
            "</link-entity>" +
            "</entity>" +
            "</fetch>";

        var req = new XMLHttpRequest();
        var globalContext = Xrm.Utility.getGlobalContext();
        var ClientUrl = globalContext.getClientUrl();
        req.open("GET", ClientUrl + "/api/data/v9.1/rsa_formlayoutmappings?fetchXml=" + encodeURIComponent(fetchXmlQuery), true);
        req.setRequestHeader("Prefer", 'odata.include-annotations="*"');
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    var results = JSON.parse(this.response);
                    if (results.value.length > 0) {
                        formId = results.value[0]["ae.rsa_formid"];
                        requestrecordtypeName = results.value[0]["_rsa_requestrecordtype_value@OData.Community.Display.V1.FormattedValue"];
						requestrecordtypeId = results.value[0]["_rsa_requestrecordtype_value"];
                          
                        formContext.getAttribute("rsa_requestrecordtype").setValue([{ id: requestrecordtypeId, name: requestrecordtypeName, entityType: "rsa_requestrecordtype" }]);
                        RequestDependentOptionset(excecutionContext, requestrecordtypeId);
                    }
                }
                else {
                    Xrm.Navigation.openAlertDialog({ text: "OnLoadRequest " + this.statusText });
                }
            }
        };
        req.send();

    }

    catch (err) {
        Xrm.Navigation.openAlertDialog({ text: "OnLoadRequest -" + err.message });
    }
}

//Author : Pooja Raje
    //This Function opens the correct form while opening the existing records
 function LoadingExistingRecord(excecutionContext) {
        try {
            var formContext = excecutionContext.getFormContext();
            if (formContext.getAttribute("rsa_requestformid") !== null && formContext.getAttribute("rsa_requestformid") !== undefined && formContext.ui.getFormType() === 2 || formContext.ui.getFormType() === 3 ||formContext.ui.getFormType() === 4) {
                if (formContext.getAttribute("rsa_requestformid").getValue() !== null && formContext.getAttribute("rsa_requestformid").getValue() !== undefined) {
                    var requestFormID = formContext.getAttribute("rsa_requestformid").getValue();
                    var formId = formContext.ui.formSelector.getCurrentItem().getId();
                    if (formId !== requestFormID) {
						if(formContext.ui.formSelector.items.get(requestFormID)!==null)
						{
                        formContext.ui.formSelector.items.get(requestFormID).navigate();
                    }
					}					
                }
				
				}
            }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "LoadingExistingRecord -" + err.message });
        }
    }
	
/* Change Summary for April 2022 Release 1 */
/* Last Modified By: Shreya Diwate*/
/* Summary of Changes: Remove Debug Code*/
/* - Reason for Change: Unexpected 'debugger' statement */
/* - Function name - RedirectExistingToRequestType */

/* Change Summary for April 2022 Release 1 */
/* Last Modified By: Shreya Diwate*/
/* Summary of Changes: Replace Xrm.page with ExecutionContext.getFormContext*/
/* - Reason for Change:Xrm.page deprecated API*/
/* - Function name - RedirectExistingToRequestType*/

function RedirectExistingToRequestType(executionContext, triggerType) {
    //debugger;
	var formId, requestrecordtypeName, requestrecordtypeId;
	//var formId, policytypeName, policytypeId;
    var formContext = executionContext.getFormContext();
	
	formId = formContext.getAttribute("rsa_requestformid").getValue();
	if(triggerType != "onchange"){
	if(formId != null && formId != undefined){
		
		return;
	}
	}
	    
    //var requestrecordtypevalue = formContext.getAttribute("rsa_requestrecordtype");
	
	//var requestrecordtypevalue = Xrm.Page.data.entity.attributes.get("rsa_requestrecordtype");
	var requestrecordtypevalue = formContext.data.entity.attributes.get("rsa_requestrecordtype");
	
	//if(Xrm.Page.data.entity.attributes.get("rsa_requestrecordtype").getValue() !== null){alert ("Check 1");}
	
	/*if (Xrm.Page.data.entity.attributes.get("rsa_requestrecordtype").getValue() === null){
		return; 
	}*/
	
	if (formContext.data.entity.attributes.get("rsa_requestrecordtype").getValue() === null){
		return; 
	}
    if (requestrecordtypevalue.getValue() === null && formContext.ui.getFormType() === 2){
        return;
	}
	
	if(formContext.ui.getFormType() === 1 && triggerType != "onchange"){
		return;
	}
    
	var requestrecordtype = requestrecordtypevalue.getValue()[0].id;
    var securityMap = new Array();
    var req = new XMLHttpRequest();
    var globalContext = Xrm.Utility.getGlobalContext();
    var ClientUrl = globalContext.getClientUrl();
    req.open("GET", ClientUrl + "/api/data/v9.1/rsa_customlabels?$select=rsa_dependentoptionsetjson,rsa_name&$filter=rsa_name eq 'SecurityRole'", false);
                req.setRequestHeader("OData-MaxVersion", "4.0");
                req.setRequestHeader("OData-Version", "4.0");
                req.setRequestHeader("Accept", "application/json");
                req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                req.onreadystatechange = function () {
                    if (this.readyState === 4) {
                        req.onreadystatechange = null;
                       if (this.status === 200) {
                            var results = JSON.parse(this.response);
                            for (var i = 0; i < results.value.length; i++) {
                                var rsa_categories = results.value[i]["rsa_categories"];
                                var rsa_dependentoptionsetjson = results.value[i]["rsa_dependentoptionsetjson"];
                                var SecurityRoleMapping = JSON.parse(results.value[i]["rsa_dependentoptionsetjson"]).SecurityRoleMapping;
								var roles = Xrm.Utility.getGlobalContext().userSettings.securityRoles;
								
								  for(var i=0; i < roles.length; i++ ){
									var GUID = Xrm.Utility.getGlobalContext().userSettings.securityRoles[i];
									SecurityRoleMapping.forEach(function (item) {
									if(item.SecurityRoleGUID.toLowerCase() == GUID.toLowerCase())
										securityMap.push(item.SecurityRoleValue);
									});
								}
							}
						}
                        else {
                            Xrm.Navigation.openAlertDialog({ text: "Get Security Role Mapping: " + this.statusText });
                        }
                    }
                };
                req.send();
				
				var securityRoleMappingStr = ''; 
				for(var k=0; k < securityMap.length; k++){
					securityRoleMappingStr += "<value>" + securityMap[k] + "</value>"
				}
		
		var fetchXmlQuery = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
        "<entity name='rsa_formlayoutmapping'>" +
        "<attribute name='rsa_formlayoutmappingid' />" +
        "<attribute name='rsa_name' />" +
        "<attribute name='rsa_requestrecordtype' />" +
		"<attribute name='rsa_securityrolemapping' />" +
        "<attribute name='rsa_form' />" +
        "<order attribute='rsa_name' descending='false' />" +
		"<filter type='and'>" +
        "<condition attribute='rsa_requestrecordtype'  operator='eq' value='" + requestrecordtype + "' />" +
		"<condition attribute='rsa_securityrolemapping' operator='contain-values'>" + securityRoleMappingStr +
		"</condition></filter>" +
        "<link-entity name='rsa_formlayout' from='rsa_formlayoutid' to='rsa_form' link-type='inner' alias='ae'>" +
        "<attribute name='rsa_formid'/>" +
        "<filter type='and'>" +
        "<condition attribute='rsa_entityname' operator='eq' value='866760004' />" +
        "</filter>" +
        "</link-entity>" +
        "</entity>" +
        "</fetch>";
		
		

    var req = new XMLHttpRequest();
    var globalContext = Xrm.Utility.getGlobalContext();
    var ClientUrl = globalContext.getClientUrl();
    req.open("GET", ClientUrl + "/api/data/v9.1/rsa_formlayoutmappings?fetchXml=" + encodeURIComponent(fetchXmlQuery), true);
    req.setRequestHeader("Prefer", 'odata.include-annotations="*"');
    req.onreadystatechange = function () {
        if (this.readyState === 4) {
            req.onreadystatechange = null;
            if (this.status === 200) {
                var results = JSON.parse(this.response);
                if (results.value.length > 0) {
                    formId = results.value[0]["ae.rsa_formid"];
                    requestrecordtypeName = results.value[0]["_rsa_requestrecordtype_value@OData.Community.Display.V1.FormattedValue"];
                    requestrecordtypeId = results.value[0]["_rsa_requestrecordtype_value"];
					

                    if (formId !== null) {
                        var entityFormOptions = {};
                        entityFormOptions["entityName"] = "rsa_request";
                        entityFormOptions["formId"] = formId;
						entityFormOptions["entityId"] = formContext.data.entity.getId();

                        var formParameters = {};
                        if (requestrecordtypeName !== null && requestrecordtypeId !== null) {
                            formParameters["rsa_requestrecordtype"] = requestrecordtypeId;
							formParameters["rsa_requestformid"] = formId;
                            formParameters["rsa_requestrecordtypename"] = requestrecordtypeName;
                            formParameters["rsa_requestrecordtypetype"] = "rsa_requestrecordtype"; 
	
                        }

                        // Open the form.
                       // Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
					    // Xrm.Navigation.openForm(entityFormOptions,formParameters).then(
                            // function (success) {
								// formContext.getAttribute("rsa_requestformid").setValue(formId);
                                // //console.log(success);
                            // },
                            // function (error) {
                                // //console.log(error);
                            // });
							if(formId==formContext.ui.formSelector.getCurrentItem().getId()){
								return;
							}
							formContext.ui.formSelector.items.get(formId).navigate();
                    }
                }
            } else {
                Xrm.Navigation.openAlertDialog(this.statusText);
            }
        }
    };
    req.send();
}

//function to hide request types option set
function hideRequestType(executionContext)
{
	var formContext = executionContext.getFormContext();
	try
	{
		formContext.ui.controls.get("rsa_requesttype").removeOption(866760001);
		formContext.ui.controls.get("rsa_requesttype").removeOption(866760003);
		formContext.ui.controls.get("rsa_requesttype").removeOption(866760005);
		formContext.ui.controls.get("rsa_requesttype").removeOption(866760007);
		formContext.ui.controls.get("rsa_requesttype").removeOption(866760008);
		formContext.ui.controls.get("rsa_requesttype").removeOption(866760009);
		formContext.ui.controls.get("rsa_requesttype").removeOption(866760010);
		formContext.ui.controls.get("rsa_requesttype").removeOption(866760011);
		formContext.ui.controls.get("rsa_requesttype").removeOption(866760051);
	}
	catch(err)
	{
		Xrm.Navigation.openAlertDialog({ text: " ERROR -" + err.message });
	}
	
}

//function to show popup when Request type is "Renewal Generation" or "New User Creation"
function onChangeRequestType(executionContext)
{
	var formContext = executionContext.getFormContext();
	try{
		var requestType=formContext.getAttribute("rsa_requesttype").getValue();
		if(requestType=="866760004")
		{
			Xrm.Navigation.openAlertDialog({ text: "Please fill the template attached and attach to the request. Download the template from 'Word Templates' in the ribbon." });
		}
	}
	catch(err)
	{
		Xrm.Navigation.openAlertDialog({ text: " ERROR -" + err.message });
	}
} 