//Author : Pooja Raje
//This Function Open the Page According to Policy Type

var formId, policytypeName, policytypeId;
function RedirectToPageLayoutBasedOnpolicyType(PrimaryControl, key) {
		var securityMap = new Array();
		var req = new XMLHttpRequest();
        var globalContext = Xrm.Utility.getGlobalContext();
        var ClientUrl = globalContext.getClientUrl();
		
				req.open("GET", ClientUrl + "/api/data/v9.1/rsa_customlabels?$select=rsa_dependentoptionsetjson,rsa_name&$filter=rsa_name eq 'SecurityRole'", false);
                req.setRequestHeader("OData-MaxVersion", "4.0");
                req.setRequestHeader("OData-Version", "4.0");
                req.setRequestHeader("Accept", "application/json");
                req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                req.onreadystatechange = function () {
                    if (this.readyState === 4) {
                        req.onreadystatechange = null;
                       if (this.status === 200) {
                            var results = JSON.parse(this.response);
                            for (var i = 0; i < results.value.length; i++) {
                                var rsa_categories = results.value[i]["rsa_categories"];
                                var rsa_dependentoptionsetjson = results.value[i]["rsa_dependentoptionsetjson"];
                                var SecurityRoleMapping = JSON.parse(results.value[i]["rsa_dependentoptionsetjson"]).SecurityRoleMapping;
								var roles = Xrm.Utility.getGlobalContext().userSettings.securityRoles;
								
								  for(var i=0; i < roles.length; i++ ){
									var GUID = Xrm.Utility.getGlobalContext().userSettings.securityRoles[i];
									SecurityRoleMapping.forEach(function (item) {
									if(item.SecurityRoleGUID.toLowerCase() == GUID.toLowerCase())
										securityMap.push(item.SecurityRoleValue);
									});
								}
							}
						}
                        else {
                            Xrm.Navigation.openAlertDialog({ text: "Get Security Role Mapping: " + this.statusText });
                        }
                    }
                };
                req.send();
				
				var securityRoleMappingStr = ''; 
				for(var k=0; k < securityMap.length; k++){
					securityRoleMappingStr += "<value>" + securityMap[k] + "</value>"
				}
    var formId, policytypeName, policytypeId;
    var fetchXmlQuery = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
        "<entity name='rsa_formlayoutmapping'>" +
        "<attribute name='rsa_formlayoutmappingid' />" +
        "<attribute name='rsa_name' />" +
        "<attribute name='rsa_policytype' />" +    
        "<attribute name='rsa_form' />" +
        "<order attribute='rsa_name' descending='false' />" +
		"<filter type='and'>" +
        "<condition attribute='rsa_formidentifier' operator='eq' value='" + key + "' />" +
		"<condition attribute='rsa_securityrolemapping' operator='contain-values'>" + securityRoleMappingStr +
		"</condition></filter>" + 
        "<link-entity name='rsa_formlayout' from='rsa_formlayoutid' to='rsa_form' link-type='inner' alias='ae'>" +
        "<attribute name='rsa_formid'/>" +
        "<filter type='and'>" +       
        "<condition attribute='rsa_entityname' operator='eq' value='866760003' />" +
        "</filter>" +
        "</link-entity>" +
        "</entity>" +
        "</fetch>";
		
    var req = new XMLHttpRequest();
    var globalContext = Xrm.Utility.getGlobalContext();
    var ClientUrl = globalContext.getClientUrl();
    req.open("GET", ClientUrl + "/api/data/v9.1/rsa_formlayoutmappings?fetchXml=" + encodeURIComponent(fetchXmlQuery), true);
    req.setRequestHeader("Prefer", 'odata.include-annotations="*"');
    req.onreadystatechange = function () {
        if (this.readyState === 4) {
            req.onreadystatechange = null;
            if (this.status === 200) {
                var results = JSON.parse(this.response);
                if (results.value.length > 0) {
                    formId = results.value[0]["ae.rsa_formid"];
                    policytypeName = results.value[0]["_rsa_policytype_value@OData.Community.Display.V1.FormattedValue"];
                    policytypeId = results.value[0]["_rsa_policytype_value"];
					//PolicyDependentOptionset(excecutionContext, policytypeId);

                    if (formId !== null) {
                        var entityFormOptions = {};
                        entityFormOptions["entityName"] = "rsa_policy";
                        entityFormOptions["formId"] = formId;

                        var formParameters = {};
                        if (policytypeName !== null && policytypeId !== null) {
                            formParameters["rsa_policytype"] = policytypeId;
                            formParameters["rsa_policytypename"] = policytypeName;
                            formParameters["rsa_policytypetype"] = "rsa_policytype";
	
                        }

                        // Open the form.
                         Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
                             function (success) {
                                 //console.log(success);
                             },
                             function (error) {
                                 //console.log(error);
                             });
						// if(formId==formContext.ui.formSelector.getCurrentItem().getId()){
							// return;
						// }
						// formContext.ui.formSelector.items.get(formId).navigate();
                    }
                }
            } else {
                Xrm.Navigation.openAlertDialog(this.statusText);
            }
        }
    };
    req.send();
}
   //This Function Option set to Option set filtering
   function PolicyDependentOptionset(executionContext,policytypeId) {
        try {			
			var formContext = executionContext.getFormContext();
			if (policytypeId !== null && policytypeId !== undefined) {
			    var req = new XMLHttpRequest();
                var globalContext = Xrm.Utility.getGlobalContext();
                var ClientUrl = globalContext.getClientUrl();
		
				req.open("GET", ClientUrl + "/api/data/v9.1/rsa_customlabels?$select=rsa_categories,rsa_customlabelid,_rsa_policytype_value,rsa_dependentoptionsetjson&$filter=_rsa_policytype_value eq " + policytypeId , true);
                req.setRequestHeader("OData-MaxVersion", "4.0");
                req.setRequestHeader("OData-Version", "4.0");
                req.setRequestHeader("Accept", "application/json");
                req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                req.onreadystatechange = function () {
                    if (this.readyState === 4) {
                        req.onreadystatechange = null;
                        if (this.status === 200) {
                            var results = JSON.parse(this.response);
                            for (var i = 0; i < results.value.length; i++) {
                                var rsa_categories = results.value[i]["rsa_categories"];
                                var rsa_customlabelid = results.value[i]["rsa_customlabelid"];
                                var rsa_dependentoptionsetjson = results.value[i]["rsa_dependentoptionsetjson"];
                                var OptionSet = JSON.parse(results.value[i]["rsa_dependentoptionsetjson"]).ParentFieldDependency[0].OptionSet;
								var LookUp = JSON.parse(results.value[i]["rsa_dependentoptionsetjson"]).ParentFieldDependency[0].LookUp;
								
								
                                
                                for (var i = 0; i < OptionSet.length; i++) {

                                    var DependentField = OptionSet[i].DependentField;
                                    var ApplicableValue = OptionSet[i].ApplicableValue;
									var DefaultValue = OptionSet[i].DefaultValue;
                                    var splitValue = ApplicableValue.split(",");

                                    if (formContext.getAttribute(DependentField) !== null && formContext.getAttribute(DependentField) !== undefined) {
                                        var OptionSetValues = formContext.getAttribute(DependentField).getOptions();

                                        for (var k = 0; k < OptionSetValues.length; k++) {
                                            if (splitValue.indexOf(OptionSetValues[k].value.toString()) === -1) {
                                                formContext.getControl(DependentField).removeOption(OptionSetValues[k].value);
                                            }

                                        }
										if(DefaultValue !== null && DefaultValue !== undefined){
										//Set the default value of the optionset
                                                                                if (formContext.ui.getFormType() === 1) {
										formContext.getAttribute(DependentField).setValue(DefaultValue);
                                                                                 }
										}
                                    }

                                }

						//Set the default value of the lookup 	
    							if(LookUp.length > 0)	{
								for (var i = 0; i < LookUp.length; i++) {
                                    var lookupDependentField = LookUp[i].lookupDependentField;
									var Entity = LookUp[i].lookupDefaultValue.Entity; 
								    var GUID = LookUp[i].lookupDefaultValue.GUID; 
									var StatusName = LookUp[i].lookupDefaultValue.StatusName;
									
                                    var lookupDefaultValue = LookUp[i].lookupDefaultValue.rsa_statusname;
                                    if (formContext.getAttribute(lookupDependentField) !== null && formContext.getAttribute(lookupDependentField) !== undefined) {
                                       //Set  defualt Value for Option set 
                                       if (formContext.ui.getFormType() === 1) {
                                        formContext.getAttribute(lookupDependentField).setValue([{ id: GUID, name: StatusName, entityType: Entity}]);
							}		
										}

									}
								}
							}
						}
						
                        else {
                            Xrm.Navigation.openAlertDialog({ text: "PolicyDependentOptionset : " + this.statusText });
                        }
                    }
                };
                req.send();

				}
			}
			
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: " Option set value -" + err.message });
        }
    }
	

/* Change Summary for April 2022 Release 1 */
/* Last Modified By: Shreya Diwate*/
/* Summary of Changes: Remove Debug Code*/
/* - Reason for Change: Unexpected 'debugger' statement */
/* - Function name - OnLoadPolicy */

function OnLoadPolicy(excecutionContext) {    
    //debugger;
    try {
		var formContext = excecutionContext.getFormContext();
		LoadingExistingRecord(excecutionContext); 

        //var lOBName, lOBId;
		
        var formId = formContext.ui.formSelector.getCurrentItem().getId().toUpperCase().replace(/[{}]/g, '');

        var fetchXmlQuery = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
            "<entity name='rsa_formlayoutmapping'>" +
            "<attribute name='rsa_formlayoutmappingid' />" +
            "<attribute name='rsa_name' />" +
            "<attribute name='rsa_policytype' />" +
            "<attribute name='rsa_form' />" +
            "<order attribute='rsa_name' descending='false' />" +
            "<link-entity name='rsa_formlayout' from='rsa_formlayoutid' to='rsa_form' link-type='inner' alias='ae'>" +
            "<attribute name='rsa_formid'/>" +
            "<filter type='and'>" +
            "<condition attribute='rsa_formid' operator='eq' value= '" + formId + "'/>" +
            "<condition attribute='rsa_entityname' operator='eq' value='866760003' />" +
            "</filter>" +
            "</link-entity>" +
            "</entity>" +
            "</fetch>";

        var req = new XMLHttpRequest();
        var globalContext = Xrm.Utility.getGlobalContext();
        var ClientUrl = globalContext.getClientUrl();
        req.open("GET", ClientUrl + "/api/data/v9.1/rsa_formlayoutmappings?fetchXml=" + encodeURIComponent(fetchXmlQuery), true);
        req.setRequestHeader("Prefer", 'odata.include-annotations="*"');
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    var results = JSON.parse(this.response);
                    if (results.value.length > 0) {
                        formId = results.value[0]["ae.rsa_formid"];
                        policytypeName= results.value[0]["_rsa_policytype_value@OData.Community.Display.V1.FormattedValue"];
                        policytypeId= results.value[0]["_rsa_policytype_value"];
                         if(formContext.getAttribute("rsa_policytype").getValue() === null)
                        formContext.getAttribute("rsa_policytype").setValue([{ id: policytypeId, name: policytypeName, entityType: "rsa_policytype" }]);
                        PolicyDependentOptionset(excecutionContext, policytypeId);
                    }
                }
                else {
                    Xrm.Navigation.openAlertDialog({ text: "OnLoadPolicy " + this.statusText });
                }
            }
        };
        req.send();

    }

    catch (err) {
        Xrm.Navigation.openAlertDialog({ text: "OnLoadPolicy -" + err.message });
    }
}

//Author : Pooja Raje
    //This Function opens the correct form while opening the existing records
 function LoadingExistingRecord(excecutionContext) {
        /* try {
            var formContext = excecutionContext.getFormContext();
            if (formContext.getAttribute("rsa_policyformid") !== null && formContext.getAttribute("rsa_policyformid") !== undefined && formContext.ui.getFormType() === 2 || formContext.ui.getFormType() === 3 ||formContext.ui.getFormType() === 4) {
                if (formContext.getAttribute("rsa_policyformid").getValue() !== null && formContext.getAttribute("rsa_policyformid").getValue() !== undefined) {
                    var policyFormID = formContext.getAttribute("rsa_policyformid").getValue();
                    var formId = formContext.ui.formSelector.getCurrentItem().getId();
                    if (formId !== policyFormID) {
                        formContext.ui.formSelector.items.get(policyFormID).navigate();
                    }
                }
            }
        }

        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "LoadingExistingRecord -" + err.message });
        } */
    }


/* Change Summary for April 2022 Release 1 */
/* Last Modified By: Shreya Diwate*/
/* Summary of Changes: Replace Xrm.Utility.alertDialog(this.responseText) with Xrm.Navigation.openAlertDialog */
/* - Reason for Change: Xrm.Utility.alertDialog(this.responseText)' uses a deprecated API*/
/* - Function name - TriggerChangeOnLoadOfForm */


function TriggerChangeOnLoadOfForm(executionContext) {
	 try {
	        var globalContext = Xrm.Utility.getGlobalContext();
            var formContext = executionContext.getFormContext();
			var req = new XMLHttpRequest();
			
			/*req.open("GET",Xrm.Page.context.getClientUrl() + "/api/data/v9.1/rsa_customlabels?$select=rsa_dependentoptionsetjson&$filter=rsa_name eq 'PolicyNumberToPercentConversion'", false);*/
			
				req.open("GET",globalContext.getClientUrl() + "/api/data/v9.1/rsa_customlabels?$select=rsa_dependentoptionsetjson&$filter=rsa_name eq 'PolicyNumberToPercentConversion'", false);
				req.setRequestHeader("OData-MaxVersion", "4.0");
				req.setRequestHeader("OData-Version", "4.0");
				req.setRequestHeader("Accept", "application/json");
				req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
				req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
				req.onreadystatechange = function() {
					if (this.readyState === 4) {
						req.onreadystatechange = null;
						if (this.status === 200) {
							var results = JSON.parse(this.response);
							for (var i = 0; i < results.value.length; i++) {
								var rsa_dependentoptionsetjson = results.value[i]["rsa_dependentoptionsetjson"];
								var NumberToPercent = JSON.parse(results.value[i]["rsa_dependentoptionsetjson"]).NumberToPercent;
								
								 for (var j = 0; j < NumberToPercent.length; j++) {
									 
									var schemaName = NumberToPercent[j].SchemaName;

									if (formContext.getAttribute(schemaName) !== null && formContext.getAttribute(schemaName) !== undefined) {
											//formContext.getAttribute(schemaName).addOnChange(ConvertNumberToPercent);
											ConvertNumberToPercent(executionContext, schemaName);
									}
								}
								
							}
						} else {
							//Xrm.Utility.alertDialog(this.statusText);
							Xrm.Navigation.openAlertDialog(this.statusText);
							
						}
					}
				};
				req.send();
			
            
        } catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "TriggerChangeOnLoadOfForm -" + err.message });
        }
    }

function ConvertNumberToPercent(executionContext, fieldName) {
        try {
            var formContext = executionContext.getFormContext();
			//var fieldName = executionContext.getEventSource().getName();
			
            if (formContext.getAttribute(fieldName) !== null && formContext.getAttribute(fieldName) !== "undefined" && formContext.getAttribute(fieldName).getValue() !== null && formContext.getAttribute(fieldName).getValue() !== "undefined" ) {
				
				//Get Number field value and divide it by 100
				//var fieldValueinPercent = formContext.getAttribute(fieldName).getValue()/100;
				
                //Set Percentage value in same field
				//formContext.getAttribute(fieldName).setValue(fieldValueinPercent);
				
            }
        } catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "ConvertNumberToPercent -" + err.message });
        }
    }
/* Change Summary for April 2022 Release 1 */
/* Last Modified By: Shreya Diwate*/
/* Summary of Changes: Remove Debug Code*/
/* - Reason for Change: Unexpected 'debugger' statement */
/* - Function name - RedirectExistingToPolicyType */

function RedirectExistingToPolicyType(executionContext, triggerType) {
    //debugger;
	var formId, policytypeName, policytypeId;
    var formContext = executionContext.getFormContext();
	
	/* formId = formContext.getAttribute("rsa_policyformid").getValue();
	if(triggerType != "onchange"){
	if(formId != null && formId != undefined){
		//formContext.getAttribute("rsa_policyformid").setValue(null);
		return;
	}
	} */
	    
    var policyTypevalue = formContext.getAttribute("rsa_policytype");
	if (policyTypevalue.getValue() === null){
        return; 
	}
    if (policyTypevalue.getValue() === null && formContext.ui.getFormType() === 2){
        return;
	}
	
	if(formContext.ui.getFormType() === 1 && triggerType != "onchange"){
		return;
	}
    
	var policyType = policyTypevalue.getValue()[0].id;
    var securityMap = new Array();
    var req = new XMLHttpRequest();
    var globalContext = Xrm.Utility.getGlobalContext();
    var ClientUrl = globalContext.getClientUrl();
    req.open("GET", ClientUrl + "/api/data/v9.1/rsa_customlabels?$select=rsa_dependentoptionsetjson,rsa_name&$filter=rsa_name eq 'SecurityRole'", false);
    req.setRequestHeader("OData-MaxVersion", "4.0");
    req.setRequestHeader("OData-Version", "4.0");
    req.setRequestHeader("Accept", "application/json");
    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
    req.onreadystatechange = function () {
        if (this.readyState === 4) {
            req.onreadystatechange = null;
            if (this.status === 200) {
                var results = JSON.parse(this.response);
                for (var i = 0; i < results.value.length; i++) {
                    var rsa_categories = results.value[i]["rsa_categories"];
                    var rsa_dependentoptionsetjson = results.value[i]["rsa_dependentoptionsetjson"];
                    var SecurityRoleMapping = JSON.parse(results.value[i]["rsa_dependentoptionsetjson"]).SecurityRoleMapping;
                    var roles = Xrm.Utility.getGlobalContext().userSettings.securityRoles;
                    for (var i = 0; i < roles.length; i++) {
                        var GUID = Xrm.Utility.getGlobalContext().userSettings.securityRoles[i];
                        SecurityRoleMapping.forEach(function (item) {
                            if (item.SecurityRoleGUID.toLowerCase() == GUID.toLowerCase())
                                securityMap.push(item.SecurityRoleValue);
                        });
                    }
                }
            }
            else {
                Xrm.Navigation.openAlertDialog({ text: "Get Security Role Mapping: " + this.statusText });
            }
        }
    };
    req.send();
    var securityRoleMappingStr = '';
    for (var k = 0; k < securityMap.length; k++) {
        securityRoleMappingStr += "<value>" + securityMap[k] + "</value>";
    }

    
    var fetchXmlQuery = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
        "<entity name='rsa_formlayoutmapping'>" +
        "<attribute name='rsa_formlayoutmappingid' />" +
        "<attribute name='rsa_name' />" +
        "<attribute name='rsa_policytype' />" +
"<attribute name='rsa_securityrolemapping' />" +
        "<attribute name='rsa_form' />" +
        "<order attribute='rsa_name' descending='false' />" +
"<filter type='and'>" +
        "<condition attribute='rsa_policytype'  operator='eq' value='" + policyType + "' />" +
"<condition attribute='rsa_securityrolemapping' operator='contain-values'>" + securityRoleMappingStr +
"</condition></filter>" +
        "<link-entity name='rsa_formlayout' from='rsa_formlayoutid' to='rsa_form' link-type='inner' alias='ae'>" +
        "<attribute name='rsa_formid'/>" +
        "<filter type='and'>" +
        "<condition attribute='rsa_entityname' operator='eq' value='866760003' />" +
        "</filter>" +
        "</link-entity>" +
        "</entity>" +
        "</fetch>";
    var req = new XMLHttpRequest();
    var globalContext = Xrm.Utility.getGlobalContext();
    var ClientUrl = globalContext.getClientUrl();
    req.open("GET", ClientUrl + "/api/data/v9.1/rsa_formlayoutmappings?fetchXml=" + encodeURIComponent(fetchXmlQuery), true);
    req.setRequestHeader("Prefer", 'odata.include-annotations="*"');
    req.onreadystatechange = function () {
        if (this.readyState === 4) {
            req.onreadystatechange = null;
            if (this.status === 200) {
                var results = JSON.parse(this.response);
                if (results.value.length > 0) {
                    formId = results.value[0]["ae.rsa_formid"];
                   policytypeName = results.value[0]["_rsa_policytype_value@OData.Community.Display.V1.FormattedValue"];
                    policytypeId = results.value[0]["_rsa_policytype_value"];

                    if (formId !== null) {
                        var entityFormOptions = {};
                        entityFormOptions["entityName"] = "rsa_policy";
                        entityFormOptions["formId"] = formId;
                        entityFormOptions["entityId"] = formContext.data.entity.getId();

                    }
					
					try {
						var navigatedformId = formContext.ui.formSelector.getCurrentItem().getId();
						if (navigatedformId.toLowerCase() === formId.toLowerCase()) {
					return;
					}
					}
					catch (err) {
						Xrm.Navigation.openAlertDialog({ text: "rsa_policyformid -" + err.message });
					}
                 //   formContext.getAttribute("rsa_policyformid").setValue(formId);
                 //   formContext.data.entity.save();
                     var formParameters = {};
                        if (policytypeName !== null && policytypeId !== null) {
                            formParameters["rsa_policytype"] = policytypeId;
							// formParameters["rsa_policyformid"] = formId;
                            formParameters["rsa_policytypename"] = policytypeName;
                            formParameters["rsa_policytypetype"] = "rsa_policytype";
	
                        }


                    // Open the form.
                    // Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
                           // function success(result) {

                             // //  formContext.getAttribute("rsa_policyformid").setValue(formId);
                            // //   formContext.data.entity.save();
                           // },
                           // function (error) {
                               // //console.log(error);
                           // });
					if(formId==formContext.ui.formSelector.getCurrentItem().getId()){
							return;
						}
					formContext.ui.formSelector.items.get(formId).navigate();
                }

            } else {
                Xrm.Navigation.openAlertDialog(this.statusText);
            }
        }
    };
    req.send();
}
