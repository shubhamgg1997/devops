"use strict";

var RSA = window.RSA || { __namespace: true, __typeName: "RSA" };
RSA.D365CRM = RSA.D365CRM || { __namespace: true, __typeName: "RSA.D365CRM" };
RSA.D365CRM.RSACustomLabel = RSA.D365CRM.RSACustomLabel || { __namespace: true, __typeName: "RSA.D365CRM.RSACustomLabel" };
RSA.D365CRM.RSACustomLabel.Main = RSA.D365CRM.RSACustomLabel.Main || ({
    FormType: {
        Create: 1,
        Update: 2,
        ReadOnly: 3,
        Disabled: 4,
        BulkEdit: 6
    },
    OnLoad: function (executionContext) {
        var formContext = executionContext.getFormContext();

        if (formContext.ui.getFormType() === RSA.D365CRM.RSACustomLabel.Main.FormType.Create) {

            RSA.D365CRM.RSACustomLabel.Main.DependentOptionset(executionContext);

        }
        else if (formContext.ui.getFormType() === RSA.D365CRM.RSACustomLabel.Main.FormType.Update) {

        }
        else if (formContext.ui.getFormType() === RSA.D365CRM.RSACustomLabel.Main.FormType.Disabled) {

        }
        else if (formContext.ui.getFormType() === RSA.D365CRM.RSACustomLabel.Main.FormType.BulkEdit) {

        }

    },

    OnSave: function (executionContext) {



    },

    //Author : Shreya Diwate
    //Date : 25 Aug 2020
    //This Function Option set to Option set filtering



    DependentOptionset: function (executionContext) {
        try {

            var formContext = executionContext.getFormContext;
            var LOBID = Xrm.Utility.getGlobalContext().getQueryStringParameters().rsa_lineofbusiness;
            var req = new XMLHttpRequest();

            var globalContext = Xrm.Utility.getGlobalContext();
            var ClientUrl = globalContext.getClientUrl();
            req.open("GET", ClientUrl + "/api/data/v9.1/rsa_customlabels?$select=rsa_categories,rsa_customlabelid,rsa_dependentoptionsetjson&$filter=rsa_categories eq " + LOBID, true);

            req.setRequestHeader("OData-MaxVersion", "4.0");
            req.setRequestHeader("OData-Version", "4.0");
            req.setRequestHeader("Accept", "application/json");
            req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
            req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            req.onreadystatechange = function () {
                if (this.readyState === 4) {
                    req.onreadystatechange = null;
                    if (this.status === 200) {
                        var results = JSON.parse(this.response);
                        for (var i = 0; i < results.value.length; i++) {
                            var rsa_categories = results.value[i]["rsa_categories"];
                            var rsa_customlabelid = results.value[i]["rsa_customlabelid"];
                            var rsa_dependentoptionsetjson = results.value[i]["rsa_dependentoptionsetjson"];
                            var childObj = JSON.parse(results.value[i]["rsa_dependentoptionsetjson"]).ParentFieldDependency[0].Childs;
                            //JSON.parse(results.value[i]["rsa_dependentoptionsetjson"].ParentFieldDependency[0].Childs[0].ApplicableValue)
                            //JSON.parse(results.value[i]["rsa_dependentoptionsetjson"]).ParentFieldDependency[0].Childs[0].DependentField


                            for (var i = 0; i < childObj.length; i++) {

                                var DependentField = childObj[i].DependentField;
                                var ApplicableValue = childObj[i].ApplicableValue;
                                var splitValue = ApplicableValue.split(",");

                                if (formContext.getAttribute(DependentField) !== null && formContext.getAttribute(DependentField) !== undefined) {
                                    var OptionSetValues = formContext.getAttribute(DependentField).getOptions();

                                    for (var k = 0; k < OptionSetValues.length; k++) {
                                        if (splitValue.indexOf(OptionSetValues[k].value.toString()) === -1) {
                                            formContext.getControl(DependentField).removeOption(OptionSetValues[k].value);
                                        }

                                    }

                                }

                            }

                        }

                    }
                    else {
                        Xrm.Navigation.openAlertDialog({ text: "DependentOptionset : " + this.statusText });
                    }
                }
            };
            req.send();

        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: " Option set value -" + err.message });
        }

    },

    ConvertGuid: function (str) {
        if (str) {
            str = str.replace(/[{}]/g, '');
            str = str.toUpperCase();
        }
        return str;
    }

});
