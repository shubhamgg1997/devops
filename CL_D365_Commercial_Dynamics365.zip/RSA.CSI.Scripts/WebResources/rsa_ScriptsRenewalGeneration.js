"use strict";

function IdentifyRenewal() {
    var parameters = {};
    parameters.renewalId = parent.Xrm.Page.data.entity.getId();
    parameters.mode = "IdentifyRenewal";
    parameters.triggeredBy = Xrm.Utility.getGlobalContext().userSettings.userId;

    var req = new XMLHttpRequest();
    var globalContext = Xrm.Utility.getGlobalContext();
    var ClientUrl = globalContext.getClientUrl();
    req.open("POST", ClientUrl + "/api/data/v8.2/rsa_IdentifyRenewal", true);
    req.setRequestHeader("OData-MaxVersion", "4.0");
    req.setRequestHeader("OData-Version", "4.0");
    req.setRequestHeader("Accept", "application/json");
    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    req.onreadystatechange = function () {
        if (this.readyState === 4) {
            req.onreadystatechange = null;
            if (this.status === 204) {
                //Success - No Return Data - Do Something
            } else {
                Xrm.Navigation.openAlertDialog(this.statusText);
            }
        }
    };
    req.send(JSON.stringify(parameters));

}


function renewalGeneration() {
    var checkRenewal;
    if (parent.Xrm.Page.getAttribute("rsa_generaterenewals").getValue() !== undefined || parent.Xrm.Page.getAttribute("rsa_generaterenewals").getValue() !== null) {
        checkRenewal = parent.Xrm.Page.getAttribute("rsa_generaterenewals").getValue();
    }
    if (checkRenewal === false) {
        Xrm.Navigation.openAlertDialog("Please select the Renewal Generation checkbox");
    }
    else {
        var parameters = {};
        parameters.renewalId = parent.Xrm.Page.data.entity.getId();
        parameters.mode = "RenewalGeneration";
        parameters.triggeredBy = Xrm.Utility.getGlobalContext().userSettings.userId;
        var req = new XMLHttpRequest();
        var globalContext = Xrm.Utility.getGlobalContext();
        var ClientUrl = globalContext.getClientUrl();
        req.open("POST", ClientUrl + "/api/data/v8.2/rsa_RenewalGeneration", true);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 204) {
                    //Success - No Return Data - Do Something
                } else {
                    Xrm.Navigation.openAlertDialog(this.statusText);
                }
            }
        };
        req.send(JSON.stringify(parameters));
    }
}