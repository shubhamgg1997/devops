"use strict";

var RSA = window.RSA || { __namespace: true, __typeName: "RSA" };
RSA.D365CRM = RSA.D365CRM || { __namespace: true, __typeName: "RSA.D365CRM" };
RSA.D365CRM.Request = RSA.D365CRM.Request || { __namespace: true, __typeName: "RSA.D365CRM.Request" };
RSA.D365CRM.Request.Main = RSA.D365CRM.Request.Main || ({
    FormType: {
        Create: 1,
        Update: 2,
        ReadOnly: 3,
        Disabled: 4,
        BulkEdit: 6
    },
    OnLoad: function (executionContext) {
        var formContext = executionContext.getFormContext();
        RSA.D365CRM.Request.Main.RetriveOpportunityData(executionContext);
        if (formContext.ui.getFormType() === RSA.D365CRM.Request.Main.FormType.Create) {

        }
        else if (formContext.ui.getFormType() === RSA.D365CRM.Request.Main.FormType.Update) {

        }
        else if (formContext.ui.getFormType() === RSA.D365CRM.Request.Main.FormType.Disabled) {

        }
        else if (formContext.ui.getFormType() === RSA.D365CRM.Request.Main.FormType.BulkEdit) {

        }

    },
    OnSave: function (executionContext) {
        RSA.D365CRM.Request.Main.PrioritiseRequiredFields(executionContext);
        RSA.D365CRM.Request.Main.TechDescriptionRequired(executionContext);
    },

    //Author : Chandani Vaishnani
    //Date : 06 Aug 2020
    //This Function Validation for Expiry Date Field for certain condition
    //Time_Remaining__c
    TimeRemaining: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_targetcompletion") !== null && formContext.getAttribute("rsa_targetcompletion") !== "undefined" && formContext.getAttribute("rsa_timeremaining") !== null && formContext.getAttribute("rsa_timeremaining") !== "undefined") {
                var targetCompletion = new Date(formContext.getAttribute("rsa_targetcompletion").getValue());
                var currentDate = new Date;
                if (currentDate - targetCompletion > 0) {
                    var diff = (currentDate - targetCompletion) / (1000 * 60);
                    var parts = new Object();

                    parts.Days = Math.floor(diff / (60 * 24));
                    diff -= (parts.Days * 60 * 24);
                    parts.Hours = Math.floor(diff / 60);
                    diff -= (parts.Hours * 60);
                    parts.Minutes = Math.floor(diff);

                    parts.Display =
                        (parts.Days > 0 ? parts.Days + " days, " : "") +
                        (parts.Hours > 0 ? parts.Hours + " hrs, " : "") +
                        (parts.Minutes + " mins");

                    formContext.getAttribute("rsa_timeremaining").setValue((parts.Days > 0 ? parts.Days + " days, " : "") + (parts.Hours > 0 ? parts.Hours + " hrs, " : "") + (parts.Minutes + " mins"));
                }
            }
            else {
                formContext.getAttribute("rsa_timeremaining").setValue("0 days 0 hours 0 mins");
            }

        } catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "TimeRemaining -" + err.message });
        }
    },

    PrioritiseRequiredFields: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_status") !== "undefined"
                && formContext.getAttribute("rsa_implementationtype") !== null && formContext.getAttribute("rsa_functionaldescription") !== null
                && formContext.getAttribute("rsa_businessareasimpacted") !== null && formContext.getAttribute("rsa_impactassessment") !== null
                && formContext.getAttribute("rsa_design") !== null && formContext.getAttribute("rsa_build") !== null
                && formContext.getAttribute("rsa_test") !== null && formContext.getAttribute("rsa_uat") !== null && formContext.getAttribute("rsa_technicaldescription") !== null) {

                var status = formContext.getAttribute("rsa_status").getValue();
                var statusTypeArray = [866760006, 866760007, 866760008, 866760009, 866760011, 866760012, 866760013, 866760014, 866760015, 866760016]
                var hasValue = statusTypeArray.includes(status, 0);
                var implementationType = formContext.getAttribute("rsa_implementationtype");
                var functionalDescription = formContext.getAttribute("rsa_functionaldescription");
                var businessareasImpacted = formContext.getAttribute("rsa_businessareasimpacted");
                var impactAssessment = formContext.getAttribute("rsa_impactassessment");
                var design = formContext.getAttribute("rsa_design");
                var build = formContext.getAttribute("rsa_build");
                var test = formContext.getAttribute("rsa_test");
                var uat = formContext.getAttribute("rsa_uat");
                var technicalDescription = formContext.getAttribute("rsa_technicaldescription");

                if (hasValue) {
                    if (implementationType.getValue() === null && functionalDescription.getValue() === null && businessareasImpacted.getValue() === null && impactAssessment.getValue() === null &&
                        design.getValue() === null && build.getValue() === null && test.getValue() === null && uat.getValue() === null) {
                        formContext.getAttribute("rsa_implementationtype").setRequiredLevel("required");
                        formContext.getAttribute("rsa_functionaldescription").setRequiredLevel("required");
                        formContext.getAttribute("rsa_businessareasimpacted").setRequiredLevel("required");
                        formContext.getAttribute("rsa_impactassessment").setRequiredLevel("required");
                        formContext.getAttribute("rsa_design").setRequiredLevel("required");
                        formContext.getAttribute("rsa_build").setRequiredLevel("required");
                        formContext.getAttribute("rsa_test").setRequiredLevel("required");
                        formContext.getAttribute("rsa_uat").setRequiredLevel("required");
                    }
                    else {
                        formContext.getAttribute("rsa_implementationtype").setRequiredLevel("none");
                        formContext.getAttribute("rsa_functionaldescription").setRequiredLevel("none");
                        formContext.getAttribute("rsa_businessareasimpacted").setRequiredLevel("none");
                        formContext.getAttribute("rsa_impactassessment").setRequiredLevel("none");
                        formContext.getAttribute("rsa_design").setRequiredLevel("none");
                        formContext.getAttribute("rsa_build").setRequiredLevel("none");
                        formContext.getAttribute("rsa_test").setRequiredLevel("none");
                        formContext.getAttribute("rsa_uat").setRequiredLevel("none");
                    }


                    if (technicalDescription.getValue() === null && implementationType.getValue() !== null && (implementationType.getValue() === 866760009 || implementationType.getValue() === 866760010)) {
                        formContext.getAttribute("rsa_technicaldescription").setRequiredLevel("required");
                    }
                    else {
                        formContext.getAttribute("rsa_technicaldescription").setRequiredLevel("none");
                    }
                }

            }

        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "TimeRemaining -" + err.message });
        }
    },

TechDescriptionRequired: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
             var requestRecordType = formContext.getAttribute("rsa_requestrecordtype").getValue()[0].id.replace(/[{}]/g, '');
            if (formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_status") !== "undefined"
                && formContext.getAttribute("rsa_implementationtype") !== null && formContext.getAttribute("rsa_implementationtype") !== "undefined" && formContext.getAttribute("rsa_technicaldescription") !== null && formContext.getAttribute("rsa_technicaldescription") !== "undefined" && formContext.getAttribute("rsa_requestrecordtype") !== null && formContext.getAttribute("rsa_requestrecordtype") !== "undefined" && requestRecordType === "90C75594-A7D8-EA11-A814-000D3A7FC45E")
				{
				
				
                var status = formContext.getAttribute("rsa_status").getValue();
				var statusTypeArray = [866760006, 866760007, 866760008, 866760009, 866760011, 866760012, 866760013, 866760014, 866760015, 866760016]
                var statusHasValue = statusTypeArray.includes(status, 0);

				var technicalDescription = formContext.getAttribute("rsa_technicaldescription");
				
				var implementationType = formContext.getAttribute("rsa_implementationtype").getValue();
				var impTypeArray = [866760009, 866760010]
                var impTypeHasValue = impTypeArray.includes(implementationType, 0);
				
             
                if (statusHasValue && impTypeHasValue && technicalDescription.getValue() === null) {
                    

                    
                        formContext.getAttribute("rsa_technicaldescription").setRequiredLevel("required");
						formContext.getControl("rsa_technicaldescription").setNotification("As this request requires customisation the technical description field should be completed.", 201);
                }
				
				else if (statusHasValue && implementationType.includes(866760009) && technicalDescription.getValue() === null) {
                    

                    
                        formContext.getAttribute("rsa_technicaldescription").setRequiredLevel("required");
						formContext.getControl("rsa_technicaldescription").setNotification("As this request requires customisation the technical description field should be completed.", 201);
                }
				
				else if (statusHasValue && implementationType.includes(866760010) && technicalDescription.getValue() === null) {
                    

                    
                        formContext.getAttribute("rsa_technicaldescription").setRequiredLevel("required");
						formContext.getControl("rsa_technicaldescription").setNotification("As this request requires customisation the technical description field should be completed.", 201);
                }
				
				
                    else {
						formContext.getControl("rsa_technicaldescription").clearNotification(201);
                        formContext.getAttribute("rsa_technicaldescription").setRequiredLevel("none");
                    }
                
			}

         }

        
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "Tech Description Required -" + err.message });
        }
    },
});

