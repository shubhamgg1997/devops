/* Date: 27-Mar-2025
  Created By: Hanumantha */

"use strict";

var RSA = window.RSA || { __namespace: true, __typeName: "RSA" };
RSA.D365CRM = RSA.D365CRM || { __namespace: true, __typeName: "RSA.D365CRM" };
RSA.D365CRM.SLCommon = RSA.D365CRM.SLCommon || { __namespace: true, __typeName: "RSA.D365CRM.SLCommon" };
RSA.D365CRM.SLCommon.Main = RSA.D365CRM.SLCommon.Main || ({
    FormType: {
        Create: 1,
        Update: 2,
        ReadOnly: 3,
        Disabled: 4,
        BulkEdit: 6
    },
    OnLoad: function (executionContext) {
        // RSA.D365CRM.SLCommon.Main.ShowHideFormFields(executionContext);
    },
    ShowHideFormFields: function (executionContext, arrIds, IsVisible, SetNullValue) {
        var formContext = executionContext.getFormContext();
        arrIds.forEach(function (id) {
            formContext.getControl(id).setVisible(IsVisible);
            if (SetNullValue === true) {
                formContext.getAttribute(id).setValue(null);
            }
        });
    }
});