/* Change Summary for April 2022 Release 1 */
/* Last Modified By: Bubun Bhandari*/
/* Summary of Changes: Remove Debug Code*/
/* - Reason for Change: Unexpected 'debugger' statement */
/* - Function name -ABRTrackingFilter */

//"use strict";

function SelectActivityTypeBasedOnForm(excecutionContext) {
    var formContext = excecutionContext.getFormContext();
    var formName = formContext.ui.formSelector.getCurrentItem().getId().toUpperCase();
    if (formContext.getAttribute("rsa_activityrecordtype") !== null && formContext.getAttribute("rsa_activityrecordtype") !== undefined) {
        if (formName === "Activity General Layout") {
            formContext.getAttribute("rsa_activityrecordtype").setValue(866760001);
        }
        else if (formName === "F0B554F1-AD1E-4879-99C0-409243D678CC") //Activity General 2 (Breach Reason)
        {
            formContext.getAttribute("rsa_activityrecordtype").setValue(866760000);
        }
        else if (formName === "1C0788E3-4C48-43F9-A2C1-33F8C7E5AD4B") //Activity General Layout (Due Date Locked and Volume)
        {
            formContext.getAttribute("rsa_activityrecordtype").setValue(866760002);
        }
        else if (formName === "ECFC2F78-1A82-4394-9671-37830D3FDF90") //Activity General Layout (Due Date Locked)
        {
            formContext.getAttribute("rsa_activityrecordtype").setValue(866760003);
        }
        else if (formName === "8B9566F9-F606-44DF-A579-2666CE358861") //ePromise Call - Callback
        {
            formContext.getAttribute("rsa_activityrecordtype").setValue(866760047);
        }
        else if (formName === "B6FE9904-C09A-4593-8440-43B3F23F3849") //ePromise Call
        {
            formContext.getAttribute("rsa_activityrecordtype").setValue(866760046);
        }
        else if (formName === "8BD8F862-D76F-4A12-9647-0EB5E38F665B") //Workbook Tasks Layout1
        {
            formContext.getAttribute("rsa_activityrecordtype").setValue(866760045);
        }
    }
}


function TimeRemaining(executionContext) {
    try {
        var formContext = executionContext.getFormContext();
        if (formContext.getAttribute("rsa_targetcompletion") !== null && formContext.getAttribute("rsa_targetcompletion") !== "undefined" && formContext.getAttribute("rsa_timeremainingtocomplete") !== null && formContext.getAttribute("rsa_timeremainingtocomplete") !== "undefined") {
            var targetCompletion = new Date(formContext.getAttribute("rsa_targetcompletion").getValue());
            var currentDate = new Date;
            if (currentDate - targetCompletion > 0) {
                var diff = (currentDate - targetCompletion) / (1000 * 60);
                var parts = new Object();

                parts.Days = Math.floor(diff / (60 * 24));
                diff -= (parts.Days * 60 * 24);
                parts.Hours = Math.floor(diff / 60);
                diff -= (parts.Hours * 60);
                parts.Minutes = Math.floor(diff);

                parts.Display =
                    (parts.Days > 0 ? parts.Days + " days, " : "") +
                    (parts.Hours > 0 ? parts.Hours + " hrs, " : "") +
                    (parts.Minutes + " mins");
                formContext.getAttribute("rsa_timeremaining").setValue((parts.Days > 0 ? parts.Days + " days, " : "") + (parts.Hours > 0 ? parts.Hours + " hrs, " : "") + (parts.Minutes + " mins"));
                //var DateLib = {};
                //var DatePart = DateLib.DiffParts(targetCompletion, currentDate);
                //formContext.getAttribute("rsa_timeremaing").setValue(DatePart);

                //DateLib.Diff = function (from, to) {
                //    return to - from;
                //}
                //DateLib.DiffMinutes = function (from, to) {
                //    return DateLib.Diff(from, to) / (1000 * 60);
                //}
                //DateLib.DiffParts = function (targetCompletion, currentDate) {
                //    var diff = DateLib.DiffMinutes(targetCompletion, currentDate);

                //    var parts = new Object();

                //    parts.Days = Math.floor(diff / (60 * 24));
                //    diff -= (parts.Days * 60 * 24);
                //    parts.Hours = Math.floor(diff / 60);
                //    diff -= (parts.Hours * 60);
                //    parts.Minutes = Math.floor(diff);

                //    parts.Display =
                //        (parts.Days > 0 ? parts.Days + " days, " : "") +
                //        (parts.Hours > 0 ? parts.Hours + " hrs, " : "") +
                //        (parts.Minutes + " mins");
                //    alert(parts);
                //    return parts;
            }
        }
        else {

        }

    } catch (err) {
        Xrm.Navigation.openAlertDialog({ text: "TimeRemaining -" + err.message });
    }
}

//Author : Pooja Raje
//Date : 21 Oct 2020
//This Function Open the Page According to Activity Type

/* Change Summary for April 2022 Release 1 */
/* Last Modified By: Shreya Diwate*/
/* Summary of Changes: Remove Debug Code*/
/* - Reason for Change: Unexpected 'debugger' statement */
/* - Function name - RedirectToPageLayoutBasedOnActivityType */
var formId, activitytypeName, activitytypeId;
function RedirectToPageLayoutBasedOnActivityType(PrimaryControl, key) {
    //debugger;
    var securityMap = new Array();
    var req = new XMLHttpRequest();
    var globalContext = Xrm.Utility.getGlobalContext();
    var ClientUrl = globalContext.getClientUrl();

    req.open("GET", ClientUrl + "/api/data/v9.1/rsa_customlabels?$select=rsa_dependentoptionsetjson,rsa_name&$filter=rsa_name eq 'SecurityRole'", false);
    req.setRequestHeader("OData-MaxVersion", "4.0");
    req.setRequestHeader("OData-Version", "4.0");
    req.setRequestHeader("Accept", "application/json");
    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
    req.onreadystatechange = function () {
        if (this.readyState === 4) {
            req.onreadystatechange = null;
            if (this.status === 200) {
                var results = JSON.parse(this.response);
                for (var i = 0; i < results.value.length; i++) {
                    var rsa_categories = results.value[i]["rsa_categories"];
                    var rsa_dependentoptionsetjson = results.value[i]["rsa_dependentoptionsetjson"];
                    var SecurityRoleMapping = JSON.parse(results.value[i]["rsa_dependentoptionsetjson"]).SecurityRoleMapping;
                    var roles = Xrm.Utility.getGlobalContext().userSettings.securityRoles;

                    for (var i = 0; i < roles.length; i++) {
                        var GUID = Xrm.Utility.getGlobalContext().userSettings.securityRoles[i];
                        SecurityRoleMapping.forEach(function (item) {
                            if (item.SecurityRoleGUID.toLowerCase() == GUID.toLowerCase())
                                securityMap.push(item.SecurityRoleValue);
                        });
                    }
                }
            }
            else {
                Xrm.Navigation.openAlertDialog({ text: "Get Security Role Mapping: " + this.statusText });
            }
        }
    };
    req.send();

    var securityRoleMappingStr = '';
    for (var k = 0; k < securityMap.length; k++) {
        securityRoleMappingStr += "<value>" + securityMap[k] + "</value>";
    }


    var formContext = PrimaryControl;
    var fetchXmlQuery = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
         "<entity name='rsa_formlayoutmapping'>" +
         "<attribute name='rsa_formlayoutmappingid' />" +
         "<attribute name='rsa_name' />" +
         "<attribute name='rsa_activitytype' />" +
         "<attribute name='rsa_securityrolemapping' />" +
         "<attribute name='rsa_form' />" +
         "<order attribute='rsa_name' descending='false' />" +
         "<filter type='and'>" +
         "<condition attribute='rsa_formidentifier' operator='eq' value='" + key + "' />" +
         "<condition attribute='rsa_securityrolemapping' operator='contain-values'>" + securityRoleMappingStr +
         "</condition></filter>" +
         "<link-entity name='rsa_formlayout' from='rsa_formlayoutid' to='rsa_form' link-type='inner' alias='ae'>" +
         "<attribute name='rsa_formid'/>" +
         "<filter type='and'>" +
         "<condition attribute='rsa_entityname' operator='eq' value='866760002' />" +
         "</filter>" +
         "</link-entity>" +
         "</entity>" +
         "</fetch>";

    var req = new XMLHttpRequest();
    var globalContext = Xrm.Utility.getGlobalContext();
    var ClientUrl = globalContext.getClientUrl();
    req.open("GET", ClientUrl + "/api/data/v9.1/rsa_formlayoutmappings?fetchXml=" + encodeURIComponent(fetchXmlQuery), true);
    req.setRequestHeader("Prefer", 'odata.include-annotations="*"');
    req.onreadystatechange = function () {
        if (this.readyState === 4) {
            req.onreadystatechange = null;
            if (this.status === 200) {
                var results = JSON.parse(this.response);
                if (results.value.length > 0) {
                    formId = results.value[0]["ae.rsa_formid"];
                    activitytypeName = results.value[0]["_rsa_activitytype_value@OData.Community.Display.V1.FormattedValue"];
                    activitytypeId = results.value[0]["_rsa_activitytype_value"];


                    if (formId !== null) {
                        var entityFormOptions = {};
                        entityFormOptions["entityName"] = "task";
                        entityFormOptions["formId"] = formId;

                        var formParameters = {};
                        if (activitytypeName !== null && activitytypeId !== null) {
                            formParameters["rsa_tasktype"] = activitytypeId;
                            formParameters["rsa_tasktypename"] = activitytypeName;
                            formParameters["rsa_tasktypetype"] = "rsa_activitytype";

                            if (formContext.data.entity.getEntityName() === "incident" && formContext.data !== undefined && formContext.getAttribute("title") !== undefined && formContext.getAttribute("title") !== null) {
                                formParameters["regardingobjectid"] = formContext.data.entity.getId();
                                formParameters["regardingobjectidname"] = formContext.getAttribute("title").getValue();
                                formParameters["regardingobjectidtype"] = formContext.data.entity.getEntityName();
                            }
                            if (formContext.data.entity.getEntityName() === "opportunity" && formContext.data !== undefined && formContext.getAttribute("name") !== undefined && formContext.getAttribute("name") !== null) {
                                formParameters["regardingobjectid"] = formContext.data.entity.getId();
                                formParameters["regardingobjectidname"] = formContext.getAttribute("name").getValue();
                                formParameters["regardingobjectidtype"] = formContext.data.entity.getEntityName();
                            }
                        }

                        // Open the form.
                        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
                            function (success) {
                                //console.log(success);
                            },
                            function (error) {
                                //console.log(error);
                            });
                    }
                }
            } else {
                Xrm.Navigation.openAlertDialog(this.statusText);
            }
        }
    };
    req.send();
}

/* Change Summary for April 2022 Release 1 */
/* Last Modified By: Shreya Diwate*/
/* Summary of Changes: Replace Xrm.page with ExecutionContext.getFormContext*/
/* - Reason for Change:Xrm.page deprecated API*/
/* - Function name - ABRTrackingFilter*/

function ABRTrackingFilter(executionContext) {

   

    try {
        formContext = executionContext.getFormContext();
        var InValues = formContext.getAttribute("rsa_carabr").getValue()
        if (InValues !== null && InValues === 866760000) {
            //Xrm.Page.ui.tabs.get("ABR").setVisible(true);
            formContext.ui.tabs.get("ABR").setVisible(true);

            //Xrm.Page.ui.tabs.get("CaseAllocationRule").setVisible(false);
            formContext.ui.tabs.get("CaseAllocationRule").setVisible(false);

        }
        if (InValues !== null && InValues === 866760001) {
            //Xrm.Page.ui.tabs.get("ABR").setVisible(false);
            formContext.ui.tabs.get("ABR").setVisible(false);

            //Xrm.Page.ui.tabs.get("CaseAllocationRule").setVisible(true);
            formContext.ui.tabs.get("CaseAllocationRule").setVisible(true);

        }

    }

    catch (err) {
        Xrm.Navigation.openAlertDialog({ text: "ABRTrackingFilter-" + err.message });
    }

}
/* Change Summary for April 2022 Release 1 */
/* Last Modified By: Shreya Diwate*/
/* Summary of Changes: Remove Debug Code*/
/* - Reason for Change: Unexpected 'debugger' statement */
/* - Function name - RedirectExistingTotaskType*/
function RedirectExistingTotaskType(executionContext, triggerType) {
    //debugger;
    var formId, tasktypeName, tasktypeId;
    var formContext = executionContext.getFormContext();

    /* formId = formContext.getAttribute("rsa_taskformid").getValue();
	if(triggerType != "onchange"){
	if(formId != null && formId != undefined){
		//formContext.getAttribute("rsa_taskformid").setValue(null);
		return;
	}
	} */

    var taskTypevalue = formContext.getAttribute("rsa_targetactivityrecordtype");
    if (taskTypevalue.getValue() === null) {
        return;
    }
    if (taskTypevalue.getValue() === null && formContext.ui.getFormType() === 2) {
        return;
    }

    if (formContext.ui.getFormType() === 1 && triggerType != "onchange") {
        return;
    }

    var taskType = taskTypevalue.getValue()[0].id;
    var securityMap = new Array();
    var req = new XMLHttpRequest();
    var globalContext = Xrm.Utility.getGlobalContext();
    var ClientUrl = globalContext.getClientUrl();
    req.open("GET", ClientUrl + "/api/data/v9.1/rsa_customlabels?$select=rsa_dependentoptionsetjson,rsa_name&$filter=rsa_name eq 'SecurityRole'", false);
    req.setRequestHeader("OData-MaxVersion", "4.0");
    req.setRequestHeader("OData-Version", "4.0");
    req.setRequestHeader("Accept", "application/json");
    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
    req.onreadystatechange = function () {
        if (this.readyState === 4) {
            req.onreadystatechange = null;
            if (this.status === 200) {
                var results = JSON.parse(this.response);
                for (var i = 0; i < results.value.length; i++) {
                    var rsa_categories = results.value[i]["rsa_categories"];
                    var rsa_dependentoptionsetjson = results.value[i]["rsa_dependentoptionsetjson"];
                    var SecurityRoleMapping = JSON.parse(results.value[i]["rsa_dependentoptionsetjson"]).SecurityRoleMapping;
                    var roles = Xrm.Utility.getGlobalContext().userSettings.securityRoles;
                    for (var i = 0; i < roles.length; i++) {
                        var GUID = Xrm.Utility.getGlobalContext().userSettings.securityRoles[i];
                        SecurityRoleMapping.forEach(function (item) {
                            if (item.SecurityRoleGUID.toLowerCase() == GUID.toLowerCase())
                                securityMap.push(item.SecurityRoleValue);
                        });
                    }
                }
            }
            else {
                Xrm.Navigation.openAlertDialog({ text: "Get Security Role Mapping: " + this.statusText });
            }
        }
    };
    req.send();
    var securityRoleMappingStr = '';
    for (var k = 0; k < securityMap.length; k++) {
        securityRoleMappingStr += "<value>" + securityMap[k] + "</value>";
    }


    var fetchXmlQuery = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
        "<entity name='rsa_formlayoutmapping'>" +
        "<attribute name='rsa_formlayoutmappingid' />" +
        "<attribute name='rsa_name' />" +
        "<attribute name='rsa_activitytype' />" +
"<attribute name='rsa_securityrolemapping' />" +
        "<attribute name='rsa_form' />" +
        "<order attribute='rsa_name' descending='false' />" +
"<filter type='and'>" +
        "<condition attribute='rsa_activitytype'  operator='eq' value='" + taskType + "' />" +
"<condition attribute='rsa_securityrolemapping' operator='contain-values'>" + securityRoleMappingStr +
"</condition></filter>" +
        "<link-entity name='rsa_formlayout' from='rsa_formlayoutid' to='rsa_form' link-type='inner' alias='ae'>" +
        "<attribute name='rsa_formid'/>" +
        "<filter type='and'>" +
        "<condition attribute='rsa_entityname' operator='eq' value='866760002' />" +
        "</filter>" +
        "</link-entity>" +
        "</entity>" +
        "</fetch>";
    var req = new XMLHttpRequest();
    var globalContext = Xrm.Utility.getGlobalContext();
    var ClientUrl = globalContext.getClientUrl();
    req.open("GET", ClientUrl + "/api/data/v9.1/rsa_formlayoutmappings?fetchXml=" + encodeURIComponent(fetchXmlQuery), true);
    req.setRequestHeader("Prefer", 'odata.include-annotations="*"');
    req.onreadystatechange = function () {
        if (this.readyState === 4) {
            req.onreadystatechange = null;
            if (this.status === 200) {
                var results = JSON.parse(this.response);
                if (results.value.length > 0) {
                    formId = results.value[0]["ae.rsa_formid"];
                    tasktypeName = results.value[0]["_rsa_activitytype_value@OData.Community.Display.V1.FormattedValue"];
                    tasktypeId = results.value[0]["_rsa_activitytype_value"];

                    if (formId !== null) {
                        var entityFormOptions = {};
                        entityFormOptions["entityName"] = "task";
                        entityFormOptions["formId"] = formId;
                        entityFormOptions["entityId"] = formContext.data.entity.getId();

                    }

                    try {
                        var navigatedformId = formContext.ui.formSelector.getCurrentItem().getId();
                        if (navigatedformId.toLowerCase() === formId.toLowerCase()) {
                            return;
                        }
                    }
                    catch (err) {
                        Xrm.Navigation.openAlertDialog({ text: "rsa_taskformid -" + err.message });
                    }
                    //formContext.getAttribute("rsa_taskformid").setValue(formId);
                    //   formContext.data.entity.save();
                    var formParameters = {};
                    if (tasktypeName !== null && tasktypeId !== null) {
                        formParameters["rsa_targetactivityrecordtype"] = tasktypeId;
                        //formParameters["rsa_taskformid"] = formId;
                        formParameters["rsa_targetactivityrecordtypename"] = tasktypeName;
                        formParameters["rsa_targetactivityrecordtypetype"] = "rsa_tasktype";

                    }


                    // Open the form.
                    Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
                           function success(result) {

                               //formContext.getAttribute("rsa_taskformid").setValue(formId);
                               //   formContext.data.entity.save();
                           },
                           function (error) {
                               //console.log(error);
                           });
                }

            } else {
                Xrm.Navigation.openAlertDialog(this.statusText);
            }
        }
    };
    req.send();
}

function HideTaskButtonbasedonLOB(PrimaryControl) {
    var formContext = PrimaryControl;
    var LOB = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;

    if (LOB == "Renewal - Marine London" || LOB == "Renewal - Marine Regional")
        return true;
    else
        return false;
}
