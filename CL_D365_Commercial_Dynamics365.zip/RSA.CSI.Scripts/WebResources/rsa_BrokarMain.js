//Author : Pooja Raje
//This Function Open the Page According to Policy Type

function RedirectToPageLayoutBasedOnBrokerType(PrimaryControl, key) {
		var securityMap = new Array();
		var brokertype;
		var req = new XMLHttpRequest();
        var globalContext = Xrm.Utility.getGlobalContext();
        var ClientUrl = globalContext.getClientUrl();
		
				req.open("GET", ClientUrl + "/api/data/v9.1/rsa_customlabels?$select=rsa_dependentoptionsetjson,rsa_name&$filter=rsa_name eq 'SecurityRole'", false);
                req.setRequestHeader("OData-MaxVersion", "4.0");
                req.setRequestHeader("OData-Version", "4.0");
                req.setRequestHeader("Accept", "application/json");
                req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                req.onreadystatechange = function () {
                    if (this.readyState === 4) {
                        req.onreadystatechange = null;
                       if (this.status === 200) {
                            var results = JSON.parse(this.response);
                            for (var i = 0; i < results.value.length; i++) {
                                var rsa_categories = results.value[i]["rsa_categories"];
                                var rsa_dependentoptionsetjson = results.value[i]["rsa_dependentoptionsetjson"];
                                var SecurityRoleMapping = JSON.parse(results.value[i]["rsa_dependentoptionsetjson"]).SecurityRoleMapping;
								var roles = Xrm.Utility.getGlobalContext().userSettings.securityRoles;
								
								  for(var i=0; i < roles.length; i++ ){
									var GUID = Xrm.Utility.getGlobalContext().userSettings.securityRoles[i];
									SecurityRoleMapping.forEach(function (item) {
									if(item.SecurityRoleGUID.toLowerCase() == GUID.toLowerCase())
										securityMap.push(item.SecurityRoleValue);
									});
								}
							}
						}
                        else {
                            Xrm.Navigation.openAlertDialog({ text: "Get Security Role Mapping: " + this.statusText });
                        }
                    }
                };
                req.send();
				
				var securityRoleMappingStr = ''; 
				for(var k=0; k < securityMap.length; k++){
					securityRoleMappingStr += "<value>" + securityMap[k] + "</value>"
				}
	
    var formId, policytypeName, policytypeId;
    var fetchXmlQuery = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
        "<entity name='rsa_formlayoutmapping'>" +
        "<attribute name='rsa_formlayoutmappingid' />" +
        "<attribute name='rsa_name' />" +
        "<attribute name='rsa_brokertype' />" +    
        "<attribute name='rsa_form' />" +
        "<order attribute='rsa_name' descending='false' />" +
		"<filter type='and'>" +
        "<condition attribute='rsa_formidentifier' operator='eq' value='" + key + "' />" +
		"<condition attribute='rsa_securityrolemapping' operator='contain-values'>" + securityRoleMappingStr +
		"</condition></filter>" + 
        "<link-entity name='rsa_formlayout' from='rsa_formlayoutid' to='rsa_form' link-type='inner' alias='ae'>" +
        "<attribute name='rsa_formid'/>" +
        "<filter type='and'>" +       
        "<condition attribute='rsa_entityname' operator='eq' value='866760005' />" +
        "</filter>" +
        "</link-entity>" +
        "</entity>" +
        "</fetch>";
		
    var req = new XMLHttpRequest();
    var globalContext = Xrm.Utility.getGlobalContext();
    var ClientUrl = globalContext.getClientUrl();
    req.open("GET", ClientUrl + "/api/data/v9.1/rsa_formlayoutmappings?fetchXml=" + encodeURIComponent(fetchXmlQuery), true);
    req.setRequestHeader("Prefer", 'odata.include-annotations="*"');
    req.onreadystatechange = function () {
        if (this.readyState === 4) {
            req.onreadystatechange = null;
            if (this.status === 200) {
                var results = JSON.parse(this.response);
                if (results.value.length > 0) {
                    formId = results.value[0]["ae.rsa_formid"];
					brokertype = results.value[0]["rsa_brokertype"];

                    if (formId !== null) {
                        var entityFormOptions = {};
                        entityFormOptions["entityName"] = "account";
                        entityFormOptions["formId"] = formId;

                        var formParameters = {};
                        if (brokertype !== null) {                          
                            formParameters["rsa_brokertype"] = brokertype;	
                        }

                        // Open the form.
                        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
                            function (success) {
                                //console.log(success);
                            },
                            function (error) {
                                //console.log(error);
                            });
                    }
                }
            } else {
                Xrm.Navigation.openAlertDialog(this.statusText);
            }
        }
    };
    req.send();
}
  
/* Change Summary for April 2022 Release 1 */
/* Last Modified By: Shreya Diwate*/
/* Summary of Changes: Remove Debug Code*/
/* - Reason for Change: Unexpected 'debugger' statement */
/* - Function name - RedirectExistingToBrokerType */

function RedirectExistingToBrokerType(executionContext, triggerType) {
    //debugger;
	var formId, brokertypeName, brokertypeId;
    var formContext = executionContext.getFormContext();
	
	formId = formContext.getAttribute("rsa_brokerformid").getValue();
	if(triggerType != "onchange"){
	if(formId != null && formId != undefined){
		//formContext.getAttribute("rsa_brokerformid").setValue(null);
		return;
	}
	}
	    
    var brokerType = formContext.getAttribute("rsa_brokertype").getValue();
	if (brokerType === null){
        return; 
	}
    if (brokerType === null && formContext.ui.getFormType() === 2){
        return;
	}
	
	if(formContext.ui.getFormType() === 1 && triggerType != "onchange"){
		return;
	}
    
	//var brokerType = brokerTypevalue.getValue()[0].id;
    var securityMap = new Array();
    var req = new XMLHttpRequest();
    var globalContext = Xrm.Utility.getGlobalContext();
    var ClientUrl = globalContext.getClientUrl();
    req.open("GET", ClientUrl + "/api/data/v9.1/rsa_customlabels?$select=rsa_dependentoptionsetjson,rsa_name&$filter=rsa_name eq 'SecurityRole'", false);
    req.setRequestHeader("OData-MaxVersion", "4.0");
    req.setRequestHeader("OData-Version", "4.0");
    req.setRequestHeader("Accept", "application/json");
    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
    req.onreadystatechange = function () {
        if (this.readyState === 4) {
            req.onreadystatechange = null;
            if (this.status === 200) {
                var results = JSON.parse(this.response);
                for (var i = 0; i < results.value.length; i++) {
                    var rsa_categories = results.value[i]["rsa_categories"];
                    var rsa_dependentoptionsetjson = results.value[i]["rsa_dependentoptionsetjson"];
                    var SecurityRoleMapping = JSON.parse(results.value[i]["rsa_dependentoptionsetjson"]).SecurityRoleMapping;
                    var roles = Xrm.Utility.getGlobalContext().userSettings.securityRoles;
                    for (var i = 0; i < roles.length; i++) {
                        var GUID = Xrm.Utility.getGlobalContext().userSettings.securityRoles[i];
                        SecurityRoleMapping.forEach(function (item) {
                            if (item.SecurityRoleGUID.toLowerCase() == GUID.toLowerCase())
                                securityMap.push(item.SecurityRoleValue);
                        });
                    }
                }
            }
            else {
                Xrm.Navigation.openAlertDialog({ text: "Get Security Role Mapping: " + this.statusText });
            }
        }
    };
    req.send();
    var securityRoleMappingStr = '';
    for (var k = 0; k < securityMap.length; k++) {
        securityRoleMappingStr += "<value>" + securityMap[k] + "</value>"
    }

    
    var fetchXmlQuery = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
        "<entity name='rsa_formlayoutmapping'>" +
        "<attribute name='rsa_formlayoutmappingid' />" +
        "<attribute name='rsa_name' />" +
        "<attribute name='rsa_brokertype' />" +
"<attribute name='rsa_securityrolemapping' />" +
        "<attribute name='rsa_form' />" +
        "<order attribute='rsa_name' descending='false' />" +
"<filter type='and'>" +
        "<condition attribute='rsa_brokertype'  operator='eq' value='" + brokerType + "' />" +
"<condition attribute='rsa_securityrolemapping' operator='contain-values'>" + securityRoleMappingStr +
"</condition></filter>" +
        "<link-entity name='rsa_formlayout' from='rsa_formlayoutid' to='rsa_form' link-type='inner' alias='ae'>" +
        "<attribute name='rsa_formid'/>" +
        "<filter type='and'>" +
        "<condition attribute='rsa_entityname' operator='eq' value='866760005' />" +
        "</filter>" +
        "</link-entity>" +
        "</entity>" +
        "</fetch>";
    var req = new XMLHttpRequest();
    var globalContext = Xrm.Utility.getGlobalContext();
    var ClientUrl = globalContext.getClientUrl();
    req.open("GET", ClientUrl + "/api/data/v9.1/rsa_formlayoutmappings?fetchXml=" + encodeURIComponent(fetchXmlQuery), true);
    req.setRequestHeader("Prefer", 'odata.include-annotations="*"');
    req.onreadystatechange = function () {
        if (this.readyState === 4) {
            req.onreadystatechange = null;
            if (this.status === 200) {
                var results = JSON.parse(this.response);
                if (results.value.length > 0) {
                    formId = results.value[0]["ae.rsa_formid"];
                   brokertypeName = results.value[0]["_rsa_brokertype_value@OData.Community.Display.V1.FormattedValue"];
                    brokertypeId = results.value[0]["_rsa_brokertype_value"];

                    if (formId !== null) {
                        var entityFormOptions = {};
                        entityFormOptions["entityName"] = "account";
                        entityFormOptions["rsa_brokerformid"] = formId;
                        entityFormOptions["entityId"] = formContext.data.entity.getId();

                    }
                   // formContext.getAttribute("rsa_brokerformid").setValue(formId);
                 //   formContext.data.entity.save();
                     var formParameters = {};
                        if (brokertypeName !== null && brokertypeId !== null) {
                           // formParameters["rsa_brokertype"] = brokertypeId;
							 formParameters["rsa_brokerformid"] = formId;
                        }

                    // Open the form.
                    /*Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
                           function success(result) {

                            //  formContext.getAttribute("rsa_brokerformid").setValue(formId);
                            //   formContext.data.entity.save();
                           },
                           function (error) {
                               //console.log(error);
                           });
*/

if(formId==formContext.ui.formSelector.getCurrentItem().getId()){
								return;
							}
formContext.ui.formSelector.items.get(formId).navigate();
                }

            } else {
                Xrm.Navigation.openAlertDialog(this.statusText);
            }
        }
    };
    req.send();
}