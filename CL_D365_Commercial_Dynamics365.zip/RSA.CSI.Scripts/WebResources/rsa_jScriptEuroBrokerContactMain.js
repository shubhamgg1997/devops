"use strict";

var RSA = window.RSA || { __namespace: true, __typeName: "RSA" };
RSA.D365CRM = RSA.D365CRM || { __namespace: true, __typeName: "RSA.D365CRM" };
RSA.D365CRM.EuroBrokerContact = RSA.D365CRM.EuroBrokerContact || { __namespace: true, __typeName: "RSA.D365CRM.EuroBrokerContact" };
RSA.D365CRM.EuroBrokerContact.Main = RSA.D365CRM.EuroBrokerContact.Main || ({
    FormType: {
        Create: 1,
        Update: 2,
        ReadOnly: 3,
        Disabled: 4,
        BulkEdit: 6
    },
    OnLoad: function (executionContext) {
        var formContext = executionContext.getFormContext();

        if (formContext.ui.getFormType() === RSA.D365CRM.EuroBrokerContact.Main.FormType.Create) {

            //RSA.D365CRM.EuroBrokerContact.Main.CheckBranchOfBrokerContact(executionContext);

        }
        else if (formContext.ui.getFormType() === RSA.D365CRM.EuroBrokerContact.Main.FormType.Update) {



        }
        else if (formContext.ui.getFormType() === RSA.D365CRM.EuroBrokerContact.Main.FormType.Disabled) {



        }
        else if (formContext.ui.getFormType() === RSA.D365CRM.EuroBrokerContact.Main.FormType.BulkEdit) {



        }



    },
    OnSave: function (executionContext) {
    },


    //Author : Shreya Diwate
    //Date : 11 August 2020 
    //Function for Checking Branch Of Broker Contact

    CheckBranchOfBrokerContact: function (executionContext) {
        try {

            var formContext = executionContext.getFormContext();

            var userRoles = Xrm.Utility.getGlobalContext().userSettings;

            if (Object.keys(userRoles.roles._collection).length > 0) {

                for (var rolidcollection in userRoles.roles._collection) {

                    var currentUserRoles = Xrm.Utility.getGlobalContext().userSettings.roles._collection[rolidcollection].name;
                    if (currentUserRoles.indexOf("Belgium") !== -1) {
                        formContext.getAttribute("new_branch").setValue("Belgium");
                    }
                    else if (currentUserRoles.indexOf("France") !== -1) {
                        formContext.getAttribute("new_branch").setValue("France");
                    }
                    else if (currentUserRoles.indexOf("Netherlands") !== -1) {
                        formContext.getAttribute("new_branch").setValue("Netherlands");
                    }
                    else if (currentUserRoles.indexOf("Spain") !== -1) {
                        formContext.getAttribute("new_branch").setValue("Spain");
                    }
                    else {
                        formContext.getAttribute("new_branch").setValue("Error");
                    }

                }
            }
        }
        catch (e) {

            Xrm.Navigation.openAlertDialog({ text: "Error Message for Open Activity Is Mine : " + e.message });
        }
    }


});
