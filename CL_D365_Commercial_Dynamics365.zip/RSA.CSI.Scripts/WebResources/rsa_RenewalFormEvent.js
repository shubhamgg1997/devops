﻿"use strict";

var RSA = window.RSA || { __namespace: true, __typeName: "RSA" };
RSA.D365CRM = RSA.D365CRM || { __namespace: true, __typeName: "RSA.D365CRM" };
RSA.D365CRM.Renewal = RSA.D365CRM.Renewal || { __namespace: true, __typeName: "RSA.D365CRM.Renewal" };
RSA.D365CRM.Renewal.Main = RSA.D365CRM.Renewal.Main || ({
    FormType: {
        Create: 1,
        Update: 2,
        ReadOnly: 3,
        Disabled: 4,
        BulkEdit: 6
    },
    OnLoad: function (executionContext) {
        RSA.D365CRM.Renewal.Main.ShowHideControls(executionContext);
        RSA.D365CRM.Renewal.Main.MandatoryFields(executionContext);
        RSA.D365CRM.Renewal.Main.addFunctionToOnChange(executionContext);        
        RSA.D365CRM.Renewal.Main.setStatusReason(executionContext);       
        RSA.D365CRM.Renewal.Main.filterRenewals(executionContext);
        RSA.D365CRM.Renewal.Main.tatNotMetRenewals(executionContext);
        RSA.D365CRM.Renewal.Main.showHideOtherReasonText(executionContext);
        RSA.D365CRM.Renewal.Main.RenewalCOBValidation(executionContext);
        RSA.D365CRM.Renewal.Main.CalculateDiscountfromTechPrice(executionContext);
        RSA.D365CRM.Renewal.Main.ShowRBOReasonIfOffshoreUser(executionContext);
        RSA.D365CRM.Renewal.Main.onChangeRBOReason(executionContext);
        RSA.D365CRM.Renewal.Main.UnlockrsaFieldsForSecurityRole(executionContext);
        RSA.D365CRM.Renewal.Main.ExecuteallBusinessRuleonLoad(executionContext);

    },

    OnSave: function (executionContext) {       
        RSA.D365CRM.Renewal.Main.renewedpremiumbanding(executionContext);
        RSA.D365CRM.Renewal.Main.expiringpremiumbanding(executionContext);
        RSA.D365CRM.Renewal.Main.tatNotMetRenewals(executionContext);
        
    },

    ShowHideControls: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var formType = formContext.ui.getFormType();
        if (formType === RSA.D365CRM.Renewal.Main.FormType.Update) {
            formContext.getControl("rsa_renewalstatus").setDisabled(true);
        }
        else if (formType === RSA.D365CRM.Renewal.Main.FormType.BulkEdit) {
            formContext.getControl("rsa_renewalstatus").setDisabled(false);
        }
    },

    MandatoryFields: function (executionContext) {
        var formContext = executionContext.getFormContext();
        formContext.getAttribute("rsa_contact").setRequiredLevel("required");
        formContext.getAttribute("rsa_underwriter").setRequiredLevel("required");
        formContext.getAttribute("rsa_teamassignedto").setRequiredLevel("required");
        formContext.getAttribute("rsa_expirydate").setRequiredLevel("required");
    },

    ExecuteallBusinessRuleonLoad: function (executionContext) {
        RSA.D365CRM.Renewal.Main.agencyLookupChange(executionContext);
        RSA.D365CRM.Renewal.Main.renewalStatusCheck(executionContext);
        //RSA.D365CRM.Renewal.Main.addOptionStatusReason(executionContext);
        RSA.D365CRM.Renewal.Main.checkAddtoPipeline(executionContext);
    },
    addFunctionToOnChange: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var attributeAgency = formContext.getAttribute("rsa_agency");
        if (attributeAgency) {
            attributeAgency.addOnChange(function () {
                RSA.D365CRM.Renewal.Main.agencyLookupChange(executionContext);
            });
        }
        var attributeInActiveStatusReason = formContext.getAttribute("rsa_statusreason");
        if (attributeInActiveStatusReason) {
            attributeInActiveStatusReason.addOnChange(function () {
                RSA.D365CRM.Renewal.Main.renewalStatusCheck(executionContext);
            });
        }
        var attributeActiveStatusReason = formContext.getAttribute("rsa_renewalstatus");
        if (attributeActiveStatusReason) {
            attributeActiveStatusReason.addOnChange(function () {
                RSA.D365CRM.Renewal.Main.addOptionStatusReason(executionContext);
            });
        }
        var attributeAddedCaseToPipeLine = formContext.getAttribute("rsa_addtopipeline");
        if (attributeAddedCaseToPipeLine) {
            attributeAddedCaseToPipeLine.addOnChange(function () {
                RSA.D365CRM.Renewal.Main.checkAddtoPipeline(executionContext);
            });

            RSA.D365CRM.Renewal.Main.registerCheckboxClick("rsa_addtopipeline", executionContext);
        }

        var renewedPremium = formContext.getAttribute("brm_renewedpremium");
        if (renewedPremium) {
            renewedPremium.addOnChange(function () {
                RSA.D365CRM.Renewal.Main.calculateRateCarried(executionContext);
            });
        }
    },
    agencyLookupChange: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var agencyLookupItem = formContext.getAttribute("rsa_agency").getValue();
        if (agencyLookupItem != null) {
            var agencyGuid = agencyLookupItem[0].id;
            RSA.D365CRM.Renewal.Main.populateBroker(agencyGuid, executionContext);
        }
        else {
            formContext.getAttribute("rsa_brokernameid").setValue(null);
            formContext.getAttribute("rsa_brokernameid").setSubmitMode("always"); 
            formContext.getAttribute("rsa_bdmname").setValue(null);
            formContext.getAttribute("rsa_renewalowningregionid").setSubmitMode("always");
            formContext.getAttribute("rsa_renewalowningregionid").setValue(null);
            formContext.getAttribute("rsa_bdmname").setSubmitMode("always");
        }              
      
    },
    addOptionStatusReason: function (executionContext) {
        var formContext = executionContext.getFormContext();
        formContext.ui.controls.get("rsa_lapsedreason").setVisible(false);
        formContext.ui.controls.get("rsa_addtopipeline").setVisible(false);
        formContext.ui.controls.get("rsa_nextactiondate").setVisible(false);
        formContext.ui.controls.get("rsa_termsissuedon").setVisible(false);
        formContext.getAttribute("rsa_lapsedreason").setRequiredLevel("none");
        var formType = formContext.ui.getFormType();
        if (formType === RSA.D365CRM.Renewal.Main.FormType.Create) {
            var source = formContext.getAttribute("rsa_statusreason").getOptions();
            var renewalStatus = formContext.getAttribute("rsa_renewalstatus").getValue();
            if (renewalStatus == "866760000") {
                formContext.getAttribute("rsa_statusreason").setRequiredLevel("none");

                RSA.D365CRM.Renewal.Main.filterPickList(source, executionContext, [866760000, 866760001, 866760002, 866760003, 866760009, 866760010, 866760011, 866760012, 866760013, 866760014, 866760015]);
                formContext.getAttribute("rsa_statusreason").setValue(866760000);
            }
            else if (renewalStatus == "866760001") {
                formContext.getAttribute("rsa_statusreason").setRequiredLevel("required");

                RSA.D365CRM.Renewal.Main.filterPickList(source, executionContext, [866760004, 866760005, 866760006, 866760007, 866760008]);
            }
            else {
                formContext.ui.controls.get("rsa_statusreason").clearOptions();
            }
        }
        else {            
            var source = formContext.getAttribute("rsa_statusreason").getOptions();
            var statusReason = formContext.getAttribute("rsa_statusreason").getValue();
            var renewalStatus = formContext.getAttribute("rsa_renewalstatus").getValue();
            if (renewalStatus == "866760000") {
                formContext.getAttribute("rsa_statusreason").setRequiredLevel("none");                
                RSA.D365CRM.Renewal.Main.filterPickList(source, executionContext, [866760000, 866760001, 866760002, 866760003, 866760009, 866760010, 866760011, 866760012, 866760013, 866760014, 866760015]);                
                if (statusReason == 866760001 || statusReason == 866760002 || statusReason == 866760003 || statusReason == 866760009 || statusReason == 866760010 || statusReason == 866760011 || statusReason == 866760012 || statusReason == 866760013 || statusReason == 866760014 || statusReason == 866760015) {                    
                    formContext.getAttribute("rsa_statusreason").setValue(statusReason);                    
                }
                else {                    
                    formContext.getAttribute("rsa_statusreason").setValue(866760000);                    
                }                
            }
            else if (renewalStatus == "866760001") {
                formContext.getAttribute("rsa_statusreason").setRequiredLevel("required");

                RSA.D365CRM.Renewal.Main.filterPickList(source, executionContext, [866760004, 866760005, 866760006, 866760007, 866760008]);                
                formContext.getAttribute("rsa_statusreason").setValue(statusReason);               
            }
            else {
                formContext.ui.controls.get("rsa_statusreason").clearOptions();
            }
        }
        RSA.D365CRM.Renewal.Main.renewalStatusCheck(executionContext);
    },
    filterPickList: function (Pick, executionContext, arrDesiredOptions) {
        var formContext = executionContext.getFormContext();
        var length = Pick.length;
        var originalPicklistValues = Pick;
        var oTempArray = new Array();
        var i;
        var j;
        for (j = 0; j <= arrDesiredOptions.length - 1; j++) {
            for (i = 0; i <= length - 1; i++) {
                if (Pick[i].value == arrDesiredOptions[j]) {
                    oTempArray[i] = true;
                    break;
                }
            }
        }
        formContext.ui.controls.get("rsa_statusreason").clearOptions();
        formContext.ui.controls.get("header_rsa_statusreason").clearOptions();
        for (var z = 0; z < length - 1; z++) {
            formContext.ui.controls.get("rsa_statusreason").addOption(Pick[z], z);
            formContext.ui.controls.get("header_rsa_statusreason").addOption(Pick[z], z);
        }
        for (i = 0; i < length - 1; i++) {
            if (oTempArray[i] != true) {
                var choice = Pick[i].value;
                formContext.ui.controls.get("rsa_statusreason").removeOption(choice);
                formContext.ui.controls.get("header_rsa_statusreason").removeOption(choice);
            }
        }
        formContext.getAttribute("rsa_statusreason").setSubmitMode("always");
    },

    calculateRateCarried: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var renewedPremium = formContext.getAttribute("rsa_renewedpremium").getValue();
        var expiryPlusorMinus = formContext.getAttribute("rsa_expirypremiumplusorminusamendments").getValue();
        if (renewedPremium != null && expiryPlusorMinus != null && renewedPremium != 0 && expiryPlusorMinus != 0) {
            var rateCarryPercentage = ((renewedPremium - expiryPlusorMinus) / expiryPlusorMinus) * 100;
            Xrm.Page.getAttribute("rsa_ratecarried").setValue(rateCarryPercentage);
        }
        else {
            formContext.getAttribute("rsa_ratecarried").setValue(0);
        }
        formContext.getAttribute("rsa_ratecarried").setSubmitMode("always");
    },

    renewalStatusCheck: function (executionContext) {
        var formContext = executionContext.getFormContext();
        formContext.ui.controls.get("rsa_lapsedreason").setVisible(false);
        formContext.ui.controls.get("rsa_addtopipeline").setVisible(false);
        formContext.ui.controls.get("rsa_nextactiondate").setVisible(false);
        formContext.ui.controls.get("rsa_termsissuedon").setVisible(false);
        formContext.getAttribute("rsa_lapsedreason").setRequiredLevel("none");
        var renewalStatus = formContext.getAttribute("rsa_renewalstatus").getValue();
        if (renewalStatus == "866760000") {
            formContext.getAttribute("rsa_statusreason").setRequiredLevel("none");
            var activeStatusReason = formContext.getAttribute("rsa_statusreason").getValue();
            if (activeStatusReason == "866760003") {//Terms issued
                formContext.ui.controls.get("rsa_termsissuedon").setVisible(true);
                formContext.ui.controls.get("rsa_termsissuedon").setDisabled(false);
                var termsissuedon = formContext.getAttribute("rsa_termsissuedon").getValue();
                if (termsissuedon == null) {
                    formContext.getAttribute("rsa_termsissuedon").setValue(new Date());
                }
            }
            else {
                formContext.ui.controls.get("rsa_termsissuedon").setVisible(false);
                formContext.getAttribute("rsa_termsissuedon").setValue(null);
                formContext.ui.controls.get("rsa_termsissuedon").setDisabled(true);
            }
            formContext.ui.controls.get("rsa_lapsedfirmrenewallostto").setVisible(false);
            formContext.ui.controls.get("rsa_caserenewedat").setVisible(false);
        }
        else if (renewalStatus == "866760001") {//"InActive"
            formContext.getAttribute("rsa_statusreason").setRequiredLevel("required");
            var inActiveStatusReason = formContext.getAttribute("rsa_statusreason").getValue();
            if (inActiveStatusReason == "866760006" || inActiveStatusReason == "866760005") {//"Lapsed" and Mid Term Cancellation
                formContext.ui.controls.get("rsa_lapsedreason").setVisible(true);
                formContext.getAttribute("rsa_lapsedreason").setRequiredLevel("required");
                formContext.ui.controls.get("rsa_addtopipeline").setVisible(true);
                RSA.D365CRM.Renewal.Main.checkAddtoPipeline(executionContext);
                if (inActiveStatusReason == "866760006") {
                   formContext.ui.controls.get("rsa_lapsedfirmrenewallostto").setVisible(true);
                    formContext.ui.controls.get("rsa_caserenewedat").setVisible(true);
                }
                else {
                    formContext.ui.controls.get("rsa_lapsedfirmrenewallostto").setVisible(false);
                    formContext.ui.controls.get("rsa_caserenewedat").setVisible(false);
                }
            }
            else {
                formContext.ui.controls.get("rsa_lapsedreason").setVisible(false);
                formContext.getAttribute("rsa_lapsedreason").setRequiredLevel("none");
                formContext.ui.controls.get("rsa_addtopipeline").setVisible(false);
                formContext.getAttribute("rsa_lapsedreason").setValue(null);
                formContext.ui.controls.get("rsa_lapsedfirmrenewallostto").setVisible(false);
                formContext.ui.controls.get("rsa_caserenewedat").setVisible(false);
            }
        }
        else {
            formContext.ui.controls.get("rsa_lapsedreason").setVisible(false);
            formContext.ui.controls.get("rsa_addtopipeline").setVisible(false);
            formContext.ui.controls.get("rsa_nextactiondate").setVisible(false);
            formContext.ui.controls.get("rsa_termsissuedon").setVisible(false);
            formContext.getAttribute("rsa_lapsedreason").setValue(null);
            formContext.ui.controls.get("rsa_lapsedfirmrenewallostto").setVisible(false);
            formContext.ui.controls.get("rsa_caserenewedat").setVisible(false);
        }
        RSA.D365CRM.Renewal.Main.AutoPopulateDate(executionContext);
    },

    checkAddtoPipeline: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var addedCaseToPipeLine = formContext.getAttribute("rsa_addtopipeline").getValue();
        if (addedCaseToPipeLine == true) {
            formContext.ui.controls.get("rsa_nextactiondate").setVisible(true);
        }
        else {
            formContext.ui.controls.get("rsa_nextactiondate").setVisible(false);
        }
    },

    registerCheckboxClick: function (attr,executionContext) {
        var formContext = executionContext.getFormContext();
        formContext.getAttribute(attr).fireOnChange();
    },
    populateBroker: function (agencyId, executionContext) {
        var formContext = executionContext.getFormContext();
        var branchName = null;
        Xrm.WebApi.online.retrieveRecord("account", agencyId).then(
            function (result) {
                if (result._rsa_parentid_value != null) {
                    var brokerLookup = new Array();
                    brokerLookup[0] = new Object();
                    brokerLookup[0].id = result["_rsa_parentid_value"];
                    brokerLookup[0].name = result["_rsa_parentid_value@OData.Community.Display.V1.FormattedValue"];
                    brokerLookup[0].entityType = result["_rsa_parentid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                    branchName = result["rsa_branch@OData.Community.Display.V1.FormattedValue"];
                    formContext.getAttribute("rsa_brokernameid").setValue(brokerLookup);
                    formContext.getAttribute("rsa_brokernameid").setSubmitMode("always");
                    if (branchName != null) {
                        var req = new XMLHttpRequest();
                        var globalContext = Xrm.Utility.getGlobalContext();
                        var ClientUrl = globalContext.getClientUrl();
                        req.open("GET", ClientUrl + "/api/data/v9.1/rsa_regions?$filter=" + encodeURIComponent("rsa_name eq '" + branchName + "'"), false);
                        req.setRequestHeader("OData-MaxVersion", "4.0");
                        req.setRequestHeader("OData-Version", "4.0");
                        req.setRequestHeader("Accept", "application/json");
                        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                        req.onreadystatechange = function () {
                            if (this.readyState === 4) {
                                req.onreadystatechange = null;
                                if (this.status === 200) {
                                    var results = JSON.parse(this.response);
                                    if (results) {
                                        var lookupRegion = new Array();
                                        lookupRegion[0] = new Object();
                                        lookupRegion[0].id = results.value[0]["rsa_regionid"];
                                        lookupRegion[0].name = results.value[0]["rsa_name"];
                                        lookupRegion[0].entityType = "rsa_region";
                                        formContext.getAttribute("rsa_renewalowningregionid").setValue(lookupRegion);
                                        formContext.getAttribute("rsa_renewalowningregionid").setSubmitMode("always");
                                    }
                                    else {
                                        formContext.getAttribute("rsa_renewalowningregionid").setValue(null);
                                        formContext.getAttribute("rsa_renewalowningregionid").setSubmitMode("always");
                                    }

                                }
                                else {
                                    formContext.getAttribute("rsa_renewalowningregionid").setValue(null);
                                    formContext.getAttribute("rsa_renewalowningregionid").setSubmitMode("always");
                                }
                            }
                        };
                        req.send();
                    }
                    else {
                        formContext.getAttribute("rsa_renewalowningregionid").setValue(null);
                        formContext.getAttribute("rsa_renewalowningregionid").setSubmitMode("always");
                        errorHandler("Issue in API");
                    }
                }
                else {
                    formContext.getAttribute("rsa_brokernameid").setValue(null);
                    formContext.getAttribute("rsa_brokernameid").setSubmitMode("always");
                }
            },
            function (error) {
                errorHandler(error);
            }
        );

        if (agencyId != null) {
            var req = new XMLHttpRequest();
            var globalContext = Xrm.Utility.getGlobalContext();
            var ClientUrl = globalContext.getClientUrl();
            req.open("GET", ClientUrl + "/api/data/v9.1/connectionroles?$select=connectionroleid&$filter=" + encodeURIComponent("name eq 'BDM'"), false);
            req.setRequestHeader("OData-MaxVersion", "4.0");
            req.setRequestHeader("OData-Version", "4.0");
            req.setRequestHeader("Accept", "application/json");
            req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
            req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            req.onreadystatechange = function () {
                if (this.readyState === 4) {
                    req.onreadystatechange = null;
                    if (this.status === 200) {
                        var results = JSON.parse(this.response);
                        if (results) {
                            var connectionRoleID = results.value[0]["connectionroleid"];
                            RSA.D365CRM.Renewal.Main.BDMLooupSync(executionContext, agencyId, connectionRoleID);
                        }
                        else {
                            formContext.getAttribute("rsa_bdmname").setValue(null);
                            formContext.getAttribute("rsa_bdmname").setSubmitMode("always");
                        }
                       
                    }
                    else {
                        formContext.getAttribute("rsa_bdmname").setValue(null);
                        formContext.getAttribute("rsa_bdmname").setSubmitMode("always");
                        errorHandler("Issue in API");
                    }
                }
            };
            req.send();           
        }
       
    },

    BDMLooupSync: function (executionContext, agencyid, connectionroleid) {
        var agencyId = agencyid;
        var connectionroleId = connectionroleid ;
        var formContext = executionContext.getFormContext();
        var req1 = new XMLHttpRequest();
        var globalContext = Xrm.Utility.getGlobalContext();
        var ClientUrl = globalContext.getClientUrl();
        //req1.open("GET", ClientUrl + "/api/data/v9.1/connections?$filter=_record1id_value eq '1464df28-50cf-f011-8544-000d3a86b82a' and _record2roleid_value eq '7E0BB681-A014-EC11-B6E6-000D3ADC1A72'", false);
        req1.open("GET", ClientUrl + "/api/data/v9.1/connections?$filter=" + encodeURIComponent("_record1id_value  eq '" + agencyId + "' and _record2roleid_value eq '" + connectionroleId + "'"), false);
        req1.setRequestHeader("OData-MaxVersion", "4.0");
        req1.setRequestHeader("OData-Version", "4.0");
        req1.setRequestHeader("Accept", "application/json");
        req1.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req1.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
        req1.onreadystatechange = function () {
            if (this.readyState === 4) {
                req1.onreadystatechange = null;
                if (this.status === 200) {
                    var results1 = JSON.parse(this.response);
                    if (results1) {
                        var BDMLookup = new Array();
                        BDMLookup[0] = new Object();
                        BDMLookup[0].id = results1.value[0]["_record2id_value"];
                        BDMLookup[0].name = results1.value[0]["_record2id_value@OData.Community.Display.V1.FormattedValue"];
                        BDMLookup[0].entityType = "systemuser";
                        formContext.getAttribute("rsa_bdmname").setValue(BDMLookup);
                        formContext.getAttribute("rsa_bdmname").setSubmitMode("always");
                    }
                    else {
                        formContext.getAttribute("rsa_bdmname").setValue(null);
                        formContext.getAttribute("rsa_bdmname").setSubmitMode("always");
                    }
                }
                else {
                    formContext.getAttribute("rsa_bdmname").setValue(null);
                    formContext.getAttribute("rsa_bdmname").setSubmitMode("always");
                    errorHandler("Issue in API");
                }
            }
        }
        req1.send();
    },
    errorHandler: function (error) {
        alert("Error:=" + error.message);
    },
    

    AutoPopulateDate: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var statusReasonOptions = formContext.getAttribute("rsa_statusreason").getValue();
        if (statusReasonOptions == "866760004") {
            formContext.getAttribute("rsa_renewedstatusdate").setValue(new Date());
            formContext.getAttribute("rsa_renewedstatusdate").setSubmitMode("always");
            formContext.getAttribute("rsa_notstarteddate").setValue(null);
            formContext.getAttribute("rsa_inprogressdate").setValue(null);
            formContext.getAttribute("rsa_awaitinginformationdate").setValue(null);
            formContext.getAttribute("rsa_declineddate").setValue(null);
            formContext.getAttribute("rsa_lapseddate").setValue(null);

        }
        else if (statusReasonOptions == "866760000") {
            formContext.getAttribute("rsa_notstarteddate").setValue(new Date());
            formContext.getAttribute("rsa_notstarteddate").setSubmitMode("always");

            formContext.getAttribute("rsa_renewedstatusdate").setValue(null);
            formContext.getAttribute("rsa_inprogressdate").setValue(null);
            formContext.getAttribute("rsa_awaitinginformationdate").setValue(null);
            formContext.getAttribute("rsa_declineddate").setValue(null);
            formContext.getAttribute("rsa_lapseddate").setValue(null);
        }
        else if (statusReasonOptions == "866760001") {
            formContext.getAttribute("rsa_inprogressdate").setValue(new Date());
            formContext.getAttribute("rsa_inprogressdate").setSubmitMode("always");

            formContext.getAttribute("rsa_renewedstatusdate").setValue(null);
            formContext.getAttribute("rsa_notstarteddate").setValue(null);
            formContext.getAttribute("rsa_awaitinginformationdate").setValue(null);
            formContext.getAttribute("rsa_declineddate").setValue(null);
            formContext.getAttribute("rsa_lapseddate").setValue(null);
        }
        else if (statusReasonOptions == "866760002") {
            formContext.getAttribute("rsa_awaitinginformationdate").setValue(new Date());
            formContext.getAttribute("rsa_awaitinginformationdate").setSubmitMode("always");

            formContext.getAttribute("rsa_renewedstatusdate").setValue(null);
            formContext.getAttribute("rsa_notstarteddate").setValue(null);
            formContext.getAttribute("rsa_inprogressdate").setValue(null);
            formContext.getAttribute("rsa_declineddate").setValue(null);
            formContext.getAttribute("rsa_lapseddate").setValue(null);
        }
        else if (statusReasonOptions == "866760007") {
            formContext.getAttribute("rsa_declineddate").setValue(new Date());
            formContext.getAttribute("rsa_declineddate").setSubmitMode("always");

            formContext.getAttribute("rsa_renewedstatusdate").setValue(null);
            formContext.getAttribute("rsa_notstarteddate").setValue(null);
            formContext.getAttribute("rsa_inprogressdate").setValue(null);
            formContext.getAttribute("rsa_awaitinginformationdate").setValue(null);
            formContext.getAttribute("rsa_lapseddate").setValue(null);
        }
        else if (statusReasonOptions == "866760006") {
            formContext.getAttribute("rsa_lapseddate").setValue(new Date());
            formContext.getAttribute("rsa_lapseddate").setSubmitMode("always");

            formContext.getAttribute("rsa_renewedstatusdate").setValue(null);
            formContext.getAttribute("rsa_notstarteddate").setValue(null);
            formContext.getAttribute("rsa_inprogressdate").setValue(null);
            formContext.getAttribute("rsa_awaitinginformationdate").setValue(null);
            formContext.getAttribute("rsa_declineddate").setValue(null);
        }
        else {
            formContext.getAttribute("rsa_renewedstatusdate").setValue(null);
            formContext.getAttribute("rsa_notstarteddate").setValue(null);
            formContext.getAttribute("rsa_inprogressdate").setValue(null);
            formContext.getAttribute("rsa_awaitinginformationdate").setValue(null);
            formContext.getAttribute("rsa_declineddate").setValue(null);
            formContext.getAttribute("rsa_lapseddate").setValue(null);
        }
    },

    setStatusReason: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var renewalStatus = formContext.getAttribute("rsa_renewalstatus").getValue();
        if (renewalStatus == "866760000") {//"Active"

            var statusReason = formContext.getAttribute("rsa_statusreason").getValue();
            if (statusReason == null || statusReason == 866760000) {             
                formContext.getAttribute("rsa_statusreason").setValue(866760000);                
            }

        }
    },

    filterRenewals: function (executionContext) {
       // var formContext = executionContext.getFormContext();
       //// var subGirdRenewal = document.getElementById("AssociatedClientAllRenewalsSubGrid");
       // var clientLookup = formContext.getAttribute("rsa_insured").getValue();
       // //if (subGirdRenewal == null) { //make sure the grid has loaded 
       // //    setTimeout(function () { filterRenewals(); }, 1000); //if the grid hasn’t loaded run this again when it has 
       // //    return;
       // //}
       // if (clientLookup != null) {
       //     formContext.ui.tabs.get("AssociatedClientAllRenewalsTab").setVisible(true);
       //     var fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
       //         "<entity name='rsa_renewal'>" +
       //         "<attribute name='rsa_underwritern' />" +
       //         "<attribute name='rsa_renewalstatus' />" +
       //         "<attribute name='rsa_renewaldate' />" +
       //         "<attribute name='rsa_policynumber' />" +
       //         "<attribute name='rsa_insured' />" +
       //         "<attribute name='rsa_expirypremium' />" +
       //         "<attribute name='rsa_brokernameid' />" +
       //         "<attribute name='rsa_statusreason' />" +
       //         "<attribute name='rsa_renewalcob' />" +
       //         "<attribute name='rsa_businessdescription' />" +
       //         "<attribute name='rsa_renewaltype' />" +
       //         "<attribute name='rsa_teamassignedto' />" +
       //         "<attribute name='ownerid' />" +
       //         "<attribute name='rsa_stopcode' />" +
       //         "<attribute name='rsa_checkcodes' />" +             
       //         "<attribute name='rsa_renewalowningregionid' />" +
       //         "<attribute name='rsa_renewalid' />" +
       //         "<order attribute='rsa_renewalstatus' descending='false' />" +
       //         "<order attribute='rsa_renewaldate' descending='false' />" +
       //         "<filter type='and'>" +
       //         "<condition attribute='statecode' operator='in'>" +
       //         "<value>0</value>" +
       //         "<value>1</value>" +
       //         "</condition>" +
       //         "      <condition attribute='rsa_insured' operator='eq' value='" + clientLookup[0].id + "' />" +
       //         "</filter>" +
       //         "</entity>" +
       //         "</fetch>";

       //     subGirdRenewal.control.SetParameter("fetchXml", fetchXml);
       // }
       // else {
       //    // formContext.ui.tabs.get("AssociatedClientAllRenewalsTab").setVisible(false);
       // }
    },

    policyOnChange: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var policyLookupValue = formContext.getAttribute("rsa_policynumber").getValue();
        if (policyLookupValue != null && policyLookupValue != "") {
            var policyLookupId = policyLookupValue[0].id;
            retrievePolicyValues(policyLookupId,executionContext);
        }
    },

    retrievePolicyValues: function (PolicyID, executionContext) {
        var formContext = executionContext.getFormContext();
        SDK.JQuery.retrieveRecord(
            PolicyID,
            "rsa_policy",
            null, null,
            function (policy) {
                if (policy.rsa_Client.Id != null) {
                    var lookupClient = new Array();
                    lookupClient[0] = new Object();
                    lookupClient[0].id = policy.rsa_customer.Id;
                    lookupClient[0].name = policy.rsa_customer.Name;
                    lookupClient[0].entityType = policy.rsa_customer.LogicalName;
                    formContext.getAttribute("rsa_insured").setValue(lookupClient);
                }
                else {
                    formContext.getAttribute("rsa_insured").setValue(null);
                }
                formContext.getAttribute("rsa_insured").fireOnChange();
            },
            errorHandler
        );
    },

    AutoPopulateAssumptionsConfirmedOn: function (executionContext) {
        var formContext = executionContext.getFormContext();
        if (formContext.getAttribute("rsa_assumptionsconfirmed") != null) {
            var assumptionsconfirmed = formContext.getAttribute("rsa_assumptionsconfirmed").getValue();
            if (assumptionsconfirmed == "1") {
                if (formContext.getAttribute("rsa_assumptionsconfirmedon") != null) {
                    formContext.getAttribute("rsa_assumptionsconfirmedon").setValue(new Date());
                    formContext.getAttribute("rsa_assumptionsconfirmedon").setSubmitMode("always");
                }
            }
            else {
                if (formContext.getAttribute("rsa_assumptionsconfirmedon") != null) {
                    formContext.getAttribute("rsa_assumptionsconfirmedon").setValue(null);
                    formContext.getAttribute("rsa_assumptionsconfirmedon").setSubmitMode("always");
                }
            }
        }
    },

    AutoPopulateinformationrecievedOn: function (executionContext) {
        var formContext = executionContext.getFormContext();
        if (formContext.getAttribute("rsa_informationrecieved") != null) {
            var informationrecieved = formContext.getAttribute("rsa_informationrecieved").getValue();
            if (informationrecieved == "1") {
                if (formContext.getAttribute("rsa_informationrecievedon") != null) {
                    formContext.getAttribute("rsa_informationrecievedon").setValue(new Date());
                    formContext.getAttribute("rsa_informationrecievedon").setSubmitMode("always");
                }
            }
            else {
                if (formContext.getAttribute("rsa_informationrecievedon") != null) {
                    formContext.getAttribute("rsa_informationrecievedon").setValue(null);
                }
            }
        }
    },

    tatNotMetRenewals: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var StatusReason = formContext.data.entity.attributes.get("rsa_statusreason").getValue();
        if (StatusReason != null) {
            if (StatusReason == "866760001" || StatusReason == "866760009") {
                var RequiredOnDate = formContext.data.entity.attributes.get("rsa_actionrequiredon").getValue();
                var OffshorePreppedDate = formContext.data.entity.attributes.get("rsa_offshorepreppeddate").getValue();
                if (OffshorePreppedDate == null) {
                    var NewOfshorePreppedDate = new Date();
                    formContext.getAttribute("rsa_offshorepreppeddate").setValue(NewOfshorePreppedDate);
                    formContext.getAttribute("rsa_offshorepreppeddate").setSubmitMode("always");

                    var teamassignedtoid = formContext.data.entity.attributes.get("rsa_teamassignedto");
                    if (teamassignedtoid.getValue() != null) {
                        var entityId = teamassignedtoid.getValue()[0].id;
                        var entityLabel = teamassignedtoid.getValue()[0].name;
                        if (entityLabel == "INDIA EB" || entityLabel == "BRITERFORD" || entityLabel == "STONEARM" || entityLabel == "BRISLON" || entityLabel == "MANGOLEE" || entityLabel == "INDIA NB" || entityLabel == "Noida Clerical" || entityLabel == "Pune Clerical" || entityLabel == "Offshore Peterborough" || entityLabel == "Offshore QT Team_Noida" || entityLabel == "Offshore QT Team_Pune") {

                            var dd = NewOfshorePreppedDate.getDate();
                            var mm = NewOfshorePreppedDate.getMonth();
                            var yy = NewOfshorePreppedDate.getFullYear();
                            var NewOffPreppedDate = new Date(yy, mm, dd);

                            if (NewOffPreppedDate <= RequiredOnDate) {
                                formContext.getControl("rsa_tatmet").setVisible(true);
                                formContext.getAttribute("rsa_tatmet").setValue(true);
                                formContext.getAttribute("rsa_tatmet").setSubmitMode("always");
                                formContext.getControl("rsa_tatnotmetreasons").setVisible(false);
                                formContext.getControl("rsa_offshorepreppeddate").setVisible(true);

                                formContext.getControl("rsa_tatnotmetotherreason").setVisible(false);
                                formContext.getAttribute("rsa_tatnotmetotherreason").setValue("");
                                formContext.getAttribute("rsa_tatnotmetotherreason").setRequiredLevel("none");
                                formContext.getAttribute("rsa_tatnotmetotherreason").setRequiredLevel("none");
                                formContext.getAttribute("rsa_tatnotmetotherreason").setSubmitMode("always");
                            }
                            else if (NewOffPreppedDate > RequiredOnDate) {
                                //clearTatNotMetReasons();
                                formContext.getControl("rsa_tatmet").setVisible(true);
                                formContext.getAttribute("rsa_tatmet").setValue(false);
                                formContext.getAttribute("rsa_tatmet").setSubmitMode("always");
                                formContext.getControl("rsa_tatnotmetreasons").setVisible(true);
                                formContext.getAttribute("rsa_tatnotmetreasons").getSelectedOption();
                                formContext.getAttribute("rsa_tatnotmetreasons").setRequiredLevel("required");
                                formContext.getAttribute("rsa_tatnotmetreasons").setSubmitMode("always");
                                formContext.getControl("rsa_offshorepreppeddate").setVisible(true);
                                // Xrm.Paga.ui.controls.get("rsa_offshorepreppeddate").setDisabled(true);
                            }
                            formContext.getControl("rsa_tatmet").setVisible(true);
                            formContext.data.entity.attributes.get("rsa_tatmet").setSubmitMode("always");
                            formContext.data.entity.attributes.get("rsa_tatnotmetreasons").setSubmitMode("always");
                        }
                        else {
                            formContext.getControl("rsa_offshorepreppeddate").setVisible(false);

                            formContext.getControl("rsa_tatmet").setVisible(false);
                            formContext.getAttribute("rsa_tatmet").setValue(null);
                            formContext.getAttribute("rsa_tatmet").setSubmitMode("always");

                            formContext.getControl("rsa_tatnotmetreasons").setVisible(false);
                            formContext.getAttribute("rsa_tatnotmetreasons").setValue("");
                            formContext.getAttribute("rsa_tatnotmetreasons").setRequiredLevel("none");
                            formContext.getAttribute("rsa_tatnotmetreasons").setSubmitMode("always");

                            formContext.getControl("rsa_tatnotmetotherreason").setVisible(false);
                            formContext.getAttribute("rsa_tatnotmetotherreason").setValue("");
                            formContext.getAttribute("rsa_tatnotmetotherreason").setRequiredLevel("none");
                            formContext.getAttribute("rsa_tatnotmetotherreason").setSubmitMode("always");
                        }
                    }
                }
                else {
                    var teamassignedtoid = formContext.data.entity.attributes.get("rsa_teamassignedto");
                    if (teamassignedtoid.getValue() != null) {
                        var entityId = teamassignedtoid.getValue()[0].id;
                        var entityLabel = teamassignedtoid.getValue()[0].name;
                        if (entityLabel == "INDIA EB" || entityLabel == "BRITERFORD" || entityLabel == "STONEARM" || entityLabel == "BRISLON" || entityLabel == "MANGOLEE" || entityLabel == "INDIA NB" || entityLabel == "Noida Clerical" || entityLabel == "Pune Clerical" || entityLabel == "Offshore Peterborough" || entityLabel == "Offshore QT Team_Noida" || entityLabel == "Offshore QT Team_Pune") {

                            var dd = OffshorePreppedDate.getDate();
                            var mm = OffshorePreppedDate.getMonth();
                            var yy = OffshorePreppedDate.getFullYear();
                            var NewOffPreppedDate = new Date(yy, mm, dd);

                            if (NewOffPreppedDate <= RequiredOnDate) {
                                formContext.getControl("rsa_tatmet").setVisible(true);
                                formContext.getAttribute("rsa_tatmet").setValue(true);
                                formContext.getAttribute("rsa_tatmet").setSubmitMode("always");

                                formContext.getControl("rsa_tatnotmetreasons").setVisible(false);
                                formContext.getAttribute("rsa_tatnotmetreasons").setValue("");
                                formContext.getAttribute("rsa_tatnotmetreasons").setRequiredLevel("none");
                                formContext.getAttribute("rsa_tatnotmetreasons").setSubmitMode("always");

                                formContext.getControl("rsa_offshorepreppeddate").setVisible(true);

                                formContext.getControl("rsa_tatnotmetotherreason").setVisible(false);
                                formContext.getAttribute("rsa_tatnotmetotherreason").setValue("");
                                formContext.getAttribute("rsa_tatnotmetotherreason").setRequiredLevel("none");
                                formContext.getAttribute("rsa_tatnotmetotherreason").setSubmitMode("always");
                            }
                            else if (NewOffPreppedDate > RequiredOnDate) {
                                //clearTatNotMetReasons();
                                formContext.getControl("rsa_tatmet").setVisible(true);
                                formContext.getAttribute("rsa_tatmet").setValue(false);
                                formContext.getAttribute("rsa_tatmet").setSubmitMode("always");
                                formContext.getControl("rsa_tatnotmetreasons").setVisible(true);
                                formContext.getAttribute("rsa_tatnotmetreasons").getSelectedOption();
                                formContext.getAttribute("rsa_tatnotmetreasons").setRequiredLevel("required");
                                formContext.getAttribute("rsa_tatnotmetreasons").setSubmitMode("always");
                                formContext.getControl("rsa_offshorepreppeddate").setVisible(true);
                                // Xrm.Paga.ui.controls.get("rsa_offshorepreppeddate").setDisabled(true);
                            }
                            formContext.getControl("rsa_tatmet").setVisible(true);
                            formContext.data.entity.attributes.get("rsa_tatmet").setSubmitMode("always");
                            formContext.data.entity.attributes.get("rsa_tatnotmetreasons").setSubmitMode("always");
                        }
                        else {
                            formContext.getControl("rsa_tatmet").setVisible(false);
                            formContext.getAttribute("rsa_tatmet").setValue(null);
                            formContext.getAttribute("rsa_tatmet").setSubmitMode("always");

                            formContext.getControl("rsa_tatnotmetreasons").setVisible(false);
                            formContext.getAttribute("rsa_tatnotmetreasons").setValue("");
                            formContext.getAttribute("rsa_tatnotmetreasons").setRequiredLevel("none");
                            formContext.getAttribute("rsa_tatnotmetreasons").setSubmitMode("always");

                            formContext.getControl("rsa_tatnotmetotherreason").setVisible(false);
                            formContext.getAttribute("rsa_tatnotmetotherreason").setValue("");
                            formContext.getAttribute("rsa_tatnotmetotherreason").setRequiredLevel("none");
                            formContext.getAttribute("rsa_tatnotmetotherreason").setSubmitMode("always");

                            formContext.getControl("rsa_offshorepreppeddate").setVisible(false);
                        }
                    }
                }
            }
            else {
                formContext.getControl("rsa_offshorepreppeddate").setVisible(false);
                formContext.getAttribute("rsa_offshorepreppeddate").setSubmitMode("always");

                formContext.getControl("rsa_tatmet").setVisible(false);
                formContext.getAttribute("rsa_tatmet").setSubmitMode("always");
                formContext.getAttribute("rsa_tatmet").setValue(null);

                formContext.getControl("rsa_tatnotmetreasons").setVisible(false);
                formContext.getAttribute("rsa_tatnotmetreasons").setRequiredLevel("none");
                formContext.getAttribute("rsa_tatnotmetreasons").setSubmitMode("always");
                formContext.getAttribute("rsa_tatnotmetreasons").setValue(null);

                formContext.getControl("rsa_tatnotmetotherreason").setVisible(false);
                formContext.getAttribute("rsa_tatnotmetotherreason").setValue("");
                formContext.getAttribute("rsa_tatnotmetotherreason").setRequiredLevel("none");
                formContext.getAttribute("rsa_tatnotmetotherreason").setSubmitMode("always");
            }
        }

    },
    showHideOtherReasonText: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var tatNotMet = formContext.getAttribute('rsa_tatmet').getValue();
        var tatNotMetReason = formContext.getAttribute('rsa_tatnotmetreasons').getValue();
        if (!tatNotMet) {
            if (tatNotMetReason == "866760010" || tatNotMetReason == "866760007") {
                formContext.getControl("rsa_tatnotmetotherreason").setVisible(true);
                formContext.getAttribute("rsa_tatnotmetotherreason").setRequiredLevel("required");
                formContext.getAttribute("rsa_tatnotmetotherreason").setSubmitMode("always");
            }
            else {
                formContext.getControl("rsa_tatnotmetotherreason").setVisible(false);
                formContext.getAttribute("rsa_tatnotmetotherreason").setValue("");
                formContext.getAttribute("rsa_tatnotmetotherreason").setRequiredLevel("none");
                formContext.getAttribute("rsa_tatnotmetotherreason").setSubmitMode("always");
            }
        }
        else {
            formContext.getControl("rsa_tatnotmetotherreason").setVisible(false);
            formContext.getAttribute("rsa_tatnotmetotherreason").setValue("");
            formContext.getAttribute("rsa_tatnotmetotherreason").setRequiredLevel("none");
            formContext.getAttribute("rsa_tatnotmetotherreason").setRequiredLevel("none");
            formContext.getAttribute("rsa_tatnotmetotherreason").setSubmitMode("always");
        }
    },

    RenewalCOBValidation: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var statusReason = formContext.getAttribute("rsa_statusreason").getValue();
        //if statusReason = terms issued or renewal-prepped make the following fields required.
        if (statusReason != null) {
            if (statusReason == "866760000" || statusReason == "866760012") {
                var COBLookupValue = formContext.getAttribute("rsa_product").getValue();
                if (COBLookupValue != null && COBLookupValue != "") {
                    RSA.D365CRM.Renewal.Main.applyValidation(COBLookupValue[0].id, executionContext);
                }
            }
            else {
                RSA.D365CRM.Renewal.Main.DisableCOBValidation(executionContext);
            }
        }
    },

    applyValidation: function (COBLookupId, executionContext) {
        Xrm.WebApi.online.retrieveRecord("rsa_product", COBLookupId).then(
            function (result) {
                if (result._rsa_classofbusinessid_value != null) {
                    var CobName = result["_rsa_classofbusinessid_value@OData.Community.Display.V1.FormattedValue"];
                    if (CobName === "Motor Fleet") {
                        RSA.D365CRM.Renewal.Main.EnableCOBValidation(executionContext);
                    }
                }
            }
        );
        //SDK.JQuery.retrieveRecord(
        //    COBLookupId,
        //    "rsa_product",
        //    null, null,
        //    function (cob) {
        //        if (cob.rsa_classofbusinessid.Id != null) {
        //            if (cob.rsa_classofbusinessid.Name != null && cob.rsa_classofbusinessid.Name != "") {
        //                if (cob.rsa_classofbusinessid.Name == "Motor Fleet") {
        //                    RSA.D365CRM.Renewal.Main.EnableCOBValidation(executionContext);
        //                }
        //            }
        //        }
        //    },
        //    errorHandler
        //);
    },

    EnableCOBValidation: function (executionContext) {
        var formContext = executionContext.getFormContext();
        formContext.getAttribute("rsa_technicalprice").setRequiredLevel("required");
        formContext.getAttribute("rsa_rationalforpricingadjustments").setRequiredLevel("required");
        formContext.getAttribute("rsa_renewedpremium").setRequiredLevel("required");
    },

    DisableCOBValidation: function (executionContext) {
        var formContext = executionContext.getFormContext();
        formContext.getAttribute("rsa_technicalprice").setRequiredLevel("none");
        formContext.getAttribute("rsa_rationalforpricingadjustments").setRequiredLevel("none");
        formContext.getAttribute("rsa_renewedpremium").setRequiredLevel("none");
    },

    CalculateDiscountfromTechPrice: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var entityName = formContext.data.entity.getEntityName();
        if (entityName != "" && entityName != null) {
            if (entityName != "" && entityName != null) {
                if (entityName == "rsa_quote") {
                    //var quotedGWP = formContext.getAttribute("rsa_quotedgwpexipt").getValue();
                    var techPrice = formContext.getAttribute("rsa_technicalprice").getValue();
                    if (quotedGWP != null && techPrice != null && quotedGWP != 0 && techPrice != 0) {
                        var discTechPrice = (quotedGWP / techPrice) * 100;
                        formContext.getAttribute("rsa_discountfromtechprice").setValue(discTechPrice);
                    }
                    else {
                        formContext.getAttribute("rsa_discountfromtechprice").setValue(0);
                    }
                    formContext.getAttribute("rsa_discountfromtechprice").setSubmitMode("always");
                }
                else {
                    if (entityName == "rsa_renewal") {
                        var renewedPremium = formContext.getAttribute("rsa_renewedpremium").getValue();
                        var techPrice = formContext.getAttribute("rsa_technicalprice").getValue();
                        if (renewedPremium != null && techPrice != null && renewedPremium != 0 && techPrice != 0) {
                            var discTechPrice = (renewedPremium / techPrice) * 100;
                            formContext.getAttribute("rsa_discountfromtechprice").setValue(discTechPrice);
                        }
                        else {
                            formContext.getAttribute("rsa_discountfromtechprice").setValue(0);
                        }
                        formContext.getAttribute("rsa_discountfromtechprice").setSubmitMode("always");
                    }
                }
            }
        }
    },

    ShowRBOReasonIfOffshoreUser: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var status = formContext.getAttribute('rsa_statusreason').getValue();
        if (status != null && status == 866760009) {
            var teamAssignedTo = formContext.getAttribute('rsa_teamassignedto');
            if (teamAssignedTo != null) {
                var lookupValue = teamAssignedTo.getValue();
                if (lookupValue != null) {
                    var teamId = lookupValue[0].id;
                    var teamName = lookupValue[0].name;
                    if (teamId != null) {
                        RSA.D365CRM.Renewal.Main.retrieveTeamBU(teamId,teamName,executionContext);
                    }
                }
            }
        }
        else {
            formContext.getControl("rsa_rbo").setVisible(false);
            formContext.getAttribute("rsa_rbo").setValue(null);
            formContext.getAttribute("rsa_rbo").setRequiredLevel("none");
            formContext.getAttribute("rsa_rbo").setSubmitMode("always");

            formContext.getAttribute("rsa_rboreasonavailable").setValue(null);
            formContext.getControl("rsa_rboreasonavailable").setVisible(false);
            formContext.getAttribute("rsa_rboreasonavailable").setSubmitMode("always");

            formContext.getControl("rsa_rbootherreason").setVisible(false);
            formContext.getAttribute("rsa_rbootherreason").setRequiredLevel("none");
            formContext.getAttribute("rsa_rbootherreason").setValue("");
            formContext.getAttribute("rsa_rbootherreason").setSubmitMode("always");
        }
    },

    retrieveTeamBU: function (teamId,teamName,executionContext) {
        var formContext = executionContext.getFormContext();
        var teamid = teamId.replace("{", "").replace("}", "");
        if (teamName === "India") {
            formContext.getControl("rsa_rbo").setVisible(true);
            formContext.getAttribute("rsa_rbo").setRequiredLevel("required");
            formContext.getAttribute("rsa_rbo").setSubmitMode("always");

            formContext.getAttribute("rsa_rboreasonavailable").setValue(null);
            formContext.getControl("rsa_rboreasonavailable").setVisible(true);
            formContext.getAttribute("rsa_rboreasonavailable").setSubmitMode("always");
        }
        else {
            formContext.getControl("rsa_rbo").setVisible(false);
            formContext.getAttribute("rsa_rbo").setValue(null);
            formContext.getAttribute("rsa_rbo").setRequiredLevel("none");
            formContext.getAttribute("rsa_rbo").setSubmitMode("always");
            formContext.getAttribute("rsa_rboreasonavailable").setValue(null);
            formContext.getControl("rsa_rboreasonavailable").setVisible(false);
            formContext.getAttribute("rsa_rboreasonavailable").setSubmitMode("always");

            formContext.getControl("rsa_rbootherreason").setVisible(false);
            formContext.getAttribute("rsa_rbootherreason").setRequiredLevel("none");
            formContext.getAttribute("rsa_rbootherreason").setValue("");
            formContext.getAttribute("rsa_rbootherreason").setSubmitMode("always");
        }
    },

    onChangeRBOReason: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var rboReason = formContext.getAttribute('rsa_rbo').getValue();
        if (rboReason != null && rboReason != -1) {
            formContext.getAttribute("rsa_rboreasonavailable").setValue(true);
            formContext.getAttribute("rsa_rboreasonavailable").setSubmitMode("always");
            if (rboReason == "172030012") {
                formContext.getControl("rsa_rbootherreason").setVisible(true);
                formContext.getAttribute("rsa_rbootherreason").setRequiredLevel("required");
                formContext.getAttribute("rsa_rbootherreason").setSubmitMode("always");
            }
            else {
                formContext.getControl("rsa_rbootherreason").setVisible(false);
                formContext.getAttribute("rsa_rbootherreason").setRequiredLevel("none");
                formContext.getAttribute("rsa_rbootherreason").setValue("");
                formContext.getAttribute("rsa_rbootherreason").setSubmitMode("always");
            }
        }
        else {
            formContext.getAttribute("rsa_rboreasonavailable").setValue(false);
            formContext.getAttribute("rsa_rboreasonavailable").setSubmitMode("always");
            formContext.getControl("rsa_rbootherreason").setVisible(false);
            formContext.getAttribute("rsa_rbootherreason").setValue("");
            formContext.getAttribute("rsa_rbootherreason").setRequiredLevel("none");
            formContext.getAttribute("rsa_rbootherreason").setSubmitMode("always");
        }
    },

    UnlockrsaFieldsForSecurityRole: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var roles = Xrm.Utility.getGlobalContext().userSettings.roles;
        if (roles === null) return false;
        var hasRole = false;
        roles.forEach(function (item) {
            if (item.name.toUpperCase() === "SYSTEM ADMINISTRATOR") {
                hasRole = true;
            }
        });
        if (hasRole === true) {
            RSA.D365CRM.Renewal.Main.UnlockAllFields(executionContext);
        } 
    },

    UnlockAllFields: function (executionContext) {
        var formContext = executionContext.getFormContext();
        formContext.ui.controls.forEach(function (control, index) {
            var controlType = control.getControlType();
            if (controlType != 'iframe' && controlType != 'webresource' && controlType != 'subgrid') {
                control.setDisabled(false);
            }
        });
    },

    renewedpremiumbanding: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var renewedpremium = formContext.getAttribute("rsa_renewedpremium").getValue();
        if (renewedpremium != null || renewedpremium != "") {
            var num1 = renewedpremium;

            var num2 = 5000;
            var num3 = 7500;
            var num4 = 10000;
            var num5 = 15000;


            if (num1 <= num2) {

                formContext.getAttribute("rsa_renewedpremiumbanding").setValue(866760000);
                formContext.getAttribute("rsa_renewedpremiumbanding").setSubmitMode("always");
            }
            else if (num1 <= num3) {

                formContext.getAttribute("rsa_renewedpremiumbanding").setValue(866760001);
                formContext.getAttribute("rsa_renewedpremiumbanding").setSubmitMode("always");
            }
            else if (num1 <= num4) {

                formContext.getAttribute("rsa_renewedpremiumbanding").setValue(866760002);
                formContext.getAttribute("rsa_renewedpremiumbanding").setSubmitMode("always");
            }
            else if (num1 <= num5) {

                formContext.getAttribute("rsa_renewedpremiumbanding").setValue(866760003);
                formContext.getAttribute("rsa_renewedpremiumbanding").setSubmitMode("always");
            }
            else if (num1 > num5) {

                formContext.getAttribute("rsa_renewedpremiumbanding").setValue(866760004);
               formContext.getAttribute("rsa_renewedpremiumbanding").setSubmitMode("always");
            }
        }

    },

    expiringpremiumbanding: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var expiredpremium = formContext.getAttribute("rsa_expirypremiumplusorminusamendments").getValue();

        if (expiredpremium != null || expiredpremium != "") {
            var num1 = expiredpremium;

            var num2 = 5000;
            var num3 = 7500;
            var num4 = 10000;
            var num5 = 15000;

            if (num1 <= num2) {

                formContext.getAttribute("rsa_expiringpremiumbanding").setValue(866760000);
                formContext.getAttribute("rsa_expiringpremiumbanding").setSubmitMode("always");
            }
            else if (num1 <= num3) {
                formContext.getAttribute("rsa_expiringpremiumbanding").setValue(866760001);
               formContext.getAttribute("rsa_expiringpremiumbanding").setSubmitMode("always");
            }
            else if (num1 <= num4) {
                formContext.getAttribute("rsa_expiringpremiumbanding").setValue(866760002);
                formContext.getAttribute("rsa_expiringpremiumbanding").setSubmitMode("always");
            }
            else if (num1 <= num5) {
                formContext.getAttribute("rsa_expiringpremiumbanding").setValue(866760003);
                formContext.getAttribute("rsa_expiringpremiumbanding").setSubmitMode("always");
            }
            else if (num1 > num5) {
                formContext.getAttribute("rsa_expiringpremiumbanding").setValue(866760004);
                formContext.getAttribute("rsa_expiringpremiumbanding").setSubmitMode("always");
            }
        }
    },


});