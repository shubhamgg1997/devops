//"use strict";

var RSA = window.RSA || { __namespace: true, __typeName: "RSA" };
RSA.D365CRM = RSA.D365CRM || { __namespace: true, __typeName: "RSA.D365CRM" };
RSA.D365CRM.Broker = RSA.D365CRM.Broker || { __namespace: true, __typeName: "RSA.D365CRM.Broker" };
RSA.D365CRM.Broker.Main = RSA.D365CRM.Broker.Main || ({
    FormType: {
        Create: 1,
        Update: 2,
        ReadOnly: 3,
        Disabled: 4,
        BulkEdit: 6
    },
    OnLoad: function (executionContext) {
        var formContext = executionContext.getFormContext();

        if (formContext.ui.getFormType() === RSA.D365CRM.Broker.Main.FormType.Create) {

        }
        else if (formContext.ui.getFormType() === RSA.D365CRM.Broker.Main.FormType.Update) {

        }
        else if (formContext.ui.getFormType() === RSA.D365CRM.Broker.Main.FormType.Disabled) {

        }
        else if (formContext.ui.getFormType() === RSA.D365CRM.Broker.Main.FormType.BulkEdit) {

        }

    },

    OnSave: function (executionContext) {
        RSA.D365CRM.Broker.Main.CannotchangeBrokerName(executionContext);
        RSA.D365CRM.Broker.Main.BrokerFormID(executionContext);
        RSA.D365CRM.Broker.Main.PromiseNewBusinessTEXTName(executionContext);
        RSA.D365CRM.Broker.Main.PromiseRenewalTEXTName(executionContext);
        RSA.D365CRM.Broker.Main.dealProds(executionContext);
    },

    CheckUserRole: function (formContext) {
        var allroles = [];
        var userSettings = Xrm.Utility.getGlobalContext().userSettings;
        var userRoleNamearray = userSettings.roles.getAll();


        for (var i = 0; i < userRoleNamearray.length; i++) {

            var userRoleName = userRoleNamearray[i].name;
            if (userRoleName === "CSI BPO Handler") {
                allroles[i] = 1;
                //return value;
            }
            if (userRoleName === "CSI BPO Manager") {
                allroles[i] = 2;
                // return value;
            }
            if (userRoleName === "CSI Marketing") {
                allroles[i] = 3;
                //return value;
            }
            if (userRoleName === "System Administrator") {
                allroles[i] = 4;
                //return value;
            }
            if (userRoleName === "CSI Sales User") {
                allroles[i] = 5;
                //return value;
            }
            if (userRoleName === "CSI MI/Data Analyst") {
                allroles[i] = 6;
                //return value;
            }
            if (userRoleName === "CSI Integration") {
                allroles[i] = 7;
                //return value;
            }

        }
        return allroles;
    },

    CannotchangeBrokerName: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("name") !== null && formContext.getAttribute("name") !== "undefined" && formContext.getAttribute("name").getValue() !== null) {
                var userRole = [];
                var hasValue = false;
                userRole = RSA.D365CRM.Broker.Main.CheckUserRole(formContext);
                for (var i = userRole.length - 1; i >= 0; i--) {
                    if (userRole[i] !== "4" || userRole[i] !== "5" || userRole[i] !== "6" || userRole[i] !== "7") {
                        hasValue = true;
                    }

                }
                if (!hasValue) {
                    //rsa_status,rsa_activitydate,rsa_recordtypeid,rsa_description,rsa_ishighpriority,ownerid
                    formContext.getControl("name").setDisabled(true);
                    formContext.ui.setFormNotification("Broker name can be updated only if it belongs to Profile.Name = 'System Administrator' or 'CSI Sales User' or 'CSI MI/Data Analyst' or 'CSI Integration' ", "ERROR");
                }
                else {
                    formContext.getControl("name").setDisabled(false);
                    formContext.ui.clearFormNotification();
                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "CannotchangeBrokerName -" + err.message });
        }
    },
//Author : Prachi Paunikqar
    //Date : 29 September 2020
    //This Function sets form ID of Broker  form to a Field named BrokerformId
    BrokerFormID: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            var formId = formContext.ui.formSelector.getCurrentItem().getId();

            if (formContext.getAttribute("rsa_brokerformid") !== null && formContext.getAttribute("rsa_brokerformid") !== undefined) {

                formContext.getAttribute("rsa_brokerformid").setValue(formId);
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "BrokerFormID -" + err.message });
        }

    },

    //Author : Prachi Paunikar
    //Date : 29 September 2020
    //This Function opens the correct form while opening the existing records
    LoadingExistingRecord: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_brokerformid") !== null && formContext.getAttribute("rsa_brokerformid") !== undefined && (formContext.ui.getFormType() === 2 || formContext.ui.getFormType() === 4  || formContext.ui.getFormType() === 3)) {
                if (formContext.getAttribute("rsa_brokerformid").getValue() !== null && formContext.getAttribute("rsa_brokerformid").getValue() !== undefined) {
                    var BrokerFormID = formContext.getAttribute("rsa_brokerformid").getValue();
                    var formId = formContext.ui.formSelector.getCurrentItem().getId();
                    if (formId !== BrokerFormID) {
                        formContext.ui.formSelector.items.get(BrokerFormID).navigate();


                    }
                }
            }
        }

        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "LoadingExistingRecord -" + err.message });
        }
    },
	
	OnChangeOfSalesTeam: function(executionContext){
		try {
            var formContext = executionContext.getFormContext();
			if (formContext.getAttribute("rsa_salesteam").getValue()!==null){
				var salesteam = formContext.getAttribute("rsa_salesteam").getValue();
				formContext.getControl("rsa_brokerpanelid").addPreSearch(RSA.D365CRM.Broker.Main.filterLookup);
			}
		}
		catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "OnChangeOfSalesTeam -" + err.message });
        }
		
	},
	
	filterLookup: function(executionContext){
		var formContext = executionContext.getFormContext();
                var salesteam = formContext.getAttribute("rsa_salesteam").getValue();
		var filter = "<filter type='and'><condition attribute='rsa_applicablesalesteam' operator='like' value='" + salesteam + "' /></filter>";  
		formContext.getControl("rsa_brokerpanelid").addCustomFilter(filter);
	},


//Validation rule for Broker Profile Entity
SoftwareUsedfieldisrequired: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_softwarehouseforcommercialpurposes") !== null && formContext.getAttribute("rsa_softwarehouseforcommercialpurposes") !== "undefined")
				{
					var softwareHouse = formContext.getAttribute("rsa_softwarehouseforcommercialpurposes").getValue();
					
					if(formContext.getAttribute("rsa_softwarehouseforcommercialpurposes").getValue() === null)
						
						{
							formContext.getAttribute("rsa_softwarehouseforcommercialpurposes").setRequiredLevel("required");
							formContext.getControl("rsa_softwarehouseforcommercialpurposes").setNotification("Software House for Commercial Purposes : 1. You must enter a value. 2. You cannot enter any other value if 'None' is selected. Please remove 'None' and try again.", 201);
							
						}
						
					else{
								formContext.getControl("rsa_softwarehouseforcommercialpurposes").clearNotification(201);
								formContext.getAttribute("rsa_softwarehouseforcommercialpurposes").setRequiredLevel("none");
					}
						
					if(formContext.getAttribute("rsa_softwarehouseforcommercialpurposes").getValue() == 866760004)	
					{ 
						formContext.getControl("rsa_softwarehouseforcommercialpurposes").clearNotification(201);
						formContext.getAttribute("rsa_softwarehouseforcommercialpurposes").setRequiredLevel("none");
					}
					
					else if(formContext.getAttribute("rsa_softwarehouseforcommercialpurposes").getValue() !== null)
						
						{
							
							var softwareHouseHasValue = softwareHouse.includes(866760004);
							
							if(softwareHouseHasValue){
								formContext.getAttribute("rsa_softwarehouseforcommercialpurposes").setRequiredLevel("required");
								formContext.getControl("rsa_softwarehouseforcommercialpurposes").setNotification("Software House for Commercial Purposes : 1. You must enter a value. 2. You cannot enter any other value if 'None' is selected. Please remove 'None' and try again.", 202);
							}
							
							else{
								formContext.getControl("rsa_softwarehouseforcommercialpurposes").clearNotification(202);
								formContext.getAttribute("rsa_softwarehouseforcommercialpurposes").setRequiredLevel("none");
							}
							
					}
					
				}
				
           
         }

        
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "Software Used field is required -" + err.message });
        }
    },

PromiseNewBusinessTEXTName: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
			var promiseNewBusinessTEXT = "";
				if(formContext.getAttribute("rsa_rsapromisenewbusinesstext") !== null && formContext.getAttribute("rsa_rsapromisenewbusinesstext") !== "undefined" && formContext.getAttribute("rsa_promisenewbusiness") !== null && formContext.getAttribute("rsa_promisenewbusiness") !== "undefined" && formContext.getAttribute("rsa_promisenewbusiness").getValue() !== "undefined")
				{
				
					if(formContext.getAttribute("rsa_promisenewbusiness").getValue() !== null)
					{
						var promiseNewBusiness = formContext.getAttribute("rsa_promisenewbusiness").getValue();
						if(promiseNewBusiness.includes(866760000))
						{
							promiseNewBusinessTEXT = promiseNewBusinessTEXT + "Mid-Market";
						}
						else
						{
							promiseNewBusinessTEXT = promiseNewBusinessTEXT + "";
						}
						promiseNewBusinessTEXT = promiseNewBusinessTEXT + "<br>";
						
						if(promiseNewBusiness.includes(866760001))
						{
							promiseNewBusinessTEXT = promiseNewBusinessTEXT + "GSL - Regional CE&RE";
						}
						else
						{
							promiseNewBusinessTEXT = promiseNewBusinessTEXT + "";
						}
						promiseNewBusinessTEXT = promiseNewBusinessTEXT + "<br>";
						
						if(promiseNewBusiness.includes(866760002))
						{
							promiseNewBusinessTEXT = promiseNewBusinessTEXT + "GSL - Real Estate";
						}
						else
						{
							promiseNewBusinessTEXT = promiseNewBusinessTEXT + "";
						}
						promiseNewBusinessTEXT = promiseNewBusinessTEXT + "<br>";
						
						if(promiseNewBusiness.includes(866760003))
						{
							promiseNewBusinessTEXT = promiseNewBusinessTEXT + "GSL - Profin";
						}
						else
						{
							promiseNewBusinessTEXT = promiseNewBusinessTEXT + "";
						}
						promiseNewBusinessTEXT = promiseNewBusinessTEXT + "<br>";
						
						if(promiseNewBusiness.includes(866760004))
						{
							promiseNewBusinessTEXT = promiseNewBusinessTEXT + "GSL - London Construction";
						}
					}
					
					else if(formContext.ui.getFormType() === 1 || formContext.getAttribute("rsa_promisenewbusiness").getValue() === null){
						promiseNewBusinessTEXT = "<br><br><br><br>";
					}
					
					formContext.getAttribute("rsa_rsapromisenewbusinesstext").setValue(promiseNewBusinessTEXT);
				}
				
				
			}
		catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "PromiseNewBusinessTEXTName -" + err.message });
        }
    },
	
PromiseRenewalTEXTName: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
			var promiseRenewalTEXT = "";
				if(formContext.getAttribute("rsa_rsapromiserenewaltext") !== null && formContext.getAttribute("rsa_rsapromiserenewaltext") !== "undefined" && formContext.getAttribute("rsa_promiserenewal") !== null && formContext.getAttribute("rsa_promiserenewal") !== "undefined" && formContext.getAttribute("rsa_promiserenewal").getValue() !== "undefined")
				{
				
					if(formContext.getAttribute("rsa_promiserenewal").getValue() !== null)
					{
						var promiseRenewal = formContext.getAttribute("rsa_promiserenewal").getValue();
						if(promiseRenewal.includes(866760000))
						{
							promiseRenewalTEXT = promiseRenewalTEXT + "Mid-Market";
						}
						else
						{
							promiseRenewalTEXT = promiseRenewalTEXT + "";
						}
						promiseRenewalTEXT = promiseRenewalTEXT + "<br>";
						
						if(promiseRenewal.includes(866760001))
						{
							promiseRenewalTEXT = promiseRenewalTEXT + "GSL - Regional CE&RE";
						}
						else
						{
							promiseRenewalTEXT = promiseRenewalTEXT + "";
						}
						promiseRenewalTEXT = promiseRenewalTEXT + "<br>";
						
						if(promiseRenewal.includes(866760002))
						{
							promiseRenewalTEXT = promiseRenewalTEXT + "GSL - Real Estate";
						}
						else
						{
							promiseRenewalTEXT = promiseRenewalTEXT + "";
						}
						promiseRenewalTEXT = promiseRenewalTEXT + "<br>";
						
						if(promiseRenewal.includes(866760003))
						{
							promiseRenewalTEXT = promiseRenewalTEXT + "GSL - Profin";
						}
						else
						{
							promiseRenewalTEXT = promiseRenewalTEXT + "";
						}
						promiseRenewalTEXT = promiseRenewalTEXT + "<br>";
						
						if(promiseRenewal.includes(866760004))
						{
							promiseRenewalTEXT = promiseRenewalTEXT + "GSL - London Construction";
						}
					}
					
					else if(formContext.ui.getFormType() === 1 || formContext.getAttribute("rsa_promiserenewal").getValue() === null){
						promiseRenewalTEXT = "<br><br><br><br>";
					}
					
					formContext.getAttribute("rsa_rsapromiserenewaltext").setValue(promiseRenewalTEXT);
				}
				
				
			}
		catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "promiseRenewalTEXTName -" + err.message });
        }
    },

dealProds: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
			var dealProds = "";
				if(formContext.getAttribute("rsa_dealprod") !== null && formContext.getAttribute("rsa_dealprod") !== "undefined" && formContext.getAttribute("rsa_dealproducts") !== null && formContext.getAttribute("rsa_dealproducts") !== "undefined" && formContext.getAttribute("rsa_dealproducts").getValue() !== "undefined")
				{
				
					if(formContext.getAttribute("rsa_dealproducts").getValue() !== null)
					{
						var dealproducts = formContext.getAttribute("rsa_dealproducts").getValue();
						if(dealproducts.includes(866760000))
						{
							dealProds = dealProds + "Commercial Vehicle";
						}
						else
						{
							dealProds = dealProds + "";
						}
						dealProds = dealProds + ",";
						
						if(dealproducts.includes(866760001))
						{
							dealProds = dealProds + "Business Car";
						}
						else
						{
							dealProds = dealProds + "";
						}
						dealProds = dealProds + ",";
						
						if(dealproducts.includes(866760002))
						{
							dealProds = dealProds + "Van";
						}
						else
						{
							dealProds = dealProds + "";
						}
						dealProds = dealProds + ",";
						
						if(dealproducts.includes(866760003))
						{
							dealProds = dealProds + "Truck";
						}
						else
						{
							dealProds = dealProds + "";
						}
						dealProds = dealProds + ",";
						
						if(dealproducts.includes(866760004))
						{
							dealProds = dealProds + "Shop";
						}
						else
						{
							dealProds = dealProds + "";
						}
						dealProds = dealProds + ",";
						
						if(dealproducts.includes(866760005))
						{
							dealProds = dealProds + "Office";
						}
						else
						{
							dealProds = dealProds + "";
						}
						dealProds = dealProds + ",";
						
						if(dealproducts.includes(866760006))
						{
							dealProds = dealProds + "Minifleet";
						}
						else
						{
							dealProds = dealProds + "";
						}
						dealProds = dealProds + ",";
						
						if(dealproducts.includes(866760007))
						{
							dealProds = dealProds + "Property Owners";
						}
						else
						{
							dealProds = dealProds + "";
						}
						dealProds = dealProds + ",";
						
						if(dealproducts.includes(866760008))
						{
							dealProds = dealProds + "Pubs, Restaurants, Hotels";
						}
						else
						{
							dealProds = dealProds + "";
						}
						//dealProds = dealProds + ",";
						
						
					}
					
					else if(formContext.ui.getFormType() === 1 || formContext.getAttribute("rsa_dealproducts").getValue() === null){
						dealProds = ",,,,,,,,,";
					}
					
					formContext.getAttribute("rsa_dealprod").setValue(dealProds);
				}
				
				
			}
		catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "dealProds -" + err.message });
        }
	},

	//RefreshPerformanceCategoryChoice: function (executionContext) {
	//	var formContext = executionContext.getFormContext();
	//	formContext.getControl("rsa_channel").removeOption(866760010);
	//	formContext.getControl("rsa_channel").removeOption(866760011);
	//	formContext.getControl("rsa_channel").removeOption(866760012);
	//	formContext.getControl("rsa_channel").removeOption(866760013);
	//	formContext.getControl("rsa_channel").removeOption(866760014);
	//	formContext.getControl("rsa_channel").removeOption(866760015);
	//	formContext.getControl("rsa_channel").removeOption(866760016);
	//	formContext.getControl("rsa_channel").removeOption(866760017);
	//	formContext.getControl("rsa_channel").removeOption(866760018);
	//	formContext.getControl("rsa_channel").removeOption(866760019);
	//	formContext.getControl("rsa_channel").removeOption(866760003);
	//	formContext.getControl("rsa_channel").removeOption(866760006);
	//	formContext.getControl("rsa_channel").removeOption(866760005);
	//	formContext.getControl("rsa_channel").removeOption(866760007);
	//	formContext.getControl("rsa_channel").removeOption(866760008);
	//},
	
    ConvertGuid: function (str) {
        if (str) {
            str = str.replace(/[{}]/g, '');
            str = str.toUpperCase();
        }
        return str;
    }

});
