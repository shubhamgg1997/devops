//"use strict";

var SecurityMapping = {
    AISIntegrationUser: 866760000,
    BPOHandler: 866760001,
    ClaimsAccountManager: 866760002,
    CSIAdmin: 866760003,
    CSISalesUser: 866760004,
    DataAnalyst: 866760005,
    ESIAdmin: 866760006,
    ESISales: 866760007,
    OperationsHandler: 866760008,
    ReadOnly: 866760009,
    SMEOperationsHandler: 866760010,
    SystemAdministrator: 866760011,
    TradingHandler: 866760012,
    WebChatIntegrationUser: 866760013,
    MarineUser: 866760016,
    BPOExtendedSupport: 866760017,

}
/* Change Summary for April 2022 Release 1 */
/* Last Modified By: Shreya Diwate*/
/* Summary of Changes: Remove Debug Code*/
/* - Reason for Change: Unexpected 'debugger' statement */
/* - Function name - RedirectToPageLayout */

function RedirectToPageLayout(PrimaryControl, key) {
    try {
        //debugger;
        var securityMap = new Array();
        var req = new XMLHttpRequest();
        var globalContext = Xrm.Utility.getGlobalContext();
        var ClientUrl = globalContext.getClientUrl();

        req.open("GET", ClientUrl + "/api/data/v9.1/rsa_customlabels?$select=rsa_dependentoptionsetjson,rsa_name&$filter=rsa_name eq 'SecurityRole'", false);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    var results = JSON.parse(this.response);
                    for (var i = 0; i < results.value.length; i++) {
                        var rsa_categories = results.value[i]["rsa_categories"];
                        var rsa_dependentoptionsetjson = results.value[i]["rsa_dependentoptionsetjson"];
                        var SecurityRoleMapping = JSON.parse(results.value[i]["rsa_dependentoptionsetjson"]).SecurityRoleMapping;
                        var roles = Xrm.Utility.getGlobalContext().userSettings.securityRoles;

                        for (var i = 0; i < roles.length; i++) {
                            var GUID = Xrm.Utility.getGlobalContext().userSettings.securityRoles[i];
                            SecurityRoleMapping.forEach(function (item) {
                                if (item.SecurityRoleGUID.toLowerCase() == GUID.toLowerCase())
                                    securityMap.push(item.SecurityRoleValue);
                            });
                        }
                    }
                }
                else {
                    Xrm.Navigation.openAlertDialog({ text: "Get Security Role Mapping: " + this.statusText });
                }
            }
        };
        req.send();

        var securityRoleMappingStr = '';
        for (var k = 0; k < securityMap.length; k++) {
            securityRoleMappingStr += "<value>" + securityMap[k] + "</value>"
        }

        var formId, lOBName, lOBId;
        var formContext = PrimaryControl;
        var fetchXmlQuery = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
            "<entity name='rsa_formlayoutmapping'>" +
            "<attribute name='rsa_formlayoutmappingid' />" +
            "<attribute name='rsa_name' />" +
            "<attribute name='rsa_lineofbusiness' />" +
            "<attribute name='rsa_securityrolemapping' />" +
            "<attribute name='rsa_form' />" +
            "<order attribute='rsa_name' descending='false' />" +
            "<filter type='and'>" +
            "<condition attribute='rsa_formidentifier' operator='eq' value='" + key + "' />" +
            "<condition attribute='rsa_securityrolemapping' operator='contain-values'>" + securityRoleMappingStr +
            "</condition></filter>" +
            "<link-entity name='rsa_formlayout' from='rsa_formlayoutid' to='rsa_form' link-type='inner' alias='ae'>" +
            "<attribute name='rsa_formid'/>" +
            "<filter type='and'>" +

            "<condition attribute='rsa_entityname' operator='eq' value='866760000' />" +
            "</filter>" +
            "</link-entity>" +
            "<link-entity name='rsa_lineofbusiness' from='rsa_lineofbusinessid' to='rsa_lineofbusiness' link-type='inner' alias='aa'>" +
            "<attribute name='rsa_lobidentifier' />" +
            "</link-entity>" +
            "</entity>" +
            "</fetch>";
        var req = new XMLHttpRequest();
        var globalContext = Xrm.Utility.getGlobalContext();
        var ClientUrl = globalContext.getClientUrl();
        req.open("GET", ClientUrl + "/api/data/v9.1/rsa_formlayoutmappings?fetchXml=" + encodeURIComponent(fetchXmlQuery), true);
        req.setRequestHeader("Prefer", 'odata.include-annotations="*"');
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    var results = JSON.parse(this.response);
                    if (results.value.length > 0) {
                        formId = results.value[0]["ae.rsa_formid"];
                        lOBName = results.value[0]["_rsa_lineofbusiness_value@OData.Community.Display.V1.FormattedValue"];
                        lOBId = results.value[0]["_rsa_lineofbusiness_value"];

                        if (formId !== null) {
                            var entityFormOptions = {};
                            entityFormOptions["entityName"] = "opportunity";
                            entityFormOptions["formId"] = formId;
                            entityFormOptions["rsa_lineofbusiness"] = lOBId;

                            var formParameters = {};
                            if (lOBId !== null && lOBName !== null) {
                                formParameters["rsa_lineofbusiness"] = lOBId;
                                formParameters["rsa_lineofbusinessname"] = lOBName;
                                formParameters["rsa_lineofbusinesstype"] = "rsa_lineofbusiness";

                                if (formContext.data !== undefined && formContext.getAttribute("title") !== undefined && formContext.getAttribute("title") !== null && formContext.data.entity.getEntityName() === "incident") {
                                    formParameters["rsa_case"] = formContext.data.entity.getId();
                                    formParameters["rsa_casename"] = formContext.getAttribute("title").getValue();
                                    formParameters["rsa_casetype"] = formContext.data.entity.getEntityName();

                                }

                                if (formContext.data !== undefined && formContext.getAttribute("rsa_policyid") !== undefined && formContext.getAttribute("rsa_policyid") !== null && formContext.getAttribute("rsa_policyid").getValue() !== undefined && formContext.getAttribute("rsa_policyid").getValue() !== null && formContext.data.entity.getEntityName() === "incident") {
                                    formParameters["rsa_policyid"] = formContext.getAttribute("rsa_policyid").getValue()[0].id;
                                    formParameters["rsa_policyidname"] = formContext.getAttribute("rsa_policyid").getValue()[0].name;
                                    formParameters["rsa_policyidtype"] = "rsa_policy";

                                }
                                if (formContext.data !== undefined && formContext.getAttribute("name") !== undefined && formContext.getAttribute("name") !== null && formContext.data.entity.getEntityName() === "account") {
                                    formParameters["parentaccountid"] = formContext.data.entity.getId();
                                    formParameters["parentaccountidname"] = formContext.getAttribute("name").getValue();
                                    formParameters["parentaccountidtype"] = "account";
                                }


                                if (formContext.data !== undefined && formContext.getAttribute("rsa_name") !== undefined && formContext.getAttribute("rsa_name") !== null && formContext.data.entity.getEntityName() === "rsa_customer") {
                                    formParameters["rsa_customer"] = formContext.data.entity.getId();
                                    formParameters["rsa_customername"] = formContext.getAttribute("rsa_name").getValue();
                                    formParameters["rsa_customertype"] = "rsa_customer";
                                }



                            }
                            // Open the form.
                            Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
                                function (success) {
                                    //console.log(success);
                                },
                                function (error) {
                                    //console.log(error);
                                });
                        }
                    }
                } else {

                    //alert(this.statusText);
                    Xrm.Navigation.openAlertDialog({ text: "RedirectToPageLayout" + this.statusText });
                }
            }
        };
        req.send();

        var formContext = PrimaryControl;

    }
    catch (err) {
        Xrm.Navigation.openAlertDialog({ text: "RedirectToPageLayout -" + err.message });
    }

}


function EnableCreateCaseAfterCreateOpportunity(PrimaryControl) {
    var formContext = PrimaryControl;
    if (formContext.ui.getFormType() === 1) {
        return true;
    }
    else {
        return false;
    }
}

//Author : Pooja Raje
//Date : 09 September 2020
//Function for setting value of LOB on load

/* Change Summary for April 2022 Release 1 */
/* Last Modified By: Shreya Diwate*/
/* Summary of Changes: Remove Debug Code*/
/* - Reason for Change: Unexpected 'debugger' statement */
/* - Function name - OnLoadLOB */

function OnLoadLOB(executionContext) {
    var formContext = executionContext.getFormContext();
    //debugger;
    try {


        var lOBName, lOBId;

        var formId = formContext.ui.formSelector.getCurrentItem().getId().toUpperCase().replace(/[{}]/g, '');

        var fetchXmlQuery = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
            "<entity name='rsa_formlayoutmapping'>" +
            "<attribute name='rsa_formlayoutmappingid' />" +
            "<attribute name='rsa_name' />" +
            "<attribute name='rsa_lineofbusiness' />" +
            "<attribute name='rsa_form' />" +
            "<order attribute='rsa_name' descending='false' />" +
            "<link-entity name='rsa_formlayout' from='rsa_formlayoutid' to='rsa_form' link-type='inner' alias='ae'>" +
            "<attribute name='rsa_formid'/>" +
            "<filter type='and'>" +
            "<condition attribute='rsa_formid' operator='eq' value= '" + formId + "'/>" +
            "<condition attribute='rsa_entityname' operator='eq' value='866760000' />" +
            "</filter>" +
            "</link-entity>" +
            "</entity>" +
            "</fetch>";

        var req = new XMLHttpRequest();
        var globalContext = Xrm.Utility.getGlobalContext();
        var ClientUrl = globalContext.getClientUrl();
        req.open("GET", ClientUrl + "/api/data/v9.1/rsa_formlayoutmappings?fetchXml=" + encodeURIComponent(fetchXmlQuery), true);
        req.setRequestHeader("Prefer", 'odata.include-annotations="*"');
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    var results = JSON.parse(this.response);
                    if (results.value.length > 0) {
                        formId = results.value[0]["ae.rsa_formid"];
                        lOBName = results.value[0]["_rsa_lineofbusiness_value@OData.Community.Display.V1.FormattedValue"];
                        lOBId = results.value[0]["_rsa_lineofbusiness_value"];
                        // If value of LOB exists then skip this function
                        if ((formContext.getAttribute("rsa_lineofbusiness") !== null && formContext.getAttribute("rsa_lineofbusiness") !== undefined) || (formContext.ui.getFormType() === 1)) {
                            if ((formContext.getAttribute("rsa_lineofbusiness").getValue() === null && formContext.getAttribute("rsa_lineofbusiness").getValue() !== undefined) || (formContext.ui.getFormType() === 1 && formContext.getAttribute("rsa_lineofbusiness").getValue() === null)) {

                                formContext.getAttribute("rsa_lineofbusiness").setValue([{ id: lOBId, name: lOBName, entityType: "rsa_lineofbusiness" }]);
                            }
                        }


                        LOBDependentOptionset(executionContext, lOBId);
                    }
                }
                else {
                    Xrm.Navigation.openAlertDialog({ text: "OnLoadLOB " + this.statusText });
                }
            }
        };
        req.send();

    }

    catch (err) {
        Xrm.Navigation.openAlertDialog({ text: "OnLoadLOB -" + err.message });
    }
}


//Author : Shreya Diwate
//Date : 25 Aug 2020
//This Function Option set to Option set filtering
function LOBDependentOptionset(executionContext, lOBId) {
    try {

        var LOBIDSet;
        var formContext = executionContext.getFormContext();

        if (lOBId !== null && lOBId !== undefined) {
            var req = new XMLHttpRequest();
            var globalContext = Xrm.Utility.getGlobalContext();
            var ClientUrl = globalContext.getClientUrl();

            req.open("GET", ClientUrl + "/api/data/v9.1/rsa_customlabels?$select=rsa_categories,rsa_customlabelid,_rsa_opportunitylob_value,rsa_dependentoptionsetjson&$filter=_rsa_opportunitylob_value eq " + lOBId, true);
            req.setRequestHeader("OData-MaxVersion", "4.0");
            req.setRequestHeader("OData-Version", "4.0");
            req.setRequestHeader("Accept", "application/json");
            req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
            req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            req.onreadystatechange = function () {
                if (this.readyState === 4) {
                    req.onreadystatechange = null;
                    if (this.status === 200) {
                        var results = JSON.parse(this.response);
                        for (var i = 0; i < results.value.length; i++) {
                            var rsa_categories = results.value[i]["rsa_categories"];
                            var rsa_customlabelid = results.value[i]["rsa_customlabelid"];
                            var rsa_dependentoptionsetjson = results.value[i]["rsa_dependentoptionsetjson"];
                            var OptionSet = JSON.parse(results.value[i]["rsa_dependentoptionsetjson"]).ParentFieldDependency[0].OptionSet;
                            var LookUp = JSON.parse(results.value[i]["rsa_dependentoptionsetjson"]).ParentFieldDependency[0].LookUp;
                            var DecimalCurrencyfields = JSON.parse(results.value[i]["rsa_dependentoptionsetjson"]).ParentFieldDependency[0].DecimalCurrencyfields;


                            for (var i = 0; i < OptionSet.length; i++) {

                                var DependentField = OptionSet[i].DependentField;
                                var ApplicableValue = OptionSet[i].ApplicableValue;
                                var DefaultValue = OptionSet[i].DefaultValue;
                                var splitValue = ApplicableValue.split(",");

                                if (formContext.getAttribute(DependentField) !== null && formContext.getAttribute(DependentField) !== undefined) {
                                    var OptionSetValues = formContext.getAttribute(DependentField).getOptions();

                                    for (var k = 0; k < OptionSetValues.length; k++) {
                                        if (splitValue.indexOf(OptionSetValues[k].value.toString()) === -1) {
                                            formContext.getControl(DependentField).removeOption(OptionSetValues[k].value);
                                        }

                                    }
                                    if (DefaultValue !== null && DefaultValue !== undefined) {
                                        //Set the default value of the optionset
                                        if (formContext.ui.getFormType() === 1) {
                                            formContext.getAttribute(DependentField).setValue(DefaultValue);
                                        }
                                    }
                                }

                            }

                            //Set Default value for Decimal and Currency
                            for (var i = 0; i < DecimalCurrencyfields.length; i++) {

                                var DependentField = DecimalCurrencyfields[i].DependentField;
                                var DefaultValue = DecimalCurrencyfields[i].DefaultValue;

                                if (formContext.getAttribute(DependentField) !== null && formContext.getAttribute(DependentField) !== undefined) {

                                    if (DefaultValue !== null && DefaultValue !== undefined) {
                                        //Set the default value of the optionset
                                        if (formContext.ui.getFormType() === 1 && formContext.getAttribute(DependentField).getValue() === null) {
                                            formContext.getAttribute(DependentField).setValue(DefaultValue);
                                        }
                                    }
                                }
                            }

                            //Set the default value of the lookup 	
                            if (LookUp.length > 0) {
                                for (var i = 0; i < LookUp.length; i++) {
                                    var lookupDependentField = LookUp[i].lookupDependentField;
                                    var Entity = LookUp[i].lookupDefaultValue.Entity;
                                    var GUID = LookUp[i].lookupDefaultValue.GUID;
                                    var StatusName = LookUp[i].lookupDefaultValue.StatusName;

                                    var lookupDefaultValue = LookUp[i].lookupDefaultValue.rsa_statusname;
                                    if (formContext.getAttribute(lookupDependentField) !== null && formContext.getAttribute(lookupDependentField) !== undefined) {
                                        //Set  defualt Value for Option set 
                                        if (formContext.ui.getFormType() === 1) {
                                            formContext.getAttribute(lookupDependentField).setValue([{ id: GUID, name: StatusName, entityType: Entity }]);
                                        }

                                    }

                                }
                            }
                        }
                    }

                    else {
                        Xrm.Navigation.openAlertDialog({ text: "DependentOptionset : " + this.statusText });
                    }
                }
            };
            req.send();

        }
    }

    catch (err) {
        Xrm.Navigation.openAlertDialog({ text: " Option set value -" + err.message });
    }
}



function OptionSetAddRemove(executionContext) {
    try {
        formContext = executionContext.getFormContext();

        var InOpptyValues = formContext.getAttribute("rsa_opportunitytype").getValue()
        var InStageValues = formContext.getAttribute("rsa_stage").getText();

        var dependentStageValues = formContext.ui.controls.get("rsa_stage");
        var optionSetStageValues = dependentStageValues.getAttribute().getOptions();

        var dependentConfidenceStageValues = formContext.ui.controls.get("rsa_confidencestatus");
        var optionSetConfidenceStageValues = dependentConfidenceStageValues.getAttribute().getOptions();

        var dependentlostReasonValues = formContext.ui.controls.get("rsa_lostreason");
        var optionSetlostReasonValues = dependentlostReasonValues.getAttribute().getOptions();

        var dependentReasonDetailsValues = formContext.ui.controls.get("rsa_reasondetail");
        var optionSetReasonDetailsValues = dependentReasonDetailsValues.getAttribute().getOptions();
        var lostReasonValue = formContext.getAttribute("rsa_lostreason").getText();

        dependentStageValues.clearOptions();
        if (InStageValues !== null) {
            dependentlostReasonValues.clearOptions();
            dependentConfidenceStageValues.clearOptions();
            dependentReasonDetailsValues.clearOptions();
        }

        if (InStageValues !== null) {
            optionSetlostReasonValues.forEach(function (element) {
                if (InStageValues.includes("Closed Lost")) {
                    if (element.value === 866760002 || element.value === 866760000 || element.value === 866760001)
                        dependentlostReasonValues.addOption(element)
                }
                if (InStageValues.includes("Lapse")) {
                    if (element.value === 866760002 || element.value === 866760000 || element.value === 866760001)
                        dependentlostReasonValues.addOption(element)
                }
            }
            );
        }

        if (InStageValues !== null && lostReasonValue !== null) {
            optionSetReasonDetailsValues.forEach(function (element) {
                //Declined 
                if (lostReasonValue.includes("Declined")) {
                    if (element.value === 866760000 || element.value === 866760001 || element.value === 866760002 || element.value === 866760003 || element.value === 866760004 || element.value === 866760005 || element.value === 866760006 || element.value === 866760007 || element.value === 866760008 || element.value === 866760009 || element.value === 866760010 || element.value === 866760011 || element.value === 866760012 || element.value === 866760013)
                        dependentReasonDetailsValues.addOption(element)
                }
                //Not Taken Up
                if (lostReasonValue.includes(" Not Taken up")) {
                    if (element.value === 866760014 || element.value === 866760015 || element.value === 866760016 || element.value === 866760017 || element.value === 866760018 || element.value === 866760019 || element.value === 866760020)
                        dependentReasonDetailsValues.addOption(element)
                }
            }
            );
        }

        if (InOpptyValues !== null) {
            optionSetStageValues.forEach(function (element) {

                if (InOpptyValues === 866760000) {
                    if (element.value === 866760001 || element.value === 866760002 || element.value === 866760006 || element.value === 866760009 || element.value === 866760011)
                        dependentStageValues.addOption(element);
                }

                if (InOpptyValues === 866760001) {
                    if (element.value === 866760004 || element.value === 866760005 || element.value === 866760008)
                        dependentStageValues.addOption(element);
                }


            });
        }
        if (InStageValues !== null) {
            optionSetConfidenceStageValues.forEach(function (element) {

                if (InStageValues.includes("Closed Lost")) {//Ã‚ Closed LostÃ‚ 

                    if (element.value === 866760000)
                        dependentConfidenceStageValues.addOption(element);
                }

                if (InStageValues.includes("Closed Won")) {//Ã‚ Closed WonÃ‚ 
                    if (element.value === 866760002)
                        dependentConfidenceStageValues.addOption(element);
                }
                if (InStageValues.includes("Lapse")) { //Lapse
                    if (element.value === 866760000)
                        dependentConfidenceStageValues.addOption(element);
                }
                if (InStageValues.includes("Outstanding")) {//Ã‚ OutstandingÃ‚ 
                    if (element.value === 866760000 || element.value === 866760001 || element.value === 866760002)
                        dependentConfidenceStageValues.addOption(element);
                }
                if (InStageValues.includes("Renewed")) {//Renewed
                    if (element.value === 866760002)
                        dependentConfidenceStageValues.addOption(element);
                }
                if (InStageValues.includes("Submission In")) { //Submission In
                    if (element.value === 866760000 || element.value === 866760001 || element.value === 866760002)
                        dependentConfidenceStageValues.addOption(element);
                }
                if (InStageValues.includes("Quote Out")) { //Quoted out
                    if (element.value === 866760000 || element.value === 866760001 || element.value === 866760002)
                        dependentConfidenceStageValues.addOption(element);
                }

            }
            );
        }

    }
    catch (err) {
        Xrm.Navigation.openAlertDialog({ text: " A -" + err.message });
    }

}


//
//To filter RSA branch in accordance with RSA office

function branchToOffcie(executionContext) {
    try {
        formContext = executionContext.getFormContext();

        var InValues = formContext.getAttribute("rsa_rsaoffice").getValue()

        var dependentValues = formContext.ui.controls.get("rsa_rsabranch");
        var optionSetValues = dependentValues.getAttribute().getOptions();
        if (InValues !== null) {
            dependentValues.clearOptions();
            formContext.getAttribute("rsa_rsaoffice").addOnChange(function () { formContext.getAttribute("rsa_rsabranch").setValue(null) });


            optionSetValues.forEach(function (element) {

                if (InValues === 866760000) {
                    if (element.value === 866760002 || element.value === 866760012) {
                        dependentValues.addOption(element);
                    }
                }

                if (InValues === 866760001) {
                    if (element.value === 866760003) {
                        dependentValues.addOption(element);

                    }
                }
                if (InValues === 866760002) {
                    if (element.value === 866760001 || element.value === 866760005 || element.value === 866760006 || element.value === 866760008 || element.value === 866760009) {

                        dependentValues.addOption(element);
                    }

                }
                if (InValues === 866760003) {
                    if (element.value === 866760010) {
                        dependentValues.addOption(element);

                    }
                }
                if (InValues === 866760004) {
                    if (element.value === 866760000 || element.value === 866760004 || element.value === 866760007) {
                        dependentValues.addOption(element);

                    }
                }
            });
        }
    }
    catch (err) {
        Xrm.Navigation.openAlertDialog({ text: " A -" + err.message });
    }

}

/* Change Summary for April 2022 Release 1 */
/* Last Modified By: Shreya Diwate*/
/* Summary of Changes: Remove Debug Code*/
/* - Reason for Change: Unexpected 'debugger' statement */
/* - Function name - RedirectToExtensionOppty */

/* Change Summary for April 2022 Release 1 */
/* Last Modified By: Shreya Diwate*/
/* Summary of Changes: Replace Xrm.page with ExecutionContext.getFormContext*/
/* - Reason for Change:Xrm.page deprecated API*/
/* - Function name - RedirectToExtensionOppty */

function RedirectToExtensionOppty(PrimaryControl) {
    //debugger;
    var globalContext = Xrm.Utility.getGlobalContext();
    var formContext = PrimaryControl;

    var formParameters = {};



    if (formContext.data !== undefined && formContext.getAttribute("name") !== undefined && formContext.getAttribute("name") !== null) {

        formParameters["rsa_opportunity"] = formContext.data.entity.getId();
        formParameters["rsa_opportunityname"] = formContext.getAttribute("name").getValue();
        formParameters["rsa_opportunitytype"] = formContext.data.entity.getEntityName();
        formParameters["rsa_lineofbusiness"] = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].id;
        formParameters["rsa_lineofbusinessname"] = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].name;
        formParameters["rsa_lineofbusinesstype"] = formContext.getAttribute("rsa_lineofbusiness").getValue()[0].entityType;
        formParameters["rsa_name"] = formContext.getAttribute("name").getValue();
    }
    var opptyID = formContext.data.entity.getId().replace(/[{}]/g, '');
    var req = new XMLHttpRequest();

    //req.open("GET", Xrm.Page.context.getClientUrl() +
    req.open("GET", globalContext.getClientUrl() +
        "/api/data/v9.1/rsa_extensionopportunities?$select=_rsa_opportunity_value&$filter=_rsa_opportunity_value eq " + opptyID, false);
    req.setRequestHeader("OData-MaxVersion", "4.0");
    req.setRequestHeader("OData-Version", "4.0");
    req.setRequestHeader("Accept", "application/json");
    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
    req.onreadystatechange = function () {
        if (this.readyState === 4) {
            req.onreadystatechange = null;
            if (this.status === 200) {
                var results = JSON.parse(this.response);
                if (results.value.length === 0) {
                    var pageInput = {};
                    pageInput["pageType"] = "entityrecord";
                    pageInput["entityName"] = "rsa_extensionopportunity";
                    pageInput["formId"] = "A1ED7AD7-DFB9-4062-93C0-9FF5B960C61E";
                    pageInput["data"] = formParameters;
                }
                else {
                    var extensionId = results.value[0].rsa_extensionopportunityid;
                    var opportunity = results.value[0]["_rsa_opportunity_value"];
                    var opportunityName = results.value[0]["_rsa_opportunity_value@OData.Community.Display.V1.FormattedValue"];
                    var opportunityType = results.value[0]["_rsa_opportunity_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                    if (extensionId !== null && opportunityName === formContext.getAttribute("name").getValue()) {
                        var pageInput = {};
                        pageInput["pageType"] = "entityrecord";
                        pageInput["entityName"] = "rsa_extensionopportunity";
                        pageInput["entityId"] = extensionId;
                        pageInput["formId"] = "A1ED7AD7-DFB9-4062-93C0-9FF5B960C61E";
                        pageInput["data"] = formParameters;
                    }
                    else if ((extensionId === null || extensionId === undefined) && opportunityName === formContext.getAttribute("name").getValue()) {
                        var pageInput = {};
                        pageInput["pageType"] = "entityrecord";
                        pageInput["entityName"] = "rsa_extensionopportunity";
                        pageInput["formId"] = "7b36a2c7-1d4f-4caa-88e9-b6b453009026";
                        pageInput["data"] = formParameters;
                    }
                }

                var navigationOptions = {
                    target: 2,
                    height: { value: 80, unit: "%" },
                    width: { value: 80, unit: "%" },
                    position: 2
                };
                // Open the form.
                Xrm.Navigation.navigateTo(pageInput, navigationOptions).then(
                    function success(result) {


                    },

                    function (error) {
                        //console.log(error);
                    });

            }
        } else {
            //  Xrm.Utility.alertDialog(this.statusText);
            Xrm.Navigation.openAlertDialog({ text: "Error 1 " + this.statusText });

        }

    };
    req.send();

}




//SP
//Date:08012021
//Testing in Progress

/* Change Summary for April 2022 Release 1 */
/* Last Modified By: Shreya Diwate*/
/* Summary of Changes: Remove Debug Code*/
/* - Reason for Change: Unexpected 'debugger' statement */
/* - Function name - RedirectAccordingToLOB */

function RedirectAccordingToLOB(executionContext, triggerType) {
    //debugger;
    var formId, LOB, LOBid, opptyStageId, OpptyStageName;
    var formContext = executionContext.getFormContext();


    //formId = formContext.getAttribute("rsa_opportunityformid").getValue();
    //if (triggerType != "onchange") {
    // if (formId != null && formId != undefined) {
    //formContext.getAttribute("rsa_caseformid").setValue(null);
    //  return;
    // }
    // }

    var lobValue = formContext.getAttribute("rsa_lineofbusiness");
    if (lobValue.getValue() === null) {
        return;
    }
    if (lobValue.getValue() === null && formContext.ui.getFormType() === 2) {
        return;
    }

    if (formContext.ui.getFormType() === 1 && triggerType != "onchange") {
        return;
    }

    if (localStorage['OpptyTriggerType'] === "onchange") {
        var LineOfBusiness = localStorage["rsa_lineofbusiness"];

        var lookupValue = new Array();
        lookupValue[0] = new Object();
        lookupValue[0].id = LineOfBusiness;
        lookupValue[0].name = localStorage["rsa_lineofbusinessname"];
        lookupValue[0].entityType = "rsa_lineofbusiness";
        if (LineOfBusiness != undefined && LineOfBusiness != null && LineOfBusiness != "")
            formContext.getAttribute("rsa_lineofbusiness").setValue(lookupValue);
        localStorage['OpptyTriggerType'] = "";

    }
    else {
        var LineOfBusiness = lobValue.getValue()[0].id;
    }


    var securityMap = new Array();
    var req = new XMLHttpRequest();
    var globalContext = Xrm.Utility.getGlobalContext();
    var ClientUrl = globalContext.getClientUrl();
    req.open("GET", ClientUrl + "/api/data/v9.1/rsa_customlabels?$select=rsa_dependentoptionsetjson,rsa_name&$filter=rsa_name eq 'SecurityRole'", false);
    req.setRequestHeader("OData-MaxVersion", "4.0");
    req.setRequestHeader("OData-Version", "4.0");
    req.setRequestHeader("Accept", "application/json");
    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
    req.onreadystatechange = function () {
        if (this.readyState === 4) {
            req.onreadystatechange = null;
            if (this.status === 200) {
                var results = JSON.parse(this.response);
                for (var i = 0; i < results.value.length; i++) {
                    var rsa_categories = results.value[i]["rsa_categories"];
                    var rsa_dependentoptionsetjson = results.value[i]["rsa_dependentoptionsetjson"];
                    var SecurityRoleMapping = JSON.parse(results.value[i]["rsa_dependentoptionsetjson"]).SecurityRoleMapping;
                    var roles = Xrm.Utility.getGlobalContext().userSettings.securityRoles;
                    for (var i = 0; i < roles.length; i++) {
                        var GUID = Xrm.Utility.getGlobalContext().userSettings.securityRoles[i];
                        SecurityRoleMapping.forEach(function (item) {
                            if (item.SecurityRoleGUID.toLowerCase() == GUID.toLowerCase())
                                securityMap.push(item.SecurityRoleValue);
                        });
                    }
                }
            }
            else {
                Xrm.Navigation.openAlertDialog({ text: "Get Security Role Mapping: " + this.statusText });
            }
        }
    };
    req.send();
    var securityRoleMappingStr = '';
    for (var k = 0; k < securityMap.length; k++) {
        securityRoleMappingStr += "<value>" + securityMap[k] + "</value>"
    }


    var fetchXmlQuery = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
        "<entity name='rsa_formlayoutmapping'>" +
        "<attribute name='rsa_formlayoutmappingid' />" +
        "<attribute name='rsa_name' />" +
        "<attribute name='rsa_lineofbusiness' />" +
        "<attribute name='rsa_securityrolemapping' />" +
        "<attribute name='rsa_form' />" +
        "<order attribute='rsa_name' descending='false' />" +
        "<filter type='and'>" +
        "<condition attribute='rsa_lineofbusiness'  operator='eq' value='" + LineOfBusiness + "' />" +
        "<condition attribute='rsa_securityrolemapping' operator='contain-values'>" + securityRoleMappingStr +
        "</condition></filter>" +
        "<link-entity name='rsa_formlayout' from='rsa_formlayoutid' to='rsa_form' link-type='inner' alias='ae'>" +
        "<attribute name='rsa_formid'/>" +
        "<filter type='and'>" +
        "<condition attribute='rsa_entityname' operator='eq' value='866760000' />" +   ///Check 1
        "</filter>" +
        "</link-entity>" +
        "</entity>" +
        "</fetch>";
    var req = new XMLHttpRequest();
    var globalContext = Xrm.Utility.getGlobalContext();
    var ClientUrl = globalContext.getClientUrl();
    req.open("GET", ClientUrl + "/api/data/v9.1/rsa_formlayoutmappings?fetchXml=" + encodeURIComponent(fetchXmlQuery), false);
    req.setRequestHeader("Prefer", 'odata.include-annotations="*"');
    req.onreadystatechange = function () {
        if (this.readyState === 4) {

            req.onreadystatechange = null;

            if (this.status === 200) {
                var results = JSON.parse(this.response);

                if (results.value.length > 0) {
                    formId = results.value[0]["ae.rsa_formid"];
                    LOB = results.value[0]["_rsa_lineofbusiness_value@OData.Community.Display.V1.FormattedValue"];
                    LOBid = results.value[0]["_rsa_lineofbusiness_value"];

                    if (triggerType === "onchange") {
                        localStorage['OpptyTriggerType'] = "onchange";
                        localStorage["rsa_lineofbusiness"] = LOBid;
                        localStorage["rsa_lineofbusinessname"] = LOB;
                        localStorage["rsa_lineofbusinesstype"] = "rsa_lineofbusiness";
                    }
                    else {
                        localStorage['OpptyTriggerType'] = "";
                    }

                    if (formId !== null) {
                        var entityFormOptions = {};
                        entityFormOptions["entityName"] = "opportunity";
                        entityFormOptions["formId"] = formId;
                        entityFormOptions["entityId"] = formContext.data.entity.getId();

                    }
                    try {
                        var navigatedformId = formContext.ui.formSelector.getCurrentItem().getId();
                        if (navigatedformId.toLowerCase() === formId.toLowerCase()) {
                            return;
                        }
                    }
                    catch (err) {
                        Xrm.Navigation.openAlertDialog({ text: "OpportunityFormID -" + err.message });
                    }
                    //   formContext.getAttribute("rsa_opportunityformid").setValue(formId);
                    //   formContext.data.entity.save();
                    var formParameters = {};

                    formParameters["rsa_lineofbusiness"] = LOBid;
                    //formParameters["rsa_opportunityformid"] = formId;
                    formParameters["rsa_lineofbusinessname"] = LOB;
                    formParameters["rsa_lineofbusinesstype"] = "rsa_lineofbusiness";


                    // Open the form.
                    // Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
                    // function success(result) {

                    // //  formContext.getAttribute("rsa_opportunityformid").setValue(formId);


                    // //   formContext.data.entity.save();

                    // },
                    // function (error) {
                    // //console.log(error);
                    // });

                    formContext.ui.formSelector.items.get(formId.toLowerCase()).navigate();
                }

            } else {
                //Xrm.Navigation.openAlertDialog(this.statusText);
                Xrm.Navigation.openAlertDialog({ text: "Error 2 " + this.statusText });
            }
        }
    };
    req.send();
}




