﻿"use strict";

var RSA = window.RSA || { __namespace: true, __typeName: "RSA" };
RSA.D365CRM = RSA.D365CRM || { __namespace: true, __typeName: "RSA.D365CRM" };
RSA.D365CRM.Contact = RSA.D365CRM.Contact || { __namespace: true, __typeName: "RSA.D365CRM.Contact" };
RSA.D365CRM.Contact.Main = RSA.D365CRM.Contact.Main || ({
    FormType: {
        Create: 1,
        Update: 2,
        ReadOnly: 3,
        Disabled: 4,
        BulkEdit: 6
    },

    OnLoad: function (executionContext) {
        RSA.D365CRM.Contact.Main.ShowAddressDetails(executionContext);
    },

    ShowAddressDetails: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var formType = formContext.ui.getFormType();
        if (formType != undefined) {
            if (formType == 1) { //if form is of type "Create"    
                formContext.getAttribute("rsa_updateaddressfrom").setValue(100000000);
                var BrokerLookupValue = formContext.getAttribute("rsa_accountid").getValue();
                if (BrokerLookupValue != null) {
                    var agencyId = BrokerLookupValue[0].id;
                    Xrm.WebApi.online.retrieveRecord("account", agencyId).then(
                        function (result) {
                            var Address1 = result["address1_line1"];
                            var PostalCode = result["address1_postalcode"];
                            var AddressCity = result["address1_city"];
                            if (Address1 != null)
                                formContext.getAttribute("address1_line1").setValue(Address1);
                            if (PostalCode!= null)
                                formContext.getAttribute("address1_city").setValue(AddressCity);
                            if (AddressCity != null)
                                formContext.getAttribute("address1_postalcode").setValue(PostalCode);


                        }
                    )


                }
            }
            if (formType == 2) {// Update Mode
                RSA.D365CRM.Contact.Main.setDisableEnable(executionContext);
            }
        }
    },

    setDisableEnable: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var updateAddrOptionVal = formContext.getAttribute("rsa_updateaddressfrom").getValue();
        if (updateAddrOptionVal != null) {
            formContext.ui.controls.get("address1_line1").setDisabled(true);            
            formContext.ui.controls.get("address1_city").setDisabled(true);
            formContext.ui.controls.get("address1_postalcode").setDisabled(true);           
        }
        else {
            formContext.ui.controls.get("address1_line1").setDisabled(false);           
            formContext.ui.controls.get("address1_city").setDisabled(false);
            formContext.ui.controls.get("address1_postalcode").setDisabled(false);           
        }
    } 
})