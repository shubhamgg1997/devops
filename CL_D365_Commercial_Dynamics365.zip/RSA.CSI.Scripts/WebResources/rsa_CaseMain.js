"use strict";



//Author : Chandani Vaishnani
//Date : 11 Aug 2020
//This Function Open the Page According to Case Type
/* Change Summary for April 2022 Release 1 */
/* Last Modified By: Bubun Bhandari*/
/* Summary of Changes: Unexpected 'debugger' statement-MS Code Review*/
/* - Reason for Change: Remove Debug Code*/
/* - Function name - RedirectToPageLayoutBasedOnCaseType */
function RedirectToPageLayoutBasedOnCaseType(PrimaryControl, key) {

    var securityMap = new Array();
    var req = new XMLHttpRequest();
    var globalContext = Xrm.Utility.getGlobalContext();
    var ClientUrl = globalContext.getClientUrl();

    req.open("GET", ClientUrl + "/api/data/v9.1/rsa_customlabels?$select=rsa_dependentoptionsetjson,rsa_name&$filter=rsa_name eq 'SecurityRole'", false);
    req.setRequestHeader("OData-MaxVersion", "4.0");
    req.setRequestHeader("OData-Version", "4.0");
    req.setRequestHeader("Accept", "application/json");
    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
    req.onreadystatechange = function () {
        if (this.readyState === 4) {
            req.onreadystatechange = null;
            if (this.status === 200) {
                var results = JSON.parse(this.response);
                for (var i = 0; i < results.value.length; i++) {
                    var rsa_categories = results.value[i]["rsa_categories"];
                    var rsa_dependentoptionsetjson = results.value[i]["rsa_dependentoptionsetjson"];
                    var SecurityRoleMapping = JSON.parse(results.value[i]["rsa_dependentoptionsetjson"]).SecurityRoleMapping;
                    var roles = Xrm.Utility.getGlobalContext().userSettings.securityRoles;

                    for (var i = 0; i < roles.length; i++) {
                        var GUID = Xrm.Utility.getGlobalContext().userSettings.securityRoles[i];
                        SecurityRoleMapping.forEach(function (item) {
                            if (item.SecurityRoleGUID.toLowerCase() == GUID.toLowerCase())
                                securityMap.push(item.SecurityRoleValue);
                        });
                    }
                }
            }
            else {
                Xrm.Navigation.openAlertDialog({ text: "Get Security Role Mapping: " + this.statusText });
            }
        }
    };
    req.send();

    var securityRoleMappingStr = '';
    for (var k = 0; k < securityMap.length; k++) {
        securityRoleMappingStr += "<value>" + securityMap[k] + "</value>"
    }


    var formContext = PrimaryControl;

    var formId, caseTypeName, caseTypeId, casestatusId, casestatusName, caseorigin;
    var fetchXmlQuery = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
            "<entity name='rsa_formlayoutmapping'>" +
            "<attribute name='rsa_formlayoutmappingid' />" +
            "<attribute name='rsa_name' />" +
            "<attribute name='rsa_casetype' />" +
            "<attribute name='rsa_securityrolemapping' />" +
            "<attribute name='rsa_form' />" +
            "<order attribute='rsa_name' descending='false' />" +
            "<filter type='and'>" +
            "<condition attribute='rsa_formidentifier' operator='eq' value='" + key + "' />" +
            "<condition attribute='rsa_securityrolemapping' operator='contain-values'>" + securityRoleMappingStr +
            "</condition></filter>" +
            "<link-entity name='rsa_formlayout' from='rsa_formlayoutid' to='rsa_form' link-type='inner' alias='ae'>" +
            "<attribute name='rsa_formid'/>" +
            "<filter type='and'>" +
            "<condition attribute='rsa_entityname' operator='eq' value='866760001' />" +
            "</filter>" +
            "</link-entity>" +
            "</entity>" +
            "</fetch>";

    var req = new XMLHttpRequest();
    var globalContext = Xrm.Utility.getGlobalContext();
    var ClientUrl = globalContext.getClientUrl();
    req.open("GET", ClientUrl + "/api/data/v9.1/rsa_formlayoutmappings?fetchXml=" + encodeURIComponent(fetchXmlQuery), true);
    req.setRequestHeader("Prefer", 'odata.include-annotations="*"');
    req.onreadystatechange = function () {
        if (this.readyState === 4) {
            req.onreadystatechange = null;
            if (this.status === 200) {
                var results = JSON.parse(this.response);
                if (results.value.length > 0) {
                    formId = results.value[0]["ae.rsa_formid"];
                    caseTypeName = results.value[0]["_rsa_casetype_value@OData.Community.Display.V1.FormattedValue"];
                    caseTypeId = results.value[0]["_rsa_casetype_value"];

                    if (formId !== null) {
                        var entityFormOptions = {};
                        entityFormOptions["entityName"] = "incident";
                        entityFormOptions["formId"] = formId;
                        entityFormOptions["rsa_casetype"] = caseTypeId;

                        var formParameters = {};
                        if (caseTypeName !== null && caseTypeId !== null) {
                            formParameters["rsa_casetype"] = caseTypeId;
                            //formParameters["rsa_caseformid"] = formId;
                            formParameters["rsa_casetypename"] = caseTypeName;
                            formParameters["rsa_casetypetype"] = "rsa_casetype";

                            //Populate Opportunity Data
                            if (formContext.data !== undefined && formContext.getAttribute("name") !== undefined && formContext.getAttribute("name") !== null && formContext.data.entity.getEntityName() === "opportunity") {
                                formParameters["rsa_opportunityid"] = formContext.data.entity.getId();
                                formParameters["rsa_opportunityidname"] = formContext.getAttribute("name").getValue();
                                formParameters["rsa_opportunityidtype"] = formContext.data.entity.getEntityName();

                                //Populate Broker present in opportunity in Case Layout
                                if (formContext.data !== undefined && formContext.getAttribute("parentaccountid") !== undefined && formContext.getAttribute("parentaccountid") !== null && formContext.getAttribute("parentaccountid").getValue() !== undefined && formContext.getAttribute("parentaccountid").getValue() !== null) {
                                    formParameters["rsa_account"] = formContext.getAttribute("parentaccountid").getValue()[0].id;
                                    formParameters["rsa_accountname"] = formContext.getAttribute("parentaccountid").getValue()[0].name;
                                    formParameters["rsa_accounttype"] = "account";
                                }
                            }
                            if (formContext.data !== undefined && formContext.getAttribute("name") !== undefined && formContext.getAttribute("name") !== null && formContext.data.entity.getEntityName() === "account") {
                                formParameters["rsa_account"] = formContext.data.entity.getId();
                                formParameters["rsa_accountname"] = formContext.getAttribute("name").getValue();
                                formParameters["rsa_accounttype"] = "account";
                            }

                            if (formContext.data !== undefined && formContext.getAttribute("rsa_name") !== undefined && formContext.getAttribute("rsa_name") !== null && formContext.data.entity.getEntityName() === "rsa_policy") {
                                formParameters["rsa_policyid"] = formContext.data.entity.getId();
                                formParameters["rsa_policyidname"] = formContext.getAttribute("rsa_name").getValue();
                                formParameters["rsa_policyidtype"] = formContext.data.entity.getEntityName();
                            }
                            if (formContext.data !== undefined && formContext.getAttribute("rsa_name") !== undefined && formContext.getAttribute("rsa_name") !== null && formContext.data.entity.getEntityName() === "rsa_customer") {
                                formParameters["rsa_customerrsa"] = formContext.data.entity.getId();
                                formParameters["rsa_customerrsaname"] = formContext.getAttribute("rsa_name").getValue();
                                formParameters["rsa_customerrsatype"] = "rsa_customer";
                            }
                            //Sumegh Dhole : 22 June 2021 : Fix for opportunity to populate policy on case 
                            if (formContext.data !== undefined && formContext.getAttribute("rsa_policyid") !== undefined && formContext.getAttribute("rsa_policyid") !== null && formContext.data.entity.getEntityName() === "opportunity") {
                                if (formContext.getAttribute("rsa_policyid").getValue() != null && formContext.getAttribute("rsa_policyid").getValue() != undefined) {
                                    formParameters["rsa_policyid"] = formContext.getAttribute("rsa_policyid").getValue()[0].id;
                                    formParameters["rsa_policyidname"] = formContext.getAttribute("rsa_policyid").getValue()[0].name;
                                    formParameters["rsa_policyidtype"] = "rsa_policy";
                                }
                            }

                        }

                        // Open the form.
                        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
                            function (success) {
                                //console.log(success);
                            },
                            function (error) {
                                //console.log(error);
                            });
                    }
                }
            } else {
                Xrm.Navigation.openAlertDialog(this.statusText);
            }
        }
    };
    req.send();
}

function SelectCaseTypeBasedOnForm(excecutionContext) {
    var formContext = excecutionContext.getFormContext();
    if (formContext.ui.getFormType() === 1) {
        var formName = formContext.ui.formSelector.getCurrentItem().getId().toUpperCase();
        var id;
        if (formContext.getAttribute("rsa_casetype") !== null && formContext.getAttribute("rsa_casetype") !== undefined) {
            if (formName === "A38B8090-2DC3-46C0-8932-58F52E6C7EBB") // New-Business
            {
                formContext.getAttribute("rsa_casetype").setValue([{ id: "146DD87C-57BC-EA11-A812-000D3AF01A07", name: "New Business", entityType: "rsa_casetype" }]);
                id = "146DD87C-57BC-EA11-A812-000D3AF01A07";
            }
            else if (formName === "7C44CA34-32CA-4B9E-B775-9FA7208A2C7F") //Insurance Referral Layout
            {
                formContext.getAttribute("rsa_casetype").setValue([{ id: "0e6dd87c-57bc-ea11-a812-000d3af01a07", name: "Insurance Referral", entityType: "rsa_casetype" }]);
                id = "0e6dd87c-57bc-ea11-a812-000d3af01a07";
            }
            else if (formName === "39F72337-E644-4FA2-88A0-9B329657BC17") //Agency Request
            {
                formContext.getAttribute("rsa_casetype").setValue([{ id: "fa6cd87c-57bc-ea11-a812-000d3af01a07", name: "Agency Request", entityType: "rsa_casetype" }]);
                id = "fa6cd87c-57bc-ea11-a812-000d3af01a07";
            }
        }
        id = ConvertGuid(id);
        var req = new XMLHttpRequest();
        var globalContext = Xrm.Utility.getGlobalContext();
        var ClientUrl = globalContext.getClientUrl();
        req.open("GET", ClientUrl + "/api/data/v9.1/rsa_statuses?$select=rsa_name,rsa_statusid&$filter=rsa_statuscode eq 866760000 and  _rsa_casetype_value eq " + id, true);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    var results = JSON.parse(this.response);
                    for (var i = 0; i < results.value.length; i++) {
                        var statusName = results.value[i]["rsa_name"];
                        var Statusid = results.value[i]["rsa_statusid"];
                        if (statusName !== null && Statusid !== null && formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_status") !== undefined) {
                            formContext.getAttribute("rsa_status").setValue([{ id: Statusid, name: statusName, entityType: "rsa_status" }]);
                        }
                    }
                } else {
                    Xrm.Navigation.openAlertDialog(this.statusText);
                }
            }
        };
        req.send();
    }
}

function ConvertGuid(str) {
    if (str) {
        str = str.replace(/[{}]/g, '');
        str = str.toUpperCase();
    }
    return str;
}

function switchFormsBasedOnCaseType(excecutionContext) {
    var formContext = excecutionContext.getFormContext();

    var caseTypeName = formContext.getAttribute('rsa_casetype').getValue()[0].name;
    var formId;
    if (caseTypeName === "Agency Request") {
        formId = "39F72337-E644-4FA2-88A0-9B329657BC17";
    }
    else if (caseTypeName === "Computer (e–Traded) New Business") {
        formId = "BE6FF496-7AEC-438E-9A30-02588DF68B96";
    }
    else if (caseTypeName === "Computer (e–Traded) Renewal") {
        formId = "2D9465EB-4A16-43C2-BA0A-B63DDAEAE0BC";
    }


    var entityFormOptions = {};
    entityFormOptions["entityName"] = "incident";
    entityFormOptions["formId"] = formId;

    // Set default values for the Contact form
    var formParameters = {};

    formParameters["title"] = formContext.getAttribute('title').getValue();

    // Open the form.
    Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
        function (success) {
            //console.log(success);
        },
        function (error) {
            //console.log(error);
        });
}

function openMainForm(excecutionContext) {
    var formContext = excecutionContext.getFormContext();
    var entityFormOptions = {};
    entityFormOptions["entityName"] = "incident";
    entityFormOptions["formId"] = "6D980945-B0EC-44A7-A3FF-6AC60FB9E66A";

    var formParameters = {};

    if (formContext.getAttribute("title").getValue() === null) {
        // Open the form.
        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
            function (success) {
                //console.log(success);
            },
            function (error) {
                //console.log(error);
            });
    }
}



//Modified By : Pooja Raje
//Date : 16 December 2020
//This Function Open the Close Case Forms According to Case Type and Restrict Case resolution if activities are open
/* Change Summary for April 2022 Release 1 */
/* Last Modified By: Bubun Bhandari*/
/* Summary of Changes: Remove Debug Code,add Xrm.Navigation.openAlertDialog instead of Xrm.Utility.alertDialog and add formContext instead of Xrm.Page*/
/* - Reason for Change: Unexpected 'debugger' statement and Xrm.Utility.alertDialog and Xrm.Page use in code  -MS Code Review  */
/* - Function name - RedirectToCloseFormOnCaseType */
function RedirectToCloseFormOnCaseType(PrimaryControl) {

    localStorage["closeCase"] = true;
    var formContext = PrimaryControl;
    var closecaseformId, caseTypeName, caseTypeId, casestatusId, casestatusName, caseorigin;
    var caseType = formContext.data.entity.attributes.get('rsa_casetype').getValue()[0].name;
    caseTypeId = formContext.data.entity.attributes.get('rsa_casetype').getValue()[0].id;

    //var CaseID = Xrm.Page.data.entity.getId().replace(/[{}]/g, '');
    var CaseID = formContext.data.entity.getId().replace(/[{}]/g, '');
    var fetchXmlQueryforActivityStatus = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
     "<entity name='activitypointer'>" +
    "<attribute name='activitytypecode' />" +
    "<attribute name='subject' />" +
    "<attribute name='statecode' />" +
    "<attribute name='prioritycode' />" +
    "<attribute name='modifiedon' />" +
    "<attribute name='activityid' />" +
    "<attribute name='instancetypecode' />" +
    "<attribute name='community' />" +
    "<order attribute='modifiedon' descending='false' />" +
	"<filter type='and'>" +
      "<condition attribute='activitytypecode' operator='eq' value='4212' />" +
    "</filter>" +
    "<filter type='and'>" +
     "<condition attribute='statecode' operator='eq' value='0' />" +
    "</filter>" +
    "<link-entity name='incident' from='incidentid' to='regardingobjectid' link-type='inner' alias='ad'>" +
      "<filter type='and'>" +
        "<condition attribute='incidentid' operator='eq' uitype='incident' value='" + CaseID + "' />" +
      "</filter>" +
    "</link-entity>" +
  "</entity>" +
"</fetch>";


    var req_status = new XMLHttpRequest();
    var globalContext = Xrm.Utility.getGlobalContext();
    var ClientUrl = globalContext.getClientUrl();
    req_status.open("GET", ClientUrl + "/api/data/v9.1/activitypointers?fetchXml=" + encodeURIComponent(fetchXmlQueryforActivityStatus), true);
    req_status.setRequestHeader("OData-MaxVersion", "4.0");
    req_status.setRequestHeader("OData-Version", "4.0");
    req_status.setRequestHeader("Accept", "application/json");
    req_status.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
    req_status.onreadystatechange = function () {
        if (this.readyState === 4) {
            req_status.onreadystatechange = null;
            if (this.status === 200) {
                var Activity_results = JSON.parse(this.response);
                if (Activity_results.value.length > 0) {
                    Xrm.Navigation.openAlertDialog("The case cannot be closed as all activities related to this case are not completed.");
                    return;
                }
                else {
                    var fetchXmlQuery = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
           "<entity name='rsa_formlayoutmapping'>" +
           "<attribute name='rsa_formlayoutmappingid' />" +
           "<attribute name='rsa_name' />" +
           "<attribute name='rsa_casetype' />" +
           "<attribute name='rsa_form' />" +
           "<order attribute='rsa_name' descending='false' />" +
            "<filter type='and'>" +
            "<condition attribute='rsa_casetype' value='" + caseTypeId + "' uitype='rsa_casetype'  operator='eq'/>" +
           "</filter>" +
           "<link-entity name='rsa_formlayout' from='rsa_formlayoutid' to='rsa_form' link-type='inner' alias='ae'>" +
            "<attribute name='rsa_closecaseformid'/>" +
           "<filter type='and'>" +
           "<condition attribute='rsa_entityname' operator='eq' value='866760001' />" +
           "</filter>" +
           "</link-entity>" +
           "</entity>" +
           "</fetch>";

                    var req = new XMLHttpRequest();
                    var globalContext = Xrm.Utility.getGlobalContext();
                    var ClientUrl = globalContext.getClientUrl();
                    req.open("GET", ClientUrl + "/api/data/v9.1/rsa_formlayoutmappings?fetchXml=" + encodeURIComponent(fetchXmlQuery), true);
                    req.setRequestHeader("Prefer", 'odata.include-annotations="*"');
                    req.onreadystatechange = function () {
                        if (this.readyState === 4) {
                            req.onreadystatechange = null;
                            if (this.status === 200) {
                                var results = JSON.parse(this.response);
                                if (results.value.length > 0) {
                                    closecaseformId = results.value[0]["ae.rsa_closecaseformid"];
                                    caseTypeName = results.value[0]["_rsa_casetype_value@OData.Community.Display.V1.FormattedValue"];


                                    if (closecaseformId !== null && caseType == caseTypeName) {

                                        var pageInput = {};
                                        pageInput["pageType"] = "entityrecord";
                                        pageInput["entityName"] = "incident";
                                        pageInput["entityId"] = formContext.data.entity.getId();
                                        pageInput["formId"] = closecaseformId;

                                        var navigationOptions = {
                                            target: 2,
                                            height: { value: 80, unit: "%" },
                                            width: { value: 60, unit: "%" },
                                            position: 2
                                        };
                                        // Open the form.
                                        Xrm.Navigation.navigateTo(pageInput, navigationOptions).then(
                                             function success(result) {
                                                 //console.log(success);
                                                 // alert("Saved!")
                                                 formContext.data.save();
                                             },

                                             function (error) {
                                                 //console.log(error);
                                             });
                                    }
                                }
                            }
                            else {
                                Xrm.Navigation.openAlertDialog(this.statusText);
                            }
                        }
                    };
                    req.send();
                    formContext.data.save();
                }

            } else {
                Xrm.Navigation.openAlertDialog(this.statusText);
            }
        }
    };
    req_status.send();
}

function HideButtonForCloseCase(PrimaryControl) {

    var formContext = PrimaryControl;
    if (formContext.ui != undefined) {
        var formId = formContext.ui.formSelector.getCurrentItem().getId().toUpperCase();
        if (formId === "DECEBED0-F2F8-47A6-BF5A-32A953B3EF91" || formId === "98B24A36-4010-464D-84EB-6BC5EF0D50CE" || formId === "D85C6207-DCAC-4A69-94AD-7DF2DDB8C023")
            return false;
        else
            return true;
    } else {
        return true;
    }
}

function HideButtonForpreporocessing(PrimaryControl) {
    var formContext = PrimaryControl;
    var formId = formContext.ui.formSelector.getCurrentItem().getId().toUpperCase()
    if (formId == "16597900-ED7D-43F3-B9D0-DBB7F1518938")
        return false;
    else
        return true;
}

/* Change Summary for April 2022 Release 1 */
/* Last Modified By: Bubun Bhandari*/
/* Summary of Changes: Unexpected 'debugger' statement-MS Code Review*/
/* - Reason for Change: Remove Debug Code*/
/* - Function name - RedirectAccordingToCaseType */
function RedirectAccordingToCaseType(executionContext, triggerType) {

    var formId, caseTypeName, caseTypeId, casestatusId, casestatusName, caseorigin;
    var formContext = executionContext.getFormContext();

    /* formId = formContext.getAttribute("rsa_caseformid").getValue();
	if(triggerType != "onchange"){
	if(formId != null && formId != undefined){
		//formContext.getAttribute("rsa_caseformid").setValue(null);
		return;
	}
	} */
    if (localStorage["closeCase"] == "true") {
        localStorage["closeCase"] = false;
        return;
    }

    var caseTypevalue = formContext.getAttribute("rsa_casetype");
    if (caseTypevalue.getValue() === null) {
        return;
    }
    if (caseTypevalue.getValue() === null && formContext.ui.getFormType() === 2) {
        return;
    }

    if (formContext.ui.getFormType() === 1 && triggerType != "onchange") {
        return;
    }

    if (localStorage['CaseTriggerType'] === "onchange") {
        var caseType = localStorage["rsa_casetype"];

        var lookupValue = new Array();
        lookupValue[0] = new Object();
        lookupValue[0].id = caseType;
        lookupValue[0].name = localStorage["rsa_casetypename"];
        lookupValue[0].entityType = "rsa_casetype";
        if (caseType != undefined && caseType != null && caseType != "")
            formContext.getAttribute("rsa_casetype").setValue(lookupValue);
        localStorage['CaseTriggerType'] = "";

    }
    else {
        var caseType = caseTypevalue.getValue()[0].id;
    }


    var securityMap = new Array();
    var req = new XMLHttpRequest();
    var globalContext = Xrm.Utility.getGlobalContext();
    var ClientUrl = globalContext.getClientUrl();
    req.open("GET", ClientUrl + "/api/data/v9.1/rsa_customlabels?$select=rsa_dependentoptionsetjson,rsa_name&$filter=rsa_name eq 'SecurityRole'", false);
    req.setRequestHeader("OData-MaxVersion", "4.0");
    req.setRequestHeader("OData-Version", "4.0");
    req.setRequestHeader("Accept", "application/json");
    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
    req.onreadystatechange = function () {
        if (this.readyState === 4) {
            req.onreadystatechange = null;
            if (this.status === 200) {
                var results = JSON.parse(this.response);
                for (var i = 0; i < results.value.length; i++) {
                    var rsa_categories = results.value[i]["rsa_categories"];
                    var rsa_dependentoptionsetjson = results.value[i]["rsa_dependentoptionsetjson"];
                    var SecurityRoleMapping = JSON.parse(results.value[i]["rsa_dependentoptionsetjson"]).SecurityRoleMapping;
                    var roles = Xrm.Utility.getGlobalContext().userSettings.securityRoles;
                    for (var i = 0; i < roles.length; i++) {
                        var GUID = Xrm.Utility.getGlobalContext().userSettings.securityRoles[i];
                        SecurityRoleMapping.forEach(function (item) {
                            if (item.SecurityRoleGUID.toLowerCase() == GUID.toLowerCase())
                                securityMap.push(item.SecurityRoleValue);
                        });
                    }
                }
            }
            else {
                Xrm.Navigation.openAlertDialog({ text: "Get Security Role Mapping: " + this.statusText });
            }
        }
    };
    req.send();
    var securityRoleMappingStr = '';
    for (var k = 0; k < securityMap.length; k++) {
        securityRoleMappingStr += "<value>" + securityMap[k] + "</value>";
    }


    var fetchXmlQuery = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
        "<entity name='rsa_formlayoutmapping'>" +
        "<attribute name='rsa_formlayoutmappingid' />" +
        "<attribute name='rsa_name' />" +
        "<attribute name='rsa_casetype' />" +
		"<attribute name='rsa_securityrolemapping' />" +
				"<attribute name='rsa_form' />" +
				"<order attribute='rsa_name' descending='false' />" +
		"<filter type='and'>" +
				"<condition attribute='rsa_casetype'  operator='eq' value='" + caseType + "' />" +
		"<condition attribute='rsa_securityrolemapping' operator='contain-values'>" + securityRoleMappingStr +
		"</condition></filter>" +
        "<link-entity name='rsa_formlayout' from='rsa_formlayoutid' to='rsa_form' link-type='inner' alias='ae'>" +
        "<attribute name='rsa_formid'/>" +
        "<filter type='and'>" +
        "<condition attribute='rsa_entityname' operator='eq' value='866760001' />" +
        "</filter>" +
        "</link-entity>" +
        "</entity>" +
        "</fetch>";
    var req = new XMLHttpRequest();
    var globalContext = Xrm.Utility.getGlobalContext();
    var ClientUrl = globalContext.getClientUrl();
    req.open("GET", ClientUrl + "/api/data/v9.1/rsa_formlayoutmappings?fetchXml=" + encodeURIComponent(fetchXmlQuery), false);
    req.setRequestHeader("Prefer", 'odata.include-annotations="*"');
    req.onreadystatechange = function () {
        if (this.readyState === 4) {
            req.onreadystatechange = null;
            if (this.status === 200) {
                var results = JSON.parse(this.response);
                if (results.value.length > 0) {
                    formId = results.value[0]["ae.rsa_formid"];
                    caseTypeName = results.value[0]["_rsa_casetype_value@OData.Community.Display.V1.FormattedValue"];
                    caseTypeId = results.value[0]["_rsa_casetype_value"];

                    if (triggerType === "onchange") {
                        localStorage['CaseTriggerType'] = "onchange";
                        localStorage["rsa_casetype"] = caseTypeId;
                        localStorage["rsa_casetypename"] = caseTypeName;
                        localStorage["rsa_casetypetype"] = "rsa_casetype";
                    }
                    else {
                        localStorage['CaseTriggerType'] = "";
                    }


                    if (formId !== null) {
                        var entityFormOptions = {};
                        entityFormOptions["entityName"] = "incident";
                        entityFormOptions["formId"] = formId;
                        entityFormOptions["entityId"] = formContext.data.entity.getId();

                    }

                    try {
                        var navigatedformId = formContext.ui.formSelector.getCurrentItem().getId();
                        if (navigatedformId.toLowerCase() === formId.toLowerCase()) {
                            return;
                        }
                    }
                    catch (err) {
                        Xrm.Navigation.openAlertDialog({ text: "CaseFormID -" + err.message });
                    }
                    //formContext.getAttribute("rsa_caseformid").setValue(formId);
                    //   formContext.data.entity.save();
                    var formParameters = {};

                    formParameters["rsa_casetype"] = caseTypeId;
                    // formParameters["rsa_caseformid"] = formId;
                    formParameters["rsa_casetypename"] = caseTypeName;
                    formParameters["rsa_casetypetype"] = "rsa_casetype";


                    // Open the form.
                    // Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
                    // function success(result) {

                    // },
                    // function (error) {

                    // });

                    formContext.ui.formSelector.items.get(formId.toLowerCase()).navigate();
                }

            } else {
                Xrm.Navigation.openAlertDialog(this.statusText);
            }
        }
    };
    req.send();
}
/* Change Summary for April 2022 Release 1 */
/* Last Modified By: Bubun Bhandari*/
/* Summary of Changes: formContext instead of Xrm.Page*/
/* - Reason for Change: Xrm.Page use in code  -MS Code Review  */
/* - Function name - RedirectToCloseFormOnCaseType */
function CallAction(PrimaryControl) {
    var formContext = PrimaryControl;
    var actionName = "rsa_CaseAssignAction";
    var confirmStrings = { text: "Do you want to Assign this Case?", title: "Confirm", confirmButtonLabel: "Yes", cancelButtonLabel: "Cancel", subtitle: "Assign Case" };
    var confirmOptions = { height: 200, width: 300 };
    Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
	function (success) {
	    if (success.confirmed) {
              //Defect 2675 : assign case button not working in production environment - Sumegh Dhole - 26 Mar 2022
                //activateCustomAction(actionName);
	        activateCustomAction(formContext);
	        // Xrm.Page.data.save();
	        formContext.data.save();
	    }

	    else {
	        return;
	    }

	});



}

/* Change Summary for April 2022 Release 1 */
/* Last Modified By: Bubun Bhandari*/
/* Summary of Changes: Remove Debug Code,add Xrm.Navigation.openAlertDialog instead of Xrm.Utility.alertDialog and add Xrm.Utility.getGlobalContext instead of Xrm.Page*/
/* - Reason for Change: Unexpected 'debugger' statement and Xrm.Utility.alertDialog and Xrm.Page use in code  -MS Code Review*/
/* - Function name - activateCustomAction */

function activateCustomAction(actionName) {

    var formContext = actionName;
    var caseIDvalue = formContext.data.entity.getId().replace(/[{}]/g, '');
    var parameters = {};
    parameters.caseId = caseIDvalue;
    var globalContext = Xrm.Utility.getGlobalContext();
    var req = new XMLHttpRequest();
    // req.open("POST", Xrm.Page.context.getClientUrl() + "/api/data/v9.1/rsa_CaseAssignAction", true);
    req.open("POST", globalContext.getClientUrl() + "/api/data/v9.1/rsa_CaseAssignAction", true);
    req.setRequestHeader("OData-MaxVersion", "4.0");
    req.setRequestHeader("OData-Version", "4.0");
    req.setRequestHeader("Accept", "application/json");
    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    req.onreadystatechange = function () {
        if (this.readyState === 4) {
            req.onreadystatechange = null;
            if (this.status === 200) {
                var results = JSON.parse(this.response);
                if (results !== null && results !== undefined) {
                    if (results["IsQueueAssign"] === "false") {
                        Xrm.Navigation.openAlertDialog("No Queue matching to Case");
                    }
                    else if (results["IsQueueAssign"] === "true") {
                        if (results["QueueName"] !== null && results["QueueName"] !== undefined) {
                            Xrm.Navigation.openAlertDialog("Case has been assigned to Queue: " + results["QueueName"]);
                        }
                    }
                }
            } else {
                Xrm.Navigation.openAlertDialog(this.statusText);
            }
        }
    };
    req.send(JSON.stringify(parameters));
}
//testing for bug 1025

/* Change Summary for April 2022 Release 1 */
/* Last Modified By: Bubun Bhandari*/
/* Summary of Changes: add Xrm.Navigation.openAlertDialog instead of Xrm.Utility.alertDialog */
/* - Reason for Change:  Xrm.Utility.alertDialog  -MS Code Review  */
/* - Function name - GetFeedbackCount */
function GetFeedbackCount(executionContext) {
    try {
        var formContext = executionContext.getFormContext();
        var req = new XMLHttpRequest();
        var feedbackCount;
        var title = formContext.getAttribute("title").getValue();
        var fetchFeedback = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
							"<entity name='rsa_casefeedback'>" +
							"<attribute name='rsa_casefeedbackid' />" +
							"<attribute name='rsa_name' />" +
							"<attribute name='createdon' />" +
							"<order attribute='rsa_name' descending='false' />" +
							"<link-entity name='incident' from='incidentid' to='rsa_case' link-type='inner' alias='ae'>" +
							"<filter type='and'>" +
							"<condition attribute='title' operator='eq' value='" + title + "' />" +
							"</filter>" +
							"</link-entity>" +
							"</entity>" +
							"</fetch>";

        var req = new XMLHttpRequest();
        var globalContext = Xrm.Utility.getGlobalContext();
        var ClientUrl = globalContext.getClientUrl();
        req.open("GET", ClientUrl + "/api/data/v9.1/rsa_casefeedbacks?fetchXml=" + encodeURIComponent(fetchFeedback), false);
        req.setRequestHeader("Prefer", 'odata.include-annotations="*"');
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    var results = JSON.parse(this.response);
                    var results = JSON.parse(this.response);
                    feedbackCount = results.value.length;

                } else {
                    Xrm.Navigation.openAlertDialog(this.statusText);
                }
            }
        };

        req.send();
        return feedbackCount;
    }
    catch (err) {
        Xrm.Navigation.openAlertDialog({ text: "GetFeedbackCount -" + err.message });
    }
}
/* Change Summary for April 2022 Release 1 */
/* Last Modified By: Bubun Bhandari*/
/* Summary of Changes: Remove Xrm.Page and  Xrm.Utility.getGlobalContext() instead of Xrm.Page*/
/* - Reason for Change: Xrm.Page use in code  -MS Code Review*/
/* - Function name - CaseFeedbaackRecordCount */
function CaseFeedbaackRecordCount(executionContext) {
    try {
        var formContext = executionContext.getFormContext();
        var caseTypeName, numberOfFeedback, numberOfFeedbackFormatted, promise, statusName;
        var title = formContext.getAttribute("title").getValue();
        var globalContext = Xrm.Utility.getGlobalContext();
        var req = new XMLHttpRequest();
        //req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v9.1/incidents?$select=_rsa_casetype_value,rsa_promise,_rsa_status_value&$filter= title eq '" + title + "'", false);
        req.open("GET", globalContext.getClientUrl() + "/api/data/v9.1/incidents?$select=_rsa_casetype_value,rsa_promise,_rsa_status_value&$filter= title eq '" + title + "'", false);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    var results = JSON.parse(this.response);
                    for (var i = 0; i < results.value.length; i++) {
                        caseTypeName = results.value[i]["_rsa_casetype_value@OData.Community.Display.V1.FormattedValue"];
                        promise = results.value[i]["rsa_promise"];
                        statusName = results.value[i]["_rsa_status_value@OData.Community.Display.V1.FormattedValue"];
                        numberOfFeedback = GetFeedbackCount(executionContext);

                        if ((caseTypeName === "New Business" || caseTypeName === "Renewal") && numberOfFeedback < 1 && promise === 866760000 && (statusName === "Quoted" || statusName === "Accepted" || statusName === "Not Taken Up" || statusName === "Renewed")) {
                            formContext.getControl("rsa_status").setNotification("At least one piece of feedback must be created for this Case before it can be closed.", 201);
                        }
                        else {
                            formContext.getControl("rsa_status").clearNotification(201);
                        }
                    }
                } else {
                    Xrm.Navigation.openAlertDialog(this.statusText);
                }
            }
        };
        req.send();
    }
    catch (err) {
        Xrm.Navigation.openAlertDialog({ text: "CaseFeedbaackRecordCount -" + err.message });
    }
}






