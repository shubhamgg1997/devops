"use strict";

function EnquiryReasonandLicenseLevelRequired(executionContext) {

    try {

        var formContext = executionContext.getFormContext();
        var status = formContext.getAttribute("rsa_status").getValue();
        if (status !== null) {
            var CaseStatus = status[0].name;
        }


        var RecordType = formContext.getAttribute("rsa_casetype").getValue();
        if (RecordType !== null) {
            var CaseType = RecordType[0].name;
        }
        var EnquiryReason = formContext.getAttribute("rsa_outcomereasonid").getValue();
        var LicenseLevelRequired = formContext.getAttribute("rsa_licenselevelrequiredtoauthorise").getValue();

        if ((CaseStatus === "Closed (Closed)") && (CaseType === "SME - iMarket Referral" ||
            CaseType === "SME Deals - Imarket Migration" ||
            CaseType === "SME - VEF" ||
            CaseType === "SME - Declaration" ||
            CaseType === "SME - Powerplace Referral" ||
            CaseType === "SME - RSA Online Referral" ||
            CaseType === "SME - Phone Enquiry" ||
            CaseType === "SME - Email Enquiry" ||
            CaseType === "SME - EDI Phone Enquiry" ||
            CaseType === "SME - Deals Enquiry" ||
            CaseType === "SME Deals - Phone Enquiry") &&
            (EnquiryReason === null ||
                LicenseLevelRequired === null)) {
            //formContext.ui.setFormNotification("Please Complete the 'Enquiry Reason' and 'License Level required to authorise' before closing the case ", "ERROR",2844);
            //formContext.getControl("rsa_licenselevelrequiredtoauthorise").setNotification("Please Complete the 'Enquiry Reason' and 'License Level required' before closing the case ", 11);

            //formContext.getControl("rsa_licenselevelrequiredtoauthorise").setNotification("Please Complete the 'Enquiry Reason' and 'License Level required to authorise' before closing the case", 2844);
            // alert("Please Complete the 'Enquiry Reason' and 'License Level required to authorise' before closing the case");
            formContext.getAttribute("rsa_licenselevelrequiredtoauthorise").setRequiredLevel("none");
            formContext.getAttribute("rsa_outcomereasonid").setRequiredLevel("none");

        }
        else {
            formContext.getAttribute("rsa_licenselevelrequiredtoauthorise").setRequiredLevel("none");
            formContext.getAttribute("rsa_outcomereasonid").setRequiredLevel("none");
        }
    }
    catch (err) {
        Xrm.Navigation.openAlertDialog({ text: "EnquiryReasonandLicenseLevelRequired -" + err.message });
    }
}



//Complete OverrideLog OutcomeType Powerplace
function CompleteOverrideLogOutcomeTypePowerplace(executionContext) {

    try {
        var formContext = executionContext.getFormContext();
        var RecordType = formContext.getAttribute("rsa_casetype").getValue();
        if (RecordType !== null) {
            var CaseType = RecordType[0].name;
        }
        var AuthorisationType = formContext.getAttribute("rsa_outcometype").getValue();
        var RevisedPremiumQuote = formContext.getAttribute("rsa_premiumquote").getValue();

        var TradingFundAmountUsed = formContext.getAttribute("rsa_amountdiscounted").getValue();

        var PremiumOverride = formContext.getAttribute("rsa_premiumoverride").getValue();

        if ((AuthorisationType === 866760001 || AuthorisationType === 866760002) && (CaseType === "SME - Powerplace Referral" ||
            CaseType === "SME - iMarket Referral")
            &&


            (RevisedPremiumQuote === null || PremiumOverride === null || TradingFundAmountUsed === null)) {

            //formContext.ui.setFormNotification("Please Complete the 'Enquiry Reason' and 'License Level required to authorise' before closing the case ", "ERROR",2844);
            //formContext.getControl("rsa_licenselevelrequiredtoauthorise").setNotification("Please Complete the 'Enquiry Reason' and 'License Level required' before closing the case ", 11);
            //formContext.getControl("rsa_premiumquote").setNotification("As Pricing Override has been given, please complete: Revised Premium Quote, Premium Override %, Trading Fund Amount Used." , 2844);
            //alert("As Pricing Override has been given, please complete: Revised Premium Quote, Premium Override %, Trading Fund Amount Used");
            formContext.getAttribute("rsa_premiumquote").setRequiredLevel("required");
            formContext.getAttribute("rsa_premiumoverride").setRequiredLevel("required");
            formContext.getAttribute("rsa_amountdiscounted").setRequiredLevel("required");
        }
        else {
            formContext.getAttribute("rsa_premiumquote").setRequiredLevel("none");
            formContext.getAttribute("rsa_premiumoverride").setRequiredLevel("none");
            formContext.getAttribute("rsa_amountdiscounted").setRequiredLevel("none");
        }
    }

    catch (err) {
        Xrm.Navigation.openAlertDialog({ text: "CompleteOverrideLogOutcomeTypePowerplace -" + err.message });
    }
}



//Override Log Required
function OverrideLogRequired(executionContext) {


    try {
        var formContext = executionContext.getFormContext();
        var RecordType = formContext.getAttribute("rsa_casetype").getValue();
        if (RecordType !== null) {
            var CaseType = RecordType[0].name;
        }
        var status = formContext.getAttribute("rsa_status").getValue();
        if (status !== null) {
            var CaseStatus = status[0].name;
        }
        var EnquiryReason = formContext.getAttribute("rsa_outcomereasonid").getValue();
        if (EnquiryReason !== null) {
            var EnquiryReasons = EnquiryReason[0].name;
        }
        var AuthorisationType = formContext.getAttribute("rsa_outcometype").getValue();

        if ((CaseStatus === "Closed (Closed)") && (CaseType === "SME - Powerplace Referral" ||
            CaseType === "SME - RSA Online Referral" ||
            CaseType === "SME - Email Enquiry" ||
            CaseType === "SME - Live Chat" ||
            CaseType === "SME - iMarket Referral") &&
            (EnquiryReasons === "System - Override Terms - Auth Code Used" || EnquiryReasons === "Price - Override Premium" || EnquiryReasons === "Override - Both Terms and Price - Code Used"
                || EnquiryReasons === "Override - Both TRI and Terms - Code Used") &&
            AuthorisationType === null) {
            //formContext.ui.setFormNotification("Please Complete the 'Enquiry Reason' and 'License Level required to authorise' before closing the case ", "ERROR",2844);
            //formContext.getControl("rsa_licenselevelrequiredtoauthorise").setNotification("Please Complete the 'Enquiry Reason' and 'License Level required' before closing the case ", 11);
            // alert("As an Override has been provided please complete the Override Log Section before Closing the Case");
            formContext.getAttribute("rsa_outcometype").setRequiredLevel("required");
            formContext.getAttribute("rsa_pricingauthorisationcode").setRequiredLevel("required");

        }
        else {
            formContext.getAttribute("rsa_outcometype").setRequiredLevel("none");
            formContext.getAttribute("rsa_pricingauthorisationcode").setRequiredLevel("none");
        }
    }
    catch (err) {
        Xrm.Navigation.openAlertDialog({ text: "OverrideLogRequired -" + err.message });
    }
}

////Complete the Override Log 'Outcome Type'

function CompletetheOverrideLogOutcomeType(executionContext) {

    try {
        var formContext = executionContext.getFormContext();
        var RecordType = formContext.getAttribute("rsa_casetype").getValue();
        if (RecordType !== null) {
            var CaseType = RecordType[0].name;
        }
        var status = formContext.getAttribute("rsa_status").getValue();
        if (status !== null) {
            var CaseStatus = status[0].name;
        }
        var EnquiryReason = formContext.getAttribute("rsa_outcomereasonid").getValue();
        if (EnquiryReason !== null) {
            var EnquiryReasons = EnquiryReason[0].name;
        }
        var AuthorisationType = formContext.getAttribute("rsa_outcometype").getValue();
        var COB = formContext.getAttribute("rsa_classofbusinessphoneenqid").getValue();
        if (COB !== null) {
            var ClassOfBusiness = COB[0].name;
        }

        if ((CaseStatus === "Closed (Closed)") && (CaseType === "SME - Phone Enquiry" ||
            CaseType === "SME Deals - Imarket Migration" ||
            CaseType === "SME Deals - Phone Enquiry") &&
            (EnquiryReasons === "System - Override Terms - Auth Code Used" || EnquiryReasons === "Price - Override Premium")
            &&
            (ClassOfBusiness === "Extranet" || ClassOfBusiness === "SWH – Acturis" || ClassOfBusiness === "SWH – Powerplace")
            && (AuthorisationType === null)) {
            //formContext.ui.setFormNotification("Please Complete the 'Enquiry Reason' and 'License Level required to authorise' before closing the case ", "ERROR",2844);
            //formContext.getControl("rsa_licenselevelrequiredtoauthorise").setNotification("Please Complete the 'Enquiry Reason' and 'License Level required' before closing the case ", 11);
            //alert("Please Complete the Override Log 'Outcome Type'");
            formContext.getAttribute("rsa_outcometype").setRequiredLevel("required");

        }
        else {
            formContext.getAttribute("rsa_outcometype").setRequiredLevel("none");
        }
    }
    catch (err) {
        Xrm.Navigation.openAlertDialog({ text: "CompletetheOverrideLogOutcomeType -" + err.message });
    }
}


/////complete Class of Business and Product
function CompleteClassofBusinessandProduct(executionContext) {

    try {
        var formContext = executionContext.getFormContext();
		if (formContext.getAttribute("rsa_productphoneenqid") !== null && formContext.getAttribute("rsa_productphoneenqid") !== undefined  && formContext.getAttribute("rsa_classofbusinessphoneenqid") !== null && formContext.getAttribute("rsa_classofbusinessphoneenqid") !== undefined && formContext.getAttribute("rsa_casetype") !== null && formContext.getAttribute("rsa_casetype") !== undefined){
        var RecordType = formContext.getAttribute("rsa_casetype").getValue();
        if (RecordType !== null) {
            var CaseType = RecordType[0].name;
        }
        //   var Product = formContext.getAttribute("rsa_product").getValue();//Calculated field
		
        var ProductPhoneenq = formContext.getAttribute("rsa_productphoneenqid").getValue();
        var COB = formContext.getAttribute("rsa_classofbusinessphoneenqid").getValue();
        if (COB !== null) {
            var ClassOfBusiness = COB[0].name;
        }
        //var COB_c = formContext.getAttribute("").getValue();


        if ((CaseType === "SME - Phone Enquiry" || CaseType === "SME - Deals Enquiry" || CaseType === "SME Deals - Imarket Migration") && (ProductPhoneenq === null &&ClassOfBusiness === null)) {

            // alert("Please complete Class of Business and Product fields.");
            formContext.getAttribute("rsa_classofbusinessphoneenqid").setRequiredLevel("required");
            //formContext.getAttribute("rsa_classofbusiness").setRequiredLevel("required");
            formContext.getAttribute("rsa_productphoneenqid").setRequiredLevel("required");


        }
        else {
            formContext.getAttribute("rsa_classofbusinessphoneenqid").setRequiredLevel("none");
            //formContext.getAttribute("rsa_classofbusiness").setRequiredLevel("none");
            formContext.getAttribute("rsa_productphoneenqid").setRequiredLevel("none");

        }
		}
    }

    catch (err) {
        Xrm.Navigation.openAlertDialog({ text: "CompleteClassofBusinessandProduct -" + err.message });
    }

}



///////Complete 'Proposition' & 'Policy Transaction'
function CompletePropositionPolicyTransaction(executionContext) {

    try {
        var formContext = executionContext.getFormContext();
        var RecordType = formContext.getAttribute("rsa_casetype").getValue();
        if (RecordType !== null) {
            var CaseType = RecordType[0].name;
        }
        var AmountDiscounted = formContext.getAttribute("rsa_amountdiscounted").getValue();
        var Proposition = formContext.getAttribute("rsa_proposition").getValue();
        var policyTransaction = formContext.getAttribute("rsa_policytransaction").getValue();



        if (AmountDiscounted !== null) {
            if ((CaseType === "SME Email Enquiry" || CaseType === "SME - Accounts" || CaseType === "SME - Boss Query" || CaseType === "SME - Deals Enquiry" || CaseType === "SME Deals - Phone Enquiry" || CaseType === "SME - Declaration" || CaseType === "SME - Email Pre-Processing" || CaseType === "SME - iMarket Referral" || CaseType === "SME - Live Chat" || CaseType === "SME MID Update" || CaseType === "SME - Phone Enquiry" || CaseType === "SME - Powerplace Referral" || CaseType === "SME - RSA Online Referral") && (Proposition === null) || (policyTransaction === null)) {

                //alert("Please Complete 'Proposition' & 'Policy Transaction'");
				formContext.getAttribute("rsa_proposition").setRequiredLevel("required");

                formContext.getAttribute("rsa_policytransaction").setRequiredLevel("required");
            }
        }
        else {
            formContext.getAttribute("rsa_proposition").setRequiredLevel("none");

            formContext.getAttribute("rsa_policytransaction").setRequiredLevel("none");

        }
    }
    catch (err) {
        Xrm.Navigation.openAlertDialog({ text: "CompletePropositionPolicyTransaction -" + err.message });
    }
}


//Option set filtering based on case type
function filterOptionSets(executionContext) {
    //get option set control and its options
    try {
        var formContext = executionContext.getFormContext();

        if (formContext.getAttribute("caseorigincode") !== null && formContext.getAttribute("rsa_casetype") !== null) {

            var optionsetControl = formContext.ui.controls.get("caseorigincode");
            if (optionsetControl !== null) {
                var options = optionsetControl.getAttribute().getOptions();

                var formName = formContext.ui.formSelector.getCurrentItem().getLabel();  // can use this as well
                var caseType = formContext.getAttribute("rsa_casetype").getValue()[0].name;
                //get current selected value of option set
                var currentValue = formContext.getAttribute("caseorigincode").getValue();
                //based on the filterValue, clear option set and then add the required options
                if (caseType === "SME - Email Enquiry") {
                    optionsetControl.clearOptions();
                    optionsetControl.addOption(options[0]);

                }
            }
        }
    }
    catch (err) {
        Xrm.Navigation.openAlertDialog({ text: "filter check -" + err.message });
    }
}
