var url;

function Download(executionContext)
{
	parent.Xrm.Utility.showProgressIndicator("Downloading");
	
	try
	{
	
		var formContext = executionContext;
		var emailId = formContext.data.entity.getId();
		
		if(emailId==="" || emailId===null)
		{
			console.log("EmailGUID received is empty");
			return;
		}
		
		emailId = emailId.replace(/{|}/gi, "");
		
		var data = {
			"EmailGUID" : emailId
		}
		
		GetURLName();

		var req = new XMLHttpRequest();
		req.open("POST", url, true);
		req.setRequestHeader('Content-Type', 'application/json');

		req.onreadystatechange = function () {
			if (this.readyState === 4) {
				req.onreadystatechange = null;
				if (this.status === 200) {
					var email = JSON.parse(this.response);
					var convertedEmail = transform(email);
					
					const link = document.createElement("a");
					var blob = new Blob([convertedEmail], {type: 'text/plain'});
					link.href = URL.createObjectURL(blob);
					link.download = (email.Subject==="" || email.Subject===null) ? "default.eml" : email.Subject + ".eml";
					link.click();
					URL.revokeObjectURL(link.href);
				} 
				else {
					parent.Xrm.Utility.alertDialog("Error: " + this.statusText);
				}	
				parent.Xrm.Utility.closeProgressIndicator();
			}
		};

		req.send(JSON.stringify(data));
	}
		
	catch(err)
	{
		parent.Xrm.Utility.alertDialog("Exception occured" + err.message);
		parent.Xrm.Utility.closeProgressIndicator();
	}
		
}

function transform(email)
{
    var emlContent = 'data:message/rfc822 eml;charset=utf-8' +'\n';
    emlContent += 'From: '+email.Sender+'\n';
    emlContent += 'To: '+email.Recipients+'\n';
	emlContent += 'Cc: '+email.CC+'\n';
    emlContent += 'Subject: '+email.Subject+'\n';
    emlContent += 'X-Unsent: 0'+'\n';
    emlContent += 'Content-Type: multipart/mixed; boundary=--boundary_text_string'+'\n';
    emlContent += ''+'\n';
    emlContent +='----boundary_text_string'+'\n'
    emlContent += 'Content-Type: text/html; charset=UTF-8'+'\n';
    emlContent += ''+'\n';
    emlContent += email.Description;

    for(var x in email.Attachments)
    {
        var file = email.Attachments[x];
        emlContent += ''+'\n';
        emlContent +='----boundary_text_string'+'\n'
        emlContent += 'Content-Type: application/octet-stream; name='+file.Filename+'\n';
        emlContent += 'Content-Transfer-Encoding: base64'+'\n';
        emlContent += 'Content-Disposition: attachment'+'\n';
        emlContent += ''+'\n';
        emlContent += file.ContentBytes.$content +'\n'
        emlContent += ''+'\n';
    }

    return emlContent;
}

function GetURLName()
{
'use strict'; 
	var req = new XMLHttpRequest();
	req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v9.1/environmentvariabledefinitions?$select=defaultvalue&$filter=schemaname eq 'rsa_FetchEmailURL'", false);
	req.setRequestHeader("OData-MaxVersion", "4.0");
	req.setRequestHeader("OData-Version", "4.0");
	req.setRequestHeader("Accept", "application/json");
	req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
	req.setRequestHeader("Prefer", "odata.include-annotations=\"*\",odata.maxpagesize=1");
	req.onreadystatechange = function() {
		if (this.readyState === 4) {
			req.onreadystatechange = null;
			if (this.status === 200) {
				var results = JSON.parse(this.response);
				for (var i = 0; i < results.value.length; i++) {
					  url = results.value[i]["defaultvalue"];
				}
			} else {
				Xrm.Utility.alertDialog(this.statusText);
			}
		}
	};
	req.send();
}