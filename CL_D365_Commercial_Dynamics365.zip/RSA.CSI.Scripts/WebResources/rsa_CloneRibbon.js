/* Change Summary for April 2022 Release 1 */
/* Last Modified By: Bubun Bhandari*/
/* Summary of Changes: Remove Debug Code*/
/* - Reason for Change: Unexpected 'debugger' statement-MS Code Review  */
/* - Function name - CaseCloneClick */
function CaseCloneClick(primaryControl) {

    var formContext = primaryControl;
    var excludeAttributes = ["createdon", "createdby", "modifiedon", "modifiedby", "title", "rsa_autonumberattribute", "ticketnumber"];
    SaveAsEntity(formContext, excludeAttributes);
}

/* Change Summary for April 2022 Release 1 */
/* Last Modified By: Bubun Bhandari*/
/* Summary of Changes: Remove Debug Code*/
/* - Reason for Change: Unexpected 'debugger' statement-MS Code Review  */
/* - Function name - OpportunityCloneClick */
function OpportunityCloneClick(primaryControl) {

    var formContext = primaryControl;
    var excludeAttributes = ["createdon", "createdby", "modifiedon", "modifiedby"];
    SaveAsEntity(formContext, excludeAttributes);
}

/* Change Summary for April 2022 Release 1 */
/* Last Modified By: Bubun Bhandari*/
/* Summary of Changes: add Xrm.Navigation.openAlertDialog instead of Xrm.Utility.alertDialog*/
/* - Reason for Change: Xrm.Utility.alertDialog use in code-MS Code Review  */
/* - Function name - CreateEntity */
function CreateEntity(formContext, entityName, entity, isAsync) {

    try {
        var newEntityId;
        var req = new XMLHttpRequest();
        req.open("POST", formContext.context.getClientUrl() + "/api/data/v8.2/" + entityName, isAsync);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                //debugger;
                if (this.status === 204) {
                    //Success - No Return Data - Do Something

                    var uri = this.getResponseHeader("OData-EntityId");
                    var regExp = /\(([^)]+)\)/;
                    var matches = regExp.exec(uri);
                    newEntityId = matches[1];
                } else {
                    Xrm.Utility.openAlertDialog(this.responseText);
                }
            }
        };
        req.send(JSON.stringify(entity));

        return newEntityId;
    }
    catch (error) {
        console.log(error);
    }
}
/* Change Summary for April 2022 Release 1 */
/* Last Modified By: Bubun Bhandari*/
/* Summary of Changes: add Xrm.Navigation.openAlertDialog instead of Xrm.Utility.alertDialog*/
/* - Reason for Change: Xrm.Utility.alertDialog use in code-MS Code Review  */
/* - Function name - UpdateEntity */
function UpdateEntity(formContext, entityName, entityId, entity, isAsync) {

    try {
        var req = new XMLHttpRequest();
        req.open("PATCH", formContext.context.getClientUrl() + "/api/data/v8.2/" + entityName + "(" + entityId + ")", isAsync);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                //debugger;
                if (this.status === 204) {
                    //Success - No Return Data - Do Something
                } else {
                    Xrm.Utility.openAlertDialog(this.responseText);
                }
            }
        };
        req.send(JSON.stringify(entity));
    }
    catch (error) {
        console.log(error);
    }
}

function RetrieveEntity(formContext, entityName, entityId, attribute, isAsync) {
    try {
        var results;
        var req = new XMLHttpRequest();
        req.open("GET", formContext.context.getClientUrl() + "/api/data/v9.1/" + entityName + "(" + entityId + ")?$select=" + attribute + "", isAsync);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    results = JSON.parse(this.response);
                } else {
                    var alertStrings = { confirmButtonLabel: "Ok", text: this.responseText };
                    var alertOptions = { height: 150, width: 500 };
                    Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);

                }
            }
        }; req.send();
        return results;
    }
    catch (error) {
        console.log(error);
    }
}
/* Change Summary for April 2022 Release 1 */
/* Last Modified By: Bubun Bhandari*/
/* Summary of Changes: Remove Debug Code and add Xrm.Navigation.openAlertDialog instead of Xrm.Utility.alertDialog*/
/* - Reason for Change: Unexpected 'debugger' statement and Xrm.Utility.alertDialog uses in code-MS Code Review  */
/* - Function name - ExecuteAction */
function ExecuteAction(formContext, actionName, parameters, isAsync) {

    try {
        var results;
        var req = new XMLHttpRequest();
        req.open("POST", formContext.context.getClientUrl() + "/api/data/v9.1/" + actionName, isAsync);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    results = JSON.parse(this.response);
                } else {
                    Xrm.Utility.openAlertDialog(this.responseText);
                }
            }
        };
        req.send(JSON.stringify(parameters));
        return results;
    }
    catch (error) {
        console.log(error);
    }
}
/* Change Summary for April 2022 Release 1 */
/* Last Modified By: Bubun Bhandari*/
/* Summary of Changes: add Xrm.Navigation.openAlertDialog instead of Xrm.Utility.alertDialog,Remove Xrm.Page and add Xrm.Utility.getGlobalContext() instead of Xrm.Page*/
/* - Reason for Change: Xrm.Utility.alertDialog and Xrm.Page use in code-MS Code Review  */
/* - Function name - FetchNumberToPercentAttr */
function FetchNumberToPercentAttr(filterValue) {
    try {
        var NumberToPercent;
        var valueArray = [];
        var globalContext = Xrm.Utility.getGlobalContext();
        var req = new XMLHttpRequest();
       // req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v9.1/rsa_customlabels?$select=rsa_dependentoptionsetjson&$filter=rsa_name eq '" + filterValue + "'", false);
        req.open("GET", globalContext.getClientUrl() + "/api/data/v9.1/rsa_customlabels?$select=rsa_dependentoptionsetjson&$filter=rsa_name eq '" + filterValue + "'", false);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    var results = JSON.parse(this.response);
                    for (var i = 0; i < results.value.length; i++) {
                        var rsa_dependentoptionsetjson = results.value[i]["rsa_dependentoptionsetjson"];
                        NumberToPercent = JSON.parse(results.value[i]["rsa_dependentoptionsetjson"]).NumberToPercent;

                        for (var j = 0; j < NumberToPercent.length; j++) {

                            var schemaName = NumberToPercent[j].SchemaName;
                            valueArray.push(schemaName);


                        }

                    }
                } else {
                    Xrm.Utility.openAlertDialog(this.statusText);
                }
            }
        };
        req.send();
        return valueArray;

    } catch (err) {
        Xrm.Navigation.openAlertDialog({ text: "FetchNumberToPercentAttr -" + err.message });
    }
}
/* Change Summary for April 2022 Release 1 */
/* Last Modified By: Bubun Bhandari*/
/* Summary of Changes: Remove Debug Code*/
/* - Reason for Change: Unexpected 'debugger' statement-MS Code Review  */
/* - Function name - SaveAsEntity */
function SaveAsEntity(formContext, excludeAttributes) {

    try {
        var entityName = formContext.data.entity.getEntityName();
        var parameters = {};
        var entityFormOptions = {};
        var fetchNumberToPercentAttrColl;
        var customValue = null;
        entityFormOptions["entityName"] = entityName;
        entityFormOptions["openInNewWindow"] = false;
        entityFormOptions["formId"] = formContext.ui.formSelector.getCurrentItem().getId();

        if (entityName.toLowerCase() === "opportunity") {
            customValue = "OpportunityNumberToPercentConversion";
            fetchNumberToPercentAttrColl = FetchNumberToPercentAttr(customValue);
        }
        else if (entityName.toLowerCase() === "incident") {
            customValue = "CaseNumberToPercentConversion";
            fetchNumberToPercentAttrColl = FetchNumberToPercentAttr(customValue);
        }
        else if (entityName.toLowerCase() === "rsa_policy") {
            customValue = "PolicyNumberToPercentConversion";
            fetchNumberToPercentAttrColl = FetchNumberToPercentAttr(customValue);
        }

        var attributeCollections = formContext.data.entity.attributes;

        for (var i = 0; i < attributeCollections.getLength() ; i++) {
            var key = attributeCollections.getByIndex(i).getName();
            var value = attributeCollections.getByIndex(i).getValue();

            /* Change for July 2022 def-2234 */
            /* Last Modified By: Jyoti Bhosale*/
            /* Summary of Changes: Below If condition added to get Parent opportunity Id on click on clone button*/
            if (attributeCollections.getByIndex(i)._attributeName === "rsa_parentopportunityid") {
                var parentrecordId = formContext.data.entity.getId();
                var Id = parentrecordId.replace('{', '').replace('}', '');
                var Name = formContext.getAttribute("name").getValue();
                var Type = "opportunity";
                parameters[key] = Id;
                parameters[key + "name"] = Name;
                parameters[key + "type"] = Type;
            }
            /*******************************/
            /* Change for July 2022(29/06/2022) def-2312 */
            /* Last Modified By: Jyoti Bhosale*/
            /* Summary of Changes: Below If condition added to get Parent Case Id on click on clone button*/
            if (attributeCollections.getByIndex(i)._attributeName === "rsa_originatingcase") {
                var parentCaseId = formContext.data.entity.getId();
                var Id = parentCaseId.replace('{', '').replace('}', '');
                var Name = formContext.getAttribute("title").getValue();
                var Type = "incident";
                parameters[key] = Id;
                parameters[key + "name"] = Name;
                parameters[key + "type"] = Type;
            }
            /*******************************/
            if (value != null) {
                if (!entityName.includes("rsa_euro")) {
                    if (AttributeToBeExcluded(excludeAttributes, key)) {
                        continue;
                    }
                    else if (fetchNumberToPercentAttrColl.indexOf(key) != -1) {
                        value = value * 100;
                    }
                }

                else {
                    if (AttributeToBeExcluded(excludeAttributes, key)) {
                        continue;
                    }
                }


                var attributeType = attributeCollections.getByIndex(i).getAttributeType();
                switch (attributeType) {
                    case "boolean":
                        parameters[key] = value;
                        break;
                    case "datetime":

                        var date = value;
                        var year = date.getFullYear();
                        var month = date.getMonth();
                        var day = date.getDate();
                        parameters[key] = month + 1 + "/" + day + "/" + year;
                        break;
                    case "decimal":
                        parameters[key] = value;
                        break;
                    case "double":
                        parameters[key] = value;
                        break;
                    case "integer":
                        parameters[key] = value;
                        break;
                    case "lookup":

                        // if (attributeCollections.getByIndex(i).getValue()[0].entityType == "transactioncurrency")
                        // break;

                        var Id = attributeCollections.getByIndex(i).getValue()[0].id.replace('{', '').replace('}', '');
                        var Name = attributeCollections.getByIndex(i).getValue()[0].name;
                        var Type = attributeCollections.getByIndex(i).getValue()[0].entityType;

                        parameters[key] = Id;
                        parameters[key + "name"] = Name;

                        if (key == "ownerid" || key == "parentcustomerid")
                            parameters[key + "type"] = Type;

                        break;
                    case "memo":
                        parameters[key] = value;
                        break;
                    case "money":
                        parameters[key] = value;
                        break;
                    case "multiselectoptionset":
                        parameters[key] = "[" + value + "]";
                        break;
                    case "optionset":
                        parameters[key] = value;
                        break;
                    case "string":
                        parameters[key] = value;
                        break;
                }
            }
        }

        Xrm.Navigation.openForm(entityFormOptions, parameters).then(
            function (success) {
                console.log(success);
            },
            function (error) {
                console.log(error);
            });
    }
    catch (error) {
        console.log(error);
    }
}
/* Change Summary for April 2022 Release 1 */
/* Last Modified By: Bubun Bhandari*/
/* Summary of Changes: Remove Debug Code*/
/* - Reason for Change: Unexpected 'debugger' statement-MS Code Review  */
/* - Function name - AttributeToBeExcluded */
function AttributeToBeExcluded(excludeAttributesList, attribute) {

    try {
        var isAttributeToBeExcluded = false;
        if (typeof excludeAttributesList !== 'undefined' && excludeAttributesList !== null
            && typeof attribute !== 'undefined' && attribute !== null) {
            for (var i = 0; i < excludeAttributesList.length; i++) {
                if (attribute.toLowerCase() === excludeAttributesList[i].toLowerCase()) {
                    isAttributeToBeExcluded = true;
                    break;
                }
            }
        }
    }
    catch (error) {
        console.log(error);
    }
    return isAttributeToBeExcluded;
}

function _refreshForm(formContext) {
    formContext.data.refresh();
}

