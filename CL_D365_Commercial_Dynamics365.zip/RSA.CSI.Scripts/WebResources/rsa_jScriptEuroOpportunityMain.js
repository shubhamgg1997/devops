"use strict";

var RSA = window.RSA || { __namespace: true, __typeName: "RSA" };
RSA.D365CRM = RSA.D365CRM || { __namespace: true, __typeName: "RSA.D365CRM" };
RSA.D365CRM.EuroOpportunity = RSA.D365CRM.EuroOpportunity || { __namespace: true, __typeName: "RSA.D365CRM.EuroOpportunity" };
RSA.D365CRM.EuroOpportunity.Main = RSA.D365CRM.EuroOpportunity.Main || ({
    FormType: {
        Create: 1,
        Update: 2,
        ReadOnly: 3,
        Disabled: 4,
        BulkEdit: 6
    },
    OnLoad: function (executionContext) {
        var formContext = executionContext.getFormContext();

        if (formContext.ui.getFormType() === RSA.D365CRM.EuroOpportunity.Main.FormType.Create) {

            

        }
        else if (formContext.ui.getFormType() === RSA.D365CRM.EuroOpportunity.Main.FormType.Update) {



        }
        else if (formContext.ui.getFormType() === RSA.D365CRM.EuroOpportunity.Main.FormType.Disabled) {



        }
        else if (formContext.ui.getFormType() === RSA.D365CRM.EuroOpportunity.Main.FormType.BulkEdit) {



        }



    },
    OnSave: function (executionContext) {
    },

    OnChangeOfClass: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_class").getValue() !== null) {
                var euroClass = formContext.getAttribute("rsa_class").getValue();
                formContext.getControl("rsa_subclassid").addPreSearch(RSA.D365CRM.EuroOpportunity.Main.filterLookup);
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "OnChangeOfSalesTeam -" + err.message });
        }

    },

    filterLookup: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var euroClass = formContext.getAttribute("rsa_class").getValue();
        var filter = "<filter type='and'><condition attribute='rsa_applicableclass' operator='like' value='%" + euroClass + "%' /></filter>";
        formContext.getControl("rsa_subclassid").addCustomFilter(filter);
    },
    SettingInceptionYearAndMonth: function (executionContext) {
        formContext = executionContext.getFormContext();
        var InCeptionValue = formContext.getAttribute("rsa_inceptiondate").getValue();
        if (InCeptionValue != null && InCeptionValue != undefined) {
            formContext.getAttribute("rsa_inceptionmonthnew").setValue((InCeptionValue.getMonth()+1).toString());
            formContext.getAttribute("rsa_inceptionyearnew").setValue(InCeptionValue.getFullYear().toString());
        }
        }
});










