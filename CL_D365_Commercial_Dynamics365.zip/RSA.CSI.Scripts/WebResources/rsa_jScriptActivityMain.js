"use strict";
var RSA = window.RSA || { __namespace: true, __typeName: "RSA" };
RSA.D365CRM = RSA.D365CRM || { __namespace: true, __typeName: "RSA.D365CRM" };
RSA.D365CRM.Activity = RSA.D365CRM.Activity || { __namespace: true, __typeName: "RSA.D365CRM.Activity" };
RSA.D365CRM.Activity.Main = RSA.D365CRM.Activity.Main || ({
    FormType: {
        Create: 1,
        Update: 2,
        ReadOnly: 3,
        Disabled: 4,
        BulkEdit: 6
    },
    OnLoad: function (executionContext) {

        var formContext = executionContext.getFormContext();
		RSA.D365CRM.Activity.Main.SetVolume(executionContext);
		
        if (formContext.ui.getFormType() === RSA.D365CRM.Activity.Main.FormType.Create) {
        }
        else if (formContext.ui.getFormType() === RSA.D365CRM.Activity.Main.FormType.Update) {
               //RedirectExistingTotaskType(executionContext,"onload");
        }
        else if (formContext.ui.getFormType() === RSA.D365CRM.Activity.Main.FormType.Disabled) {

        }
        else if (formContext.ui.getFormType() === RSA.D365CRM.Activity.Main.FormType.BulkEdit) {

        }

    },

    OnSave: function (executionContext) {
        RSA.D365CRM.Activity.Main.VolumeRequiredField(executionContext);
        RSA.D365CRM.Activity.Main.NextCallDatenRequiredField(executionContext);
        RSA.D365CRM.Activity.Main.NumberDialledRequiredField(executionContext);
        RSA.D365CRM.Activity.Main.RSAMARKETINGEditTask(executionContext);
        RSA.D365CRM.Activity.Main.EnterBPOHandlingTime(executionContext);
        RSA.D365CRM.Activity.Main.TaskFormID(executionContext);
        RSA.D365CRM.Activity.Main.ePromiseReferralReasonsRequired(executionContext);
        RSA.D365CRM.Activity.Main.Enter_reason_for_different_delivery_date(executionContext);
    },

    //Author : Chandani Vaishnani
    //Date : 06 Aug 2020
    //This Function to populate Initial_Activity_Status__c field
    InitialActivityStatus: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_initialduedatetime") !== null && formContext.getAttribute("rsa_initialduedatetime") !== "undefined" && formContext.getAttribute("rsa_initialactivitystatus") !== null && formContext.getAttribute("rsa_initialactivitystatus") !== "undefined" && formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_status") !== "undefined") {
                var initialDueDatetime;
                var currentDate = new Date();
                var status = formContext.getAttribute("rsa_status").getValue();
                if (formContext.getAttribute("rsa_initialduedatetime").getValue() !== null) {
                    initialDueDatetime = new Date(formContext.getAttribute("rsa_initialduedatetime").getValue());
                    if ((currentDate < initialDueDatetime) && status === '866760004') {
                        formContext.getAttribute("rsa_initialactivitystatus").setValue("Closed within SLA");
                    }
                    else if (currentDate > initialDueDatetime) {
                        formContext.getAttribute("rsa_initialactivitystatus").setValue("Open Outside SLA");
                    }
                    else if (currentDate < initialDueDatetime) {
                        formContext.getAttribute("rsa_initialactivitystatus").setValue("Open within SLA");
                    }
                    else {
                        formContext.getAttribute("rsa_initialactivitystatus").setValue("Closed Outside SLA");
                    }
                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "InitialActivityStatus -" + err.message });
        }
    },
	//Author Sujeet 
	
	form_onload: function(formContext) {
		 if (formContext.getAttribute("rsa_statusreason") !== null && formContext.getAttribute("rsa_statusreason") !== "undefined" ){
   var value = formContext.getAttribute("rsa_statusreason").getValue();
                       
   var ctrl = formContext.getControl("rsa_statusreason");
   var inactive = RSA.D365CRM.Activity.Main.getInactiveOptions("rsa_statusreason");
   inactive.forEach(
      function(i) {
         // check if value is in use
         if(i != value)
		 {		 ctrl.removeOption(i);}
      }
   );
	}},
 
getInactiveOptions:function(field) {
   if(field == "rsa_statusreason") 
      return [866760007];
   else
      return [];
},

    //Author : Chandani Vaishnani
    //Date : 06 Aug 2020
    //This Function to make mandatory DateTimeCallMadeRequired Field 
    //Date_Time_Call_Made_Required_Field
    DateTimeCallMadeRequiredField: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_datetimecallmade") !== null && formContext.getAttribute("rsa_datetimecallmade") !== "undefined" && formContext.getAttribute("rsa_tasktype") !== null && formContext.getAttribute("rsa_tasktype") !== "undefined" && formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_status") !== "undefined") {
                var division, taskTypeId, taskType;
                var status = formContext.getAttribute("rsa_status").getValue();
                if (formContext.getAttribute("rsa_tasktype").getValue() !== null) {
                   taskTypeId= formContext.getAttribute("rsa_tasktype").getValue()[0].name;
					//taskTypeId = taskType.toLowerCase();
                }
                var dateTimeCallMade = formContext.getAttribute("rsa_datetimecallmade").getValue();
                var systemuserId = RSA.D365CRM.Activity.Main.ConvertGuid(Xrm.Utility.getGlobalContext().userSettings.userId);
                var req = new XMLHttpRequest();
                var globalContext = Xrm.Utility.getGlobalContext();
                var ClientUrl = globalContext.getClientUrl();
                req.open("GET", ClientUrl + "/api/data/v9.1/systemusers(" + systemuserId + ")?$select=rsa_division", false);
                req.setRequestHeader("OData-MaxVersion", "4.0");
                req.setRequestHeader("OData-Version", "4.0");
                req.setRequestHeader("Accept", "application/json");
                req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                req.onreadystatechange = function () {
                    if (this.readyState === 4) {
                        req.onreadystatechange = null;
                        if (this.status === 200) {
                            var result = JSON.parse(this.response);
                            division = result["rsa_division"];
							if (division !== '866760003' && (status == '866760004' || status == '866760005') && dateTimeCallMade === null && (taskTypeId === "Chase Conversation" || taskTypeId === "Feedback Conversation" || taskTypeId === "Quote Conversation" || taskTypeId === "Vetting Conversation" || taskTypeId === "Follow Up Vetting Conversation" || taskTypeId === "ePromise Query - Callback" )) {
							formContext.getAttribute("rsa_datetimecallmade").setRequiredLevel("required");
							}
							else {
							formContext.getAttribute("rsa_datetimecallmade").setRequiredLevel("none");
							}
                        } else {
                            Xrm.Navigation.openAlertDialog(this.statusText);
                        }
                    }
                };
                req.send();
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "DateTimeCallMadeRequiredField -" + err.message });
        }
    },
    //Author : Nida
    //Date : 06 Aug 2020
    //This Function to make mandatory Volume Field 
    //Date_Time_Call_Made_Required_Field
    VolumeRequiredField: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_volume") !== null && formContext.getAttribute("rsa_volume") !== "undefined"
                && formContext.getAttribute("rsa_tasktype") !== null && formContext.getAttribute("rsa_tasktype") !== "undefined") {
                var division, taskTypeId;
                if (formContext.getAttribute("rsa_tasktype").getValue() !== null) {
                    taskTypeId = RSA.D365CRM.Activity.Main.ConvertGuid(formContext.getAttribute("rsa_tasktype").getValue()[0].name).toLowerCase();

                    var volume = formContext.getAttribute("rsa_volume").getValue();
                    var systemuserId = RSA.D365CRM.Activity.Main.ConvertGuid(Xrm.Utility.getGlobalContext().userSettings.userId);
                    var division = null;

                    var taskTypeArray = ["account query","chase","chase - real estate","complete renewal review","cqe","debit premium","eml form","feedback conversation","issue letter to holding broker","issue policy documents","issue quote documents","lindex update","perform accumulation check","process cancellation","process lapse","process mta","process query","process revised renewal","quote - renewal","quote - real estate","quote - conversation","quote - conversation (renewal)","quote - work up","referral" ,"re-insurance","re-negotiate renewal outcome","renewal comunication","renewal work up"," review cqe renewal quote","review survey report","rework","scheme review","send renewal submission to trader","supply claims experience"," survey request","task","update eml","vetting","quote new business"]

                    var hasValue = taskTypeArray.includes(taskTypeId, 0);
                    var req = new XMLHttpRequest();
                    var globalContext = Xrm.Utility.getGlobalContext();
                    var ClientUrl = globalContext.getClientUrl();

                    req.open("GET", ClientUrl + "/api/data/v9.1/systemusers(" + systemuserId + ")?$select=rsa_division", true);
                    req.setRequestHeader("OData-MaxVersion", "4.0");
                    req.setRequestHeader("OData-Version", "4.0");
                    req.setRequestHeader("Accept", "application/json");
                    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                    req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                    req.onreadystatechange = function () {
                        if (this.readyState === 4) {
                            req.onreadystatechange = null;
                            if (this.status === 200) {
                                var result = JSON.parse(this.response);
                                division = result["rsa_division"];
                                if (division !== '866760003' && volume === null && hasValue === true) {
                                    formContext.getAttribute("rsa_volume").setRequiredLevel("required");
									//formContext.getControl("rsa_volume").setNotification("Volume: Required fields must be filled in", 1001);
                                }
                                else {
                                    formContext.getAttribute("rsa_volume").setRequiredLevel("none");
									formContext.getControl("rsa_volume").clearNotification(1001);
                                }
                            } else {
                                Xrm.Navigation.openAlertDialog(this.statusText);
                            }
                        }
                    };
                    req.send();

                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "VolumeRequiredField-" + err.message });
        }
    },
    //This Generic Function is for Retriving Division for User
    RetriveUserDivison: function (UserId) {
        try {
            var division
            var req = new XMLHttpRequest();
            var globalContext = Xrm.Utility.getGlobalContext();
            var ClientUrl = globalContext.getClientUrl();
            req.open("GET", ClientUrl + "/api/data/v8.2/systemusers(" + UserId + ")?$select=rsa_division", true);
            req.setRequestHeader("OData-MaxVersion", "4.0");
            req.setRequestHeader("OData-Version", "4.0");
            req.setRequestHeader("Accept", "application/json");
            req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
            req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            req.onreadystatechange = function () {
                if (this.readyState === 4) {
                    req.onreadystatechange = null;
                    if (this.status === 200) {
                        var result = JSON.parse(this.response);
                        division = result["rsa_division"];

                        //var rsa_division_formatted = result["rsa_division@OData.Community.Display.V1.FormattedValue"];
                    } else {
                        Xrm.Navigation.openAlertDialog(this.statusText);
                    }
                }
            };
            req.send();
            return division;
        } catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "RetriveUserDivison -" + err.message });
        }
    },


    //Author : Pooja Raje
    //Date : 06 Aug 2020
    //This Function to make mandatory Referral Other Field 
    //ePromise_Referral_Other_Not_Blank

    ePromiseReferralOtherNotBlank: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_referralreasons") !== null && formContext.getAttribute("rsa_referralreasons") !== "undefined" && formContext.getAttribute("rsa_tasktype") !== null && formContext.getAttribute("rsa_tasktype") !== "undefined" && formContext.getAttribute("rsa_referralother") !== null && formContext.getAttribute("rsa_referralother") !== "undefined") {
                //var tasktype = formContext.getAttribute("rsa_tasktype").getValue();
                var tasktype;
                if (formContext.getAttribute("rsa_tasktype").getValue() !== null) {
                    tasktype = formContext.getAttribute("rsa_tasktype").getValue()[0].name;
                }
                var Referralother = formContext.getAttribute("rsa_referralother").getValue();
                var ReferralReasons = formContext.getAttribute("rsa_referralreasons").getValue();

                if (ReferralReasons !== null && ReferralReasons.includes(866760031) && Referralother === null && (tasktype === "ePromise Query" || tasktype === "ePromise Query - Callback")) {
                    formContext.getAttribute("rsa_referralother").setRequiredLevel("required");
                }
                else {
                    formContext.getAttribute("rsa_referralother").setRequiredLevel("none");
                }

            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "ePromiseReferralOtherNotBlank -" + err.message });
        }
    },

    //Author : Pooja Raje
    //Date : 06 Aug 2020
    //ePromise_Referral_Reasons_Required

    ePromiseReferralReasonsRequired: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_referralreasons") !== null && formContext.getAttribute("rsa_referralreasons") !== "undefined" && formContext.getAttribute("rsa_tasktype") !== null && formContext.getAttribute("rsa_tasktype") !== "undefined" && formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_status") !== "undefined") {
                var tasktype;
                if (formContext.getAttribute("rsa_tasktype").getValue() !== null) {
                    tasktype = formContext.getAttribute("rsa_tasktype").getValue()[0].name;
                }
               // var Referralother = formContext.getAttribute("rsa_referralother").getValue();
                var status = formContext.getAttribute("rsa_status").getValue();
                var ReferralReasons = formContext.getAttribute("rsa_referralreasons").getValue();

                if (status === 866760004 && ReferralReasons === null && tasktype === "ePromise Query - Callback") {
                    formContext.getControl("rsa_motor").setNotification("Referral Reason must be selected in order to complete activity.", 501);

                }
                else {
                    formContext.getControl("rsa_motor").clearNotification(501);
                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "ePromiseReferralReasonsRequired-" + err.message });
        }
    },
//Author: Sujeet Pandey
	//Date
	//Enter_reason_for_different_delivery_date
Enter_reason_for_different_delivery_date: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_activityslastatus") !== null && formContext.getAttribute("rsa_activityslastatus") !== "undefined"
                && formContext.getAttribute("rsa_tasktype") !== null && formContext.getAttribute("rsa_tasktype") !== "undefined" && formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_status") !== "undefined"&& formContext.getAttribute("rsa_reasonfordifferentdeliverydate") !== "undefined"&& formContext.getAttribute("rsa_reasonfordifferentdeliverydate") !== null) {
                var division, taskTypeId;
                if (formContext.getAttribute("rsa_tasktype").getValue() !== null && formContext.getAttribute("rsa_status").getValue() !== null) {
                    taskTypeId = RSA.D365CRM.Activity.Main.ConvertGuid(formContext.getAttribute("rsa_tasktype").getValue()[0].name).toLowerCase();

                    var activityslastatus = formContext.getAttribute("rsa_activityslastatus").getValue();
                    var systemuserId = RSA.D365CRM.Activity.Main.ConvertGuid(Xrm.Utility.getGlobalContext().userSettings.userId);
                    var status = formContext.getAttribute("rsa_status").getValue();
var reasonfordifferentdeliverydate = formContext.getAttribute("rsa_reasonfordifferentdeliverydate").getValue();
                    var division = null;

                    var taskTypeArray = ["account query",
"action change",
"chase",
"chase conversation",
"chase conversation renewal",
"debit bordereaux",
"debit premium",
"feedback conversation",
"follow up vetting conversation",
"issue letter to holding broker",
"issue policy documents",
"issue quote documents",
"issue rdf",
"mid update",
"process cancellation",
"process lapse",
"process mta",
"quote",
"quote conversation",
"quote conversation renewal",
"quote work up",
"re-negotiate renewal outcome",
"quote - real estate",
"chase - real estate",
"referral",
"renewal communication",
"renewal review",
"renewal work up",
"rework",
"send policy instructions to support team",
"supply claims experience",
"survey request",
"vetting",
"vetting conversation",
"chase declaration",
"chase vef",
"chase broker",
"contact broker",
"issue survey request",
"produce letter",
"review survey report when survey type = site",
"review survey report when survey type = support",
"review vef",
"review and issue letter",
"send survey request to bpo",
"update mid",
"process referral",
"work up renewal review",
"review completion",
"follow up activity",
"initial processing"
]
                    var hasValue = taskTypeArray.includes(taskTypeId, 0);
                    var req = new XMLHttpRequest();
                    var globalContext = Xrm.Utility.getGlobalContext();
                    var ClientUrl = globalContext.getClientUrl();

                    req.open("GET", ClientUrl + "/api/data/v9.1/systemusers(" + systemuserId + ")?$select=rsa_division", false);
                    req.setRequestHeader("OData-MaxVersion", "4.0");
                    req.setRequestHeader("OData-Version", "4.0");
                    req.setRequestHeader("Accept", "application/json");
                    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                    req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                    req.onreadystatechange = function () {
                        if (this.readyState === 4) {
                            req.onreadystatechange = null;
                            if (this.status === 200) {
                                var result = JSON.parse(this.response);
                                division = result["rsa_division"];
                                if (division !== 866760003 &&reasonfordifferentdeliverydate===null&&( activityslastatus ==="Open Outside SLA"||activityslastatus==="Closed Outside SLA" ) && hasValue === true && (status === 866760004 || status === 100000000||status === 866760005||status === 866760007)) {
                                    formContext.getAttribute("rsa_reasonfordifferentdeliverydate").setRequiredLevel("required");
                                }
                                else {
                                    formContext.getAttribute("rsa_reasonfordifferentdeliverydate").setRequiredLevel("none");
                                }

                            } else {
                                Xrm.Navigation.openAlertDialog(this.statusText);
                            }
                        }
                    };
                    req.send();

                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "Enter_reason_for_different_delivery_date-" + err.message });
        }
    },

    //Author : Nida
    //Date : 10 Aug 2020
    //This Function to make mandatory rsa_nextcallduedatetime  Field
    //Next_Call_Date_Required_Field
    NextCallDatenRequiredField: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_nextcallduedatetime") !== null && formContext.getAttribute("rsa_nextcallduedatetime") !== "undefined"
                && formContext.getAttribute("rsa_tasktype") !== null && formContext.getAttribute("rsa_tasktype") !== "undefined" && formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_status") !== "undefined") {
                var division, taskTypeId;
                if (formContext.getAttribute("rsa_tasktype").getValue() !== null && formContext.getAttribute("rsa_status").getValue() !== null) {
                    taskTypeId = RSA.D365CRM.Activity.Main.ConvertGuid(formContext.getAttribute("rsa_tasktype").getValue()[0].name).toLowerCase();
                    var nextCallDueDateTime = formContext.getAttribute("rsa_nextcallduedatetime").getValue();
                    var systemuserId = RSA.D365CRM.Activity.Main.ConvertGuid(Xrm.Utility.getGlobalContext().userSettings.userId);
                    var status = formContext.getAttribute("rsa_status").getValue();

                    var division = null;

                    var taskTypeArray = ["quote conversation","vetting conversation","follow up vetting conversation","chase conversation","vetting","quote","quote - real estate"]
                    var hasValue = taskTypeArray.includes(taskTypeId, 0);
                    var req = new XMLHttpRequest();
                    var globalContext = Xrm.Utility.getGlobalContext();
                    var ClientUrl = globalContext.getClientUrl();

                    req.open("GET", ClientUrl + "/api/data/v9.1/systemusers(" + systemuserId + ")?$select=rsa_division", true);
                    req.setRequestHeader("OData-MaxVersion", "4.0");
                    req.setRequestHeader("OData-Version", "4.0");
                    req.setRequestHeader("Accept", "application/json");
                    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                    req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                    req.onreadystatechange = function () {
                        if (this.readyState === 4) {
                            req.onreadystatechange = null;
                            if (this.status === 200) {
                                var result = JSON.parse(this.response);
                                division = result["rsa_division"];
                                if (division !== '866760003' && nextCallDueDateTime === null && hasValue === true && (status === 866760004 || status === 100000000)) {
                                    formContext.getAttribute("rsa_nextcallduedatetime").setRequiredLevel("required");
                                }
                                else {
                                    formContext.getAttribute("rsa_nextcallduedatetime").setRequiredLevel("none");
                                }

                            } else {
                                Xrm.Navigation.openAlertDialog(this.statusText);
                            }
                        }
                    };
                    req.send();

                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "NextCallDatenRequiredField-" + err.message });
        }
    },
    //Author : Nida
    //Date : 10 Aug 2020
    //This Function to make mandatory rsa_numberdialled Field
    //NumberDialledRequired_Field
    NumberDialledRequiredField: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_numberdialled") !== null && formContext.getAttribute("rsa_numberdialled") !== "undefined"
                && formContext.getAttribute("rsa_tasktype") !== null && formContext.getAttribute("rsa_tasktype") !== "undefined" && formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_status") !== "undefined") {
                var division, taskTypeId;
                if (formContext.getAttribute("rsa_tasktype").getValue() !== null && formContext.getAttribute("rsa_status").getValue() !== null) {
                    taskTypeId = RSA.D365CRM.Activity.Main.ConvertGuid(formContext.getAttribute("rsa_tasktype").getValue()[0].id).toLowerCase();

                    var numberdialled = formContext.getAttribute("rsa_numberdialled").getValue();
                    var systemuserId = RSA.D365CRM.Activity.Main.ConvertGuid(Xrm.Utility.getGlobalContext().userSettings.userId);
                    var status = formContext.getAttribute("rsa_status").getValue();

                    var division = null;

                    var taskTypeArray = ["3a79af57-bde2-ea11-a818-000d3a649f51", "7fb02222-f9ec-ea11-a817-000d3a649465", "e13679c9-22e2-ea11-a818-000d3a649f51"]
                    var hasValue = taskTypeArray.includes(taskTypeId, 0);
                    var req = new XMLHttpRequest();
                    var globalContext = Xrm.Utility.getGlobalContext();
                    var ClientUrl = globalContext.getClientUrl();

                    req.open("GET", ClientUrl + "/api/data/v9.1/systemusers(" + systemuserId + ")?$select=rsa_division", true);
                    req.setRequestHeader("OData-MaxVersion", "4.0");
                    req.setRequestHeader("OData-Version", "4.0");
                    req.setRequestHeader("Accept", "application/json");
                    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                    req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                    req.onreadystatechange = function () {
                        if (this.readyState === 4) {
                            req.onreadystatechange = null;
                            if (this.status === 200) {
                                var result = JSON.parse(this.response);
                                division = result["rsa_division"];
                                if (division !== '866760003' && numberdialled === null && hasValue === true && status === 866760004) {
                                    formContext.getAttribute("rsa_numberdialled").setRequiredLevel("required");
                                }
                                else {
                                    formContext.getAttribute("rsa_numberdialled").setRequiredLevel("none");
                                }

                            } else {
                                Xrm.Navigation.openAlertDialog(this.statusText);
                            }
                        }
                    };
                    req.send();

                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "NumberDialledRequiredField-" + err.message });
        }
    },

    CheckUserRole: function (formContext) {
        var allroles = [];
        var userSettings = Xrm.Utility.getGlobalContext().userSettings;
        var userRoleNamearray = userSettings.roles.getAll();


        for (var i = 0; i < userRoleNamearray.length; i++) {

            var userRoleName = userRoleNamearray[i].name;
            if (userRoleName === "CSI BPO Handler") {
                allroles[i] = 1;
                //return value;
            }
            if (userRoleName === "CSI BPO Manager") {
                allroles[i] = 2;
                // return value;
            }
            if (userRoleName === "CSI Marketing") {
                allroles[i] = 3;
                //return value;
            }
            if (userRoleName === "System Administrator") {
                allroles[i] = 4;
                //return value;
            }
            if (userRoleName === "CSI Sales User") {
                allroles[i] = 5;
                //return value;
            }
            if (userRoleName === "CSI MI/Data Analyst") {
                allroles[i] = 6;
                //return value;
            }
            if (userRoleName === "CSI Integration") {
                allroles[i] = 7;
                //return value;
            }

        }
        return allroles;
    },

    RSAMARKETINGEditTask: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_tasktype") !== null && formContext.getAttribute("rsa_tasktype") !== "undefined" && formContext.getAttribute("rsa_tasktype").getValue() !== null &&
                formContext.getAttribute("rsa_status") !== null &&
                formContext.getAttribute("rsa_description") !== null && formContext.getAttribute("ownerid") !== null) {
                var taskTypeId = formContext.getAttribute("rsa_tasktype").getValue()[0].name;
                var taskTypeArray = ["Customer Team Activity", "Customer Team Reminder"];
                var hasValue = false;
                var hastaskValue = taskTypeArray.includes(taskTypeId, 0);

                var userRole = [];
                userRole = RSA.D365CRM.Activity.Main.CheckUserRole(formContext);
                for (var i = userRole.length - 1; i >= 0; i--) {
                    if (userRole[i] === 4 || userRole[i] === 5) {
                        hasValue = true;

                    }
                }
                if (hasValue === false && hastaskValue && formContext.ui.getFormType() === 2) {
                    formContext.getAttribute("statecode").setValue(1);
                    formContext.ui.setFormNotification("Only Marketing Team is allowed to edit this record", "ERROR")

                }
                else {
                    formContext.getAttribute("statecode").setValue(0);
                    formContext.ui.clearFormNotification()
                }


            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "RSAMARKETINGEditTask -" + err.message });
        }
    },

    EnterBPOHandlingTime: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getAttribute("rsa_tasktype") !== null && formContext.getAttribute("rsa_tasktype") !== "undefined" && formContext.getAttribute("rsa_tasktype").getValue() !== null &&
                formContext.getAttribute("rsa_handlingtimemins") !== null && formContext.getAttribute("rsa_status") !== null && formContext.getAttribute("rsa_status") !== "undefined") {
                var taskTypeId = RSA.D365CRM.Activity.Main.ConvertGuid(formContext.getAttribute("rsa_tasktype").getValue()[0].id);
                var taskTypeArray = ["8db02222-f9ec-ea11-a817-000d3a649465", "8fb02222-f9ec-ea11-a817-000d3a649465"]
                var hasValue = taskTypeArray.includes(taskTypeId, 0);
                var status = formContext.getAttribute("rsa_status").getValue();

                var userRole = [];
                var rsa_handlingtimemins = formContext.getAttribute("rsa_handlingtimemins").getValue();
                userRole = RSA.D365CRM.Activity.Main.CheckUserRole(formContext);
                for (var i = userRole.length - 1; i >= 0; i--) {
                    if (rsa_handlingtimemins === null && hasValue === true && (status === 866760002 || status === 866760017 || status === 866760004) && (userRole[i] === 1 || userRole[i] === 2)) {
                        formContext.getAttribute("rsa_handlingtimemins").setRequiredLevel("required");

                    }
                    else {

                        formContext.getAttribute("rsa_handlingtimemins").setRequiredLevel("none");
                    }
                }
            }
        }
        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "EnterBPOHandlingTime -" + err.message });
        }
    },

// JavaScript source code
//Author : Prachi Paunikqar
//Date : 09 December 2020
//This Function sets form ID of Task  form to a Field named TaskformId
TaskFormID: function (executionContext) {
	/* try {
		var formContext = executionContext.getFormContext();
		var formId = formContext.ui.formSelector.getCurrentItem().getId();

		if (formContext.getAttribute("rsa_taskformid") !== null && formContext.getAttribute("rsa_taskformid") !== undefined && formContext.ui.getFormType() === 1) {

			formContext.getAttribute("rsa_taskformid").setValue(formId);
		}
	}
	catch (err) {
		Xrm.Navigation.openAlertDialog({ text: "rsa_taskformid -" + err.message });
	} */

},

 //Author : Prachi Paunikar
    //Date : 09 December 2020
    //This Function opens the correct form while opening the existing records

/* Change Summary for April 2022 Release 1 */
/* Last Modified By: Shreya Diwate*/
/* Summary of Changes: Remove Debug Code*/
/* - Reason for Change: Unexpected 'debugger' statement */
/* - Function name - LoadingExistingRecordForTask */

LoadingExistingRecordForTask: function (executionContext) {
//debugger;
        try {
			
	 	var formId, tasktypeName, tasktypeId;
    var formContext = executionContext.getFormContext();
	
	
	
     /*if (formContext.getAttribute("rsa_taskformid") !== null && formContext.getAttribute("rsa_taskformid") !== undefined && (formContext.ui.getFormType() === 2 || formContext.ui.getFormType() === 4|| formContext.ui.getFormType() === 3)) {
            if (formContext.getAttribute("rsa_taskformid").getValue() !== null && formContext.getAttribute("rsa_taskformid").getValue() !== undefined) {
                    var taskFormID = formContext.getAttribute("rsa_taskformid").getValue().toLowerCase();
                    var formguidId = formContext.ui.formSelector.getCurrentItem().getId();
					 //var entityGUID = RSA.D365CRM.Activity.Main.ConvertGuid(formContext.data.entity.getId());
                    if (formguidId !== taskFormID) { 
					if(formContext.ui.formSelector.items.get(taskFormID)!==null){
                        formContext.ui.formSelector.items.get(taskFormID).navigate();
					}
					   Xrm.Navigation.openForm({
                   entityName:"task",
                    entityId:entityGUID,
                     formId:caseFormID
                });
                    }
                }
				else{ */
			
			
	var triggerType = "onload";
	/* formId = formContext.getAttribute("rsa_taskformid").getValue();
	if(triggerType != "onchange"){
	if(formId != null && formId != undefined){
		//formContext.getAttribute("rsa_taskformid").setValue(null);
		return;
	}
	} */
	    
    var taskTypevalue = formContext.getAttribute("rsa_tasktype");
	if (taskTypevalue.getValue() === null){
        return; 
	}
    if (taskTypevalue.getValue() === null && formContext.ui.getFormType() === 2){
        return;
	}
	
	if(formContext.ui.getFormType() === 1 && triggerType != "onchange"){
		return;
	}
    
	var taskType = taskTypevalue.getValue()[0].id;
    var securityMap = new Array();
    var req = new XMLHttpRequest();
    var globalContext = Xrm.Utility.getGlobalContext();
    var ClientUrl = globalContext.getClientUrl();
    req.open("GET", ClientUrl + "/api/data/v9.1/rsa_customlabels?$select=rsa_dependentoptionsetjson,rsa_name&$filter=rsa_name eq 'SecurityRole'", false);
    req.setRequestHeader("OData-MaxVersion", "4.0");
    req.setRequestHeader("OData-Version", "4.0");
    req.setRequestHeader("Accept", "application/json");
    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
    req.onreadystatechange = function () {
        if (this.readyState === 4) {
            req.onreadystatechange = null;
            if (this.status === 200) {
                var results = JSON.parse(this.response);
                for (var i = 0; i < results.value.length; i++) {
                    var rsa_categories = results.value[i]["rsa_categories"];
                    var rsa_dependentoptionsetjson = results.value[i]["rsa_dependentoptionsetjson"];
                    var SecurityRoleMapping = JSON.parse(results.value[i]["rsa_dependentoptionsetjson"]).SecurityRoleMapping;
                    var roles = Xrm.Utility.getGlobalContext().userSettings.securityRoles;
                    for (var i = 0; i < roles.length; i++) {
                        var GUID = Xrm.Utility.getGlobalContext().userSettings.securityRoles[i];
                        SecurityRoleMapping.forEach(function (item) {
                            if (item.SecurityRoleGUID.toLowerCase() == GUID.toLowerCase())
                                securityMap.push(item.SecurityRoleValue);
                        });
                    }
                }
            }
            else {
                Xrm.Navigation.openAlertDialog({ text: "Get Security Role Mapping: " + this.statusText });
            }
        }
    };
    req.send();
    var securityRoleMappingStr = '';
    for (var k = 0; k < securityMap.length; k++) {
        securityRoleMappingStr += "<value>" + securityMap[k] + "</value>";
    }

    
    var fetchXmlQuery = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
        "<entity name='rsa_formlayoutmapping'>" +
        "<attribute name='rsa_formlayoutmappingid' />" +
        "<attribute name='rsa_name' />" +
        "<attribute name='rsa_activitytype' />" +
"<attribute name='rsa_securityrolemapping' />" +
        "<attribute name='rsa_form' />" +
        "<order attribute='rsa_name' descending='false' />" +
"<filter type='and'>" +
        "<condition attribute='rsa_activitytype'  operator='eq' value='" + taskType + "' />" +
"<condition attribute='rsa_securityrolemapping' operator='contain-values'>" + securityRoleMappingStr +
"</condition></filter>" +
        "<link-entity name='rsa_formlayout' from='rsa_formlayoutid' to='rsa_form' link-type='inner' alias='ae'>" +
        "<attribute name='rsa_formid'/>" +
        "<filter type='and'>" +
        "<condition attribute='rsa_entityname' operator='eq' value='866760002' />" +
        "</filter>" +
        "</link-entity>" +
        "</entity>" +
        "</fetch>";
    var req = new XMLHttpRequest();
    var globalContext = Xrm.Utility.getGlobalContext();
    var ClientUrl = globalContext.getClientUrl();
    req.open("GET", ClientUrl + "/api/data/v9.1/rsa_formlayoutmappings?fetchXml=" + encodeURIComponent(fetchXmlQuery), true);
    req.setRequestHeader("Prefer", 'odata.include-annotations="*"');
    req.onreadystatechange = function () {
        if (this.readyState === 4) {
            req.onreadystatechange = null;
            if (this.status === 200) {
                var results = JSON.parse(this.response);
                if (results.value.length > 0) {
                    formId = results.value[0]["ae.rsa_formid"];
                   tasktypeName = results.value[0]["_rsa_activitytype_value@OData.Community.Display.V1.FormattedValue"];
                    tasktypeId = results.value[0]["_rsa_activitytype_value"];

                    if (formId !== null) {
                        var entityFormOptions = {};
                        entityFormOptions["entityName"] = "task";
                        entityFormOptions["formId"] = formId;
                        entityFormOptions["entityId"] = formContext.data.entity.getId();

                    }
					try {
						var navigatedformId = formContext.ui.formSelector.getCurrentItem().getId();
						if (navigatedformId.toLowerCase() === formId.toLowerCase()) {
					return;
					}
					}
					catch (err) {
						Xrm.Navigation.openAlertDialog({ text: "rsa_taskformid -" + err.message });
					}
					
                  //  formContext.getAttribute("rsa_taskformid").setValue(formId);
                 //   formContext.data.entity.save();
                     var formParameters = {};
                        if (tasktypeName !== null && tasktypeId !== null) {
                            formParameters["rsa_tasktype"] = tasktypeId;
							 //formParameters["rsa_taskformid"] = formId;
                            formParameters["rsa_tasktypename"] = tasktypeName;
                            formParameters["rsa_tasktypetype"] = "rsa_activitytype";
	
                        }


                    // Open the form.
                    // Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
                           // function success(result) {

                              // // formContext.getAttribute("rsa_taskformid").setValue(formId);
                            // //   formContext.data.entity.save();
                           // },
                           // function (error) {
                               // //console.log(error);
                           // });
						   
					formContext.ui.formSelector.items.get(formId.toLowerCase()).navigate();
                }

            } else {
                Xrm.Navigation.openAlertDialog(this.statusText);
            }
        }
    };
    req.send();	
      }

        catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "LoadingExistingRecordForTask -" + err.message });
        }
    },
	
	SetVolume: function (executionContext) {
        try 
		{
var formContext = executionContext.getFormContext();
			if (formContext.getAttribute("rsa_volume") !== null && formContext.getAttribute("rsa_volume") !== undefined && formContext.getAttribute("rsa_volume").getValue() === null) {
				formContext.getAttribute("rsa_volume").setValue(1);
			}
		}
		catch (err) {
            Xrm.Navigation.openAlertDialog({ text: "SetVolume -" + err.message });
        }
        
    },

    ConvertGuid: function (str) {
        if (str) {
            str = str.replace(/[{}]/g, '');
            str = str.toUpperCase();
        }
        return str;
    }
});
