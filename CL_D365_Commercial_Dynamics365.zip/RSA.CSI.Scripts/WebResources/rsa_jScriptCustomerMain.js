"use strict";

var RSA = window.RSA || { __namespace: true, __typeName: "RSA" };
RSA.D365CRM = RSA.D365CRM || { __namespace: true, __typeName: "RSA.D365CRM" };
RSA.D365CRM.Customer = RSA.D365CRM.Customer || { __namespace: true, __typeName: "RSA.D365CRM.Customer" };
RSA.D365CRM.Customer.Main = RSA.D365CRM.Customer.Main || ({
    FormType: {
        Create: 1,
        Update: 2,
        ReadOnly: 3,
        Disabled: 4,
        BulkEdit: 6
    },
    OnLoad: function (executionContext) {
        var formContext = executionContext.getFormContext();
		
        //RSA.D365CRM.Customer.Main.RetriveOpportunityData(executionContext);
        if (formContext.ui.getFormType() === RSA.D365CRM.Customer.Main.FormType.Create) {
		RSA.D365CRM.Customer.Main.DefaultValue(executionContext);
		RSA.D365CRM.Customer.Main.DataOrigin(executionContext);
        }
        else if (formContext.ui.getFormType() === RSA.D365CRM.Customer.Main.FormType.Update) {

        }
        else if (formContext.ui.getFormType() === RSA.D365CRM.Customer.Main.FormType.Disabled) {

        }
        else if (formContext.ui.getFormType() === RSA.D365CRM.Customer.Main.FormType.BulkEdit) {

        }

    },
    OnSave: function (executionContext) {
        RSA.D365CRM.Customer.Main.PostCodePrefix(executionContext);
        RSA.D365CRM.Customer.Main.Keyword(executionContext);
        RSA.D365CRM.Customer.Main.KeywordPrefix(executionContext);
        RSA.D365CRM.Customer.Main.KeywordPrefix3(executionContext);
    },


    //Author : Prachi Paunikar
    //Date : 08 August 2020
    //Function for Post Code Prefix
    PostCodePrefix: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
			if(formContext.getAttribute("rsa_rsapostalcode") !== undefined && formContext.getAttribute("rsa_rsapostalcode") !== null && formContext.getAttribute("rsa_postcodeprefix") !== undefined && formContext.getAttribute("rsa_postcodeprefix") !== null){
				var postalCode = formContext.getAttribute("rsa_rsapostalcode").getValue();
				if (postalCode !== null) {
					if (postalCode.indexOf(" ") === -1) {
						formContext.getAttribute("rsa_postcodeprefix").setValue(postalCode);
					}
					else if (postalCode.indexOf(" ") !== -1) {
						var indexOfBlank = postalCode.indexOf(" ");
						var postalCodeSubstring = postalCode.substring(0, indexOfBlank);
						formContext.getAttribute("rsa_postcodeprefix").setValue(postalCodeSubstring);
					}
				}
			}
        }
        catch (e) {

            Xrm.Navigation.openAlertDialog("Error Message for Post Code Prefix : " + e.message);
        }
    },
	
	 //Author : Prachi Paunikar
    //Date : 07 April 2021
    //Function for Post Code Prefix for Customer Staging
    PostCodePrefixCustomerStaging: function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
			if(formContext.getAttribute("rsa_postcodefinal") !== undefined && formContext.getAttribute("rsa_postcodefinal") !== null && formContext.getAttribute("rsa_rsapostcodeprefix") !== undefined && formContext.getAttribute("rsa_rsapostcodeprefix") !== null){
				var postalCode = formContext.getAttribute("rsa_postcodefinal").getValue();
				if (postalCode !== null) {
					if (postalCode.indexOf(" ") === -1) {
						formContext.getAttribute("rsa_rsapostcodeprefix").setValue(postalCode);
					}
					else if (postalCode.indexOf(" ") !== -1) {
						var indexOfBlank = postalCode.indexOf(" ");
						var postalCodeSubstring = postalCode.substring(0, indexOfBlank);
						formContext.getAttribute("rsa_rsapostcodeprefix").setValue(postalCodeSubstring);
					}
				}
			}
        }
        catch (e) {

            Xrm.Navigation.openAlertDialog("Error Message for Post Code Prefix for Customer Staging: " + e.message);
        }
    },


    //Author : Prachi Paunikar
    //Date : 10 August 2020 
    //Function for setting value of Keyword Prefix
    KeywordPrefix: function (executionContext) {

        try {
            var formContext = executionContext.getFormContext();
			if(formContext.getAttribute("rsa_rsacustomerkeyword") !== undefined && formContext.getAttribute("rsa_rsacustomerkeyword") !== null && formContext.getAttribute("rsa_keywordprefix") !== undefined && formContext.getAttribute("rsa_keywordprefix") !== null){
				var customerKeyword = formContext.getAttribute("rsa_rsacustomerkeyword").getValue();
				if (customerKeyword !== null) {
					var len = customerKeyword.length;
					if (len === 1) {
						var keywordPrefixLen1 = customerKeyword.concat("_");
						formContext.getAttribute("rsa_keywordprefix").setValue(keywordPrefixLen1);
					}
					else {
						var keywordPrefix = customerKeyword.substring(0, 2);
						formContext.getAttribute("rsa_keywordprefix").setValue(keywordPrefix);
					}
				}
			}
        }
        catch (e) {

            Xrm.Navigation.openAlertDialog("Error Message for Keyword Prefix : " + e.message);
        }
    },
	
	 //Author : Prachi Paunikar
    //Date : 07 April 2021
    //Function for setting value of Keyword Prefix for Customer Staging
    KeywordPrefixCustomerStaging: function (executionContext) {

        try {
            var formContext = executionContext.getFormContext();
			if(formContext.getAttribute("rsa_customerkeyword") !== undefined && formContext.getAttribute("rsa_customerkeyword") !== null && formContext.getAttribute("rsa_rsakeywordprefix") !== undefined && formContext.getAttribute("rsa_rsakeywordprefix") !== null){
				var customerKeyword = formContext.getAttribute("rsa_customerkeyword").getValue();
				if (customerKeyword !== null) {
					var len = customerKeyword.length;
					if (len === 1) {
						var keywordPrefixLen1 = customerKeyword.concat("_");
						formContext.getAttribute("rsa_rsakeywordprefix").setValue(keywordPrefixLen1);
					}
					else {
						var keywordPrefix = customerKeyword.substring(0, 2);
						formContext.getAttribute("rsa_rsakeywordprefix").setValue(keywordPrefix);
					}
				}
			}
        }
        catch (e) {

            Xrm.Navigation.openAlertDialog("Error Message for Keyword Prefix for Customer Staging: " + e.message);
        }
    },

    //Modified By : Pooja Raje
    //Date : 29 december 2020 
    //Function for setting value of Keyword Prefix 3
    KeywordPrefix3: function (executionContext) {

        try {

            var formContext = executionContext.getFormContext();
			if(formContext.getAttribute("rsa_rsacustomerkeyword") !== undefined && formContext.getAttribute("rsa_rsacustomerkeyword") !== null && formContext.getAttribute("rsa_keywordprefix3") !== undefined && formContext.getAttribute("rsa_keywordprefix3") !== null && formContext.getAttribute("rsa_rsakeywordprefix3value") !== undefined && formContext.getAttribute("rsa_rsakeywordprefix3value") !== null){
				var customerKeywordPrefix3 = formContext.getAttribute("rsa_rsacustomerkeyword").getValue();
				if (customerKeywordPrefix3 !== null) {
					var len = customerKeywordPrefix3.length;
					if (len === 1) {
						var keywordPrefix3Len1 = customerKeywordPrefix3.concat("_");
						formContext.getAttribute("rsa_keywordprefix3").setValue(keywordPrefix3Len1);
						formContext.getAttribute("rsa_rsakeywordprefix3value").setValue(keywordPrefix3Len1);
					}
					else if (len === 2) {
						var keywordPrefix3Len2 = customerKeywordPrefix3.concat("_");
						formContext.getAttribute("rsa_keywordprefix3").setValue(keywordPrefix3Len2);
						formContext.getAttribute("rsa_rsakeywordprefix3value").setValue(keywordPrefix3Len2);
					}
					else {
						var keywordPrefix3 = customerKeywordPrefix3.substring(0, 3);
						formContext.getAttribute("rsa_keywordprefix3").setValue(keywordPrefix3);
						formContext.getAttribute("rsa_rsakeywordprefix3value").setValue(keywordPrefix3);
					}
				}
			}
        }
        catch (e) {

            Xrm.Navigation.openAlertDialog("Error Message for Keyword Prefix (3) : " + e.message);
        }
    },
	
	//Author : Prachi Paunikar
    //Date : 07 April 2021
    //Function for setting value of Keyword Prefix 3 for Customer Staging
    KeywordPrefix3CustomerStaging: function (executionContext) {

        try {

            var formContext = executionContext.getFormContext();
			if(formContext.getAttribute("rsa_customerkeyword") !== undefined && formContext.getAttribute("rsa_customerkeyword") !== null && formContext.getAttribute("rsa_rsakeywordprefix3") !== undefined && formContext.getAttribute("rsa_rsakeywordprefix3") !== null && formContext.getAttribute("rsa_rsakeywordprefix3value") !== undefined && formContext.getAttribute("rsa_rsakeywordprefix3value") !== null){
				var customerKeywordPrefix3 = formContext.getAttribute("rsa_customerkeyword").getValue();
				if (customerKeywordPrefix3 !== null) {
					var len = customerKeywordPrefix3.length;
					if (len === 1) {
						var keywordPrefix3Len1 = customerKeywordPrefix3.concat("_");
						formContext.getAttribute("rsa_rsakeywordprefix3").setValue(keywordPrefix3Len1);
						formContext.getAttribute("rsa_rsakeywordprefix3value").setValue(keywordPrefix3Len1);
					}
					else if (len === 2) {
						var keywordPrefix3Len2 = customerKeywordPrefix3.concat("_");
						formContext.getAttribute("rsa_rsakeywordprefix3").setValue(keywordPrefix3Len2);
						formContext.getAttribute("rsa_rsakeywordprefix3value").setValue(keywordPrefix3Len2);
					}
					else {
						var keywordPrefix3 = customerKeywordPrefix3.substring(0, 3);
						formContext.getAttribute("rsa_rsakeywordprefix3").setValue(keywordPrefix3);
						formContext.getAttribute("rsa_rsakeywordprefix3value").setValue(keywordPrefix3);
					}
				}
			}
        }
        catch (e) {

            Xrm.Navigation.openAlertDialog("Error Message for Keyword Prefix (3) for cutomer staging : " + e.message);
        }
    },
	
	//Author : Pooja Raje
    //Date : 29 December 2020 
    //Function for setting value of Key Word
    Keyword: function (executionContext) {

        try {

            var formContext = executionContext.getFormContext();
			if(formContext.getAttribute("rsa_rsacustomerkeyword") !== undefined && formContext.getAttribute("rsa_rsacustomerkeyword") !== null && formContext.getAttribute("rsa_name") !== undefined && formContext.getAttribute("rsa_name") !== null){
			var keyword = formContext.getAttribute("rsa_name").getValue();
			if (keyword !== null)
			{
				formContext.getAttribute("rsa_rsacustomerkeyword").setValue(keyword.toUpperCase());
			}
			}
        }
        catch (e) {

            Xrm.Navigation.openAlertDialog("Error Message for Keyword: " + e.message);
        }
    },
	
	//Author : Pooja Raje
    //Date : 29 December 2020 
    //Function for setting value of Key Word
    DataOrigin: function (executionContext) {

        try {

            var formContext = executionContext.getFormContext();
			if(formContext.getAttribute("rsa_dataorigin") !== undefined && formContext.getAttribute("rsa_dataorigin") !== null){
			formContext.getAttribute("rsa_dataorigin").setValue([866760000]);            
             }
        }
        catch (e) {

            Xrm.Navigation.openAlertDialog("DataOrigin: " + e.message);
        }
    }, 
	
	

//Author : Sujeet
    //Date : 29 December 2020
    //Function To set The default valuesin customer form
    DefaultValue: function (executionContext) {


        try {
            var formContext = executionContext.getFormContext();
			if((formContext.getAttribute("rsa_propertyappetite") !== undefined && formContext.getAttribute("rsa_propertyappetite") !== null)&&(formContext.getAttribute("rsa_casualtyappetite") !== undefined && formContext.getAttribute("rsa_casualtyappetite") !== null)){
			formContext.getAttribute("rsa_propertyappetite").setValue([866760000]); 
            formContext.getAttribute("rsa_casualtyappetite").setValue([866760000]);
             }
        }
        catch (e) {

            Xrm.Navigation.openAlertDialog("Default Value " + e.message);
        }
    },


});
