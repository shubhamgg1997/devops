﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Net;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;

namespace RSA.CSI.Plugins.ABR.Logic
{
    public class ABRLogic
    {
        /// <summary>
        ///  //Jyoti Bhosale : 04 Aug 2022 :  Retrieve Custom label for the getting the ABRARC multiselect optionset 
        /// </summary>
        /// <param name="context"></param>
        /// <param name="entity"></param>
        /// <param name="service"></param>
        /// <param name="tracer"></param>
        /// <returns></returns>
        public static ARCOptionsetRoot GetARCJSON(IPluginExecutionContext context, Entity entity, IOrganizationService service, ITracingService tracer)
        {
            //ABRARC related code changes done by Jyoti Bhosale
            //Jyoti Bhosale : 04 Aug 2022 :  Retrieve Custom label for the getting the ABRARC multiselect optionset 
            string ARCCondition = string.Empty;
            QueryExpression ABR_ARCExpression = new QueryExpression("rsa_customlabel");
            ABR_ARCExpression.TopCount = 1;
            ABR_ARCExpression.NoLock = true;
            ABR_ARCExpression.ColumnSet = new ColumnSet(new string[] { "rsa_dependentoptionsetjson" });
            ABR_ARCExpression.Criteria = new FilterExpression();
            ABR_ARCExpression.Criteria.AddCondition("rsa_name", ConditionOperator.Equal, "ABRARCReceivingMailboxMapping");
            EntityCollection abrArcCustomLabel = service.RetrieveMultiple(ABR_ARCExpression);
            string ReceivingEmail = string.Empty;
            string arcdependentOptionset = string.Empty;
            var objARCOptionsetRoot = new ARCOptionsetRoot();

            foreach (var item in abrArcCustomLabel.Entities)
            {
                arcdependentOptionset = Convert.ToString(item.Attributes["rsa_dependentoptionsetjson"]);
            }
            var ms1 = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(arcdependentOptionset));
            var ser1 = new DataContractJsonSerializer(objARCOptionsetRoot.GetType());
            objARCOptionsetRoot = ser1.ReadObject(ms1) as ARCOptionsetRoot;
            tracer.Trace("objARCOptionsetRoot" + objARCOptionsetRoot.ARCDetails.Count);

            return objARCOptionsetRoot;
        }
        /// <summary>
        ///  //Jyoti Bhosale : 04 Aug 2022 :  Retrieve Guid from Custom label for the getting the ABRARC multiselect optionset 
        /// </summary>
        /// <param name="context"></param>
        /// <param name="entity"></param>
        /// <param name="service"></param>
        /// <param name="tracer"></param>
        /// <returns></returns>
        public static Guid GetQueueIDForARCCases(IPluginExecutionContext context, Entity entity, IOrganizationService service, ITracingService tracer)
        {
            //Jyoti Bhosale : 04 Aug 2022 : ACR ABR change
            Guid QueueID = Guid.Empty;
            Guid MailboxID = Guid.Empty;
            ARCDetails objARCDetails = new ARCDetails();
            string ReceivingEmail = string.Empty;
            int caseSource = 0;
            ARCOptionsetRoot objARCOptionsetRoot = GetARCJSON(context, entity, service, tracer);

            tracer.Trace("objARCOptionsetRoot" + objARCOptionsetRoot.ARCDetails.Count);


            if (entity.Attributes.Contains("rsa_receivingemailbox") && entity.GetAttributeValue<EntityReference>("rsa_receivingemailbox") != null)
            {
                ReceivingEmail = Convert.ToString(entity.GetAttributeValue<EntityReference>("rsa_receivingemailbox").Id);
                tracer.Trace("Receiving email is: " + ReceivingEmail);
            }
            if (entity.Attributes.Contains("incidentstagecode") && Convert.ToString(entity.Attributes["incidentstagecode"]) != null)
            {

                caseSource = Convert.ToInt32(entity.GetAttributeValue<OptionSetValue>("incidentstagecode").Value);
                tracer.Trace("Case Source: " + caseSource);
            }
            if (caseSource == 100000001 && ReceivingEmail != null)
            {
                //                string fetchMailboxGuid = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                //  <entity name='mailbox'>
                //     <attribute name='mailboxid' />
                //        <order attribute='name' descending='false' />
                //    <filter type='and'>
                //      <condition attribute='emailaddress' operator='eq' value='{0}' />
                //    </filter>
                //  </entity>
                //</fetch>";
                //                tracer.Trace("fetchMailboxGuid: " + fetchMailboxGuid);
                //                var objresult = service.RetrieveMultiple(new FetchExpression(String.Format(fetchMailboxGuid,ReceivingEmail)));
                //                if (objresult != null && objresult.Entities.Count > 0)
                //                {
                //MailboxID = objresult[0].Attributes.Contains("mailboxid") ? ((Guid)objresult[0].Attributes["mailboxid"]): Guid.Empty;
                //tracer.Trace("MailboxID: " + MailboxID.ToString());


                if (objARCOptionsetRoot != null)
                {
                    if (objARCOptionsetRoot.ARCDetails != null)
                    {
                        tracer.Trace("objARCOptionsetRoot count: " + objARCOptionsetRoot.ARCDetails.ToString());
                        // objARCDetails = objARCOptionsetRoot.ARCDetails.Find(a => a.MailboxGUID.Equals(MailboxID.ToString()));
                        objARCDetails = objARCOptionsetRoot.ARCDetails.Find(a => a.MailboxGUID.Equals(Convert.ToString(ReceivingEmail)));
                        tracer.Trace("Json Contains Email with Queue details: " + objARCDetails.ReceivingMailbox);
                        List<QueueDetails> QueueDetails = objARCDetails.QueueDetails;
                        tracer.Trace("QueueDetails: " + QueueDetails.Count);
                        foreach (var QueueData in QueueDetails)
                        {
                            QueueID = new Guid(QueueData.QueueID);
                            tracer.Trace("QueueID : " + QueueData.QueueID);
                        }

                    }
                }
                //  }
            }

            return QueueID;
        }
        /// <summary>
        /// Get the correspondant ABR Template for the particular case
        /// </summary>
        /// <param name="entity">Case</param>
        /// <param name="service">The Service</param>
        /// <param name="tracer">The tracing service.</param>
        /// <returns></returns>
        public static EntityCollection GetABRTemplate(IPluginExecutionContext context, Entity entity, IOrganizationService service, ITracingService tracer, Entity ABRTracking)
        {
            var ms = Stream.Null;
            try
            {
                string caseTypeName = entity.GetAttributeValue<EntityReference>("rsa_casetype").Name;
                string ABRCondition = string.Empty;
                string brokerPrimaryRef = string.Empty;
                bool dealBroker = false, dealBrokerApplicable = false;
                string productName = string.Empty;
                int reviewTypeCode = -1;
                int caseSource = 0;//Jyoti Bhosale ABR ACR change
                tracer.Trace("Fetch the ABR Optionset Mapping from RSA Custom labels: ActivityBusinessRulesOptionset");

                //Sumegh Dhole : 16 Oct 2020 :  Retrieve Custom label for the getting the ABR multiselect optionset 
                QueryExpression ABRExpression = new QueryExpression("rsa_customlabel");
                ABRExpression.TopCount = 1;
                ABRExpression.NoLock = true;
                ABRExpression.ColumnSet = new ColumnSet(new string[] { "rsa_dependentoptionsetjson" });
                ABRExpression.Criteria = new FilterExpression();
                ABRExpression.Criteria.AddCondition("rsa_name", ConditionOperator.Equal, "ActivityBusinessRulesOptionset");
                EntityCollection abrCustomLabel = service.RetrieveMultiple(ABRExpression);

                string dependentOptionset = string.Empty;

                foreach (var item in abrCustomLabel.Entities)
                {
                    dependentOptionset = Convert.ToString(item.Attributes["rsa_dependentoptionsetjson"]);
                }

                tracer.Trace("Optionset Mapping retrieved: ActivityBusinessRulesOptionset");

                var abrOptionsetRoot = new ABROptionsetRoot();
                //var ms = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(dependentOptionset));
                //var ser = new DataContractJsonSerializer(abrOptionsetRoot.GetType());
                //abrOptionsetRoot = ser.ReadObject(ms) as ABROptionsetRoot;
                //ms.Close();
                //Remediation - 20/07/2022
                ms = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(dependentOptionset));
                var ser = new DataContractJsonSerializer(abrOptionsetRoot.GetType());
                abrOptionsetRoot = ser.ReadObject(ms) as ABROptionsetRoot;

                /********************************************Jyoti Bhosale*********************************************************/
                //ABRARC related code changes done by Jyoti Bhosale
                //Jyoti Bhosale : 04 Aug 2022 :  Retrieve Custom label for the getting the ABRARC multiselect optionset 

                tracer.Trace("Fetch the ABRARC Optionset Mapping from RSA Custom labels: ABRARCReceivingMailboxMapping");
                Guid QueueID = Guid.Empty;
                Guid MailboxID = Guid.Empty;
                ARCDetails objARCDetails = new ARCDetails();
                string ReceivingEmail = string.Empty;

                ARCOptionsetRoot objARCOptionsetRoot = null;
                if (entity.Attributes.Contains("rsa_receivingemailbox") && entity.GetAttributeValue<EntityReference>("rsa_receivingemailbox") != null)
                {

                    ReceivingEmail = Convert.ToString(entity.GetAttributeValue<EntityReference>("rsa_receivingemailbox").Id);
                    tracer.Trace("Receiving email is: " + ReceivingEmail);
                    caseSource = 1;
                }

                /********************************************Jyoti Bhosale*********************************************************/


                Incident objIncident = new Incident();
                tracer.Trace("Start building the fetch xml for activity business rules retrieval");

                string fetchQuery = "<fetch mapping = 'logical' distinct='true'>";
                fetchQuery += "<entity name = 'rsa_activitybusinessrule' >";
                fetchQuery += "<attribute name = 'rsa_activitybusinessruleid' />";
                fetchQuery += "<attribute name = 'rsa_name' />";
                fetchQuery += "<filter type = 'and' >";
                fetchQuery += "<condition attribute = 'statecode' value = '0' operator='eq'/>";
                if (entity.Attributes.Contains("rsa_casenumber"))
                {
                    tracer.Trace("Case Number " + entity.GetAttributeValue<string>("rsa_casenumber"));
                }
                else if (entity.Attributes.Contains("title"))
                {
                    tracer.Trace("Case Number " + entity.GetAttributeValue<string>("title"));
                }

                // Set the condition for Apply R90 Conditions
                if (entity.Attributes.Contains("rsa_applyr90conditions"))
                {
                    fetchQuery += "<condition attribute = 'rsa_applyr90conditions' operator= 'eq' value = '" + entity.GetAttributeValue<bool>("rsa_applyr90conditions") + "' />";

                    tracer.Trace("rsa_applyr90conditions " + entity.GetAttributeValue<bool>("rsa_applyr90conditions"));
                    ABRCondition += "...." + "rsa_applyr90conditions :" + entity.GetAttributeValue<bool>("rsa_applyr90conditions");
                }

                //Defect id 1835 : duplicate ABR for the set of attributes. Only enforce fulfillment is varied. 
                //Set the conditions for enforcefullfilment. If post fulfillment activities are provided then enforce post fullfillment
                OptionSetValueCollection pfActivityType = new OptionSetValueCollection();
                int pfvalue = 0;
                bool noneRequired = true;
                if (entity.Attributes.Contains("rsa_rsapolicyfulfilmentactivities") && !caseTypeName.Contains("EI&C MTA Case"))
                {

                    pfActivityType = (OptionSetValueCollection)entity.Attributes["rsa_rsapolicyfulfilmentactivities"];
                    // Defect id 1413 ABR- CQE EML Form Task are not generating in CRM when None Required is also Selected in Post Fulfilment Activities
                    // Sumegh Dhole 28 April 2021 : If only none required or nothing selected then enforcepostfullfilment will be false else true. 
                    if (pfActivityType.Contains(new OptionSetValue(866760006)) && pfActivityType.Count == 1)
                    {
                        noneRequired = false;
                    }

                    foreach (var option in pfActivityType)
                    {
                        pfvalue = option.Value;
                    }
                    tracer.Trace("linepfvalue  " + pfvalue);
                }
                // Defect id 1413 ABR- CQE EML Form Task 
                // if (entity.Attributes.Contains("rsa_rsapolicyfulfilmentactivities") && !caseTypeName.Contains("EI&C MTA Case") && (pfvalue!=866760006))
                if (entity.Attributes.Contains("rsa_rsapolicyfulfilmentactivities") && !caseTypeName.Contains("EI&C MTA Case") && noneRequired)
                {

                    tracer.Trace("line 89 ");
                    fetchQuery += "<filter type = 'or'>";
                    fetchQuery += "<condition attribute = 'rsa_enforcepostfulfillment' operator= 'eq' value = '0' />";
                    fetchQuery += "<condition attribute = 'rsa_enforcepostfulfillment' operator= 'eq' value = '1' />";
                    fetchQuery += "</filter>";
                    tracer.Trace("rsa_pfactivitytype : true");
                    ABRCondition += "...." + "rsa_rsapolicyfulfilmentactivities : true";
                }
                else
                {
                    fetchQuery += "<condition attribute = 'rsa_enforcepostfulfillment' operator= 'eq' value = '0' />";
                    tracer.Trace("rsa_pfactivitytype : false");
                    ABRCondition += "...." + "rsa_rsapolicyfulfilmentactivities : false";
                }


                //Set the fetchxml condition for broker primary reference. 
                if (entity.Contains("rsa_brokerprimaryreference") && entity.GetAttributeValue<string>("rsa_brokerprimaryreference") != null)
                {
                    brokerPrimaryRef = entity.GetAttributeValue<string>("rsa_brokerprimaryreference");

                    tracer.Trace("Broker Primary Reference " + brokerPrimaryRef);
                    ABRCondition += "...." + "rsa_brokerprimaryreference : " + brokerPrimaryRef;
                }
                else
                {
                    EntityReference brokerRef = entity.Attributes.Contains("rsa_account") ? (EntityReference)entity.Attributes["rsa_account"] : null;
                    if (brokerRef != null)
                    {
                        Entity accountRef = service.Retrieve("account", brokerRef.Id, new ColumnSet(new string[] { "rsa_primaryreference", "rsa_dealbroker" }));

                        brokerPrimaryRef = accountRef.Attributes.Contains("rsa_primaryreference") ? Convert.ToString(accountRef.Attributes["rsa_primaryreference"]) : string.Empty;
                        tracer.Trace("Broker Primary Reference " + brokerPrimaryRef);
                        dealBroker = accountRef.Attributes.Contains("rsa_dealbroker") ? (bool)accountRef.Attributes["rsa_dealbroker"] : false;
                        tracer.Trace("Deal Broker " + dealBroker);
                        dealBrokerApplicable = accountRef.Attributes.Contains("rsa_dealbroker") ? true : false;
                        ABRCondition += "...." + "rsa_brokerprimaryreference : " + brokerPrimaryRef;
                    }
                }

                if (brokerPrimaryRef != string.Empty)
                {
                    //Get the broker primary reference value to compare and get the ABR. 
                    ABRMultiselect aBRBrokerPrimaryRef = abrOptionsetRoot.ABRMultiselect.Find(a => a.AttributeName.ToLower().Equals("rsa_brokerprimaryreference"));

                    if (aBRBrokerPrimaryRef.Applicablevalues.Find(a => a.key.ToLower().Replace(" ", "").Equals(brokerPrimaryRef.ToLower().Replace(" ", ""))) != null)
                    {
                        objIncident.BrokerPrimaryReference = Convert.ToInt32(((Applicablevalue)aBRBrokerPrimaryRef.Applicablevalues.FirstOrDefault(a => a.key.ToLower().Replace(" ", "").Equals(brokerPrimaryRef.ToLower().Replace(" ", "")))).Value);

                        tracer.Trace("Broker Primary Reference ABR Optionset Map " + objIncident.BrokerPrimaryReference);
                        fetchQuery += "<filter type = 'or'>";
                        fetchQuery += "<condition attribute = 'rsa_brokerprimaryreference' operator= 'null'/>";
                        fetchQuery += "<condition attribute = 'rsa_brokerprimaryreference' operator='contain-values'>";
                        fetchQuery += " <value>" + objIncident.BrokerPrimaryReference + "</value>";
                        fetchQuery += "</condition>";
                        fetchQuery += "</filter>";
                        ABRCondition += "...." + "rsa_brokerprimaryreference : " + objIncident.BrokerPrimaryReference;
                    }
                }
                else
                {
                    fetchQuery += "<condition attribute = 'rsa_brokerprimaryreference' operator= 'null'/>";
                    ABRCondition += "...." + "rsa_brokerprimaryreference : null ";
                }
                //bug 1440 condition added for 3 case types for case reason.
                if (entity.Attributes.Contains("rsa_casereasonrsa") && (caseTypeName.ToLower().Contains("query") || caseTypeName.ToLower().Contains("mid-term adjustment") || caseTypeName.ToLower().Contains("query - sme")))
                {
                    objIncident.CaseReason = entity.GetAttributeValue<OptionSetValue>("rsa_casereasonrsa").Value;

                    tracer.Trace("Case Reason for 3 case types " + objIncident.CaseReason);
                    fetchQuery += "<filter type = 'or'>";
                    fetchQuery += "<condition attribute = 'rsa_casereason' operator= 'null'/>";
                    fetchQuery += "<condition attribute = 'rsa_casereason' operator='contain-values'>";
                    fetchQuery += " <value>" + objIncident.CaseReason + "</value>";
                    fetchQuery += "</condition>";
                    fetchQuery += "</filter>";
                    ABRCondition += "...." + "Case Reason  : " + objIncident.CaseReason;
                }
                //Set the case reason attribute value for comparison
                //date:04022021 condition added whrn case reason is null.

                else if (entity.Attributes.Contains("rsa_casereasonrsa") && (!caseTypeName.ToLower().Contains("query") || !caseTypeName.ToLower().Contains("mid-term adjustment") || !caseTypeName.ToLower().Contains("query - sme")))
                {
                    objIncident.CaseReason = entity.GetAttributeValue<OptionSetValue>("rsa_casereasonrsa").Value;

                    tracer.Trace("Case Reason " + objIncident.CaseReason);
                    fetchQuery += "<filter type = 'and'>";
                    fetchQuery += "<condition attribute = 'rsa_casereason' operator='contain-values'>";
                    fetchQuery += " <value>" + objIncident.CaseReason + "</value>";
                    fetchQuery += "</condition>";
                    fetchQuery += "</filter>";
                    ABRCondition += "...." + "Case Reason  : " + objIncident.CaseReason;
                }

                else
                {
                    fetchQuery += "<condition attribute = 'rsa_casereason' operator= 'null'/>";
                    ABRCondition += "...." + "rsa_casereason : null";
                }

                //Set the value of class of business and compare with product in activity business rules. 
                string classOfBusinessName = string.Empty;
                if (entity.Attributes.Contains("rsa_classofbusinessphoneenqid") && string.IsNullOrWhiteSpace(classOfBusinessName) && !caseTypeName.Contains("SME - RSA Online Referral"))
                {
                    //  classOfBusinessId = ((EntityReference)entity.Attributes["rsa_classofbusinessphoneenqid"]).Id;
                    classOfBusinessName = ((EntityReference)entity.Attributes["rsa_classofbusinessphoneenqid"]).Name;
                    if (string.IsNullOrWhiteSpace(classOfBusinessName))
                    {
                        Entity cobEntity = service.Retrieve("rsa_classofbusiness", ((EntityReference)entity.Attributes["rsa_classofbusinessphoneenqid"]).Id, new ColumnSet(new string[] { "rsa_name" }));
                        classOfBusinessName = cobEntity.Attributes.Contains("rsa_name") ? Convert.ToString(cobEntity.Attributes["rsa_name"]) : string.Empty;
                    }
                    tracer.Trace("rsa_classofbusinessphoneenqid " + classOfBusinessName);
                }
                if (entity.Attributes.Contains("rsa_classofbusiness") && string.IsNullOrWhiteSpace(classOfBusinessName) && !caseTypeName.Contains("SME - RSA Online Referral"))
                {
                    classOfBusinessName = Convert.ToString(entity.Attributes["rsa_classofbusiness"]);
                    tracer.Trace("rsa_classofbusiness " + classOfBusinessName);
                }
                if (entity.Attributes.Contains("rsa_classofbusinesssme") && string.IsNullOrWhiteSpace(classOfBusinessName) && !caseTypeName.Contains("SME - RSA Online Referral"))
                {
                    classOfBusinessName = Convert.ToString(entity.Attributes["rsa_classofbusinesssme"]);
                    tracer.Trace("rsa_classofbusinesssme " + classOfBusinessName);
                }

                //Get the class of business, reviewtypecdoe and product from value from opportunity or Policy
                if (entity.Attributes.Contains("rsa_opportunityid") && string.IsNullOrWhiteSpace(classOfBusinessName))
                {
                    EntityReference opportunityId = entity.Attributes.Contains("rsa_opportunityid") ? (EntityReference)entity.Attributes["rsa_opportunityid"] : null;
                    if (opportunityId != null)
                    {
                        Entity Opportunity = service.Retrieve(opportunityId.LogicalName, opportunityId.Id, new ColumnSet(new string[] { "rsa_classofbusiness", "rsa_productid" }));
                        if (!caseTypeName.Contains("SME - RSA Online Referral"))
                        {
                            classOfBusinessName = Opportunity.Attributes.Contains("rsa_classofbusiness") ? ((EntityReference)Opportunity.Attributes["rsa_classofbusiness"]).Name : string.Empty;
                        } //Defect ID 1405 : ABR not working as product not retrieved. 
                        productName = Opportunity.Attributes.Contains("rsa_productid") ? ((EntityReference)Opportunity.Attributes["rsa_productid"]).Name : string.Empty;
                        tracer.Trace("rsa_classofbusiness from opportunity as not found from case " + classOfBusinessName);
                        tracer.Trace("Data Retrieved from Opportunity " + reviewTypeCode + ": " + classOfBusinessName + " : " + productName);
                    }
                }
                else if (entity.Attributes.Contains("rsa_policyid") && string.IsNullOrWhiteSpace(classOfBusinessName))
                {
                    //Defect ID 1405 : ABR not working as product not retrieved. 
                    tracer.Trace("Get review type from policy  : " + ((EntityReference)entity.Attributes["rsa_policyid"]).Name);
                    //  if renewal type is not populated thru business rule then fetch from policy provided policy exists for case. 
                    Entity policyInfo = service.Retrieve("rsa_policy", ((EntityReference)entity.Attributes["rsa_policyid"]).Id, new ColumnSet(new string[] { "rsa_reviewtypecode", "rsa_productid", "rsa_classofbusiness" }));

                    reviewTypeCode = policyInfo.Attributes.Contains("rsa_reviewtypecode") ? ((OptionSetValue)policyInfo.Attributes["rsa_reviewtypecode"]).Value : -1;
                    if (!caseTypeName.Contains("SME - RSA Online Referral"))
                    {
                        classOfBusinessName = policyInfo.Attributes.Contains("rsa_classofbusiness") ? ((EntityReference)policyInfo.Attributes["rsa_classofbusiness"]).Name : string.Empty;
                    }
                    productName = policyInfo.Attributes.Contains("rsa_productid") ? ((EntityReference)policyInfo.Attributes["rsa_productid"]).Name : string.Empty;

                    tracer.Trace("Data Retrieved from Policy " + reviewTypeCode + " : " + classOfBusinessName + " : " + productName);
                }
                tracer.Trace("line 219" + classOfBusinessName);
                //CR 2552 retrive product from quote for Task creation
                //Modfied By :Nida
                //Modified On : 1 Feb 2022
                //if (entity.Attributes.Contains("rsa_quoteid") && string.IsNullOrWhiteSpace(productName))
                //{

                //    Entity QuoteProduct = service.Retrieve("rsa_rsaquote", ((EntityReference)entity.Attributes["rsa_quoteid"]).Id, new ColumnSet("rsa_products"));
                //    if (QuoteProduct.Contains("rsa_products"))
                //    {
                //        productName = QuoteProduct.Attributes.Contains("rsa_products") ? ((EntityReference)QuoteProduct.Attributes["rsa_products"]).Name : string.Empty;
                //    }

                //    tracer.Trace("Data Retrieved from Quote :" + productName);
                //}

                if (classOfBusinessName != string.Empty)
                {
                    ABRMultiselect aBRCoB = abrOptionsetRoot.ABRMultiselect.Find(a => a.AttributeName.ToLower().Equals("rsa_product"));
                    tracer.Trace("line 225" + classOfBusinessName.ToLower().Replace(" ", ""));

                    if (aBRCoB.Applicablevalues.Find(a => a.key.ToLower().Replace(" ", "").Equals(classOfBusinessName.ToLower().Replace(" ", ""))) != null)
                    {
                        objIncident.ClassofBusiness = Convert.ToInt32(((Applicablevalue)aBRCoB.Applicablevalues.FirstOrDefault(a => a.key.ToLower().Replace(" ", "").Equals(classOfBusinessName.ToLower().Replace(" ", "")))).Value);

                        tracer.Trace("Class of business/Product ABR Optionset Map  " + objIncident.ClassofBusiness);
                        fetchQuery += "<filter type = 'or'>";
                        fetchQuery += "<condition attribute = 'rsa_product' operator= 'null'/>";
                        fetchQuery += "<condition attribute = 'rsa_product' operator='contain-values'>";
                        fetchQuery += "<value>" + objIncident.ClassofBusiness + "</value>";
                        fetchQuery += "</condition>";
                        fetchQuery += "</filter>";
                        ABRCondition += "...." + "ClassofBusiness  : " + classOfBusinessName;
                    }
                    else
                    {
                        fetchQuery += "<condition attribute = 'rsa_product' operator= 'null'/>";//bug 1504 multiple task being created
                    }
                }
                else if (string.IsNullOrEmpty(classOfBusinessName))
                {

                    fetchQuery += "<condition attribute = 'rsa_product' operator= 'null'/>"; //bug 1261 Case assign action - to be vetted
                }

                //Set the customer type value in the activity business rule
                if (entity.Attributes.Contains("rsa_customertype"))
                {
                    objIncident.CustomerType = entity.Attributes.Contains("rsa_customertype") ? entity.GetAttributeValue<OptionSetValue>("rsa_customertype").Value : -1;
                    tracer.Trace("rsa_customertype : " + objIncident.CustomerType);
                    fetchQuery += "<filter type='or'>";
                    fetchQuery += "<condition attribute = 'rsa_customertype' operator='contain-values'>";
                    fetchQuery += " <value>" + objIncident.CustomerType + "</value>";
                    fetchQuery += "</condition>";
                    fetchQuery += "<condition attribute = 'rsa_customertype' operator= 'null' /></filter>";
                    ABRCondition += "...." + "rsa_customertype  : " + objIncident.CustomerType;
                }
                else
                {
                    fetchQuery += "<condition attribute = 'rsa_customertype' operator= 'null' />";
                    ABRCondition += "...." + "ClassofBusiness  : null ";
                }

                //Set value of deals case.
                if (entity.Attributes.Contains("rsa_dealscase"))
                {
                    objIncident.Dealscase = entity.GetAttributeValue<string>("rsa_dealscase").ToLower() == "yes" ? 1 : 0;
                    if (objIncident.Dealscase == 1)
                    {
                        tracer.Trace("Dealscase : " + objIncident.Dealscase);
                        //  fetchQuery += "<condition attribute = 'rsa_dealcase' operator= 'eq' value = '" + objIncident.Dealscase + "' />";
                        //Fix for 1894 : Sumegh Dhole : PGLS defect. Debit premium and the related tasks were not creating
                        fetchQuery += "<filter type='or'>";
                        fetchQuery += "<condition attribute = 'rsa_dealcase' operator= 'eq' value = '" + 1 + "' />";
                        fetchQuery += "<condition attribute = 'rsa_dealcase' operator= 'eq' value = '" + 0 + "' />";
                        fetchQuery += "</filter>";
                        ABRCondition += "...." + "rsa_dealscase  : " + objIncident.Dealscase;
                    }
                    else
                    {
                        fetchQuery += "<condition attribute = 'rsa_dealcase' operator= 'eq' value = '" + objIncident.Dealscase + "' />";
                    }
                }
                else
                {
                    if (dealBrokerApplicable)
                    {
                        // fetchQuery += "<condition attribute = 'rsa_dealcase' operator= 'eq' value = '" + dealBroker + "' />";
                        //Fix for 1894 : Sumegh Dhole : PGLS defect. Debit premium and the related tasks were not creating
                        fetchQuery += "<filter type='or'>";
                        fetchQuery += "<condition attribute = 'rsa_dealcase' operator= 'eq' value = '" + 1 + "' />";
                        fetchQuery += "<condition attribute = 'rsa_dealcase' operator= 'eq' value = '" + 0 + "' />";
                        fetchQuery += "</filter>";
                        ABRCondition += "...." + "rsa_dealcase  : Deals case yes and no both";
                    }
                    else
                    {
                        fetchQuery += "<condition attribute = 'rsa_dealcase' operator= 'eq' value = '" + dealBroker + "' />";
                        ABRCondition += "...." + "rsa_dealcase  : " + dealBroker;
                    }
                }

                //Set the value of Key SME broker
                if (entity.Attributes.Contains("rsa_keysmebroker"))
                {
                    objIncident.KeySMEBroker = Convert.ToString(entity.Attributes["rsa_keysmebroker"]).ToLower().Equals("yes") ? 1 : 0;

                    tracer.Trace("rsa_keysmebroker : " + objIncident.KeySMEBroker);
                    fetchQuery += "<condition attribute = 'rsa_keysmebroker' operator= 'eq' value = '" + objIncident.KeySMEBroker + "' />";
                    ABRCondition += "...." + "rsa_keysmebroker  : " + objIncident.KeySMEBroker;
                }

                //Set the value of the product SME for comparison

                if (entity.Contains("rsa_product_w"))
                {
                    productName = entity.Attributes.Contains("rsa_product_w") ? Convert.ToString(entity.Attributes["rsa_product_w"]) : string.Empty;
                    tracer.Trace("rsa_product_w : " + productName);
                }
                if (entity.Contains("rsa_productsmev2") && string.IsNullOrWhiteSpace(productName))
                {
                    productName = entity.Attributes.Contains("rsa_productsmev2") ? Convert.ToString(entity.Attributes["rsa_productsmev2"]) : string.Empty;
                    tracer.Trace("rsa_productsmev2 : " + productName);
                }
                if (entity.Contains("rsa_productlivechat") && string.IsNullOrWhiteSpace(productName))
                {
                    productName = entity.Attributes.Contains("rsa_productlivechat") ? Convert.ToString(entity.Attributes["rsa_productlivechat"]) : string.Empty;
                    tracer.Trace("rsa_productlivechat : " + productName);
                }
                if (entity.Contains("rsa_productphoneenqid") && string.IsNullOrWhiteSpace(productName))
                {
                    productName = entity.Attributes.Contains("rsa_productphoneenqid") ? ((EntityReference)entity.Attributes["rsa_productphoneenqid"]).Name : string.Empty;
                    if (string.IsNullOrWhiteSpace(productName))
                    {
                        Entity productEntity = service.Retrieve("rsa_product", ((EntityReference)entity.Attributes["rsa_productphoneenqid"]).Id, new ColumnSet(new string[] { "rsa_name" }));
                        productName = productEntity.Attributes.Contains("rsa_name") ? Convert.ToString(productEntity.Attributes["rsa_name"]) : string.Empty;
                    }
                    tracer.Trace("rsa_productphoneenqid : " + productName);
                }
                if (caseTypeName.ToLower().Contains("sme - imarket referral") && productName == string.Empty)
                {
                    tracer.Trace("Inside sme - imarket referral ");
                    fetchQuery += "<filter type = 'and'>";
                    fetchQuery += "<condition attribute = 'rsa_productsme' operator= 'null'/>";
                    //2552 for null product fetching abr rule
                    //fetchQuery += "<condition attribute = 'rsa_productsme' operator='contain-values'>";
                    //fetchQuery += "<value>" + 0 + "</value>";
                    //fetchQuery += "</condition>";
                    fetchQuery += "</filter>";
                    ABRCondition += "...." + "Productsme  : " + productName;
                }
                if (productName != string.Empty)
                {
                    ABRMultiselect aBRProductsme = abrOptionsetRoot.ABRMultiselect.Find(a => a.AttributeName.ToLower().Equals("rsa_productsme"));
                    if (aBRProductsme.Applicablevalues.Find(a => a.key.ToLower().Replace(" ", "").Equals(productName.ToLower().Replace(" ", ""))) != null)
                    {
                        objIncident.Productsme = Convert.ToInt32(((Applicablevalue)aBRProductsme.Applicablevalues.FirstOrDefault(a => a.key.ToLower().Replace(" ", "").Equals(productName.ToLower().Replace(" ", "")))).Value);
                        tracer.Trace("ProductSME ABR Optionset Map  " + objIncident.Productsme);

                        // fetchQuery += "<condition attribute = 'rsa_productsme' operator='contain-values'>";
                        // fetchQuery += " <value>" + objIncident.Productsme + "</value>";
                        // fetchQuery += "</condition>";
                        if (caseTypeName.ToLower().Contains("sme - imarket referral"))
                        {
                            tracer.Trace("Inside sme - imarket referral ");
                            fetchQuery += "<filter type = 'and'>";
                            //fetchQuery += "<condition attribute = 'rsa_productsme' operator= 'null'/>";
                            fetchQuery += "<condition attribute = 'rsa_productsme' operator='contain-values'>";
                            fetchQuery += "<value>" + objIncident.Productsme + "</value>";
                            fetchQuery += "</condition>";
                            fetchQuery += "</filter>";
                            ABRCondition += "...." + "Productsme  : " + productName;
                        }
                        else if (!caseTypeName.ToLower().Contains("sme - imarket referral"))
                        {
                            fetchQuery += "<filter type = 'or'>";
                            fetchQuery += "<condition attribute = 'rsa_productsme' operator= 'null'/>";
                            fetchQuery += "<condition attribute = 'rsa_productsme' operator='contain-values'>";
                            fetchQuery += "<value>" + objIncident.Productsme + "</value>";
                            fetchQuery += "</condition>";
                            fetchQuery += "</filter>";
                            ABRCondition += "...." + "Productsme  : " + productName;
                        }

                    }
                    else
                    {
                        fetchQuery += "<condition attribute = 'rsa_productsme' operator= 'null'/>";
                        ABRCondition += "...." + "Productsme  : null";
                    }
                }
                //else
                //{
                //    fetchQuery += "<condition attribute = 'rsa_productsme' operator= 'null'/>";
                //    ABRCondition += "...." + "Productsme  : null";
                //}


                //Set the value of the renewal review type
                if (entity.Attributes.Contains("rsa_renewalreviewtype"))
                {
                    string renewalReviewType = entity.GetAttributeValue<string>("rsa_renewalreviewtype");
                    tracer.Trace("rsa_renewalreviewtype : " + renewalReviewType);

                    ABRMultiselect aBRRenewalReviewType = abrOptionsetRoot.ABRMultiselect.Find(a => a.AttributeName.ToLower().Equals("rsa_renewalreviewtype"));
                    if (aBRRenewalReviewType.Applicablevalues.Find(a => a.key.ToLower().Replace(" ", "").Equals(renewalReviewType.Replace(" ", "").ToLower())) != null)
                    {
                        objIncident.RenewalReviewType = Convert.ToInt32(((Applicablevalue)aBRRenewalReviewType.Applicablevalues.FirstOrDefault(a => a.key.ToLower().Replace(" ", "").Equals(renewalReviewType.ToLower().Replace(" ", "")))).Value);
                        tracer.Trace("Renewal Review Type ABR Optionset Map  " + objIncident.RenewalReviewType);
                        fetchQuery += "<filter type = 'or'>";
                        fetchQuery += "<condition attribute = 'rsa_renewalreviewtype' operator= 'null'/>";
                        fetchQuery += "<condition attribute = 'rsa_renewalreviewtype' operator='contain-values'>";
                        fetchQuery += " <value>" + objIncident.RenewalReviewType + "</value>";
                        fetchQuery += "</condition>";
                        fetchQuery += "</filter>";
                        ABRCondition += "...." + "RenewalReviewType  : " + renewalReviewType;
                    }
                }
                else if (reviewTypeCode != -1)
                {
                    tracer.Trace("Get review type Code  : " + reviewTypeCode);
                    fetchQuery += "<filter type = 'or'>";
                    fetchQuery += "<condition attribute = 'rsa_renewalreviewtype' operator= 'null'/>";
                    fetchQuery += "<condition attribute = 'rsa_renewalreviewtype' operator='contain-values'>";
                    fetchQuery += " <value>" + reviewTypeCode + "</value>";
                    fetchQuery += "</condition>";
                    fetchQuery += "</filter>";
                    ABRCondition += "...." + "RenewalReviewType  : " + reviewTypeCode;
                }
                else
                {
                    fetchQuery += "<condition attribute = 'rsa_renewalreviewtype' operator= 'null'/>";
                    ABRCondition += "...." + "RenewalReviewType  : null";
                }

                //Set the value of traded 
                if (entity.Attributes.Contains("rsa_traded"))
                {
                    tracer.Trace("rsa_traded  : " + ((OptionSetValue)entity.Attributes["rsa_traded"]).Value);
                    objIncident.Traded = entity.GetAttributeValue<OptionSetValue>("rsa_traded").Value;
                    fetchQuery += "<filter type = 'or'>";
                    fetchQuery += "<condition attribute = 'rsa_traded' operator= 'null'/>";
                    fetchQuery += "<condition attribute = 'rsa_traded' operator='contain-values'>";
                    fetchQuery += " <value>" + objIncident.Traded + "</value>";
                    fetchQuery += "</condition>";
                    fetchQuery += "</filter>";
                    ABRCondition += "...." + "Traded  : " + objIncident.Traded;
                }
                else
                {
                    fetchQuery += "<condition attribute = 'rsa_traded' operator= 'null'/>";
                    ABRCondition += "...." + "Traded  : null";
                }

                //Set the value of transaction type
                if (entity.Attributes.Contains("rsa_transactiontypeid"))
                {
                    string TransactionType = entity.GetAttributeValue<EntityReference>("rsa_transactiontypeid").Name;
                    if (String.IsNullOrWhiteSpace(TransactionType))
                    {
                        Entity transactionType = service.Retrieve("rsa_transactiontype", entity.GetAttributeValue<EntityReference>("rsa_transactiontypeid").Id, new ColumnSet(new string[] { "rsa_name" }));
                        TransactionType = transactionType.Attributes.Contains("rsa_name") ? Convert.ToString(transactionType.Attributes["rsa_name"]) : string.Empty;
                    }
                    tracer.Trace("TransactionType  : " + TransactionType);
                    ABRMultiselect aBRTransactionType = abrOptionsetRoot.ABRMultiselect.Find(a => a.AttributeName.ToLower().Equals("rsa_transactiontype"));
                    if (aBRTransactionType.Applicablevalues.Find(a => a.key.ToLower().Replace(" ", "").Equals(TransactionType.ToLower().Replace(" ", ""))) != null)
                    {
                        objIncident.TransactiontType = Convert.ToInt32(((Applicablevalue)aBRTransactionType.Applicablevalues.FirstOrDefault(a => a.key.ToLower().Replace(" ", "").Equals(TransactionType.ToLower().Replace(" ", "")))).Value);
                        tracer.Trace("Transaction Type ABR Optionset Map  " + objIncident.TransactiontType);
                        //Defect No 195 : Sumegh Dhole : handled condition for transaction type
                        fetchQuery += "<filter type='or'>";
                        fetchQuery += "<condition attribute = 'rsa_transactiontype' operator='contain-values'>";
                        fetchQuery += "<value>" + objIncident.TransactiontType + "</value>";
                        fetchQuery += "</condition>";
                        fetchQuery += "<condition attribute='rsa_transactiontype' operator='null'/></filter>";
                        ABRCondition += "...." + "TransactiontType  : " + TransactionType;
                    }
                }
                else
                {
                    fetchQuery += "<condition attribute='rsa_transactiontype' operator='null'/>";
                    ABRCondition += "...." + "TransactiontType  :null";
                }
                string statusName = string.Empty;
                //Set the value of status
                if (entity.Attributes.Contains("rsa_status"))
                {
                    statusName = ((EntityReference)entity.Attributes["rsa_status"]).Name;

                    if (string.IsNullOrWhiteSpace(statusName) || !string.IsNullOrEmpty(statusName))
                    {
                        Entity Status = service.Retrieve("rsa_status", entity.GetAttributeValue<EntityReference>("rsa_status").Id, new ColumnSet(new string[] { "rsa_name" }));
                        // string statusName = ((EntityReference)entity.Attributes["rsa_status"]).Name;
                        statusName = Status.Attributes.Contains("rsa_name") ? Convert.ToString(Status.Attributes["rsa_name"]) : string.Empty;
                        tracer.Trace("statusNameTest  : " + Convert.ToString(Status.Attributes["rsa_name"]));
                    }
                    tracer.Trace("statusId  : " + ((EntityReference)entity.Attributes["rsa_status"]).Id);
                    tracer.Trace("statusName  : " + statusName);

                    if (statusName != null && !string.IsNullOrEmpty(statusName))
                    {
                        ABRCondition += "...." + "rsa_status  :" + statusName;
                        ABRMultiselect aBRStatus = abrOptionsetRoot.ABRMultiselect.Find(a => a.AttributeName.ToLower().Equals("rsa_status"));

                        //throw new InvalidPluginExecutionException();
                        if (aBRStatus.Applicablevalues.Find(a => a.key.ToLower().Replace(" ", "").Equals(statusName.ToLower().Replace(" ", ""))) != null)
                        {
                            objIncident.Status = Convert.ToInt32(((Applicablevalue)aBRStatus.Applicablevalues.FirstOrDefault(a => a.key.ToLower().Replace(" ", "").Equals(statusName.ToLower().Replace(" ", "")))).Value);
                            tracer.Trace("Status ABR Optionset Map  " + objIncident.Status);
                            fetchQuery += "<condition attribute = 'rsa_status' operator='eq' value = '" + objIncident.Status + "' />";

                        }
                        //Bug 1994, 1966 when status is no longer required and Under extension .hence No ABR Template.
                        //CR 2560 for NB and renewal these No Longer Required and Under Extension required ABR Rules available now - Modified On - 15th March 2022 - nida
                        if (statusName.Contains("No Longer Required") || statusName.Contains("Under Extension"))
                        {
                            if (!caseTypeName.ToLower().Contains("renewal") && !caseTypeName.ToLower().Contains("new business"))
                            {
                                tracer.Trace("caseTypeName line 586 :" + caseTypeName);
                                fetchQuery += "<condition attribute = 'rsa_status' operator='eq' value = '0' />";
                                tracer.Trace("As the Status is no longer required hence No ABR Template");
                            }
                        }
                    }

                }
                ///Date:04022021 - For webchat bug, when status is null.

                else
                {


                    fetchQuery += "<condition attribute = 'rsa_status' operator='eq' value = '0' />";
                    tracer.Trace("Status ABR  Map  is Null ");

                }
                //Set the value of Triggering object 
                if (entity.Attributes.Contains("rsa_casetype") && ReceivingEmail == string.Empty)//&& caseSource != 1 is added by Jyoti Bhosale for ABRARC 
                {
                    string TriggerinObjectType = entity.GetAttributeValue<EntityReference>("rsa_casetype").Name;

                    if (String.IsNullOrWhiteSpace(TriggerinObjectType))
                    {
                        Entity caseType = service.Retrieve("rsa_casetype", entity.GetAttributeValue<EntityReference>("rsa_casetype").Id, new ColumnSet(new string[] { "rsa_casetype" }));
                        TriggerinObjectType = caseType.Attributes.Contains("rsa_name") ? Convert.ToString(caseType.Attributes["rsa_casetype"]) : string.Empty;
                    }
                    tracer.Trace("TriggerinObjectType  : " + TriggerinObjectType);
                    ABRCondition += "...." + "rsa_casetype  :" + objIncident.TriggerinObjectRecordType;
                    ABRMultiselect aBRTriggeringObjectType = abrOptionsetRoot.ABRMultiselect.Find(a => a.AttributeName.ToLower().Equals("rsa_triggeringobjectrecordtype"));
                    if (aBRTriggeringObjectType.Applicablevalues.Find(a => a.key.ToLower().Replace(" ", "").Equals(TriggerinObjectType.ToLower().Replace(" ", ""))) != null)
                    {
                        objIncident.TriggerinObjectRecordType = Convert.ToInt32(((Applicablevalue)aBRTriggeringObjectType.Applicablevalues.FirstOrDefault(a => a.key.ToLower().Replace(" ", "").Equals(TriggerinObjectType.ToLower().Replace(" ", "")))).Value);
                        tracer.Trace("TriggerinObjectRecordType ABR Optionset Map  " + objIncident.TriggerinObjectRecordType);

                        fetchQuery += "<condition attribute = 'rsa_triggeringobjectrecordtype' operator='contain-values'>";
                        fetchQuery += " <value>" + objIncident.TriggerinObjectRecordType + "</value>";
                        fetchQuery += "</condition>";

                    }
                    //bug 1492
                    else
                    {
                        tracer.Trace("when case type of case does not match with any of the ABR case types");
                        fetchQuery += "<condition attribute = 'rsa_triggeringobjectrecordtype' operator='contain-values'>";
                        fetchQuery += " <value>" + 0 + "</value>";
                        fetchQuery += "</condition>";
                    }
                }

                //Set the value of triggering object to case
                fetchQuery += "<condition attribute = 'rsa_triggeringobject' operator= 'eq' value = '866760000' />";
                tracer.Trace("rsa_triggeringobject  : " + "866760000");
                ABRCondition += "...." + "rsa_triggeringobject  : Case";
                //Set the value of promise 
                objIncident.Promise = setPromiseNonPromise(service, entity, tracer);

                if (ReceivingEmail == string.Empty)//&& caseSource != 1 condition added by jyoti Bhosale for ABRARC changes
                {
                    if (objIncident.Promise != 0)
                    {
                        // objIncident.Promise = entity.GetAttributeValue<OptionSetValue>("rsa_promise").Value;
                        tracer.Trace("Promise  : " + objIncident.Promise);
                        fetchQuery += "<filter type = 'or'>";
                        //fetchQuery += "<condition attribute = 'rsa_promise' operator= 'null'/>"; //bug 1432 Promise value as null in or condition 
                        fetchQuery += "<condition attribute = 'rsa_promise' operator='contain-values'>";
                        fetchQuery += " <value>" + objIncident.Promise + "</value>"; //// date:14042021 for underwriting rationale.

                        fetchQuery += "</condition>";
                        fetchQuery += "</filter>";
                        ABRCondition += "...." + "rsa_promise  : " + objIncident.Promise;
                    }
                    else if (objIncident.Promise != 0 && !entity.Attributes.Contains("rsa_promise")) //promise
                    {
                        // objIncident.Promise = entity.GetAttributeValue<OptionSetValue>("rsa_promise").Value;
                        tracer.Trace("Promise  : " + objIncident.Promise);
                        fetchQuery += "<filter type = 'or'>";
                        fetchQuery += "<condition attribute = 'rsa_promise' operator= 'null'/>"; //bug 1810 Promise value as null in or condition 
                        fetchQuery += "<condition attribute = 'rsa_promise' operator='contain-values'>";
                        fetchQuery += " <value>" + objIncident.Promise + "</value>"; //// date:14042021 for underwriting rationale.

                        fetchQuery += "</condition>";
                        fetchQuery += "</filter>";
                        ABRCondition += "...." + "rsa_promise  : " + objIncident.Promise;
                    }
                    else if (objIncident.Promise == 0 && entity.Attributes.Contains("rsa_promise")) //non promise
                    {


                        if (objIncident.TriggerinObjectRecordType.Equals(866760008))
                        {
                            tracer.Trace("when case type is NB IOM bypassing Promise non promise condition ");
                        }
                        else
                        {
                            objIncident.Promise = entity.GetAttributeValue<OptionSetValue>("rsa_promise").Value;
                            tracer.Trace("Promise  : " + objIncident.Promise);
                            fetchQuery += "<filter type = 'or'>";
                            // fetchQuery += "<condition attribute = 'rsa_promise' operator= 'null'/>";
                            fetchQuery += "<condition attribute = 'rsa_promise' operator='contain-values'>";
                            fetchQuery += " <value>" + objIncident.Promise + "</value>";
                            fetchQuery += "</condition>";
                            fetchQuery += "</filter>";
                            ABRCondition += "...." + "rsa_promise  : " + objIncident.Promise;
                        }
                    }
                    else if (entity.Attributes.Contains("rsa_brokerpromise"))
                    {
                        string promiseValue = entity.GetAttributeValue<string>("rsa_brokerpromise");
                        tracer.Trace("Broker Promise  : " + promiseValue);
                        if (promiseValue.ToLower().Equals("promise"))
                        {
                            objIncident.Promise = 866760000;
                            ABRCondition += "...." + "rsa_promise  : Promise";
                        }
                        else
                        {
                            objIncident.Promise = 866760001;
                            ABRCondition += "...." + "rsa_promise  : Non-Promise";
                        }
                        tracer.Trace("Promise Check : ");
                        fetchQuery += "<filter type = 'or'>";
                        fetchQuery += "<condition attribute = 'rsa_promise' operator= 'null'/>";
                        fetchQuery += "<condition attribute = 'rsa_promise' operator='contain-values'>";
                        fetchQuery += " <value>" + objIncident.Promise + "</value>";
                        fetchQuery += "</condition>";
                        fetchQuery += "</filter>";

                    }
                    else
                    {
                        tracer.Trace(" final Promise  : ");
                        fetchQuery += "<condition attribute = 'rsa_promise' operator='null'/>";
                        ABRCondition += "...." + "rsa_promise  : null";
                    }
                }
                if (entity.Attributes.Contains("rsa_receivingemailbox") && entity.GetAttributeValue<EntityReference>("rsa_receivingemailbox") != null)//Add condition message is case create
                {
                    tracer.Trace("Add condition in fetchxml- Receiving mailbox");

                    if (ReceivingEmail != null)
                    {
                        //                        string fetchMailboxGuid = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                        //  <entity name='mailbox'>
                        //     <attribute name='mailboxid' />
                        //        <order attribute='name' descending='false' />
                        //    <filter type='and'>
                        //      <condition attribute='emailaddress' operator='eq' value='{0}' />
                        //    </filter>
                        //  </entity>
                        //</fetch>";
                        //                        tracer.Trace("fetchMailboxGuid: " + fetchMailboxGuid);
                        //                        var objresult = service.RetrieveMultiple(new FetchExpression(String.Format(fetchMailboxGuid, ReceivingEmail)));
                        //                        if (objresult != null && objresult.Entities.Count > 0)
                        //                        {
                        //                            MailboxID = objresult[0].Attributes.Contains("mailboxid") ? ((Guid)objresult[0].Attributes["mailboxid"]) : Guid.Empty;
                        //                            tracer.Trace("MailboxID: " + MailboxID.ToString());

                        objARCOptionsetRoot = GetARCJSON(context, entity, service, tracer);
                        if (objARCOptionsetRoot != null)
                        {
                            if (objARCOptionsetRoot.ARCDetails != null)
                            {
                                tracer.Trace("objARCOptionsetRoot count" + objARCOptionsetRoot.ARCDetails.Count);

                                ARCDetails objARC = objARCOptionsetRoot.ARCDetails.Find(a => a.MailboxGUID.Equals(Convert.ToString(ReceivingEmail)));
                                if (objARC.MailboxGUID != null)
                                {
                                    fetchQuery += "<condition attribute = 'rsa_receivingmailbox' operator='contain-values'>";
                                    fetchQuery += " <value>" + objARC.AbrMailboxValue + "</value>";
                                    fetchQuery += "</condition>";
                                    ABRCondition += "...." + "rsa_receivingmailbox  : Case";

                                }
                            }
                        }
                        // }
                    }
                    //  tracer.Trace("rsa_classofbusinessphoneenqid " + classOfBusinessName);
                }
                fetchQuery += "</filter >";
                fetchQuery += "</entity >";
                fetchQuery += "</fetch >";


                // tracer.Trace("FetchXML Query : {0}", fetchQuery);
                EntityCollection abrCol = service.RetrieveMultiple(new FetchExpression(fetchQuery));
                tracer.Trace("Count of ABR records retrieved: {0}", abrCol.Entities.Count);
                tracer.Trace("Query created for ABR:" + fetchQuery);
                Entity CaseUpdate = new Entity("incident", entity.Id);
                //CaseUpdate["description"] = ABRCondition;
                //service.Update(CaseUpdate);
                string toggle = string.Empty;
                Entity enABRtrack = toggleABRTracking(service, "ABR Tracking");
                tracer.Trace("Entity object Created" + enABRtrack.Attributes.Count());
                //string CaseNumber = entity.Attributes.Contains("title") ? entity.GetAttributeValue<string>("title"):string.Empty;
                var casetitle = service.Retrieve("incident", entity.Id, new ColumnSet("title"));
                //tracer.Trace("casetitle"+ casetitle.Id);
                if (casetitle != null)
                    ABRTracking["rsa_case"] = new EntityReference("rsa_abrtracking", casetitle.Id);

                if (context.MessageName.ToLowerInvariant() == "create")
                {
                    ABRTracking["rsa_casetriggeraction"] = new OptionSetValue(866760000);
                }
                else { ABRTracking["rsa_casetriggeraction"] = new OptionSetValue(866760001); }
                if (enABRtrack != null)
                {
                    tracer.Trace("toggle check");
                    toggle = enABRtrack.Attributes.Contains("rsa_language") ? enABRtrack.GetAttributeValue<string>("rsa_language") : string.Empty;
                    tracer.Trace("toggle check" + toggle);
                }
                if (toggle.ToLower().Contains("yes"))
                {
                    tracer.Trace("toggle check Yes");
                    ABRTracking["rsa_name"] = "ABR Tracking LOG " + DateTime.Now;
                    tracer.Trace("Name + " + ABRTracking["rsa_name"]);
                    ABRTracking["rsa_abrretrievequery"] = fetchQuery + "\n Count of ABR records retrieved: " + abrCol.Entities.Count;
                    tracer.Trace("query log for ABR pasted ");
                    WhoAmIRequest systemUserRequest = new WhoAmIRequest();
                    WhoAmIResponse systemUserResponse = (WhoAmIResponse)service.Execute(systemUserRequest);
                    Guid userId = systemUserResponse.UserId;
                    tracer.Trace("get USer ");
                    var User = service.Retrieve("systemuser", userId, new ColumnSet("firstname"));
                    ABRTracking["rsa_abrtriggeredby"] = new EntityReference("systemuser", User.Id);

                    // service.Create(ABRTracking);
                }
                string abrId = string.Empty;

                //if (abrCol.Entities.Count > 0)
                //{
                //    foreach (var objABR in abrCol.Entities)
                //    {
                //        abrId = objABR.Id.ToString();
                //        tracer.Trace("Activity Business Rule Id : {0}", abrId);
                //        break;
                //    }
                //}
                return abrCol;
            }
            catch (Exception ex)
            {
                tracer.Trace("GetABRTemplate-Error" + ex.Message.ToString());
                throw new InvalidPluginExecutionException(ex.Message);
            }
            finally
            {
                ms.Close();
            }
        }
        public static int setPromiseNonPromise(IOrganizationService service, Entity entity, ITracingService tracer)
        {
            int promiseValue = 0;
            EntityReference caseType = entity.Attributes.Contains("rsa_casetype") ? entity.GetAttributeValue<EntityReference>("rsa_casetype") : null;
            EntityReference opportunityId = entity.Attributes.Contains("rsa_opportunityid") ? entity.GetAttributeValue<EntityReference>("rsa_opportunityid") : null;
            EntityReference BrokerId = entity.Attributes.Contains("rsa_account") ? entity.GetAttributeValue<EntityReference>("rsa_account") : null;
            EntityReference policyId = entity.Attributes.Contains("rsa_policyid") ? entity.GetAttributeValue<EntityReference>("rsa_policyid") : null;
            EntityReference pandl = null;
            string promiseBroker = entity.Attributes.Contains("rsa_promisebroker") ? entity.GetAttributeValue<string>("rsa_promisebroker") : string.Empty;
            string promiseNewBusiness = null;
            string promiseRenewal = string.Empty;
            if (caseType != null)
            {
                tracer.Trace("case type found:" + caseType.Id);
                if (BrokerId != null)
                {
                    Entity BrokerData = service.Retrieve(BrokerId.LogicalName, BrokerId.Id, new ColumnSet(new string[] { "rsa_promisenewbusiness", "rsa_promiserenewal" }));
                    promiseNewBusiness = BrokerData.FormattedValues.ContainsKey("rsa_promisenewbusiness") ? BrokerData.FormattedValues["rsa_promisenewbusiness"] : null;
                    tracer.Trace("promise broker from broker value" + promiseNewBusiness);
                    promiseRenewal = BrokerData.FormattedValues.ContainsKey("rsa_promiserenewal") ? BrokerData.FormattedValues["rsa_promiserenewal"] : null;
                    tracer.Trace("promise renewal broker from broker value" + promiseRenewal);
                }



                if ((opportunityId != null && policyId != null) || (opportunityId != null && policyId == null))
                {
                    Entity opptyPl = service.Retrieve(opportunityId.LogicalName, opportunityId.Id, new ColumnSet(new string[] { "rsa_pandlid" }));
                    pandl = opptyPl.Attributes.Contains("rsa_pandlid") ? opptyPl.GetAttributeValue<EntityReference>("rsa_pandlid") : null;
                    tracer.Trace("pandl" + pandl);
                }
                else if (opportunityId == null && policyId != null)
                {
                    Entity policyPl = service.Retrieve(policyId.LogicalName, policyId.Id, new ColumnSet(new string[] { "rsa_plcode" }));
                    pandl = policyPl.Attributes.Contains("rsa_plcode") ? policyPl.GetAttributeValue<EntityReference>("rsa_plcode") : null;
                    tracer.Trace("pandl" + pandl);
                    //entity["rsa_pl_w"] = pandl.Name;
                }
                if (caseType.Name.ToLowerInvariant().Equals("new business") || caseType.Name.ToLowerInvariant().Equals("schemes - bordereaux"))
                {
                    tracer.Trace("case type name:" + caseType.Name);
                    if (promiseNewBusiness != null && pandl != null && promiseNewBusiness.ToLowerInvariant().Contains(pandl.Name.ToLowerInvariant()))
                    {
                        tracer.Trace("Promise about to set");
                        //entity["rsa_promise"] = new OptionSetValue(866760000);
                        promiseValue = 866760000;
                    }
                    else if (promiseNewBusiness != null && pandl != null && !promiseNewBusiness.ToLowerInvariant().Contains(pandl.Name.ToLowerInvariant()))
                    {
                        tracer.Trace("Non Promise about to set");
                        //entity["rsa_promise"] = new OptionSetValue(866760001);
                        promiseValue = 866760001;
                    }


                }
                else if (caseType.Name.ToLowerInvariant().Equals("renewal"))
                {
                    if (promiseRenewal != null && pandl != null && promiseRenewal.ToLowerInvariant().Contains(pandl.Name.ToLowerInvariant()))
                    {
                        tracer.Trace("Promise renewal about to set");
                        //enCaseTarget["rsa_promise"] = new OptionSetValue(866760000);
                        promiseValue = 866760000;
                    }
                    else if (promiseRenewal != null && pandl != null && !promiseRenewal.ToLowerInvariant().Contains(pandl.Name.ToLowerInvariant()))
                    {
                        tracer.Trace("Non Promise about to set 1");
                        //enCaseTarget["rsa_promise"] = new OptionSetValue(866760001);
                        promiseValue = 866760001;
                    }
                    else
                    {

                        tracer.Trace("Non Promise about to set 2");
                        //enCaseTarget["rsa_promise"] = new OptionSetValue(866760001);
                        promiseValue = 866760001;
                    }

                }
            }
            return promiseValue;
        }
        //Nida: 14 June 2022 :depth commented for 2511 task creation issue
        /// <summary>
        /// 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="caseEntity"></param>
        /// <param name="tracer"></param>
        /// <param name="ABRExecutionStatus"></param>
        /// <param name="statusID"></param>
        public void updateCaseABRStatus(IOrganizationService service, Entity caseEntity, ITracingService tracer, int ABRExecutionStatus, Guid statusID)
        {
            try
            {
                Entity caseRecord = new Entity("incident", caseEntity.Id);
                if (statusID != Guid.Empty)
                {
                    caseEntity["rsa_status"] = new EntityReference("rsa_status", statusID);
                }
                tracer.Trace("statusID Updated in updateCaseABRStatus");

                caseRecord["rsa_abrexecutionstatus"] = new OptionSetValue(ABRExecutionStatus);
                tracer.Trace("rsa_abrexecutionstatus Updated with" + ABRExecutionStatus);
                service.Update(caseRecord);
            }
            catch (Exception ex)
            {
                tracer.Trace("updateCaseABRStatus-Error" + ex.Message.ToString());
                throw new InvalidPluginExecutionException(ex.Message);
            }

        }

        /// <summary>
        /// Get the ABR Actions for the Activity Business Rule
        /// </summary>
        /// <param name="entity">Case</param>
        /// <param name="service">The Service</param>
        /// <param name="tracer">The tracing service.</param>
        /// <param name="abrId">Activity Business Rule ID</param>
        /// <param name="opportunityId">Opportunity ID</param>
        public void GetABRActions(IOrganizationService service, ITracingService tracer, Guid caseID, Guid abrId, Guid opportunityId, Entity ABRTracking, Guid arcQueueID)
        {
            try
            {
                QueryExpression queryExp = new QueryExpression("rsa_abraction");
                queryExp.ColumnSet = new ColumnSet(new string[] { "rsa_relatedtargetobject", "rsa_fieldtoupdate", "rsa_valuetoset", "rsa_casestatus", "rsa_queue", "rsa_opportunitystage", "rsa_copyreason" });
                queryExp.Criteria.AddCondition("rsa_activitytemplate", ConditionOperator.Equal, abrId);
                queryExp.NoLock = true;
                EntityCollection objABRActions = (EntityCollection)service.RetrieveMultiple(queryExp);
                tracer.Trace("Activity Business Rule Actions Count : {0}", objABRActions.Entities.Count);
                ABRTracking["rsa_abractionretrieved"] = objABRActions.Entities.Count.ToString();
                //service.Create(ABRTracking);
                if (objABRActions.Entities.Count > 0)
                {
                    foreach (var action in objABRActions.Entities)
                    {
                        string objRelatedTargetObject = action.Contains("rsa_relatedtargetobject") ? action.FormattedValues["rsa_relatedtargetobject"] : string.Empty;

                        tracer.Trace("Activity Business Rule Actions objRelatedTargetObject : {0}", objRelatedTargetObject);

                        string objFieldtoUpdate = action.Contains("rsa_fieldtoupdate") ? action.FormattedValues["rsa_fieldtoupdate"] : string.Empty;
                        tracer.Trace("Activity Business Rule Actions objFieldtoUpdate : {0}", objFieldtoUpdate);
                        int iValuetoset = action.Attributes.Contains("rsa_valuetoset") ? action.GetAttributeValue<OptionSetValue>("rsa_valuetoset").Value : 0;
                        tracer.Trace("Activity Business Rule Actions iValuetoset : {0}", iValuetoset);

                        EntityReference status = action.Contains("rsa_casestatus") ? action.GetAttributeValue<EntityReference>("rsa_casestatus") : null;
                        tracer.Trace("Activity Business Rule Actions status : {0}", status);
                        EntityReference queue = action.Contains("rsa_queue") ? action.GetAttributeValue<EntityReference>("rsa_queue") : null;
                        tracer.Trace("Activity Business Rule Actions queue : {0}", queue);
                        EntityReference stage = action.Contains("rsa_opportunitystage") ? action.GetAttributeValue<EntityReference>("rsa_opportunitystage") : null;
                        tracer.Trace("Activity Business Rule Actions iValuetoset : {0}", iValuetoset);

                        if (!string.IsNullOrEmpty(objRelatedTargetObject) && !string.IsNullOrEmpty(objFieldtoUpdate) && (opportunityId != Guid.Empty || caseID != Guid.Empty))
                        {
                            tracer.Trace("Start Opportunity Update.");
                            UpdateOpportunity(service, tracer, caseID, opportunityId, iValuetoset, objRelatedTargetObject, objFieldtoUpdate, status, queue, stage, arcQueueID);
                            tracer.Trace("ABR Opportunity Updated.");
                        }
                        //Code if condition Added by Jyoti Bhosale for ABRARC changes
                        if (arcQueueID != Guid.Empty)
                        {
                            tracer.Trace("Start Email to case queue update.");
                            UpdateOpportunity(service, tracer, caseID, opportunityId, iValuetoset, objRelatedTargetObject, objFieldtoUpdate, status, queue, stage, arcQueueID);
                            tracer.Trace("Case added in the queue.");
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                tracer.Trace("GetABRActions-Error" + ex.Message.ToString());
                throw new InvalidPluginExecutionException(ex.Message);
            }

        }


        /// <summary>
        /// Update the correspondance case opportunity
        /// </summary>
        /// <param name="service">The Service</param>
        /// <param name="tracer">The tracing service.</param>
        /// <param name="opportunityId">Opportunity ID</param>
        /// <param name="valuetoset">Opportunity 
        /// Parameter Guid arcQueueID added by Jyoti Bhosale for ABR ACR change</param>
        private void UpdateOpportunity(IOrganizationService service, ITracingService tracer, Guid caseID, Guid opportunityID, Int32 valuetoSet, string relatedTargetObject, string fieldtoUpdate, EntityReference status, EntityReference queue, EntityReference stage, Guid arcQueueID)
        {
            try
            {
                tracer.Trace("Start UpdateOpportunity function");
                if (relatedTargetObject == "Opportunity" && fieldtoUpdate == "Stage" && valuetoSet != 0 && opportunityID != null && opportunityID != Guid.Empty)
                {
                    tracer.Trace("Retieve Opportunity Info.");
                    tracer.Trace("Opprtunity ID " + opportunityID);
                    tracer.Trace("Retieve Opportunity started.");
                    Entity Opportunity = service.Retrieve("opportunity", opportunityID, new ColumnSet(new string[] { "rsa_lineofbusiness" }));
                    tracer.Trace("Retieve Opportunity Info Completed");
                    Guid statusRef = Guid.Empty;
                    Guid lobRef = Opportunity.Attributes.Contains("rsa_lineofbusiness") ? ((EntityReference)Opportunity.Attributes["rsa_lineofbusiness"]).Id : Guid.Empty;
                    tracer.Trace("Retieve Opportunity Info Completed" + lobRef);
                    if (Opportunity.Attributes.Contains("rsa_lineofbusiness"))
                    {
                        string statusName = string.Empty;

                        switch (valuetoSet)
                        {
                            case 866760000:
                                statusName = "Diverted";
                                break;
                            case 866760001:
                                statusName = "Quoted";
                                break;
                            case 866760002:
                                statusName = "Accepted";
                                break;
                            case 866760003:
                                statusName = "Not Taken Up";
                                break;
                            case 866760004:
                                statusName = "Decline to Renew";
                                break;
                            case 866760005:
                                statusName = "Renewed";
                                break;
                            case 866760006:
                                statusName = "Lapsed";
                                break;
                            case 866760007:
                                statusName = "Renewal Work Up";
                                break;
                            case 866760008:
                                statusName = "Renewal Invited";
                                break;
                            case 866760009:
                                statusName = "In Play";
                                break;
                            case 866760010:
                                statusName = "Work In Hand";
                                break;
                            case 866760023:
                                statusName = "Quote";
                                break;
                            case 866760025:
                                statusName = "Redirect to SME";
                                break;
                            case 100000010:
                                statusName = "Target and Tactics";
                                break;
                            case 866760028:
                                statusName = "Under Extension";
                                break;
                            case 866760027:
                                statusName = "No Longer Required";
                                break;
                            default:
                                break;
                        }

                        QueryExpression exp = new QueryExpression("rsa_opportunitystage");
                        exp.TopCount = 1;
                        exp.NoLock = true;
                        exp.ColumnSet = new ColumnSet(new string[] { "rsa_name" });
                        exp.Criteria = new FilterExpression();

                        ConditionExpression condition1 = new ConditionExpression();
                        condition1.AttributeName = "rsa_name";
                        condition1.Operator = ConditionOperator.Like;
                        condition1.Values.Add(statusName);

                        FilterExpression filter1 = new FilterExpression();
                        filter1.Conditions.Add(condition1);

                        ConditionExpression condition2 = new ConditionExpression();
                        condition2.AttributeName = "rsa_lineofbusiness";
                        condition2.Operator = ConditionOperator.Equal;
                        condition2.Values.Add(lobRef);

                        FilterExpression filter2 = new FilterExpression();
                        filter2.Conditions.Add(condition2);

                        exp.Criteria.AddCondition(condition1);
                        exp.Criteria.AddCondition(condition2);
                        tracer.Trace("Retieve opportunity Status");
                        EntityCollection statusCollection = service.RetrieveMultiple(exp);
                        tracer.Trace("Retieve opportunity Status Completed: " + statusCollection.Entities.Count);
                        foreach (var item in statusCollection.Entities)
                        {
                            statusRef = item.Id;
                            break;
                        }

                        //UAT defect Id 88 : Fix for stage guid if empty.
                        if (statusRef != Guid.Empty)
                        {
                            Entity opportunityUpdate = new Entity("opportunity");
                            opportunityUpdate.Id = opportunityID;
                            //Sumegh Dhole 20 Oct 2020 : Update opportunity stage
                            // rsa_opportunitystage
                            opportunityUpdate["rsa_opportunitystage"] = new EntityReference("rsa_opportunitystage", statusRef);
                            // opportunityUpdate["rsa_stage"] = new OptionSetValue(valuetoSet);
                            service.Update(opportunityUpdate);
                            tracer.Trace("Opportunity stage is update {0}", valuetoSet);
                        }
                    }
                }
                if (relatedTargetObject.ToLower().Trim() == "case" && caseID != null)
                {
                    tracer.Trace("caseID " + caseID);
                    Entity caseUpdate = new Entity("incident");
                    caseUpdate.Id = caseID;
                    if (fieldtoUpdate.ToLower().Trim() == "status" && status != null)
                    {
                        //string statusId = GetCaseTypeID(service, tracer, valuetoSet);
                        caseUpdate["rsa_status"] = new EntityReference("rsa_status", status.Id);
                        service.Update(caseUpdate);
                        tracer.Trace("Case status is update {0}", status.Id);
                    }
                    if (fieldtoUpdate.ToLower().Trim() == "ownerid" && queue != null)
                    {
                        if (queue.Id != Guid.Empty)
                        {
                            tracer.Trace(" queue." + queue.Id);
                            AddToQueueRequest routeRequest = new AddToQueueRequest
                            {
                                Target = new EntityReference("incident", caseID),
                                DestinationQueueId = queue.Id
                            };
                            service.Execute(routeRequest);
                            tracer.Trace("Activities added in queue.");
                        }
                    }
                }
                //IF Case is created from Email then assign to queue
                //abrARC changes below condition addded by Jyoti Bhosale.
                if (arcQueueID != Guid.Empty)
                {
                    tracer.Trace("ARC queue." + arcQueueID);
                    AddToQueueRequest routeRequest = new AddToQueueRequest
                    {
                        Target = new EntityReference("incident", caseID),
                        DestinationQueueId = arcQueueID
                    };
                    service.Execute(routeRequest);
                    tracer.Trace("Activities added in queue that is email to case queue");

                }
            }
            catch (Exception ex)
            {
                tracer.Trace("UpdateOpportunity-Error" + ex.Message.ToString());
                throw new InvalidPluginExecutionException(ex.Message);
            }

        }
        /// <summary>
        /// Get Case Type Id from Case Type Code
        /// </summary>
        /// <param name="service">The Service</param>
        /// <param name="tracer">The tracing service.</param>
        /// <param name="opportunityId">Opportunity ID</param>
        /// <param name="valuetoset">Opportunity Stage Value</param>
        /// <returns></returns>
        private static string GetCaseTypeID(IOrganizationService service, ITracingService tracer, Int32 statusCode)
        {
            try
            {
                string casetypeId = string.Empty;
                string fetchQuery = "<fetch mapping = 'logical'>";
                fetchQuery += "<entity name = 'rsa_status'>";
                fetchQuery += "<attribute name = 'rsa_statusid'/>";
                fetchQuery += "<filter type = 'and'> ";
                fetchQuery += "<condition attribute = 'rsa_statuscode' operator= 'eq' value = '" + statusCode + "'/>";
                //fetchQuery += "<condition attribute = 'rsa_casetype' operator= 'eq' value = 'FE6CD87C-57BC-EA11-A812-000D3AF01A07'/>";
                fetchQuery += "</filter>";
                fetchQuery += "</entity>";
                fetchQuery += "</fetch>";
                EntityCollection caseTypeCol = service.RetrieveMultiple(new FetchExpression(fetchQuery));
                if (caseTypeCol.Entities.Count > 0)
                {
                    foreach (var objCaseType in caseTypeCol.Entities)
                    {
                        casetypeId = objCaseType.Id.ToString();
                        tracer.Trace("Case Type Id : {0}", casetypeId);
                    }
                }
                return casetypeId;
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }

        /// <summary>
        /// Get the ABR Activities for the Activity Business Rule
        /// </summary>
        /// <param name="entity">ABR Task</param>
        /// <param name="service">The Service</param>
        /// <param name="tracer">The tracing service.</param>
        /// <param name="abrId">Activity Business Rule Id</param>
        public void GetABRTasks(IPluginExecutionContext context, IOrganizationService service, ITracingService tracer, Entity entityPostImage, Guid abrId, Guid opportunityId, Guid policyId, Entity ABRTracking, Guid ARCQueueId, ARCOptionsetRoot JSONConfig, string workupOwnerID)
        {
            try
            {
                //Code changes done by Jyoti Bhosale for ABRARC
                //Jyoti Bhosale: 06/08/2022 to get task SLA from RSA custom label Name:ABRARCReceivingMailboxMapping
                string BasedOn = string.Empty;
                decimal offset = 0;
                string ReceivingEmail = string.Empty;
                if (ARCQueueId != Guid.Empty)
                {
                    tracer.Trace("JSONConfig: ");
                    if (entityPostImage.Attributes.Contains("rsa_receivingemailbox") && entityPostImage.GetAttributeValue<EntityReference>("rsa_receivingemailbox") != null)
                    {
                        ReceivingEmail = Convert.ToString(entityPostImage.GetAttributeValue<EntityReference>("rsa_receivingemailbox").Id);
                        tracer.Trace("Receiving email is: " + ReceivingEmail);
                    }
                    ARCDetails objARCDetails = new ARCDetails();

                    objARCDetails = JSONConfig.ARCDetails.Find(a => a.MailboxGUID.Equals(Convert.ToString(ReceivingEmail)));
                    tracer.Trace("Json Contains Email with Queue details: " + objARCDetails.ReceivingMailbox);


                    SLADetails objSLA = new SLADetails();
                    QueueDetails q = new QueueDetails();
                    //   List<ARCDetails> ARCDetails = JSONConfig.ARCDetails;
                    //  ARCDetails objARCDetails = ARCDetails.Find(a => a.QueueDetails[0].QueueID.Equals(ARCQueueId.ToString()));
                    if (JSONConfig != null)
                    {
                        if (JSONConfig.ARCDetails != null)
                        {
                            tracer.Trace("ARCQueueId: " + ARCQueueId);
                            List<QueueDetails> queueDetails = objARCDetails.QueueDetails;


                            foreach (var qData in queueDetails)
                            {

                                tracer.Trace("Queueid " + qData.QueueID);

                                if (qData.QueueID == ARCQueueId.ToString())
                                {
                                    List<SLADetails> SLADetails = objARCDetails.SLADetails;

                                    tracer.Trace("SLADetails: " + SLADetails.Count);
                                    foreach (var SLAData in SLADetails)
                                    {
                                        BasedOn = SLAData.BasedOn;
                                        offset = Convert.ToDecimal(SLAData.DuedateOffset);
                                        tracer.Trace("BasedOn : " + BasedOn);
                                        tracer.Trace("DuedateOffset : " + offset);
                                    }
                                }
                            }

                        }
                    }
                }

                /////////////////////////////////////
                string caseTypeName = entityPostImage.GetAttributeValue<EntityReference>("rsa_casetype").Name;
                string caseStatus = entityPostImage.GetAttributeValue<EntityReference>("rsa_status").Name;
                tracer.Trace("ABR ID" + abrId);
                tracer.Trace("user" + context.UserId);
                int? userTimezone = RetrieveCurrentUsersSettings(service);
                tracer.Trace("userTimezone" + userTimezone);
                DateTime LocalTime = RetrieveLocalTimeFromUTCTime(DateTime.UtcNow, userTimezone, service);
                tracer.Trace(" DateTime LocalTime" + LocalTime);
                DateTime UTCTimeFromLocalTime = RetrieveUTCTimeFromLocalTime(LocalTime, userTimezone, service);
                tracer.Trace(" UTCTimeFromLocalTimee" + UTCTimeFromLocalTime);
                if (abrId != null)
                {
                    Entity enABR = service.Retrieve("rsa_activitybusinessrule", abrId, new ColumnSet(new string[] { "rsa_name" }));
                    string ABRnames = enABR.Contains("rsa_name") ? enABR.GetAttributeValue<string>("rsa_name") : string.Empty;
                    tracer.Trace("rsa_abrretrieved" + ABRnames);
                    ABRTracking["rsa_abrretrieved"] = ABRnames;
                }
                OptionSetValueCollection postfullfilmentActivityType = new OptionSetValueCollection();
                //abrId = Guid.Parse("1e8b4a9c-17c1-ea11-a812-000d3af02cd4");
                //Defect id 1835 : duplicate ABR for the set of attributes. Only enforce fulfillment is varied. 
                //Set the conditions for enforcefullfilment
                List<int> pfvalue = new List<int>();
                if (entityPostImage.Attributes.Contains("rsa_rsapolicyfulfilmentactivities") && !caseTypeName.Contains("EI&C MTA Case"))
                {
                    postfullfilmentActivityType = (OptionSetValueCollection)entityPostImage.Attributes["rsa_rsapolicyfulfilmentactivities"];
                    foreach (var option in postfullfilmentActivityType)
                    { //pfvalue = option.Value;
                        pfvalue.Add(option.Value);
                        tracer.Trace("linepfvalue  " + option.Value);
                    }
                    tracer.Trace("linepfvalue  " + pfvalue.Count);
                }
                // if ((pfvalue != 866760006)&& entityPostImage.Attributes.Contains("rsa_rsapolicyfulfilmentactivities") && !caseTypeName.Contains("EI&C MTA Case") )
                //OptionSetValueCollection pfActivityType = new OptionSetValueCollection();
                //if ((pfvalue != 866760006) && entityPostImage.Attributes.Contains("rsa_rsapolicyfulfilmentactivities") && !caseTypeName.Contains("EI&C MTA Case"))
                //{
                //    pfActivityType = (OptionSetValueCollection)entityPostImage.Attributes["rsa_rsapolicyfulfilmentactivities"];
                //}

                Guid caseId = entityPostImage.Id;
                QueryExpression queryExp = new QueryExpression("rsa_abrtask");
                queryExp.ColumnSet = new ColumnSet(new string[] { "rsa_subject", "rsa_name", "rsa_duedateoffset", "rsa_businesshourrequired", "rsa_warnafterhours", "rsa_duedatebasedon", "rsa_handlingtimemins", "rsa_warnafterunits", "rsa_duedateunits", "rsa_status", "rsa_duedatetime", "rsa_targetactivityrecordtype", "rsa_priority", "rsa_actualhandletimemins", "rsa_assigntemplatetaskto", "rsa_assigntemplatetasktoqueues", "rsa_pfactivitytype", "rsa_activitytype", "rsa_businessdaysrequired", "rsa_isholiday" });
                queryExp.Criteria.AddCondition("rsa_relatedto", ConditionOperator.Equal, abrId);
                queryExp.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);
                queryExp.NoLock = true;

                tracer.Trace("queryExp filter condition added");



                // Dictionary for mapping policy fullfillment from case to PFactivity in ABR Task 
                //Dictionary<case, ABR Task>
                Dictionary<int, int> pfActivityMap = new Dictionary<int, int>();
                pfActivityMap.Add(866760000, 866760001); // CQE
                pfActivityMap.Add(866760001, 866760002); // EML Form
                pfActivityMap.Add(866760002, 866760004);//Handover
                pfActivityMap.Add(866760003, 866760013); //  Welcome Call
                pfActivityMap.Add(866760004, 866760005); // Lindex Update
                pfActivityMap.Add(866760005, 866760006); // MID Update
                pfActivityMap.Add(866760006, 866760007); //None required
                pfActivityMap.Add(866760007, 866760008);// P100/101 Money Back
                pfActivityMap.Add(866760008, 866760010);// RDS
                pfActivityMap.Add(866760009, 866760011);// Re - insurance
                pfActivityMap.Add(866760010, 866760012); //  Survey Request
                pfActivityMap.Add(866760011, 866760014);// Year End Adjustment
                pfActivityMap.Add(866760012, 866760003); // ERN Chaser	

                //tracer.Trace("pfActivityType : {0}", pfActivityType.Count);
                FilterExpression mainfilter = new FilterExpression(LogicalOperator.And);
                ConditionExpression relatedto = new ConditionExpression("rsa_relatedto", ConditionOperator.Equal, abrId);
                mainfilter.AddCondition(relatedto);
                tracer.Trace("main filter condition added");
                if (pfvalue.Count() == 1 && pfvalue.Contains(866760006)) //condition for none required
                {
                    //No task to be fetched specifc to post fullfillment
                    tracer.Trace("when pf value is none required");
                }
                else if (pfvalue.Count() == 0)
                {
                    //No task to be fetched specifc to post fullfillment
                    tracer.Trace("when pf value is not selected");
                }
                else if (pfvalue.Count() > 0 && pfvalue.Contains(866760006))//none required+ something
                {
                    FilterExpression pfActivityFilter = new FilterExpression(LogicalOperator.Or);
                    tracer.Trace("none required + something");
                    ConditionExpression pfActivityCondforPFNull = new ConditionExpression("rsa_pfactivitytype", ConditionOperator.Null); //Bug 1440 null condition added for pfactivity

                    pfActivityFilter.AddCondition(pfActivityCondforPFNull);

                    //retrieve ABR tasks specifc to pfvalue List
                    foreach (var item in pfvalue)
                    {

                        if (pfActivityMap.ContainsKey(item) && !item.Equals(866760006))
                        {
                            tracer.Trace("Policy Fullfilmment activity item.Value : {0}", item);
                            ConditionExpression pfActivityCond = new ConditionExpression("rsa_pfactivitytype", ConditionOperator.Equal, (pfActivityMap.FirstOrDefault(a => a.Key == item)).Value);

                            pfActivityFilter.AddCondition(pfActivityCond);
                            tracer.Trace("Policy Fullfilmment activity condition added successfully");
                        }
                        mainfilter.AddFilter(pfActivityFilter);
                    }

                }
                else if (pfvalue.Count() > 0 && !pfvalue.Contains(866760006))
                {

                    FilterExpression pfActivityFilter = new FilterExpression(LogicalOperator.Or);

                    ConditionExpression pfActivityCondforPFNull = new ConditionExpression("rsa_pfactivitytype", ConditionOperator.Null);
                    pfActivityFilter.AddCondition(pfActivityCondforPFNull);
                    tracer.Trace("PfValue is greater than zero");

                    //retrieve ABR tasks specifc to pfvalue List
                    foreach (var item in pfvalue)
                    {

                        if (pfActivityMap.ContainsKey(item))
                        {
                            tracer.Trace("Policy Fullfilmment activity item.Value : {0}", item);
                            ConditionExpression pfActivityCond = new ConditionExpression("rsa_pfactivitytype", ConditionOperator.Equal, (pfActivityMap.FirstOrDefault(a => a.Key == item)).Value);
                            pfActivityFilter.AddCondition(pfActivityCond);
                            tracer.Trace("Policy Fullfilmment activity condition added successfully");
                        }
                        mainfilter.AddFilter(pfActivityFilter);
                    }

                }


                //#region //date:14042021 for post fullfillment activity.
                //Entity ActivityRecordName = new Entity();
                //EntityCollection businessRecordTypes = service.RetrieveMultiple(queryExp);
                //if (businessRecordTypes != null && businessRecordTypes.Entities.Count > 0)
                //{
                //    ActivityRecordName = businessRecordTypes.Entities[0];
                //}

                //string pfActivityTypeValue = ActivityRecordName.Attributes.ContainsKey("rsa_pfactivitytype") ? ActivityRecordName.FormattedValues["rsa_pfactivitytype"] : string.Empty;
                //tracer.Trace("pfActivityTypeValue : {0}", pfActivityTypeValue);
                //#endregion
                //FilterExpression mainfilter = new FilterExpression(LogicalOperator.And);
                //ConditionExpression relatedto = new ConditionExpression("rsa_relatedto", ConditionOperator.Equal, abrId);
                //mainfilter.AddCondition(relatedto);
                ////Fix for the PF activity type values. 
                //if (pfActivityType.Count >0  && !string.IsNullOrEmpty(pfActivityTypeValue))
                //{
                //    FilterExpression pfActivityFilter = new FilterExpression(LogicalOperator.Or);

                //    foreach (var item in pfActivityType)
                //    {
                //        if (pfActivityMap.ContainsKey(item.Value))
                //        {
                //            tracer.Trace("Policy Fullfilmment activity item.Value : {0}", item.Value);
                //            ConditionExpression pfActivityCond = new ConditionExpression("rsa_pfactivitytype", ConditionOperator.Equal, (pfActivityMap.FirstOrDefault(a => a.Key == item.Value)).Value);
                //            pfActivityFilter.AddCondition(pfActivityCond);
                //            tracer.Trace("Policy Fullfilmment activity condition added successfully");
                //        }
                //    }

                //    mainfilter.AddFilter(pfActivityFilter);
                //}
                queryExp.Criteria.AddFilter(mainfilter);

                #region Convert Query Expression to FetchXML
                QueryExpressionToFetchXmlRequest req = new QueryExpressionToFetchXmlRequest();
                req.Query = queryExp;
                QueryExpressionToFetchXmlResponse resp = (QueryExpressionToFetchXmlResponse)service.Execute(req);

                //work with newly formed fetch string
                string myfetch = resp.FetchXml;
                EntityCollection retrievedDetails = null;
                #endregion Convert the query expression to FetchXML.
                // tracer.Trace("queryExp for task" + myfetch);
                EntityCollection abrTasks = (EntityCollection)service.RetrieveMultiple(queryExp);

                tracer.Trace("Activities Count is : {0}", abrTasks.Entities.Count);

                // ABRTracking["rsa_abrtaskretrieved"] = abrTasks.Entities.Count.ToString();
                //service.Create(ABRTracking);
                if (abrTasks.Entities.Count > 0)
                {
                    foreach (var task in abrTasks.Entities)
                    {
                        string subject = string.Empty;
                        decimal warnafterhours = -1, handlingtimemins = -1, actualhandletimemins = -1;
                        bool businesshours = false;
                        bool isHoliday = false;
                        DateTime duedatetime = DateTime.MinValue;
                        decimal dueDateOffset = 0;
                        int status = 0;

                        //20 Oct 2020 : Sumegh Dhole : Fix for object reference error for the activities creation
                        bool BusinessDaysRequired = false;
                        if (task.Attributes.Contains("rsa_subject"))
                        {
                            subject = task.GetAttributeValue<string>("rsa_subject").ToString();
                            tracer.Trace("Activities subject is : {0}", subject);
                        }

                        // Chandani: 30/11/2022 : Added this code from line 3086 to check if Task already exist
                        bool isTaskAlreadyAvailable = false;
                        
                        if (!string.IsNullOrEmpty(subject) && entityPostImage.Id!= null)
                        {
                            tracer.Trace("BPO Initial Processing Task found. Now prepairing query to check if task already available");
                            string duplicateBPOTask = "<fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>";
                            duplicateBPOTask += "<entity name='task'>";
                            duplicateBPOTask += "<attribute name='subject' />";
                            duplicateBPOTask += "<attribute name='statecode' />";
                            duplicateBPOTask += "<attribute name='prioritycode' />";
                            duplicateBPOTask += "<attribute name='scheduledend' />";
                            duplicateBPOTask += "<attribute name='createdby' />";
                            duplicateBPOTask += "<attribute name='regardingobjectid' />";
                            duplicateBPOTask += "<attribute name='activityid' />";
                            duplicateBPOTask += "<attribute name='rsa_nextcallduedatetime' />";
                            duplicateBPOTask += "<order descending='true' attribute='modifiedon' />";
                            duplicateBPOTask += "<filter type='and'>";
                            duplicateBPOTask += "<condition attribute='regardingobjectid' value='" + entityPostImage.Id + "' uitype='incident' uiname='' operator='eq' />";
                            duplicateBPOTask += "<condition attribute='statuscode' value='5' operator='ne' />";
                            duplicateBPOTask += "<condition attribute='subject' value='" + subject + "' operator='eq'/>";
                            duplicateBPOTask += "</filter>";
                            duplicateBPOTask += "</entity>";
                            duplicateBPOTask += "</fetch>";
                            EntityCollection existingTasks = service.RetrieveMultiple(new FetchExpression(duplicateBPOTask));
                            tracer.Trace("After RetrieveMultiple");
                            if (existingTasks != null && existingTasks.Entities != null && existingTasks.Entities.Count > 0)
                            {
                                tracer.Trace("task already available: " + existingTasks.Entities.Count.ToString());
                                isTaskAlreadyAvailable = true;
                                continue;
                            }
                        }

                        int warnafterunits = task.Attributes.Contains("rsa_warnafterunits") ? task.GetAttributeValue<OptionSetValue>("rsa_warnafterunits").Value : 0;
                        if (task.Attributes.Contains("rsa_businesshourrequired"))
                        {
                            businesshours = task.GetAttributeValue<bool>("rsa_businesshourrequired");
                            tracer.Trace("Activities businesshours is : {0}", businesshours);
                        }
                        if (task.Attributes.Contains("rsa_businessdaysrequired"))
                        {
                            BusinessDaysRequired = task.GetAttributeValue<bool>("rsa_businessdaysrequired");
                            tracer.Trace("Activities businesshours is : {0}", businesshours);
                        }
                        if (task.Attributes.Contains("rsa_isholiday"))
                        {
                            isHoliday = task.GetAttributeValue<bool>("rsa_isholiday");
                            tracer.Trace("Activities isHoliday is : {0}", isHoliday);
                        }
                        if (task.Attributes.Contains("rsa_warnafterhours"))
                        {
                            warnafterhours = task.GetAttributeValue<decimal>("rsa_warnafterhours");
                            warnafterhours = task.GetAttributeValue<decimal>("rsa_warnafterhours");
                            tracer.Trace("Activities warnafterhours is : {0}", warnafterhours);
                        }
                        if (task.Attributes.Contains("rsa_status"))
                        {
                            //Jyoti Bhosale added below code for ARC Abr change
                            //09/08/2022 : Jyoti Bhosale Get Task status from Json in RsaCustom filed

                            if (entityPostImage.Attributes.Contains("rsa_receivingemailbox") && entityPostImage.GetAttributeValue<EntityReference>("rsa_receivingemailbox") != null)
                            {
                                tracer.Trace("Get Task status from JSON");
                                ARCOptionsetRoot objARCOptionsetRoot = GetARCJSON(context, entityPostImage, service, tracer);
                                ARCDetails objARCDetails = objARCOptionsetRoot.ARCDetails.Find(a => a.MailboxGUID.Equals(entityPostImage.GetAttributeValue<EntityReference>("rsa_receivingemailbox").Id.ToString()));
                                tracer.Trace("Json Contains Email with Queue details: " + objARCDetails.ReceivingMailbox);
                                status = Convert.ToInt32(objARCDetails.Taskstatus);
                                tracer.Trace("Task status from JSON: " + status);

                            }
                            //////////////////////
                            else
                                status = task.GetAttributeValue<OptionSetValue>("rsa_status").Value;
                            tracer.Trace("Activities status is : {0}", status);
                        }
                        if (task.Attributes.Contains("rsa_handlingtimemins"))
                        {
                            handlingtimemins = task.GetAttributeValue<decimal>("rsa_handlingtimemins");
                            tracer.Trace("Activities handlingtimemins is : {0}", handlingtimemins);
                        }
                        //sumegh Dhole : Changed this to activity type lookup
                        Guid targetActivityRecordType = task.Attributes.Contains("rsa_targetactivityrecordtype") && task.GetAttributeValue<EntityReference>("rsa_targetactivityrecordtype").Id != null ? task.GetAttributeValue<EntityReference>("rsa_targetactivityrecordtype").Id : Guid.Empty;
                        if (task.Attributes.Contains("rsa_duedatetime"))
                        {
                            duedatetime = task.GetAttributeValue<DateTime>("rsa_duedatetime");
                            tracer.Trace("Activities duedatetime is : {0}", duedatetime);
                        }
                        int priority = task.Contains("rsa_priority") ? task.GetAttributeValue<OptionSetValue>("rsa_priority").Value : 99;
                        if (task.Attributes.Contains("rsa_actualhandletimemins"))
                        {
                            actualhandletimemins = task.GetAttributeValue<decimal>("rsa_actualhandletimemins");
                            tracer.Trace("Activities actualhandletimemins is : {0}", actualhandletimemins);
                        }

                        int postfulfillmentactivitytype = task.Contains("rsa_pfactivitytype") ? task.GetAttributeValue<OptionSetValue>("rsa_pfactivitytype").Value : 0;
                        tracer.Trace("Activities postfulfillmentactivitytype is : {0}", postfulfillmentactivitytype);





                        //DateTime taskStartDate = DateTime.Now;
                        DateTime taskStartDate = LocalTime;
                        //DateTime taskEndDate = DateTime.Now;
                        DateTime taskEndDate = LocalTime;
                        int defaultTime = 17;
                        TimeSpan ts_DefaultTime = TimeSpan.FromHours(defaultTime);//this Variable holds time for task defaulted to 6'o clock

                        EntityCollection enNextCallDueDateTasks = null;



                        string dueDatefetchQuery = "<fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>";
                        dueDatefetchQuery += "<entity name='task'>";
                        dueDatefetchQuery += "<attribute name='subject' />";
                        dueDatefetchQuery += "<attribute name='statecode' />";
                        dueDatefetchQuery += "<attribute name='prioritycode' />";
                        dueDatefetchQuery += "<attribute name='scheduledend' />";
                        dueDatefetchQuery += "<attribute name='createdby' />";
                        dueDatefetchQuery += "<attribute name='regardingobjectid' />";
                        dueDatefetchQuery += "<attribute name='activityid' />";
                        dueDatefetchQuery += "<attribute name='rsa_nextcallduedatetime' />";
                        dueDatefetchQuery += "<order descending='true' attribute='modifiedon' />";
                        dueDatefetchQuery += "<filter type='and'>";
                        dueDatefetchQuery += "<condition attribute='regardingobjectid' value='" + entityPostImage.Id + "' uitype='incident' uiname='' operator='eq' />";
                        dueDatefetchQuery += "<condition attribute='statuscode' value='5' operator='eq' />";
                        dueDatefetchQuery += "<condition attribute='rsa_nextcallduedatetime' operator='not-null' />";
                        dueDatefetchQuery += "<filter type='or'>";
                        dueDatefetchQuery += "<condition attribute='subject' value='Quote' operator='eq'/>";
                        dueDatefetchQuery += "<condition attribute='subject' value='Quote Conversation' operator='eq'/>";
                        dueDatefetchQuery += "<condition attribute='subject' value='Chase' operator='eq'/>";
                        dueDatefetchQuery += "<condition attribute='subject' value='Chase Conversation' operator='eq'/>";
                        dueDatefetchQuery += "<condition attribute='subject' value='Feedback Conversation' operator='eq'/>";
                        dueDatefetchQuery += "<condition attribute='subject' value='Vetting' operator='eq'/>";
                        dueDatefetchQuery += "<condition attribute='subject' value='Vetting Conversation' operator='eq'/>";
                        dueDatefetchQuery += "<condition attribute='subject' value='Chase Call' operator='eq'/>";
                        dueDatefetchQuery += "</filter>";
                        dueDatefetchQuery += "</filter>";
                        dueDatefetchQuery += "</entity>";
                        dueDatefetchQuery += "</fetch>";

                        //string sQuery = string.Format(dueDatefetchQuery, entityPostImage.Id);
                        bool flagDueDate = false;
                        enNextCallDueDateTasks = service.RetrieveMultiple(new FetchExpression(dueDatefetchQuery));
                        //Entity retrievedTask = new Entity();
                        tracer.Trace("Count of enNextCallDueDateTasks: {0}", enNextCallDueDateTasks.Entities.Count);
                        DateTime nextCallDueDate = DateTime.MinValue;
                        if (enNextCallDueDateTasks != null && enNextCallDueDateTasks.Entities.Count() > 0) //=0
                        {
                            if (context.MessageName.ToLowerInvariant() == "update" && (subject.Equals("Quote") || subject.Equals("Quote Conversation")
                        || subject.Equals("Chase") || subject.Equals("Chase Conversation") || subject.Equals("Feedback Conversation") || subject.Equals("Chase Call"))
                        )
                            {
                                if (enNextCallDueDateTasks.Entities[0].Attributes.Contains("rsa_nextcallduedatetime"))
                                {
                                    tracer.Trace("inside if of next call due date");
                                    nextCallDueDate = (DateTime)enNextCallDueDateTasks.Entities[0]["rsa_nextcallduedatetime"];
                                    tracer.Trace("nextCallDueDate" + nextCallDueDate);
                                }
                                string taskname = enNextCallDueDateTasks.Entities[0].Attributes.Contains("rsa_name") ? enNextCallDueDateTasks.Entities[0].GetAttributeValue<string>("rsa_name") : string.Empty;
                                tracer.Trace("taskname" + taskname);
                                if (nextCallDueDate != DateTime.MinValue)
                                {
                                    taskEndDate = nextCallDueDate;
                                    tracer.Trace("taskenddate when End date flows froms previous record     :-  " + taskEndDate);
                                }
                            }
                            else { flagDueDate = true; }
                        }
                        else { flagDueDate = true; }

                        #region bug 2176
                        if (flagDueDate == false)
                        {
                            Entity opportunityUpdate = new Entity("task");
                            //INC2302030: Dynamics issue - Tasks are not allocating to the case owner || Modified on 21.11.2022 || Modified by Samiksha Dhakde
                            opportunityUpdate["ownerid"] = new EntityReference("systemuser", context.InitiatingUserId);
                            if (task.Attributes.Contains("rsa_activitytype"))
                            {
                                opportunityUpdate["rsa_tasktype"] = task.GetAttributeValue<EntityReference>("rsa_activitytype");
                            }
                            opportunityUpdate["rsa_casetotaskid"] = new EntityReference("incident", caseId);//bug id 1710
                            opportunityUpdate["subject"] = subject;
                            opportunityUpdate["regardingobjectid"] = new EntityReference("incident", caseId);
                            if (warnafterhours != -1)
                            {
                                opportunityUpdate["rsa_warnafterhours"] = warnafterhours;
                            }
                            opportunityUpdate["rsa_businesshourrequired"] = businesshours;
                            opportunityUpdate["rsa_warnafterhours"] = warnafterhours;
                            if (handlingtimemins != -1)
                            {
                                opportunityUpdate["rsa_handlingtimemins"] = handlingtimemins;
                            }
                            if (warnafterunits != 0)
                                opportunityUpdate["rsa_warnafterunits"] = new OptionSetValue(warnafterunits);
                            if (status != 0)
                                opportunityUpdate["rsa_status"] = new OptionSetValue(status);
                            //if (duedatetime != DateTime.MinValue)//commented on 27052021 Bug 1616 Duedatetime is = task Due date
                            //    opportunityUpdate["rsa_duedatetime"] = duedatetime;
                            //if (taskStartDate != DateTime.MinValue) //commented as due date = due date/time always
                            //{
                            //    //opportunityUpdate["rsa_duedatetime"] = taskStartDate;
                            //}

                            if (targetActivityRecordType != Guid.Empty)
                                opportunityUpdate["rsa_targetactivityrecordtype"] = new EntityReference("rsa_targetactivityrecordtype", targetActivityRecordType);
                            if (priority != 99)
                                opportunityUpdate["prioritycode"] = new OptionSetValue(priority);
                            if (taskStartDate != DateTime.MinValue)
                            {
                                tracer.Trace("Line 1535");
                                opportunityUpdate["scheduledstart"] = taskStartDate;

                            }
                            if (taskStartDate == taskEndDate)
                            {
                                int result = TimeSpan.Compare(taskStartDate.TimeOfDay, taskEndDate.TimeOfDay);
                                if (taskStartDate != DateTime.MinValue && (result > 0 || result == 0))
                                {
                                    tracer.Trace("Line 1566");
                                    opportunityUpdate["scheduledend"] = taskEndDate;
                                    opportunityUpdate["rsa_duedatetime"] = taskEndDate;
                                }
                                else if (result < 0)
                                {
                                    tracer.Trace("Line 1571");
                                    opportunityUpdate["scheduledend"] = taskStartDate;
                                    opportunityUpdate["rsa_duedatetime"] = taskStartDate;
                                }
                            }
                            opportunityUpdate["rsa_volume"] = Convert.ToDecimal(1); // bug 1579
                            if (taskStartDate < taskEndDate)
                            {
                                if (taskStartDate != DateTime.MinValue)
                                {
                                    tracer.Trace("Line 1581");
                                    opportunityUpdate["scheduledend"] = taskEndDate;
                                    opportunityUpdate["rsa_duedatetime"] = taskEndDate;

                                }
                            }
                            //Modified On : 04 July 2022; Modified By: Nida; Description: INC-2190354

                            //if (taskStartDate > taskEndDate)
                            //{
                            //    if (taskStartDate != DateTime.MinValue)
                            //    {
                            //        tracer.Trace("Line 1581");
                            //        opportunityUpdate["scheduledend"] = taskEndDate;
                            //        opportunityUpdate["rsa_duedatetime"] = taskEndDate;

                            //    }
                            //}
                            if (actualhandletimemins != -1)
                            {
                                opportunityUpdate["rsa_actualhandletimemins"] = actualhandletimemins;
                            }

                            if (postfulfillmentactivitytype != 0 && postfulfillmentactivitytype != 1 && postfulfillmentactivitytype != null)
                                opportunityUpdate["rsa_postfulfillmentactivitytype"] = new OptionSetValue(postfulfillmentactivitytype);
                            string assigntemplatetaskto = task.Attributes.ContainsKey("rsa_assigntemplatetaskto") ? task.FormattedValues["rsa_assigntemplatetaskto"] : null;
                            tracer.Trace(" assigntemplatetaskto" + assigntemplatetaskto);
                            bool flag = false;
                            string formID = string.Empty;
                            Guid entaskID = Guid.Empty;
                            Guid useridcheck = context.InitiatingUserId;
                            tracer.Trace("useridcheck" + useridcheck);
                            //List<string> RoleName = new List<string>();
                            //EntityCollection securityRole = getUserRole(service, context.InitiatingUserId, tracer);
                            //tracer.Trace("securityRole line 1570" + securityRole.Entities.Count);
                            //foreach (var item in securityRole.Entities)
                            //{
                            //    // tracer.Trace("Inside Foreach line 1573");
                            //    if (item.Attributes.Contains("role2.name"))
                            //    {
                            //        // tracer.Trace("item.Attributes.Contains(role2.name)");
                            //        AliasedValue AvUserRole = (AliasedValue)item.Attributes["role2.name"];
                            //        //tracer.Trace("AvUserRole Aliased value" + AvUserRole.Value);
                            //        RoleName.Add((Convert.ToString(AvUserRole.Value)));
                            //    }
                            //    //tracer.Trace("userRole"+ RoleName.ToString());
                            //}
                            //RoleName = RoleName.Select(s => s = s.Replace(" ", "")).ToList();
                            //    //  # region
                            //foreach(var item in RoleName)
                            //  {
                            //      tracer.Trace("item line 1587" + item.ToString());
                            //  }
                            //      //#endregion


                            //EntityReference taskID = task.Attributes.Contains("rsa_activitytype") ? task.GetAttributeValue<EntityReference>("rsa_activitytype") : null;

                            //entaskID = taskID.Id;
                            //tracer.Trace("entaskID" + entaskID);
                            #region 
                            //form layout mapping and related source code is no longer required. hence commenting. 
                            //Sumegh Dhole : 20 Aug 2021 
                            //  if (taskID != null)
                            //  {
                            //var fetchXmlQuery = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' no-lock='true'>";
                            //fetchXmlQuery += "<entity name='rsa_formlayoutmapping'>";
                            //fetchXmlQuery += "<attribute name='rsa_formlayoutmappingid' />";
                            //fetchXmlQuery += "<attribute name='rsa_name' />";
                            //fetchXmlQuery += "<attribute name='rsa_activitytype' />";
                            //fetchXmlQuery += "<attribute name='rsa_form' />";
                            //fetchXmlQuery += "<attribute name='rsa_securityrolemapping' />";
                            //fetchXmlQuery += "<order attribute='rsa_name' descending='false' />";
                            //fetchXmlQuery += "<filter type='and'>";
                            //fetchXmlQuery += "<condition attribute='rsa_activitytype' operator='eq' value= '" + taskID.Id + "'/>";
                            //fetchXmlQuery += "</filter>";
                            //fetchXmlQuery += "<link-entity name='rsa_formlayout' from='rsa_formlayoutid' to='rsa_form' link-type='inner' alias='ae'>";
                            //fetchXmlQuery += "<attribute name='rsa_formid'/>";
                            //fetchXmlQuery += "<filter type='and'>";
                            //fetchXmlQuery += "<condition attribute='rsa_entityname' operator='eq' value='866760002' />";
                            //fetchXmlQuery += "</filter>";
                            //fetchXmlQuery += "</link-entity>";
                            //fetchXmlQuery += "</entity>";
                            //fetchXmlQuery += "</fetch>";
                            //// tracer.Trace("FetchXML Query : {0}", fetchXmlQuery);
                            //  string securityroleoptionset = string.Empty;
                            //EntityCollection formLayoutMapping = service.RetrieveMultiple(new FetchExpression(fetchXmlQuery));
                            //  tracer.Trace("Count of Formlayouts: {0}", formLayoutMapping.Entities.Count);
                            //if (formLayoutMapping.Entities.Count > 0)
                            //{
                            //    foreach (var SecurityRoleMap in formLayoutMapping.Entities)
                            //    {
                            //        securityroleoptionset = SecurityRoleMap.FormattedValues["rsa_securityrolemapping"];

                            //        tracer.Trace("securityroleoptionset line1624 : {0}", securityroleoptionset);
                            //        //if (aBRTransactionType.Applicablevalues.Find(a => a.key.ToLower().Replace(" ", "").Equals(TransactionType.ToLower().Replace(" ", ""))) != null)

                            //        List<string> securityroleList = securityroleoptionset.Split(';').ToList();
                            //        securityroleList = securityroleList.Select(t => t.Replace(" ", "")).ToList();
                            //        #region
                            //        //foreach (var item in securityroleList)
                            //        //{
                            //        //    tracer.Trace("item line 1635" + item.ToString());
                            //        //}

                            //        #endregion
                            //        if (securityroleList.Intersect(RoleName).Any())
                            //        {
                            //            tracer.Trace("success");
                            //            flag = true;
                            //            formID = Convert.ToString(((AliasedValue)SecurityRoleMap.Attributes["ae.rsa_formid"]).Value);
                            //            tracer.Trace("FormID : {0}", formID);
                            //            break;
                            //        }
                            //    }
                            //}


                            //if (formLayoutMapping.Entities.Count > 0 && flag == false)
                            //{
                            //    foreach (var formLayout in formLayoutMapping.Entities)
                            //    {
                            //        formID = Convert.ToString(((AliasedValue)formLayout.Attributes["ae.rsa_formid"]).Value);
                            //        tracer.Trace("FormID : {0}", formID);
                            //        break;
                            //    }
                            //}
                            // }
                            #endregion
                            // opportunityUpdate["rsa_taskformid"] = formID;

                            tracer.Trace("Policy Id : " + policyId);
                            tracer.Trace("Opportunity Id : " + opportunityId);
                            if (!string.IsNullOrEmpty(assigntemplatetaskto) && assigntemplatetaskto.ToLower() == "owner")
                            {
                                //EntityReference ownerId = entityPostImage.Contains("ownerid") && entityPostImage.GetAttributeValue<EntityReference>("ownerid") != null ? entityPostImage.GetAttributeValue<EntityReference>("ownerid") : null;

                                service.Create(opportunityUpdate);

                                tracer.Trace("Activities created.");
                            }
                            else if (!string.IsNullOrEmpty(assigntemplatetaskto) && assigntemplatetaskto.ToLower() == "queue")
                            {
                                tracer.Trace("line 1617");


                                Guid queueId = task.Contains("rsa_assigntemplatetasktoqueues") ? task.GetAttributeValue<EntityReference>("rsa_assigntemplatetasktoqueues").Id : Guid.Empty;
                                tracer.Trace("queueId" + queueId);
                                if (queueId != Guid.Empty)
                                {
                                    opportunityUpdate["rsa_queue"] = new EntityReference("queue", queueId);//bug 1618 Queue not assigned
                                                                                                           //service.Update(opportunityUpdate);
                                }
                                Guid taskId = service.Create(opportunityUpdate);
                                tracer.Trace("taskId" + taskId);
                                //bug 2141 : task get assigned to unassigned user.
                                tracer.Trace("calling getuser function");
                                Entity enUser = getUser("Unassigned", service);
                                tracer.Trace("Record reterieved " + enUser);
                                tracer.Trace("Record reterieved " + enUser.Id);
                                Guid userid = enUser.Id;
                                EntityReference unassigneduser = new EntityReference("systemuser", enUser.Id);
                                tracer.Trace("Activities created.");
                                tracer.Trace("Activities created.now");
                                if (userid != Guid.Empty)
                                {
                                    //AssignRequest assignRequest = new AssignRequest
                                    //{
                                    //    Assignee = unassigneduser,
                                    //    Target = new EntityReference("task", taskId)

                                    //};
                                    //service.Execute(assignRequest);
                                    //commented assignRequest as its depricated
                                    //Modified on -18/03 ;Modified By-Nida;Details:MS remediation applied to  Replace deprecated assignrequest message
                                    //Modified on -20/04 ;Modified By-Nida;Details:2689

                                    Entity taskUpdate = new Entity("task", taskId);
                                    taskUpdate["ownerid"] = unassigneduser;
                                    service.Update(taskUpdate);
                                    tracer.Trace("Activities is unassigned .");
                                }
                                //End bug :2141

                                tracer.Trace("Activities created.");
                                //Below If condition added by Jyoti Bhosale for ABRARC changes
                                if (ARCQueueId != Guid.Empty)
                                {
                                    queueId = ARCQueueId;
                                    tracer.Trace("Email to case and Task allocation Queue: " + queueId);
                                }
                                //////////////////////////////////
                                if (queueId != Guid.Empty)
                                {
                                    AddToQueueRequest routeRequest = new AddToQueueRequest
                                    {
                                        Target = new EntityReference("task", taskId),
                                        DestinationQueueId = queueId
                                    };

                                    service.Execute(routeRequest);
                                    tracer.Trace("Activities added in queue.");
                                }
                                if (queueId != Guid.Empty)
                                {
                                    opportunityUpdate["rsa_queue"] = new EntityReference("queue", queueId);//bug 1618 Queue not assigned
                                                                                                           //service.Update(opportunityUpdate);
                                }

                                //Reassign queue
                                if (opportunityUpdate.Attributes.Contains("subject") && opportunityUpdate.GetAttributeValue<String>("subject") == "Quote Work Up")
                                {
                                    tracer.Trace("Reassign function - Quote Workup identified. -1");
                                    var offShoreProcQueue = new Guid("eb14194c-e7be-f011-bbd3-000d3ad642e9");
                                    if (caseId != null && caseId != Guid.Empty)
                                    {
                                        
                                        var caseDet = service.Retrieve("incident", caseId, new ColumnSet("rsa_product_w"));
                                        
                                        if (caseDet != null && caseDet.Attributes.Contains("rsa_product_w") && caseDet.GetAttributeValue<String>("rsa_product_w") == "Intact Motor Fleet")
                                        {
                                            tracer.Trace("Reassign function - Product : " + caseDet.GetAttributeValue<String>("rsa_product_w"));
                                            

                                            //Remove from other queues
                                            QueryExpression query = new QueryExpression("queueitem");
                                            query.ColumnSet = new ColumnSet("queueitemid");
                                            query.Criteria.AddCondition("objectid", ConditionOperator.Equal, taskId);

                                            EntityCollection queueItems = service.RetrieveMultiple(query);

                                            // 2. Loop through and delete each queue item
                                            foreach (Entity queueItem in queueItems.Entities)
                                            {
                                                //tracer.Trace("Reassign function 1 - Deleting queue item : " + queueItem.Id);
                                                //service.Delete("queueitem", queueItem.Id);
                                                //tracer.Trace("Reassign function 2 - Deleted queue item : " + queueItem.Id);
                                            }

                                            //Reassign to Offhore Processing
                                            AddToQueueRequest routeRequestOffProcessing = new AddToQueueRequest
                                            {
                                                Target = new EntityReference("task", taskId),
                                                DestinationQueueId = offShoreProcQueue
                                            };
                                            service.Execute(routeRequestOffProcessing);
                                            tracer.Trace("Reassign function - Added to Offshore Queue : eb14194c-e7be-f011-bbd3-000d3ad642e9");

                                            //Update Queue on task
                                            Entity workUptaskUpdate = new Entity("task", taskId);
                                            workUptaskUpdate["rsa_queue"] = new EntityReference("queue", offShoreProcQueue);
                                            EntityReference taskOwner = new EntityReference("systemuser", new Guid(workupOwnerID));
                                            workUptaskUpdate["ownerid"] = taskOwner;
                                            service.Update(workUptaskUpdate);
                                        }
                                    }
                                }
                            }
                            else if (!string.IsNullOrEmpty(assigntemplatetaskto) && assigntemplatetaskto.ToLower() == "mumbai handler")
                            {
                                Guid activitytaskId = service.Create(opportunityUpdate);
                                tracer.Trace("Activities created fr Mumbai Handler");

                                if (policyId != Guid.Empty)
                                {
                                    Entity mumbaiHandler = service.Retrieve("rsa_policy", policyId, new ColumnSet(new string[] { "rsa_mumbaihandler" }));

                                    if (mumbaiHandler.Attributes.Contains("rsa_mumbaihandler"))
                                    {
                                        EntityReference handlerUser = (EntityReference)mumbaiHandler.Attributes["rsa_mumbaihandler"];
                                        tracer.Trace("Mumbai Handler " + mumbaiHandler.Id);
                                        //AssignRequest assignRequest = new AssignRequest
                                        //{
                                        //    Assignee = handlerUser,
                                        //    Target = new EntityReference("task", activitytaskId)
                                        //};
                                        //service.Execute(assignRequest);

                                        //commented assignRequest as its depricated
                                        //Modified on -18/03 ;Modified By-Nida;Details:MS remediation applied to  Replace deprecated assignrequest message
                                        //Modified on -20/04 ;Modified By-Nida;Details:2689
                                        Entity taskUpdate = new Entity("task", activitytaskId);
                                        taskUpdate["ownerid"] = handlerUser;
                                        service.Update(taskUpdate);
                                        tracer.Trace("Task Record Assigned to mumbaiHandler.");
                                    }
                                }
                            }
                            else if (!string.IsNullOrEmpty(assigntemplatetaskto) && assigntemplatetaskto.ToLower() == "trader")
                            {
                                Guid activitytaskId = service.Create(opportunityUpdate);
                                tracer.Trace("Activities created for Trader");
                                if (policyId != Guid.Empty)
                                {
                                    Entity policyTrader = service.Retrieve("rsa_policy", policyId, new ColumnSet(new string[] { "rsa_policytrader" }));
                                    if (policyTrader.Attributes.Contains("rsa_policytrader"))
                                    {
                                        EntityReference TraderUser = (EntityReference)policyTrader.Attributes["rsa_policytrader"];
                                        //AssignRequest assignRequest = new AssignRequest
                                        //{
                                        //    Assignee = TraderUser,
                                        //    Target = new EntityReference("task", activitytaskId)
                                        //};
                                        //service.Execute(assignRequest);
                                        //Modified on -18/03 ;Modified By-Nida;Details:MS remediation applied to  Replace deprecated assignrequest message
                                        //Modified on -20/04 ;Modified By-Nida;Details:2689
                                        Entity taskUpdate = new Entity("task", activitytaskId);
                                        taskUpdate["ownerid"] = TraderUser;
                                        service.Update(taskUpdate);
                                        tracer.Trace("Task Record Assigned to Trader.");
                                    }
                                }
                            }
                            else if (!string.IsNullOrEmpty(assigntemplatetaskto) && assigntemplatetaskto.ToLower() == "underwriter")
                            {
                                Guid activitytaskId = service.Create(opportunityUpdate);
                                tracer.Trace("Activities created for underwriter");
                                if (opportunityId != Guid.Empty)
                                {
                                    Entity underwriter = service.Retrieve("opportunity", opportunityId, new ColumnSet(new string[] { "rsa_secondaryowner" }));
                                    if (underwriter.Attributes.Contains("rsa_secondaryowner"))
                                    {
                                        EntityReference TraderUser = (EntityReference)underwriter.Attributes["rsa_secondaryowner"];
                                        //AssignRequest assignRequest = new AssignRequest
                                        //{
                                        //    Assignee = TraderUser,
                                        //    Target = new EntityReference("task", activitytaskId)
                                        //};
                                        //service.Execute(assignRequest);
                                        //Modified on -18/03 ;Modified By-Nida;Details:MS remediation applied to  Replace deprecated assignrequest message
                                        //Modified on -20/04 ;Modified By-Nida;Details:2689
                                        Entity taskUpdate = new Entity("task", activitytaskId);
                                        taskUpdate["ownerid"] = TraderUser;
                                        service.Update(taskUpdate);
                                        tracer.Trace("Task Record Assigned to Underwriter.");
                                    }
                                }
                            }
                            //Date:04022021 Unaassigned usercondition added
                            else if (!string.IsNullOrEmpty(assigntemplatetaskto) && assigntemplatetaskto.ToLower() == "unassigned")
                            {
                                Guid taskId = service.Create(opportunityUpdate);
                                tracer.Trace("calling getuser function");
                                Entity enUser = getUser("Unassigned", service);
                                tracer.Trace("Record reterieved " + enUser);
                                tracer.Trace("Record reterieved " + enUser.Id);
                                Guid userid = enUser.Id;
                                EntityReference user = new EntityReference("systemuser", enUser.Id);
                                tracer.Trace("Activities created.");
                                tracer.Trace("Activities created.now");
                                if (userid != Guid.Empty)
                                {
                                    //AssignRequest assignRequest = new AssignRequest
                                    //{
                                    //    Assignee = user,
                                    //    Target = new EntityReference("task", taskId)

                                    //};
                                    //service.Execute(assignRequest);
                                    //Modified on -18/03 ;Modified By-Nida;Details:MS remediation applied to  Replace deprecated assignrequest message
                                    //Modified on -20/04 ;Modified By-Nida;Details:2689
                                    Entity taskUpdate = new Entity("task", taskId);
                                    taskUpdate["ownerid"] = user;
                                    service.Update(taskUpdate);
                                    tracer.Trace("Activities is unassigned .");
                                }
                            }
                        }
                        #endregion 
                        if (flagDueDate)//offset
                        {
                            tracer.Trace("enNextCallDueDateTasks.Entities.Count==0 || enNextCallDueDateTasks==null");
                            #region//SLA CALCULATIONS

                            string dueDateUnits = string.Empty;
                            DateTime dt = DateTime.MinValue;
                            string dueDateBasedOn = string.Empty;
                            if (task.FormattedValues.Contains("rsa_duedateunits"))
                            {
                                dueDateUnits = task.FormattedValues["rsa_duedateunits"];

                                tracer.Trace("Activities dueDateUnits is : {0}", dueDateUnits);
                            }
                            if (task.FormattedValues.Contains("rsa_duedatebasedon"))
                            {
                                dueDateBasedOn = task.FormattedValues["rsa_duedatebasedon"];
                                tracer.Trace("Activities dueDateBasedOn is : {0}", dueDateBasedOn);
                            }
                            if (dueDateBasedOn.ToLower().Trim() == "case.created")
                            {
                                dt = entityPostImage.Attributes.Contains("createdon") && entityPostImage.GetAttributeValue<DateTime>("createdon") != null ? entityPostImage.GetAttributeValue<DateTime>("createdon") : DateTime.MinValue;
                                dt = CreateNewDate(dt.Year, dt.Month, dt.Day, dt);
                                dt = RetrieveLocalTimeFromUTCTime(dt.ToUniversalTime(), userTimezone, service);
                                //dt = GetCasesDates(service, caseId, "createdon");
                                tracer.Trace("case.created Activities dt is : {0}", dt);
                            }
                            //Created by Jyoti Bhosale for ABRARC change 
                            if (dueDateBasedOn.ToLower().Trim() == "email.created")
                            {

                                dt = entityPostImage.Attributes.Contains("rsa_casereceiveddate") && entityPostImage.GetAttributeValue<DateTime>("rsa_casereceiveddate") != null ? entityPostImage.GetAttributeValue<DateTime>("rsa_casereceiveddate") : DateTime.MinValue;

                                tracer.Trace("Email received dt       " + dt);
                                dt = RetrieveLocalTimeFromUTCTime(dt.ToUniversalTime(), userTimezone, service);
                                tracer.Trace("  RetrieveLocalTimeFromUTCTime   " + dt);

                                tracer.Trace("Email received date is: {0}", dt);
                            }
                            ///////////////////////////
                            else if (dueDateBasedOn.ToLower().Trim() == "case.case_received_date__c")
                            {
                                dt = entityPostImage.Attributes.Contains("rsa_casereceiveddate") && entityPostImage.GetAttributeValue<DateTime>("rsa_casereceiveddate") != null ? entityPostImage.GetAttributeValue<DateTime>("rsa_casereceiveddate") : DateTime.MinValue;
                                dt = RetrieveLocalTimeFromUTCTime(dt.ToUniversalTime(), userTimezone, service);
                                //dt = GetCasesDates(service, caseId, "rsa_casereceiveddate");
                                tracer.Trace(" case.case_received_date__c Activities dt is : {0}", dt);
                            }
                            else if (dueDateBasedOn.ToLower().Trim() == "last day of month")
                            {
                                // int year = System.DateTime.Now.Year;
                                int year = LocalTime.Year;
                                //int month = System.DateTime.Now.Month + 1;
                                int month = LocalTime.Month + 1;
                                dt = new DateTime(year, month, System.DateTime.DaysInMonth(LocalTime.Year, month));
                                tracer.Trace("last day of month Activities dt is : {0}", dt);
                            }
                            else if (dueDateBasedOn.ToLower().Trim() == "case.scheme_review_deadline__c")
                            {
                                dt = entityPostImage.Attributes.Contains("rsa_schemereviewdeadline") && entityPostImage.GetAttributeValue<DateTime>("rsa_schemereviewdeadline") != null ? entityPostImage.GetAttributeValue<DateTime>("rsa_schemereviewdeadline") : DateTime.MinValue;
                                dt = RetrieveLocalTimeFromUTCTime(dt.ToUniversalTime(), userTimezone, service);
                                //dt = GetCasesDates(service, caseId, "rsa_schemereviewdeadline");
                                tracer.Trace("case.scheme_review_deadline__c Activities dt is : {0}", dt);
                            }
                            else if (dueDateBasedOn.ToLower().Trim() == "case.tech_nextcallduedate__c")
                            {
                                dt = entityPostImage.Attributes.Contains("rsa_technextcallduedate") && entityPostImage.GetAttributeValue<DateTime>("rsa_technextcallduedate") != null ? entityPostImage.GetAttributeValue<DateTime>("rsa_technextcallduedate") : DateTime.MinValue;
                                dt = RetrieveLocalTimeFromUTCTime(dt.ToUniversalTime(), userTimezone, service);
                                //dt = GetCasesDates(service, caseId, "rsa_technextcallduedate");
                                tracer.Trace("case.tech_nextcallduedate__c Activities dt is : {0}", dt);
                            }
                            else if (dueDateBasedOn.ToLower().Trim() == "case.effective_date__c")
                            {
                                dt = entityPostImage.Attributes.Contains("rsa_effectivedate") && entityPostImage.GetAttributeValue<DateTime>("rsa_effectivedate") != null ? entityPostImage.GetAttributeValue<DateTime>("rsa_effectivedate") : DateTime.MinValue;
                                dt = RetrieveLocalTimeFromUTCTime(dt.ToUniversalTime(), userTimezone, service);
                                //dt = GetCasesDates(service, caseId, "rsa_effectivedate");
                                tracer.Trace("case.effective_date__c Activities dt is : {0}", dt);
                            }
                            else if (dueDateBasedOn.ToLower().Trim() == "case.ais_task_due_date__c")
                            {
                                //dt = GetCasesDates(service, caseId, "rsa_aistaskduedate");
                                dt = entityPostImage.Attributes.Contains("rsa_aistaskduedate") && entityPostImage.GetAttributeValue<DateTime>("rsa_aistaskduedate") != null ? entityPostImage.GetAttributeValue<DateTime>("rsa_aistaskduedate") : DateTime.MinValue;
                                dt = RetrieveLocalTimeFromUTCTime(dt.ToUniversalTime(), userTimezone, service);
                                tracer.Trace("case.ais_task_due_date__c Activities dt is : {0}", dt);
                            }
                            else if (dueDateBasedOn.ToLower().Trim() == "activity.created")
                            {
                                dt = LocalTime;
                                // Not considering the initial date
                                tracer.Trace("activity.created time  " + dt);


                                tracer.Trace("activity.created Activities dt is : {0}", dt);
                            }
                            else if (dueDateBasedOn.ToLower().Trim() == "opportunity.closedate" && opportunityId != Guid.Empty)
                            {
                                dt = GetOpportunityDate(service, opportunityId, "rsa_closedate");
                                tracer.Trace("dt       " + dt);
                                dt = RetrieveLocalTimeFromUTCTime(dt.ToUniversalTime(), userTimezone, service);
                                tracer.Trace("  RetrieveLocalTimeFromUTCTime   " + dt);

                                tracer.Trace("opportunity.closedate Activities dt is : {0}", dt);
                            }
                            else if (dueDateBasedOn.ToLower().Trim() == "opportunity.closedate or end of month" && opportunityId != Guid.Empty)
                            {
                                dt = GetOpportunityDate(service, opportunityId, "rsa_closedate");
                                dt = RetrieveLocalTimeFromUTCTime(dt.ToUniversalTime(), userTimezone, service);

                                tracer.Trace("  RetrieveLocalTimeFromUTCTime   " + dt);
                                tracer.Trace("opportunity.closedate or end of month Activities dt is : {0}", dt);
                            }
                            else
                            {
                                dt = LocalTime;
                                tracer.Trace("Activities dt is : {0}", dt);
                            }
                            var timeSpandt = dt.TimeOfDay;
                            double EndofBusinessHoursTime = 17.01;
                            int startofBusinessHoursTime = 9;
                            TimeSpan ts_EndofBusinessHoursTime = TimeSpan.FromHours(EndofBusinessHoursTime); // this is defined to use the time of day .that is 17 o clock.
                            TimeSpan ts_StartofBusinessHoursTime = TimeSpan.FromHours(startofBusinessHoursTime);
                            TimeSpan ts_DefaultStartTime = new TimeSpan(09, 00, 00);
                            tracer.Trace("ts_EndofBusinessHoursTime   " + ts_EndofBusinessHoursTime);
                            tracer.Trace("timeSpandt  " + timeSpandt);
                            tracer.Trace("timeSpandt hour  " + timeSpandt.Hours);
                            tracer.Trace("Business Hours  " + businesshours);
                            tracer.Trace(" Business Days " + BusinessDaysRequired);
                            if (!string.IsNullOrEmpty(dueDateUnits) && dueDateUnits.ToLower() == "days" && dt != null)
                            {
                                if (task.Attributes.Contains("rsa_duedateoffset"))
                                {
                                    dueDateOffset = task.GetAttributeValue<decimal>("rsa_duedateoffset"); //gives us the data from ABR task entity
                                }
                                //Below if condition added by Jyoti. Get dueDateOffset from JSON (RSA Custom Label)
                                if (offset != 0)
                                {
                                    dueDateOffset = offset;
                                }
                                ///////////
                                //Sumegh Dhole 20 Oct 2020 : Check added if dt is always datetime.
                                //Minvalue as the rsa_technextcallduedate is captured in pre activity create and its not calculated in the case record. 
                                tracer.Trace("DT shortdate string  : {0} : {1}", dt.ToShortDateString(), Convert.ToDouble(dueDateOffset));
                                tracer.Trace("Today shortdate  : {0}", DateTime.Today.ToShortDateString());
                                if (dt != DateTime.MinValue && dt.ToShortDateString() == DateTime.Today.ToShortDateString() && dueDateOffset > 1)
                                {

                                    if (BusinessDaysRequired)   //this condition to be removed as records are configured as INCLUDE WEEKENDS
                                    {
                                        tracer.Trace(" Business Days  required 1534");
                                        taskEndDate = CalculateBusinessDays(service, tracer, dt, Convert.ToInt32(dueDateOffset)); //initial date always

                                        tracer.Trace("taskEndDate  " + taskEndDate);
                                    }
                                    else
                                    {
                                        tracer.Trace(" Business Days Not required");
                                        tracer.Trace("taskEndDate line 1926 " + taskEndDate);
                                        taskEndDate = dt.AddDays(Convert.ToDouble(dueDateOffset)); //

                                        tracer.Trace("taskEndDate line 1540 " + taskEndDate);
                                    }
                                    if (businesshours)
                                    {
                                        tracer.Trace("inside hours business hours"); //timespandt is due date based on 
                                        if (timeSpandt <= ts_EndofBusinessHoursTime && timeSpandt >= ts_StartofBusinessHoursTime) //within the business hrs.
                                        {
                                            tracer.Trace("inside hours business hours  " + timeSpandt.Hours); //printing the vlue of current businesshr

                                            taskEndDate = dt.AddDays(Convert.ToDouble(dueDateOffset - 1)); //added te offset .from next line if it is grater than Busines hrs then we will subtract


                                        }
                                        else
                                        {
                                            tracer.Trace("if the dt is outside business hours");
                                            if (timeSpandt > ts_EndofBusinessHoursTime)
                                            {
                                                dt = dt.AddDays(Convert.ToDouble(dueDateOffset)); ;//
                                                tracer.Trace("when the due date based on is outside the end of  business hrs ");
                                            }

                                            //taskEndDate = CalculateBusinessDays(service, tracer, dt, Convert.ToInt32(dueDateOffset));//08062021
                                        }
                                        if (BusinessDaysRequired)
                                        {
                                            if (taskEndDate.DayOfWeek == DayOfWeek.Saturday)
                                            {
                                                taskEndDate = taskEndDate.AddDays(2);
                                            }
                                            else if (taskEndDate.DayOfWeek == DayOfWeek.Sunday)
                                                taskEndDate = taskEndDate.AddDays(1);
                                        }
                                    }
                                    tracer.Trace("Task End Date  : {0}", taskEndDate);
                                }
                                else if (dt != DateTime.MinValue && dt.ToShortDateString() == DateTime.Today.ToShortDateString() && dueDateOffset == 1)
                                {
                                    tracer.Trace("test1");

                                    if (BusinessDaysRequired)
                                    {
                                        tracer.Trace(" Business Days  required 1568");
                                        taskEndDate = CalculateBusinessDays(service, tracer, dt, Convert.ToInt32(dueDateOffset));

                                    } //////this condition to be removed as records are configured as INCLUDE WEEKENDS

                                    else
                                    {
                                        tracer.Trace(" Business Days  not  required 1975");
                                        taskEndDate = dt.AddDays(Convert.ToDouble(dueDateOffset));
                                    }
                                    if (businesshours)
                                    {
                                        if (timeSpandt <= ts_EndofBusinessHoursTime)
                                        {
                                            taskEndDate = taskEndDate; //
                                            if (BusinessDaysRequired)//this condition to be removed as records are configured as INCLUDE WEEKENDS   
                                            {
                                                if (taskEndDate.DayOfWeek == DayOfWeek.Saturday)
                                                {
                                                    taskEndDate = taskEndDate.AddDays(-1);
                                                }
                                                else if (taskEndDate.DayOfWeek == DayOfWeek.Sunday)
                                                    taskEndDate = taskEndDate.AddDays(-2);
                                            }
                                            taskEndDate = taskEndDate.Date + ts_DefaultTime; //Added this to default the time to 6 o clock
                                            tracer.Trace("taskEndDate when timeSpandt is less  than 5 " + taskEndDate);
                                        }
                                        else
                                        {
                                            taskEndDate = taskEndDate.AddDays(1);
                                            tracer.Trace("taskEndDate when timeSpandt is greater  than 5    " + taskEndDate);
                                        }

                                    }


                                    tracer.Trace("Task End Date  when offset is 1 : {0}", taskEndDate);
                                }
                                else if (dt != DateTime.MinValue && dt >= DateTime.Today.AddDays(Convert.ToDouble(dueDateOffset)) && dt.AddDays(Convert.ToDouble(dueDateOffset)) >= DateTime.Now)
                                {
                                    if (dueDateOffset > 0)
                                    {
                                        tracer.Trace("test2");
                                        tracer.Trace("BusinessDaysRequired " + BusinessDaysRequired);
                                        if (BusinessDaysRequired)
                                        {
                                            tracer.Trace(" Business Days  required 1603");
                                            taskEndDate = CalculateBusinessDays(service, tracer, dt, Convert.ToInt32(dueDateOffset)); //INCLUDES INITIAL DATE

                                        }

                                        else
                                        {
                                            tracer.Trace(" Business Days  not  required 1611");
                                            taskEndDate = dt.AddDays(Convert.ToDouble(dueDateOffset));
                                        }
                                        if (businesshours)
                                        {
                                            if (timeSpandt.Hours <= EndofBusinessHoursTime)
                                            {
                                                taskEndDate = taskEndDate.AddDays(-1);  //8 

                                                if (BusinessDaysRequired)
                                                {
                                                    if (taskEndDate.DayOfWeek == DayOfWeek.Saturday)
                                                    {
                                                        taskEndDate = taskEndDate.AddDays(-1);
                                                    }
                                                    else if (taskEndDate.DayOfWeek == DayOfWeek.Sunday)
                                                        taskEndDate = taskEndDate.AddDays(-2);
                                                }
                                                tracer.Trace("taskEndDate when timeSpandt is less  than 5 " + taskEndDate);
                                            }
                                            else { taskEndDate = taskEndDate; }
                                        }
                                        else
                                        {
                                            taskEndDate = taskEndDate;
                                            tracer.Trace("taskEndDate when timeSpandt is greater  than 5 " + taskEndDate);
                                        }
                                    }

                                    else if (dueDateOffset < 0)
                                    {
                                        tracer.Trace("test3");
                                        if (BusinessDaysRequired)
                                        {
                                            tracer.Trace(" Business Days  required 1634");
                                            taskEndDate = CalculateBusinessDays(service, tracer, dt, Convert.ToInt32(dueDateOffset));

                                        }

                                        else
                                        {
                                            tracer.Trace("Business Days  not  required 1641");
                                            taskEndDate = dt.AddDays(Convert.ToDouble(dueDateOffset));//Changes done
                                            tracer.Trace("Business Days  not  required 2060" + taskEndDate);
                                        }
                                        if (businesshours)
                                        {
                                            if (timeSpandt <= ts_EndofBusinessHoursTime)
                                            {
                                                taskEndDate = taskEndDate.AddDays(-1);

                                                if (BusinessDaysRequired)
                                                {
                                                    if (taskEndDate.DayOfWeek == DayOfWeek.Saturday)
                                                    {
                                                        taskEndDate = taskEndDate.AddDays(-1);
                                                    }
                                                    else if (taskEndDate.DayOfWeek == DayOfWeek.Sunday)
                                                        taskEndDate = taskEndDate.AddDays(-2);
                                                }
                                                tracer.Trace("taskEndDate when timeSpandt is less  than 5 " + taskEndDate);
                                            }
                                            else { taskEndDate = taskEndDate; }

                                        }
                                        else
                                        {
                                            taskEndDate = taskEndDate;
                                            tracer.Trace("taskEndDate when timeSpandt is greater  than 5 " + taskEndDate);
                                        }

                                    }
                                    tracer.Trace("Task End Date  : {0}", taskEndDate);
                                }
                                else if (dt != DateTime.MinValue && dt < DateTime.Today.AddDays(Convert.ToDouble(dueDateOffset)) && dt.AddDays(Convert.ToDouble(dueDateOffset - 1)) >= DateTime.Now)
                                {

                                    if (dueDateOffset > 0)
                                    {
                                        if (BusinessDaysRequired)
                                        {
                                            tracer.Trace(" Business Days   required 1670");
                                            taskEndDate = CalculateBusinessDays(service, tracer, dt, Convert.ToInt32(dueDateOffset));

                                        }

                                        else
                                        {
                                            tracer.Trace(" Business Days  not  required 1670");
                                            taskEndDate = dt.AddDays(Convert.ToDouble(dueDateOffset));
                                        }
                                        if (businesshours)
                                        {
                                            if (timeSpandt.Hours <= EndofBusinessHoursTime)
                                            {
                                                taskEndDate = taskEndDate.AddDays(-1);

                                                if (BusinessDaysRequired)
                                                {
                                                    if (taskEndDate.DayOfWeek == DayOfWeek.Saturday)
                                                    {
                                                        taskEndDate = taskEndDate.AddDays(-1);
                                                    }
                                                    else if (taskEndDate.DayOfWeek == DayOfWeek.Sunday)
                                                        taskEndDate = taskEndDate.AddDays(-2);
                                                }
                                                tracer.Trace("taskEndDate when timeSpandt is less  than 5 " + taskEndDate);
                                            }
                                            else { taskEndDate = taskEndDate; }

                                        }
                                        else
                                        {
                                            taskEndDate = taskEndDate; //ADD a day
                                            tracer.Trace("taskEndDate when timeSpandt is greater  than 5 " + taskEndDate);
                                        }


                                        tracer.Trace("Task End Date when dt is dt < DateTime.Today.AddDays(Convert.ToDouble(dueDateOffset) : {0}", taskEndDate);
                                    }
                                    else if (dueDateOffset < 0)
                                    {

                                        if (BusinessDaysRequired)
                                        {
                                            tracer.Trace(" Business Days   required 1703");
                                            taskEndDate = CalculateBusinessDays(service, tracer, dt, Convert.ToInt32(dueDateOffset));

                                        }

                                        else
                                        {
                                            tracer.Trace(" Business Days Not  required 1703");
                                            taskEndDate = dt.AddDays(Convert.ToDouble(dueDateOffset));
                                        }
                                        if (businesshours)
                                        {
                                            if (timeSpandt.Hours <= EndofBusinessHoursTime)
                                            {
                                                taskEndDate = taskEndDate.AddDays(-1);
                                                if (BusinessDaysRequired)
                                                {
                                                    if (taskEndDate.DayOfWeek == DayOfWeek.Saturday)
                                                    {
                                                        taskEndDate = taskEndDate.AddDays(-1);
                                                    }
                                                    else if (taskEndDate.DayOfWeek == DayOfWeek.Sunday)
                                                        taskEndDate = taskEndDate.AddDays(-2);
                                                }
                                                tracer.Trace("taskEndDate when timeSpandt is less  than 5 " + taskEndDate);
                                            }
                                            else { taskEndDate = taskEndDate; }

                                        }
                                        else
                                        {
                                            taskEndDate = taskEndDate;
                                            tracer.Trace("taskEndDate when timeSpandt is greater  than 6 " + taskEndDate);
                                        }

                                        tracer.Trace("Task End Date when dueDateOffset < 0 anddt < DateTime.Today.AddDays(Convert.ToDouble(dueDateOffset)   : {0}", taskEndDate);
                                    }


                                    else
                                    {
                                        tracer.Trace("Task now Date : {0}", LocalTime);
                                        //taskEndDate = DateTime.Now;
                                        taskEndDate = LocalTime;
                                    }
                                    tracer.Trace("Activities dueDateUnits is : {0}", dueDateOffset);
                                }
                                if (taskEndDate != DateTime.MinValue)
                                {
                                    if (dueDateBasedOn.ToLower().Trim() == "opportunity.closedate or end of month")
                                    {
                                        if (taskEndDate.Month == dt.Month)
                                        { //do nothing
                                        }
                                        else if (taskEndDate.Month != dt.Month || taskEndDate.Year != dt.Year)
                                        {
                                            var LastDayOfMonth = DateTime.DaysInMonth(dt.Year, dt.Month);
                                            tracer.Trace("LastDayOfMonth  " + LastDayOfMonth);
                                            taskEndDate = CreateNewDate(dt.Year, dt.Month, LastDayOfMonth, dt);
                                            tracer.Trace("taskEndDate WHEN dueDateBased == opportunity.closedate or end of month:  " + taskEndDate);
                                        }
                                    }

                                    taskEndDate = RevertBackToFriday(service, taskEndDate);
                                    taskEndDate = taskEndDate.Date + ts_DefaultTime; //adding this to set the time to 5'o clock when unit is days
                                    tracer.Trace("taskEndDate when   " + taskEndDate);
                                }

                            }
                            // 
                            if (!string.IsNullOrEmpty(dueDateUnits) && dueDateUnits.ToLower() == "hours")
                            {
                                //taskEndDate = Convert.ToDateTime(dt);

                                dueDateOffset = task.GetAttributeValue<decimal>("rsa_duedateoffset");
                                //Below if condition added by Jyoti Bhosale Get dueDateOffset from JSON (RSA Custom Label) for ABR ARC change
                                if (offset != 0)
                                {
                                    dueDateOffset = offset;
                                }
                                tracer.Trace("Activities dueDateUnits in hours : {0}", dueDateOffset); //gives us the value of ABR Task Due date Hrs 

                                if (dt != DateTime.MinValue && dt.ToShortDateString() == DateTime.Today.ToShortDateString() && dueDateOffset > 0)
                                {
                                    //ARC code changes to handle due date offset
                                    //Jyoti Bhosale : 17 Aug 2022 : ABR to handle the due dates for ARC
                                    int minutesComponent = dt.Minute;
                                    dt = dt.AddMinutes(-(minutesComponent - 1));
                                    if (businesshours)
                                    {
                                        tracer.Trace("inside hours business hours"); //timespandt is due date based on 
                                        if (timeSpandt <= ts_EndofBusinessHoursTime && timeSpandt >= ts_StartofBusinessHoursTime) //within the business hrs.
                                        {
                                            tracer.Trace("inside hours business hours  " + timeSpandt.Hours); //printing the vlue of current businesshr

                                            //  taskEndDate = dt.AddHours(Convert.ToDouble(dueDateOffset)); //added te offset .from next line if it is grater than Busines hrs then we will subtract
                                            decimal hoursLeft = dueDateOffset;
                                            if (dueDateOffset != 24)
                                            {
                                                for (int i = 1; i <= dueDateOffset; i++)  //   checking for 24 hrs now
                                                {
                                                    if (hoursLeft <= 0) { break; }

                                                    tracer.Trace("hoursLeft line 2230   " + hoursLeft);
                                                    taskEndDate = dt.AddHours(Convert.ToDouble(i));
                                                    tracer.Trace("taskEndDate for loop   " + taskEndDate);
                                                    if (taskEndDate.TimeOfDay < ts_EndofBusinessHoursTime) //changes done line 2209 2234
                                                    {
                                                        hoursLeft = hoursLeft - 1;
                                                    }

                                                    if (taskEndDate.TimeOfDay >= ts_EndofBusinessHoursTime && !(hoursLeft <= 0))
                                                    {
                                                    AFTER: taskEndDate = taskEndDate.AddDays(1);
                                                        //ARC code changes to handle due date offset
                                                        //Jyoti Bhosale : 17 Aug 2022 : ABR to handle the due dates for ARC
                                                        hoursLeft = hoursLeft - 1;
                                                        taskEndDate = taskEndDate.Date + ts_DefaultStartTime; //9 o clock
                                                        tracer.Trace(" taskEndDate line 2244  " + taskEndDate);

                                                        for (i = i; i <= dueDateOffset; i++)  //   checking for 24 hrs now
                                                        {
                                                            if (hoursLeft > 0)
                                                            {
                                                                taskEndDate = taskEndDate.AddHours(Convert.ToDouble(1));
                                                            }
                                                            tracer.Trace(" taskEndDate line 2248  " + taskEndDate);
                                                            if (taskEndDate.TimeOfDay < ts_EndofBusinessHoursTime)
                                                            {
                                                                hoursLeft = hoursLeft - 1;
                                                                tracer.Trace("hoursLeft when    " + hoursLeft);
                                                            }
                                                            if (taskEndDate.TimeOfDay > ts_EndofBusinessHoursTime && hoursLeft != 0) { tracer.Trace("i print    " + i); ; goto AFTER; }

                                                        }
                                                    }
                                                    if (hoursLeft == 0)
                                                    {
                                                        break;
                                                    }

                                                }
                                                //ARC code changes to handle due date offset
                                                //Jyoti Bhosale : 17 Aug 2022 : ABR to handle the due dates for ARC 
                                                taskEndDate = taskEndDate.AddMinutes(minutesComponent);
                                            }
                                            else
                                            {
                                                taskEndDate = dt.AddHours(Convert.ToDouble(dueDateOffset));
                                            }

                                            //if (taskEndDate.TimeOfDay > ts_EndofBusinessHoursTime)
                                            //{
                                            //    tracer.Trace("WHEN end date exceeds the business hrs ");

                                            //    taskEndDate = dt.AddDays(1);
                                            //    TimeSpan ts1 = new TimeSpan(09, 00, 00);
                                            //    taskEndDate = taskEndDate.Date + ts1; //9 o clock
                                            //    taskEndDate = taskEndDate.AddHours(Convert.ToDouble(hoursLeft));
                                            //}

                                        }
                                        else
                                        {
                                            tracer.Trace("if the dt is outside business hours");
                                            if (timeSpandt > ts_EndofBusinessHoursTime)
                                            {
                                                dt = dt.AddDays(1);//
                                                tracer.Trace("when the due date based on is outside the end of  business hrs ");
                                            }


                                            TimeSpan ts = new TimeSpan(09, 00, 00);
                                            dt = dt.Date + ts; //9 o clock
                                            taskEndDate = dt.AddHours(Convert.ToDouble(dueDateOffset));
                                            tracer.Trace("end date 2288  " + taskEndDate);
                                            if (taskEndDate.TimeOfDay >= ts_EndofBusinessHoursTime)
                                            {
                                                taskEndDate = taskEndDate.AddDays(1);
                                                TimeSpan ts1 = new TimeSpan(09, 00, 00);
                                                taskEndDate = taskEndDate.Date + ts1; //9 o clock
                                                taskEndDate = taskEndDate.AddHours(Convert.ToDouble(dueDateOffset));
                                                tracer.Trace("end date 2295  " + taskEndDate);
                                            }

                                            //taskEndDate = CalculateBusinessDays(service, tracer, dt, Convert.ToInt32(dueDateOffset));//08062021
                                        }
                                        if (BusinessDaysRequired)
                                        {
                                            if (taskEndDate.DayOfWeek == DayOfWeek.Saturday)
                                            {
                                                taskEndDate = taskEndDate.AddDays(2);
                                            }
                                            else if (taskEndDate.DayOfWeek == DayOfWeek.Sunday)
                                                taskEndDate = taskEndDate.AddDays(1);
                                        }
                                    }
                                    else
                                    {
                                        tracer.Trace("busineshours is false");
                                        taskEndDate = dt.AddHours(Convert.ToDouble(dueDateOffset));
                                    }
                                    tracer.Trace("Activities taskEndDate is : {0}", taskEndDate);


                                }
                            }
                            tracer.Trace(" Task start date and end date is - {0} & {1}", taskStartDate, taskEndDate);

                            // //Fix for defect 88. Start date will not be greater than end date

                            if (taskStartDate > taskEndDate && opportunityId != Guid.Empty)
                            {
                                //throw new InvalidPluginExecutionException(string.Format("Activity end date {4} depends on {0} and cannot be less than activity start date {3} as due date offset is : {1} {2} " , dueDateBasedOn ,dueDateOffset, dueDateUnits, taskStartDate,taskEndDate));
                                //taskEndDate= taskStartDate ;
                                if (taskEndDate.Hour >= EndofBusinessHoursTime)
                                {
                                    taskEndDate = taskEndDate.AddDays(1);
                                    TimeSpan ts = new TimeSpan(09, 00, 00);
                                    taskEndDate = taskEndDate.Date + ts; //9 o clock
                                    taskEndDate = taskEndDate.AddHours(Convert.ToDouble(dueDateOffset));
                                }

                            }

                            #endregion                        
                            
                            Entity etaskUpdate = new Entity("task");
                            //INC2302030: Dynamics issue - Tasks are not allocating to the case owner || Modified on 21.11.2022 || Modified by Samiksha Dhakde
                            etaskUpdate["ownerid"] = new EntityReference("systemuser", context.InitiatingUserId);
                            if (task.Attributes.Contains("rsa_activitytype"))
                            {
                                etaskUpdate["rsa_tasktype"] = task.GetAttributeValue<EntityReference>("rsa_activitytype");
                            }
                            //jyoti  Bhosale 1/08/2022 ABR ARC change task not showing name
                            if (task.Attributes.Contains("rsa_activitytype"))
                            {
                                etaskUpdate["rsa_name"] = task.GetAttributeValue<string>("rsa_name").ToString();
                            }
                            etaskUpdate["rsa_casetotaskid"] = new EntityReference("incident", caseId);//bug id 1710
                            etaskUpdate["subject"] = subject;
                            if (abrId != null || abrId != Guid.Empty)
                                etaskUpdate["rsa_abrtemplatename"] = new EntityReference("rsa_activitybusinessrule", abrId);

                            etaskUpdate["regardingobjectid"] = new EntityReference("incident", caseId);
                            if (warnafterhours != -1)
                            {
                                etaskUpdate["rsa_warnafterhours"] = warnafterhours;
                            }
                            etaskUpdate["rsa_businesshourrequired"] = businesshours;
                            etaskUpdate["rsa_warnafterhours"] = warnafterhours;
                            if (handlingtimemins != -1)
                            {
                                etaskUpdate["rsa_handlingtimemins"] = handlingtimemins;
                            }
                            if (warnafterunits != 0)
                                etaskUpdate["rsa_warnafterunits"] = new OptionSetValue(warnafterunits);
                            if (status != 0)
                                etaskUpdate["rsa_status"] = new OptionSetValue(status);
                            //if (duedatetime != DateTime.MinValue)//commented on 27052021 Bug 1616 Duedatetime is = task Due date
                            //    opportunityUpdate["rsa_duedatetime"] = duedatetime;
                            //if (taskStartDate != DateTime.MinValue) //commented as due date = due date/time always
                            //{
                            //    //opportunityUpdate["rsa_duedatetime"] = taskStartDate;
                            //}

                            if (targetActivityRecordType != Guid.Empty)
                                etaskUpdate["rsa_targetactivityrecordtype"] = new EntityReference("rsa_targetactivityrecordtype", targetActivityRecordType);
                            if (priority != 99)
                                etaskUpdate["prioritycode"] = new OptionSetValue(priority);
                            if (taskStartDate != DateTime.MinValue)
                            {
                                tracer.Trace("Line 1535");
                                etaskUpdate["scheduledstart"] = taskStartDate;

                            }
                            etaskUpdate["rsa_volume"] = Convert.ToDecimal(1); // bug 1579                          
                            tracer.Trace("Task end Date" + taskEndDate);

                            // CR 335 - Case SLA - 23/11/2022 
                            //commented code for case SLA
                            //#region CR 335
                            if (!isHoliday)
                            {
                                tracer.Trace("isHoliday to validate weekends" + isHoliday);
                                taskEndDate = validateWeekend(service, tracer, taskEndDate);
                                tracer.Trace("taskValidDate2 : " + taskEndDate);
                                if (taskStartDate == taskEndDate)
                                {
                                    int result = TimeSpan.Compare(taskStartDate.TimeOfDay, taskEndDate.TimeOfDay);
                                    if (taskStartDate != DateTime.MinValue && (result > 0 || result == 0))
                                    {
                                        tracer.Trace("Line 1566");
                                        etaskUpdate["scheduledend"] = taskEndDate;
                                        etaskUpdate["rsa_duedatetime"] = taskEndDate;
                                    }
                                    else if (result < 0)
                                    {
                                        tracer.Trace("Line 1571");
                                        etaskUpdate["scheduledend"] = taskStartDate;
                                        etaskUpdate["rsa_duedatetime"] = taskStartDate;
                                    }
                                }

                                if (taskStartDate < taskEndDate)
                                {
                                    if (taskStartDate != DateTime.MinValue)
                                    {
                                        tracer.Trace("Line 1581   " + taskEndDate);
                                        etaskUpdate["scheduledend"] = taskEndDate;
                                        etaskUpdate["rsa_duedatetime"] = taskEndDate;

                                    }
                                }

                                //Modified On : 04 July 2022; Modified By: Nida; Description: INC-2190354
                                if (taskStartDate > taskEndDate)
                                {
                                    if (taskStartDate != DateTime.MinValue)
                                    {
                                        int setdefaultTime = 8;
                                        TimeSpan setts_DefaultTime = TimeSpan.FromHours(setdefaultTime);
                                        if (!businesshours)
                                        {
                                            tracer.Trace("businesshours set to false hence start = end" + taskStartDate);
                                            etaskUpdate["scheduledend"] = taskStartDate;
                                            etaskUpdate["rsa_duedatetime"] = taskStartDate;
                                        }
                                        else
                                        {
                                            tracer.Trace("businesshours set to True hence Add 1 day" + taskStartDate.AddDays(1));
                                            taskStartDate = taskStartDate.AddDays(1);

                                            etaskUpdate["scheduledend"] = taskStartDate.Date + setts_DefaultTime;
                                            etaskUpdate["rsa_duedatetime"] = taskStartDate.Date + setts_DefaultTime;
                                        }

                                        if (BusinessDaysRequired)
                                        {
                                            if (taskEndDate.DayOfWeek == DayOfWeek.Saturday)
                                            {
                                                taskEndDate = taskEndDate.AddDays(2);
                                                etaskUpdate["scheduledend"] = taskEndDate.Date + setts_DefaultTime;
                                                etaskUpdate["rsa_duedatetime"] = taskEndDate.Date + setts_DefaultTime;
                                            }
                                            else if (taskEndDate.DayOfWeek == DayOfWeek.Sunday)
                                            {
                                                taskEndDate = taskEndDate.AddDays(1);
                                                etaskUpdate["scheduledend"] = taskEndDate.Date + setts_DefaultTime;
                                                etaskUpdate["rsa_duedatetime"] = taskEndDate.Date + setts_DefaultTime;
                                            }
                                            tracer.Trace("BusinessDaysRequired set to True Consider weekend");
                                            tracer.Trace("taskEndDate" + taskEndDate.Date + setts_DefaultTime);
                                        }
                                        //else
                                        //{
                                        //    tracer.Trace("businessDaysRequired set to false hence start == end" + taskStartDate);
                                        //    etaskUpdate["scheduledend"] = taskStartDate;
                                        //    etaskUpdate["rsa_duedatetime"] = taskStartDate;
                                        //    tracer.Trace("taskEndDate" + taskEndDate.Date + setts_DefaultTime);
                                        //}
                                    }
                                }
                            }
                            else
                            {
                                tracer.Trace("isHoliday" + isHoliday);
                                TimeSpan defaultStartTime = new TimeSpan(09, 00, 00);
                                TimeSpan defaultEndTime = new TimeSpan(17, 00, 00);
                                int dueDateModulo = 0;
                                decimal reminder = 0.0M;
                                //TimeSpan setts_DefaultTime = TimeSpan.FromHours(ts_DefaultEndTime);
                                DateTime taskValidDate = new DateTime();

                                if (dueDateOffset <= 8)
                                {
                                    tracer.Trace("dueDateOffset <= 8   ..." + dueDateOffset);
                                    taskValidDate = ListHoliday(service, tracer, taskStartDate, taskEndDate);
                                    tracer.Trace("taskValidDate" + taskValidDate);
                                    taskValidDate = (taskValidDate.Date + defaultStartTime).AddHours(Convert.ToDouble(dueDateOffset)); //9 o clock
                                    tracer.Trace("taskValidDate" + taskValidDate);
                                    etaskUpdate["scheduledend"] = taskValidDate;
                                    etaskUpdate["rsa_duedatetime"] = taskValidDate;
                                    tracer.Trace("taskValidDate Updated as : " + taskValidDate);
                                }
                                else
                                {
                                    if (!string.IsNullOrEmpty(dueDateUnits) && dueDateUnits.ToLower() == "hours")
                                    {
                                        dueDateModulo = Convert.ToInt32(dueDateOffset / 8);
                                        tracer.Trace("dueDateModulo : " + dueDateModulo);
                                        reminder = dueDateOffset % 8;
                                        tracer.Trace("reminder : " + reminder);

                                    }
                                    else
                                    {
                                        dueDateModulo = Convert.ToInt32(dueDateOffset);
                                        tracer.Trace("dueDateModulo : " + dueDateModulo);
                                        reminder = dueDateOffset % 8;
                                        tracer.Trace("reminder : " + reminder);

                                    }
                                    if (dueDateModulo > 0)
                                    {
                                        tracer.Trace("dueDateModulo > 0 : " + dueDateModulo);

                                        if (taskStartDate.Date == taskEndDate.Date)
                                        {
                                            tracer.Trace("taskStartDate.Date == taskEndDate.Date");
                                            taskValidDate = ListHoliday(service, tracer, taskStartDate, taskEndDate);
                                            tracer.Trace("ListHoliday1 : " + taskValidDate);
                                            //taskValidDate = taskValidDate.AddDays(dueDateModulo);
                                            taskValidDate = ValidatedDate(service, tracer, taskValidDate, dueDateModulo);
                                            tracer.Trace("taskValidDate1 : " + taskValidDate);

                                            //taskValidDate = ListHoliday(service, tracer, taskStartDate, taskValidDate);
                                            //tracer.Trace("taskValidDate : " + taskValidDate);

                                            taskValidDate = validateWeekend(service, tracer, taskValidDate);
                                            tracer.Trace("taskValidDate2 : " + taskValidDate);

                                            if (dueDateOffset == 24)
                                            {
                                                taskValidDate = (taskValidDate.Date + defaultEndTime).AddHours(Convert.ToDouble(reminder));
                                            }
                                            else
                                            {
                                                taskValidDate = (taskValidDate.Date + defaultStartTime).AddHours(Convert.ToDouble(reminder));
                                            }
                                            tracer.Trace("taskValidDate : " + taskValidDate);

                                            etaskUpdate["scheduledend"] = taskValidDate;
                                            etaskUpdate["rsa_duedatetime"] = taskValidDate;
                                            tracer.Trace("taskValidDate Updated as : " + taskValidDate);
                                        }
                                        else
                                        {
                                            taskValidDate = ListHoliday(service, tracer, taskStartDate, taskEndDate);
                                            tracer.Trace("taskStartDate : " + taskStartDate);
                                            tracer.Trace("taskEndDate : " + taskEndDate);

                                            tracer.Trace("taskValidDate : " + taskValidDate);
                                            //taskValidDate = taskValidDate.AddDays(dueDateModulo);
                                            taskValidDate = ValidatedDate(service, tracer, taskValidDate, dueDateModulo);
                                            //taskValidDate = validateWeekend(service, tracer, taskValidDate);
                                            if (dueDateOffset == 24)
                                            {
                                                taskValidDate = (taskValidDate.Date + defaultEndTime).AddHours(Convert.ToDouble(reminder));
                                            }
                                            else
                                            {
                                                taskValidDate = (taskValidDate.Date + defaultStartTime).AddHours(Convert.ToDouble(reminder));
                                            }
                                            tracer.Trace("taskValidDate : " + taskValidDate);

                                            etaskUpdate["scheduledend"] = taskValidDate;
                                            etaskUpdate["rsa_duedatetime"] = taskValidDate;
                                            tracer.Trace("taskValidDate Updated as : " + taskValidDate);
                                        }
                                    }

                                }

                            }
                            //#endregion CR 335

                            if (actualhandletimemins != -1)
                            {
                                etaskUpdate["rsa_actualhandletimemins"] = actualhandletimemins;
                            }

                            if (postfulfillmentactivitytype != 0 && postfulfillmentactivitytype != 1 && postfulfillmentactivitytype != null)
                                etaskUpdate["rsa_postfulfillmentactivitytype"] = new OptionSetValue(postfulfillmentactivitytype);
                            string assigntemplatetaskto = task.Attributes.ContainsKey("rsa_assigntemplatetaskto") ? task.FormattedValues["rsa_assigntemplatetaskto"] : null;
                            tracer.Trace(" assigntemplatetaskto" + assigntemplatetaskto);
                            bool flag = false;
                            string formID = string.Empty;
                            Guid entaskID = Guid.Empty;
                            Guid useridcheck = context.InitiatingUserId;
                            tracer.Trace("useridcheck" + useridcheck);
                            //List<string> RoleName = new List<string>();
                            //EntityCollection securityRole = getUserRole(service, context.InitiatingUserId, tracer);
                            //tracer.Trace("securityRole line 1570" + securityRole.Entities.Count);
                            //foreach (var item in securityRole.Entities)
                            //{
                            //    // tracer.Trace("Inside Foreach line 1573");
                            //    if (item.Attributes.Contains("role2.name"))
                            //    {
                            //        // tracer.Trace("item.Attributes.Contains(role2.name)");
                            //        AliasedValue AvUserRole = (AliasedValue)item.Attributes["role2.name"];
                            //        //tracer.Trace("AvUserRole Aliased value" + AvUserRole.Value);
                            //        RoleName.Add((Convert.ToString(AvUserRole.Value)));
                            //    }
                            //    //tracer.Trace("userRole"+ RoleName.ToString());
                            //}
                            //RoleName = RoleName.Select(s => s = s.Replace(" ", "")).ToList();
                            //    //  # region
                            //foreach(var item in RoleName)
                            //  {
                            //      tracer.Trace("item line 1587" + item.ToString());
                            //  }
                            //      //#endregion


                            // EntityReference taskID = task.Attributes.Contains("rsa_activitytype") ? task.GetAttributeValue<EntityReference>("rsa_activitytype") : null;
                            //form layout mapping and related source code is no longer required. hence commenting. 
                            //Prachi Paunikar : 20 Aug 2021 
                            #region
                            //if (taskID != null)
                            //{
                            //    entaskID = taskID.Id;
                            //    tracer.Trace("entaskID" + entaskID);
                            //    var fetchXmlQuery = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' no-lock='true'>";
                            //    fetchXmlQuery += "<entity name='rsa_formlayoutmapping'>";
                            //    fetchXmlQuery += "<attribute name='rsa_formlayoutmappingid' />";
                            //    fetchXmlQuery += "<attribute name='rsa_name' />";
                            //    fetchXmlQuery += "<attribute name='rsa_activitytype' />";
                            //    fetchXmlQuery += "<attribute name='rsa_form' />";
                            //    fetchXmlQuery += "<attribute name='rsa_securityrolemapping' />";
                            //    fetchXmlQuery += "<order attribute='rsa_name' descending='false' />";
                            //    fetchXmlQuery += "<filter type='and'>";
                            //    fetchXmlQuery += "<condition attribute='rsa_activitytype' operator='eq' value= '" + taskID.Id + "'/>";
                            //    fetchXmlQuery += "</filter>";
                            //    fetchXmlQuery += "<link-entity name='rsa_formlayout' from='rsa_formlayoutid' to='rsa_form' link-type='inner' alias='ae'>";
                            //    fetchXmlQuery += "<attribute name='rsa_formid'/>";
                            //    fetchXmlQuery += "<filter type='and'>";
                            //    fetchXmlQuery += "<condition attribute='rsa_entityname' operator='eq' value='866760002' />";
                            //    fetchXmlQuery += "</filter>";
                            //    fetchXmlQuery += "</link-entity>";
                            //    fetchXmlQuery += "</entity>";
                            //    fetchXmlQuery += "</fetch>";
                            //    // tracer.Trace("FetchXML Query : {0}", fetchXmlQuery);
                            //    string securityroleoptionset = string.Empty;
                            //    EntityCollection formLayoutMapping = service.RetrieveMultiple(new FetchExpression(fetchXmlQuery));
                            //    tracer.Trace("Count of Formlayouts: {0}", formLayoutMapping.Entities.Count);
                            //    if (formLayoutMapping.Entities.Count > 0)
                            //    {
                            //        foreach (var SecurityRoleMap in formLayoutMapping.Entities)
                            //        {
                            //            securityroleoptionset = SecurityRoleMap.FormattedValues["rsa_securityrolemapping"];

                            //            tracer.Trace("securityroleoptionset line1624 : {0}", securityroleoptionset);
                            //            //if (aBRTransactionType.Applicablevalues.Find(a => a.key.ToLower().Replace(" ", "").Equals(TransactionType.ToLower().Replace(" ", ""))) != null)

                            //            List<string> securityroleList = securityroleoptionset.Split(';').ToList();
                            //            securityroleList = securityroleList.Select(t => t.Replace(" ", "")).ToList();
                            //            #region
                            //            //foreach (var item in securityroleList)
                            //            //{
                            //            //    tracer.Trace("item line 1635" + item.ToString());
                            //            //}

                            //            #endregion
                            //            if (securityroleList.Intersect(RoleName).Any())
                            //            {
                            //                tracer.Trace("success");
                            //                flag = true;
                            //                formID = Convert.ToString(((AliasedValue)SecurityRoleMap.Attributes["ae.rsa_formid"]).Value);
                            //                tracer.Trace("FormID : {0}", formID);
                            //                break;
                            //            }
                            //        }
                            //    }


                            //    if (formLayoutMapping.Entities.Count > 0 && flag == false)
                            //    {
                            //        foreach (var formLayout in formLayoutMapping.Entities)
                            //        {
                            //            formID = Convert.ToString(((AliasedValue)formLayout.Attributes["ae.rsa_formid"]).Value);
                            //            tracer.Trace("FormID : {0}", formID);
                            //            break;
                            //        }
                            //    }
                            //}
                            #endregion

                            //Update the case owner to unassigned user : for Defect 2198
                            //Sumegh Dhole : 10 Aug 2021 : Task not getting created for the renewal generated records. 
                            Entity renewalGenerationStatus = null;  // 20/08/2021
                            if (policyId != null && policyId != Guid.Empty)
                            {
                                renewalGenerationStatus = service.Retrieve("rsa_policy", policyId, new ColumnSet(new string[] { "rsa_renewalgenerationstatuscode" }));
                            }

                            //2316 - Prachi Paunikar : 03 Sept 2021
                            //Capturing renewal generation id and owner from Case
                            Entity caseRenewalGenerationID = null;
                            string caseOwnerName = string.Empty;
                            Guid caseOwnerId = Guid.Empty;
                            if (caseId != null && caseId != Guid.Empty)
                            {
                                caseRenewalGenerationID = service.Retrieve("incident", caseId, new ColumnSet(new string[] { "rsa_renewalgeneration", "ownerid" }));
                                caseOwnerName = caseRenewalGenerationID.Attributes.Contains("ownerid") ? ((EntityReference)caseRenewalGenerationID.Attributes["ownerid"]).Name : string.Empty;
                                caseOwnerId = caseRenewalGenerationID.Attributes.Contains("ownerid") ? ((EntityReference)caseRenewalGenerationID.Attributes["ownerid"]).Id : Guid.Empty;
                                tracer.Trace("ownerid : " + "Unassigned user : " + caseOwnerName);
                                tracer.Trace("ownerid : " + "Unassigned user : " + caseOwnerName.ToLower().Contains("unassigned"));
                            }

                            //if (renewalGenerationStatus!=null && renewalGenerationStatus.GetAttributeValue<EntityReference>("rsa_renewalgenerationstatuscode") != null)

                            //2316 - Prachi Paunikar : 03 Sept 2021
                            //Using renewal generation id and owner from Case should be Unassigned

                            if (caseRenewalGenerationID != null && caseRenewalGenerationID.Attributes.Contains("rsa_renewalgeneration") && caseRenewalGenerationID.Attributes["rsa_renewalgeneration"] != null && caseOwnerName.ToLower().Contains("unassigned"))
                            {
                                QueryExpression userQry = new QueryExpression("systemuser");
                                userQry.TopCount = 1;
                                userQry.ColumnSet = new ColumnSet(new string[] { "rsa_username", "fullname" });
                                userQry.NoLock = true;
                                userQry.Criteria = new FilterExpression();
                                ConditionExpression usrCondtExp = new ConditionExpression();
                                usrCondtExp.AttributeName = "rsa_username";
                                usrCondtExp.Operator = ConditionOperator.Equal;
                                usrCondtExp.Values.Add("unassigneduser@uk.rsagroup.com");
                                userQry.Criteria.AddCondition(usrCondtExp);
                                EntityCollection unassigneduser = service.RetrieveMultiple(userQry);

                                foreach (Entity item in unassigneduser.Entities)
                                {
                                    tracer.Trace("ownerid : " + "Unassigned user : " + item.Id);
                                    etaskUpdate["ownerid"] = new EntityReference("systemuser", item.Id);
                                }

                                //2316 - Prachi Paunikar : 03 Sept 2021
                                //Set Unassigned to Owner of task
                                etaskUpdate["ownerid"] = new EntityReference("systemuser", caseOwnerId);

                                // opportunityUpdate["rsa_taskformid"] = formID;
                                tracer.Trace("Case Id : " + caseId);
                                tracer.Trace("Policy Id : " + policyId);
                                tracer.Trace("Opportunity Id : " + opportunityId);
                            }

                            //// Defect 2100 By Atul Agrawal
                            /////Chandani: 30/11/2022 : Added below commented code at line 1637
                            /*
                            bool isTaskAlreadyAvailable = false;
                            if (etaskUpdate["regardingobjectid"] != null && ((EntityReference)etaskUpdate["regardingobjectid"]).LogicalName == "incident"
                                && !string.IsNullOrEmpty(subject))
                            {
                                tracer.Trace("BPO Initial Processing Task found. Now prepairing query to check if task already available");
                                string duplicateBPOTask = "<fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>";
                                duplicateBPOTask += "<entity name='task'>";
                                duplicateBPOTask += "<attribute name='subject' />";
                                duplicateBPOTask += "<attribute name='statecode' />";
                                duplicateBPOTask += "<attribute name='prioritycode' />";
                                duplicateBPOTask += "<attribute name='scheduledend' />";
                                duplicateBPOTask += "<attribute name='createdby' />";
                                duplicateBPOTask += "<attribute name='regardingobjectid' />";
                                duplicateBPOTask += "<attribute name='activityid' />";
                                duplicateBPOTask += "<attribute name='rsa_nextcallduedatetime' />";
                                duplicateBPOTask += "<order descending='true' attribute='modifiedon' />";
                                duplicateBPOTask += "<filter type='and'>";
                                duplicateBPOTask += "<condition attribute='regardingobjectid' value='" + entityPostImage.Id + "' uitype='incident' uiname='' operator='eq' />";
                                duplicateBPOTask += "<condition attribute='statuscode' value='5' operator='ne' />";
                                duplicateBPOTask += "<condition attribute='subject' value='" + subject + "' operator='eq'/>";
                                duplicateBPOTask += "</filter>";
                                duplicateBPOTask += "</entity>";
                                duplicateBPOTask += "</fetch>";
                                EntityCollection existingTasks = service.RetrieveMultiple(new FetchExpression(duplicateBPOTask));
                                tracer.Trace("After RetrieveMultiple");
                                if (existingTasks != null && existingTasks.Entities != null && existingTasks.Entities.Count > 0)
                                {
                                    tracer.Trace("task already available: " + existingTasks.Entities.Count.ToString());
                                    isTaskAlreadyAvailable = true;
                                }
                            }*/
                            //// Defect 2100 Changes End

                            if (isTaskAlreadyAvailable == false)  //// Condition added for defect 2100 by Atul
                            {
                                if (!string.IsNullOrEmpty(assigntemplatetaskto) && assigntemplatetaskto.ToLower() == "owner")
                                {
                                    //EntityReference ownerId = entityPostImage.Contains("ownerid") && entityPostImage.GetAttributeValue<EntityReference>("ownerid") != null ? entityPostImage.GetAttributeValue<EntityReference>("ownerid") : null;

                                    service.Create(etaskUpdate);

                                    tracer.Trace("Activities created.");
                                }
                                else if (!string.IsNullOrEmpty(assigntemplatetaskto) && assigntemplatetaskto.ToLower() == "queue")
                                {
                                    tracer.Trace("line 2513");
                                    Guid queueId = task.Contains("rsa_assigntemplatetasktoqueues") ? task.GetAttributeValue<EntityReference>("rsa_assigntemplatetasktoqueues").Id : Guid.Empty;
                                    tracer.Trace("queueId" + queueId);
                                    //Below If condition added by Jyoti Bhosale for ABRARC changes 12/08/2022
                                    if (ARCQueueId != Guid.Empty)
                                    {
                                        queueId = ARCQueueId;
                                        tracer.Trace("Email to case and Task allocation Queue while updating ARCQueueid is: " + ARCQueueId);
                                    }
                                    //////////////////////////////////
                                    if (queueId != Guid.Empty)
                                    {
                                        etaskUpdate["rsa_queue"] = new EntityReference("queue", queueId);//bug 1618 Queue not assigned
                                                                                                         //service.Update(opportunityUpdate);
                                    }
                                    Guid taskId = service.Create(etaskUpdate);
                                    tracer.Trace("taskId" + taskId);
                                    //bug 2141 : task get assigned to unassigned user.
                                    tracer.Trace("calling getuser function");
                                    Entity enUser = getUser("Unassigned", service);
                                    tracer.Trace("Record reterieved " + enUser);
                                    tracer.Trace("Record reterieved " + enUser.Id);
                                    Guid userid = enUser.Id;
                                    EntityReference unassigneduser = new EntityReference("systemuser", enUser.Id);
                                    tracer.Trace("Activities created.");
                                    tracer.Trace("Activities created.now");
                                    if (userid != Guid.Empty)
                                    {
                                        AssignRequest assignRequest = new AssignRequest
                                        {
                                            Assignee = unassigneduser,
                                            Target = new EntityReference("task", taskId)

                                        };
                                        service.Execute(assignRequest);
                                        //Modified on -18/03 ;Modified By-Nida;Details:MS remediation applied to  Replace deprecated assignrequest message
                                        //Modified on -20/04 ;Modified By-Nida;Details:2689
                                        Entity taskUpdate = new Entity("task", taskId);
                                        taskUpdate["ownerid"] = unassigneduser;
                                        service.Update(taskUpdate);
                                        tracer.Trace("Activities is unassigned .");
                                    }
                                    //End bug :2141
                                    tracer.Trace("Activities created.");
                                    //Below If condition added by Jyoti for ABRARC changes
                                    if (ARCQueueId != Guid.Empty)
                                    {
                                        queueId = ARCQueueId;
                                        tracer.Trace("Email to case and Task allocation Queue: " + queueId);
                                    }
                                    //////////////////////////////////
                                    if (queueId != Guid.Empty)
                                    {

                                        AddToQueueRequest routeRequest = new AddToQueueRequest
                                        {
                                            Target = new EntityReference("task", taskId),
                                            DestinationQueueId = queueId
                                        };

                                        service.Execute(routeRequest);
                                        tracer.Trace("Activities added in queue." + taskId);
                                    }
                                    if (queueId != Guid.Empty)
                                    {
                                        etaskUpdate["rsa_queue"] = new EntityReference("queue", queueId);//bug 1618 Queue not assigned
                                                                                                         //service.Update(opportunityUpdate);
                                    }
                                   
                                    //Reassign queue
                                    if (etaskUpdate.Attributes.Contains("subject") && etaskUpdate.GetAttributeValue<String>("subject") == "Quote Work Up")
                                    {
                                        tracer.Trace("Reassign function - Quote Workup identified. - 2");
                                        var offShoreProcQueue = new Guid("eb14194c-e7be-f011-bbd3-000d3ad642e9");
                                        if (caseId != null && caseId != Guid.Empty)
                                        {
                                            var caseDet = service.Retrieve("incident", caseId, new ColumnSet("rsa_product_w"));
                                            if (caseDet != null && caseDet.Attributes.Contains("rsa_product_w") && caseDet.GetAttributeValue<String>("rsa_product_w") == "Intact Motor Fleet")
                                            {
                                                tracer.Trace("Reassign function - Product : " + caseDet.GetAttributeValue<String>("rsa_product_w"));
                                                tracer.Trace("Reassign function - Taskid : " + taskId);
                                                
                                                tracer.Trace("Reassign function - Task updated with owner and queue");

                                                //Remove from other queues
                                                tracer.Trace("Reassign function - Remove from existing queues started");
                                                tracer.Trace("Reassign function - Taskid : " + taskId);

                                                QueryExpression query = new QueryExpression("queueitem");
                                                query.ColumnSet = new ColumnSet("queueitemid");

                                                query.Criteria.AddCondition("objectid", ConditionOperator.Equal, taskId);

                                                EntityCollection queueItems = service.RetrieveMultiple(query);

                                                // 2. Loop through and delete each queue item
                                                foreach (Entity queueItem in queueItems.Entities)
                                                {
                                                    //tracer.Trace("Reassign function 2 - Deleting queue item : " + queueItem.Id);
                                                   // service.Delete("queueitem", queueItem.Id);
                                                    //tracer.Trace("Reassign function 2 - Deleted queue item : " + queueItem.Id);
                                                }
                                                tracer.Trace("Reassign function - Removed from existing queues");

                                                //Reassign to Offhore Processing
                                                AddToQueueRequest routeRequestOffProcessing = new AddToQueueRequest
                                                {
                                                    Target = new EntityReference("task", taskId),
                                                    DestinationQueueId = offShoreProcQueue
                                                };
                                                service.Execute(routeRequestOffProcessing);
                                                tracer.Trace("Reassign function - Added to Offshore Queue : eb14194c-e7be-f011-bbd3-000d3ad642e9");

                                                //Update Queue on task
                                                Entity workUptaskUpdate = new Entity("task", taskId);
                                                tracer.Trace("Reassign function - queueid : " + offShoreProcQueue);
                                                workUptaskUpdate["rsa_queue"] = new EntityReference("queue", offShoreProcQueue);
                                                tracer.Trace("Reassign function - userid : " + workupOwnerID);
                                                EntityReference taskOwner = new EntityReference("systemuser", new Guid(workupOwnerID));
                                                workUptaskUpdate["ownerid"] = taskOwner;
                                                service.Update(workUptaskUpdate);
                                            }
                                        }
                                    }
                                }
                                else if (!string.IsNullOrEmpty(assigntemplatetaskto) && assigntemplatetaskto.ToLower() == "mumbai handler")
                                {
                                    Guid activitytaskId = service.Create(etaskUpdate);
                                    tracer.Trace("Activities created fr Mumbai Handler");

                                    if (policyId != Guid.Empty)
                                    {
                                        Entity mumbaiHandler = service.Retrieve("rsa_policy", policyId, new ColumnSet(new string[] { "rsa_mumbaihandler" }));

                                        if (mumbaiHandler.Attributes.Contains("rsa_mumbaihandler"))
                                        {
                                            EntityReference handlerUser = (EntityReference)mumbaiHandler.Attributes["rsa_mumbaihandler"];
                                            tracer.Trace("Mumbai Handler " + mumbaiHandler.Id);
                                            //AssignRequest assignRequest = new AssignRequest
                                            //{
                                            //    Assignee = handlerUser,
                                            //    Target = new EntityReference("task", activitytaskId)
                                            //};
                                            //service.Execute(assignRequest);
                                            //Modified on -18/03 ;Modified By-Nida;Details:MS remediation applied to  Replace deprecated assignrequest message
                                            //Modified on -20/04 ;Modified By-Nida;Details:2689
                                            Entity taskUpdate = new Entity("task", activitytaskId);
                                            taskUpdate["ownerid"] = handlerUser;
                                            service.Update(taskUpdate);
                                            tracer.Trace("Task Record Assigned to mumbaiHandler.");
                                        }
                                    }
                                }
                                else if (!string.IsNullOrEmpty(assigntemplatetaskto) && assigntemplatetaskto.ToLower() == "trader")
                                {
                                    Guid activitytaskId = service.Create(etaskUpdate);
                                    tracer.Trace("Activities created for Trader");
                                    if (policyId != Guid.Empty)
                                    {
                                        Entity policyTrader = service.Retrieve("rsa_policy", policyId, new ColumnSet(new string[] { "rsa_policytrader" }));
                                        if (policyTrader.Attributes.Contains("rsa_policytrader"))
                                        {
                                            EntityReference TraderUser = (EntityReference)policyTrader.Attributes["rsa_policytrader"];
                                            //AssignRequest assignRequest = new AssignRequest
                                            //{
                                            //    Assignee = TraderUser,
                                            //    Target = new EntityReference("task", activitytaskId)
                                            //};
                                            //service.Execute(assignRequest);
                                            //Modified on -18/03 ;Modified By-Nida;Details:MS remediation applied to  Replace deprecated assignrequest message
                                            //Modified on -20/04 ;Modified By-Nida;Details:2689
                                            Entity taskUpdate = new Entity("task", activitytaskId);
                                            taskUpdate["ownerid"] = TraderUser;
                                            service.Update(taskUpdate);
                                            tracer.Trace("Task Record Assigned to Trader.");
                                        }
                                    }
                                }
                                else if (!string.IsNullOrEmpty(assigntemplatetaskto) && assigntemplatetaskto.ToLower() == "underwriter")
                                {
                                    Guid activitytaskId = service.Create(etaskUpdate);
                                    tracer.Trace("Activities created for underwriter");
                                    if (opportunityId != Guid.Empty)
                                    {
                                        Entity underwriter = service.Retrieve("opportunity", opportunityId, new ColumnSet(new string[] { "rsa_secondaryowner" }));
                                        if (underwriter.Attributes.Contains("rsa_secondaryowner"))
                                        {
                                            EntityReference TraderUser = (EntityReference)underwriter.Attributes["rsa_secondaryowner"];
                                            //AssignRequest assignRequest = new AssignRequest
                                            //{
                                            //    Assignee = TraderUser,
                                            //    Target = new EntityReference("task", activitytaskId)
                                            //};
                                            //service.Execute(assignRequest);
                                            //Modified on -18/03 ;Modified By-Nida;Details:MS remediation applied to  Replace deprecated assignrequest message
                                            //Modified on -20/04 ;Modified By-Nida;Details:2689
                                            Entity taskUpdate = new Entity("task", activitytaskId);
                                            taskUpdate["ownerid"] = TraderUser;
                                            service.Update(taskUpdate);
                                            tracer.Trace("Task Record Assigned to Underwriter.");
                                        }
                                    }
                                }
                                //Date:04022021 Unaassigned usercondition added
                                else if (!string.IsNullOrEmpty(assigntemplatetaskto) && assigntemplatetaskto.ToLower() == "unassigned")
                                {
                                    Guid taskId = service.Create(etaskUpdate);
                                    tracer.Trace("calling getuser function");
                                    Entity enUser = getUser("Unassigned", service);
                                    tracer.Trace("Record reterieved " + enUser);
                                    tracer.Trace("Record reterieved " + enUser.Id);
                                    Guid userid = enUser.Id;
                                    EntityReference user = new EntityReference("systemuser", enUser.Id);
                                    tracer.Trace("Activities created.");
                                    tracer.Trace("Activities created.now");
                                    if (userid != Guid.Empty)
                                    {
                                        //AssignRequest assignRequest = new AssignRequest
                                        //{
                                        //    Assignee = user,
                                        //    Target = new EntityReference("task", taskId)

                                        //};
                                        //service.Execute(assignRequest);
                                        //Modified on -18/03 ;Modified By-Nida;Details:MS remediation applied to  Replace deprecated assignrequest message
                                        //Modified on -20/04 ;Modified By-Nida;Details:2689
                                        Entity taskUpdate = new Entity("task", taskId);
                                        taskUpdate["ownerid"] = user;
                                        service.Update(taskUpdate);
                                        tracer.Trace("Activities is unassigned .");
                                    }
                                }
                                else
                                {
                                    return;
                                }
                            }

                        }

                    }
                }
            }
            catch (Exception ex)
            {
                tracer.Trace("GetABRTasks-Error" + ex.Message.ToString());
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        public EntityCollection getUserRole(IOrganizationService service, Guid userid, ITracingService tracer)
        {
            //Guid userid = new Guid("55A0BCC3-6DC2-4B75-B00F-200B2C7A8EF6");
            // List<string> userRole = null;
            QueryExpression qe = new QueryExpression("systemuserroles");
            qe.ColumnSet.AddColumns("systemuserid");
            qe.Criteria.AddCondition("systemuserid", ConditionOperator.Equal, userid);
            qe.NoLock = true;

            LinkEntity link1 = qe.AddLink("systemuser", "systemuserid", "systemuserid", JoinOperator.Inner);
            link1.Columns.AddColumns("fullname");
            LinkEntity link = qe.AddLink("role", "roleid", "roleid", JoinOperator.Inner);
            link.Columns.AddColumns("roleid", "name");
            EntityCollection results = service.RetrieveMultiple(qe);
            tracer.Trace("results line 1776" + results);
            //foreach (Entity Userrole in results.Entities)
            //{
            //    if (Userrole.Attributes.Contains("systemuser1.fullname"))
            //    {
            //       // tracer.Trace("name of the user");
            //    }
            //    if (Userrole.Attributes.Contains("role2.name"))
            //    {
            //        AliasedValue AvUserRole = (AliasedValue)Userrole.Attributes["role2.name"];
            //        userRole.Add(AvUserRole.Value.ToString());
            //        tracer.Trace("userRole"+ userRole.ToString());
            //    }

            //}
            return results;
        }

        /// <summary>
        /// Unassigned User fetch  for abr tracking
        /// </summary>
        /// <param name="service"></param>
        /// <param name="caseId"></param>
        /// <param name="fieldName"></param>
        /// <returns></returns>
        public static Entity getUser(string name, IOrganizationService service)
        {
            try
            {
                var recordName = new Entity();
                QueryExpression query = new QueryExpression("systemuser");
                query.ColumnSet = new ColumnSet(new string[] { "firstname" });

                query.Criteria.AddCondition("firstname", ConditionOperator.Equal, name);
                query.NoLock = true;
                EntityCollection businessRecordTypes = service.RetrieveMultiple(query);
                if (businessRecordTypes != null && businessRecordTypes.Entities.Count > 0)
                {
                    recordName = businessRecordTypes.Entities[0];
                }
                return recordName;
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
        private static DateTime GetCasesDates(IOrganizationService service, Guid caseId, string fieldName)
        {
            try
            {
                DateTime date = DateTime.MinValue;
                var oppLookup = service.Retrieve("incident", caseId, new ColumnSet("createdon"));
                if (oppLookup != null)
                {
                    date = Convert.ToDateTime(oppLookup.Attributes["createdon"]);
                }
                return date;
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        private static DateTime GetOpportunityDate(IOrganizationService service, Guid opportunityId, string fieldName)
        {
            try
            {
                DateTime date = DateTime.MinValue;
                var oppLookup = service.Retrieve("opportunity", opportunityId, new ColumnSet("" + fieldName + ""));
                if (oppLookup != null)
                {
                    date = Convert.ToDateTime(oppLookup.Attributes["" + fieldName + ""]);
                }
                return date;
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
        /// <summary>
        /// To get Email create date and time for ARC ABR changes
        /// </summary>
        /// <param name="service"></param>
        /// <param name="caseid"></param>
        /// <param name="fieldName"></param>
        /// <returns></returns>
        private static DateTime GetEmailCreatedDate(IOrganizationService service, Guid caseId, string fieldName)
        {
            try
            {
                DateTime date = DateTime.MinValue;
                string fetchMailCreatedDate = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
  <entity name='email'>
       <attribute name='createdon' />
      <filter type='and'>
      <condition attribute='regardingobjectid' operator='eq' uitype='incident' value='{0}' />
    </filter>
  </entity>
</fetch>";

                var objresult = service.RetrieveMultiple(new FetchExpression(String.Format(fetchMailCreatedDate, caseId)));
                if (objresult != null && objresult.Entities.Count > 0)
                {

                    date = Convert.ToDateTime(objresult[0].Attributes["" + fieldName + ""]);
                }


                return date;
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
        public static DateTime CalculateBusinessDays(IOrganizationService service, ITracingService tracer, DateTime dt, int numberOfDays)
        {
            try
            {
                int offset = numberOfDays;


                var timeSpandt = dt.TimeOfDay;
                tracer.Trace("timeSpandt 2224 line " + timeSpandt);
                DateTime duedate = dt;
                //Defect id 2098 : Sumegh Dhole : Change for considering the due date offset if marked as negative 
                if (offset > 0)
                {
                    for (int i = 0; i < offset; i++)
                    {
                        duedate = duedate.AddDays(1);

                        if (duedate.DayOfWeek == DayOfWeek.Saturday || duedate.DayOfWeek == DayOfWeek.Sunday)
                        {
                            duedate = duedate.AddDays(2);
                        }
                    }
                }
                else
                {
                    for (int i = 0; i > offset; i--)
                    {
                        duedate = duedate.AddDays(-1);

                        if (duedate.DayOfWeek == DayOfWeek.Saturday || duedate.DayOfWeek == DayOfWeek.Sunday)
                        {
                            duedate = duedate.AddDays(-2);
                        }
                    }
                }

                return duedate;
            }

            catch (Exception ex)
            {
                tracer.Trace("CalculateBusinessDays-Error" + ex.Message.ToString());
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
        public static DateTime RevertBackToFriday(IOrganizationService service, DateTime taskEndDate)
        {
            try
            {
                switch (taskEndDate.DayOfWeek)
                {
                    case DayOfWeek.Saturday:
                        taskEndDate = taskEndDate.AddDays(-1);
                        break;
                    case DayOfWeek.Sunday:
                        taskEndDate = taskEndDate.AddDays(-2);
                        break;
                    default:
                        break;
                }


                return taskEndDate;
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
        public static DateTime CreateNewDate(int year, int month, int day, DateTime time)
        {
            return new DateTime(year, month, day, time.Hour, time.Minute, 0);
        }
        //retrive all holiday

        public static DateTime ListHoliday(IOrganizationService service, ITracingService tracer, DateTime taskStartDate, DateTime taskEndDate)
        {
            try
            {
                tracer.Trace("ListHoliday in side");
                List<Entity> calendarRules = new List<Entity>();
                Entity businessClosureCalendar = null;
                DateTime validDate = new DateTime();
                QueryExpression holidayQuery = new QueryExpression("calendar") { NoLock = true };
                holidayQuery.Criteria.AddCondition("type", ConditionOperator.Equal, 2);
                EntityCollection businessClosureCalendars = service.RetrieveMultiple(holidayQuery);
                tracer.Trace("businessClosureCalendars.Entities.Count" + businessClosureCalendars.Entities.Count);
                if (businessClosureCalendars.Entities.Count > 0)
                {
                    businessClosureCalendar = businessClosureCalendars.Entities[0];

                    calendarRules = (businessClosureCalendar.GetAttributeValue<EntityCollection>("calendarrules")).Entities.ToList();
                    List<DateTime> holidays = calendarRules.Select(rule => rule.GetAttributeValue<DateTime>("starttime")).Where(date => date >= taskStartDate.Date && date <= taskEndDate.Date).ToList();
                    tracer.Trace("holidays" + holidays.Count);
                    if (holidays.Contains(taskEndDate.Date))
                    {
                        while (holidays.Contains(taskEndDate.Date))
                        {

                            taskEndDate = taskEndDate.AddDays(1);
                            taskEndDate = validateWeekend(service, tracer, taskEndDate);

                        }
                        validDate = taskEndDate;

                    }
                    else
                    {
                        if (holidays.Contains(taskStartDate.Date))

                            while (holidays.Contains(taskStartDate.Date))
                            {

                                taskStartDate = taskStartDate.AddDays(1);
                                tracer.Trace("add day as  found holiday taskStartDate" + taskStartDate);
                                taskStartDate = validateWeekend(service, tracer, taskStartDate);

                            }
                        validDate = taskStartDate;
                    }

                }
                return validDate;

            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        public static DateTime validateWeekend(IOrganizationService service, ITracingService tracer, DateTime validDate)
        {
            try
            {
                tracer.Trace("validDate in side");
                if (validDate.DayOfWeek == DayOfWeek.Saturday)
                {
                    validDate = validDate.AddDays(2);
                    tracer.Trace("add day as  found weekend Saturday taskEndDate" + validDate);
                }
                else if (validDate.DayOfWeek == DayOfWeek.Sunday)
                {
                    validDate = validDate.AddDays(1);
                    tracer.Trace("add day as  found weekend Sunday taskEndDate" + validDate);
                }

                return validDate;

            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        public static DateTime ValidatedDate(IOrganizationService service, ITracingService tracer, DateTime validDate, int addDay)
        {
            try
            {
                int addedDay = 1;
                while (addedDay >= 1 && addedDay < addDay)
                {
                    validDate = validDate.AddDays(1);
                    validDate = validateWeekend(service, tracer, validDate);
                    tracer.Trace("ValidatedDate " + validDate);
                    addedDay = addedDay + 1;
                    tracer.Trace("addedDay " + addedDay);
                }
                tracer.Trace("ValidatedDate " + validDate);
                return validDate;


            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
        public static Entity toggleABRTracking(IOrganizationService service, string name)
        {
            try
            {
                var recordName = new Entity();
                QueryExpression query = new QueryExpression("rsa_customlabel");
                query.ColumnSet = new ColumnSet(new string[] { "rsa_name", "rsa_language" });
                query.NoLock = true;

                query.Criteria.AddCondition("rsa_name", ConditionOperator.Equal, name);
                EntityCollection businessRecordTypes = service.RetrieveMultiple(query);
                if (businessRecordTypes != null && businessRecordTypes.Entities.Count > 0)
                {
                    recordName = businessRecordTypes.Entities[0];
                }
                return recordName;
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
        /// <summary>
        /// Create Activities for the Case
        /// </summary>
        /// <param name="service">The Service</param>
        /// <param name="tracer">The tracing service.</param>
        /// <param name="entity">Tasks</param>
        /// <param name="Subject">Subject</param>
        public void CreateActivities(IOrganizationService service, Guid caseId, string Subject, ITracingService tracer)
        {
            try
            {

            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        public int? RetrieveCurrentUsersSettings(IOrganizationService service)

        {

            var currentUserSettings = service.RetrieveMultiple(

                new QueryExpression("usersettings")

                {

                    ColumnSet = new ColumnSet("timezonecode"),

                    Criteria = new FilterExpression

                    {

                        Conditions =

                        {

                            new ConditionExpression("systemuserid", ConditionOperator.EqualUserId)

                        }

                    },

                    NoLock = true

                }).Entities[0].ToEntity<Entity>();

            //return time zone code

            return (int?)currentUserSettings.Attributes["timezonecode"];

        }


        ///

        ///  Retrive the local time from the UTC time.

        ///

        /// UTC Date time which needs to convert to Local DateTime

        /// TimeZoneCode

        /// IOrganizationService service

        ///

        public DateTime RetrieveLocalTimeFromUTCTime(DateTime utcTime, int? timeZoneCode, IOrganizationService service)

        {

            if (!timeZoneCode.HasValue)

                return DateTime.Now;

            var request = new LocalTimeFromUtcTimeRequest

            {

                TimeZoneCode = timeZoneCode.Value,
                //02/09/2022: Task completion error
                UtcTime = utcTime.ToUniversalTime()
                //Remediation 22/07/2022
                //UtcTime = utcTime

            };

            var response = (LocalTimeFromUtcTimeResponse)service.Execute(request);

            return response.LocalTime;

        }


        ///

        ///  Retrive the UTC DateTime from Local Date time format.

        ///

        /// Local Date time which needs to convert to UTC

        /// TimeZoneCode

        /// IOrganizationService service

        ///

        public DateTime RetrieveUTCTimeFromLocalTime(DateTime localTime, int? timeZoneCode, IOrganizationService service)

        {

            if (!timeZoneCode.HasValue)

                //return DateTime.Now;
                return DateTime.UtcNow;


            var request = new UtcTimeFromLocalTimeRequest

            {

                TimeZoneCode = timeZoneCode.Value,

                LocalTime = localTime

            };

            var response = (UtcTimeFromLocalTimeResponse)service.Execute(request);

            return response.UtcTime;

        }

    }

    public class Incident
    {
        public int Status { get; set; }//  rsa_Status
        public int TransactiontType { get; set; }  //rsa_transactiontype
        public int Promise { get; set; }//rsa_Promise d
        public int Traded { get; set; }//rsa_Traded  d
        public int Active { get; set; }//statecode
        public int CustomerType { get; set; }//rsa_CustomerType d        
        public bool EnforcePostFulfillment { get; set; }
        public int TriggerinObjectRecordType { get; set; }   //rsa_RecordType
        public int CaseReason { get; set; } //rsa_casereason na
        public int RenewalReviewType { get; set; } //rsa_RenewalReviewType d
        public int ClassofBusiness { get; set; } //rsa_ClassofBusiness d
        public bool ApplyR90conditions { get; set; }
        public int BrokerPrimaryReference { get; set; } //rsa_brokerprimaryreference
        public int Productsme { get; set; }
        public int KeySMEBroker { get; set; }
        public int Dealscase { get; set; }
    }

    [DataContract]
    public class Applicablevalue
    {
        [DataMember]
        public string key { get; set; }
        [DataMember]
        public string Value { get; set; }
    }
    [DataContract]
    public class ABRMultiselect
    {
        [DataMember]
        public string AttributeName { get; set; }
        [DataMember]
        public List<Applicablevalue> Applicablevalues { get; set; }
    }
    [DataContract]
    public class ABROptionsetRoot
    {
        [DataMember]
        public List<ABRMultiselect> ABRMultiselect { get; set; }
    }

    //ARC code change :Jyoti Bhosale 02/08/2022
    [DataContract]
    public class ARCDetails
    {
        [DataMember]
        public string ReceivingMailbox { get; set; }

        [DataMember]
        public string MailboxGUID { get; set; }

        [DataMember]
        public string AbrMailboxValue { get; set; }

        [DataMember]
        public List<QueueDetails> QueueDetails { get; set; }
        [DataMember]
        public List<SLADetails> SLADetails { get; set; }
        [DataMember]
        public string Taskstatus { get; set; }


    }
    [DataContract]
    public class SLADetails
    {
        [DataMember]
        public string DuedateOffset { get; set; }

        [DataMember]
        public string BasedOn { get; set; }
    }

    [DataContract]
    public class QueueDetails
    {
        [DataMember]
        public string QueueName { get; set; }

        [DataMember]
        public string QueueID { get; set; }

    }
    [DataContract]
    public class ARCOptionsetRoot
    {
        [DataMember]
        public List<ARCDetails> ARCDetails { get; set; }
    }
    /////////////////////jyoti


}




