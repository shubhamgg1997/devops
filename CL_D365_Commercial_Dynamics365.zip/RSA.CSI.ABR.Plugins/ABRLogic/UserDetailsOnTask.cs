﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;

namespace RSA.CSI.Plugins.Case.Logic
{
    public class UserDetailsOnTask
    {
        private void ValidateTask(Entity entity, IOrganizationService service, ITracingService tracer)
        {
            try
            {
                var userDetails = service.Retrieve("systemuser", entity.Id, new ColumnSet("systemuserid", "site", "rsa_division"));
                
                string initialAssignedtoUser = entity.Attributes.Contains("rsa_initialassignedtouser") ? entity.GetAttributeValue<string>("rsa_initialassignedtouser") :string.Empty;

                int initialAssignedtoDivision = entity.Contains("rsa_initialassignedtodivision") && entity.GetAttributeValue<OptionSetValue>("rsa_customertype") != null ? entity.GetAttributeValue<OptionSetValue>("rsa_initialassignedtodivision").Value : -1;

                int initialAssignedtoSite = entity.Contains("rsa_initialassignedtosite") && entity.GetAttributeValue<OptionSetValue>("rsa_customertype") != null ? entity.GetAttributeValue<OptionSetValue>("rsa_initialassignedtosite").Value : -1;

                int initialAssignedtoTeam = entity.Contains("rsa_initialassignedtoteam") && entity.GetAttributeValue<OptionSetValue>("rsa_customertype") != null ? entity.GetAttributeValue<OptionSetValue>("rsa_initialassignedtoteam").Value : -1;

                Boolean tRule1 = true;//!tskObj.IsClosed && initialAssignedtoUser == string.Empty && initialAssignedtoDivision == -1 && initialAssignedtoSite == -1 && initialAssignedtoTeam == -1;

                Boolean tRule2 = false; //tskObj.IsClosed;

                if (tRule1)
                {
                    UpdateUserDetailsOnTask(entity, userDetails, tRule1);
                }
                if (tRule2)
                {
                    UpdateUserDetailsOnTask(entity, userDetails, tRule2);
                }

            }
            catch (Exception)
            {

                throw;
            }
        }
        private void UpdateUserDetailsOnTask(Entity entity, Entity userDetails, bool tRule)
        {
            try
            {
                if (tRule)
                {
                    //entity["rsa_initialassignedtouser"] = ((EntityReference)entity.Attributes["systemuserid"]).Name;
                    //entity["rsa_initialassignedtodivision"] = c1;
                    //entity["rsa_initialassignedtosite"] = c2;
                    //entity["rsa_initialassignedtoteam"] = c3;
                }
                else
                {
                    //entity["rsa_completedbyuser"] = ((EntityReference)entity.Attributes["systemuserid"]).Name;
                    //entity["rsa_completedbydivision"] = c1;
                    //entity["rsa_completedbysite"] = c2;
                    //entity["rsa_completedbyteam"] = c3;


                }
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
