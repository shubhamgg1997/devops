﻿using RSA.Crm.Plugins;
using Microsoft.Xrm.Sdk;
using System;
using System.ServiceModel;
using RSA.CSI.Plugins.ABR.Logic;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using System.Linq;
using Microsoft.Xrm.Sdk.Query;

namespace RSA.CSI.Plugins.ABR
{
    public class ABRPostUpdate : IPlugin
    {
        private readonly string _unsecureString;

        public ABRPostUpdate(string unsecureString)
        {
            _unsecureString = unsecureString;
        }

        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService tracer = null;
            IPluginExecutionContext context = null;
            IOrganizationService service = null;

            CrmPluginHelper.Initialise(serviceProvider, ref context, ref service, ref tracer, false);
            tracer.Trace("ABR Post update Trace: " + context.Depth.ToString());
            // Sumegh DHole : Defect 2098, 2193 : Historic data fix 
            //Nida: 08 June 2022 : Depth 6 condition added for the tasks to be generated post renewal generation. 
            //Nida: 17 June 2022 : Depth  condition added to prevent duplicate Task creation. 
            //Chandani: 6/10/2022 : Depth removed as no dependency
            //Chandani: 01/12/2022 : Depth removed as no dependency - Added record to ABR Tracking
            /*
            if (context.Depth > 1 && context.Depth != 6)           
            {
                return;
            }
            */

            if (!context.MessageName.ToLower().Equals("update"))
            {
                return;
            }

            try
            {
                if ((context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity) && context.MessageName.ToLowerInvariant() == "update" && context.Stage == 40)
                {
                    tracer.Trace("Instance created and target is available.");
                    Entity entity = (Entity)context.InputParameters["Target"];
                    Entity entityPostImage = (Entity)context.PostEntityImages["PostImage"];
                    //VAriable added by Jyoti Bhosale 3/08/2022
                    ARCOptionsetRoot objARCOptionsetRoot = new ARCOptionsetRoot();
                    Guid ARCQueueId = new Guid();
                    int casesource = 0;
                    //////////////////////////
                    tracer.Trace("Case Id :" + entity.Id);

                    //Check for renewal generation cases : If Depth is 4 and case is of renewala generration then only continue else return 
                    //Defect id 2098 : 
                    //Chandani : 30/11/2022 : Commented below code to remove Depth Dependency
                    #region Commented code to check whether Case is Renewal Generated
                    /*
                    if (context.Depth == 4 || context.Depth == 2 || context.Depth == 6)
                    {
                        string fetchQuery = "<fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>";
                        fetchQuery += "<entity name='incident'>";
                        fetchQuery += "<attribute name='title' />";
                        fetchQuery += "<order descending='false' attribute='title' />";
                        fetchQuery += "<filter type='and'>";
                        fetchQuery += "<condition attribute='incidentid' operator='eq' value = '" + entity.Id + "'/>";
                        fetchQuery += "<condition attribute='rsa_renewalgeneration' operator='not-null' />";
                        fetchQuery += "</filter>";
                        fetchQuery += "</entity>";
                        fetchQuery += "</fetch>";
                        tracer.Trace("Fetch case if renewal generated :" + entity.Id);
                        EntityCollection entyCollCase = service.RetrieveMultiple(new FetchExpression(fetchQuery));
                        if (entyCollCase.Entities.Count < 1)
                        {
                            tracer.Trace("return as record is not renewal generated and having depth as 2 or 4");
                            return;
                        }
                    }
                    */
                    #endregion
                    
                    string caseStatus = string.Empty;
                    //Check for Case status closed : if case status is closed then do not trigger.
                    if (entity.Attributes.Contains("rsa_status"))
                    {
                        caseStatus = ((EntityReference)entity.Attributes["rsa_status"]).Name;
                    }
                    else if (entityPostImage.Attributes.Contains("rsa_status"))
                    {
                        caseStatus = ((EntityReference)entityPostImage.Attributes["rsa_status"]).Name;
                    }

                    if (entity.LogicalName.ToLowerInvariant() != "incident" && caseStatus.ToLower().Contains("closed"))
                        return;

                    //Chandani : 30/11/2022 : To remove Depth Dependencies, creating status records to ABR Tracking entity.
                    //INC2304659: Duplicate Task Creation Issue
                    #region Check if ABRTracking Record exist for Case with Same Status and create ABR Tracking Record if not
                    string fetchQueryABRTracking = "<fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0' top='1'>";
                    fetchQueryABRTracking += "<entity name='rsa_abrtracking'>";
                    fetchQueryABRTracking += "<attribute name='rsa_abrtrackingid'/>";
                    fetchQueryABRTracking += "<attribute name='rsa_name'/>";
                    fetchQueryABRTracking += "<attribute name='createdon'/>";
                    fetchQueryABRTracking += "<attribute name='rsa_abrretrievequery'/>";
                    fetchQueryABRTracking += "<order descending='true' attribute='createdon'/>";
                    fetchQueryABRTracking += "<filter type='and'>";
                    fetchQueryABRTracking += "<condition attribute='rsa_case' operator='eq' value = '" + entity.Id + "'/>";
                    fetchQueryABRTracking += "<condition attribute='rsa_casetriggeraction' value='866760001' operator='eq'/>";
                    //fetchQueryABRTracking += "<condition attribute='rsa_abrretrievequery' value='" + caseStatus + "%' operator='like'/>";
                    fetchQueryABRTracking += "<condition attribute='rsa_carabr' value='866760000' operator='eq'/>";
                    fetchQueryABRTracking += "</filter>";
                    fetchQueryABRTracking += "</entity>";
                    fetchQueryABRTracking += "</fetch>";
                    tracer.Trace("Fetch abrtracking is already having existing status :" + caseStatus);
                    EntityCollection entyCollABRTracking = service.RetrieveMultiple(new FetchExpression(fetchQueryABRTracking));
                    if (entyCollABRTracking.Entities.Count > 0)
                    {
                        tracer.Trace("entyCollABRTracking.Entities.Count: "+ entyCollABRTracking.Entities.Count);
                        string retStatus = Convert.ToString(entyCollABRTracking.Entities[0].Attributes["rsa_abrretrievequery"]);
                        tracer.Trace("entyCollABRTracking retStatus: " + retStatus);
                        if (caseStatus.Equals(retStatus))
                        {
                            tracer.Trace("Return as record is already available in ABRTracking");
                            return;
                        }                        
                    }

                    //Create ABRTracking Record
                    
                    tracer.Trace("Create Record in ABRTracking");
                        Entity enABRTracking = new Entity("rsa_abrtracking");
                        enABRTracking["rsa_case"] = new EntityReference("incident", entity.Id);
                        enABRTracking["rsa_name"] = Convert.ToString(entity.Id);
                        //enABRTracking["rsa_name"] = Convert.ToString(entity.Attributes["name"]);
                        enABRTracking["rsa_casetriggeraction"] = new OptionSetValue(866760001);
                        enABRTracking["rsa_abrretrievequery"] = caseStatus;
                        enABRTracking["rsa_abrtriggeredby"] = new EntityReference("systemuser", context.UserId);
                        enABRTracking["rsa_carabr"] = new OptionSetValue(866760000);
                        service.Create(enABRTracking);
                        tracer.Trace("Record created in ABRTracking");
                    #endregion

                    //ARC:Email to Case creation : Jyoti Bhosale 05/08/2022 ABR ACR change
                    if (entity.Attributes.Contains("rsa_receivingemailbox") && entity.GetAttributeValue<EntityReference>("rsa_receivingemailbox") != null)
                    {
                        casesource = entity.Contains("incidentstagecode") && entity.GetAttributeValue<OptionSetValue>("incidentstagecode") != null ? entity.GetAttributeValue<OptionSetValue>("incidentstagecode").Value : -1;
                        ARCQueueId = ABRLogic.GetQueueIDForARCCases(context, entity, service, tracer);
                        //  objARCOptionsetRoot = ABRLogic.GetARCJSON(context, entity, service, tracer);
                        tracer.Trace("ARCQueueId" + ARCQueueId);
                    }
                    //////////////////////////
                    ///
                    ABRLogic objABRLogic = new ABRLogic();
                    tracer.Trace("Enter the Get ABR template function");
                    Entity ABRTracking = new Entity("rsa_abrtracking");
                    EntityCollection ABRTemplates = ABRLogic.GetABRTemplate(context, entityPostImage, service, tracer, ABRTracking);
                    //string abrTemplateID = ABRLogic.GetABRTemplate(entityPostImage, service, tracer);

                    //// Defect 2098 By Atul Agrawal
                    tracer.Trace("Duplicate ABR removal logic starting");
                    for (int i = 0; i < ABRTemplates.Entities.Count; i++)
                    //foreach (var item in ABRTemplates.Entities)
                    {
                        tracer.Trace("Duplicate ABR record Updated Count ." + ABRTemplates.Entities.Count().ToString());
                        //var enCount = ABRTemplates.Entities.Count(a => a.Attributes["rsa_name"].Equals(item.Attributes["rsa_name"]));
                        var enCount = ABRTemplates.Entities.Count(a => a.Attributes["rsa_name"].Equals(ABRTemplates.Entities[i].Attributes["rsa_name"]));
                        tracer.Trace("After Linq Query to remove duplicate ABR");
                        if (enCount >= 2)
                        {
                            tracer.Trace("Duplicate Found");
                            ABRTemplates.Entities.Remove(ABRTemplates.Entities[i]);
                            tracer.Trace("Duplicate Removed");
                        }
                    }

                    /////

                    foreach (var item in ABRTemplates.Entities)
                    {
                        string abrTemplateID = item.Id.ToString();
                        tracer.Trace("Activity Business Rule Id : {0}", item.Id);
                        // if (!string.IsNullOrEmpty(abrTemplateID))
                        if (!string.IsNullOrEmpty(abrTemplateID))
                        {
                            Guid opportunityId = Guid.Empty;
                            Guid policyId = Guid.Empty;
                            Guid arcQueueID = Guid.Empty;//Jyoti Bhosale for ABR ARC change
                            if (entityPostImage.Contains("rsa_opportunityid") && entityPostImage.GetAttributeValue<EntityReference>("rsa_opportunityid") != null)
                            {
                                EntityReference Opportunity = entityPostImage.GetAttributeValue<EntityReference>("rsa_opportunityid");
                                opportunityId = Opportunity.Id;
                                tracer.Trace("opportunity ID ." + opportunityId);
                            }
                            if (entityPostImage.Contains("rsa_policyid") && entityPostImage.GetAttributeValue<EntityReference>("rsa_policyid") != null)
                            {
                                EntityReference policy = entityPostImage.GetAttributeValue<EntityReference>("rsa_policyid");
                                policyId = policy.Id;
                                tracer.Trace("Policy ID ." + policyId);
                            }
                            //Added By Jyoti Bhosale 1/08/2022 ARC ABR Change(Parameter arcQueueID added)
                            objABRLogic.GetABRActions(service, tracer, entity.Id, Guid.Parse(abrTemplateID), opportunityId, ABRTracking, arcQueueID);
                            // }
                            //fix for defect id 82 : 12 Nov 2020 : Sumegh DHole : Opportunity Id was empty hence it was throwing an error. SME has no opportunity id
                            //Added By Jyoti Bhosale 1/08/2022 ARC ABR Change(Parameter  arcQueueID, objARCOptionsetRoot)
                            objABRLogic.GetABRTasks(context, service, tracer, entityPostImage, Guid.Parse(abrTemplateID), opportunityId, policyId, ABRTracking, arcQueueID, objARCOptionsetRoot,_unsecureString);
                            // }

                        }
                    }
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                CrmPluginHelper.CatchFaultException(ex, this);
            }
            catch (InvalidPluginExecutionException ex)
            {
                CrmPluginHelper.CatchInvalidPluginException(ex);
            }
            catch (Exception ex)
            {
                CrmPluginHelper.CatchGenericException(ex, this);
            }
        }
    }
}
