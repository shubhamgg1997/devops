﻿using System;

namespace RSA.Crm.Base
{
    public class NotFoundException : Exception
    {
        private const string MessageFormat1 = "Item {0} with id {1} doesn't exist.";
        private const string MessageFormat2 = "Item {0} doesn't exist.";

        public NotFoundException(string itemType, string id)
            : base(FormatMessage1(itemType, id))
        {
        }

        public NotFoundException(string itemType, Guid id)
            : base(FormatMessage1(itemType, id.ToString()))
        {
        }

        public NotFoundException(string itemType)
            : base(FormatMessage2(itemType))
        {
        }

        private static string FormatMessage1(string itemType, string id)
        {
            return string.Format(MessageFormat1, itemType, id);
        }

        private static string FormatMessage2(string itemType)
        {
            return string.Format(MessageFormat2, itemType);
        }
    }
}
