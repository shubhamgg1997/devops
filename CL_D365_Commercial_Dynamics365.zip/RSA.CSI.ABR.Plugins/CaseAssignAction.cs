﻿using RSA.Crm.Plugins;
using Microsoft.Xrm.Sdk;
using System;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using RSA.CSI.Plugins.ABR.Logic;
using RSA.CSI.Plugins.ABR;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.IO;
using System.Net;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Linq;

namespace RSA.CSI.Plugins.CAR
{
    public class CaseAssignAction : IPlugin
    {
        public Guid COBId = Guid.Empty;

        private readonly string _unsecureString;

        public CaseAssignAction(string unsecureString)
        {
            _unsecureString = unsecureString;
        }
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService tracer = null;
            IPluginExecutionContext context = null;
            IOrganizationService service = null;
            //Added By Jyoti Bhosale 1/08/2022 ARC ABR Change
            ARCOptionsetRoot objARCOptionsetRoot = new ARCOptionsetRoot();
            //

            CrmPluginHelper.Initialise(serviceProvider, ref context, ref service, ref tracer, false);
            if (context.Depth > 1)
            {
                return;
            }
            //Pooja Raje : Assign Case to queue on button click
            string caseId = string.Empty;
            Entity ABRTracking = new Entity("rsa_abrtracking");
            if (context.InputParameters.Contains("caseId") && context.InputParameters["caseId"] != null)
            {
                try
                {
                    Entity caseEntity;
                    caseId = context.InputParameters["caseId"].ToString();
                    //Check for Action 
                    if (context.MessageName == "rsa_CaseAssignAction")
                    {
                        //Check any of the Fields has been changed

                        tracer.Trace("CaseAllocationRuleAddCasetoQueue- In action Message");
                        //Use Pre-Image
                        caseEntity = service.Retrieve("incident", new Guid(caseId), new ColumnSet("rsa_status", "ownerid", "caseorigincode", "rsa_opportunityorigin", "rsa_keysmebroker", "rsa_dealscase", "rsa_dealcheck", "rsa_dealbroker", "rsa_customertype", "rsa_customername", "rsa_customerrsa", "rsa_casereceiveddate", "rsa_casereasonrsa", "rsa_brokerprimaryreference", "rsa_applyr90conditions", "rsa_brokercommitmentimage", "rsa_accountnumber", "accountid", "rsa_account", "rsa_branchaccount", "rsa_distributioncategory", "rsa_scheme", "rsa_classofbusinesssme",
                            "rsa_classofbusiness", "rsa_classofbusinessphoneenqid", "rsa_opportunityid", "rsa_policyid", "rsa_casetype", "rsa_basepremiumrsa", "rsa_cobextranet", "rsa_clientname", "createdon", "rsa_rsapolicyfulfilmentactivities", "rsa_productphoneenqid", "productid", "rsa_product_w", "rsa_productlivechat", "rsa_productsmev2", "rsa_productholder", "rsa_promise", "rsa_promisebroker", "rsa_rsarecordtype", "rsa_renewalreviewtype", "statecode", "rsa_transaction", "rsa_traded", "rsa_transactiontypeid", "rsa_originatingcase"));

                    }
                    else
                    {
                        return;
                    }

                    ////Sumegh Dhole : 10 Oct :Defect for agency request case type record not getting saved as rsa_Account is not applicable for that case type 

                    EntityReference broker = null;
                    EntityReference objCaseRecordType = null;
                    Guid brokerId = Guid.Empty;
                    if (caseEntity.Attributes.Contains("rsa_account"))
                    {
                        broker = caseEntity.GetAttributeValue<EntityReference>("rsa_account");
                    }
                    if (broker != null)
                        brokerId = broker.Id;

                    string branchAccount = string.Empty, distributionCategory = string.Empty;//premiumCode = string.Empty;
                    int caseRecordType = -1;
                    string caseTypeName = string.Empty;
                    decimal basePremium = 0.0M;
                    string classOfBusinessName = string.Empty;
                    Guid classOfBusinessId = Guid.Empty;
                    EntityReference queue = new EntityReference("queue");
                    bool scheme = false;
                    string product = string.Empty;
                   
                    EntityReference encaseStatus = caseEntity.Attributes.Contains("rsa_status") ? caseEntity.GetAttributeValue<EntityReference>("rsa_status") : null;
                    if (encaseStatus != null)
                        tracer.Trace("Case Status" + encaseStatus.Name);
                    if (caseEntity.Attributes.Contains("rsa_distributioncategory"))
                        distributionCategory = caseEntity.GetAttributeValue<string>("rsa_distributioncategory");

                    if (caseEntity.Attributes.Contains("rsa_branchaccount"))
                    {
                        branchAccount = caseEntity.GetAttributeValue<string>("rsa_branchaccount");
                    }
                    else if (string.IsNullOrWhiteSpace(branchAccount) || string.IsNullOrWhiteSpace(distributionCategory))
                    {
                        EntityReference accountReference = caseEntity.Attributes.Contains("rsa_account") ? (EntityReference)caseEntity.Attributes["rsa_account"] : null;
                        if (accountReference != null)
                        {
                            tracer.Trace("Start retrieving data from account entity " + accountReference.Name);
                            Entity accountInfo = service.Retrieve(accountReference.LogicalName, accountReference.Id, new ColumnSet(new string[] { "rsa_branch", "rsa_distributioncategoryagency" }));
                            int branchValue = accountInfo.Attributes.Contains("rsa_branch") ? ((OptionSetValue)accountInfo.Attributes["rsa_branch"]).Value : 0;
                            //Wave 2 issue: Blank popup when branch does not contain data: branchValue!=0 condition added: 29/08/2022: Samiksha Dhakde
                            tracer.Trace("Branchvalue is : " + branchValue);
                            if (branchValue == 0)
                            {
                                //context.OutputParameters["IsQueueAssign"] = "false";
                                //Commenetd below code as throwing blank popup
                                //return;
                            }
                            //Fix for 2193 : SUmegh Dhole : 04 Oct 2021
                            AccountBranchRoot accountBranchRoot = getBranchJsonValues("BranchAccountJSON", tracer, service);
                            AccountBranch brMap = new AccountBranch();
                            tracer.Trace("retrived accountBranchRoot branchMap branch");
                            if (accountBranchRoot != null && branchValue != 0)
                            {
                                tracer.Trace("accountBranchRoot is not null");
                                if (accountBranchRoot.AccountBranch != null && accountBranchRoot.AccountBranch.Count > 0)
                                {
                                    brMap = (AccountBranch)accountBranchRoot.AccountBranch.Find(a => a.Branchvalue.Equals(branchValue));
                                    tracer.Trace("accountBranchRoot branchMap branch" + brMap.BranchName);
                                    branchAccount = Convert.ToString(brMap.BranchName);
                                }
                            }

                            //switch (branchValue)
                            //{
                            //    case 866760000:
                            //        branchAccount = "Belfast";
                            //        break;
                            //    case 866760001:
                            //        branchAccount = "Birmingham";
                            //        break;
                            //    case 866760002:
                            //        branchAccount = "Bristol";
                            //        break;
                            //    case 866760003:
                            //        branchAccount = "Cardiff";
                            //        break;
                            //    case 866760004:
                            //        branchAccount = "Edinburgh";
                            //        break;
                            //    case 866760005:
                            //        branchAccount = "Glasgow";
                            //        break;
                            //    case 866760006:
                            //        branchAccount = "Horsham";
                            //        break;
                            //    case 866760007:
                            //        branchAccount = "Ipswich";
                            //        break;
                            //    case 866760008:
                            //        branchAccount = "Leeds";
                            //        break;
                            //    case 866760009:
                            //        branchAccount = "Leicester";
                            //        break;
                            //    case 866760010:
                            //        branchAccount = "London";
                            //        break;
                            //    case 866760011:
                            //        branchAccount = "Manchester";
                            //        break;
                            //    case 866760012:
                            //        branchAccount = "Real Estate";
                            //        break;
                            //    case 866760013:
                            //        branchAccount = "Redhill";
                            //        break;
                            //    case 866760014:
                            //        branchAccount = "Blocks of Flats";
                            //        break;
                            //    default:
                            //        break;
                            //}

                            distributionCategory = accountInfo.Attributes.Contains("rsa_distributioncategoryagency") ? Convert.ToString(accountInfo.Attributes["rsa_distributioncategoryagency"]) : string.Empty; ;
                        }
                    }

                    tracer.Trace("branchAccount " + branchAccount);
                    tracer.Trace("distributionCategory " + distributionCategory);

                    if (caseEntity.Attributes.Contains("rsa_scheme"))
                        scheme = caseEntity.GetAttributeValue<bool>("rsa_scheme");

                    tracer.Trace("schemeName " + scheme);
                    EntityReference policyId = new EntityReference();

                    //Sumegh Dhole 13 Oct 2020 : Add the check for the class of business data types
                    if (caseEntity.Attributes.Contains("rsa_classofbusinessphoneenqid"))
                    {
                        classOfBusinessId = ((EntityReference)caseEntity.Attributes["rsa_classofbusinessphoneenqid"]).Id;
                        classOfBusinessName = ((EntityReference)caseEntity.Attributes["rsa_classofbusinessphoneenqid"]).Name;
                        tracer.Trace("Class of Business Name from Case0 " + classOfBusinessName);
                        //2444
                        COBId = ((EntityReference)caseEntity.Attributes["rsa_classofbusinessphoneenqid"]).Id;
                        //Modified on 18-08-2022 ;By : Nida/Samiksha ; Des:Regression Issue: COB Null check
                        if (classOfBusinessName == null)
                        {
                            Entity eClassofbusiness = service.Retrieve("rsa_classofbusiness", COBId, new ColumnSet("rsa_name"));
                            classOfBusinessName = eClassofbusiness.Contains("rsa_name") ? eClassofbusiness.GetAttributeValue<string>("rsa_name").ToString() : null;

                        }
                        tracer.Trace("COBId" + COBId);

                    }
                    else if (caseEntity.Attributes.Contains("rsa_opportunityid"))

                    {

                        tracer.Trace("Get the class name from opportunity");

                        EntityReference opportunityId = caseEntity.Attributes.Contains("rsa_opportunityid") ? (EntityReference)caseEntity.Attributes["rsa_opportunityid"] : null;

                        if (opportunityId != null)

                        {

                            string lineofbusiness = string.Empty;

                            Guid lineofbusinessId = Guid.Empty;

                            string pl = string.Empty;

                            Guid plid = Guid.Empty;

                            tracer.Trace("classOfBusinessName 4");

                            Entity Opportunity = service.Retrieve(opportunityId.LogicalName, opportunityId.Id, new ColumnSet(new string[] { "rsa_classofbusiness", "rsa_lineofbusiness", "rsa_pandlid", "rsa_classofbusiness", "rsa_productid" }));

                            classOfBusinessName = Opportunity.Attributes.Contains("rsa_classofbusiness") ? ((EntityReference)Opportunity.Attributes["rsa_classofbusiness"]).Name : string.Empty;

                            tracer.Trace("Class of Business Name from optty " + classOfBusinessName);



                            //2444



                            lineofbusiness = Opportunity.Attributes.Contains("rsa_lineofbusiness") ? ((EntityReference)Opportunity.Attributes["rsa_lineofbusiness"]).Name : string.Empty;

                            tracer.Trace("Line of Business Name from optty " + lineofbusiness);



                            lineofbusinessId = Opportunity.Attributes.Contains("rsa_lineofbusiness") ? ((EntityReference)Opportunity.Attributes["rsa_lineofbusiness"]).Id : Guid.Empty;



                            pl = Opportunity.Attributes.Contains("rsa_pandlid") ? ((EntityReference)Opportunity.Attributes["rsa_pandlid"]).Name : string.Empty;

                            tracer.Trace("P&L Name from optty " + pl);



                            plid = Opportunity.Attributes.Contains("rsa_pandlid") ? ((EntityReference)Opportunity.Attributes["rsa_pandlid"]).Id : Guid.Empty;



                            COBId = Opportunity.Attributes.Contains("rsa_classofbusiness") ? ((EntityReference)Opportunity.Attributes["rsa_classofbusiness"]).Id : Guid.Empty;

                            tracer.Trace("COBId" + COBId);

                            if (classOfBusinessName != string.Empty)

                            {

                                //Updated by Jyoti Bhosale for 24444

                                // fetch COB based on COBName +LOB + P&L combination : If found then override COBID value else continue

                                string fetchCOB = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>

                                <entity name='rsa_classofbusiness'>
                                <attribute name='rsa_name' />
                                <attribute name='createdon' />
                                <attribute name='rsa_pl' />
                                <attribute name='rsa_description' />
                                <attribute name='rsa_lineofbusiness' />
                                <attribute name='rsa_classofbusinessid' />
                                <order attribute='rsa_name' descending='false' />
                                <filter type='and'>
                                <condition attribute='rsa_lineofbusiness' operator='eq' uitype='rsa_lineofbusiness' value='{0}' />
                                <condition attribute='rsa_name' operator='eq' value='{2}' />
                                </filter>
                                <link-entity name='rsa_pl' from='rsa_plid' to='rsa_pl' link-type='inner' alias='ac'>
                                <filter type='and'>
                                <condition attribute='rsa_name' operator='eq' value='{1}' />
                                </filter>
                                </link-entity>
                                </entity>
                                </fetch>";


                                //modified : 18 oct 22 ; Nida ; Defect : TFS 530 : Invalid Xml for d&O cob name
                                //modified : 19 oct 22 ; Shravani ; Defect : TFS 666 : Invalid Xml for P&L
                                EntityCollection OpptyentityCollection = service.RetrieveMultiple(new FetchExpression(String.Format(fetchCOB, lineofbusinessId, WebUtility.HtmlEncode(pl), WebUtility.HtmlEncode(classOfBusinessName))));

                                if (OpptyentityCollection.Entities.Count > 0)

                                {

                                    foreach (var cob in OpptyentityCollection.Entities)

                                    {

                                        COBId = cob.Id;

                                        //COBID to be override

                                        break;

                                    }

                                }

                            }

                            product = Opportunity.Attributes.Contains("rsa_productid") ? ((EntityReference)Opportunity.Attributes["rsa_productid"]).Name : string.Empty;
                            tracer.Trace("product name from opportunity:" + product);
                        }

                    }
                    else if (caseEntity.Attributes.Contains("rsa_policyid"))

                    {

                        tracer.Trace("Get the class name from policy");

                        policyId = caseEntity.Attributes.Contains("rsa_policyid") ? (EntityReference)caseEntity.Attributes["rsa_policyid"] : null;

                        if (policyId != null)

                        {

                            string Policy = string.Empty;

                            Guid lineofbusinessId = Guid.Empty;

                            string pl = string.Empty;

                            Guid plid = Guid.Empty;

                            Guid policytype = Guid.Empty;                            

                            Entity PolicyData = service.Retrieve(policyId.LogicalName, policyId.Id, new ColumnSet(new string[] { "rsa_classofbusiness", "rsa_plcode", "rsa_name", "rsa_policytype", "rsa_productid" }));

                            classOfBusinessName = PolicyData.Attributes.Contains("rsa_classofbusiness") ? ((EntityReference)PolicyData.Attributes["rsa_classofbusiness"]).Name : string.Empty;

                            tracer.Trace("Class of Business Name from policy " + classOfBusinessName);

                            //2444

                            Policy = PolicyData.Attributes.Contains("rsa_policytype") ? ((EntityReference)PolicyData.Attributes["rsa_policytype"]).Name : string.Empty;

                            tracer.Trace("Policy Name " + Policy);



                            policytype = PolicyData.Attributes.Contains("rsa_policytype") ? ((EntityReference)PolicyData.Attributes["rsa_policytype"]).Id : Guid.Empty;



                            pl = PolicyData.Attributes.Contains("rsa_plcode") ? ((EntityReference)PolicyData.Attributes["rsa_plcode"]).Name : string.Empty;

                            tracer.Trace("P&L Name from optty " + pl);

                            plid = PolicyData.Attributes.Contains("rsa_plcode") ? ((EntityReference)PolicyData.Attributes["rsa_plcode"]).Id : Guid.Empty;

                            
                            product = PolicyData.Attributes.Contains("rsa_productid") ? ((EntityReference)PolicyData.Attributes["rsa_productid"]).Name : string.Empty;

                            tracer.Trace("Product name from policy " + product);


                            COBId = PolicyData.Attributes.Contains("rsa_classofbusiness") ? ((EntityReference)PolicyData.Attributes["rsa_classofbusiness"]).Id : Guid.Empty;

                            tracer.Trace("COBId" + COBId);

                            if (classOfBusinessName != string.Empty)

                            {

                                // fetch COB based on COBName +LOB + P&L combination : If found then override COBID value else continue

                                string fetchCOBfromPolicy = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>

                                <entity name='rsa_classofbusiness'>

                                <attribute name='rsa_name' />

                                <attribute name='createdon' />

                                <attribute name='rsa_pl' />

                                <attribute name='rsa_description' />

                                <attribute name='rsa_lineofbusiness' />

                                <attribute name='rsa_classofbusinessid' />

                                <order attribute='rsa_name' descending='false' />

                                <filter type='and'>

                                <condition attribute='rsa_policytype' operator='eq' uitype='rsa_policytype' value='{0}' />

                                <condition attribute='rsa_name' operator='eq' value='{2}' />

                                </filter>

                                <link-entity name='rsa_pl' from='rsa_plid' to='rsa_pl' link-type='inner' alias='ac'>

                                <filter type='and'>

                                <condition attribute='rsa_name' operator='eq' value='{1}' />

                                </filter>

                                </link-entity>

                                </entity>

                                </fetch>";
                                //modified : 18 oct 22 ; Nida ; Defect : TFS 530 : Invalid Xml for d&O cob name
                                //modified : 19 oct 22 ; Shravani ; Defect : TFS 666 : Invalid Xml for P&L
                                EntityCollection PolicyCollection = service.RetrieveMultiple(new FetchExpression(String.Format(fetchCOBfromPolicy, policytype, WebUtility.HtmlEncode(pl), WebUtility.HtmlEncode(classOfBusinessName))));

                                if (PolicyCollection.Entities.Count > 0)

                                {

                                    foreach (var cob in PolicyCollection.Entities)

                                    {

                                        COBId = cob.Id;

                                        tracer.Trace("COBId" + COBId);

                                        //COBID to be override

                                        break;

                                    }

                                }



                            }

                        }
                    }
                    else if (caseEntity.Attributes.Contains("rsa_classofbusiness") && !caseEntity.Attributes.Contains("rsa_originatingcase"))
                    {
                        classOfBusinessName = Convert.ToString(caseEntity.Attributes["rsa_classofbusiness"]);
                        tracer.Trace("Class of Business Name from Case1 " + classOfBusinessName);

                    }
                    else if (caseEntity.Attributes.Contains("rsa_classofbusinesssme") && !caseEntity.Attributes.Contains("rsa_originatingcase"))
                    {
                        classOfBusinessName = Convert.ToString(caseEntity.Attributes["rsa_classofbusinesssme"]);
                        tracer.Trace("Class of Business Name from Case2 " + classOfBusinessName);

                    }

                    tracer.Trace("Class of Business Name " + classOfBusinessName);
                    //Chandani: 25/01/2023: Add code to set flag
                    string strClassofBusinessNew = string.Empty;
                    string branchtoSkipCAR = string.Empty;
                    #region check whether Branch is old or new
                    bool isCOBOld = true;
                    Entity CLBranchCARS = GetCustomLabel(service, tracer, "CL_Branch_CARS_OLD");
                    if (CLBranchCARS != null)
                    {
                        if (CLBranchCARS.Attributes.Contains("rsa_dependentoptionsetjson"))
                        {
                            branchtoSkipCAR = CLBranchCARS.Attributes["rsa_dependentoptionsetjson"].ToString();
                        }
                        string strBranchOld = string.Empty;
                        if (CLBranchCARS.Attributes.Contains("rsa_values"))
                        {
                            strBranchOld = CLBranchCARS.Attributes["rsa_values"].ToString();
                        }

                        tracer.Trace("Get Custom Label CL_Branch_CARS_OLD " + strBranchOld);
                        if (!string.IsNullOrEmpty(strBranchOld) && !strBranchOld.ToLower().Contains(branchAccount.ToLower()))
                        {
                            Entity CLClassofBusinessNew = GetCustomLabel(service, tracer, "CL_COB_CARS_NEW");
                            if (CLClassofBusinessNew != null)
                            {

                                if (CLClassofBusinessNew.Attributes.Contains("rsa_values"))
                                {
                                    strClassofBusinessNew = CLClassofBusinessNew.Attributes["rsa_values"].ToString();
                                }

                                tracer.Trace("Get Custom Label CL_COB_CARS_NEW " + strClassofBusinessNew);
                                if (!string.IsNullOrEmpty(strClassofBusinessNew) && strClassofBusinessNew.ToLower().Contains(classOfBusinessName.ToLower()))
                                {
                                    tracer.Trace("Inside New Branch: isCOBOld: False");
                                    isCOBOld = false;
                                }
                                else
                                {
                                    isCOBOld = true;
                                }
                            }

                        }
                        else if (string.IsNullOrEmpty(strBranchOld))
                        {
                            tracer.Trace("Inside strBranchOld empty: isCOBOld: False");
                            isCOBOld = false;
                        }
                        else if (branchAccount == string.Empty)
                        {
                            tracer.Trace("Inside Broker Branch is blank : isCOBOld: False");
                            isCOBOld = false;
                        }
                        else
                        {
                            tracer.Trace("Inside Else : isCOBOld: true");
                            isCOBOld = true;
                        }
                    }
                    #endregion

                    if (caseEntity.Attributes.Contains("rsa_casetype"))
                    {
                        objCaseRecordType = caseEntity.Contains("rsa_casetype") ? caseEntity.GetAttributeValue<EntityReference>("rsa_casetype") : null;
                        if (objCaseRecordType != null)
                        {
                            var recordtypeLookup = service.Retrieve(objCaseRecordType.LogicalName, objCaseRecordType.Id, new ColumnSet("rsa_casetypecode", "rsa_casetype"));
                            caseRecordType = recordtypeLookup.Contains("rsa_casetypecode") ? recordtypeLookup.GetAttributeValue<int>("rsa_casetypecode") : -1;
                            caseTypeName = recordtypeLookup.Contains("rsa_casetype") ? recordtypeLookup.GetAttributeValue<string>("rsa_casetype").ToLower() : null;
                        }
                    }
                    tracer.Trace("caseRecordType " + caseRecordType);

                    if (caseEntity.Attributes.Contains("rsa_basepremiumrsa"))
                    {
                        basePremium = Convert.ToDecimal(caseEntity.GetAttributeValue<decimal>("rsa_basepremiumrsa"));
                    }
                    tracer.Trace("basePremium " + basePremium);
                    if (basePremium == 0.00M && caseEntity.Attributes.Contains("rsa_policyid"))
                    {
                        //22/02/2023: Bug: 1819
                        var PolicyGiud = caseEntity.Attributes.Contains("rsa_policyid") ? (EntityReference)caseEntity.Attributes["rsa_policyid"] : null;
                        Entity PolicyData = service.Retrieve(PolicyGiud.LogicalName, PolicyGiud.Id, new ColumnSet(new string[] { "rsa_premium" }));
                        basePremium = PolicyData.Attributes.Contains("rsa_premium") ? Convert.ToDecimal(PolicyData.GetAttributeValue<Money>("rsa_premium").Value) : 0.00M;

                        //Commented below code to fix 1819
                        /*
                        string FetchXML = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='rsa_policy'>
                                    <attribute name='rsa_policyid' />
                                    <attribute name='rsa_name' />
                                    <attribute name='rsa_premium' />
                                    <order attribute='rsa_name' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='rsa_policyid' operator='eq' uiname='0000847A7EC4' uitype='rsa_policy' value='" + policyId.Id + @"' />
                                    </filter>
                                  </entity>
                                </fetch>";
                        EntityCollection policyPremiumColl = service.RetrieveMultiple(new FetchExpression(FetchXML));

                        if (policyPremiumColl.Entities.Count > 0 && policyPremiumColl.Entities[0].Contains("rsa_premium"))
                        {
                            basePremium = Convert.ToDecimal(policyPremiumColl.Entities[0].GetAttributeValue<Money>("rsa_premium"));
                        }
                        */
                    }
                    //Modified On 03-08-2022 ;By : Nida ; Des: CR2642 handles Standard and BPW scenario in 1 logic GetPremiumRange()
                    // removed commented


                    tracer.Trace("CaseAllocationRuleAddCasetoQueue- QueryExpression");
                    //Query Expression to find matching record of Case Allocation Rule with Case
                    QueryExpression query = new QueryExpression("rsa_caseallocationrules");
                    query.ColumnSet = new ColumnSet("rsa_queue", "rsa_name");
                    query.NoLock = true;

                    FilterExpression filter = new FilterExpression(LogicalOperator.And);
                    //if (!string.IsNullOrEmpty(branchAccount))
                    //    filter.Conditions.Add(new ConditionExpression("rsa_branch", ConditionOperator.Equal, branchAccount));
                    //tracer.Trace("branchAccounte " + branchAccount);

                    //if (!string.IsNullOrEmpty(distributionCategory))
                    //    filter.Conditions.Add(new ConditionExpression("rsa_distributioncategory", ConditionOperator.Equal, distributionCategory));
                    //tracer.Trace("distributionCategory " + distributionCategory);
                    //sumegh dhole : 11 Oct 2021 :
                    //check if the branch has data else handle it for defect id 2193
                    //Defect: 1718 Added code to consider blank branch in CAR

                    string[] strBranchCode = { "Birmingham", "Bristol", "Cardiff", "Edinburgh", "Glasgow", "Horsham", "Ipswich", "Leeds", "Leicester", "London", "Manchester", "Redhill" };


                    tracer.Trace("Started with JSONCode ");
                    var branchOptionsetRoot = new BranchJSONRoot();
                    var ms = new MemoryStream(Encoding.UTF8.GetBytes(branchtoSkipCAR));
                    tracer.Trace("branchtoSkipCAR " + branchtoSkipCAR);
                    try
                    {
                        tracer.Trace("in Try block ");
                        var ser = new DataContractJsonSerializer(branchOptionsetRoot.GetType());
                        tracer.Trace("in Try block set ser");
                        branchOptionsetRoot = ser.ReadObject(ms) as BranchJSONRoot;
                        tracer.Trace("in Try block set branchOptionsetRoot");
                    }
                    catch (Exception ex)
                    {
                        throw new InvalidPluginExecutionException(ex.Message);
                    }
                    finally
                    {
                        ms.Close();
                    }
                    tracer.Trace("Set branchMap");
                    BranchJSON branchMap = new BranchJSON();
                    bool branchEmpty = false;
                    tracer.Trace("After Set branchMap");
                    foreach (var item in branchOptionsetRoot.BranchJSON)
                    {
                        if (item.COB.ToLower().Contains(classOfBusinessName.ToLower()) && item.RecordType.ToLower().Contains(caseTypeName.ToLower()))
                        {
                            branchEmpty = true;
                            //TFS 2048: Check if branch is Engineering and consider as new CAR
                            isCOBOld = false;
                        }
                    }
                    //if (branchEmpty == true && isCOBOld == false)
                    if (branchEmpty == true && !((caseTypeName.ToLower().Contains("renewal") || caseTypeName.ToLower().Contains("query")
                                || caseTypeName.ToLower().Contains("mid-term adjustment")) && classOfBusinessName.ToLower().Contains("blocks of flats")))
                    {
                        filter.Conditions.Add(new ConditionExpression("rsa_branch", ConditionOperator.Null));
                        tracer.Trace("branchAccount skipped as classOfBusinessName" + classOfBusinessName + " caseTypeName " + caseTypeName);
                    }
                    else if (!string.IsNullOrEmpty(branchAccount) && caseTypeName != "bes referral" && !((caseTypeName.ToLower().Contains("renewal") || caseTypeName.ToLower().Contains("query")
                                || caseTypeName.ToLower().Contains("mid-term adjustment")) && classOfBusinessName.ToLower().Contains("blocks of flats")))
                    {
                        tracer.Trace("branchAccount " + branchAccount);
                        if (!string.IsNullOrEmpty(branchAccount) && caseTypeName.ToLower().Contains("mid-term adjustment") &&
                            classOfBusinessName.ToLower().Contains("motor fleet") && basePremium <= 20000)
                        {
                            filter.Conditions.Add(new ConditionExpression("rsa_branch", ConditionOperator.Null)); //1124
                        }
                        else if (!string.IsNullOrEmpty(branchAccount) && caseTypeName.ToLower().Contains("mid-term adjustment") &&
                            classOfBusinessName.ToLower().Contains("motor fleet") && basePremium > 20000 && !strBranchCode.Contains(branchAccount))
                        {
                            filter.Conditions.Add(new ConditionExpression("rsa_branch", ConditionOperator.Null)); //1124
                        }
                        else
                        {
                            filter.Conditions.Add(new ConditionExpression("rsa_branch", ConditionOperator.Equal, branchAccount));
                        }
                    }
                    else if (!((caseTypeName.ToLower().Contains("renewal") || caseTypeName.ToLower().Contains("query")
                                || caseTypeName.ToLower().Contains("mid-term adjustment")) && classOfBusinessName.ToLower().Contains("blocks of flats")))
                    {
                        filter.Conditions.Add(new ConditionExpression("rsa_branch", ConditionOperator.Null));
                        tracer.Trace("branchAccount does not contain data " + branchAccount);
                    }
                    //sumegh dhole : 11 Oct 2021 : 
                    //check if the branch has data else handle it for defect id 2193
                    //Chandani: 25/01/2023: To handle old Branch CARs
                    if (isCOBOld == true)
                    {
                        if (!string.IsNullOrEmpty(distributionCategory))
                        {
                            filter.Conditions.Add(new ConditionExpression("rsa_distributioncategory", ConditionOperator.Equal, distributionCategory));
                            tracer.Trace("distributionCategory " + distributionCategory);
                        }
                        else
                        {
                            filter.Conditions.Add(new ConditionExpression("rsa_distributioncategory", ConditionOperator.Null));
                            tracer.Trace("distributionCategory does not contain data " + distributionCategory);
                        }
                    }

                    //Modified On 04-08-2022 ;By : Nida ; Des: CR2642 
                    //Modified on 12-08-2022 ;By : Nida ; Des: CR2642- Bug314
                    //Modified on 17-08-2022 ;By : Nida ; Des: CR2642- Bug317
                    //Modified on 14-10-2022 ;By : Nida ; Des: issue 2444 and 2642
                    int isBpw = 0;
                    bool isBpwyes = false;

                    tracer.Trace("isBpw" + isBpw);
                    PremiumRange range = GetPremiumRange(service, tracer, basePremium, classOfBusinessName, isBpwyes, caseTypeName, isCOBOld, strClassofBusinessNew);
                    Entity CLBPW = GetCustomLabel(service, tracer, "CL_BPW_CARS_NEW");
                    string BPWString = string.Empty;
                    bool isBPWApplicable = false;
                    if (CLBPW != null)
                    {
                        if (CLBPW.Attributes.Contains("rsa_dependentoptionsetjson"))
                        {
                            BPWString = CLBPW.Attributes["rsa_dependentoptionsetjson"].ToString();
                            var isBPWRoot = new BPWJsonRoot();
                            var msBPW = new MemoryStream(Encoding.UTF8.GetBytes(BPWString));
                            tracer.Trace("BPWString " + BPWString);
                            try
                            {
                                tracer.Trace("in Try block ");
                                var ser = new DataContractJsonSerializer(isBPWRoot.GetType());
                                tracer.Trace("in Try block set ser");
                                isBPWRoot = ser.ReadObject(msBPW) as BPWJsonRoot;
                                tracer.Trace("in Try block set isBPWRoot");
                            }
                            catch (Exception ex)
                            {
                                throw new InvalidPluginExecutionException(ex.Message);
                            }
                            finally
                            {
                                msBPW.Close();
                            }
                            tracer.Trace("Set BPWMap");
                            BPWJSON BPWMap = new BPWJSON();
                            tracer.Trace("After Set BPWMap");
                            foreach (var item in isBPWRoot.BPWJSON)
                            {
                                tracer.Trace("ForEach Loop from CL: Classof Business:" + item.COB.ToLower() + "PremiumValue:" + item.PremiumValue);
                                tracer.Trace("ForEach Loop from Case: Classof Business:" + classOfBusinessName + "PremiumValue:" + range.PremiumRangeCode);
                                tracer.Trace("Int comparision:" + item.PremiumValue.Equals(range.PremiumRangeCode));
                                tracer.Trace("classOfBusinessName comparision:" + item.COB.ToLower().Contains(classOfBusinessName.ToLower()));
                                if (item.COB.ToLower().Contains(classOfBusinessName.ToLower()) && item.PremiumValue.ToLower().Equals(range.PremiumRangeCode.ToLower()))
                                {
                                    isBPWApplicable = true;
                                    tracer.Trace("isBPWApplicable :" + isBPWApplicable);
                                }
                            }
                        }
                    }
                    if (caseTypeName.ToLower().Contains("bes referral"))
                    {
                        filter.Conditions.Add(new ConditionExpression("rsa_policywording", ConditionOperator.Null));
                        filter.Conditions.Add(new ConditionExpression("rsa_premiumcode", ConditionOperator.Null));
                    }
                    else
                    {
                        if (isCOBOld == false)
                        {
                            if (product.ToLower().Contains("professional insured select"))
                            {
                                tracer.Trace("scheme team queue");
                                filter.Conditions.Clear();
                                filter.Conditions.Add(new ConditionExpression("rsa_branch", ConditionOperator.Null));
                                filter.Conditions.Add(new ConditionExpression("rsa_policywording", ConditionOperator.Null));
                                filter.Conditions.Add(new ConditionExpression("rsa_premiumcode", ConditionOperator.Null));
                            }
                            else if (isBPWApplicable == true)
                            {
                                tracer.Trace("isBPWapplicable true");
                               isBpw = GetBPWFlag(service, tracer, brokerId);
                                //if (isBpw != 0)
                                //{
                                //    isBpwyes = true;
                                //    filter.Conditions.Add(new ConditionExpression("rsa_policywording", ConditionOperator.Equal, isBpw));

                                //    tracer.Trace("rsa_policywording added " + isBpw);
                                //}
                                //else
                                //{
                                //    filter.Conditions.Add(new ConditionExpression("rsa_policywording", ConditionOperator.Null));
                                //    tracer.Trace("rsa_policywording not added " + isBpw);
                                //}
                                filter.Conditions.Add(new ConditionExpression("rsa_premiumcode", ConditionOperator.Equal, range.PremiumRangeCode));
                            }
                            else if (branchEmpty == true && !classOfBusinessName.ToLower().Contains("blocks of flats"))
                            {
                                tracer.Trace("rsa_policywording and rsa_premiumcode condition skipped as BranchEmpty condition true");
                                filter.Conditions.Add(new ConditionExpression("rsa_policywording", ConditionOperator.Null));
                                filter.Conditions.Add(new ConditionExpression("rsa_premiumcode", ConditionOperator.Null));
                            }
                            else if (caseTypeName.ToLower().Contains("new business") || classOfBusinessName.ToLower().Contains("profin"))
                            {
                                tracer.Trace("rsa_policywording and rsa_premiumcode condition skipped as Case Type New Business");
                                filter.Conditions.Add(new ConditionExpression("rsa_policywording", ConditionOperator.Null));
                                filter.Conditions.Add(new ConditionExpression("rsa_premiumcode", ConditionOperator.Null));
                            }
                            //Tfs 2787
                            else if (caseTypeName.ToLower().Contains("renewal") && branchAccount.ToLower().Contains("iom"))
                            {
                                tracer.Trace("rsa_policywording and rsa_premiumcode condition skipped as Case Type Renewal");
                                filter.Conditions.Add(new ConditionExpression("rsa_policywording", ConditionOperator.Null));
                                filter.Conditions.Add(new ConditionExpression("rsa_premiumcode", ConditionOperator.Null));
                            }
                            else if ((caseTypeName.ToLower().Contains("renewal") || caseTypeName.ToLower().Contains("query")
                                || caseTypeName.ToLower().Contains("mid-term adjustment")) && classOfBusinessName.ToLower().Contains("blocks of flats") && string.IsNullOrEmpty(branchAccount))
                            {
                                tracer.Trace("when branch code null");
                                filter.Conditions.Add(new ConditionExpression("rsa_policywording", ConditionOperator.Null));
                                filter.Conditions.Add(new ConditionExpression("rsa_premiumcode", ConditionOperator.Null));
                                filter.Conditions.Add(new ConditionExpression("rsa_branch", ConditionOperator.Null));
                            }
                            else if ((caseTypeName.ToLower().Contains("renewal") || caseTypeName.ToLower().Contains("query")
                              || caseTypeName.ToLower().Contains("mid-term adjustment")) && classOfBusinessName.ToLower().Contains("blocks of flats") && !strBranchCode.Contains(branchAccount))
                            {
                                tracer.Trace("When brach code does not conains in given array");
                                filter.Conditions.Add(new ConditionExpression("rsa_policywording", ConditionOperator.Null));
                                filter.Conditions.Add(new ConditionExpression("rsa_premiumcode", ConditionOperator.Null));
                                filter.Conditions.Add(new ConditionExpression("rsa_branch", ConditionOperator.Null));
                            }
                            else if ((caseTypeName.ToLower().Contains("renewal") || caseTypeName.ToLower().Contains("query")
                                || caseTypeName.ToLower().Contains("mid-term adjustment")) && classOfBusinessName.ToLower().Contains("blocks of flats") && basePremium >= 50000)
                            {
                                tracer.Trace("rsa_policywording and rsa_premiumcode condition skipped for premium amount >=50000");
                                filter.Conditions.Add(new ConditionExpression("rsa_policywording", ConditionOperator.Null));
                                filter.Conditions.Add(new ConditionExpression("rsa_premiumcode", ConditionOperator.Equal, 18));
                                filter.Conditions.Add(new ConditionExpression("rsa_branch", ConditionOperator.Equal, branchAccount));
                            }
                            else if ((caseTypeName.ToLower().Contains("renewal") || caseTypeName.ToLower().Contains("query") || caseTypeName.ToLower().Contains("mid-term adjustment")) && classOfBusinessName.ToLower().Contains("blocks of flats") && basePremium < 50000)
                            {
                                tracer.Trace("rsa_policywording and rsa_premiumcode condition skipped as Case Type Renewal");
                                filter.Conditions.Add(new ConditionExpression("rsa_policywording", ConditionOperator.Null));
                                filter.Conditions.Add(new ConditionExpression("rsa_premiumcode", ConditionOperator.Null));
                            }
                            ////////
                            else
                            {
                                tracer.Trace("rsa_policywording and rsa_premiumcode condition skipped");
                                filter.Conditions.Add(new ConditionExpression("rsa_policywording", ConditionOperator.Null));
                                //filter.Conditions.Add(new ConditionExpression("rsa_premiumcode", ConditionOperator.Null));
                                filter.Conditions.Add(new ConditionExpression("rsa_premiumcode", ConditionOperator.Equal, range.PremiumRangeCode));
                            }
                        }
                        else
                        {
                            if (range.ValidCOB)
                            {
                                isBpw = GetBPWFlag(service, tracer, brokerId);
                                //if (isBpw != 0)
                                //{
                                //    isBpwyes = true;
                                //    filter.Conditions.Add(new ConditionExpression("rsa_policywording", ConditionOperator.Equal, isBpw));

                                //    tracer.Trace("rsa_policywording added " + isBpw);
                                //}
                                //else
                                //{
                                //    filter.Conditions.Add(new ConditionExpression("rsa_policywording", ConditionOperator.Null));
                                //    tracer.Trace("rsa_policywording not added " + isBpw);
                                //}
                                filter.Conditions.Add(new ConditionExpression("rsa_premiumcode", ConditionOperator.Equal, range.PremiumRangeCode));
                                tracer.Trace("Premium Code" + range.PremiumRangeCode);
                            }
                            ///if CaseType ,Branch and DistributionCategory exist then it check JSOn else added condition
                            else
                            {
                                if (!string.IsNullOrWhiteSpace(caseTypeName) && !string.IsNullOrWhiteSpace(branchAccount) && !string.IsNullOrWhiteSpace(distributionCategory))
                                {
                                    ///if CaseType = NB,renewal,MTA,Query
                                    if (caseTypeName.ToLower().Contains("query")
                                        || caseTypeName.ToLower().Contains("mid-term adjustment")
                                        || caseTypeName.ToLower().Contains("new business")
                                        || caseTypeName.ToLower().Contains("renewal") || caseTypeName.ToLower().Contains("bes referral"))
                                    {
                                        if (COBId != null && COBId != Guid.Empty)
                                        {

                                            tracer.Trace("COBId " + COBId);
                                            tracer.Trace("caseTypeName" + caseTypeName);
                                            tracer.Trace("branchAccount" + branchAccount);
                                            tracer.Trace("distributionCategory" + distributionCategory);
                                            bool IgnorePremiumCodeValue = false;
                                            bool IgnorePolicyScheme = false;
                                            tracer.Trace("Before GetCARConfigurtaionValue");
                                            Dictionary<string, bool> confList = GetCARConfigurtaionValue(service, tracer, COBId, caseTypeName, branchAccount, distributionCategory);
                                            tracer.Trace("After Calling GetCARConfigurtaionValue" + confList.Count);
                                            if (confList != null && confList.Count > 0)
                                            {

                                                if (confList.ContainsKey("IgnorePolicyScheme"))
                                                {
                                                    IgnorePolicyScheme = confList["IgnorePolicyScheme"];
                                                    tracer.Trace("PolicySchema: " + IgnorePolicyScheme);
                                                }


                                                if (confList.ContainsKey("IgnorePremiumCode"))
                                                {
                                                    IgnorePremiumCodeValue = confList["IgnorePremiumCode"];
                                                    tracer.Trace("Premium Code: " + IgnorePremiumCodeValue);
                                                }

                                                if (IgnorePremiumCodeValue != false)
                                                {
                                                    filter.Conditions.Add(new ConditionExpression("rsa_premiumcode", ConditionOperator.Equal, range.PremiumRangeCode));
                                                    tracer.Trace("Premium Code " + range.PremiumRangeCode);
                                                    tracer.Trace("Added condition for Premium Code to retrive CAR");
                                                }
                                                //Chandani: 25/01/2023: To handle old Branch
                                                if (isCOBOld == true)
                                                {
                                                    if (IgnorePolicyScheme != false)
                                                    {
                                                        filter.Conditions.Add(new ConditionExpression("rsa_policyscheme", ConditionOperator.Equal, scheme));
                                                        tracer.Trace("scheme " + scheme);
                                                        tracer.Trace("Added condition for scheme to retrive CAR");
                                                    }
                                                }
                                            }
                                            else //if no JSon Record found then add condition PremiumCode and PolicySchemee as per process
                                            {   //to handle code for invalid cob
                                                FilterExpression premiumCodeFilter = new FilterExpression(LogicalOperator.Or);
                                                ConditionExpression premiumCodeCondforNull = new ConditionExpression("rsa_premiumcode", ConditionOperator.Null);
                                                ConditionExpression premiumCodeCond = new ConditionExpression("rsa_premiumcode", ConditionOperator.Equal, range.PremiumRangeCode);
                                                premiumCodeFilter.AddCondition(premiumCodeCondforNull);
                                                premiumCodeFilter.AddCondition(premiumCodeCond);
                                                //filter.Conditions.Add(new ConditionExpression("rsa_premiumcode", ConditionOperator.Null));
                                                //filter.Conditions.Add(new ConditionExpression("rsa_premiumcode", ConditionOperator.Equal, range.PremiumRangeCode));
                                                filter.AddFilter(premiumCodeFilter);
                                                tracer.Trace("Premium Code " + range.PremiumRangeCode);
                                                tracer.Trace("No COnfiguration : pass null code/ premiumcode to retrive CAR");
                                            }
                                        }
                                    }
                                }
                            }
                        }

                    }
                    filter.Conditions.Add(new ConditionExpression("statecode", ConditionOperator.Equal, 0));
                    //2444  Commented and added on above function
                    //filter.Conditions.Add(new ConditionExpression("rsa_premiumcode", ConditionOperator.Equal, premiumCode));
                    //tracer.Trace("Premium Code " + premiumCode);

                    //filter.Conditions.Add(new ConditionExpression("rsa_policyscheme", ConditionOperator.Equal, scheme));
                    //tracer.Trace("scheme " + scheme);

                    //Sumegh Dhole 13 Oct 2020 : Add the check for the class of business data types
                    // if (classOfBusinessId != Guid.Empty)
                    //     filter.Conditions.Add(new ConditionExpression("rsa_classofbusiness", ConditionOperator.Equal, classOfBusinessId));
                    //if (!string.IsNullOrWhiteSpace(classOfBusinessName))
                    //{}//bug 1155
                    //Chandani: 25/01/2023: Code update to check COB text field. Commeneted below line of code
                    //LinkEntity cobLink = query.AddLink("rsa_classofbusiness", "rsa_classofbusiness", "rsa_classofbusinessid");
                    filter.Conditions.Add(new ConditionExpression("rsa_classofbusinesstext", ConditionOperator.Equal, classOfBusinessName));
                    //Chandani: 25/01/2023: Commeneted below line of code
                    //cobLink.LinkCriteria.AddCondition("rsa_name", ConditionOperator.Equal, classOfBusinessName);
                    // filter.Conditions.Add(new ConditionExpression("rsa_classofbusinessname", ConditionOperator.BeginsWith, classOfBusinessName));
                    tracer.Trace("classOfBusinessName " + classOfBusinessName);
                    //2444 Add Status 

                    if (caseRecordType != 1)
                    {
                        filter.Conditions.Add(new ConditionExpression("rsa_recordtype", ConditionOperator.ContainValues, caseRecordType));
                    }

                    tracer.Trace("caseRecordType " + caseRecordType);

                    tracer.Trace("caseStatus fetch for New business assign action");
                    string caseStatusName = string.Empty;
                    //unused code
                    //if (caseEntity.Attributes.Contains("rsa_status"))
                    //{
                    //    tracer.Trace(" caseEntity contains status");
                    //    EntityReference objCaseStatus = caseEntity.GetAttributeValue<EntityReference>("rsa_status");
                    //    if (objCaseStatus != null)
                    //    {
                    //        var recordtypeLookup = service.Retrieve(objCaseStatus.LogicalName, objCaseStatus.Id, new ColumnSet("rsa_name"));
                    //        // caseRecordType = recordtypeLookup.Contains("rsa_casetypecode") ? recordtypeLookup.GetAttributeValue<int>("rsa_casetypecode") : -1;
                    //        caseStatusName = recordtypeLookup.Contains("rsa_name") ? recordtypeLookup.GetAttributeValue<string>("rsa_name").ToLower() : null;
                    //    }
                    //}
                    //if (!string.IsNullOrEmpty(caseStatusName))
                    //{
                    //    if (caseTypeName.Equals("New Business") && caseStatusName.Equals("Initial Processing"))
                    //    {
                    if (encaseStatus != null)
                    {
                        if (caseRecordType == 866760006 && encaseStatus.Name.Equals("Initial Processing"))
                        {
                            // tracer.Trace("case type  for New business assign action" + caseTypeName);

                            Guid statusID = GetLookUpDetailsbyText(service, "To be Vetted", "rsa_status", objCaseRecordType.Id).Id;
                            caseEntity["rsa_status"] = new EntityReference("rsa_status", statusID);
                            service.Update(caseEntity);
                            ABRLogic objABRLogic = new ABRLogic();
                            Entity caseEntityforABR = null;
                            caseEntityforABR = service.Retrieve("incident", new Guid(caseId), new ColumnSet("ownerid", "caseorigincode", "rsa_opportunityorigin", "rsa_keysmebroker", "rsa_dealscase", "rsa_dealcheck", "rsa_dealbroker", "rsa_customertype", "rsa_customername", "rsa_customerrsa", "rsa_casereceiveddate", "rsa_casereasonrsa", "rsa_brokerprimaryreference", "rsa_applyr90conditions", "rsa_brokercommitmentimage", "rsa_accountnumber", "accountid", "rsa_account", "rsa_branchaccount", "rsa_distributioncategory", "rsa_scheme", "rsa_classofbusinesssme",
"rsa_classofbusiness", "rsa_classofbusinessphoneenqid", "rsa_opportunityid", "rsa_policyid", "rsa_casetype", "rsa_basepremiumrsa", "rsa_status", "rsa_cobextranet", "rsa_clientname", "createdon", "rsa_rsapolicyfulfilmentactivities", "rsa_productphoneenqid", "productid", "rsa_product_w", "rsa_productlivechat", "rsa_productsmev2", "rsa_productholder", "rsa_promise", "rsa_promisebroker", "rsa_rsarecordtype", "rsa_renewalreviewtype", "statecode", "rsa_transaction", "rsa_traded", "rsa_transactiontypeid"));
                            if (caseEntityforABR != null)
                            {
                                EntityCollection ABRTemplates = ABRLogic.GetABRTemplate(context, caseEntityforABR, service, tracer, ABRTracking);
                                foreach (var item2 in ABRTemplates.Entities)
                                {
                                    string abrTemplateID = item2.Id.ToString();

                                    if (!string.IsNullOrEmpty(abrTemplateID))
                                    {
                                        Guid opportunityId = Guid.Empty;
                                        Guid policyGuidId = Guid.Empty;
                                        Guid QueueID = Guid.Empty;//Added by Jyoti Bhosale ABR ARC change
                                        if (caseEntity.Contains("rsa_opportunityid") && caseEntity.GetAttributeValue<EntityReference>("rsa_opportunityid") != null)
                                        {
                                            EntityReference Opportunity = caseEntity.GetAttributeValue<EntityReference>("rsa_opportunityid");
                                            opportunityId = Opportunity.Id;
                                            tracer.Trace("opportunity ID ." + opportunityId);
                                        }
                                        if (caseEntity.Contains("rsa_policyid") && caseEntity.GetAttributeValue<EntityReference>("rsa_policyid") != null)
                                        {
                                            EntityReference policy = caseEntity.GetAttributeValue<EntityReference>("rsa_policyid");
                                            policyGuidId = policy.Id;
                                            tracer.Trace("Policy ID ." + policyGuidId);
                                        }
                                        objABRLogic.GetABRTasks(context, service, tracer, caseEntityforABR, Guid.Parse(abrTemplateID), opportunityId, policyGuidId, ABRTracking, QueueID, objARCOptionsetRoot,_unsecureString);


                                    }
                                }
                            }
                        }
                    }




                    query.Criteria = filter;
                    #region Convert Query Expression to FetchXML
                    QueryExpressionToFetchXmlRequest req = new QueryExpressionToFetchXmlRequest();
                    req.Query = query;
                    QueryExpressionToFetchXmlResponse resp = (QueryExpressionToFetchXmlResponse)service.Execute(req);

                    //work with newly formed fetch string
                    string myfetch = resp.FetchXml;
                    EntityCollection retrievedDetails = null;
                    #endregion Convert the query expression to FetchXML.
                    //for bug 1155 CAR gets triggered without oppty and POLICY DATA

                    retrievedDetails = (EntityCollection)service.RetrieveMultiple(query);

                    tracer.Trace("CaseAllocationRuleAdd" + myfetch);
                    tracer.Trace("CaseAllocationRuleAddCasetoQueue- Retrieved Details" + retrievedDetails.Entities.Count);
                    string DestinationQueueName = string.Empty;
                    bool statusflag = false;

                    //EntityReference caseStatus = caseEntity.Attributes.Contains("rsa_status") ? caseEntity.GetAttributeValue<EntityReference>("rsa_status") : null;

                    if (retrievedDetails.Entities.Count > 0)
                    {
                        tracer.Trace("CaseAllocationRuleAddCasetoQueue- Count >0 Details");
                        //Apply Foreach
                        foreach (var item in retrievedDetails.Entities)
                        {
                            tracer.Trace("CaseAllocationRuleAddCasetoQueue- Setting Queue CAR Name : " + item.Attributes["rsa_name"]);
                            ABRTracking["rsa_abrretrieved"] = item.Attributes["rsa_name"].ToString();
                            if (item != null)
                                ABRTracking["rsa_carretrieved"] = new EntityReference("rsa_abrtracking", item.Id);
                            //bug 1025 changing the case status to in progress
                            if (caseTypeName.Contains("query") || caseTypeName.Contains("revised renewal") || caseTypeName.Contains("mid-term adjustment"))
                            {
                                Guid statusID = GetLookUpDetailsbyText(service, "In Progress", "rsa_status", objCaseRecordType.Id).Id;
                                context.SharedVariables["rsa_status"] = statusID.ToString();
                                tracer.Trace(context.SharedVariables["rsa_status"].ToString());
                                tracer.Trace("In progress ID" + statusID);
                                if (encaseStatus != null && !encaseStatus.Name.Equals("In Progress")) //bug 2212 BPO workup generating twice.
                                {
                                    caseEntity["rsa_status"] = new EntityReference("rsa_status", statusID);
                                    statusflag = true;
                                }
                            }

                            if (item.Attributes.Contains("rsa_queue"))
                            {
                                tracer.Trace("CaseAllocationRuleAddCasetoQueue- Setting Queue");
                                //Query Expression to find matching record of Case Allocation Rule with Case
                                AddToQueueRequest routeRequest = new AddToQueueRequest
                                {
                                    Target = new EntityReference("incident", caseEntity.Id),
                                    DestinationQueueId = ((EntityReference)item.Attributes["rsa_queue"]).Id,

                                    //DestinationQueueId = ((EntityReference)retrievedDetails[0].Attributes["rsa_queuelookup"]).Id
                                };
                                service.Execute(routeRequest);
                                tracer.Trace("Inprogress status");
                                if (statusflag)
                                {
                                    service.Update(caseEntity);//In progress
                                    ABRLogic objABRLogic = new ABRLogic();
                                    Entity caseEntityforABR = null;
                                    caseEntityforABR = service.Retrieve("incident", new Guid(caseId), new ColumnSet("ownerid", "caseorigincode", "rsa_opportunityorigin", "rsa_keysmebroker", "rsa_dealscase", "rsa_dealcheck", "rsa_dealbroker", "rsa_customertype", "rsa_customername", "rsa_customerrsa", "rsa_casereceiveddate", "rsa_casereasonrsa", "rsa_brokerprimaryreference", "rsa_applyr90conditions", "rsa_brokercommitmentimage", "rsa_accountnumber", "accountid", "rsa_account", "rsa_branchaccount", "rsa_distributioncategory", "rsa_scheme", "rsa_classofbusinesssme",
        "rsa_classofbusiness", "rsa_classofbusinessphoneenqid", "rsa_opportunityid", "rsa_policyid", "rsa_casetype", "rsa_basepremiumrsa", "rsa_status", "rsa_cobextranet", "rsa_clientname", "createdon", "rsa_rsapolicyfulfilmentactivities", "rsa_productphoneenqid", "productid", "rsa_product_w", "rsa_productlivechat", "rsa_productsmev2", "rsa_productholder", "rsa_promise", "rsa_promisebroker", "rsa_rsarecordtype", "rsa_renewalreviewtype", "statecode", "rsa_transaction", "rsa_traded", "rsa_transactiontypeid"));
                                    if (caseEntityforABR != null)
                                    {
                                        EntityCollection ABRTemplates = ABRLogic.GetABRTemplate(context, caseEntityforABR, service, tracer, ABRTracking);
                                        foreach (var item2 in ABRTemplates.Entities)
                                        {
                                            string abrTemplateID = item2.Id.ToString();
                                            tracer.Trace("Activity Business Rule Id : {0}", item.Id);
                                            // if (!string.IsNullOrEmpty(abrTemplateID))
                                            if (!string.IsNullOrEmpty(abrTemplateID))
                                            {
                                                Guid opportunityId = Guid.Empty;
                                                Guid policyGuidId = Guid.Empty;
                                                Guid Queueid = Guid.Empty;//Jyoti Bhosale
                                                if (caseEntity.Contains("rsa_opportunityid") && caseEntity.GetAttributeValue<EntityReference>("rsa_opportunityid") != null)
                                                {
                                                    EntityReference Opportunity = caseEntity.GetAttributeValue<EntityReference>("rsa_opportunityid");
                                                    opportunityId = Opportunity.Id;

                                                    tracer.Trace("opportunity ID ." + opportunityId);
                                                }
                                                if (caseEntity.Contains("rsa_policyid") && caseEntity.GetAttributeValue<EntityReference>("rsa_policyid") != null)
                                                {
                                                    EntityReference policy = caseEntity.GetAttributeValue<EntityReference>("rsa_policyid");
                                                    policyGuidId = policy.Id;
                                                    tracer.Trace("Policy ID ." + policyGuidId);
                                                }

                                                //objABRLogic.GetABRActions(service, tracer, entity.Id, Guid.Parse(abrTemplateID), opportunityId, ABRTracking);
                                                // }
                                                //fix for defect id 82 : 12 Nov 2020 : Sumegh DHole : Opportunity Id was empty hence it was throwing an error. SME has no opportunity id
                                                objABRLogic.GetABRTasks(context, service, tracer, caseEntityforABR, Guid.Parse(abrTemplateID), opportunityId, policyGuidId, ABRTracking, Queueid, objARCOptionsetRoot,_unsecureString);
                                                // }

                                            }
                                        }
                                    }
                                }
                                DestinationQueueName = ((EntityReference)item.Attributes["rsa_queue"]).Name;
                            }

                            //If more than record with matching criteria, continue
                            //Sumegh Dhole: 15 Oct 2020 : Consider only top one matching criteria. 
                            break;
                            //continue;
                        }
                        tracer.Trace("CaseAllocationRuleAddCasetoQueue- End");
                        context.OutputParameters["QueueName"] = DestinationQueueName;
                        context.OutputParameters["IsQueueAssign"] = "true";
                        ABRTracking["rsa_abrretrievequery"] = myfetch;
                        ABRTracking["rsa_carabr"] = new OptionSetValue(866760001);
                        ABRTracking["rsa_name"] = "CAR Tracking LOG " + DateTime.Now + "\n Queue: " + DestinationQueueName.ToString();
                        WhoAmIRequest systemUserRequest = new WhoAmIRequest();
                        WhoAmIResponse systemUserResponse = (WhoAmIResponse)service.Execute(systemUserRequest);
                        Guid userId = systemUserResponse.UserId;
                        tracer.Trace("get USer ");
                        var User = service.Retrieve("systemuser", userId, new ColumnSet("firstname"));
                        ABRTracking["rsa_abrtriggeredby"] = new EntityReference("systemuser", User.Id);
                        ABRTracking["rsa_casetriggeraction"] = new OptionSetValue(866760001);
                        if (caseEntity != null)
                        {
                            ABRTracking["rsa_case"] = new EntityReference("rsa_abrtracking", caseEntity.Id);
                        }
                        string toggle = string.Empty;
                        Entity enABRtrack = ABRLogic.toggleABRTracking(service, "ABR Tracking");
                        tracer.Trace("Entity object Created" + enABRtrack.Attributes.Count);
                        if (enABRtrack != null)
                        {
                            tracer.Trace("toggle check");
                            toggle = enABRtrack.Attributes.Contains("rsa_language") ? enABRtrack.GetAttributeValue<string>("rsa_language") : string.Empty;
                            tracer.Trace("toggle check" + toggle);
                        }
                        if (toggle.ToLower().Contains("yes"))
                        {
                            service.Create(ABRTracking);
                        }
                    }

                    else
                    {
                        context.OutputParameters["IsQueueAssign"] = "false";
                    }

                }
                catch (Exception ex)
                {
                    tracer.Trace("CaseAllocationRuleAddCasetoQueue-Error" + ex.Message.ToString());
                    context.OutputParameters["IsQueueAssign"] = "false";
                    throw new InvalidPluginExecutionException("An error occurred in the CaseAllocationRuleAddCasetoQueue plug-in" + ex.Message.ToString());

                }
            }
        }

        public AccountBranchRoot getBranchJsonValues(string strCustomLabel, ITracingService tracingService, IOrganizationService service)
        {
            tracingService.Trace("getRouteOfSaleJsonValues - Loaded");
            var AccBranchOptionsetRoot = new AccountBranchRoot();

            string dependentOptionset = string.Empty;

            QueryExpression BranchExpression = new QueryExpression("rsa_customlabel");
            BranchExpression.TopCount = 1;
            BranchExpression.NoLock = true;
            BranchExpression.ColumnSet = new ColumnSet(new string[] { "rsa_dependentoptionsetjson" });
            BranchExpression.Criteria = new FilterExpression();
            BranchExpression.Criteria.AddCondition("rsa_name", ConditionOperator.Equal, strCustomLabel);
            EntityCollection branchCustomLabel = service.RetrieveMultiple(BranchExpression);
            if (branchCustomLabel != null && branchCustomLabel.Entities.Count > 0)
            {
                tracingService.Trace("AccountBranchRoot != null && AccountBranchRoot.Entities.Count > 0");

                if (branchCustomLabel.Entities[0].Contains("rsa_dependentoptionsetjson")
                    && !string.IsNullOrEmpty(branchCustomLabel.Entities[0]["rsa_dependentoptionsetjson"].ToString()))
                {
                    dependentOptionset = branchCustomLabel.Entities[0]["rsa_dependentoptionsetjson"].ToString();
                    tracingService.Trace("Optionset Mapping retrieved: AccountBranchRoot Optionset");

                    //var ms = new MemoryStream(Encoding.UTF8.GetBytes(dependentOptionset));
                    //var ser = new DataContractJsonSerializer(AccBranchOptionsetRoot.GetType());
                    //AccBranchOptionsetRoot = ser.ReadObject(ms) as AccountBranchRoot;
                    //ms.Close();
                    //Remediation - 20/07/2022
                    var ms = new MemoryStream(Encoding.UTF8.GetBytes(dependentOptionset));
                    try
                    {
                        var ser = new DataContractJsonSerializer(AccBranchOptionsetRoot.GetType());
                        AccBranchOptionsetRoot = ser.ReadObject(ms) as AccountBranchRoot;
                    }
                    catch (Exception ex)
                    {
                        throw new InvalidPluginExecutionException(ex.Message);
                    }
                    finally
                    {
                        ms.Close();
                    }

                }
            }
            else
            {
                tracingService.Trace("AccountBranchRoot == null || AccountBranchRoot.Entities.Count < 1");
            }
            tracingService.Trace("AccountBranchRoot - Unloaded");
            return AccBranchOptionsetRoot;
        }
        public Entity GetLookUpDetailsbyText(IOrganizationService service, string pName, string entityName, Guid casetype)
        {
            try
            {
                var entity = new Entity(entityName);
                string fetchQuery = "<fetch mapping = 'logical'>";
                fetchQuery += "<entity name = '" + entityName + "'>";
                fetchQuery += "<attribute name='rsa_name' />";
                fetchQuery += "<filter type = 'and'>";
                fetchQuery += "<condition attribute = 'rsa_name' operator= 'eq' value = '" + pName + "' />";
                if (casetype != Guid.Empty)
                    fetchQuery += "<condition attribute = 'rsa_casetype' operator= 'eq' value = '" + casetype + "' />";
                fetchQuery += "</filter>";
                fetchQuery += "</entity>";
                fetchQuery += "</fetch>";
                EntityCollection lobDetails = service.RetrieveMultiple(new FetchExpression(fetchQuery));
                if (lobDetails.Entities.Count > 0)
                {
                    foreach (var entities in lobDetails.Entities)
                    {
                        entity = entities;
                    }
                }
                return entity;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public Dictionary<string, bool> GetCARConfigurtaionValue(IOrganizationService service, ITracingService tracer, Guid COBId, string recordTypeName, string branchName, string distributionCategory)
        {
            Dictionary<string, bool> carConfList = new Dictionary<string, bool>();
            try
            {

                Entity eclassOfBusiness = service.Retrieve("rsa_classofbusiness", COBId, new ColumnSet("rsa_carconditionalconfiguration"));
                string carConditionalConfiguration = string.Empty;
                carConditionalConfiguration = eclassOfBusiness.Attributes.Contains("rsa_carconditionalconfiguration") ? ((string)eclassOfBusiness.Attributes["rsa_carconditionalconfiguration"]) : string.Empty;
                //   tracer.Trace("carConditionalConfiguration:  " + carConditionalConfiguration);
                tracer.Trace("Case Assign: GetCARConfigurtaionValue Starting");
                if (!string.IsNullOrWhiteSpace(carConditionalConfiguration))
                {
                    var car = new CARConfiguration();
                    var ms = new MemoryStream(Encoding.UTF8.GetBytes(carConditionalConfiguration));
                    var ser = new DataContractJsonSerializer(car.GetType());
                    car = ser.ReadObject(ms) as CARConfiguration;
                    ms.Close();
                    tracer.Trace("Case Assign:Fetch Cong Started");
                    tracer.Trace("Case Assign:COBId" + COBId);
                    tracer.Trace("Case Assign:recordTypeName" + recordTypeName);
                    tracer.Trace("Case Assign:branchName" + branchName);

                    tracer.Trace("Case Assign:distributionCategory" + distributionCategory);

                    if (car != null)
                    {
                        tracer.Trace("Case Assign:GetCARConfigurtaionValue:Inside CAR");
                        if (car.ConditionalCARConfig != null)
                        {
                            tracer.Trace("car.ConditionalCARConfig: " + car.ConditionalCARConfig.Count());

                            var recordType = car.ConditionalCARConfig.FirstOrDefault(x => x.RecordTypeName.ToLower() == recordTypeName.ToLower());

                            if (recordType != null)
                            {
                                tracer.Trace("recordTypeName: " + recordType.RecordTypeName);

                                var branch = recordType.RecordTypeDetails.FirstOrDefault(x => x.Branch.ToLower() == branchName.ToLower());
                                tracer.Trace("branchName: " + branch.Branch);
                                if (branch != null)
                                {
                                    var disCat = branch.BrokerDetails.FirstOrDefault(d => d.DistributionCategory.ToLower() == distributionCategory.ToLower());
                                    tracer.Trace("distributionCat: " + disCat.DistributionCategory);
                                    if (disCat != null)
                                    {
                                        var IgnorePolicyScheme = false; var IgnorePremiumCode = false;
                                        IgnorePolicyScheme = (disCat.IgnorePolicyScheme != null) ? disCat.IgnorePolicyScheme : false;
                                        IgnorePremiumCode = (disCat.IgnorePremiumCode != null) ? disCat.IgnorePremiumCode : false;

                                        //  var IgnorePolicyScheme = disCat.IgnorePolicyScheme;
                                        //  var IgnorePremiumCode = disCat.IgnorePremiumCode;

                                        tracer.Trace("IgnorePremiumCode: " + IgnorePremiumCode);
                                        tracer.Trace("IgnorePolicyScheme: " + IgnorePolicyScheme);

                                        // adding elements
                                        carConfList.Add("IgnorePolicyScheme", IgnorePolicyScheme);
                                        carConfList.Add("IgnorePremiumCode", IgnorePremiumCode);
                                        tracer.Trace("Done");
                                    }


                                }
                            }

                        }
                    }


                }
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(string.Format("Error in GetCARConfigurtaionValue : {0}", ex.InnerException.Message));
            }
            return carConfList;
        }
        private PremiumRange GetPremiumRange(IOrganizationService service, ITracingService tracer, decimal premium, string cOB, bool isBPW, string caseRecordType, bool isCOBOld, string strClassofBusinessNew)
        {

            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' no-lock='true'>
                                 <entity name='rsa_premuimrange'>
                                   <attribute name = 'rsa_premuimrangeid'/>
                                   <attribute name = 'rsa_name'/>                              
                                   <attribute name='rsa_rangeid'/>
                                   <attribute name = 'rsa_lowerlimit'/>
                                   <attribute name = 'rsa_higherlimit'/>
                                   <attribute name = 'rsa_classofbusiness'/>
                                   <attribute name = 'rsa_caserecordtype'/>
    `                              <order descending = 'false' attribute = 'rsa_name'/>
                                   <filter type = 'and'>
                                   <condition attribute = 'rsa_lowerlimit' operator= 'le'  value='{0}'/>
                                   <condition attribute = 'rsa_higherlimit' operator= 'ge' value='{0}'/>
                                   </filter >
                                   </entity >
                                   </fetch >";
            EntityCollection enColpremuimrange = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, premium)));
            PremiumRange range = new PremiumRange();
            string premuimRangeId = string.Empty;
            var ClassOB = string.Empty;
            tracer.Trace("GetPremiumRange case type: " + caseRecordType + " COB: " + cOB);

            //Modified on 18-08-2022 ;By : Nida/Samiksha ; Des: CR2642- Regression Issue
            //Chandani: 04/01/2023: Commeneted below code for Premium range data
            //List<Entity> enCOBRange = (enColpremuimrange.Entities.Where(a => a.Contains("rsa_classofbusiness") && cOB != null && Convert.ToString(a.Attributes["rsa_classofbusiness"]).ToLower().Contains(cOB.ToLower()) && a.Contains("rsa_caserecordtype") && caseRecordType != null && Convert.ToString(a.Attributes["rsa_caserecordtype"]).ToLower().Contains(caseRecordType.ToLower()))).ToList<Entity>();

            //List<Entity> enCOBRange = (enColpremuimrange.Entities.Where(a => a.Contains("rsa_classofbusiness") && cOB != null
            //&& Convert.ToString(a.Attributes["rsa_classofbusiness"]).ToLower().Contains(cOB.ToLower()) && a.Contains("rsa_caserecordtype")
            //&& caseRecordType != null && Convert.ToString(a.Attributes["rsa_caserecordtype"]).ToLower().Contains(caseRecordType.ToLower()))).ToList<Entity>();

            List<Entity> enCOBRange = (enColpremuimrange.Entities.Where(a => a.Contains("rsa_caserecordtype") && cOB != null
            && (strClassofBusinessNew.ToLower().Contains(cOB.ToLower()) || strClassofBusinessNew == string.Empty)
            && caseRecordType != null && Convert.ToString(a.Attributes["rsa_caserecordtype"]).ToLower().Contains(caseRecordType.ToLower()))).ToList<Entity>();


            if (enCOBRange.Count > 0 && isCOBOld == false)
            {

                for (var i = 0; i < enCOBRange.Count; i++)
                {
                    if (cOB.ToLower() != "combined")
                    {
                        premuimRangeId = Convert.ToString(enCOBRange[0]["rsa_rangeid"]);

                    }

                    if (enCOBRange[i]["rsa_classofbusiness"].ToString().ToLower().Contains(cOB.ToLower()))
                    {

                        premuimRangeId = Convert.ToString(enCOBRange[i]["rsa_rangeid"]);
                        break;
                    }

                }
                // enCOBRange.ForEach(COBRange => premuimRangeId = Convert.ToString(COBRange.Attributes["rsa_rangeid"]));
                range.PremiumRangeCode = premuimRangeId;
                range.ValidCOB = true;
                tracer.Trace("BPW Condition");
            }
            else
            {
                List<Entity> enRange = (enColpremuimrange.Entities.Where(a => a.GetAttributeValue<Money>("rsa_lowerlimit").Value <= premium && a.GetAttributeValue<Money>("rsa_higherlimit").Value >= premium && !a.Contains("rsa_classofbusiness") && !a.Contains("rsa_caserecordtype")).ToList<Entity>());
                if (enRange.Count > 0)
                {
                    enRange.ForEach(COBRange => premuimRangeId = Convert.ToString(COBRange.Attributes["rsa_rangeid"]));
                    range.PremiumRangeCode = premuimRangeId;
                    //range.ValidCOB = false;
                    range.ValidCOB = false;
                    tracer.Trace("Not a BPW Condition");
                }
            }
            return range;

        }

        private Entity GetCustomLabel(IOrganizationService service, ITracingService tracer, string key)
        {
            Entity returnValue = null;
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' no-lock='true'>
                              <entity name='rsa_customlabel'>
                                <attribute name='rsa_values' />
                                <attribute name='rsa_shortdescription' />
                                <attribute name='rsa_categories' />   
                                <attribute name='rsa_dependentoptionsetjson'/>
                                <filter type='and'>
                                  <condition attribute='rsa_name' operator='eq' value ='{0}'/>
                                </filter>
                              </entity>
                            </fetch>";
            var entityCustomLevel = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, key)));
            if (entityCustomLevel.Entities.Count > 0)
            {
                //returnValue = entityCustomLevel[0].Attributes.Contains("rsa_values") ? entityCustomLevel[0].GetAttributeValue<string>("rsa_values") : string.Empty;
                returnValue = entityCustomLevel.Entities[0];
            }
            return returnValue;
        }
        private int GetBPWFlag(IOrganizationService service, ITracingService tracer, Guid brokerid)
        {
            int isBPWFlag = 0;

            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' no-lock='true'>
                                <entity name='rsa_agencycode'>
                                <attribute name='rsa_agencycodeid'/>
                                <attribute name='rsa_name'/>
                                <attribute name='rsa_policywording'/>
                                <attribute name='rsa_agency'/>
                                <order descending='false' attribute='rsa_name'/>
                                <filter type='and'>
                                <condition attribute='rsa_agency' operator= 'eq'  value='{0}'/>
                                <condition attribute='rsa_policywording' value='866760000' operator='eq'/>
                                </filter>
                                </entity>
                                </fetch>";

            EntityCollection enAgencyCodeCollection = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, brokerid)));


            List<Entity> enAgencyCode = (enAgencyCodeCollection.Entities.Where(a => a.Contains("rsa_agency") && a.Contains("rsa_policywording") && a.GetAttributeValue<EntityReference>("rsa_agency").Id == brokerid).ToList<Entity>());

            if (enAgencyCode.Count > 0)
            {
                enAgencyCode.ForEach(agencyCode => isBPWFlag = agencyCode.GetAttributeValue<OptionSetValue>("rsa_policywording").Value);

            }
            return isBPWFlag;

        }

    }

    [DataContract]
    public class AccountBranch
    {
        [DataMember]
        public string BranchName { get; set; }
        [DataMember]
        public int Branchvalue { get; set; }
    }

    public class AccountBranchRoot
    {
        [DataMember]
        public List<AccountBranch> AccountBranch { get; set; }
    }

    public class PremiumRange
    {
        public bool ValidCOB { get; set; }
        public string PremiumRangeCode { get; set; }
    }



}
