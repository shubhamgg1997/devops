﻿using RSA.Crm.Plugins;
using Microsoft.Xrm.Sdk;
using System;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using RSA.CSI.Plugins.ABR.Logic;
using System.IO;
using System.Text;
using System.Net;
using System.Runtime.Serialization.Json;
using System.Runtime.Serialization;
using System.Linq;
using System.Collections.Generic;

namespace RSA.CSI.Plugins.CAR
{
    public class CARPostCreate : IPlugin
    {
        public Guid COBId = Guid.Empty;
        private readonly string _unsecureString;

        public CARPostCreate(string unsecureString)
        {
            _unsecureString = unsecureString;
        }
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService tracer = null;
            IPluginExecutionContext context = null;
            IOrganizationService service = null;

            CrmPluginHelper.Initialise(serviceProvider, ref context, ref service, ref tracer, false);
            if (context.MessageName == "Create")
            {
                //Nida: 08 June 2022 : Depth 6 condition added for the tasks to be generated post renewal generation. 
                //Nida: 14 June 2022 :depth commented for 2511 task creation issue
                tracer.Trace("Create Message:" + context.Depth);
                //if (context.Depth > 6)
                //{
                //    return;
                //}
            }

            else if (context.MessageName == "Update")
            {
                // Sumegh DHole : Defect 2098, 2193 : Historic data fix 
                tracer.Trace("Update Message:" + context.Depth);
                if (context.Depth > 1 && context.Depth != 4)
                {
                    return;
                }
            }

            tracer.Trace("Depth:" + context.Depth);
            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                try
                {
                    tracer.Trace("Inside Update Logic");
                    Entity caseEntity = (Entity)context.InputParameters["Target"];
                    Guid brokerId = Guid.Empty;
                    EntityReference objCaseRecordType = null;
                    //Check for renewal generation cases : If Depth is 4 and case is of renewala generration then only continue else return 
                    //Defect id 2098 : 
                    if (context.Depth == 2)
                    {
                        string fetchQuery = "<fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>";
                        fetchQuery += "<entity name='incident'>";
                        fetchQuery += "<attribute name='title' />";
                        fetchQuery += "<order descending='false' attribute='title' />";
                        fetchQuery += "<filter type='and'>";
                        fetchQuery += "<condition attribute='incidentid' operator='eq' value = '" + caseEntity.Id + "'/>";
                        fetchQuery += "<condition attribute='rsa_renewalgeneration' operator='not-null' />";
                        fetchQuery += "</filter>";
                        fetchQuery += "</entity>";
                        fetchQuery += "</fetch>";
                        tracer.Trace("Fetch case if renewal generated :" + caseEntity.Id);
                        EntityCollection entyCollCase = service.RetrieveMultiple(new FetchExpression(fetchQuery));
                        if (entyCollCase.Entities.Count < 1)
                        {
                            tracer.Trace("return as record is not renewal generated and having depth as 2 or 4");
                            return;
                        }
                    }

                    //Check for Update
                    if (context.MessageName == "Update")
                    {
                        //Check any of the Fields has been changed
                        tracer.Trace("Inside Update Message" + caseEntity.Attributes.Count);
                        //Defect id 1424 : Sumegh Dhole : CAR was not triggering for case record updates 
                        if (caseEntity.Attributes.Contains("rsa_branchaccount") || caseEntity.Attributes.Contains("rsa_policyid") ||
                            caseEntity.Attributes.Contains("rsa_distributioncategory") || caseEntity.Attributes.Contains("rsa_classofbusinessphoneenqid")
                            || caseEntity.Attributes.Contains("rsa_caserecordtype") || caseEntity.Attributes.Contains("rsa_scheme") ||
                            caseEntity.Attributes.Contains("rsa_opportunityid") || caseEntity.Attributes.Contains("rsa_status") || caseEntity.Attributes.Contains("rsa_basepremiumrsa") || caseEntity.Attributes.Contains("rsa_historicdatasync"))
                        {
                            tracer.Trace("CaseAllocationRuleAddCasetoQueue- In Update Message");
                            //Use Pre-Image
                            //caseEntity = service.Retrieve("incident", caseEntity.Id, new ColumnSet("rsa_branchaccount", "rsa_distributioncategory", "rsa_classofbusinesslookup", "rsa_caserecordtype", "rsa_scheme"));
                            if (context.PostEntityImages.Contains("PostImageCaseRecord") && context.PostEntityImages["PostImageCaseRecord"] is Entity)
                            {
                                tracer.Trace("CaseAllocationRuleAddCasetoQueue- In PostImage");
                                caseEntity = (Entity)context.PostEntityImages["PostImageCaseRecord"];
                            }
                        }
                        else
                        {
                            return;
                        }

                    }
                    //Sumegh Dhole : 10 Oct :Defect for agency request case type record not getting saved as rsa_Account is not applicable for that case type 
                    EntityReference broker = null;
                    if (caseEntity.Attributes.Contains("rsa_account"))
                    {
                        broker = caseEntity.GetAttributeValue<EntityReference>("rsa_account");
                    }
                    if (broker != null)
                        brokerId = broker.Id;
                    //Distribution Category, Branch, rsa_classofbusinessphoneenq, Case Record Type, Premium Code(Couldn't find), Scheme
                    string branchAccount = string.Empty, distributionCategory = string.Empty; //premiumCode = string.Empty;
                    int caseRecordType = -1;
                    string caseTypeName = string.Empty;
                    decimal basePremium = 0.0M;
                    decimal PolicybasePremium = 0.0M;
                    string classOfBusinessName = string.Empty;
                    Guid classOfBusinessId = Guid.Empty;
                    EntityReference queue = new EntityReference("queue");
                    Entity Opportunity = null;
                    bool scheme = false;
                    string product = string.Empty;

                    if (caseEntity.Attributes.Contains("rsa_distributioncategory"))
                        distributionCategory = caseEntity.GetAttributeValue<string>("rsa_distributioncategory");

                    if (caseEntity.Attributes.Contains("rsa_branchaccount"))
                    {
                        branchAccount = caseEntity.GetAttributeValue<string>("rsa_branchaccount");
                    }
                    else if (string.IsNullOrWhiteSpace(branchAccount) || string.IsNullOrWhiteSpace(distributionCategory))
                    {
                        EntityReference accountReference = caseEntity.Attributes.Contains("rsa_account") ? (EntityReference)caseEntity.Attributes["rsa_account"] : null;
                        if (accountReference != null)
                        {
                            tracer.Trace("Start retrieving data from account entity " + accountReference.Name);
                            Entity accountInfo = service.Retrieve(accountReference.LogicalName, accountReference.Id, new ColumnSet(new string[] { "rsa_branch", "rsa_distributioncategoryagency" }));
                            int branchValue = accountInfo.Attributes.Contains("rsa_branch") ? ((OptionSetValue)accountInfo.Attributes["rsa_branch"]).Value : 0;
                            tracer.Trace("branchValue " + branchValue);
                            //Fix for 2193 : SUmegh Dhole : 04 Oct 2021
                            CaseAssignAction caseAssignAction = new CaseAssignAction(_unsecureString);
                            AccountBranchRoot accountBranchRoot = caseAssignAction.getBranchJsonValues("BranchAccountJSON", tracer, service);
                            AccountBranch brMap = new AccountBranch();
                            if (accountBranchRoot != null && branchValue != 0)
                            {
                                if (branchValue != 0 && accountBranchRoot.AccountBranch != null && accountBranchRoot.AccountBranch.Count > 0)
                                {
                                    brMap = (AccountBranch)accountBranchRoot.AccountBranch.Find(a => a.Branchvalue.Equals(branchValue));
                                    tracer.Trace("accountBranchRoot branchMap branch" + brMap.BranchName);
                                    branchAccount = Convert.ToString(brMap.BranchName);
                                }
                            }
                            #region Commented Code 
                            //switch (branchValue)
                            //{
                            //    case 866760000:
                            //        branchAccount = "Belfast";
                            //        break;
                            //    case 866760001:
                            //        branchAccount = "Birmingham";
                            //        break;
                            //    case 866760002:
                            //        branchAccount = "Bristol";
                            //        break;
                            //    case 866760003:
                            //        branchAccount = "Cardiff";
                            //        break;
                            //    case 866760004:
                            //        branchAccount = "Edinburgh";
                            //        break;
                            //    case 866760005:
                            //        branchAccount = "Glasgow";
                            //        break;
                            //    case 866760006:
                            //        branchAccount = "Horsham";
                            //        break;
                            //    case 866760007:
                            //        branchAccount = "Ipswich";
                            //        break;
                            //    case 866760008:
                            //        branchAccount = "Leeds";
                            //        break;
                            //    case 866760009:
                            //        branchAccount = "Leicester";
                            //        break;
                            //    case 866760010:
                            //        branchAccount = "London";
                            //        break;
                            //    case 866760011:
                            //        branchAccount = "Manchester";
                            //        break;
                            //    case 866760012:
                            //        branchAccount = "Real Estate";
                            //        break;
                            //    case 866760013:
                            //        branchAccount = "Redhill";
                            //        break;
                            //    case 866760014:
                            //        branchAccount = "Blocks of Flats";
                            //        break;
                            //    default:
                            //        break;
                            //}
                            #endregion
                            distributionCategory = accountInfo.Attributes.Contains("rsa_distributioncategoryagency") ? Convert.ToString(accountInfo.Attributes["rsa_distributioncategoryagency"]) : string.Empty;
                        }
                    }

                    tracer.Trace("branchAccount " + branchAccount);
                    tracer.Trace("distributionCategory " + distributionCategory);

                    if (caseEntity.Attributes.Contains("rsa_scheme"))
                        scheme = caseEntity.GetAttributeValue<bool>("rsa_scheme");

                    tracer.Trace("scheme " + scheme);

                    EntityReference policyId = new EntityReference();
                    //Sumegh Dhole 13 Oct 2020 : Add the check for the class of business data types
                    //Nida: 12/10/2022 : Unwanted else if condition removed to handle COBId issue: Bug id: 2444-2642
                    if (caseEntity.Attributes.Contains("rsa_classofbusiness") && !caseEntity.Attributes.Contains("rsa_originatingcase"))
                    {
                        tracer.Trace("classOfBusinessName 2");
                        classOfBusinessName = Convert.ToString(caseEntity.Attributes["rsa_classofbusiness"]);

                    }


                    if (caseEntity.Attributes.Contains("rsa_classofbusinesssme") && !caseEntity.Attributes.Contains("rsa_originatingcase"))
                    {
                        tracer.Trace("classOfBusinessName 3");
                        classOfBusinessName = Convert.ToString(caseEntity.Attributes["rsa_classofbusinesssme"]);

                    }

                    //Jyoti: 12/10/2022 : Fetch XML added to retrieve COB: Bug id: 2444
                    if (caseEntity.Attributes.Contains("rsa_opportunityid"))
                    {
                        tracer.Trace("Get the class name from opportunity");
                        EntityReference opportunityId = caseEntity.Attributes.Contains("rsa_opportunityid") ? (EntityReference)caseEntity.Attributes["rsa_opportunityid"] : null;
                        if (opportunityId != null)
                        {
                            string lineofbusiness = string.Empty;
                            Guid lineofbusinessId = Guid.Empty;
                            string pl = string.Empty;
                            Guid plid = Guid.Empty;
                            tracer.Trace("classOfBusinessName 4");
                            Opportunity = service.Retrieve(opportunityId.LogicalName, opportunityId.Id, new ColumnSet(new string[] { "rsa_classofbusiness", "rsa_lineofbusiness", "rsa_pandlid", "rsa_classofbusiness","rsa_productid" }));
                            classOfBusinessName = Opportunity.Attributes.Contains("rsa_classofbusiness") ? ((EntityReference)Opportunity.Attributes["rsa_classofbusiness"]).Name : string.Empty;
                            tracer.Trace("Class of Business Name from optty " + classOfBusinessName);
                            //2444
                            lineofbusiness = Opportunity.Attributes.Contains("rsa_lineofbusiness") ? ((EntityReference)Opportunity.Attributes["rsa_lineofbusiness"]).Name : string.Empty;
                            tracer.Trace("Line of Business Name from optty " + lineofbusiness);
                            lineofbusinessId = Opportunity.Attributes.Contains("rsa_lineofbusiness") ? ((EntityReference)Opportunity.Attributes["rsa_lineofbusiness"]).Id : Guid.Empty;
                            pl = Opportunity.Attributes.Contains("rsa_pandlid") ? ((EntityReference)Opportunity.Attributes["rsa_pandlid"]).Name : string.Empty;
                            tracer.Trace("P&L Name from optty " + pl);
                            plid = Opportunity.Attributes.Contains("rsa_pandlid") ? ((EntityReference)Opportunity.Attributes["rsa_pandlid"]).Id : Guid.Empty;
                            COBId = Opportunity.Attributes.Contains("rsa_classofbusiness") ? ((EntityReference)Opportunity.Attributes["rsa_classofbusiness"]).Id : Guid.Empty;
                            tracer.Trace("COBId" + COBId);
                            if (classOfBusinessName != string.Empty)
                            {
                                //Updated by Jyoti Bhosale for 24444
                                // fetch COB based on COBName +LOB + P&L combination : If found then override COBID value else continue
                                string fetchCOB = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                <entity name='rsa_classofbusiness'>
                                <attribute name='rsa_name' />
                                <attribute name='createdon' />
                                <attribute name='rsa_pl' />
                                <attribute name='rsa_description' />
                                <attribute name='rsa_lineofbusiness' />
                                <attribute name='rsa_classofbusinessid' />
                                <order attribute='rsa_name' descending='false' />
                                <filter type='and'>
                                <condition attribute='rsa_lineofbusiness' operator='eq'  uitype='rsa_lineofbusiness' value='{0}' />
                                <condition attribute='rsa_name' operator='eq' value='{2}' />
                                </filter>
                                <link-entity name='rsa_pl' from='rsa_plid' to='rsa_pl' link-type='inner' alias='ac'>
                                <filter type='and'>
                                <condition attribute='rsa_name' operator='eq' value='{1}' />
                                </filter>
                                </link-entity>
                                </entity>
                                </fetch>";
                                //modified : 18 oct 22 ; Nida ; Defect : TFS 530 : Invalid Xml for d&O cob name
                                //modified : 19 oct 22; Shravani : TFS 666: Invalid Xml for P&L
                                EntityCollection OpptyentityCollection = service.RetrieveMultiple(new FetchExpression(String.Format(fetchCOB, lineofbusinessId, WebUtility.HtmlEncode(pl), WebUtility.HtmlEncode(classOfBusinessName))));
                                if (OpptyentityCollection.Entities.Count > 0)
                                {
                                    foreach (var cob in OpptyentityCollection.Entities)
                                    {
                                        COBId = cob.Id;
                                        //COBID to be override
                                        break;
                                    }
                                }
                            }
                            product = Opportunity.Attributes.Contains("rsa_productid") ? ((EntityReference)Opportunity.Attributes["rsa_productid"]).Name : string.Empty;
                            tracer.Trace("product name from opportunity:" + product);
                        }
                    }
                    else if (caseEntity.Attributes.Contains("rsa_classofbusinessphoneenqid"))
                    {
                        tracer.Trace("classOfBusinessName 1");
                        classOfBusinessId = ((EntityReference)caseEntity.Attributes["rsa_classofbusinessphoneenqid"]).Id;
                        classOfBusinessName = ((EntityReference)caseEntity.Attributes["rsa_classofbusinessphoneenqid"]).Name;
                        //  2444
                        COBId = ((EntityReference)caseEntity.Attributes["rsa_classofbusinessphoneenqid"]).Id;
                        //Modified on 18-08-2022 ;By : Nida/Samiksha ; Des:Regression Issue: COB Null check
                        if (classOfBusinessName == null)
                        {
                            Entity eClassofbusiness = service.Retrieve("rsa_classofbusiness", COBId, new ColumnSet("rsa_name"));
                            classOfBusinessName = eClassofbusiness.Contains("rsa_name") ? eClassofbusiness.GetAttributeValue<string>("rsa_name").ToString() : null;

                        }
                        tracer.Trace("COBId" + COBId);


                    }
                    else if (caseEntity.Attributes.Contains("rsa_policyid"))
                    {

                        tracer.Trace("Get the class name from policy");

                        policyId = caseEntity.Attributes.Contains("rsa_policyid") ? (EntityReference)caseEntity.Attributes["rsa_policyid"] : null;

                        if (policyId != null)

                        {

                            string Policy = string.Empty;

                            Guid lineofbusinessId = Guid.Empty;

                            string pl = string.Empty;

                            Guid plid = Guid.Empty;

                            Guid policytype = Guid.Empty;

                            Entity PolicyData = service.Retrieve(policyId.LogicalName, policyId.Id, new ColumnSet(new string[] { "rsa_classofbusiness", "rsa_plcode", "rsa_name", "rsa_policytype", "rsa_productid" }));

                            classOfBusinessName = PolicyData.Attributes.Contains("rsa_classofbusiness") ? ((EntityReference)PolicyData.Attributes["rsa_classofbusiness"]).Name : string.Empty;

                            tracer.Trace("Class of Business Name from policy " + classOfBusinessName);

                            //2444

                            Policy = PolicyData.Attributes.Contains("rsa_policytype") ? ((EntityReference)PolicyData.Attributes["rsa_policytype"]).Name : string.Empty;

                            tracer.Trace("Policy Name " + Policy);



                            policytype = PolicyData.Attributes.Contains("rsa_policytype") ? ((EntityReference)PolicyData.Attributes["rsa_policytype"]).Id : Guid.Empty;

                            pl = PolicyData.Attributes.Contains("rsa_plcode") ? ((EntityReference)PolicyData.Attributes["rsa_plcode"]).Name : string.Empty;

                            tracer.Trace("P&L Name from optty " + pl);

                            plid = PolicyData.Attributes.Contains("rsa_plcode") ? ((EntityReference)PolicyData.Attributes["rsa_plcode"]).Id : Guid.Empty;
                           
                            product = PolicyData.Attributes.Contains("rsa_productid") ? ((EntityReference)PolicyData.Attributes["rsa_productid"]).Name : string.Empty;

                            tracer.Trace("Product name from policy " + product);

                            COBId = PolicyData.Attributes.Contains("rsa_classofbusiness") ? ((EntityReference)PolicyData.Attributes["rsa_classofbusiness"]).Id : Guid.Empty;

                            tracer.Trace("COBId" + COBId);

                            if (classOfBusinessName != string.Empty)

                            {

                                //Updated by Jyoti Bhosale for 24444

                                // fetch COB based on COBName +LOB + P&L combination : If found then override COBID value else continue

                                string fetchCOBfromPolicy = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                <entity name='rsa_classofbusiness'>
                                <attribute name='rsa_name' />
                                <attribute name='createdon' />
                                <attribute name='rsa_pl' />
                                <attribute name='rsa_description' />
                                <attribute name='rsa_lineofbusiness' />
                                <attribute name='rsa_classofbusinessid' />
                                <order attribute='rsa_name' descending='false' />
                                <filter type='and'>
                                <condition attribute='rsa_policytype' operator='eq' uitype='rsa_policytype' value='{0}' />
                                <condition attribute='rsa_name' operator='eq' value='{2}' />
                                </filter>
                                <link-entity name='rsa_pl' from='rsa_plid' to='rsa_pl' link-type='inner' alias='ac'>
                                <filter type='and'>
                                <condition attribute='rsa_name' operator='eq' value='{1}' />
                                </filter>
                                </link-entity>
                                </entity>
                                </fetch>";

                                //modified : 18 oct 22 ; Nida ; Defect : TFS 530 : Invalid Xml for d&O cob name
                                //modified : 19 oct 22 ; Shravani ; TFS 666 : Invalid xml for P&L
                                EntityCollection PolicyCollection = service.RetrieveMultiple(new FetchExpression(String.Format(fetchCOBfromPolicy, policytype, WebUtility.HtmlEncode(pl), WebUtility.HtmlEncode(classOfBusinessName))));


                                if (PolicyCollection.Entities.Count > 0)

                                {

                                    foreach (var cob in PolicyCollection.Entities)

                                    {

                                        COBId = cob.Id;

                                        tracer.Trace("COBId" + COBId);

                                        //COBID to be override

                                        break;

                                    }

                                }



                            }

                            if (PolicyData.Attributes.Contains("rsa_premium") && PolicyData.GetAttributeValue<Money>("rsa_premium") != null) //bug 2212 Case not saving for MTA

                            {

                                PolicybasePremium = Convert.ToDecimal(PolicyData.GetAttributeValue<Money>("rsa_premium").Value);

                            }

                        }

                    }
                    tracer.Trace("Class of Business Name " + classOfBusinessName);
                    string branchtoSkipCAR = string.Empty;
                    //Chandani: 25/01/2023: Add code to set flag
                    #region check whether Branch is old or new
                    bool isCOBOld = true;
                    string strClassofBusinessNew = string.Empty;
                    Entity CLBranchCARS = GetCustomLabel(service, tracer, "CL_Branch_CARS_OLD");
                    if (CLBranchCARS != null)
                    {
                        if (CLBranchCARS.Attributes.Contains("rsa_dependentoptionsetjson"))
                        {
                            branchtoSkipCAR = CLBranchCARS.Attributes["rsa_dependentoptionsetjson"].ToString();
                        }
                        string strBranchOld = string.Empty;
                        if (CLBranchCARS.Attributes.Contains("rsa_values"))
                        {
                            strBranchOld = CLBranchCARS.Attributes["rsa_values"].ToString();
                        }

                        tracer.Trace("Get Custom Label CL_Branch_CARS_OLD " + strBranchOld);
                        if (!string.IsNullOrEmpty(strBranchOld) && !strBranchOld.ToLower().Contains(branchAccount.ToLower()))
                        {
                            Entity CLClassofBusinessNew = GetCustomLabel(service, tracer, "CL_COB_CARS_NEW");
                            if (CLClassofBusinessNew != null)
                            {

                                if (CLClassofBusinessNew.Attributes.Contains("rsa_values"))
                                {
                                    strClassofBusinessNew = CLClassofBusinessNew.Attributes["rsa_values"].ToString();
                                }

                                tracer.Trace("Get Custom Label CL_COB_CARS_NEW " + strClassofBusinessNew);
                                if (!string.IsNullOrEmpty(strClassofBusinessNew) && strClassofBusinessNew.ToLower().Contains(classOfBusinessName.ToLower()))
                                {
                                    tracer.Trace("Inside New Branch: isCOBOld: False");
                                    isCOBOld = false;
                                }
                                else
                                {
                                    isCOBOld = true;
                                }
                            }

                        }
                        else if (string.IsNullOrEmpty(strBranchOld))
                        {
                            tracer.Trace("Inside strBranchOld empty: isCOBOld: False");
                            isCOBOld = false;
                        }
                        else if (branchAccount == string.Empty)
                        {
                            tracer.Trace("Inside Broker Branch is blank : isCOBOld: False");
                            isCOBOld = false;
                        }
                        else
                        {
                            tracer.Trace("Inside Else : isCOBOld: true");
                            isCOBOld = true;
                        }
                    }

                    #endregion


                    //bool newCOB = false;
                    //#region check whether Branch is old or new
                    //string strBranchOld = GetCustomLabel(service, tracer, "CL_Branch_CARS_OLD");
                    //tracer.Trace("Get Custom Label CL_Branch_CARS_OLD " + strBranchOld);
                    //if (!string.IsNullOrEmpty(strBranchOld) && !strBranchOld.Contains(branchAccount))
                    //{
                    //    string strClassofBusinessNew = GetCustomLabel(service, tracer, "CL_COB_CARS_NEW");
                    //    tracer.Trace("Get Custom Label CL_COB_CARS_NEW " + strClassofBusinessNew);
                    //    if (!string.IsNullOrEmpty(strClassofBusinessNew) && strClassofBusinessNew.Contains(classOfBusinessName))
                    //    {
                    //        tracer.Trace("Inside New Branch: newCOB: True");
                    //        newCOB = true;
                    //    }
                    //}
                    //else if (string.IsNullOrEmpty(strBranchOld))
                    //{
                    //    tracer.Trace("Inside Branch empty: newCOB: True");
                    //    newCOB = true;
                    //}
                    //#endregion

                    if (caseEntity.Attributes.Contains("rsa_casetype"))
                    {
                        objCaseRecordType = caseEntity.Contains("rsa_casetype") ? caseEntity.GetAttributeValue<EntityReference>("rsa_casetype") : null;
                        if (objCaseRecordType != null)
                        {
                            var recordtypeLookup = service.Retrieve(objCaseRecordType.LogicalName, objCaseRecordType.Id, new ColumnSet("rsa_casetypecode", "rsa_casetype"));
                            caseRecordType = recordtypeLookup.Contains("rsa_casetypecode") ? recordtypeLookup.GetAttributeValue<int>("rsa_casetypecode") : -1;
                            caseTypeName = recordtypeLookup.Contains("rsa_casetype") ? recordtypeLookup.GetAttributeValue<string>("rsa_casetype").ToLower() : null;
                        }
                    }
                    tracer.Trace("caseRecordType " + caseRecordType);

                    //premiumCode not present in DataModel in Case Entity
                    //premiumCode = "7";

                    if (caseEntity.Attributes.Contains("rsa_basepremiumrsa"))
                    {
                        basePremium = Convert.ToDecimal(caseEntity.GetAttributeValue<decimal>("rsa_basepremiumrsa"));
                    }
                    if (basePremium == 0.00M && caseEntity.Attributes.Contains("rsa_opportunityid") && caseEntity.Attributes.Contains("rsa_casetype"))
                    {
                        EntityReference caseTypereference = caseEntity.Attributes.Contains("rsa_casetype") ? (EntityReference)caseEntity.Attributes["rsa_casetype"] : null;
                        if (caseTypereference.Name.ToLower().Equals("new business"))
                        {
                            EntityReference opportunityId = caseEntity.Attributes.Contains("rsa_opportunityid") ? (EntityReference)caseEntity.Attributes["rsa_opportunityid"] : null;
                            Opportunity = service.Retrieve(opportunityId.LogicalName, opportunityId.Id, new ColumnSet(new string[] { "rsa_calcutatedpremium", "rsa_targetpremium" }));
                            var calculatedpremium = Opportunity.Attributes.Contains("rsa_calcutatedpremium") ? ((OptionSetValue)Opportunity.Attributes["rsa_calcutatedpremium"]).Value : 0.00M;
                            var oppTargerPremium = Opportunity.Attributes.Contains("rsa_targetpremium") ? (decimal)Opportunity.Attributes["rsa_targetpremium"] : 0.00M;
                            if (caseTypereference.Name.ToLower().Equals("new business") && (oppTargerPremium == 0 || oppTargerPremium == null))
                            {
                                switch (calculatedpremium.ToString())
                                {
                                    case "866760000":
                                        basePremium = 1000.00M;
                                        break;
                                    case "866760001":
                                        basePremium = 5000.00M;
                                        break;
                                    case "866760002":
                                        basePremium = 5000.01M;
                                        break;
                                    case "866760003":
                                        basePremium = 10000.00M;
                                        break;
                                    case "866760004":
                                        basePremium = 15000.00M;
                                        break;
                                    case "866760005":
                                        basePremium = 15000.01M;
                                        break;
                                    case "866760006":
                                        basePremium = 25000.00M;
                                        break;
                                    case "866760007":
                                        basePremium = 50000.00M;
                                        break;
                                    case "866760008":
                                        basePremium = 100000.00M;
                                        break;
                                    case "866760009":
                                        basePremium = 250000.00M;
                                        break;
                                    case "866760010":
                                        basePremium = 500000.00M;
                                        break;
                                    case "866760011":
                                        basePremium = 1000000.00M;
                                        break;
                                    case "866760012":
                                        basePremium = 1000000.01M;
                                        break;
                                    default:
                                        break;
                                }
                            }
                            else if (caseTypereference.Name.ToLower().Equals("new business") && (oppTargerPremium != 0))
                            {
                                basePremium = oppTargerPremium;
                            }
                        }
                    }

                    if (basePremium == 0.00M && caseEntity.Attributes.Contains("rsa_policyid"))
                    {
                        var PolicyGiud = caseEntity.Attributes.Contains("rsa_policyid") ? (EntityReference)caseEntity.Attributes["rsa_policyid"] : null;
                        Entity PolicyData = service.Retrieve(PolicyGiud.LogicalName, PolicyGiud.Id, new ColumnSet(new string[] { "rsa_premium" }));
                        basePremium = PolicyData.Attributes.Contains("rsa_premium") ? Convert.ToDecimal(PolicyData.GetAttributeValue<Money>("rsa_premium").Value) : 0.00M;

                        //string FetchXML = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                        //          <entity name='rsa_policy'>
                        //            <attribute name='rsa_policyid' />
                        //            <attribute name='rsa_name' />
                        //            <attribute name='rsa_premium' />
                        //            <order attribute='rsa_name' descending='false' />
                        //            <filter type='and'>
                        //              <condition attribute='rsa_policyid' operator='eq' uiname='0000847A7EC4' uitype='rsa_policy' value='" + PolicyGiud.Id + @"' />
                        //            </filter>
                        //          </entity>
                        //        </fetch>";
                        //EntityCollection policyPremiumColl = service.RetrieveMultiple(new FetchExpression(FetchXML));

                        //if (policyPremiumColl.Entities.Count > 0 && policyPremiumColl.Entities[0].Contains("rsa_premium"))
                        //{
                        //    basePremium = Convert.ToDecimal(policyPremiumColl.Entities[0].GetAttributeValue<Money>("rsa_premium"));
                        //}
                    }

                    // if base premium is 0.00 then fetch from policy rsa_premi
                    tracer.Trace("basePremium " + basePremium);
                    //Modified On 03-08-2022 ;By : Nida ; Des: CR2642 handles Standard and BPW scenario in 1 logic hence commented below
                    //Modified On 14-10-2022 ;By : Nida ; Des:removed commented code
                    tracer.Trace("CaseAllocationRuleAddCasetoQueue- QueryExpression");
                    //Query Expression to find matching record of Case Allocation Rule with Case
                    QueryExpression query = new QueryExpression("rsa_caseallocationrules");
                    query.ColumnSet = new ColumnSet("rsa_queue", "rsa_name");
                    query.NoLock = true;

                    FilterExpression filter = new FilterExpression(LogicalOperator.And);

                    //Defect: 1717 Added code to consider blank branch in CAR
                    tracer.Trace("Started with JSONCode ");
                    var branchOptionsetRoot = new BranchJSONRoot();
                    var ms = new MemoryStream(Encoding.UTF8.GetBytes(branchtoSkipCAR));
                    tracer.Trace("branchtoSkipCAR " + branchtoSkipCAR);
                    try
                    {
                        tracer.Trace("in Try block ");
                        var ser = new DataContractJsonSerializer(branchOptionsetRoot.GetType());
                        tracer.Trace("in Try block set ser");
                        branchOptionsetRoot = ser.ReadObject(ms) as BranchJSONRoot;
                        tracer.Trace("in Try block set branchOptionsetRoot");
                    }
                    catch (Exception ex)
                    {
                        throw new InvalidPluginExecutionException(ex.Message);
                    }
                    finally
                    {
                        ms.Close();
                    }
                    tracer.Trace("Set branchMap");
                    
                    string[] strBranchCode = { "Birmingham", "Bristol", "Cardiff", "Edinburgh", "Glasgow", "Horsham", "Ipswich", "Leeds", "Leicester", "London", "Manchester", "Redhill" };


                    BranchJSON branchMap = new BranchJSON();
                    bool branchEmpty = false;
                    tracer.Trace("After Set branchMap");
                    foreach (var item in branchOptionsetRoot.BranchJSON)
                    {
                        if (item.COB.ToLower().Contains(classOfBusinessName.ToLower()) && item.RecordType.ToLower().Contains(caseTypeName.ToLower()))
                        {
                            branchEmpty = true;
                            //TFS 2048: Check if branch is Engineering and consider as new CAR
                            isCOBOld = false;
                        }
                    }
                    //if (branchEmpty == true && isCOBOld == false)
                    if (branchEmpty == true && !((caseTypeName.ToLower().Contains("renewal") || caseTypeName.ToLower().Contains("query")
                                || caseTypeName.ToLower().Contains("mid-term adjustment")) && classOfBusinessName.ToLower().Contains("blocks of flats")))
                    {
                        filter.Conditions.Add(new ConditionExpression("rsa_branch", ConditionOperator.Null));
                        tracer.Trace("branchAccount skipped as classOfBusinessName" + classOfBusinessName + " caseTypeName " + caseTypeName);
                    }
                    //sumegh dhole : 11 Oct 2021 :
                    //check if the branch has data else handle it for defect id 2193
                    else if (!string.IsNullOrEmpty(branchAccount) && caseTypeName != "bes referral" && !((caseTypeName.ToLower().Contains("renewal") || caseTypeName.ToLower().Contains("query")
                                || caseTypeName.ToLower().Contains("mid-term adjustment")) && classOfBusinessName.ToLower().Contains("blocks of flats")))
                    {                       
                        tracer.Trace("branchAccounte " + branchAccount);
                        if (!string.IsNullOrEmpty(branchAccount) && caseTypeName.ToLower().Contains("mid-term adjustment") &&
                         classOfBusinessName.ToLower().Contains("motor fleet") && basePremium <= 20000)
                        {
                            filter.Conditions.Add(new ConditionExpression("rsa_branch", ConditionOperator.Null)); //1124
                        }
                        else if (!string.IsNullOrEmpty(branchAccount) && caseTypeName.ToLower().Contains("mid-term adjustment") &&
                            classOfBusinessName.ToLower().Contains("motor fleet") && basePremium > 20000 && !strBranchCode.Contains(branchAccount))
                        {
                            filter.Conditions.Add(new ConditionExpression("rsa_branch", ConditionOperator.Null)); //1124
                        }
                        else
                        {
                            filter.Conditions.Add(new ConditionExpression("rsa_branch", ConditionOperator.Equal, branchAccount)); 
                        }
                    }
                    else if(!((caseTypeName.ToLower().Contains("renewal") || caseTypeName.ToLower().Contains("query")
                                || caseTypeName.ToLower().Contains("mid-term adjustment")) && classOfBusinessName.ToLower().Contains("blocks of flats")))
                    {
                        filter.Conditions.Add(new ConditionExpression("rsa_branch", ConditionOperator.Null));
                        tracer.Trace("branchAccount does not contain data " + branchAccount);
                    }
                    //sumegh dhole : 11 Oct 2021 : 
                    //check if the branch has data else handle it for defect id 2193
                    //Chandani: 25/01/2023: To handle old Branch CARs
                    if (isCOBOld == true)
                    {
                        if (!string.IsNullOrEmpty(distributionCategory))
                        {
                            filter.Conditions.Add(new ConditionExpression("rsa_distributioncategory", ConditionOperator.Equal, distributionCategory));
                            tracer.Trace("distributionCategory " + distributionCategory);
                        }
                        else
                        {
                            filter.Conditions.Add(new ConditionExpression("rsa_distributioncategory", ConditionOperator.Null));
                            tracer.Trace("distributionCategory does not contain data " + distributionCategory);
                        }
                    }

                    //Modified On 04-08-2022 ;By : Nida ; Des: CR2642 
                    //Modified on 12-08-2022 ;By : Nida ; Des: CR2642- Bug314
                    //Modified on 17-08-2022 ;By : Nida ; Des: CR2642- Bug317
                    //Modified on 14-10-2022 ;By : Nida ; Des: issue 2444 and 2642
                    int isBpw = 0;
                    bool isBpwyes = false;

                    tracer.Trace("isBpw" + isBpw);
                    tracer.Trace("Range =" + basePremium + "COB=" + classOfBusinessName + "ISBPW==" + isBpwyes + "caseTypeName=" + caseTypeName + "isCOBOld=" + isCOBOld + "strClassofBusinessNews==" + strClassofBusinessNew);
                    PremiumRange range = GetPremiumRange(service, tracer, basePremium, classOfBusinessName, isBpwyes, caseTypeName, isCOBOld, strClassofBusinessNew);
                    Entity CLBPW = GetCustomLabel(service, tracer, "CL_BPW_CARS_NEW");
                    string BPWString = string.Empty;
                    bool isBPWApplicable = false;
                    if (CLBPW != null)
                    {
                        if (CLBPW.Attributes.Contains("rsa_dependentoptionsetjson"))
                        {
                            BPWString = CLBPW.Attributes["rsa_dependentoptionsetjson"].ToString();
                            var isBPWRoot = new BPWJsonRoot();
                            var msBPW = new MemoryStream(Encoding.UTF8.GetBytes(BPWString));
                            tracer.Trace("BPWString " + BPWString);
                            try
                            {
                                tracer.Trace("in Try block ");
                                var ser = new DataContractJsonSerializer(isBPWRoot.GetType());
                                tracer.Trace("in Try block set ser");
                                isBPWRoot = ser.ReadObject(msBPW) as BPWJsonRoot;
                                tracer.Trace("in Try block set isBPWRoot");
                            }
                            catch (Exception ex)
                            {
                                throw new InvalidPluginExecutionException(ex.Message);
                            }
                            finally
                            {
                                msBPW.Close();
                            }
                            tracer.Trace("Set BPWMap");
                            BPWJSON BPWMap = new BPWJSON();
                            tracer.Trace("After Set BPWMap");
                            foreach (var item in isBPWRoot.BPWJSON)
                            {
                                tracer.Trace("ForEach Loop from CL: Classof Business:" + item.COB.ToLower() + "PremiumValue:" + item.PremiumValue);
                                tracer.Trace("ForEach Loop from Case: Classof Business:" + classOfBusinessName + "PremiumValue:" + range.PremiumRangeCode);
                                if (item.COB.ToLower().Contains(classOfBusinessName.ToLower()) && item.PremiumValue.ToLower().Equals(range.PremiumRangeCode.ToLower()))
                                {
                                    isBPWApplicable = true;
                                    tracer.Trace("isBPWApplicable :" + isBPWApplicable);
                                    ///break;
                                }
                            }
                        }
                    }
                    if (caseTypeName.ToLower().Contains("bes referral"))
                    {
                        filter.Conditions.Add(new ConditionExpression("rsa_policywording", ConditionOperator.Null));
                        filter.Conditions.Add(new ConditionExpression("rsa_premiumcode", ConditionOperator.Null));
                    }
                    else
                    {
                        

                        if (isCOBOld == false)
                        {
                            if (product.ToLower().Contains("professional insured select"))
                            {
                                tracer.Trace("scheme team queue");
                                filter.Conditions.Clear();
                                filter.Conditions.Add(new ConditionExpression("rsa_branch", ConditionOperator.Null));
                                filter.Conditions.Add(new ConditionExpression("rsa_policywording", ConditionOperator.Null));
                                filter.Conditions.Add(new ConditionExpression("rsa_premiumcode", ConditionOperator.Null));
                            }
                            else if (isBPWApplicable == true)
                            {
                                tracer.Trace("isBPWapplicable true");
                                isBpw = GetBPWFlag(service, tracer, brokerId);
                                //if (isBpw != 0)
                                //{
                                //    isBpwyes = true;
                                //    filter.Conditions.Add(new ConditionExpression("rsa_policywording", ConditionOperator.Equal, isBpw));

                                //    tracer.Trace("rsa_policywording added " + isBpw);
                                //}
                                //else
                                //{
                                //    filter.Conditions.Add(new ConditionExpression("rsa_policywording", ConditionOperator.Null));
                                //    tracer.Trace("rsa_policywording not added " + isBpw);
                                //}
                                filter.Conditions.Add(new ConditionExpression("rsa_premiumcode", ConditionOperator.Equal, range.PremiumRangeCode));
                            }
                            else if (branchEmpty == true && !classOfBusinessName.ToLower().Contains("blocks of flats"))
                            {
                                tracer.Trace("rsa_policywording and rsa_premiumcode condition skipped as BranchEmpty condition true");
                                filter.Conditions.Add(new ConditionExpression("rsa_policywording", ConditionOperator.Null));
                                filter.Conditions.Add(new ConditionExpression("rsa_premiumcode", ConditionOperator.Null));
                            }
                            else if (caseTypeName.ToLower().Contains("new business") || classOfBusinessName.ToLower().Contains("profin"))
                            {
                                tracer.Trace("rsa_policywording and rsa_premiumcode condition skipped as Case Type New Business");
                                filter.Conditions.Add(new ConditionExpression("rsa_policywording", ConditionOperator.Null));
                                filter.Conditions.Add(new ConditionExpression("rsa_premiumcode", ConditionOperator.Null));
                            }
                            //Tfs 2787
                            else if (caseTypeName.ToLower().Contains("renewal") && branchAccount.ToLower().Contains("iom"))
                            {
                                tracer.Trace("rsa_policywording and rsa_premiumcode condition skipped as Case Type Renewal");
                                filter.Conditions.Add(new ConditionExpression("rsa_policywording", ConditionOperator.Null));
                                filter.Conditions.Add(new ConditionExpression("rsa_premiumcode", ConditionOperator.Null));
                            }
                            ////////
                            ///
                            else if ((caseTypeName.ToLower().Contains("renewal") || caseTypeName.ToLower().Contains("query")
                               || caseTypeName.ToLower().Contains("mid-term adjustment")) && classOfBusinessName.ToLower().Contains("blocks of flats") && string.IsNullOrEmpty(branchAccount))
                            {
                                tracer.Trace("when branch code null");
                                filter.Conditions.Add(new ConditionExpression("rsa_policywording", ConditionOperator.Null));
                                filter.Conditions.Add(new ConditionExpression("rsa_premiumcode", ConditionOperator.Null));
                                filter.Conditions.Add(new ConditionExpression("rsa_branch", ConditionOperator.Null));
                            }
                            else if ((caseTypeName.ToLower().Contains("renewal") || caseTypeName.ToLower().Contains("query")
                              || caseTypeName.ToLower().Contains("mid-term adjustment")) && classOfBusinessName.ToLower().Contains("blocks of flats") && !strBranchCode.Contains(branchAccount))
                            {
                                tracer.Trace("When brach code does not conains in given array");
                                filter.Conditions.Add(new ConditionExpression("rsa_policywording", ConditionOperator.Null));
                                filter.Conditions.Add(new ConditionExpression("rsa_premiumcode", ConditionOperator.Null));
                                filter.Conditions.Add(new ConditionExpression("rsa_branch", ConditionOperator.Null));
                            }
                            else if ((caseTypeName.ToLower().Contains("renewal") || caseTypeName.ToLower().Contains("query") 
                                || caseTypeName.ToLower().Contains("mid-term adjustment")) && classOfBusinessName.ToLower().Contains("blocks of flats") && basePremium >= 50000)
                            {
                                tracer.Trace("rsa_policywording and rsa_premiumcode condition skipped for premium amount >=50000");
                                filter.Conditions.Add(new ConditionExpression("rsa_policywording", ConditionOperator.Null));
                                filter.Conditions.Add(new ConditionExpression("rsa_premiumcode", ConditionOperator.Equal,18));
                                filter.Conditions.Add(new ConditionExpression("rsa_branch", ConditionOperator.Equal, branchAccount));
                            }
                            else if ((caseTypeName.ToLower().Contains("renewal") || caseTypeName.ToLower().Contains("query") 
                                || caseTypeName.ToLower().Contains("mid-term adjustment")) && classOfBusinessName.ToLower().Contains("blocks of flats") && basePremium < 50000)
                            {
                                tracer.Trace("rsa_policywording and rsa_premiumcode condition skipped as Case Type Renewal");
                                filter.Conditions.Add(new ConditionExpression("rsa_policywording", ConditionOperator.Null));
                                filter.Conditions.Add(new ConditionExpression("rsa_premiumcode", ConditionOperator.Null));
                            }

                            else if (caseTypeName.ToLower().Contains("bes referral"))
                            {
                                filter.Conditions.Add(new ConditionExpression("rsa_policywording", ConditionOperator.Null));
                                filter.Conditions.Add(new ConditionExpression("rsa_premiumcode", ConditionOperator.Null));
                            }                            
                            else
                            {
                                tracer.Trace("rsa_policywording and rsa_premiumcode condition skipped");
                                filter.Conditions.Add(new ConditionExpression("rsa_policywording", ConditionOperator.Null));
                                //filter.Conditions.Add(new ConditionExpression("rsa_premiumcode", ConditionOperator.Null));
                                filter.Conditions.Add(new ConditionExpression("rsa_premiumcode", ConditionOperator.Equal, range.PremiumRangeCode));
                            }
                        }
                        else
                        {
                            tracer.Trace("rsa_policywording" + range.ValidCOB);
                            if (range.ValidCOB)
                            {
                                isBpw = GetBPWFlag(service, tracer, brokerId);
                                if (isBpw != 0)
                                {
                                    isBpwyes = true;
                                    filter.Conditions.Add(new ConditionExpression("rsa_policywording", ConditionOperator.Equal, isBpw));

                                    tracer.Trace("rsa_policywording added " + isBpw);
                                }
                                else
                                {
                                    filter.Conditions.Add(new ConditionExpression("rsa_policywording", ConditionOperator.Null));
                                    tracer.Trace("rsa_policywording not added " + isBpw);
                                }
                                filter.Conditions.Add(new ConditionExpression("rsa_premiumcode", ConditionOperator.Equal, range.PremiumRangeCode));
                                tracer.Trace("Premium Code" + range.PremiumRangeCode);
                            }
                            ///if CaseType ,Branch and DistributionCategory exist then it check JSOn else added condition
                            else
                            {
                                if (!string.IsNullOrWhiteSpace(caseTypeName) && !string.IsNullOrWhiteSpace(branchAccount) && !string.IsNullOrWhiteSpace(distributionCategory))
                                {
                                    ///if CaseType = NB,renewal,MTA,Query
                                    if (caseTypeName.ToLower().Contains("query")
                                        || caseTypeName.ToLower().Contains("mid-term adjustment")
                                        || caseTypeName.ToLower().Contains("new business")
                                        || caseTypeName.ToLower().Contains("renewal"))
                                    {
                                        if (COBId != null && COBId != Guid.Empty)
                                        {

                                            tracer.Trace("COBId " + COBId);
                                            tracer.Trace("caseTypeName" + caseTypeName);
                                            tracer.Trace("branchAccount" + branchAccount);
                                            tracer.Trace("distributionCategory" + distributionCategory);
                                            bool IgnorePremiumCodeValue = false;
                                            bool IgnorePolicyScheme = false;
                                            tracer.Trace("Before GetCARConfigurtaionValue");
                                            Dictionary<string, bool> confList = GetCARConfigurtaionValue(service, tracer, COBId, caseTypeName, branchAccount, distributionCategory);
                                            tracer.Trace("After Calling GetCARConfigurtaionValue" + confList.Count);
                                            if (confList != null && confList.Count > 0)
                                            {

                                                if (confList.ContainsKey("IgnorePolicyScheme"))
                                                {
                                                    IgnorePolicyScheme = confList["IgnorePolicyScheme"];
                                                    tracer.Trace("PolicySchema: " + IgnorePolicyScheme);
                                                }


                                                if (confList.ContainsKey("IgnorePremiumCode"))
                                                {
                                                    IgnorePremiumCodeValue = confList["IgnorePremiumCode"];
                                                    tracer.Trace("Premium Code: " + IgnorePremiumCodeValue);
                                                }

                                                if (IgnorePremiumCodeValue != false)
                                                {
                                                    filter.Conditions.Add(new ConditionExpression("rsa_premiumcode", ConditionOperator.Equal, range.PremiumRangeCode));
                                                    tracer.Trace("Premium Code " + range.PremiumRangeCode);
                                                    tracer.Trace("Added condition for Premium Code to retrive CAR");
                                                }
                                                //Chandani: 25/01/2023: To handle old Branch
                                                if (isCOBOld == true)
                                                {
                                                    if (IgnorePolicyScheme != false)
                                                    {
                                                        filter.Conditions.Add(new ConditionExpression("rsa_policyscheme", ConditionOperator.Equal, scheme));
                                                        tracer.Trace("scheme " + scheme);
                                                        tracer.Trace("Added condition for scheme to retrive CAR");
                                                    }
                                                }
                                            }
                                            else //if no JSon Record found then add condition PremiumCode and PolicySchemee as per process
                                            {   //to handle code for invalid cob
                                                FilterExpression premiumCodeFilter = new FilterExpression(LogicalOperator.Or);
                                                ConditionExpression premiumCodeCondforNull = new ConditionExpression("rsa_premiumcode", ConditionOperator.Null);
                                                ConditionExpression premiumCodeCond = new ConditionExpression("rsa_premiumcode", ConditionOperator.Equal, range.PremiumRangeCode);
                                                premiumCodeFilter.AddCondition(premiumCodeCondforNull);
                                                premiumCodeFilter.AddCondition(premiumCodeCond);
                                                //filter.Conditions.Add(new ConditionExpression("rsa_premiumcode", ConditionOperator.Null));
                                                //filter.Conditions.Add(new ConditionExpression("rsa_premiumcode", ConditionOperator.Equal, range.PremiumRangeCode));
                                                filter.AddFilter(premiumCodeFilter);
                                                tracer.Trace("Premium Code " + range.PremiumRangeCode);
                                                tracer.Trace("No COnfiguration : pass null code/ premiumcode to retrive CAR");
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    filter.Conditions.Add(new ConditionExpression("statecode", ConditionOperator.Equal, 0));
                    //Sumegh Dhole 13 Oct 2020 : Add the check for the class of business data types
                    // if (classOfBusinessId != Guid.Empty)
                    //     filter.Conditions.Add(new ConditionExpression("rsa_classofbusiness", ConditionOperator.Equal, classOfBusinessId));
                    ///big 1155 unwanted CAR being triggered.
                    //if (!string.IsNullOrWhiteSpace(classOfBusinessName))
                    //{}
                    //Chandani: 25/01/2023: Code update to check COB text field. Commeneted below line of code
                    //LinkEntity cobLink = query.AddLink("rsa_classofbusiness", "rsa_classofbusiness", "rsa_classofbusinessid");

                    //Bug 1247 
                    if (classOfBusinessName == null)
                    {
                        classOfBusinessName = string.Empty;
                    }
                    filter.Conditions.Add(new ConditionExpression("rsa_classofbusinesstext", ConditionOperator.Equal, classOfBusinessName));
                    //Chandani: 25/01/2023: Commeneted below line of code
                    //cobLink.LinkCriteria.AddCondition("rsa_name", ConditionOperator.Equal, classOfBusinessName);
                    // filter.Conditions.Add(new ConditionExpression("rsa_classofbusinessname", ConditionOperator.BeginsWith, classOfBusinessName));
                    tracer.Trace("classOfBusinessName " + classOfBusinessName);

                    if (caseRecordType != 1)
                    {
                        filter.Conditions.Add(new ConditionExpression("rsa_recordtype", ConditionOperator.ContainValues, caseRecordType));
                    }

                    tracer.Trace("caseRecordType " + caseRecordType);
                    //2444 Add Acive status on condition 
                    // filter.Conditions.Add(new ConditionExpression("statuscode", ConditionOperator.Equal, 1));
                    //Defect 2624
                    // tracer.Trace(" myfetchxml " + myfetchxml);
                    query.Criteria = filter;
                    #region Convert Query Expression to FetchXML
                    QueryExpressionToFetchXmlRequest reqFetch = new QueryExpressionToFetchXmlRequest();
                    reqFetch.Query = query;
                    QueryExpressionToFetchXmlResponse respFetch = (QueryExpressionToFetchXmlResponse)service.Execute(reqFetch);
                    //tracer.Trace(" myfetchxml " + myfetchxml);
                    //work with newly formed fetch string
                    string myfetchxml = respFetch.FetchXml;
                    tracer.Trace(" myfetchxml " + myfetchxml);
                    #endregion

                    EntityCollection retrievedDetails = (EntityCollection)service.RetrieveMultiple(query);
                    tracer.Trace("CaseAllocationRuleAddCasetoQueue- Query" + retrievedDetails.Entities.Count);
                    tracer.Trace("CaseAllocationRuleAddCasetoQueue- Retrieved Details" + retrievedDetails.Entities.Count);
                    Guid statusID = Guid.Empty;
                    if (retrievedDetails.Entities.Count > 0)
                    {
                        tracer.Trace("CaseAllocationRuleAddCasetoQueue- Count >0 Details");
                        //Apply Foreach
                        foreach (var item in retrievedDetails.Entities)
                        {//bug 1025 changing the case status to in progress
                            if (caseTypeName.Equals("Query") || caseTypeName.Equals("revised renewal") || caseTypeName.Equals("mid-term adjustment"))
                            {
                                //Ramesh Y Bug No : 2318
                                tracer.Trace("In progress ID");
                                CaseAssignAction obj = new CaseAssignAction(_unsecureString);
                                tracer.Trace("In progress ID");//
                                statusID = obj.GetLookUpDetailsbyText(service, "In Progress", "rsa_status", objCaseRecordType.Id).Id;
                                context.SharedVariables["rsa_status"] = statusID.ToString();
                                tracer.Trace(context.SharedVariables["rsa_status"].ToString());
                                tracer.Trace("In progress ID" + statusID);
                                //caseEntity["rsa_status"] = new EntityReference("rsa_status", statusID);
                                //caseEntity.Id = caseEntity.Id;
                                //service.Update(caseEntity);
                            }
                            tracer.Trace("CaseAllocationRuleAddCasetoQueue- Setting Queue CAR Name : " + item.Attributes["rsa_name"]);
                            if (item.Attributes.Contains("rsa_queue"))
                            {
                                tracer.Trace("Inprogress status" + ((EntityReference)item.Attributes["rsa_queue"]).Name);
                                tracer.Trace("CaseAllocationRuleAddCasetoQueue- Setting Queue");
                                //Query Expression to find matching record of Case Allocation Rule with Case
                                AddToQueueRequest routeRequest = new AddToQueueRequest
                                {

                                    Target = new EntityReference("incident", caseEntity.Id),
                                    DestinationQueueId = ((EntityReference)item.Attributes["rsa_queue"]).Id
                                    //DestinationQueueId = ((EntityReference)retrievedDetails[0].Attributes["rsa_queuelookup"]).Id
                                };
                                tracer.Trace("Inprogress status");

                                service.Execute(routeRequest);
                            }
                            //Nida: 14 June 2022 :depth commented for 2511 task creation issue
                            ABRLogic objABRLogic = new ABRLogic();
                            objABRLogic.updateCaseABRStatus(service, caseEntity, tracer, 866760003, statusID);
                            //If more than record with matching criteria, continue
                            //Sumegh Dhole: 15 Oct 2020 : Consider only top one matching criteria. 
                            break;
                            //continue;
                        }
                        tracer.Trace("CaseAllocationRuleAddCasetoQueue- End");
                    }

                }
                catch (Exception ex)
                {
                    tracer.Trace("CaseAllocationRuleAddCasetoQueue-Error" + ex.Message.ToString());
                    throw new InvalidPluginExecutionException("An error occurred in the CaseAllocationRuleAddCasetoQueue plug-in" + ex.Message.ToString());
                }
            }
        }
        public Dictionary<string, bool> GetCARConfigurtaionValue(IOrganizationService service, ITracingService tracer, Guid COBId, string recordTypeName, string branchName, string distributionCategory)
        {
            Dictionary<string, bool> carConfList = new Dictionary<string, bool>();
            try
            {

                Entity eclassOfBusiness = service.Retrieve("rsa_classofbusiness", COBId, new ColumnSet("rsa_carconditionalconfiguration"));
                string carConditionalConfiguration = string.Empty;
                carConditionalConfiguration = eclassOfBusiness.Attributes.Contains("rsa_carconditionalconfiguration") ? ((string)eclassOfBusiness.Attributes["rsa_carconditionalconfiguration"]) : string.Empty;
                //   tracer.Trace("carConditionalConfiguration:  " + carConditionalConfiguration);
                tracer.Trace("GetCARConfigurtaionValue Starting");
                if (!string.IsNullOrWhiteSpace(carConditionalConfiguration))
                {
                    var car = new CARConfiguration();
                    var ms = new MemoryStream(Encoding.UTF8.GetBytes(carConditionalConfiguration));
                    var ser = new DataContractJsonSerializer(car.GetType());
                    car = ser.ReadObject(ms) as CARConfiguration;
                    ms.Close();

                    tracer.Trace("GetCARConfigurtaionValue-COBId: " + COBId);
                    tracer.Trace("GetCARConfigurtaionValue-recordTypeName: " + recordTypeName);
                    tracer.Trace("GetCARConfigurtaionValue-branchName: " + branchName);
                    tracer.Trace("GetCARConfigurtaionValue-distributionCategory: " + distributionCategory);

                    if (car != null)
                    {
                        tracer.Trace("GetCARConfigurtaionValue-Inside CAR");
                        if (car.ConditionalCARConfig != null)
                        {
                            tracer.Trace("GetCARConfigurtaionValue-ConditionalCARConfig: " + car.ConditionalCARConfig.Count());

                            var recordType = car.ConditionalCARConfig.FirstOrDefault(x => x.RecordTypeName.ToLower() == recordTypeName.ToLower());

                            if (recordType != null)
                            {


                                var branch = recordType.RecordTypeDetails.FirstOrDefault(x => x.Branch.ToLower() == branchName.ToLower());

                                if (branch != null)
                                {
                                    var disCat = branch.BrokerDetails.FirstOrDefault(d => d.DistributionCategory.ToLower() == distributionCategory.ToLower());

                                    if (disCat != null)
                                    {
                                        var IgnorePolicyScheme = false; var IgnorePremiumCode = false;
                                        IgnorePolicyScheme = (disCat.IgnorePolicyScheme != null) ? disCat.IgnorePolicyScheme : false;
                                        IgnorePremiumCode = (disCat.IgnorePremiumCode != null) ? disCat.IgnorePremiumCode : false;
                                        tracer.Trace("GetCARConfigurtaionValue-IgnorePremiumCode: " + IgnorePremiumCode);
                                        tracer.Trace("GetCARConfigurtaionValue-IgnorePolicyScheme: " + IgnorePolicyScheme);

                                        // adding elements
                                        carConfList.Add("IgnorePolicyScheme", IgnorePolicyScheme);
                                        carConfList.Add("IgnorePremiumCode", IgnorePremiumCode);
                                        tracer.Trace("Done");
                                    }


                                }
                            }

                        }
                    }
                }
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(string.Format("Error in GetCARConfigurtaionValue : {0}", ex.InnerException.Message));
            }
            return carConfList;
        }

        private PremiumRange GetPremiumRange(IOrganizationService service, ITracingService tracer, decimal premium, string cOB, bool isBPW, string caseRecordType, bool isCOBOld, string strClassofBusinessNew)
        {

            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' no-lock='true'>
                                 <entity name='rsa_premuimrange'>
                                   <attribute name = 'rsa_premuimrangeid'/>
                                   <attribute name = 'rsa_name'/>                              
                                   <attribute name='rsa_rangeid'/>
                                   <attribute name = 'rsa_lowerlimit'/>
                                   <attribute name = 'rsa_higherlimit'/>
                                   <attribute name = 'rsa_classofbusiness'/>
                                   <attribute name = 'rsa_caserecordtype'/>
    `                              <order descending = 'false' attribute = 'rsa_name'/>
                                   <filter type = 'and'>
                                   <condition attribute = 'rsa_lowerlimit' operator= 'le'  value='{0}'/>
                                   <condition attribute = 'rsa_higherlimit' operator= 'ge' value='{0}'/>
                                   </filter >
                                   </entity >
                                   </fetch >";
            EntityCollection enColpremuimrange = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, premium)));
            PremiumRange range = new PremiumRange();
            string premuimRangeId = string.Empty;
            var ClassOB = string.Empty;
            tracer.Trace("GetPremiumRange case type: " + caseRecordType + " COB: " + cOB);
            tracer.Trace("record count=" + enColpremuimrange.TotalRecordCount);

            tracer.Trace("record Entities Count=" + enColpremuimrange.Entities.Count);
            //Modified on 18-08-2022 ;By : Nida/Samiksha ; Des: CR2642- Regression Issue

            //List<Entity> enCOBRange = (enColpremuimrange.Entities.Where(a => a.Contains("rsa_classofbusiness") && cOB != null
            //&& Convert.ToString(a.Attributes["rsa_classofbusiness"]).ToLower().Contains(cOB.ToLower()) && a.Contains("rsa_caserecordtype")
            //&& caseRecordType != null && Convert.ToString(a.Attributes["rsa_caserecordtype"]).ToLower().Contains(caseRecordType.ToLower()))).ToList<Entity>();
            tracer.Trace("cOB.ToLower()=" + cOB.ToLower() + "caseRecordType.ToLower()=" + caseRecordType.ToLower());
            List<Entity> enCOBRange = (enColpremuimrange.Entities.Where(a => a.Contains("rsa_caserecordtype") && cOB != null
           && (strClassofBusinessNew.ToLower().Contains(cOB.ToLower()) || strClassofBusinessNew == string.Empty)
           && caseRecordType != null && Convert.ToString(a.Attributes["rsa_caserecordtype"]).ToLower().Contains(caseRecordType.ToLower()))).ToList<Entity>();
            tracer.Trace("record count=" + enCOBRange.Count + "Is COB Old=" + isCOBOld);
            if (enCOBRange.Count > 0 && isCOBOld == false)
            {
                for (var i = 0; i < enCOBRange.Count; i++)
                {                    

                    if (cOB.ToLower() != "combined")
                    {
                        premuimRangeId = Convert.ToString(enCOBRange[0]["rsa_rangeid"]);

                    }                      

                    if (enCOBRange[i]["rsa_classofbusiness"].ToString().ToLower().Contains(cOB.ToLower()))
                    {                                          

                        premuimRangeId = Convert.ToString(enCOBRange[i]["rsa_rangeid"]);
                        break;
                    }
                }

                //if (string.IsNullOrEmpty(premuimRangeId))
                //{
                //    tracer.Trace("for each else loop");
                //    if (cOB.ToLower() != "combined")
                //    {
                //        premuimRangeId = Convert.ToString(enCOBRange[0]["rsa_rangeid"]);                        
                //    }
                //}               

                
                // 
                range.PremiumRangeCode = premuimRangeId;
                range.ValidCOB = true;
                tracer.Trace("BPW Condition");
                tracer.Trace("range.ValidCOB" + range.ValidCOB);
                tracer.Trace("range.premuimRangeId" + premuimRangeId);
            }

            else
            {

                List<Entity> enRange = (enColpremuimrange.Entities.Where(a => a.GetAttributeValue<Money>("rsa_lowerlimit").Value <= premium
                && a.GetAttributeValue<Money>("rsa_higherlimit").Value >= premium && !a.Contains("rsa_classofbusiness")
                && !a.Contains("rsa_caserecordtype")).ToList<Entity>());
                if (enRange.Count > 0)
                {
                    enRange.ForEach(COBRange => premuimRangeId = Convert.ToString(COBRange.Attributes["rsa_rangeid"]));
                    range.PremiumRangeCode = premuimRangeId;
                    range.ValidCOB = false;
                    //range.ValidCOB = true;
                    tracer.Trace("Not a BPW Condition");
                    tracer.Trace("range.ValidCOB" + range.ValidCOB);
                }
            }


            return range;

        }

        private int GetBPWFlag(IOrganizationService service, ITracingService tracer, Guid brokerid)
        {
            int isBPWFlag = 0;

            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' no-lock='true'>
                                <entity name='rsa_agencycode'>
                                <attribute name='rsa_agencycodeid'/>
                                <attribute name='rsa_name'/>
                                <attribute name='rsa_policywording'/>
                                <attribute name='rsa_agency'/>
                                <order descending='false' attribute='rsa_name'/>
                                <filter type='and'>
                                <condition attribute='rsa_agency' operator= 'eq'  value='{0}'/>
                                <condition attribute='rsa_policywording' value='866760000' operator='eq'/>
                                </filter>
                                </entity>
                                </fetch>";

            EntityCollection enAgencyCodeCollection = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, brokerid)));


            List<Entity> enAgencyCode = (enAgencyCodeCollection.Entities.Where(a => a.Contains("rsa_agency") && a.Contains("rsa_policywording") && a.GetAttributeValue<EntityReference>("rsa_agency").Id == brokerid).ToList<Entity>());

            if (enAgencyCode.Count > 0)
            {
                enAgencyCode.ForEach(agencyCode => isBPWFlag = agencyCode.GetAttributeValue<OptionSetValue>("rsa_policywording").Value);

            }
            return isBPWFlag;

        }
        private Entity GetCustomLabel(IOrganizationService service, ITracingService tracer, string key)
        {
            Entity returnValue = null;
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' no-lock='true'>
                              <entity name='rsa_customlabel'>
                                <attribute name='rsa_values' />
                                <attribute name='rsa_shortdescription' />
                                <attribute name='rsa_categories' />   
                                <attribute name='rsa_dependentoptionsetjson'/>
                                <filter type='and'>
                                  <condition attribute='rsa_name' operator='eq' value ='{0}'/>
                                </filter>
                              </entity>
                            </fetch>";
            var entityCustomLevel = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, key)));
            if (entityCustomLevel.Entities.Count > 0)
            {
                //returnValue = entityCustomLevel[0].Attributes.Contains("rsa_values") ? entityCustomLevel[0].GetAttributeValue<string>("rsa_values") : string.Empty;
                returnValue = entityCustomLevel.Entities[0];
            }
            return returnValue;
        }
        //private string GetDistributionCategory(IOrganizationService service, ITracingService tracer, Guid brokerId)
        //{
        //    string fetchQuery = "<fetch mapping = 'logical' distinct='true'>";
        //    fetchQuery += "<entity name='account'>";
        //    fetchQuery += "<attribute name='accountid'/>";
        //    fetchQuery += "<attribute name='rsa_channel'/>";
        //    fetchQuery += "<link-entity name='account' from='rsa_parentid' to='accountid' link-type='inner' alias='aa'>";
        //    fetchQuery += "<filter type='and'>";
        //    fetchQuery += "<condition attribute='accountid' operator='eq'  value = '"+ brokerId + "' />";
        //    fetchQuery += "</filter>";
        //    fetchQuery += "</link-entity>";
        //    fetchQuery += "</entity >";
        //    fetchQuery += "</fetch>";
        //    EntityCollection accountCol = service.RetrieveMultiple(new FetchExpression(fetchQuery));
        //    string channel = string.Empty;
        //    if (accountCol.Entities.Count > 0)
        //    {
        //        foreach (var objAccount in accountCol.Entities)
        //        {
        //            channel = objAccount.Contains("rsa_channel") ? objAccount.FormattedValues["rsa_channel"] :string.Empty;
        //            tracer.Trace("Distribution Category Text : {0}", channel);
        //        }
        //    }
        //    return channel;
        //}
    }
    [DataContract]
    public class CARConfiguration
    {
        [DataMember]
        public Conditionalcarconfig[] ConditionalCARConfig { get; set; }
    }

    [DataContract]
    public class Conditionalcarconfig
    {
        [DataMember]
        public string RecordTypeName { get; set; }
        [DataMember]
        public Recordtypedetail[] RecordTypeDetails { get; set; }
    }
    [DataContract]
    public class Recordtypedetail
    {
        [DataMember]
        public string Branch { get; set; }
        [DataMember]
        public Brokerdetail[] BrokerDetails { get; set; }
    }
    [DataContract]
    public class Brokerdetail
    {
        [DataMember]
        public string DistributionCategory { get; set; }
        [DataMember]
        public bool IgnorePremiumCode { get; set; }
        [DataMember]
        public bool IgnorePolicyScheme { get; set; }
    }


    [DataContract]
    public class BranchJSONRoot
    {
        [DataMember]
        public List<BranchJSON> BranchJSON { get; set; }
    }
    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse);
    [DataContract]
    public class BranchJSON
    {
        [DataMember]
        public string COB { get; set; }
        [DataMember]
        public string RecordType { get; set; }
    }

    [DataContract]
    public class BPWJSON
    {
        [DataMember]
        public string COB { get; set; }
        [DataMember]
        public string PremiumValue { get; set; }
    }

    [DataContract]
    public class BPWJsonRoot
    {
        [DataMember]
        public List<BPWJSON> BPWJSON { get; set; }
    }

}
