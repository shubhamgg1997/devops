﻿using RSA.Crm.Plugins;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.ServiceModel;
using RSA.CSI.Plugins.ABR.Logic;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using System.Linq;
using System.Collections.Generic;//Added By Jyoti Bhosale For ACR change 09/08/2022
namespace RSA.CSI.ABR.Plugins
{
    public class ABRPostCreate : IPlugin
    {
        private readonly string _unsecureString;

        public ABRPostCreate(string unsecureString)
        {
            _unsecureString = unsecureString;
        }

            public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService tracer = null;
            IPluginExecutionContext context = null;
            IOrganizationService service = null;

            CrmPluginHelper.Initialise(serviceProvider, ref context, ref service, ref tracer, false);
            //Below variables added by Jyoti Bhosale for ARC ABR change 
            //09/08/2022: Jyoti Bhosale ARC ABR change 
            Guid ARCQueueId = new Guid();
            int casesource = 0;
            ARCOptionsetRoot objARCOptionsetRoot = new ARCOptionsetRoot();
            ARCDetails objARCDetails = new ARCDetails();
            /////////////////////////////
            tracer.Trace("context.Depth : " + context.Depth);
            //Nida: 08 June 2022 : Depth 5 condition added for the tasks to be generated post renewal generation. 

            //sumegh Dhole : 21 July 2021 : Depth 3 condition added for the tasks to be generated post renewal generation. 
            //Prachi Paunikar : 13 September 2021 : Depth 2 condition added for the tasks to be generated post SME Renewal Case. 
            //Nida: 14 June 2022 :depth commented for 2511 task creation issue
            //if (context.Depth > 5)
            //{
            //    return;
            //}

            if (!context.MessageName.ToLower().Equals("create"))
            {
                return;
            }
            try
            {
                if ((context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity) && context.MessageName.ToLowerInvariant() == "create" && context.Stage == 40)
                {
                    tracer.Trace("Instance created and target is avaialble.");
                    Entity entity = (Entity)context.InputParameters["Target"];
                    EntityCollection ABRTemplates = null;
                    Entity entityPostImage = (Entity)context.PostEntityImages["PostImage"];
                    Entity ABRTracking = new Entity("rsa_abrtracking");
                    tracer.Trace("ABR tracking object");
                    if (entity.LogicalName.ToLowerInvariant() != "incident")
                        return;

                    //AIS 
                    int caseorigin = entity.Attributes.Contains("caseorigincode") && entity.GetAttributeValue<OptionSetValue>("caseorigincode") != null ? entity.GetAttributeValue<OptionSetValue>("caseorigincode").Value : -1;
                    if (caseorigin == -1)
                    {
                        caseorigin = entityPostImage.Attributes.Contains("caseorigincode") && entityPostImage.GetAttributeValue<OptionSetValue>("caseorigincode") != null ? entityPostImage.GetAttributeValue<OptionSetValue>("caseorigincode").Value : -1;
                    }
                    tracer.Trace("Case origin :" + caseorigin);
                    if (caseorigin != 866760004 && context.Depth == 2)
                    {
                        return;
                    }

                    //ARC:Jyoti Bhosale Email to Case creation ARC ABR change 01/08/2022 

                    if (entity.Attributes.Contains("rsa_receivingemailbox") && entity.GetAttributeValue<EntityReference>("rsa_receivingemailbox") != null)
                    {
                        casesource = entity.Contains("incidentstagecode") && entity.GetAttributeValue<OptionSetValue>("incidentstagecode") != null ? entity.GetAttributeValue<OptionSetValue>("incidentstagecode").Value : -1;
                        objARCOptionsetRoot = ABRLogic.GetARCJSON(context, entity, service, tracer);
                        objARCDetails = objARCOptionsetRoot.ARCDetails.Find(a => a.MailboxGUID.Equals(Convert.ToString(entity.GetAttributeValue<EntityReference>("rsa_receivingemailbox").Id)));
                        tracer.Trace("Json Contains Email with Queue details: " + objARCDetails.ReceivingMailbox);
                        List<QueueDetails> QueueDetails = objARCDetails.QueueDetails;
                        tracer.Trace("QueueDetails: " + QueueDetails.Count);
                        foreach (var QueueData in QueueDetails)
                        {
                            ARCQueueId = new Guid(QueueData.QueueID);
                            tracer.Trace("ARCQueueId : " + QueueData.QueueID);
                        }
                        tracer.Trace("ARCQueueId" + ARCQueueId);
                    }

                    //Nida: 13 July 2022 :config driven 

                    //Nida: 22 June 2022 :Handling Cases - task  belongs to email-SME,email-Existing Buisness, Email - New Business 
                    //Case Origion: 866760015 >>Email - SME ;866760012>>Email - Existing Business;866760001>>Email - New Business

                    #region Duplicate Task - Resolution
                    string caseSubject = string.Empty;
                    string caseDescription = string.Empty;
                    string caseOwnerName = string.Empty;

                    string returnValue = string.Empty;
                    string customLabelName = "EmailToCase-CreatedBy";
                    EntityReference caseCreatedByPostImage = entityPostImage.Contains("createdby") && entityPostImage.GetAttributeValue<EntityReference>("createdby") != null ? entityPostImage.GetAttributeValue<EntityReference>("createdby") : null;
                    caseOwnerName = caseCreatedByPostImage.Name;
                    tracer.Trace("caseCreatedByPostImage" + caseOwnerName);
                    var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' no-lock='true'>
                              <entity name='rsa_customlabel'>
                                <attribute name='rsa_values' />                              
                                <filter type='and'>
                                  <condition attribute='rsa_name' operator='eq' value='{0}' />
                                </filter>
                              </entity>
                            </fetch>";
                    var entityCustomLevel = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, customLabelName)));
                    tracer.Trace("entityCustomLevel.Entities.Count" + entityCustomLevel.Entities.Count);
                    if (entityCustomLevel.Entities.Count > 0)
                    {

                        returnValue = entityCustomLevel[0].Attributes.Contains("rsa_values") ? entityCustomLevel[0].GetAttributeValue<string>("rsa_values") : string.Empty;
                        tracer.Trace("returnValue" + returnValue);
                        if (returnValue != null)
                        {
                            string[] sOwner = returnValue.Split(',');                                               
                            if ((caseorigin == 866760015 || caseorigin == 866760012 || caseorigin == 866760001) && caseOwnerName != null)
                            {
                                caseSubject = entity.Contains("rsa_subject") && entity.GetAttributeValue<string>("rsa_subject") != null ? entity.GetAttributeValue<string>("rsa_subject") : null;
                                caseDescription = entity.Contains("description") && entity.GetAttributeValue<string>("description") != null ? entity.GetAttributeValue<string>("description") : null;
                                tracer.Trace("caseSubject" + caseSubject);
                                tracer.Trace("caseDescription" + caseDescription);


                                if (caseSubject != null && caseDescription != null)
                                {
                                    foreach (string owner in sOwner)
                                    {
                                        if (owner.ToLower() == caseOwnerName.ToLower())
                                        {
                                            tracer.Trace("No Task To be fetched for Case belongs to email-SME,email-Existing Buisness, Email - New Business");
                                            return;
                                        }

                                    }
                                }
                            }
                        }
                    }
                    #endregion
                    
                    //Nida: 14 June 2022 :depth commented for 2511 task creation issue
                    int abrexecutionStatus = entity.Contains("rsa_abrexecutionstatus") && entity.GetAttributeValue<OptionSetValue>("rsa_abrexecutionstatus") != null ? entity.GetAttributeValue<OptionSetValue>("rsa_abrexecutionstatus").Value : -1;
                    if (abrexecutionStatus != -1)
                    {
                        return;
                    }


                    if (context.SharedVariables.Contains("rsa_status"))
                    {
                        tracer.Trace("Enter the Get ABR template function");

                        ABRTemplates = ABRLogic.GetABRTemplate(context, entity, service, tracer, ABRTracking);
                    }
                    else
                    {
                        ABRTemplates = ABRLogic.GetABRTemplate(context, entityPostImage, service, tracer, ABRTracking);
                    }

                    tracer.Trace("Duplicate ABR removal logic starting");
                    for (int i = 0; i < ABRTemplates.Entities.Count; i++)
                    //foreach (var item in ABRTemplates.Entities)
                    {
                        tracer.Trace("Duplicate ABR record Updated Count ." + ABRTemplates.Entities.Count().ToString());
                        //var enCount = ABRTemplates.Entities.Count(a => a.Attributes["rsa_name"].Equals(item.Attributes["rsa_name"]));
                        var enCount = ABRTemplates.Entities.Count(a => a.Attributes["rsa_name"].Equals(ABRTemplates.Entities[i].Attributes["rsa_name"]));
                        tracer.Trace("After Linq Query to remove duplicate ABR");
                        if (enCount >= 2)
                        {
                            tracer.Trace("Duplicate Found");
                            ABRTemplates.Entities.Remove(ABRTemplates.Entities[i]);
                            tracer.Trace("Duplicate Removed");
                        }
                    }

                    foreach (var item in ABRTemplates.Entities)
                    {

                        string abrTemplateID = item.Id.ToString();
                        tracer.Trace("Activity Business Rule Id : {0}", item.Id);
                        // string abrTemplateID = ABRLogic.GetABRTemplate(entityPostImage, service, tracer);
                        ABRLogic objABRLogic = new ABRLogic();

                        if (!string.IsNullOrEmpty(abrTemplateID))
                        {
                            Guid opportunityId = Guid.Empty;
                            Guid policyId = Guid.Empty;
                            if (entity.Contains("rsa_opportunityid") && entity.GetAttributeValue<EntityReference>("rsa_opportunityid") != null)
                            {
                                EntityReference Opportunity = entity.GetAttributeValue<EntityReference>("rsa_opportunityid");
                                opportunityId = Opportunity.Id;
                                tracer.Trace("Opportunity ID ." + opportunityId);
                            }
                            if (entity.Contains("rsa_policyid") && entity.GetAttributeValue<EntityReference>("rsa_policyid") != null)
                            {
                                EntityReference policy = entity.GetAttributeValue<EntityReference>("rsa_policyid");
                                policyId = policy.Id;
                                tracer.Trace("Policy ID ." + policyId);
                            }
                            //ABR AEC change :Jyoti Bhosale 05:08:2022 (ARCQueueId parameter added)
                            objABRLogic.GetABRActions(service, tracer, entity.Id, Guid.Parse(abrTemplateID), opportunityId, ABRTracking, ARCQueueId);
                            tracer.Trace("Actions data is updated.");
                            objABRLogic.updateCaseABRStatus(service, entityPostImage, tracer, 866760001, Guid.Empty);
                            //Update Case with ABR tracking status as ABR actions executed
                            //ABR AEC change :Jyoti Bhosale 05:08:2022 (ARCQueueId, objARCOptionsetRoot parameter added)
                            objABRLogic.GetABRTasks(context, service, tracer, entityPostImage, Guid.Parse(abrTemplateID), opportunityId, policyId, ABRTracking, ARCQueueId, objARCOptionsetRoot,_unsecureString);
                            tracer.Trace("Activities data is inserted.");
                            //Update Case with ABR tracking status as ABR tasks executed
                            objABRLogic.updateCaseABRStatus(service, entityPostImage, tracer, 866760002, Guid.Empty);


                        }
                    }

                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                CrmPluginHelper.CatchFaultException(ex, this);
            }
            catch (InvalidPluginExecutionException ex)
            {
                CrmPluginHelper.CatchInvalidPluginException(ex);
            }
            catch (Exception ex)
            {
                CrmPluginHelper.CatchGenericException(ex, this);
            }
        }
    }
}
