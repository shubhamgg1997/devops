﻿using Microsoft.Xrm.Sdk;
using System;
using System.ServiceModel;
using System.Activities;
using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Xrm.Sdk.Query;

namespace RSA.CSI.CustomWorkFlows
{
  public  class OpportunityRenewalMonthUpdate : CodeActivity
    {
     
        [RequiredArgument]
        [ReferenceTarget("opportunity")]
        [Input("opportunity")]
        public InArgument<EntityReference> entity { get; set; }

        protected override void Execute(CodeActivityContext _executionContext)
        {
            IWorkflowContext _context = _executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = _executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService _service = serviceFactory.CreateOrganizationService(_context.InitiatingUserId);

            ITracingService _tracingService = _executionContext.GetExtension<ITracingService>();
 
            if (entity != null)
            {
                // _tracingService.Trace("TaskManagementLogic=>CascadeTaskInfoToCase - eNTITYid of case" + entity.Id);
                EntityReference RelatedId = entity.Get<EntityReference>(_executionContext);
                var Opportunity = _service.Retrieve(RelatedId.LogicalName, RelatedId.Id, new ColumnSet("rsa_closedate"));
                if (Opportunity.Contains("rsa_closedate"))
                {
                    DateTime closeDate = Opportunity.GetAttributeValue<DateTime>("rsa_closedate");
                    if (closeDate != DateTime.MinValue)
                    {
                        Entity Oppo = new Entity(RelatedId.LogicalName);
                        Oppo.Id = RelatedId.Id;
                        Oppo["rsa_opportunityrenewalmonth"] = closeDate.ToString("MMMM"); //bug 1862
                        _service.Update(Oppo);
                    }
                }                
            }
                _tracingService.Trace("parent case has been updated.");           
        }
    }
}
