﻿using Microsoft.Xrm.Sdk;
using System;
using System.ServiceModel;
using System.Activities;
using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Xrm.Sdk.Query;

namespace RSA.CSI.CustomWorkFlows
{
    public class CurrentActivityNameCaseProcess : CodeActivity
    {
        [RequiredArgument]
        [ReferenceTarget("incident")]
        [Input("case")]

        public InArgument<EntityReference> entity { get; set; }

        //[Output("Duedate")]
        //public OutArgument<DateTime> duedate { get; set; }
        //[Output("activityname")]
        //public OutArgument<string> activityname { get; set; }
        //[Output("Owner")]
        //[ReferenceTarget("systemuser")]
        //public OutArgument<EntityReference> Ownerid { get; set; }


        protected override void Execute(CodeActivityContext _executionContext)
        {
            IWorkflowContext _context = _executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = _executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService _service = serviceFactory.CreateOrganizationService(_context.InitiatingUserId);

            ITracingService _tracingService = _executionContext.GetExtension<ITracingService>();           
            Entity _enTaskFromCase = null;
            
            if (entity != null)
            {
                // _tracingService.Trace("TaskManagementLogic=>CascadeTaskInfoToCase - eNTITYid of case" + entity.Id);
                EntityReference RelatedId = entity.Get<EntityReference>(_executionContext);
                _tracingService.Trace("realated id" + RelatedId.Id);
                string fetchQuery = "<fetch mapping = 'logical'>";
                fetchQuery += "<entity name = 'task'>";
                fetchQuery += "<attribute name='subject'/>";
                fetchQuery += "<attribute name = 'statecode'/>";
                fetchQuery += "<attribute name='prioritycode'/>";
                fetchQuery += "<attribute name = 'scheduledend'/>";
                fetchQuery += "<attribute name = 'rsa_slastatus'/>";
                fetchQuery += "<attribute name='createdby'/>";
                fetchQuery += "<attribute name = 'regardingobjectid'/>";
                fetchQuery += "<attribute name='activityid' />";
                fetchQuery += "<attribute name='ownerid' />";
                fetchQuery += "<order descending = 'false' attribute='scheduledend'/>";
                fetchQuery += "<filter type = 'and'>";
                fetchQuery += "<condition attribute='statuscode' value='5' operator='ne'/>";
                fetchQuery += "<condition attribute = 'regardingobjectid' value= '" + RelatedId.Id + "' operator='eq'/>";
                fetchQuery += "</filter>";
                fetchQuery += "</entity>";
                fetchQuery += "</fetch>";

                EntityCollection CaseTaskCOllection = _service.RetrieveMultiple(new FetchExpression(fetchQuery));
               
                _tracingService.Trace("TaskManagementLogic=>CascadeTaskInfoToCase - Tasks  of case" + CaseTaskCOllection.Entities.Count);
                if (CaseTaskCOllection != null && CaseTaskCOllection.Entities.Count > 0)
                {
                    //foreach (var en in CaseTaskCOllection.Entities)
                    //{
                    //    _enTaskFromCase = en;
                    //    _tracingService.Trace("TaskManagementLogic=>CascadeTaskInfoToCase Task from case retreived");
                    //    break;
                    //}

                    string taskSubject = CaseTaskCOllection[0].Attributes.Contains("subject") ? CaseTaskCOllection[0].GetAttributeValue<string>("subject") : string.Empty;
                    DateTime Duedate = CaseTaskCOllection[0].Attributes.Contains("scheduledend") ? CaseTaskCOllection[0].GetAttributeValue<DateTime>("scheduledend") : DateTime.MinValue;
                    EntityReference EnOwner = CaseTaskCOllection[0].Attributes.Contains("ownerid") ? CaseTaskCOllection[0].GetAttributeValue<EntityReference>("ownerid") : null;
                    Entity EnCase = new Entity("incident");
                    if (Duedate != DateTime.MinValue)
                    {
                        EnCase["rsa_nextactiondate"] = Duedate;

                    }
                    EnCase["rsa_nextactivityname"] = taskSubject;
                    EnCase["rsa_activityownerid"] = new EntityReference(EnOwner.LogicalName, EnOwner.Id);
                    EnCase.Id = RelatedId.Id;
                    _service.Update(EnCase);

                }

                _tracingService.Trace("parent case has been updated.");
            }
        }
    }

}