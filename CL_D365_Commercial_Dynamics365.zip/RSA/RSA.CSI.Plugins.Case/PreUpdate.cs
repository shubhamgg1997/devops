﻿using Microsoft.Xrm.Sdk;
using RSA.CSI.Plugins.Case.Common;
using RSA.CSI.Plugins.Case.Logic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSA.CSI.Plugins.Case
{
    public class PreUpdate : PluginBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PreUpdate"/> class.
        /// </summary>
        public PreUpdate()
            : base(typeof(PreUpdate))
        {
            RegisteredEvents.Add(new Tuple<int, string, string, Action<LocalPluginContext>>(20, "Update", "incident", ExecuteCasePreUpdate));
        }

        /// <summary>
        /// Start Validating the record when the regsiterd event occurs
        /// </summary>
        /// <param name="localContext"></param>
        protected void ExecuteCasePreUpdate(LocalPluginContext localContext)
        {
            #region Generic block of Context null checking and service creation block

            if (localContext == null)
            {
                throw new ArgumentNullException("localContext");
            }
            IPluginExecutionContext context = localContext.PluginExecutionContext;
            IOrganizationService service = localContext.OrganizationService;
            ITracingService tracingService = localContext.TracingService;
            #endregion Generic block of Context null checking and service creation block      

            #region Get Input Parameters

            if (context.InputParameters["Target"] != null &&
                context.PreEntityImages["PreImage"] != null)
            {
                try
                {
                    #region Need to register in Image
                    //rsa_surveycaseopen
                    //rsa_vefcaseopen
                    //rsa_policyid
                    //rsa_recordtypename
                    #endregion Need to register in Image

                    #region Pre Image attributes
                    //rsa_casetype
                    //rsa_policyid
                    //rsa_customerrsa
                    //rsa_status
                    //rsa_isemailparsingalreadyrun
                    //rsa_policynumberqc
                    //rsa_policysystemqc
                    //rsa_customerpostcode
                    //rsa_customername
                    //rsa_account
                    //rsa_agencynumber
                    //rsa_quoteid
                    //ownerid
                    //rsa_opportunityid
                    //rsa_outcomedate
                    //rsa_dummyreportingfield
                    //rsa_classofbusinessphoneenqid
                    //rsa_currentownerdivision
                    //rsa_currentownersite
                    //rsa_transactiontypeid
                    //rsa_surveycaseopen
                    //rsa_vefcaseopen
                    //rsa_casereceiveddate
                    //rsa_account
                    //rsa_targetpremium
                    //rsa_initialassignedtosite
                    //rsa_dummyfieldfornb
                    //rsa_initialassignedtousers
                    //createdon
                    //ticketnumber
                    //rsa_caseinitialassignedtosite
                    //rsa_promisebroker
                    //rsa_datetimeclosed
                    //rsa_potentialtowin
                    //rsa_brokercommitmentimage
                    //rsa_promise

                    //rsa_casetype, rsa_policyid, rsa_customerrsa, rsa_status, rsa_isemailparsingalreadyrun, rsa_policynumberqc, rsa_policysystemqc, rsa_customerpostcode, rsa_customername, rsa_account, rsa_agencynumber, rsa_quoteid, rsa_owner, rsa_opportunityid, rsa_outcomedate, rsa_dummyreportingfield, rsa_classofbusinessphoneenqid, rsa_currentownerdivision, rsa_currentownersite, rsa_transactiontypeid, rsa_surveycaseopen, rsa_vefcaseopen, rsa_casereceiveddate, rsa_targetpremium, rsa_caseinitialassignedtosite, rsa_dummyfieldfornb, rsa_initialassignedtousers, createdon

                    #endregion Post Image attributes

                    #region Call Function

                    if (context.Depth > 1)
                    {
                        tracingService.Trace("Plugin depth is greater than 1, hence RETURN: " + context.Depth);
                        return;
                    }
                    tracingService.Trace("Plugin depth: " + context.Depth);
                    var entityCaseTarget = context.InputParameters["Target"] as Entity;
                    tracingService.Trace("Target attribute(s) count: " + entityCaseTarget.Attributes.Count);
                    var entityCasePreImage = context.PreEntityImages["PreImage"] as Entity;
                    tracingService.Trace("Pre Image attribute(s) count: " + entityCasePreImage.Attributes.Count);
                    tracingService.Trace("Calling Execute Method()");

                    PreUpdateLogic casePreUpdate = new PreUpdateLogic(service, tracingService, entityCaseTarget, entityCasePreImage, this.MapAttributes(tracingService, entityCaseTarget, entityCasePreImage), context.InitiatingUserId);
                    casePreUpdate.Execute();
                    tracingService.Trace("Total attributes count entityCaseTarget after execution A11:" + entityCaseTarget.Attributes.Count);
                    tracingService.Trace("Successfully completed Case Pre Create plugin");
                    #endregion Call Function
                }
                catch (Exception ex)
                {
                    tracingService.Trace("Exception: " + ex.Message);
                    throw new InvalidPluginExecutionException(ex.Message);
                }
            }
            else
            {
                tracingService.Trace("Target is null");
                throw new InvalidPluginExecutionException("ExecuteCasePreUpdatePlugin: Target is null");
            }

            #endregion  Get Input Parameters
        }

        /// <summary>
        /// Attributes updated might not be available in PreImage with Post value but PreImage 
        /// with new values are required sometime to validate and other fields. 
        /// </summary>
        /// <param name="enCaseTarget"></param>
        /// <param name="enCasePreImage"></param>
        internal Entity MapAttributes(ITracingService tracingService, Entity enCaseTarget, Entity enCasePreImage)
        {
            tracingService.Trace("Within MapAttributes()");
            var newCaseTarget = new Entity("incident");
            newCaseTarget.Id = enCaseTarget.Id;

            if (enCaseTarget.Attributes.Contains("description"))
            {
                newCaseTarget["description"] = enCaseTarget["description"];
                tracingService.Trace("enCaseTarget-description :");
            }
            else if (enCasePreImage.Attributes.Contains("description"))
            {
                newCaseTarget["description"] = enCasePreImage["description"];
                tracingService.Trace("enCasePreImage-description :");
            }

            if (enCaseTarget.Attributes.Contains("rsa_casetype"))
            {
                newCaseTarget["rsa_casetype"] = enCaseTarget["rsa_casetype"];
                tracingService.Trace("enCaseTarget-rsa_casetype :");
            }
            else if (enCasePreImage.Attributes.Contains("rsa_casetype"))
            {
                newCaseTarget["rsa_casetype"] = enCasePreImage["rsa_casetype"];
                tracingService.Trace("enCasePreImage-rsa_casetype :");
            }

            if (enCaseTarget.Attributes.Contains("rsa_policyid"))
            {
                newCaseTarget["rsa_policyid"] = enCaseTarget["rsa_policyid"];
                tracingService.Trace("enCaseTarget-rsa_policyid :");
            }
            else if (enCasePreImage.Attributes.Contains("rsa_policyid"))
            {
                newCaseTarget["rsa_policyid"] = enCasePreImage["rsa_policyid"];
                tracingService.Trace("enCaseTarget-enCasePreImage :");
            }

            if (enCaseTarget.Attributes.Contains("rsa_customerrsa"))
            {
                newCaseTarget["rsa_customerrsa"] = enCaseTarget["rsa_customerrsa"];
                tracingService.Trace("enCaseTarget-rsa_customerrsa :");
            }
            else if (enCasePreImage.Attributes.Contains("rsa_customerrsa"))
            {
                newCaseTarget["rsa_customerrsa"] = enCasePreImage["rsa_customerrsa"];
                tracingService.Trace("enCasePreImage-rsa_customerrsa :");
            }

            if (enCaseTarget.Attributes.Contains("rsa_status"))
            {
                newCaseTarget["rsa_status"] = enCaseTarget["rsa_status"];
                tracingService.Trace("enCaseTarget-rsa_status :");
            }
            else if (enCasePreImage.Attributes.Contains("rsa_status"))
            {
                newCaseTarget["rsa_status"] = enCasePreImage["rsa_status"];
                tracingService.Trace("enCasePreImage-rsa_status :");
            }

            if (enCaseTarget.Attributes.Contains("rsa_isemailparsingalreadyrun"))
            {
                newCaseTarget["rsa_isemailparsingalreadyrun"] = enCaseTarget["rsa_isemailparsingalreadyrun"];
                tracingService.Trace("enCaseTarget- : rsa_isemailparsingalreadyrun");
            }
            else if (enCasePreImage.Attributes.Contains("rsa_isemailparsingalreadyrun"))
            {
                newCaseTarget["rsa_isemailparsingalreadyrun"] = enCasePreImage["rsa_isemailparsingalreadyrun"];
                tracingService.Trace("enCasePreImage- : rsa_isemailparsingalreadyrun");
            }

            if (enCaseTarget.Attributes.Contains("rsa_policynumberqc"))
            {
                newCaseTarget["rsa_policynumberqc"] = enCaseTarget["rsa_policynumberqc"];
                tracingService.Trace("enCaseTarget-rsa_policynumberqc :");
            }
            else if (enCasePreImage.Attributes.Contains("rsa_policynumberqc"))
            {
                newCaseTarget["rsa_policynumberqc"] = enCasePreImage["rsa_policynumberqc"];
                tracingService.Trace("enCasePreImage-rsa_policynumberqc :");
            }

            if (enCaseTarget.Attributes.Contains("rsa_policysystemqc"))
            {
                newCaseTarget["rsa_policysystemqc"] = enCaseTarget["rsa_policysystemqc"];
                tracingService.Trace("enCaseTarget-rsa_policysystemqc :");
            }
            else if (enCasePreImage.Attributes.Contains("rsa_policysystemqc"))
            {
                newCaseTarget["rsa_policysystemqc"] = enCasePreImage["rsa_policysystemqc"];
                tracingService.Trace("enCasePreImage-rsa_policysystemqc :");
            }

            if (enCaseTarget.Attributes.Contains("rsa_customerpostcode"))
            {
                newCaseTarget["rsa_customerpostcode"] = enCaseTarget["rsa_customerpostcode"];
                tracingService.Trace("enCaseTarget-rsa_customerpostcode :");
            }
            else if (enCasePreImage.Attributes.Contains("rsa_customerpostcode"))
            {
                newCaseTarget["rsa_customerpostcode"] = enCasePreImage["rsa_customerpostcode"];
                tracingService.Trace("enCasePreImage-rsa_customerpostcode :");
            }

            if (enCaseTarget.Attributes.Contains("rsa_customername"))
            {
                newCaseTarget["rsa_customername"] = enCaseTarget["rsa_customername"];
                tracingService.Trace("enCaseTarget-rsa_customername :");
            }
            else if (enCasePreImage.Attributes.Contains("rsa_customername"))
            {
                newCaseTarget["rsa_customername"] = enCasePreImage["rsa_customername"];
                tracingService.Trace("enCasePreImage-rsa_customername :");
            }

            if (enCaseTarget.Attributes.Contains("rsa_account"))
            {
                newCaseTarget["rsa_account"] = enCaseTarget["rsa_account"];
                tracingService.Trace("enCaseTarget-rsa_account :");
            }
            else if (enCasePreImage.Attributes.Contains("rsa_account"))
            {
                newCaseTarget["rsa_account"] = enCasePreImage["rsa_account"];
                tracingService.Trace("enCasePreImage-rsa_account :");
            }

            if (enCaseTarget.Attributes.Contains("rsa_agencynumber"))
            {
                newCaseTarget["rsa_agencynumber"] = enCaseTarget["rsa_agencynumber"];
                tracingService.Trace("enCaseTarget-rsa_agencynumber :");
            }
            else if (enCasePreImage.Attributes.Contains("rsa_agencynumber"))
            {
                newCaseTarget["rsa_agencynumber"] = enCasePreImage["rsa_agencynumber"];
                tracingService.Trace("enCasePreImage-rsa_agencynumber :");
            }

            if (enCaseTarget.Attributes.Contains("rsa_quoteid"))
            {
                newCaseTarget["rsa_quoteid"] = enCaseTarget["rsa_quoteid"];
                tracingService.Trace("enCaseTarget-rsa_quoteid :");
            }
            else if (enCasePreImage.Attributes.Contains("rsa_quoteid"))
            {
                newCaseTarget["rsa_quoteid"] = enCasePreImage["rsa_quoteid"];
                tracingService.Trace("enCasePreImage-rsa_quoteid :");
            }

            if (enCaseTarget.Attributes.Contains("ownerid"))
            {
                newCaseTarget["ownerid"] = enCaseTarget["ownerid"];
                tracingService.Trace("enCaseTarget-ownerid :");
            }
            else if (enCasePreImage.Attributes.Contains("ownerid"))
            {
                newCaseTarget["ownerid"] = enCasePreImage["ownerid"];
                tracingService.Trace("enCasePreImage-ownerid :");
            }

            if (enCaseTarget.Attributes.Contains("rsa_opportunityid"))
            {
                newCaseTarget["rsa_opportunityid"] = enCaseTarget["rsa_opportunityid"];
                tracingService.Trace("enCaseTarget-rsa_opportunityid :");
            }
            else if (enCasePreImage.Attributes.Contains("rsa_opportunityid"))
            {
                newCaseTarget["rsa_opportunityid"] = enCasePreImage["rsa_opportunityid"];
                tracingService.Trace("enCasePreImage-rsa_opportunityid :");
            }

            if (enCaseTarget.Attributes.Contains("rsa_outcomedate"))
            {
                newCaseTarget["rsa_outcomedate"] = enCaseTarget["rsa_outcomedate"];
                tracingService.Trace("enCaseTarget-rsa_outcomedate :");
            }
            else if (enCasePreImage.Attributes.Contains("rsa_outcomedate"))
            {
                newCaseTarget["rsa_outcomedate"] = enCasePreImage["rsa_outcomedate"];
                tracingService.Trace("enCasePreImage-rsa_outcomedate :");
            }

            if (enCaseTarget.Attributes.Contains("rsa_dummyreportingfield"))
            {
                newCaseTarget["rsa_dummyreportingfield"] = enCaseTarget["rsa_dummyreportingfield"];
                tracingService.Trace("enCaseTarget-rsa_dummyreportingfield :");
            }
            else if (enCasePreImage.Attributes.Contains("rsa_dummyreportingfield"))
            {
                newCaseTarget["rsa_dummyreportingfield"] = enCasePreImage["rsa_dummyreportingfield"];
                tracingService.Trace("enCasePreImage-rsa_dummyreportingfield :");
            }

            if (enCaseTarget.Attributes.Contains("rsa_classofbusinessphoneenqid"))
            {
                newCaseTarget["rsa_classofbusinessphoneenqid"] = enCaseTarget["rsa_classofbusinessphoneenqid"];
                tracingService.Trace("enCaseTarget-rsa_classofbusinessphoneenqid :");
            }
            else if (enCasePreImage.Attributes.Contains("rsa_classofbusinessphoneenqid"))
            {
                newCaseTarget["rsa_classofbusinessphoneenqid"] = enCasePreImage["rsa_classofbusinessphoneenqid"];
                tracingService.Trace("enCasePreImage-rsa_classofbusinessphoneenqid :");
            }

            if (enCaseTarget.Attributes.Contains("rsa_currentownerdivision"))
            {
                newCaseTarget["rsa_currentownerdivision"] = enCaseTarget["rsa_currentownerdivision"];
                tracingService.Trace("enCaseTarget-rsa_currentownerdivision :");
            }
            else if (enCasePreImage.Attributes.Contains("rsa_currentownerdivision"))
            {
                newCaseTarget["rsa_currentownerdivision"] = enCasePreImage["rsa_currentownerdivision"];
                tracingService.Trace("enCasePreImage-rsa_currentownerdivision :");
            }

            if (enCaseTarget.Attributes.Contains("rsa_currentownersite"))
            {
                newCaseTarget["rsa_currentownersite"] = enCaseTarget["rsa_currentownersite"];
                tracingService.Trace("enCaseTarget-rsa_currentownersite :");
            }
            else if (enCasePreImage.Attributes.Contains("rsa_currentownersite"))
            {
                newCaseTarget["rsa_currentownersite"] = enCasePreImage["rsa_currentownersite"];
                tracingService.Trace("enCasePreImage-rsa_currentownersite :");
            }

            if (enCaseTarget.Attributes.Contains("rsa_transactiontypeid"))
            {
                newCaseTarget["rsa_transactiontypeid"] = enCaseTarget["rsa_transactiontypeid"];
                tracingService.Trace("enCaseTarget-rsa_transactiontypeid :");
            }
            else if (enCasePreImage.Attributes.Contains("rsa_transactiontypeid"))
            {
                newCaseTarget["rsa_transactiontypeid"] = enCasePreImage["rsa_transactiontypeid"];
                tracingService.Trace("enCasePreImage-rsa_transactiontypeid :");
            }

            if (enCaseTarget.Attributes.Contains("rsa_surveycaseopen"))
            {
                newCaseTarget["rsa_surveycaseopen"] = enCaseTarget["rsa_surveycaseopen"];
                tracingService.Trace("enCaseTarget-rsa_surveycaseopen :");
            }
            else if (enCasePreImage.Attributes.Contains("rsa_surveycaseopen"))
            {
                newCaseTarget["rsa_surveycaseopen"] = enCasePreImage["rsa_surveycaseopen"];
                tracingService.Trace("enCasePreImage-rsa_surveycaseopen :");
            }

            if (enCaseTarget.Attributes.Contains("rsa_casereceiveddate"))
            {
                newCaseTarget["rsa_casereceiveddate"] = enCaseTarget["rsa_casereceiveddate"];
                tracingService.Trace("enCaseTarget-rsa_casereceiveddate :");
            }
            else if (enCasePreImage.Attributes.Contains("rsa_casereceiveddate"))
            {
                newCaseTarget["rsa_casereceiveddate"] = enCasePreImage["rsa_casereceiveddate"];
                tracingService.Trace("enCasePreImage-rsa_casereceiveddate :");
            }

            if (enCaseTarget.Attributes.Contains("rsa_account"))
            {
                newCaseTarget["rsa_account"] = enCaseTarget["rsa_account"];
                tracingService.Trace("enCaseTarget-rsa_account :");
            }
            else if (enCasePreImage.Attributes.Contains("rsa_account"))
            {
                newCaseTarget["rsa_account"] = enCasePreImage["rsa_account"];
                tracingService.Trace("enCasePreImage-rsa_account :");
            }

            if (enCaseTarget.Attributes.Contains("rsa_targetpremium"))
            {
                newCaseTarget["rsa_targetpremium"] = enCaseTarget["rsa_targetpremium"];
                tracingService.Trace("enCaseTarget-rsa_targetpremium :");
            }
            else if (enCasePreImage.Attributes.Contains("rsa_targetpremium"))
            {
                newCaseTarget["rsa_targetpremium"] = enCasePreImage["rsa_targetpremium"];
                tracingService.Trace("enCasePreImage-rsa_targetpremium :");
            }

            if (enCaseTarget.Attributes.Contains("rsa_initialassignedtosite"))
            {
                newCaseTarget["rsa_initialassignedtosite"] = enCaseTarget["rsa_initialassignedtosite"];
                tracingService.Trace("enCaseTarget-rsa_initialassignedtosite :");
            }
            else if (enCasePreImage.Attributes.Contains("rsa_initialassignedtosite"))
            {
                newCaseTarget["rsa_initialassignedtosite"] = enCasePreImage["rsa_initialassignedtosite"];
                tracingService.Trace("enCasePreImage-rsa_initialassignedtosite :");
            }

            if (enCaseTarget.Attributes.Contains("rsa_dummyfieldfornb"))
            {
                newCaseTarget["rsa_dummyfieldfornb"] = enCaseTarget["rsa_dummyfieldfornb"];
                tracingService.Trace("enCaseTarget-rsa_dummyfieldfornb :");
            }
            else if (enCasePreImage.Attributes.Contains("rsa_dummyfieldfornb"))
            {
                newCaseTarget["rsa_dummyfieldfornb"] = enCasePreImage["rsa_dummyfieldfornb"];
                tracingService.Trace("enCasePreImage-rsa_dummyfieldfornb :");
            }

            if (enCaseTarget.Attributes.Contains("rsa_initialassignedtousers"))
            {
                newCaseTarget["rsa_initialassignedtousers"] = enCaseTarget["rsa_initialassignedtousers"];
                tracingService.Trace("enCaseTarget-rsa_initialassignedtousers :");
            }
            else if (enCasePreImage.Attributes.Contains("rsa_initialassignedtousers"))
            {
                newCaseTarget["rsa_initialassignedtousers"] = enCasePreImage["rsa_initialassignedtousers"];
                tracingService.Trace("enCasePreImage-rsa_initialassignedtousers :");
            }
            if (enCaseTarget.Attributes.Contains("createdon"))
            {
                newCaseTarget["createdon"] = enCaseTarget["createdon"];
                tracingService.Trace("enCaseTarget-createdon :");
            }
            else if (enCasePreImage.Attributes.Contains("createdon"))
            {
                newCaseTarget["createdon"] = enCasePreImage["createdon"];
                tracingService.Trace("enCasePreImage-createdon :");
            }
            if (enCaseTarget.Attributes.Contains("rsa_subject"))
            {
                newCaseTarget["rsa_subject"] = enCaseTarget["rsa_subject"];
                tracingService.Trace("enCaseTarget-rsa_subject :");
            }
            else if (enCasePreImage.Attributes.Contains("rsa_subject"))
            {
                newCaseTarget["rsa_subject"] = enCasePreImage["rsa_subject"];
                tracingService.Trace("enCasePreImage-rsa_subject :");
            }
            if (enCaseTarget.Attributes.Contains("rsa_vefcaseopen"))
            {
                newCaseTarget["rsa_vefcaseopen"] = enCaseTarget["rsa_vefcaseopen"];
                tracingService.Trace("enCaseTarget-rsa_vefcaseopen :");
            }
            else if (enCasePreImage.Attributes.Contains("rsa_vefcaseopen"))
            {
                newCaseTarget["rsa_vefcaseopen"] = enCasePreImage["rsa_vefcaseopen"];
                tracingService.Trace("enCasePreImage-rsa_vefcaseopen :");
            }
            if (enCaseTarget.Attributes.Contains("ticketnumber"))
            {
                newCaseTarget["ticketnumber"] = enCaseTarget["ticketnumber"];
                tracingService.Trace("enCaseTarget-ticketnumber :");
            }
            else if (enCasePreImage.Attributes.Contains("ticketnumber"))
            {
                newCaseTarget["ticketnumber"] = enCasePreImage["ticketnumber"];
                tracingService.Trace("enCasePreImage-ticketnumber :");
            }
            if (enCaseTarget.Attributes.Contains("rsa_caseinitialassignedtosite"))
            {
                newCaseTarget["rsa_caseinitialassignedtosite"] = enCaseTarget["rsa_caseinitialassignedtosite"];
                tracingService.Trace("enCaseTarget-rsa_caseinitialassignedtosite :");
            }
            else if (enCasePreImage.Attributes.Contains("rsa_caseinitialassignedtosite"))
            {
                newCaseTarget["rsa_caseinitialassignedtosite"] = enCasePreImage["rsa_caseinitialassignedtosite"];
                tracingService.Trace("enCasePreImage-rsa_caseinitialassignedtosite :");
            }
            if (enCaseTarget.Attributes.Contains("rsa_promisebroker"))
            {
                newCaseTarget["rsa_promisebroker"] = enCaseTarget["rsa_promisebroker"];
                tracingService.Trace("enCaseTarget-rsa_promisebroker :");
            }
            else if (enCasePreImage.Attributes.Contains("rsa_promisebroker"))
            {
                newCaseTarget["rsa_promisebroker"] = enCasePreImage["rsa_promisebroker"];
                tracingService.Trace("enCasePreImage-rsa_promisebroker :");
            }
            tracingService.Trace("End MapAttributes()");
            return newCaseTarget;
        }
    }
}
