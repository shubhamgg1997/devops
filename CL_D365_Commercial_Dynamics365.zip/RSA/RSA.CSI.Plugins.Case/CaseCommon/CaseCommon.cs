﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;


namespace RSA.CSI.Plugins.Case.CaseCommon
{
    internal class CaseCommon
    {
        IOrganizationService service;
        ITracingService tracingService;

        internal CaseCommon(IOrganizationService cService, ITracingService cTracingService)
        {
            service = cService;
            tracingService = cTracingService;
        }


        #region Common Methods


        /// <summary>
        /// Get policy details based on Policy Id
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="guidPolicyId"></param>
        /// <returns></returns>
        internal Entity GetPolicyDetails(Guid guidPolicyId)
        {
            var enEntity = new Entity();
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' >
                    <entity name='rsa_policy'>
                        <attribute name='rsa_tradinghandlingsite' />
                            <attribute name='rsa_operationshandlingsite' />
                            <attribute name='rsa_reviewtypecode' />
                            <attribute name='rsa_renewalgenerationstatuscode' />
                            <attribute name='rsa_renewalgenerationid' />
                            <attribute name='rsa_renewalgenerationfailreason' />
                            <attribute name='rsa_policytrader' />
                            <attribute name='rsa_policyhandler' />
                            <attribute name='rsa_plcode' />
                            <attribute name='rsa_mumbaihandler' />
                            <attribute name='rsa_premium' />
                            <attribute name='rsa_classofbusiness' />
                            <attribute name='rsa_broker' />
                            <attribute name='rsa_customer' />
                        <filter type='and' >
                            <condition attribute='rsa_policyid' operator='eq' value='{0}' />
                        </filter>                  
                    </entity>
                </fetch>";
            try
            {
                var enColDetails = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, guidPolicyId)));
                if (enColDetails != null && enColDetails.Entities.Count > 0)
                {
                    enEntity = enColDetails.Entities[0];
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetching Policyinformation in GetPolicyDetails:" + ex.Message);
                //throw new Exception("Exception while fetching Policyinformation in GetPolicyDetails: " + ex.Message);
            }
            return enEntity;
        }

        /// <summary>
        /// Get user details
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="guidUserId"></param>
        /// <returns></returns>
        internal Entity GetUserDetails(Guid guidUserId)
        {
            try
            {
                return service.Retrieve("systemuser", guidUserId, new ColumnSet("rsa_usersite", "fullname", "rsa_division", "rsa_userteamlevel2", "rsa_cloneofid"));
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetching GetUserDetails List:" + ex.Message);                
                //throw new Exception("Exception while fetching GetUserDetails List: " + ex.Message);
            }
            return null;

        }

        /// <summary>
        /// Fetch record from Custom Label entity based on key 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        internal EntityCollection GetCustomLabel(List<string> lstCustomLabelKeys)
        {
            EntityCollection enColCustomLables = null;
            var strGenerateCondition = string.Empty;
            foreach (var k in lstCustomLabelKeys.ToArray())
            {
                strGenerateCondition += String.Format("<condition attribute='rsa_name' operator='eq' value ='{0}'/>", k);
            }
            var returnValue = string.Empty;
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='rsa_customlabel'>
                                <attribute name='rsa_values' />
                                <attribute name='rsa_name' />
                                <attribute name='rsa_shortdescription' />
                                <attribute name='rsa_categories' />  
                                <filter type='and'><filter type='or'>
                                  {0}
                                </filter></filter>
                              </entity>
                            </fetch>";
            try
            {
                var entityCustomLevel = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, strGenerateCondition)));
                if (entityCustomLevel != null && entityCustomLevel.Entities.Count > 0)
                {
                    enColCustomLables = entityCustomLevel;
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetching GetCustomLabel List:" + ex.Message);
                //throw new Exception("Exception while fetching GetCustomLabel List: " + ex.Message);
            }
            return enColCustomLables;
        }

        /// <summary>
        /// Fetch record from Custom Label entity based on key 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        internal string GetCustomLabel(string key)
        {
            var returnValue = string.Empty;
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='rsa_customlabel'>
                                <attribute name='rsa_values' />
                                <attribute name='rsa_shortdescription' />
                                <attribute name='rsa_categories' />   
                                <filter type='and'>
                                  <condition attribute='rsa_name' operator='eq' value ='{0}'/>
                                </filter>
                              </entity>
                            </fetch>";
            var entityCustomLevel = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, key)));
            if (entityCustomLevel.Entities.Count > 0)
            {
                returnValue = entityCustomLevel[0].Attributes.Contains("rsa_values") ? entityCustomLevel[0].GetAttributeValue<string>("rsa_values") : string.Empty;
            }
            return returnValue;
        }

        /// <summary>
        /// Get rsa_status entity guid by passing status name
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="strStatus"></param>
        internal Entity GetStatusIdByName(string strStatus)
        {
            var enStatus = new Entity(null);
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='rsa_status'>
                                <attribute name='rsa_name' />
                                <attribute name='createdon' />
                                <attribute name='rsa_casetype' />
                                <attribute name='rsa_statusid' />
                                <attribute name='rsa_statuscode' />
                                <order attribute='rsa_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='rsa_name' operator='eq' value='{0}' />
                                </filter>
                              </entity>
                            </fetch>";
            try
            {
                var enColStatus = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, strStatus.Trim())));
                if (enColStatus != null && enColStatus.Entities.Count > 0)
                {
                    enStatus = enColStatus[0];
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetching status" + ex.Message);
                //throw new Exception("Exception while fetching status" + ex.Message);
            }
            return enStatus;
        }

        /// <summary>
        /// Get rsa_status entity status name by passing statusid
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="strStatus"></param>
        internal String GetNameByStatusId(Guid guidStatusId)
        {
            var strStatus = string.Empty;
            try
            {
                var enStatus = service.Retrieve("rsa_status", guidStatusId, new ColumnSet("rsa_name"));
                if (enStatus != null && enStatus.Attributes.Contains("rsa_name"))
                {
                    strStatus = enStatus.Attributes["rsa_name"].ToString();
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetching status name" + ex.Message);
                //throw new Exception("Exception while fetching status name" + ex.Message);
            }
            return strStatus;
        }

        /// <summary>
        /// Get rsa_casetype entity status name by passing casetypeid
        /// </summary>
        /// <param name="guidCaseTypeId"></param>
        /// <returns></returns>
        internal String GetNameByCaseTypeId(Guid guidCaseTypeId)
        {
            var strCaseTypeName = string.Empty;
            try
            {
                var enCaseType = service.Retrieve("rsa_casetype", guidCaseTypeId, new ColumnSet("rsa_casetype"));
                if (enCaseType != null && enCaseType.Attributes.Contains("rsa_casetype"))
                {
                    strCaseTypeName = enCaseType.Attributes["rsa_casetype"].ToString();
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetching status name" + ex.Message);
                //throw new Exception("Exception while fetching status name" + ex.Message);
            }
            return strCaseTypeName;
        }

        /// <summary>
        ///  Get name by entity Id
        /// </summary>
        /// <param name="strEntityName"></param>
        /// <param name="guidEntityId"></param>
        /// <param name="strAttributeName" (Ex. rsa_name)></param>
        /// <returns></returns>
        internal String GetNameByEntityId(string strEntityName, Guid guidEntityId, String strAttributeName)
        {
            var strTransactionTypeName = string.Empty;
            try
            {
                var enTransType = service.Retrieve(strEntityName, guidEntityId, new ColumnSet(strAttributeName));
                if (enTransType != null && enTransType.Attributes.Contains(strAttributeName))
                {
                    strTransactionTypeName = enTransType.Attributes[strAttributeName].ToString();
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetching from " + strEntityName + "with Id" + guidEntityId + "--Exception: " + ex.Message);
                //throw new Exception("Exception while fetching from " + strEntityName + "with Id" + guidEntityId + "--Exception: " + ex.Message);
            }
            return strTransactionTypeName;
        }


        /// <summary>
        /// Update opportunity
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="enCase"></param>
        internal void StampCaseOwnerOnOpportunity(Entity enCasePostImage)
        {
            tracingService.Trace("With in StampCaseOwnerOnOpportunity()");
            if (enCasePostImage.Attributes.Contains("rsa_opportunityid"))
            {
                var enOpportunity = new Entity("opportunity");
                enOpportunity.Id = ((EntityReference)enCasePostImage["rsa_opportunityid"]).Id;
                enOpportunity["rsa_case"] = new EntityReference("incident", enCasePostImage.Id);
                if (enCasePostImage.Attributes.Contains("ownerid"))
                {
                    enOpportunity["rsa_caseownername"] = ((EntityReference)enCasePostImage["ownerid"]).Name;
                    tracingService.Trace("Successfully populated rsa_caseownername: " + ((EntityReference)enCasePostImage["ownerid"]).Name);
                }
                else
                {
                    tracingService.Trace("Owner id is missing in Case: " + enCasePostImage.Id);
                }
                try
                {
                    service.Update(enOpportunity);
                    tracingService.Trace("Successfully Oppty updated)");
                }
                catch (Exception ex)
                {
                    tracingService.Trace("Exception while CreateEmailAttachment()" + ex.Message);
                    //throw new Exception("Exception while CreateEmailAttachment()" + ex.Message);
                }
            }
            else
            {
                tracingService.Trace("Opportunity id is missing in Case: " + enCasePostImage.Id);
            }
        }

        /// <summary>
        /// Get trading thresold details
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="guidCOB"></param>
        /// <param name="intOffice"></param>
        /// <returns></returns>
        internal EntityCollection GetTradingThresoldDetails(Guid guidCOB, int intOffice)
        {
            var enColTradingThresold = new EntityCollection();

            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' >
                                <entity name='rsa_tradingthreshold' >
                                    <attribute name='rsa_name' />
                                    <attribute name='rsa_office' />
                                    <attribute name='rsa_pl' />
                                    <attribute name='rsa_thresholdvalue' />
                                    <attribute name='rsa_renewaltradingthreshold' />
                                    <attribute name='rsa_renewalpromisethreshold' />
                                    <attribute name='rsa_classofbusiness' />
                                    <attribute name='rsa_tradingthresholdid' />
                                    <attribute name='rsa_vettingthreshold' />
                                    <order attribute='rsa_name' descending='false' />
                                    <filter type='and' >
                                        <condition attribute='rsa_office' operator='eq' value='{0}' />
                                        <condition attribute='rsa_classofbusiness' operator='eq' value='{1}' />
                                    </filter>
                                </entity>
                            </fetch>";
            try
            {
                enColTradingThresold = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, intOffice, guidCOB)));
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetch Trading Thresold: " + ex.Message);
                //throw new Exception("Exception while fetching GetTradingThresoldDetails: " + ex.Message);
            }
            return enColTradingThresold;
        }

        /// <summary>
        /// fetching Case,Policy,Broker and Oppty information 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="guidCaseId"></param>
        /// <returns></returns>
        internal Entity GetOpptyAndPolicyDetails(Guid guidOpptyId)
        {
            Entity enEntity = null;
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' >
                    <entity name='opportunity'>
                        <attribute name='rsa_expiringpremium' />
                        <attribute name='rsa_classofbusiness' />
                        <filter type='and' >
                            <condition attribute='opportunityid' operator='eq' value='{0}' />
                        </filter>                      
                        <link-entity name='rsa_policy' from='rsa_policyid' to='rsa_policyid' link-type='inner' alias='pol' >
                            <attribute name='rsa_tradinghandlingsite' />
                            <attribute name='rsa_operationshandlingsite' />
                            <attribute name='rsa_reviewtypecode' />
                            <attribute name='rsa_renewalgenerationstatuscode' />
                            <attribute name='rsa_renewalgenerationid' />
                            <attribute name='rsa_renewalgenerationfailreason' />
                            <attribute name='rsa_policytrader' />
                            <attribute name='rsa_policyhandler' />
                            <attribute name='rsa_plcode' />
                            <attribute name='rsa_mumbaihandler' />
                            <attribute name='rsa_premium' />
                            <attribute name='rsa_classofbusiness' />
                            <attribute name='rsa_broker' />
                            <attribute name='rsa_customer' />
                        </link-entity>
                    </entity>
                </fetch>";
            try
            {
                var enColDetails = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, guidOpptyId)));
                if (enColDetails != null && enColDetails.Entities.Count > 0)
                {
                    enEntity = enColDetails.Entities[0];
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetching Policy and  Oppty information in GetOpptyAndPolicyDetails:" + ex.Message);
                //throw new Exception("Exception while fetching Policy and  Oppty  information in GetOpptyAndPolicyDetails: " + ex.Message);
            }
            return enEntity;
        }
        /// <summary>
        /// Get custom lables populated for R90 conditions
        /// </summary>
        /// <param name="caseCommon"></param>
        /// <param name="strR90COB"></param>
        /// <param name="strR90DistributionCategory"></param>
        /// <param name="strR90DistributionSegment"></param>
        /// <param name="strR90Network"></param>
        /// <param name="strR90Branchs"></param>
        internal void GetR90CustomLables(out string strR90COB, out string strR90DistributionCategory, out string strR90DistributionSegment,
            out string strR90Network, out string strR90Branchs)
        {
            strR90COB = "R_90_CoBs"; strR90DistributionCategory = "R_90_Distribution_Categories";
            strR90DistributionSegment = "R_90_Distribution_Subsegments";
            strR90Network = "R_90_Network"; strR90Branchs = "R_90_broker_branches";
            List<string> lstR90CustomLabels = new List<string>();
            lstR90CustomLabels.Add(strR90COB);
            lstR90CustomLabels.Add(strR90DistributionCategory);
            lstR90CustomLabels.Add(strR90DistributionSegment);
            lstR90CustomLabels.Add(strR90Network);
            lstR90CustomLabels.Add(strR90Branchs);
            EntityCollection enColCustomLabel = this.GetCustomLabel(lstR90CustomLabels);
            foreach (var enCustomLabel in enColCustomLabel.Entities)
            {
                if (enCustomLabel.Attributes.Contains("rsa_name") &&
                    enCustomLabel.Attributes["rsa_name"].ToString().Equals(strR90COB) &&
                    enCustomLabel.Attributes.Contains("rsa_values"))
                {
                    strR90COB = enCustomLabel.Attributes["rsa_values"].ToString();
                }
                else if (enCustomLabel.Attributes.Contains("rsa_name") &&
                    enCustomLabel.Attributes["rsa_name"].ToString().Equals(strR90DistributionCategory) &&
                    enCustomLabel.Attributes.Contains("rsa_values"))
                {
                    strR90DistributionCategory = enCustomLabel.Attributes["rsa_values"].ToString();
                }
                else if (enCustomLabel.Attributes.Contains("rsa_name") &&
                    enCustomLabel.Attributes["rsa_name"].ToString().Equals(strR90DistributionSegment) &&
                    enCustomLabel.Attributes.Contains("rsa_values"))
                {
                    strR90DistributionSegment = enCustomLabel.Attributes["rsa_values"].ToString();
                }
                else if (enCustomLabel.Attributes.Contains("rsa_name") &&
                    enCustomLabel.Attributes["rsa_name"].ToString().Equals(strR90Network) &&
                    enCustomLabel.Attributes.Contains("rsa_values"))
                {
                    strR90Network = enCustomLabel.Attributes["rsa_values"].ToString();
                }
                else if (enCustomLabel.Attributes.Contains("rsa_name") &&
                    enCustomLabel.Attributes["rsa_name"].ToString().Equals(strR90Branchs) &&
                    enCustomLabel.Attributes.Contains("rsa_values"))
                {
                    strR90Branchs = enCustomLabel.Attributes["rsa_values"].ToString();
                }
            }
        }


        /// <summary>
        /// trace the ticket number to trac Case
        /// </summary>
        /// <param name="enCase"></param>
        internal void TraceCaseNumber(Entity enCase)
        {
            if (enCase.Attributes.Contains("ticketnumber") &&
                !String.IsNullOrEmpty(enCase.Attributes["ticketnumber"].ToString()))
            {
                tracingService.Trace("Case 'ticketnumber' :" + enCase.Attributes["ticketnumber"].ToString());
            }
            else
            {
                tracingService.Trace("Case 'ticketnumber' is null:");
            }
        }


        /// <summary>
        /// Get custom lables populated for survey and vef flag
        /// </summary>
        /// <param name="strSMESurvey"></param>
        /// <param name="strSMEVef"></param>
        internal void GetSetSurveyVEFFlagCustomLabels(out string strSMESurvey, out string strSMEVef)
        {
            strSMESurvey = "CL_CASE_RECORD_TYPE_NAME_SME_SURVEY"; strSMEVef = "CL_CASE_RECORD_TYPE_NAME_SME_VEF";
            List<string> lstCustomLabels = new List<string>();
            lstCustomLabels.Add(strSMESurvey);
            lstCustomLabels.Add(strSMEVef);
            EntityCollection enColCustomLabel = this.GetCustomLabel(lstCustomLabels);
            foreach (var enCustomLabel in enColCustomLabel.Entities)
            {
                if (enCustomLabel.Attributes.Contains("rsa_name") &&
                enCustomLabel.Attributes["rsa_name"].ToString().Equals(strSMESurvey) &&
                enCustomLabel.Attributes.Contains("rsa_values"))
                {
                    strSMESurvey = enCustomLabel.Attributes["rsa_values"].ToString();
                }
                else if (enCustomLabel.Attributes.Contains("rsa_name") &&
                enCustomLabel.Attributes["rsa_name"].ToString().Equals(strSMEVef) &&
                enCustomLabel.Attributes.Contains("rsa_values"))
                {
                    strSMEVef = enCustomLabel.Attributes["rsa_values"].ToString();
                }
            }
        }

        /// <summary>
        /// Get option set metadata ( value/text)
        /// </summary>
        /// <param name="entityName"></param>
        /// <param name="attributeName"></param>
        /// <param name="optionSetValue"></param>
        /// <param name="optionSetText"></param>
        /// <returns></returns>
        internal string GetOptionSetMetadata(string entityName, string attributeName, string optionSetValue, string optionSetText)
        {
            var returnValue = string.Empty;
            try
            {
                var attributeRequest = new RetrieveAttributeRequest
                {
                    EntityLogicalName = entityName,
                    LogicalName = attributeName,
                    RetrieveAsIfPublished = true
                };

                var attributeResponse = (RetrieveAttributeResponse)service.Execute(attributeRequest);
                var attributeMetadata = (EnumAttributeMetadata)attributeResponse.AttributeMetadata;

                var optionList = (from o in attributeMetadata.OptionSet.Options select new { Value = o.Value, Text = o.Label.UserLocalizedLabel.Label }).ToList();
                if (!String.IsNullOrEmpty(optionSetValue))
                    returnValue = optionList.Where(o => o.Value == Convert.ToInt32(optionSetValue)).Select(o => o.Text).FirstOrDefault();
                else if (!String.IsNullOrEmpty(optionSetText))
                    returnValue = optionList.Where(o => o.Text == optionSetText).Select(o => o.Value).FirstOrDefault().ToString();
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetching Policy and  Oppty information in GetOpptyAndPolicyDetails:" + ex.Message);
                throw new Exception("Exception while fetching Policy and  Oppty  information in GetOpptyAndPolicyDetails: " + ex.Message);
            }
            return returnValue.Trim();
        }


        #endregion Common Methods
    }
}
