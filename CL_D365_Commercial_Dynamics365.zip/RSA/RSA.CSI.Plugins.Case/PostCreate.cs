﻿using Microsoft.Xrm.Sdk;
using RSA.CSI.Plugins.Case.Common;
using RSA.CSI.Plugins.Case.Logic;
using System;

namespace RSA.CSI.Plugins.Case
{
    public class PostCreate : PluginBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PostCreate"/> class.
        /// </summary>
        public PostCreate()
            : base(typeof(PostCreate))
        {
            RegisteredEvents.Add(new Tuple<int, string, string, Action<LocalPluginContext>>(40, "Create", "incident", Execute));
        }

        /// <summary>
        /// Start Validating the record when the regsiterd event occurs
        /// </summary>
        /// <param name="localContext"></param>
        protected void Execute(LocalPluginContext localContext)
        {
            #region Generic block of Context null checking and service creation block

            if (localContext == null)
            {
                throw new ArgumentNullException("localContext");
            }
            IPluginExecutionContext context = localContext.PluginExecutionContext;
            IOrganizationService service = localContext.OrganizationService;
            ITracingService tracingService = localContext.TracingService;
            #endregion Generic block of Context null checking and service creation block

            if (context.InputParameters["Target"] != null && (Entity)context.InputParameters["Target"] != null)
            {
                try
                {
                    var enCaseTarget = context.InputParameters["Target"] as Entity;
                    tracingService.Trace("Calling Post Create Execute");
                    PostCreateLogic postCreate = new PostCreateLogic(service, tracingService, enCaseTarget, context.InitiatingUserId);
                    postCreate.Execute();
                    tracingService.Trace("Successfully completed Case post Create plugin");
                }
                catch (Exception ex)
                {
                    tracingService.Trace("ExecuteCasePostCreatePlugin : " + ex.Message);
                    throw new InvalidPluginExecutionException("ExecuteCasePostCreatePlugin: " + ex.Message);
                }
            }
            else
            {
                tracingService.Trace("Target is null");
                throw new InvalidPluginExecutionException("ExecuteCasePostCreatePlugin: Target is null");
            }
        }
    }
}
