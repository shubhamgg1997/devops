﻿using Microsoft.Xrm.Sdk;
using RSA.CSI.Plugins.Case.Common;
using RSA.CSI.Plugins.Case.Logic;
using System;

namespace RSA.CSI.Plugins.Case
{
    public class PostUpdate : PluginBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PostUpdate"/> class.
        /// </summary>
        public PostUpdate()
            : base(typeof(PostUpdate))
        {
            RegisteredEvents.Add(new Tuple<int, string, string, Action<LocalPluginContext>>(40, "Update", "incident", ExecuteCasePostUpdate));
        }

        /// <summary>
        /// Start Validating the record when the regsiterd event occurs
        /// </summary>
        /// <param name="localContext"></param>
        protected void ExecuteCasePostUpdate(LocalPluginContext localContext)
        {
            #region Generic block of Context null checking and service creation block

            if (localContext == null)
            {
                throw new ArgumentNullException("localContext");
            }
            IPluginExecutionContext context = localContext.PluginExecutionContext;
            IOrganizationService service = localContext.OrganizationService;
            ITracingService tracingService = localContext.TracingService;
            #endregion Generic block of Context null checking and service creation block       

            #region Get Input Parameters

            if (context != null && context.InputParameters.Contains("Target") && 
                context.PostEntityImages.Contains("PostImage"))
            {
                try
                {
                    #region Need to register in Image
                    //rsa_casetype
                    //ownerid
                    //rsa_opportunityid
                    #endregion Need to register in Image

                    #region Call Function
                    Entity entityCaseTarget = context.InputParameters["Target"] as Entity;
                    Entity entityCasePostImage = context.PostEntityImages["PostImage"] as Entity;
                    if (context.Depth > 1)
                    {
                        tracingService.Trace("Plugin depth is greater than 1, hence RETURN: " + context.Depth);
                        return;
                    }
                    tracingService.Trace("Plugin depth: " + context.Depth);
                    tracingService.Trace("Target attribute(s) count: " + entityCaseTarget.Attributes.Count);
                    tracingService.Trace("Post Image attribute(s) count: " + entityCasePostImage.Attributes.Count);
                    tracingService.Trace("Calling Execute Method()");
                    PostUpdateLogic casePostUpdate = new PostUpdateLogic(service, tracingService, entityCaseTarget, 
                        entityCasePostImage, context.InitiatingUserId);
                    casePostUpdate.Execute();
                    tracingService.Trace("Successfully completed Case Pre Create plugin 1");
                    #endregion Call Function
                }
                catch (Exception ex)
                {
                    tracingService.Trace("Exception: " + ex.Message);
                    throw new InvalidPluginExecutionException("ExecuteCasePostUpdatePlugin: " + ex.Message);
                }
            }
            else
            {
                tracingService.Trace("Target is null");
                throw new InvalidPluginExecutionException("ExecuteCasePostUpdatePlugin: Target is null");
            }

            #endregion  Get Input Parameters
        }
    }
}
