﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSA.CSI.Plugins.Case.Logic
{
    internal class AssignToQueue
    {
        /// <summary>
        /// Constants & Global Variables
        /// </summary>
        #region Constants & Global Variables
        internal const string MESSAGE_CL0023 = "CL0023";

        internal Guid _gEmpty = Guid.Empty;
        internal string _sEmpty = string.Empty;

        internal string _sQueueName = string.Empty;
        internal string _sTradingHandlingSiteName = string.Empty;
        internal string _sOperationsHandlingSiteName = string.Empty;
        internal string _sTicketNumber = string.Empty;

        internal string _sPolicyClassOfBusinessName = string.Empty;
        internal Guid _gPolicyClassOfBusinessId = new Guid("09442fc2-62ca-ea11-a812-000d3af02cd4"); //Guid.Empty;

        internal string _sPolicyPLCodeName = string.Empty;
        internal Guid _gPolicyPLCodeId = Guid.Empty;

        internal int _iTradingHandlingSite = 866760016; //0;
        internal int _iOperationsHandlingSite = 0;

        internal decimal _dRenewalTradingThreshold = 0;
        internal decimal _dRenewalPromiseThreshold = 0;

        internal Guid _gTraderId = Guid.Empty;
        internal string _sTraderName = string.Empty;

        internal Guid _gUnderwriterId = Guid.Empty;
        internal string _sUnderwriterName = string.Empty;

        internal Entity _eTradingThreshold = null;

        internal Boolean _bIsErrorRecord = false;
        internal string _sErrorDescription = string.Empty;
        //internal String profinQueues;
        internal Dictionary<String, String> profinQueuesMap = new Dictionary<String, String>();
        internal List<String> profinQueuesList = new List<String>();
        internal Entity _eCase = null;
        internal Entity _eQueue = null;
        internal Guid _gPolicyId = Guid.Empty;

        #endregion

        /// <summary>
        /// Execute
        /// </summary>
        /// <param name="context"></param>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        public void Execute(IPluginExecutionContext context, IOrganizationService service, ITracingService tracingService)
        {
            tracingService.Trace("RSA.CSI.Plugins.Case.AssignToQueue=>Execute()- Loaded");
            //Guid gCaseId = new Guid("92b26725-ebd7-ea11-a813-000d3a7fccf0");

            string fXml = this.PrepareCaseQuery(tracingService, context.PrimaryEntityId);
            //string fXml = this.PrepareCaseQuery(tracingService, gCaseId);
            tracingService.Trace(string.Format("Fetching Case record with Id: '{0}.", context.PrimaryEntityId.ToString()));
            var ecCaseCollection = this.RetrieveMultiple(service, tracingService, fXml);
            tracingService.Trace(string.Format("Fetching Case record Count: '{0}.", ecCaseCollection.Entities.Count));
            
            tracingService.Trace(string.Format("Fetching Case record Count: '{0}.", ecCaseCollection.Entities.Count));
            if (ecCaseCollection != null && ecCaseCollection.Entities.Count > 0
                && ecCaseCollection[0] != null && ecCaseCollection[0].Attributes.Contains("rsa_policyid")
                && ((EntityReference)ecCaseCollection[0].Attributes["rsa_policyid"]).Id != _gEmpty)
            {
                _eCase = ecCaseCollection[0];
                tracingService.Trace(string.Format("Case has been fetched record with Id: '{0}.", _eCase.Id));
                if (_eCase.Attributes.Contains("ticketnumber") && _eCase["ticketnumber"] != null)
                    _sTicketNumber = _eCase["ticketnumber"].ToString();
                _gPolicyId = ((EntityReference)_eCase["rsa_policyid"]).Id;

                #region Assign Case to Queue logic
                if (!this.IdentifyTheCaseQueue(tracingService, service))
                {
                    string sErroMessage = string.Format("The Case '{0}' was not  assigned to the Queue '{1}' as it  does not  exist in the system.", _sTicketNumber, _sQueueName);
                    tracingService.Trace(sErroMessage);
                    this.UpdatePolicyCaseAssignStatus(service, tracingService, (int)CASE_ASSIGN_STATUS_CODE.Failed, sErroMessage);
                    return;
                }
                else
                {
                    if (this.AssignCaseToQueue(tracingService, service))
                    {
                        this.UpdatePolicyCaseAssignStatus(service, tracingService, (int)CASE_ASSIGN_STATUS_CODE.Success, _sEmpty);
                    }
                    else
                    {
                        string sErroMessage = string.Format("The Case '{0}' was being assigned to the Queue '{1}' which doesn\'t exist in the system.", _sTicketNumber, _sQueueName);
                        tracingService.Trace(sErroMessage);
                        this.UpdatePolicyCaseAssignStatus(service, tracingService, (int)CASE_ASSIGN_STATUS_CODE.Failed, sErroMessage);
                        return;
                    }
                }
                #endregion

                #region Case Update logic
                /*
                if (_eCase.Attributes.Contains("pol.rsa_policytrader") && ((EntityReference)((AliasedValue)_eCase.Attributes["pol.rsa_policytrader"]).Value).Id != _gEmpty)
                {
                    _sTraderName = ((EntityReference)((AliasedValue)_eCase.Attributes["pol.rsa_policytrader"]).Value).Name;
                    _gTraderId = ((EntityReference)((AliasedValue)_eCase.Attributes["pol.rsa_policytrader"]).Value).Id;
                }
                if (_eCase.Attributes.Contains("pol.rsa_policyhandler") && ((EntityReference)((AliasedValue)_eCase.Attributes["pol.rsa_policyhandler"]).Value).Id != _gEmpty)
                {
                    _sUnderwriterName = ((EntityReference)((AliasedValue)_eCase.Attributes["pol.rsa_policyhandler"]).Value).Name;
                    _gUnderwriterId = ((EntityReference)((AliasedValue)_eCase.Attributes["pol.rsa_policyhandler"]).Value).Id;
                }

                if (_gPolicyClassOfBusinessId != _gEmpty || _iTradingHandlingSite != 0)
                {
                    _eTradingThreshold = this.GetTradingThresoldDetails(service, tracingService, _gPolicyClassOfBusinessId, _iTradingHandlingSite);
                    if (_eTradingThreshold != null && _eCase.Attributes.Contains("opp.rsa_expiringpremium") && _eCase.Attributes["opp.rsa_expiringpremium"] != null)
                    {

                        if (_eTradingThreshold.Attributes.Contains("rsa_renewaltradingthreshold") && _eTradingThreshold["rsa_renewaltradingthreshold"] != null)
                            _dRenewalTradingThreshold = _eTradingThreshold.GetAttributeValue<Money>("rsa_renewaltradingthreshold").Value;

                        if (_eTradingThreshold.Attributes.Contains("rsa_renewalpromisethreshold") && _eTradingThreshold["rsa_renewalpromisethreshold"] != null)
                            _dRenewalPromiseThreshold = _eTradingThreshold.GetAttributeValue<Money>("rsa_renewalpromisethreshold").Value;

                        
                        var vProfinSitesColl = !string.IsNullOrEmpty(this.GetCustomLabel(service, tracingService, "Profin_Sites")) ? this.GetCustomLabel(service, tracingService, "Profin_Sites").Split(',') : null;
                        if (vProfinSitesColl.Contains(_sTradingHandlingSiteName))
                        {
                            if (profinQueuesMap.Count == 0)
                            {
                                string vDistribution_categories_for_Profin_SME = !string.IsNullOrEmpty(this.GetCustomLabel(service, tracingService, "Distribution_categories_for_Profin_SME")) ? this.GetCustomLabel(service, tracingService, "Distribution_categories_for_Profin_SME") : _sEmpty;
                                if (vDistribution_categories_for_Profin_SME != _sEmpty && _eCase["rsa_distributioncategory"] != null && _eCase["rsa_distributioncategory"].ToString() != _sEmpty
                                    && vDistribution_categories_for_Profin_SME.Contains(_eCase["rsa_distributioncategory"].ToString()))
                                {

                                    string vProfin_Case_Assignment_1 = !string.IsNullOrEmpty(this.GetCustomLabel(service, tracingService, "Profin_Case_Assignment_1")) ? this.GetCustomLabel(service, tracingService, "Profin_Case_Assignment_1") : _sEmpty;
                                    string vProfin_Case_Assignment_2 = !string.IsNullOrEmpty(this.GetCustomLabel(service, tracingService, "Profin_Case_Assignment_2")) ? this.GetCustomLabel(service, tracingService, "Profin_Case_Assignment_2") : _sEmpty;
                                    if (vProfin_Case_Assignment_1.Contains(_sPolicyClassOfBusinessName) || vProfin_Case_Assignment_2.Contains(_sPolicyClassOfBusinessName))
                                    {
                                        profinQueues = !string.IsNullOrEmpty(this.GetCustomLabel(service, tracingService, "Profin_New_Business_Trading_Sites")) ? this.GetCustomLabel(service, tracingService, "Profin_New_Business_Trading_Sites") : _sEmpty;
                                        profinQueuesList = profinQueues.Split(';').ToList();
                                        int i = 0;
                                        while (i < profinQueuesList.Count)
                                        {
                                            profinQueuesMap.Add(profinQueuesList[i], profinQueuesList[i + 1]);
                                            i += 2;
                                        }
                                    }
                                }
                            }
                        }
                        

                        if (((Money)((AliasedValue)_eCase.Attributes["opp.rsa_expiringpremium"]).Value).Value >= _dRenewalTradingThreshold)
                        {
                            if (_eCase.Attributes["pol.rsa_policytrader"] != null)
                            {
                                _eCase["ownerid"] = _eCase.Attributes["pol.rsa_policytrader"];
                                _eCase["rsa_traded"] = new OptionSetValue((int)CASE_TRADED.Traded);
                            }
                        }
                        else
                        {
                            if (_eCase.Attributes["pol.rsa_policyhandler"] != null)
                            {
                                _eCase["ownerid"] = _eCase.Attributes["pol.rsa_policyhandler"];
                                _eCase["rsa_traded"] = new OptionSetValue((int)CASE_TRADED.OpsTraded);
                            }
                        }
                        var vCL0016 = !string.IsNullOrEmpty(this.GetCustomLabel(service, tracingService, "CL0016")) ? this.GetCustomLabel(service, tracingService, "CL0016") : _sEmpty;
                        var vCL0016List = vCL0016.Split(';');
                        if (vCL0016List.Contains(_sPolicyClassOfBusinessName))
                        {
                            _eCase["rsa_status"] = new EntityReference("rsa_status", new Guid("1336CDDD-78BC-EA11-A812-000D3AF01FA0"));
                        }
                    }
                }
                */
                #endregion
            }
            else
            {
                tracingService.Trace("This Case '{0}' is an orphan record and is not associated to any Policy.", _sTicketNumber);
                return;
            }
            tracingService.Trace("RSA.CSI.Plugins.Case.AssignToQueue=>Execute()- Unloaded");
        }

        /// <summary>
        /// Prepare Case Query
        /// </summary>
        /// <param name="tracingService"></param>
        /// <param name="gIncidentId"></param>
        /// <returns></returns>
        private string PrepareCaseQuery(ITracingService tracingService, Guid gIncidentId)
        {
            //tracingService.Trace("RSA.CSI.Plugins.Case.AssignToQueue=>PrepareCaseQuery()- Loaded");
            var fXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' >
                            <entity name='incident' >
                                <attribute name='title' />
                                <attribute name='ticketnumber' />
                                <attribute name='createdon' />
                                <attribute name='incidentid' />
                                <attribute name='caseorigincode' />
                                <attribute name='rsa_policyid' />
                                <attribute name='rsa_opportunityid' />
                                <attribute name='rsa_account' />
                                <order attribute='title' descending='false' />
                                <filter type='and' >
                                    <condition attribute='incidentid' operator='eq' value='{0}' />
                                </filter>
                                <link-entity name='opportunity' from='opportunityid' to='rsa_opportunityid' visible='false' link-type='outer' alias='opp' >
                                    <attribute name='rsa_expiringpremium' />
                                </link-entity>
                                <link-entity name='account' from='accountid' to='rsa_account' link-type='inner' alias='acc' >
                                    <attribute name='rsa_branch' />
                                </link-entity>
                                <link-entity name='rsa_policy' from='rsa_policyid' to='rsa_policyid' link-type='inner' alias='pol' >
                                    <attribute name='rsa_tradinghandlingsite' />
                                    <attribute name='rsa_operationshandlingsite' />
                                    <attribute name='rsa_reviewtypecode' />
                                    <attribute name='rsa_renewalgenerationstatuscode' />
                                    <attribute name='rsa_renewalgenerationid' />
                                    <attribute name='rsa_renewalgenerationfailreason' />
                                    <attribute name='rsa_policytrader' />
                                    <attribute name='rsa_policyhandler' />
                                    <attribute name='rsa_plcode' />
                                    <attribute name='rsa_mumbaihandler' />
                                    <attribute name='rsa_premium' />
                                    <attribute name='rsa_classofbusiness' />
                                </link-entity>
                            </entity></fetch>";



            fXml = string.Format(fXml, gIncidentId.ToString());
            //tracingService.Trace("RSA.CSI.Plugins.Case.AssignToQueue=>PrepareCaseQuery()- Unloaded");
            return fXml;
        }
        /// <summary>
        /// Get trading thresold details
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="guidCOB"></param>
        /// <param name="intOffice"></param>
        /// <returns></returns>
        private Entity GetTradingThresoldDetails(IOrganizationService service, ITracingService tracingService, Guid guidCOB, int intOffice)
        {
            tracingService.Trace("RSA.CSI.Plugins.Case.AssignToQueue=>GetTradingThresoldDetails()- Loaded.");

            var entityTradingThresold = new Entity();
            try
            {
                var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' >
                                <entity name='rsa_tradingthreshold' >
                                    <attribute name='rsa_name' />
                                    <attribute name='createdon' />
                                    <attribute name='rsa_pl' />
                                    <attribute name='rsa_office' />
                                    <attribute name='rsa_thresholdvalue' />
                                    <attribute name='rsa_renewaltradingthreshold' />
                                    <attribute name='rsa_renewalpromisethreshold' />
                                    <attribute name='rsa_classofbusiness' />
                                    <attribute name='rsa_tradingthresholdid' />
                                    <attribute name='rsa_vettingthreshold' />
                                    <order attribute='rsa_name' descending='false' />
                                    <filter type='and' >
                                        <condition attribute='rsa_office' operator='eq' value='{1}' />
                                        <condition attribute='rsa_classofbusiness' operator='eq' value='{0}' />
                                    </filter>
                                </entity>
                            </fetch>";

                var colTradingThresold = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, guidCOB, intOffice)));
                if (colTradingThresold != null && colTradingThresold.Entities.Count > 0)
                {
                    entityTradingThresold = colTradingThresold.Entities[0];
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetch Trading Thresold: " + ex.Message);
            }
            tracingService.Trace("RSA.CSI.Plugins.Case.AssignToQueue=>GetTradingThresoldDetails()- Unloaded.");
            return entityTradingThresold;
        }

        /// <summary>
        /// RetrieveMultiple
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="query"></param>
        /// <returns></returns>
        private EntityCollection RetrieveMultiple(IOrganizationService service, ITracingService tracingService, string query)
        {
            tracingService.Trace("RSA.CSI.Plugins.Case.AssignToQueue=>RetrieveMultiple()- Loaded.");
            EntityCollection eCollection = null; //new EntityCollection();
            try
            {
                eCollection = service.RetrieveMultiple(new FetchExpression(query));
            }
            catch (Exception ex)
            {
                if (!string.IsNullOrEmpty(ex.Message))
                    tracingService.Trace(string.Format("Error in RSA.CSI.Plugins.Case.AssignToQueue=>RetrieveMultiple(). Desc.: {0}", ex.Message));
                else if (!string.IsNullOrEmpty(ex.InnerException.Message))
                    tracingService.Trace(string.Format("Error in RSA.CSI.Plugins.Case.AssignToQueue=>RetrieveMultiple(). Desc.: {0}", ex.InnerException.Message));
                //throw new InvalidPluginExecutionException(string.Format("Error in RetrieveMultiple(). Desc.:", ex.InnerException.Message));
            }
            tracingService.Trace("RSA.CSI.Plugins.Case.AssignToQueue=>RetrieveMultiple()- Unloaded.");
            return eCollection;
        }

        ///// <summary>
        ///// Fetch record from Custom Label entity based on key
        ///// </summary>
        ///// <param name="service"></param>
        ///// <param name="key"></param>
        ///// <returns></returns>
        //private string GetCustomLabel(IOrganizationService service, ITracingService tracingService, string key)
        //{
        //    tracingService.Trace("RSA.CSI.Plugins.Case.AssignToQueue=>GetCustomLabel()- Loaded.");
        //    var returnValue = string.Empty;
        //    var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
        //                      <entity name='rsa_customlabel'>
        //                        <attribute name='rsa_values' />
        //                        <attribute name='rsa_shortdescription' />
        //                        <attribute name='rsa_categories' />  
        //                        <filter type='and'>
        //                          <condition attribute='rsa_name' operator='eq' value='{0}' />
        //                        </filter>
        //                      </entity>
        //                    </fetch>";
        //    var entityCustomLevel = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, key)));
        //    if (entityCustomLevel.Entities.Count > 0)
        //    {
        //        returnValue = entityCustomLevel[0].Attributes.Contains("rsa_values") ? entityCustomLevel[0].GetAttributeValue<string>("rsa_values") : string.Empty;
        //    }
        //    tracingService.Trace("RSA.CSI.Plugins.Case.AssignToQueue=>GetCustomLabel()- Unloaded.");
        //    return returnValue;
        //}

        /// <summary>
        /// PrepareQueueQuery
        /// </summary>
        /// <param name="tracingService"></param>
        /// <param name="sQueueName"></param>
        /// <returns></returns>
        private string PrepareQueueQuery(ITracingService tracingService, string sQueueName)
        {
            tracingService.Trace("RSA.CSI.Plugins.Case.AssignToQueue=>PrepareQueueQuery()- Loaded.");
            string fXml = @"<fetch mapping='logical' version='1.0' distinct='false' output-format='xml-platform'>
                              <entity name='queue'>
                                <attribute name='name' />
                                <attribute name='emailaddress' />
                                <attribute name='queueid' />
                                <order descending='false' attribute='name' />
                                <filter type='and'>
                                  <condition value='{0}' attribute='name' operator='eq' />
                                </filter>
                              </entity>
                            </fetch>";
            fXml = string.Format(fXml, sQueueName);
            tracingService.Trace("RSA.CSI.Plugins.Case.AssignToQueue=>PrepareQueueQuery()- Unloaded.");
            return fXml;
        }

        /// <summary>
        /// Add Case to Queue.
        /// </summary>
        /// <param name="tracingService"></param>
        /// <param name="service"></param>
        /// <param name="entityName"></param>
        /// <param name="caseId"></param>
        /// <param name="destinationQueueId"></param>
        private Boolean AssignCaseToQueue(ITracingService tracingService, IOrganizationService service)//, string entityName, Guid caseId, Guid destinationQueueId)
        {
            tracingService.Trace("Method RSA.CSI.Plugins.AssignToCase=>AssignCaseToDefaultQueue()- Loaded.");
            Boolean bCaseAllocationHappened = false;
            if (_eQueue != null)
            {

                var routeRequest = new AddToQueueRequest
                {
                    Target = new EntityReference(_eCase.LogicalName, _eCase.Id),
                    DestinationQueueId = _eQueue.Id
                };
                string responseName = service.Execute(routeRequest).ResponseName;
                if (!String.IsNullOrEmpty(responseName))
                    bCaseAllocationHappened = true;
            }
            tracingService.Trace("Method RSA.CSI.Plugins.AssignToCase=>AssignCaseToDefaultQueue()- Unloaded.");
            return bCaseAllocationHappened;
        }

        /// <summary>
        /// IdentifyQueueForCase
        /// </summary>
        /// <param name="tracingService"></param>
        /// <param name="service"></param>
        /// <param name="_eCase"></param>
        private Boolean IdentifyTheCaseQueue(ITracingService tracingService, IOrganizationService service)
        {
            tracingService.Trace("Method RSA.CSI.Plugins.AssignToCase=>IdentifyQueueForCase()- Loaded.");
            Boolean isQueueIdentified = false;
            if (_eCase.Attributes.Contains("pol.rsa_operationshandlingsite") && _eCase["pol.rsa_operationshandlingsite"] != null)
            {
                _sOperationsHandlingSiteName = _eCase.FormattedValues["pol.rsa_operationshandlingsite"];
                _iOperationsHandlingSite = ((OptionSetValue)((AliasedValue)_eCase["pol.rsa_operationshandlingsite"]).Value).Value;
            }
            if (_eCase.Attributes.Contains("pol.rsa_plcode") && ((EntityReference)((AliasedValue)_eCase.Attributes["pol.rsa_plcode"]).Value).Id != _gEmpty)
            {
                _sPolicyPLCodeName = ((EntityReference)((AliasedValue)_eCase.Attributes["pol.rsa_plcode"]).Value).Name;
                _gPolicyPLCodeId = ((EntityReference)((AliasedValue)_eCase.Attributes["pol.rsa_plcode"]).Value).Id;
            }
            if (_eCase.Attributes.Contains("pol.rsa_classofbusiness") && ((EntityReference)((AliasedValue)_eCase.Attributes["pol.rsa_classofbusiness"]).Value).Id != _gEmpty)
            {
                _sPolicyClassOfBusinessName = ((EntityReference)((AliasedValue)_eCase.Attributes["pol.rsa_classofbusiness"]).Value).Name;
                _gPolicyClassOfBusinessId = ((EntityReference)((AliasedValue)_eCase.Attributes["pol.rsa_classofbusiness"]).Value).Id;
            }
            if (_eCase.Attributes.Contains("pol.rsa_tradinghandlingsite") && _eCase["pol.rsa_tradinghandlingsite"] != null)
            {
                _sTradingHandlingSiteName = _eCase.FormattedValues["pol.rsa_tradinghandlingsite"];
                _iTradingHandlingSite = ((OptionSetValue)((AliasedValue)_eCase["pol.rsa_tradinghandlingsite"]).Value).Value;
            }

            _sQueueName = _sPolicyPLCodeName + " - " + _sOperationsHandlingSiteName;

            tracingService.Trace("_sQueueName generated" + _sQueueName);
            RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon = new CaseCommon.CaseCommon(service, tracingService);
            string sLabelMessage = caseCommon.GetCustomLabel(MESSAGE_CL0023);
            if (sLabelMessage != _sEmpty)
            {
                foreach (string s in sLabelMessage.Split(';'))
                {
                    if (s.ToLower().Trim().ToLower() == _sPolicyClassOfBusinessName.ToLower())
                    {
                        _sQueueName = _sPolicyPLCodeName + " - " + _sTradingHandlingSiteName;
                        break;
                    }
                }
                string sQuery = this.PrepareQueueQuery(tracingService, _sQueueName);
                tracingService.Trace("Queue query" + sQuery);
                EntityCollection businessRecordTypes = service.RetrieveMultiple(new FetchExpression(sQuery));
                tracingService.Trace("Queue query" + businessRecordTypes.Entities.Count);
                if (businessRecordTypes.Entities.Count > 0)
                {
                    foreach (var val in businessRecordTypes.Entities)
                    {
                        //Commented as this is not required. We are checking the same queue which is fetched. 
                        //string queueName = val.Attributes.Contains("rsa_name") ? val.GetAttributeValue<string>("rsa_name") : string.Empty;
                        //if (queueName.ToLower().Equals(_sQueueName.ToLower()))
                        //{

                        //    var ecQueueColl = this.RetrieveMultiple(service, tracingService, sQuery);
                        //    if (ecQueueColl != null && ecQueueColl.Entities.Count > 0 && ecQueueColl[0] != null)
                        //    {
                        //_eQueue = ecQueueColl[0];
                        _eQueue = val;
                        isQueueIdentified = true;
                        //    }
                        //  }
                        tracingService.Trace("isQueueIdentified : " + isQueueIdentified);
                    }
                }
            }
            tracingService.Trace("Method RSA.CSI.Plugins.AssignToCase=>IdentifyQueueForCase()- Unloaded.");
            return isQueueIdentified;
        }

        /// <summary>
        /// UpdatePolicyCaseAssignStatus
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="ePolicy"></param>
        /// <param name="sUpdateResult"></param>
        /// <param name="sComments"></param>
        private void UpdatePolicyCaseAssignStatus(IOrganizationService service, ITracingService tracingService, int iCaseAssignStatusCode, string sComments)
        {
            tracingService.Trace("Method RSA.CSI.Plugins.AssignToCase=>UpdatePolicyCaseAssignStatus()- Loaded.");
            Entity ePolicy_update = new Entity("rsa_policy");
            ePolicy_update.Id = _gPolicyId;
            if (iCaseAssignStatusCode == (int)CASE_ASSIGN_STATUS_CODE.Success)
            {
                ePolicy_update["rsa_renewalgenerationcaseassignstatuscode"] = new OptionSetValue((int)CASE_ASSIGN_STATUS_CODE.Success);
            }
            else if (iCaseAssignStatusCode == (int)CASE_ASSIGN_STATUS_CODE.Failed)
            {
                ePolicy_update["rsa_renewalgenerationcaseassignstatuscode"] = new OptionSetValue((int)CASE_ASSIGN_STATUS_CODE.Failed);
                ePolicy_update["rsa_caseupdatefailreason"] = sComments;
            }
            service.Update(ePolicy_update);
            tracingService.Trace("Method RSA.CSI.Plugins.AssignToCase=>UpdatePolicyCaseAssignStatus()- Unloaded.");
        }
    }
    enum CASE_ASSIGN_STATUS_CODE
    {
        Success = 860002,
        Failed = 860000
    }
    enum CASE_TRADED
    {
        Traded = 866760000,
        OpsTraded = 866760001
    }
}