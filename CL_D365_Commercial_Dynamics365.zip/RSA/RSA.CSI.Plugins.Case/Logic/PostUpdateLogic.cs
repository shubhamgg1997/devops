﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSA.CSI.Plugins.Case.Logic
{
    internal class PostUpdateLogic
    {
        #region Variables
        IOrganizationService service;
        ITracingService tracingService;
        Entity enCaseTarget = new Entity("incident");
        Entity enCasePostImage = new Entity("incident");
        //Entity enCustomerStaging = new Entity("incident");
        Guid guidUserId = Guid.Empty;
        #endregion Variables

        /// <summary>
        /// parameterised constructor
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="enCaseTarget"></param>
        /// <param name="enCasePostImage"></param>
        /// <param name="guidUserId"></param>
        internal PostUpdateLogic(IOrganizationService cService, ITracingService cTracingService, 
            Entity cEnCaseTarget, Entity cEnCasePostImage, Guid cGuidUserId)
        {
            service = cService;
            tracingService = cTracingService;
            enCaseTarget = cEnCaseTarget;
            enCasePostImage = cEnCasePostImage;
            guidUserId = cGuidUserId;
        }

        internal void Execute()
        {
            tracingService.Trace("Calling TraceCaseNumber()");
            RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon = new RSA.CSI.Plugins.Case.CaseCommon.CaseCommon(service, tracingService);
            caseCommon.TraceCaseNumber(enCasePostImage);
            tracingService.Trace("End TraceCaseNumber()");
            //Calling CaseOwnerOnOpp()
            tracingService.Trace("Calling CallCaseOwnerOnOpp()");
            this.CallCaseOwnerOnOpp();
            // Calling SMETaskAssignment
            tracingService.Trace("Calling SMETastAssignment()");
            this.SMETastAssignment(caseCommon);
            tracingService.Trace("Calling setpromisenonpromise()");
            this.setpromisenonpromise();
            tracingService.Trace("end setpromisenonpromise()");
            tracingService.Trace("Calling AmIPolicyHandler");
            this.AmIPolicyHandler();
            tracingService.Trace("end of Calling AmIPolicyHandler");
            tracingService.Trace("Calling currentActivityIsMine");
            this.currentActivityIsMine();
            tracingService.Trace("end of Calling currentActivityIsMine");
            tracingService.Trace("Calling IsMyCase");
            this.IsMyCase();
            tracingService.Trace("end of Calling IsMyCase");
            tracingService.Trace("Calling IsMyTeamsCase");
            this.IsMyTeamsCase();
            tracingService.Trace("end of Calling IsMyTeamsCase");
    }
      

    //IsMyTeamsCase
    private void IsMyTeamsCase()
    {
        RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon = new RSA.CSI.Plugins.Case.CaseCommon.CaseCommon(service, tracingService);
        Entity username = caseCommon.GetUserDetails(guidUserId);
        tracingService.Trace("username found:" + username);
        if (username != null)
        {
               // decimal cygwpexgrossupsterrorismgbp = (enOpportunity.Attributes.Contains("rsa_cygwpexgrossupsterrorismgbp") && !string.IsNullOrEmpty(enOpportunity.GetAttributeValue<decimal>("rsa_cygwpexgrossupsterrorismgbp").ToString()))
               //? (decimal)enOpportunity["rsa_cygwpexgrossupsterrorismgbp"] : ((enPreImage.Attributes.Contains("rsa_cygwpexgrossupsterrorismgbp") && !string.IsNullOrEmpty(enPreImage.GetAttributeValue<decimal>("rsa_cygwpexgrossupsterrorismgbp").ToString()))
               //? (decimal)enPreImage["rsa_cygwpexgrossupsterrorismgbp"] : 0);
                string Myname = username.Attributes.Contains("firstname") ? username["firstname"].ToString() : null;
            tracingService.Trace("Myname found:" + Myname);
            string userteamlevel2 = username.Attributes.Contains("rsa_userteamlevel2") ? username["rsa_userteamlevel2"].ToString() : null;
            EntityReference ownerCopy = (enCaseTarget.Attributes.Contains("rsa_ownercopyid")
                    && !string.IsNullOrEmpty(enCaseTarget.GetAttributeValue<EntityReference>("rsa_ownercopyid").ToString()))
                    ? enCaseTarget.GetAttributeValue<EntityReference>("rsa_ownercopyid") 
                    : (enCasePostImage.Contains("rsa_ownercopyid")
                    && !string.IsNullOrEmpty(enCasePostImage.GetAttributeValue<EntityReference>("rsa_ownercopyid").ToString()))
                    ? enCasePostImage.GetAttributeValue<EntityReference>("rsa_ownercopyid") 
                    : null;
                tracingService.Trace("owner found:" + ownerCopy);
            if (ownerCopy != null)
            {
                Entity enownerCopy = service.Retrieve(ownerCopy.LogicalName, ownerCopy.Id, new ColumnSet(new string[] { "rsa_userteamlevel2" }));
                string ownerCopyUserTeamLevel2 = enownerCopy.Attributes.Contains("rsa_userteamlevel2") ? enownerCopy["rsa_userteamlevel2"].ToString() : null;
                tracingService.Trace("ownerCopyUserTeamLevel2 found:" + ownerCopyUserTeamLevel2);
                if (!string.IsNullOrEmpty(userteamlevel2) && !string.IsNullOrEmpty(ownerCopyUserTeamLevel2))
                    if (userteamlevel2.Contains(ownerCopyUserTeamLevel2))
                    {
                        tracingService.Trace("line 88:");
                        enCaseTarget["rsa_rsaismyteamscase"] = "True";
                        tracingService.Trace("rsa_ismyteamscase:");
                    }
                    else
                    {
                        enCaseTarget["rsa_rsaismyteamscase"] = "False";
                        tracingService.Trace("rsa_ismyteamscase:False");
                    }
            }
        }
        service.Update(enCaseTarget);
    }



    private void IsMyCase()
    {
        RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon = new RSA.CSI.Plugins.Case.CaseCommon.CaseCommon(service, tracingService);
        Entity userId = caseCommon.GetUserDetails(guidUserId);
        tracingService.Trace("userId found:" + userId);
        //EntityReference owner = enCaseTarget.Attributes.Contains("ownerid") ? enCaseTarget.GetAttributeValue<EntityReference>("ownerid") : null;
            EntityReference owner = (enCaseTarget.Attributes.Contains("ownerid")
                    && !string.IsNullOrEmpty(enCaseTarget.GetAttributeValue<EntityReference>("ownerid").ToString()))
                    ? enCaseTarget.GetAttributeValue<EntityReference>("ownerid")
                    : (enCasePostImage.Contains("ownerid")
                    && !string.IsNullOrEmpty(enCasePostImage.GetAttributeValue<EntityReference>("ownerid").ToString()))
                    ? enCasePostImage.GetAttributeValue<EntityReference>("ownerid")
                    : null;




            tracingService.Trace("owner found:" + owner.Id);
        if (userId.Id.Equals(owner.Id))
        {
            enCaseTarget["rsa_rsaismycase"] = "True";
            tracingService.Trace("rsa_rsaismycase:True");
        }
        else
        {
            enCaseTarget["rsa_rsaismycase"] = "False";
            tracingService.Trace("rsa_rsaismycase:False");
        }
        service.Update(enCaseTarget);
    }
    private void AmIPolicyHandler()
    {
        RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon = new RSA.CSI.Plugins.Case.CaseCommon.CaseCommon(service, tracingService);
        Entity userId = caseCommon.GetUserDetails(guidUserId);
        //EntityReference policyId = enCaseTarget.Attributes.Contains("rsa_policyid") ? enCaseTarget.GetAttributeValue<EntityReference>("rsa_policyid") : null;
            EntityReference policyId = (enCaseTarget.Attributes.Contains("rsa_policyid")
                   && !string.IsNullOrEmpty(enCaseTarget.GetAttributeValue<EntityReference>("rsa_policyid").ToString()))
                   ? enCaseTarget.GetAttributeValue<EntityReference>("rsa_policyid")
                   : (enCasePostImage.Contains("rsa_policyid")
                   && !string.IsNullOrEmpty(enCasePostImage.GetAttributeValue<EntityReference>("rsa_policyid").ToString()))
                   ? enCasePostImage.GetAttributeValue<EntityReference>("rsa_policyid")
                   : null;
            tracingService.Trace("policyId found:" + policyId);
            if (policyId != null)
        {
            Entity enPolicyHandler = service.Retrieve(policyId.LogicalName, policyId.Id, new ColumnSet(new string[] { "rsa_policyhandler" }));
            tracingService.Trace("enPolicyHandler found:" + enPolicyHandler);
            Guid PolicyHandlerId = enPolicyHandler.Attributes.Contains("rsa_policyhandler") ? enPolicyHandler.GetAttributeValue<EntityReference>("rsa_policyhandler").Id : Guid.Empty;
            tracingService.Trace("PolicyHandlerId found:" + PolicyHandlerId);
            if (userId.Id.Equals(PolicyHandlerId))
            {
                enCaseTarget["rsa_rsaamipolicyhandler"] = "True";
                tracingService.Trace("rsa_rsaamipolicyhandler:");
            }
            else
            {
                enCaseTarget["rsa_rsaamipolicyhandler"] = "False";
                tracingService.Trace("rsa_rsaamipolicyhandler:False");
            }
        }
        service.Update(enCaseTarget);
    }

    private void currentActivityIsMine()
    {
        //rsa_activityownerid

        RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon = new RSA.CSI.Plugins.Case.CaseCommon.CaseCommon(service, tracingService);
        Entity userId = caseCommon.GetUserDetails(guidUserId);

       // EntityReference activityOwnerId = enCaseTarget.Attributes.Contains("rsa_activityownerid") ? enCaseTarget.GetAttributeValue<EntityReference>("rsa_activityownerid") : null;
            EntityReference activityOwnerId = (enCaseTarget.Attributes.Contains("rsa_activityownerid")
                  && !string.IsNullOrEmpty(enCaseTarget.GetAttributeValue<EntityReference>("rsa_activityownerid").ToString()))
                  ? enCaseTarget.GetAttributeValue<EntityReference>("rsa_activityownerid")
                  : (enCasePostImage.Contains("rsa_activityownerid")
                  && !string.IsNullOrEmpty(enCasePostImage.GetAttributeValue<EntityReference>("rsa_activityownerid").ToString()))
                  ? enCasePostImage.GetAttributeValue<EntityReference>("rsa_activityownerid")
                  : null;
            tracingService.Trace("activityOwnerId found:" + activityOwnerId);
        if (activityOwnerId != null)
        {


            if (userId.Id.Equals(activityOwnerId.Id))
            {
                enCaseTarget["rsa_rsacurrentactivityismine"] = "True";
                tracingService.Trace("rsa_rsacurrentactivityismine:");
            }
            else
            {
                enCaseTarget["rsa_rsacurrentactivityismine"] = "False";
                tracingService.Trace("rsa_rsacurrentactivityismine:False");
            }
        }
        service.Update(enCaseTarget);
    }
    /// <summary>
    /// for bug 1208,1209,1210,1211,1212
    /// to set the promise data on case.
    /// </summary>
    private void setpromisenonpromise()
        {
            tracingService.Trace("insidesetpromisenonpromise ");
            EntityReference caseType = null;
            EntityReference opportunityId = null;
            EntityReference BrokerId = null;
            string promiseNewBusiness = string.Empty;
            EntityReference policyId = null;
            if (enCaseTarget.Attributes.Contains("rsa_casetype"))
            {
                caseType = enCaseTarget.Attributes.Contains("rsa_casetype") ? enCaseTarget.GetAttributeValue<EntityReference>("rsa_casetype") : null;
                tracingService.Trace("imagecaseType" + caseType);
            }
           else if (enCasePostImage.Attributes.Contains("rsa_casetype"))
            {
                caseType = enCasePostImage.Attributes.Contains("rsa_casetype") ? enCasePostImage.GetAttributeValue<EntityReference>("rsa_casetype") : null;
                tracingService.Trace("preimagecaseType" + caseType);
            }
            if (enCaseTarget.Attributes.Contains("rsa_opportunityid"))
            {
                opportunityId = enCaseTarget.Attributes.Contains("rsa_opportunityid") ? enCaseTarget.GetAttributeValue<EntityReference>("rsa_opportunityid") : null;
            }
            else if (enCasePostImage.Attributes.Contains("rsa_opportunityid"))
            {
                opportunityId = enCasePostImage.Attributes.Contains("rsa_opportunityid") ? enCasePostImage.GetAttributeValue<EntityReference>("rsa_opportunityid") : null;
            }
            if (enCaseTarget.Attributes.Contains("rsa_account"))
            {
                BrokerId = enCaseTarget.Attributes.Contains("rsa_account") ? enCaseTarget.GetAttributeValue<EntityReference>("rsa_account") : null;
            }
           else if (enCasePostImage.Attributes.Contains("rsa_account"))
            {
                BrokerId = enCasePostImage.Attributes.Contains("rsa_account") ? enCasePostImage.GetAttributeValue<EntityReference>("rsa_account") : null;
            }
            if (enCaseTarget.Attributes.Contains("rsa_policyid"))
            {
                policyId = enCaseTarget.Attributes.Contains("rsa_policyid") ? enCaseTarget.GetAttributeValue<EntityReference>("rsa_policyid") : null;
            }
           else if (enCasePostImage.Attributes.Contains("rsa_policyid"))
            {
                policyId = enCasePostImage.Attributes.Contains("rsa_policyid") ? enCasePostImage.GetAttributeValue<EntityReference>("rsa_policyid") : null;
            }

            EntityReference pandl = null;
            if (caseType != null)
            {
                tracingService.Trace("case type found:" + caseType.Id);
                if (caseType.Name.ToLowerInvariant().Contains("new business") || caseType.Name.ToLowerInvariant().Contains("schemes - bordereaux") || caseType.Name.ToLowerInvariant().Contains("renewal"))
                {
                    tracingService.Trace("case type name:" + caseType.Name);

                    if ((opportunityId != null && policyId != null) || (opportunityId != null && policyId == null))
                    {
                        tracingService.Trace("opportunityId is not null" );
                        Entity opptyPl = service.Retrieve(opportunityId.LogicalName, opportunityId.Id, new ColumnSet(new string[] { "rsa_pandlid" }));
                        pandl = opptyPl.Attributes.Contains("rsa_pandlid") ? opptyPl.GetAttributeValue<EntityReference>("rsa_pandlid") : null;
                        tracingService.Trace("pandl" + pandl);
                        enCaseTarget["rsa_pl_w"] = pandl.Name;
                    }
                    else if(opportunityId == null && policyId != null)
                    {
                            Entity policyPl = service.Retrieve(policyId.LogicalName, policyId.Id, new ColumnSet(new string[] { "rsa_plcode" }));
                            pandl =( policyPl.Attributes.Contains("rsa_plcode") &&!string.IsNullOrEmpty("rsa_plcode")) ? policyPl.GetAttributeValue<EntityReference>("rsa_plcode") : null;
                            tracingService.Trace("pandl" + pandl);
                        if(!string.IsNullOrEmpty(pandl.ToString()))
                        enCaseTarget["rsa_pl_w"] = pandl.Name;
                    }
                    if (BrokerId != null)
                    {
                        Entity BrokerData = service.Retrieve(BrokerId.LogicalName, BrokerId.Id, new ColumnSet(new string[] { "rsa_promisenewbusiness" }));
                        promiseNewBusiness = BrokerData.FormattedValues.ContainsKey("rsa_promisenewbusiness") ? BrokerData.FormattedValues["rsa_promisenewbusiness"] : null;
                        tracingService.Trace("promise broker from broker value" + promiseNewBusiness);
                    }
                    if (promiseNewBusiness!=null &&pandl != null && promiseNewBusiness.ToLowerInvariant().Contains(pandl.Name.ToLowerInvariant()))
                    {
                        tracingService.Trace("Promise about to set");
                        enCaseTarget["rsa_promise"] = new OptionSetValue(866760000);
                    }
                    else if (promiseNewBusiness != null && pandl != null && !promiseNewBusiness.ToLowerInvariant().Contains(pandl.Name.ToLowerInvariant()))
                    {
                        tracingService.Trace("Non Promise about to set");
                        enCaseTarget["rsa_promise"] = new OptionSetValue(866760001);
                    }
                    service.Update(enCaseTarget);


                }
            }

        }



        /// <summary>
        /// Caling Case Owner on Opportunity
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="enCaseTarget"></param>
        /// <param name="enCasePreImage"></param>
        /// <param name="enCasePostImage"></param>
        private void CallCaseOwnerOnOpp()
        {
            tracingService.Trace("Within CallCaseOwnerOnOpp()");
            tracingService.Trace("Calling StampCaseOwnerOnOpportunity()");
            this.StampCaseOwnerOnOpportunity();
        }

        private void SMETastAssignment(RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon)
        {
            tracingService.Trace("With in SMETastAssignment()");            
            string strSMECaseRecordTypeIds = string.Empty;// caseCommon.GetCustomLabel(service, tracingService, "SMECaseRecordTypeIds");
            string strSMECaseRecordTypes = string.Empty;// caseCommon.GetCustomLabel(service, tracingService, "SMECaseRecordTypes");
            List<string> lstCustomLables = new List<string>();
            lstCustomLables.Add("SMECaseRecordTypeIds");
            lstCustomLables.Add("SMECaseRecordTypes");
            //RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon = new CaseCommon.CaseCommon(service, tracingService);
            tracingService.Trace("Calling custom lables");
            EntityCollection emColCustomLables = caseCommon.GetCustomLabel(lstCustomLables);
            foreach(var enCustomLabel in emColCustomLables.Entities)
            {
                if(enCustomLabel.Attributes.Contains("rsa_name") && 
                    enCustomLabel.Attributes["rsa_name"].ToString().Equals("SMECaseRecordTypeIds") &&
                    enCustomLabel.Attributes.Contains("rsa_values"))
                {
                    strSMECaseRecordTypeIds = enCustomLabel.Attributes["rsa_values"].ToString();
                }
                if (enCustomLabel.Attributes.Contains("rsa_name") &&
                    enCustomLabel.Attributes["rsa_name"].ToString().Equals("SMECaseRecordTypes") &&
                    enCustomLabel.Attributes.Contains("rsa_values"))
                {
                    strSMECaseRecordTypes = enCustomLabel.Attributes["rsa_values"].ToString();
                }
                if (!String.IsNullOrEmpty(strSMECaseRecordTypeIds) && !String.IsNullOrEmpty(strSMECaseRecordTypes)) break;
            }
            tracingService.Trace("strSMECaseRecordTypeIds custom lables: "+ strSMECaseRecordTypeIds);
            tracingService.Trace("strSMECaseRecordTypes custom lables: " + strSMECaseRecordTypes);
            if (enCasePostImage.Attributes.Contains("rsa_casetype") &&
                (strSMECaseRecordTypeIds.Contains(((EntityReference)enCasePostImage.Attributes["rsa_casetype"]).Name) ||
                strSMECaseRecordTypes.Contains(((EntityReference)enCasePostImage.Attributes["rsa_casetype"]).Name)))
            {
                tracingService.Trace("Calling GetTaskDetailsByCaseId().");
                var enTask = this.GetTaskDetailsByCaseId(enCasePostImage.Id);
                if (enTask != null && enTask.Id != Guid.Empty && enCasePostImage.Attributes.Contains("ownerid"))
                {
                    tracingService.Trace("Successfully task fetched.");
                    try
                    {
                        var enTaskToUpdate = new Entity("task");
                        enTaskToUpdate.Id = enTask.Id;
                        enTaskToUpdate["ownerid"] = enCasePostImage["ownerid"];
                        service.Update(enTaskToUpdate);
                        tracingService.Trace("Successfully task upadted.");
                    }
                    catch (Exception ex)
                    {
                        tracingService.Trace("Exception while updating tasks: " + ex.Message);
                    }
                }
                else
                {
                    tracingService.Trace("Unable to fetch task");
                }
            }
        }

        /// <summary>
        ///  Get all not completed/closed tasks having regarding as Case id
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="guidCaseId"></param>
        /// <returns></returns>
        private Entity GetTaskDetailsByCaseId(Guid guidCaseId)
        {
            Entity enTask = null;
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='task'>
                                    <attribute name='subject' />
                                    <attribute name='statecode' />
                                    <attribute name='prioritycode' />
                                    <attribute name='scheduledend' />
                                    <attribute name='createdby' />
                                    <attribute name='regardingobjectid' />
                                    <attribute name='activityid' />
                                    <attribute name='ownerid' />
                                    <order attribute='subject' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='rsa_status' operator='not-in'>
                                        <value>866760004</value>
                                        <value>866760014</value>
                                        <value>866760012</value>
                                        <value>866760005</value>
                                        <value>866760006</value>
                                        <value>866760013</value>
                                        <value>100000000</value>
                                      </condition>
                                    <condition attribute='regardingobjectid' operator='eq' value='{0}'/>
                                    </filter>
                                  </entity>
                                </fetch>";
            try
            {
                var enColTasks = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, guidCaseId)));
                if (enColTasks != null && enColTasks.Entities.Count > 0)
                    enTask = enColTasks.Entities[0];
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception in GetTaskDetailsByCaseId: " + ex.Message);
            }
            return enTask;
        }

        /// <summary>
        /// Update opportunity
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="enCase"></param>
        internal void StampCaseOwnerOnOpportunity()
        {
            tracingService.Trace("With in StampCaseOwnerOnOpportunity()1");
            if (enCasePostImage.Attributes.Contains("rsa_opportunityid"))
            {
                var enOpportunity = new Entity("opportunity");
                enOpportunity.Id = ((EntityReference)enCasePostImage["rsa_opportunityid"]).Id;
                enOpportunity["rsa_case"] = new EntityReference("incident", enCasePostImage.Id);
                if (enCasePostImage.Attributes.Contains("ownerid"))
                {
                    enOpportunity["rsa_caseownername"] = ((EntityReference)enCasePostImage["ownerid"]).Name;
                    tracingService.Trace("Successfully populated rsa_caseownername: " + ((EntityReference)enCasePostImage["ownerid"]).Name);
                }
                else
                {
                    tracingService.Trace("Owner id is missing in Case: " + enCasePostImage.Id);
                }
                try
                {
                    service.Update(enOpportunity);
                    tracingService.Trace("Successfully Oppty updated)");
                }
                catch (Exception ex)
                {
                    tracingService.Trace("Exception while CreateEmailAttachment()" + ex.Message);
                    //throw new Exception("Exception while CreateEmailAttachment()" + ex.Message);
                }
            }
            else
            {
                tracingService.Trace("Opportunity id is missing in Case: " + enCasePostImage.Id);
            }
        }
    }
}