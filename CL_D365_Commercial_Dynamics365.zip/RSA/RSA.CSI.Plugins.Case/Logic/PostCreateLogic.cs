﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;



namespace RSA.CSI.Plugins.Case.Logic
{
    internal class PostCreateLogic
    {
        IOrganizationService service = null;
        ITracingService tracingService = null;
        Entity enCaseTarget = null;
        Guid guidCallingUserId = Guid.Empty;

        #region Constructor 
        internal PostCreateLogic(IOrganizationService cService, ITracingService cTracingService, Entity cEnCaseTarget,Guid cGuidCallingUserId)
        {
            service = cService;
            tracingService = cTracingService;
            enCaseTarget = cEnCaseTarget;
            guidCallingUserId = cGuidCallingUserId;

        }
        #endregion Constructor

        /// <summary>
        /// Execute Case post create logic
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="guidCallingUserId"></param>
        internal void Execute()
        {
            //This is has been considered in Pre Create to avoid any further update plugin trigger            

            //tracingService.Trace("Calling UpdateBrokerName()");
            //this.UpdateBrokerName(service, tracingService, enCaseTarget);
            tracingService.Trace("Calling CreateEmailMessage()");
            this.CreateEmailMessage();
            tracingService.Trace("Calling StampCaseOwnerOnOpportunity()");
            this.StampCaseOwnerOnOpportunity();
            tracingService.Trace("End of Post Create execute");
            //tracingService.Trace("Calling setpromisenonpromise");
            //this.setpromisenonpromise();
            //tracingService.Trace("end of setpromisenonpromise");
            //tracingService.Trace("Calling AmIPolicyHandler");
            //this.AmIPolicyHandler();
            //tracingService.Trace("end of Calling AmIPolicyHandler");
            //tracingService.Trace("Calling currentActivityIsMine");
            //this.currentActivityIsMine();
            //tracingService.Trace("end of Calling currentActivityIsMine");
            //tracingService.Trace("Calling IsMyCase");
            //this.IsMyCase();
            //tracingService.Trace("end of Calling IsMyCase");
            //tracingService.Trace("Calling IsMyTeamsCase");
            //this.IsMyTeamsCase();
            //tracingService.Trace("end of Calling IsMyTeamsCase");
        }
      
        //IsMyTeamsCase
        private void IsMyTeamsCase()
        {
            RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon = new RSA.CSI.Plugins.Case.CaseCommon.CaseCommon(service, tracingService);
            Entity username = caseCommon.GetUserDetails(guidCallingUserId);

            //var username = service.Retrieve("systemuser", enUser, new ColumnSet(new string[] { "rsa_userteamlevel2", "firstname" }));
            tracingService.Trace("username found:" + username);
            if (username != null)
            {
                string Myname = username.Attributes.Contains("firstname") ? username["firstname"].ToString() : null;
                tracingService.Trace("Myname found:" + Myname);
                string userteamlevel2 = username.Attributes.Contains("rsa_userteamlevel2") ? username["rsa_userteamlevel2"].ToString():null;
                EntityReference ownerCopy = enCaseTarget.Attributes.Contains("rsa_ownercopyid") ? enCaseTarget.GetAttributeValue<EntityReference>("rsa_ownercopyid") : null;
                tracingService.Trace("owner found:" + ownerCopy);
                if (ownerCopy != null)
                {
                    Entity enownerCopy = service.Retrieve(ownerCopy.LogicalName, ownerCopy.Id, new ColumnSet(new string[] { "rsa_userteamlevel2" }));
                    string ownerCopyUserTeamLevel2 = enownerCopy.Attributes.Contains("rsa_userteamlevel2") ? enownerCopy["rsa_userteamlevel2"].ToString():null;
                    tracingService.Trace("ownerCopyUserTeamLevel2 found:" + ownerCopyUserTeamLevel2);
                    if(!string.IsNullOrEmpty(userteamlevel2)&&!string.IsNullOrEmpty(ownerCopyUserTeamLevel2))
                    if (userteamlevel2.Contains(ownerCopyUserTeamLevel2))
                    {
                        tracingService.Trace("line 88:");
                        enCaseTarget["rsa_rsaismyteamscase"] = "True";
                        tracingService.Trace("rsa_ismyteamscase:");
                    }
                    else
                    {
                        enCaseTarget["rsa_rsaismyteamscase"] = "False";
                        tracingService.Trace("rsa_ismyteamscase:False");
                    }
                }
            }
            service.Update(enCaseTarget);
        }



        private void IsMyCase()
        {
            RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon = new RSA.CSI.Plugins.Case.CaseCommon.CaseCommon(service, tracingService);
            Entity userId = caseCommon.GetUserDetails(guidCallingUserId);
            tracingService.Trace("userId found:" + userId);
            EntityReference owner = enCaseTarget.Attributes.Contains("ownerid") ? enCaseTarget.GetAttributeValue<EntityReference>("ownerid") : null;
            tracingService.Trace("owner found:" + owner.Id);
            if (userId.Id.Equals(owner.Id))
            {
                enCaseTarget["rsa_rsaismycase"] = "True";
                tracingService.Trace("rsa_rsaismycase:True");
            }
            else
            {
                enCaseTarget["rsa_rsaismycase"] = "False";
                tracingService.Trace("rsa_rsaismycase:False");
            }
            service.Update(enCaseTarget);
        }
        private void AmIPolicyHandler()
        {
            RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon = new RSA.CSI.Plugins.Case.CaseCommon.CaseCommon(service, tracingService);
            Entity userId = caseCommon.GetUserDetails(guidCallingUserId);
           
            EntityReference owner = enCaseTarget.Attributes.Contains("ownerid") ? enCaseTarget.GetAttributeValue<EntityReference>("ownerid") : null;
            tracingService.Trace("owner found:" + owner);
            EntityReference policyId = enCaseTarget.Attributes.Contains("rsa_policyid") ? enCaseTarget.GetAttributeValue<EntityReference>("rsa_policyid") : null;
            tracingService.Trace("policyId found:" + policyId);
                if(policyId != null) {
                Entity enPolicyHandler = service.Retrieve(policyId.LogicalName, policyId.Id, new ColumnSet(new string[] { "rsa_policyhandler" }));
                tracingService.Trace("enPolicyHandler found:" + enPolicyHandler);
                Guid PolicyHandlerId = enPolicyHandler.Attributes.Contains("rsa_policyhandler") ? enPolicyHandler.GetAttributeValue<EntityReference>("rsa_policyhandler").Id : Guid.Empty;
                tracingService.Trace("PolicyHandlerId found:" + PolicyHandlerId);
                if (userId.Id.Equals(PolicyHandlerId))
                {
                    enCaseTarget["rsa_rsaamipolicyhandler"] = "True";
                    tracingService.Trace("rsa_rsaamipolicyhandler:");
                }
                else
                {
                    enCaseTarget["rsa_rsaamipolicyhandler"] = "False";
                    tracingService.Trace("rsa_rsaamipolicyhandler:False");
                } }
            service.Update(enCaseTarget);
        }

        private void currentActivityIsMine()
        {
            //rsa_activityownerid

            RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon = new RSA.CSI.Plugins.Case.CaseCommon.CaseCommon(service, tracingService);
            Entity userId = caseCommon.GetUserDetails(guidCallingUserId);
           
            EntityReference activityOwnerId = enCaseTarget.Attributes.Contains("rsa_activityownerid") ? enCaseTarget.GetAttributeValue<EntityReference>("rsa_activityownerid") : null;
            tracingService.Trace("activityOwnerId found:" + activityOwnerId);
            if (activityOwnerId != null)
            {
                
                
                    if (userId.Id.Equals(activityOwnerId.Id))
                    {
                        enCaseTarget["rsa_rsacurrentactivityismine"] = "True";
                        tracingService.Trace("rsa_rsacurrentactivityismine:");
                    }
                    else
                    {
                        enCaseTarget["rsa_rsacurrentactivityismine"] = "False";
                        tracingService.Trace("rsa_rsacurrentactivityismine:False");
                    }
                }
            service.Update(enCaseTarget);
        }
        /// <summary>
        /// for bug 1208,1209,1210,1211,1212
        /// to set the promise data on case. 
        /// </summary>
        private void setpromisenonpromise()
        {
            EntityReference caseType = enCaseTarget.Attributes.Contains("rsa_casetype")? enCaseTarget.GetAttributeValue<EntityReference>("rsa_casetype") : null;
            EntityReference opportunityId = enCaseTarget.Attributes.Contains("rsa_opportunityid") ? enCaseTarget.GetAttributeValue<EntityReference>("rsa_opportunityid") : null;
            EntityReference BrokerId = enCaseTarget.Attributes.Contains("rsa_account") ? enCaseTarget.GetAttributeValue<EntityReference>("rsa_account") : null;
            EntityReference policyId= enCaseTarget.Attributes.Contains("rsa_policyid") ? enCaseTarget.GetAttributeValue<EntityReference>("rsa_policyid") : null;
            EntityReference pandl = null;
            string promiseBroker = enCaseTarget.Attributes.Contains("rsa_promisebroker") ? enCaseTarget.GetAttributeValue<string>("rsa_promisebroker") : string.Empty;
            string promiseNewBusiness = null;
            if (caseType != null)
            {
                tracingService.Trace("case type found:"+ caseType.Id);
                if (caseType.Name.ToLowerInvariant().Contains("new business") || caseType.Name.ToLowerInvariant().Contains("schemes - bordereaux") || caseType.Name.ToLowerInvariant().Contains("schemes - review"))
                {
                    tracingService.Trace("case type name:" + caseType.Name);
                    if ((opportunityId != null && policyId != null) ||( opportunityId!=null && policyId==null))
                    {
                        Entity opptyPl = service.Retrieve(opportunityId.LogicalName, opportunityId.Id, new ColumnSet(new string[] { "rsa_pandlid" }));
                        pandl = opptyPl.Attributes.Contains("rsa_pandlid") ? opptyPl.GetAttributeValue<EntityReference>("rsa_pandlid") : null;
                        tracingService.Trace("pandl" + pandl);
                    }
                    else if (opportunityId == null && policyId != null)
                    {
                        Entity policyPl = service.Retrieve(policyId.LogicalName, policyId.Id, new ColumnSet(new string[] { "rsa_plcode" }));
                        pandl = policyPl.Attributes.Contains("rsa_plcode") ? policyPl.GetAttributeValue<EntityReference>("rsa_plcode") : null;
                        tracingService.Trace("pandl" + pandl);
                        enCaseTarget["rsa_pl_w"] = pandl.Name;
                    }
                    if (BrokerId != null) {
                        Entity BrokerData = service.Retrieve(BrokerId.LogicalName, BrokerId.Id, new ColumnSet(new string[] { "rsa_promisenewbusiness" }));
                         promiseNewBusiness = BrokerData.FormattedValues.ContainsKey("rsa_promisenewbusiness") ? BrokerData.FormattedValues["rsa_promisenewbusiness"] : null;
                        tracingService.Trace("promise broker from broker value" + promiseNewBusiness);
                    }
                    if (promiseNewBusiness != null && pandl != null && promiseNewBusiness.ToLowerInvariant().Contains(pandl.Name.ToLowerInvariant()))
                    {
                        tracingService.Trace("Promise about to set");
                        enCaseTarget["rsa_promise"] = new OptionSetValue(866760000);
                    }
                    else if(promiseNewBusiness != null && pandl != null && !promiseNewBusiness.ToLowerInvariant().Contains(pandl.Name.ToLowerInvariant()))
                    {
                        tracingService.Trace("Non Promise about to set");
                        enCaseTarget["rsa_promise"] = new OptionSetValue(866760001);
                    }
                        service.Update(enCaseTarget);
                    
                }
            }

        }
            /// <summary>
            /// Create email message
            /// </summary>
            /// <param name="service"></param>
            /// <param name="tracingService"></param>
            /// <param name="guidCallingUserId"></param>
            private void CreateEmailMessage()
        {
            RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon = new RSA.CSI.Plugins.Case.CaseCommon.CaseCommon(service,tracingService);
            tracingService.Trace("Within CreateEmailMessage()");
            var enUser = caseCommon.GetUserDetails(guidCallingUserId);
            if (enUser != null && enUser.Attributes.Contains("rsa_cloneofid")) 
            {
                tracingService.Trace("Successfully fetched User");
                string strCloneId = (string)enUser.Attributes["rsa_cloneofid"];
                var enEmail = this.GetEmailDetails(strCloneId);                
                if (enEmail != null && enEmail.Id != Guid.Empty)
                {
                    tracingService.Trace("Successfully fetched Email");
                    var guidOldEmailId = enEmail.Id;
                    var guidCreatedEmailId = this.CreateEmail(enEmail);
                    tracingService.Trace("Successfully created Email");
                    this.UpdateUser(enUser);
                    tracingService.Trace("Successfully updated User");
                    if (enEmail.Attributes.Contains("attachmentcount"))
                    {
                        tracingService.Trace("Email has attachment");
                        var enAttachemnt = this.GetEmailAttachment(guidOldEmailId);
                        var intEmailAttachmentCount = (int)enEmail.Attributes["attachmentcount"];
                        if (intEmailAttachmentCount > 0 && enAttachemnt != null)
                        {
                            tracingService.Trace("Successfully fetched attachment");
                            this.CreateEmailAttachment(guidCreatedEmailId, enAttachemnt);
                            tracingService.Trace("Successfully created email attahcment");
                        }
                        else
                        {
                            tracingService.Trace("Unable to fetch email attachment");
                        }
                    }
                    else
                    {
                        tracingService.Trace("There is no email attachment");
                    }
                }
                else
                {
                    tracingService.Trace("Unable to fetch Email");
                }
            }
            else
            {
                tracingService.Trace("Unable to fetch user with id(InitiatingUserId): "+ guidCallingUserId);
                tracingService.Trace("Reason is rsa_cloneofid is null in systemuser/ or user doesn't exists");
            }
        }

        /// <summary>
        /// Get email details based on Case id  
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="guidCaseId"></param>
        /// <returns></returns>
        private Entity GetEmailDetails(string strCaseId)
        {
            var enEmail = new Entity();
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='email'>
                                    <attribute name='subject' />
                                    <attribute name='regardingobjectid' />
                                    <attribute name='from' />
                                    <attribute name='to' />
                                    <attribute name='prioritycode' />
                                    <attribute name='statuscode' />
                                    <attribute name='modifiedon' />
                                    <attribute name='activityid' />
                                    <attribute name='description' />
                                    <attribute name='attachmentcount' />
                                    <attribute name='cc' />
                                    <attribute name='bcc' />
                                    <order attribute='subject' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='rsa_parentcase' operator='eq' value='{0}' />
                                    </filter>
                                  </entity>
                                </fetch>";
            try
            {
                EntityCollection enColEmail = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, strCaseId)));
                if (enColEmail != null && enColEmail.Entities.Count > 0)
                {
                    enEmail = enColEmail.Entities[0];
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetching GetEmailDetails()" + ex.Message);
                //throw new Exception("Exception while fetching GetEmailDetails()" + ex.Message);
            }
            return enEmail;
        }

        /// <summary>
        /// Create email record
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="enEmail"></param>
        /// <param name="guidCaseId"></param>
        private Guid CreateEmail(Entity enEmail)
        {
            Guid returnCreatedEmailId = Guid.Empty;
            Entity partyFrom = new Entity("activityparty");
            partyFrom["partyid"] = new EntityReference("systemuser", guidCallingUserId);
            EntityCollection enColFrom = new EntityCollection();
            enColFrom.Entities.Add(partyFrom);

            var enEmailToCreate = new Entity("email");
            enEmailToCreate["rsa_parentcase"] = new EntityReference("incident", enCaseTarget.Id);
            if (enEmail.Attributes.Contains("description"))
                enEmailToCreate["description"] = enEmail["description"];
            if (enEmail.Attributes.Contains("subject"))
                enEmailToCreate["subject"] = enEmail["subject"];
            if (enEmail.Attributes.Contains("to"))
                enEmailToCreate["to"] = enColFrom;
            if (enEmail.Attributes.Contains("from"))
                enEmailToCreate["from"] = enColFrom;
            enEmailToCreate["regardingobjectid"] = new EntityReference("incident", enCaseTarget.Id);
            enEmailToCreate["directioncode"] = true;
            try
            {
                returnCreatedEmailId = service.Create(enEmailToCreate);
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while creating Email CreateEmail()" + ex.Message);
                //throw new Exception("Exception while creating Email CreateEmail()" + ex.Message);
            }
            return returnCreatedEmailId;
        }

        /// <summary>
        /// Update system user with rsa_cloneofid =  null
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="enUser"></param>
        private void UpdateUser(Entity enUser)
        {
            enUser["rsa_cloneofid"] = null;
            try
            {
                service.Update(enUser);
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while UpdateUser()" + ex.Message);
                //throw new Exception("Exception while UpdateUser()" + ex.Message);
            }
        }

        /// <summary>
        /// Get attachment 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="guidEmailId"></param>
        private Entity GetEmailAttachment(Guid guidEmailId)
        {
            var enAttachment = new Entity();
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='activitymimeattachment'>
                                    <attribute name='subject' />
                                    <attribute name='filename' />
                                    <attribute name='body' />                                    
                                    <order attribute='subject' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='activityid' operator='eq' value='{0}' />
                                    </filter>
                                  </entity>
                                </fetch>";
            try
            {
                EntityCollection enColAttachment = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, guidEmailId)));
                if (enColAttachment != null && enColAttachment.Entities.Count > 0)
                {
                    enAttachment = enColAttachment.Entities[0];
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetching GetEmailAttachment()" + ex.Message);
                //throw new Exception("Exception while fetching GetEmailAttachment()" + ex.Message);
            }
            return enAttachment;
        }

        /// <summary>
        /// Create email attachment 
        /// </summary>
        /// <param name="guidEmailId"></param>
        /// <param name="enAttchment"></param>
        private void CreateEmailAttachment(Guid guidEmailId, Entity enAttchment)
        {
            if (guidEmailId == Guid.Empty)
            {
                tracingService.Trace("Email Id is empty guid" + guidEmailId.ToString());
                return;
            }
            var enEmailAttachment = new Entity("activitymimeattachment");

            enEmailAttachment["objectid"] = new EntityReference("email", guidEmailId);
            if (enAttchment.Attributes.Contains("subject"))
                enEmailAttachment["subject"] = enAttchment["subject"];
            if (enAttchment.Attributes.Contains("body"))
                enEmailAttachment["body"] = enAttchment["body"];
            if (enAttchment.Attributes.Contains("mimetype"))
                enEmailAttachment["mimetype"] = enAttchment["mimetype"];
            if (enAttchment.Attributes.Contains("filename"))
                enEmailAttachment["filename"] = enAttchment["filename"];
            enEmailAttachment["objecttypecode"] = "email";
            try
            {
                service.Create(enEmailAttachment);
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while CreateEmailAttachment()" + ex.Message);
                //throw new Exception("Exception while CreateEmailAttachment()" + ex.Message);
            }
        }

        /// <summary>
        /// Update opportunity
        /// </summary>
        internal void StampCaseOwnerOnOpportunity()
        {
            tracingService.Trace("With in StampCaseOwnerOnOpportunity()");
            if (enCaseTarget.Attributes.Contains("rsa_opportunityid") && enCaseTarget["rsa_opportunityid"] != null && ((EntityReference)enCaseTarget["rsa_opportunityid"]).Id.ToString() != string.Empty)
            {
                var enOpportunity = new Entity("opportunity");
                enOpportunity.Id = ((EntityReference)enCaseTarget["rsa_opportunityid"]).Id;
                enOpportunity["rsa_case"] = new EntityReference("incident", enCaseTarget.Id);
                if (enCaseTarget.Attributes.Contains("ownerid"))
                {
                    enOpportunity["rsa_caseownername"] = ((EntityReference)enCaseTarget["ownerid"]).Name;
                    tracingService.Trace("Successfully populated rsa_caseownername: "+ ((EntityReference)enCaseTarget["ownerid"]).Name);
                }
                else
                {
                    tracingService.Trace("Owner id is missing in Case: " + enCaseTarget.Id);
                }
                try
                {
                    service.Update(enOpportunity);
                    tracingService.Trace("Successfully Oppty updated)");
                }
                catch (Exception ex)
                {
                    tracingService.Trace("Exception while StampCaseOwnerOnOpportunity()" + ex.Message);
                    //throw new Exception("Exception while CreateEmailAttachment()" + ex.Message);
                }
            }
            else
            {
                tracingService.Trace("Opportunity id is missing in Case: "+ enCaseTarget.Id);
            }
        }
    }
}