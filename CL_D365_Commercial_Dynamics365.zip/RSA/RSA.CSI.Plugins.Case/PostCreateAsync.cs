﻿using Microsoft.Xrm.Sdk;
using RSA.CSI.Plugins.Case.Common;
using RSA.CSI.Plugins.Case.Logic;
using System;

namespace RSA.CSI.Plugins.Case
{
    public class PostCreateAsync : PluginBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PostCreate"/> class.
        /// </summary>
        public PostCreateAsync()
            : base(typeof(PostCreateAsync))
        {
            RegisteredEvents.Add(new Tuple<int, string, string, Action<LocalPluginContext>>(40, "Create", "incident", Execute));
        }

        /// <summary>
        /// Start Validating the record when the regsiterd event occurs
        /// </summary>
        /// <param name="localContext"></param>
        protected void Execute(LocalPluginContext localContext)
        {
            #region Generic block of Context null checking and service creation block

            if (localContext == null)
            {
                throw new ArgumentNullException("localContext");
            }
            IPluginExecutionContext context = localContext.PluginExecutionContext;
            IOrganizationService service = localContext.OrganizationService;
            ITracingService tracingService = localContext.TracingService;
            #endregion Generic block of Context null checking and service creation block
            
            AssignToQueue oAssignToQueue = new AssignToQueue();
            tracingService.Trace("AssignToQueue class object created.");
            oAssignToQueue.Execute(context, service, tracingService);
        }
    }
}
