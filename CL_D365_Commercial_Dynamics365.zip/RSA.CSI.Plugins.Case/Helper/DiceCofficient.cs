﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSA.CSI.Plugins.Case.Helper
{
    public static class DiceCoefficient
    {
        public static double DiceCoefficientAlgo(string stOne, string stTwo)
        {
            HashSet<string> nx = BuildBigramSet(stOne);
            HashSet<string> ny = BuildBigramSet(stTwo);

            HashSet<string> intersection = new HashSet<string>(nx);
            intersection.IntersectWith(ny);

            double dbOne = intersection.Count;
            return (2 * dbOne) / (nx.Count + ny.Count);

        }

        public static HashSet<string> BuildBigramSet(string input)
        {
            HashSet<string> bigrams = new HashSet<string>();

            for (int i = 0; i < input.Length - 1; i++)
            {
                bigrams.Add(input.Substring(i, 2));
            }
            return bigrams;
        }

        public static String GetBigramString(String name)
        {
            List<string> bigramList = new List<string>();
            if (!String.IsNullOrEmpty(name))
            {
                // Calls the splitIntoBigrams() method of DiceCoefficient class to get the bi grams of a name 
                //which is an input parameter to the method. 
                bigramList.Add(DiceCoefficient.SplitIntoBigrams(name));
            }
            return StringUtilities.ListToString(bigramList.ToArray(), ";");
        }

        public static String SplitIntoBigrams(String s)
        {
            List<String> bigrams = new List<String>();
            if (s.Length < 2)
            {
                bigrams.Add(s);
            }
            else
            {
                for (int i = 0; i < s.Length - 1; i++)
                {
                    bigrams.Add(s.Substring(i, 2));
                }
            }
            return String.Join(";", bigrams.ToArray()).ToLower();
        }

        public static Double compareStrings(String str1, String str2)
        {
            if (str1 == null || str2 == null) return 0;

            // Create two sets of character bigrams, one for each string.
            String[] s1 = SplitIntoBigrams(str1).Split(";");
            String[] s2 = SplitIntoBigrams(str2).Split(";");

            return compareBigramSets(s1, s2);
        }

        public static Double compareBigramStrings(String bs1, String bs2)
        {
            if (bs1 == null || bs2 == null) return 0;
            String[] s1 = bs1.Split(';');
            String[] s2 = bs2.Split(';');

            return compareBigramSets(s1, s2);
        }

        private static Double compareBigramSets(String[] s1, String[] s2)
        {

            // Get the number of elements in each set.
            int n1 = s1.Length;
            int n2 = s2.Length;
            int count = 0;
            // Find the intersection, and get the number of elements in that set.
            //s1.retainAll(s2);
            foreach (string s1String in s1)
            {
                foreach (string s2String in s2)
                {
                    if (s1String == s2String)
                    {
                        count++;
                    }
                }
            }
            int nt = count;

            return (2.0 * (double)nt) / ((double)(n1 + n2)) * 100;

        }
    }
}