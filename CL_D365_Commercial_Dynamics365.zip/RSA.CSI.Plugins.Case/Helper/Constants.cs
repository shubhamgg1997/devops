﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace RSA.CSI.Plugins.Case.Helper
{
    public static class RSAConstants
    {
        
    }

    public static class RSAEnum
    {
        public enum OPS_Task_rsa_Status
        {
            Completed = 866760004,
            CompletedFollowUp = 866760005,
            CompletedHandedBack = 866760006,
            CompletedReferred = 100000000,
            CompletedAutomated = 866760012,
            CompletedNoActionRequired = 866760013,
            CompletedActionsRequired = 866760014,
        }
        public enum OPS_Opportunity_rsa_opportunityorigin
        {
            Pipeline = 866760000,
        }
        public enum OPS_Case_rsa_traded
        {
            Traded = 866760000,
            OpsTraded = 866760001,
        }
        public enum OPS_Case_rsa_promise
        {
            Promise = 866760000,
            NonPromise = 866760001
        }
        public enum OPS_Case_rsa_policymatchstatus
        {
            NoPolicyNumberinEmail = 866760000,
            MultipleMatchingPolicies = 866760002,
            MatchFound = 866760003,
        }
        public enum OPS_Case_caseorigincode
        {
            Email = 2,
        }
        public enum OPS_Case_rsa_duplicatecheckstatus
        {
            Checking = 866760000,
        }
        public enum OPS_Policy_rsa_operationshandlingsite
        {
            IsleofMan = 866760010,
        }
        public enum RSA_Entities
        {
            rsa_casetype,
            contact,
            rsa_customer,
            account,
            rsa_opportunitystage
        }
        public enum OPS_Opportunity_rsa_stage
        {
            InView = 866760033
        }
        public enum rsa_opportunitystage
        {
            name,
            estimatedvalue,
            rsa_stage,
            rsa_targetpremium,
            rsa_secondaryowner,
            rsa_periodofinsurancemonths,
            rsa_opportunityoutcomereason,
            rsa_opportunityorigin, 
            rsa_opportunityname, 
            rsa_opportunitydescription, 
            rsa_longtermagreement, 
            rsa_isupdated,
            rsa_closedate, 
            rsa_brokercontact, 
            rsa_amountvariance, 
            description, 
            rsa_createopportunityfornextyearifntu, 
            rsa_prospecttype, 
            totalamount
        }
    }
}