﻿using Microsoft.Xrm.Sdk;
using RSA.CSI.Plugins.Case.Common;
using RSA.CSI.Plugins.Case.Logic;
using System;

namespace RSA.CSI.Plugins.Case
{
    public class PreCreate : PluginBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PreCreate"/> class.
        /// </summary>
        public PreCreate()
            : base(typeof(PreCreate))
        {
            RegisteredEvents.Add(new Tuple<int, string, string, Action<LocalPluginContext>>(20, "Create", "incident", ExecuteCasePreCreate));
        }

        /// <summary>
        /// Start Validating the record when the regsiterd event occurs
        /// </summary>
        /// <param name="localContext"></param>
        protected void ExecuteCasePreCreate(LocalPluginContext localContext)
        {
            #region Generic block of Context null checking and service creation block

            if (localContext == null)
            {
                //throw new ArgumentNullException("localContext");
                //Remediation - 18/07/2022
                throw new InvalidPluginExecutionException("localContext");
            }
            IPluginExecutionContext context = localContext.PluginExecutionContext;
            IOrganizationService service = localContext.OrganizationService;
            ITracingService tracingService = localContext.TracingService;
            #endregion Generic block of Context null checking and service creation block  

            #region Get Input Parameters

            if (context.InputParameters["Target"] != null && (Entity)context.InputParameters["Target"] != null)
            {
                try
                {
                    var enCaseTarget = context.InputParameters["Target"] as Entity;
                    tracingService.Trace("Calling PreCreateLogic()1");
                    //EntityReference caseType = enCaseTarget.Attributes.Contains("rsa_casetype") ? enCaseTarget.GetAttributeValue<EntityReference>("rsa_casetype") : null;
                    //tracingService.Trace("Case type from caseprecreate main class" + caseType);
                    PreCreateLogic preCreate = new PreCreateLogic(service, tracingService, enCaseTarget,context.InitiatingUserId);
                    
                    preCreate.Execute();
                    tracingService.Trace("Successfully completed Case Pre Create plugin");
                }
                catch (Exception ex)
                {
                    tracingService.Trace("Exception: " + ex.Message);
                    throw new InvalidPluginExecutionException("ExecuteCasePreCreatePlugin: " + ex.Message);
                }
            }
            else
            {
                tracingService.Trace("Target is null in PreCreate");
                throw new InvalidPluginExecutionException("Target is null in PreCreate");
            }

            #endregion  Get Input Parameters
        }
    }
}
