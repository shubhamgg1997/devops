﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using RSA.CSI.Plugins.Case.CaseCommon;


namespace RSA.CSI.Plugins.Case.Logic
{
    internal class CustDupeFinderNew
    {
        #region Constant 
        private const string STANDARD_POLICY = "";
        #endregion Constant

        #region Variables
        IOrganizationService service;
        ITracingService tracingService;
        string strPrefixKeyPref3 = string.Empty;
        string strQuery = string.Empty;
        Entity enCaseTarget = null;
        Entity enCasePreImage = null;
        string strClientName = string.Empty;
        string strClientPostCode = string.Empty;
        #endregion Variables

        #region Constructor
        internal CustDupeFinderNew(IOrganizationService cService, ITracingService cTracingService, string cPrefixKeyPref3, string cClientName, string cClientPostCode,
            string cQuery, Entity cCaseTarget, Entity cCasePreImage)
        {
            service = cService;
            tracingService = cTracingService;
            strPrefixKeyPref3 = cPrefixKeyPref3;
            strClientName = cClientName;
            strClientPostCode = cClientPostCode;
            strQuery = cQuery;
            enCaseTarget = cCaseTarget;
            enCasePreImage = cCasePreImage;
        }

        #endregion Constructor

        internal void Execute()
        {
            tracingService.Trace("Within CustDupeFinderNew.Execute()");
            var strPrefix = string.Empty;
            var strCheckName = string.Empty;
            string strPrefixMatch = string.Empty;
            //if (enCustomerStaging == null || !enCustomerStaging.Attributes.Contains("rsa_keywordprefix3"))
            //{
            //    tracingService.Trace("Customer Staging obj is null or empty.");
            //    return;
            //}
            //else
            //{
            //Dictionary<Entity, string> dicCustomerStaging1 = new Dictionary<Entity, string>();
            //strPrefix = enCustomerStaging.Attributes["rsa_keywordprefix3"].ToString();
            //tracingService.Trace("strPrefix: " + strPrefix);
            //tracingService.Trace("strPrefixKeyPref3: " + strPrefixKeyPref3);
            //if (strPrefix.Equals(strPrefixKeyPref3))
            //    dicCustomerStaging1.Add(enCustomerStaging, strPrefix);
            //tracingService.Trace("Calling GetCustomerDetailsByKeyword");
            /*
             //Commenting the below part as this is to associate customer with Customer Staging, and SME customer staging will not be considerd in D365
            var enColCustomerDetails = this.GetCustomerDetailsByKeyword(strQuery);

            if (enColCustomerDetails == null)
            {
                tracingService.Trace("Unable to fetch customers");
                return;
            }
            else
            {
                tracingService.Trace("successfully fetched GetCustomerDetailsByKeyword");
               // Dictionary<EntityCollection, string> dicCustomer2 = new Dictionary<EntityCollection, string>();
                EntityCollection enColCustomer = new EntityCollection();
                strPrefixMatch = " " + strPrefixKeyPref3.Replace("_", " ").ToLower();
                tracingService.Trace("strPrefixMatch: " + strPrefixMatch);
                foreach (var enCust in enColCustomerDetails.Entities)
                {
                    if (enCust.Attributes.Contains("rsa_keywordcheckname") &&
                        strCheckName.Contains(enCust.Attributes["rsa_keywordcheckname"].ToString()) &&
                        enCust.Attributes.Contains("rsa_keywordprefix3") &&
                        enCust.Attributes["rsa_keywordprefix3"].ToString().Equals(strPrefixKeyPref3))
                    {
                        enColCustomer.Entities.Add(enCust);
                    }
                    else
                    {
                        tracingService.Trace("Validation failed for enColCustomerDetails");
                    }
                }
                if (enColCustomer.Entities.Count == 0)
                {
                    tracingService.Trace("enColCustomerStaging count is 0");
                }
                else
                {
                    //dicCustomer2.Add(enColCustomer, strPrefixKeyPref3);
                    //if (dicCustomerStaging1.Count > 0)
                    //{
                        //tracingService.Trace("Calling DupeSMEFinderDetail: TODO");
                        //var custDupeFinderNew = new DupeSMEFinderDetail(service, tracingService, dicCustomerStaging1, dicCustomer2);
                    //var custDupeFinderNew = new DupeSMEFinderDetail(service, tracingService,str,dicCustomer2);
                    //custDupeFinderNew.Execute();
                    //}
                }
            //}
        }*/

            //Call finish Method
            this.Finish();
        }

        private void Finish()
        {
            tracingService.Trace("Within Finish()");
            //Create Customer
            tracingService.Trace("Creating customer");
            var guidCustomerId = this.CreateCustomer();
            //if (guidCustomerId != Guid.Empty)
            //{
            //    tracingService.Trace("Calling UpdateCustomerStaging()");
            //    this.UpdateCustomerStaging(enCustomerStaging, guidCustomerId);
            //    tracingService.Trace("Successfully updated  Customer Staging()");
            //}
            //enCaseTarget["rsa_smecuststagingid"] = new EntityReference("rsa_smecustomerstaging", enCustomerStaging.Id);
            //Chandani: added condition to resolve ISV issue
            if(guidCustomerId!= Guid.Empty)
            {
                enCaseTarget["rsa_customerrsa"] = new EntityReference("rsa_customer", guidCustomerId);
            }
            
            tracingService.Trace("Calling UpdatePolicy()");
            this.UpdatePolicy();
            tracingService.Trace("Successfully Updated Policy.");
        }

        /// <summary>
        /// Create customer
        /// </summary>
        /// <param name="enCustomerStaging"></param>
        /// <returns></returns>
        private Guid CreateCustomer()
        {
            tracingService.Trace("Within CreateCustomer()");
            var enCustomer = new Entity("rsa_customer");
            enCustomer["rsa_name"] = strClientName;
            enCustomer["rsa_postalcode"] = strClientPostCode;
            try
            {
                return service.Create(enCustomer);
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while customer creation in CreateCustomer(): " + ex.Message);
            }
            return Guid.Empty;
        }
        /// <summary>
        /// Update customer staging
        /// </summary>
        /// <param name="enCustomerStaging"></param>
        //private void UpdateCustomerStaging(Entity enCustomerStaging, Guid guidCustomerId)
        //{
        //    tracingService.Trace("Within UpdateCustomerStaging()");
        //    var enCustStaging = new Entity("rsa_smecustomerstaging");
        //    enCustStaging.Id = enCustomerStaging.Id;
        //    enCustStaging["rsa_possiblesmeduplicatelinkid"] = new EntityReference("rsa_customer", guidCustomerId);
        //    enCustStaging["rsa_duplicatecheckstatus"] = new OptionSetValue(866760003); // No Duplicates
        //    try
        //    {
        //        service.Update(enCustStaging);
        //        tracingService.Trace("Successfully updated Customer Staging");
        //    }
        //    catch (Exception ex)
        //    {
        //        tracingService.Trace("Exception while customer staging  update in UpdateCustomerStaging(): " + ex.Message);
        //    }
        //}

        /// <summary>
        /// Update policy record
        /// </summary>
        private void UpdatePolicy()
        {
            try
            {
                tracingService.Trace("Within UpdatePolicy");
                RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon = new CaseCommon.CaseCommon(service, tracingService);
                string strrecordTypeNameExtranet = caseCommon.GetCustomLabel("CL0030_SME_EmailTemplate");
                if (!String.IsNullOrEmpty(strrecordTypeNameExtranet) &&
                    enCasePreImage.Attributes.Contains("rsa_casetype") &&
                    strrecordTypeNameExtranet.Equals(((EntityReference)enCasePreImage.Attributes["rsa_casetype"]).Name) &&
                    enCasePreImage.Attributes.Contains("rsa_policyid"))
                {
                    tracingService.Trace("Validation succeeded");
                    var enUpdatePolicy = new Entity("rsa_policy");
                    enUpdatePolicy.Id = ((EntityReference)enCasePreImage.Attributes["rsa_policyid"]).Id;
                    //Added condition for customerrsa guid contains data
                    if (enCasePreImage.Attributes.Contains("rsa_customerrsa") && ((EntityReference)enCasePreImage.Attributes["rsa_customerrsa"]).Id != Guid.Empty)
                        enUpdatePolicy["rsa_customer"] = enCasePreImage["rsa_customerrsa"];
                    if (enCasePreImage.Attributes.Contains("rsa_account"))
                        enUpdatePolicy["rsa_broker"] = enCasePreImage["rsa_account"];
                    var enPolicyType = this.GetPolicyTypeDetails(STANDARD_POLICY);
                    if (enPolicyType != null)
                        enUpdatePolicy["rsa_policytype"] = new EntityReference("rsa_policytype", enPolicyType.Id);

                    service.Update(enUpdatePolicy);
                    tracingService.Trace("Successfully policy updated");
                }
                else
                {
                    tracingService.Trace("String.IsNullOrEmpty(strrecordTypeNameExtranet)" + strrecordTypeNameExtranet);
                    tracingService.Trace("enCasePreImage.Attributes.Contains(rsa_casetype): " + enCasePreImage.Attributes.Contains("rsa_casetype"));
                    tracingService.Trace("enCasePreImage.Attributes.Contains(rsa_policyid): " + enCasePreImage.Attributes.Contains("rsa_policyid"));
                    if (enCasePreImage.Attributes.Contains("rsa_casetype"))
                        tracingService.Trace("((EntityReference)enCasePreImage.Attributes[rsa_casetype]).Name: " + ((EntityReference)enCasePreImage.Attributes["rsa_casetype"]).Name);
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while policy update in UpdatePolicy(): " + ex.Message);
            }
        }

        /// <summary>
        /// Fetch customer 
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        private EntityCollection GetCustomerDetailsByKeyword(string query)
        {
            try
            {
                return service.RetrieveMultiple(new FetchExpression(query));
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetching customer in GetCustomerDetailsByKeyword(): " + ex.Message);
            }

            return null;
        }

        /// <summary>
        /// Get Policy type
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        private Entity GetPolicyTypeDetails(string key)
        {
            //Standard Policy
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='rsa_policytype'>
                                <attribute name='rsa_policytypeid' />
                                <attribute name='rsa_name' />
                                <attribute name='createdon' />
                                <order attribute='rsa_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='rsa_name' operator='eq' value='{0}' />
                                </filter>
                              </entity>
                            </fetch>";
            try
            {
                var enColPolicyType = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, key)));
                if (enColPolicyType != null && enColPolicyType.Entities.Count > 0)
                    return enColPolicyType.Entities[0];
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetching Policy type in GetPolicyTypeDetails(): " + ex.Message);
            }
            return null;
        }
    }
}