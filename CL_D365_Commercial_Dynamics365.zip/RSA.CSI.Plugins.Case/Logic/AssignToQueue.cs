﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;

namespace RSA.CSI.Plugins.Case.Logic
{
    internal class AssignToQueue
    {
        /// <summary>
        /// Constants & Global Variables
        /// </summary>
        #region Constants & Global Variables
        internal const string MESSAGE_CL0023 = "CL0023";

        internal Guid _gEmpty = Guid.Empty;
        internal string _sEmpty = string.Empty;

        internal string _sQueueName = string.Empty;
        internal string _sTradingHandlingSiteName = string.Empty;
        internal string _sOperationsHandlingSiteName = string.Empty;
        internal string _sTicketNumber = string.Empty;

        internal string _sPolicyClassOfBusinessName = string.Empty;
        internal Guid _gPolicyClassOfBusinessId = new Guid("09442fc2-62ca-ea11-a812-000d3af02cd4"); //Guid.Empty;

        internal string _sPolicyPLCodeName = string.Empty;
        internal Guid _gPolicyPLCodeId = Guid.Empty;

        internal int _iTradingHandlingSite = 866760016; //0;
        internal int _iOperationsHandlingSite = 0;

        internal decimal _dRenewalTradingThreshold = 0;
        internal decimal _dRenewalPromiseThreshold = 0;

        internal Guid _gTraderId = Guid.Empty;
        internal string _sTraderName = string.Empty;

        internal Guid _gUnderwriterId = Guid.Empty;
        internal string _sUnderwriterName = string.Empty;

        internal Entity _eTradingThreshold = null;

        internal Boolean _bIsErrorRecord = false;
        internal string _sErrorDescription = string.Empty;
        //internal String profinQueues;
        internal Dictionary<String, String> profinQueuesMap = new Dictionary<String, String>();
        internal List<String> profinQueuesList = new List<String>();
        internal Entity _eCase = null;
        internal Guid CaseId = Guid.Empty;


        internal Entity _eQueue = null;
        internal Guid _gPolicyId = Guid.Empty;
        internal EntityReference _caseType = null;
        #endregion

        /// <summary>
        /// Execute
        /// </summary>
        /// <param name="context"></param>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        public void Execute(IPluginExecutionContext context, Entity entity, IOrganizationService service, ITracingService tracingService)
        {
            tracingService.Trace("RSA.CSI.Plugins.Case.AssignToQueue=>Execute()- Loaded");
            //Guid gCaseId = new Guid("92b26725-ebd7-ea11-a813-000d3a7fccf0");
            //Defect 1877: Changed function to retrive case entity
            string fetchxml = this.PrepareCaseQuery(tracingService, context.PrimaryEntityId);
            //Commented and added after policy Check to retrive data of Policy
            //string fXml = this.PrepareCaseQueryPolicy(tracingService, context.PrimaryEntityId);
            //string fXml = this.PrepareCaseQuery(tracingService, gCaseId);
            tracingService.Trace(string.Format("Fetching Case record with Id: '{0}.", context.PrimaryEntityId.ToString()));
            var ecCaseCollections = this.RetrieveMultiple(service, tracingService, fetchxml);
            tracingService.Trace(string.Format("Fetching Case record Count: '{0}.", ecCaseCollections.Entities.Count));

            tracingService.Trace(string.Format("Fetching Case record Count: '{0}.", ecCaseCollections.Entities.Count));
            if (ecCaseCollections != null && ecCaseCollections.Entities.Count > 0
                && ecCaseCollections[0] != null && ecCaseCollections[0].Attributes.Contains("rsa_policyid")
                && ((EntityReference)ecCaseCollections[0].Attributes["rsa_policyid"]).Id != _gEmpty)
            {
                string fXml = this.PrepareCaseQueryPolicy(tracingService, context.PrimaryEntityId);
                //string fXml = this.PrepareCaseQuery(tracingService, gCaseId);
                tracingService.Trace(string.Format("Fetching Case Policy record with Id: '{0}.", context.PrimaryEntityId.ToString()));
                var ecCaseCollection = this.RetrieveMultiple(service, tracingService, fXml);
                tracingService.Trace(string.Format("Fetching Case Policy record Count: '{0}.", ecCaseCollection.Entities.Count));

                tracingService.Trace(string.Format("Fetching Case record Count: '{0}.", ecCaseCollection.Entities.Count));
                _eCase = ecCaseCollection[0];
                tracingService.Trace(string.Format("Case has been fetched record with Id: '{0}.", _eCase.Id));
                if (_eCase.Attributes.Contains("title") && _eCase["title"] != null)
                    _sTicketNumber = _eCase["title"].ToString();
                _gPolicyId = ((EntityReference)_eCase["rsa_policyid"]).Id;

                //// Code Cganed for 2098 By Atul Agrawal
                if (_eCase.Attributes.Contains("rsa_casetype") && _eCase["rsa_casetype"] != null)
                {
                    _caseType = ((EntityReference)_eCase["rsa_casetype"]);
                    tracingService.Trace("Case Type found: " + _caseType.Name);
                }

                #region Assign Case to Queue logic
                //If case already exists in queue then 
                //Defect id 2098 : Sumegh Dhole : 30 July 2021 : Case was getting into default queue. 
                QueryExpression qry = new QueryExpression("queueitem");
                qry.NoLock = true;
                qry.TopCount = 1;
                qry.Criteria = new FilterExpression();
                ConditionExpression cndt = new ConditionExpression();
                cndt.AttributeName = "objectid";
                cndt.Operator = ConditionOperator.Equal;
                cndt.Values.Add(_eCase.Id);
                qry.Criteria.AddCondition(cndt);
                qry.ColumnSet = new ColumnSet(new string[] { "queueid", "objectid" });
                EntityCollection queueCase = service.RetrieveMultiple(qry);

                if (queueCase.Entities.Count > 0)
                {
                    tracingService.Trace("Policy already exists in queue :" + (queueCase.Entities[0].Attributes.Contains("queueid") ? ((EntityReference)queueCase.Entities[0].Attributes["queueid"]).Name : string.Empty));
                    this.UpdatePolicyCaseAssignStatus(service, tracingService, (int)CASE_ASSIGN_STATUS_CODE.Success, _sEmpty);
                }
                //else if (_caseType != null && _caseType.Name.Contains("Renewal"))
                //{
                //    tracingService.Trace("Skipped For Renewal Generation: " + _caseType.Name);
                //    this.UpdatePolicyCaseAssignStatus(service, tracingService, (int)CASE_ASSIGN_STATUS_CODE.Success, _sEmpty);
                //    tracingService.Trace("PolicyCaseAssignStatus changed to Success");
                //}

                //Chandani: Commented to check
                /* else if (!this.IdentifyTheCaseQueue(tracingService, service))
                 {
                     CaseId = entity.Id;
                     tracingService.Trace("IdentifyTheCaseQueue");
                     string QueueQuery = this.PrepareQueueItemQuery(tracingService, CaseId);
                     tracingService.Trace("Queue query" + QueueQuery);
                     EntityCollection EnExistingqueue = service.RetrieveMultiple(new FetchExpression(QueueQuery));
                     tracingService.Trace("Queue query Count" + EnExistingqueue.Entities.Count);
                     if (EnExistingqueue.Entities.Count > 0)
                     {
                         string sMessage = string.Format("The Case is already assigned to the Queue", _sQueueName);
                         tracingService.Trace(sMessage);
                         this.UpdatePolicyCaseAssignStatus(service, tracingService, (int)CASE_ASSIGN_STATUS_CODE.Success, sMessage);

                     }
                     else
                     {
                         string sErroMessage = string.Format("The Case '{0}' was not  assigned to the Queue '{1}' as it  does not  exist in the system.", _sTicketNumber, _sQueueName);
                         tracingService.Trace(sErroMessage);
                         this.UpdatePolicyCaseAssignStatus(service, tracingService, (int)CASE_ASSIGN_STATUS_CODE.Failed, sErroMessage);

                         return;
                     }

                 }*/
                else if (this.IdentifyTheCaseQueue(tracingService, service))
                {
                    if (this.AssignCaseToQueue(tracingService, service))
                    {
                        this.UpdatePolicyCaseAssignStatus(service, tracingService, (int)CASE_ASSIGN_STATUS_CODE.Success, _sEmpty);
                        // tracingService.Trace("assigned case");
                    }
                    else
                    {

                        string sErroMessage = string.Format("", _sTicketNumber, _sQueueName);
                        tracingService.Trace(sErroMessage);
                        this.UpdatePolicyCaseAssignStatus(service, tracingService, (int)CASE_ASSIGN_STATUS_CODE.Success, sErroMessage);
                        return;
                    }
                }
                else
                {
                    //CR 1511 : Assign Case to Default queue
                    //set default queue
                    tracingService.Trace("Default queue");
                    bool queueAssign = SetDefaultQueue(_eCase, tracingService, service);
                    if (queueAssign)
                    {
                        this.UpdatePolicyCaseAssignStatus(service, tracingService, (int)CASE_ASSIGN_STATUS_CODE.Success, _sEmpty);
                    }

                }
                #endregion

                #region Case Update logic
                /*
                if (_eCase.Attributes.Contains("pol.rsa_policytrader") && ((EntityReference)((AliasedValue)_eCase.Attributes["pol.rsa_policytrader"]).Value).Id != _gEmpty)
                {
                    _sTraderName = ((EntityReference)((AliasedValue)_eCase.Attributes["pol.rsa_policytrader"]).Value).Name;
                    _gTraderId = ((EntityReference)((AliasedValue)_eCase.Attributes["pol.rsa_policytrader"]).Value).Id;
                }
                if (_eCase.Attributes.Contains("pol.rsa_policyhandler") && ((EntityReference)((AliasedValue)_eCase.Attributes["pol.rsa_policyhandler"]).Value).Id != _gEmpty)
                {
                    _sUnderwriterName = ((EntityReference)((AliasedValue)_eCase.Attributes["pol.rsa_policyhandler"]).Value).Name;
                    _gUnderwriterId = ((EntityReference)((AliasedValue)_eCase.Attributes["pol.rsa_policyhandler"]).Value).Id;
                }

                if (_gPolicyClassOfBusinessId != _gEmpty || _iTradingHandlingSite != 0)
                {
                    _eTradingThreshold = this.GetTradingThresoldDetails(service, tracingService, _gPolicyClassOfBusinessId, _iTradingHandlingSite);
                    if (_eTradingThreshold != null && _eCase.Attributes.Contains("opp.rsa_expiringpremium") && _eCase.Attributes["opp.rsa_expiringpremium"] != null)
                    {

                        if (_eTradingThreshold.Attributes.Contains("rsa_renewaltradingthreshold") && _eTradingThreshold["rsa_renewaltradingthreshold"] != null)
                            _dRenewalTradingThreshold = _eTradingThreshold.GetAttributeValue<Money>("rsa_renewaltradingthreshold").Value;

                        if (_eTradingThreshold.Attributes.Contains("rsa_renewalpromisethreshold") && _eTradingThreshold["rsa_renewalpromisethreshold"] != null)
                            _dRenewalPromiseThreshold = _eTradingThreshold.GetAttributeValue<Money>("rsa_renewalpromisethreshold").Value;

                        
                        var vProfinSitesColl = !string.IsNullOrEmpty(this.GetCustomLabel(service, tracingService, "Profin_Sites")) ? this.GetCustomLabel(service, tracingService, "Profin_Sites").Split(',') : null;
                        if (vProfinSitesColl.Contains(_sTradingHandlingSiteName))
                        {
                            if (profinQueuesMap.Count == 0)
                            {
                                string vDistribution_categories_for_Profin_SME = !string.IsNullOrEmpty(this.GetCustomLabel(service, tracingService, "Distribution_categories_for_Profin_SME")) ? this.GetCustomLabel(service, tracingService, "Distribution_categories_for_Profin_SME") : _sEmpty;
                                if (vDistribution_categories_for_Profin_SME != _sEmpty && _eCase["rsa_distributioncategory"] != null && _eCase["rsa_distributioncategory"].ToString() != _sEmpty
                                    && vDistribution_categories_for_Profin_SME.Contains(_eCase["rsa_distributioncategory"].ToString()))
                                {

                                    string vProfin_Case_Assignment_1 = !string.IsNullOrEmpty(this.GetCustomLabel(service, tracingService, "Profin_Case_Assignment_1")) ? this.GetCustomLabel(service, tracingService, "Profin_Case_Assignment_1") : _sEmpty;
                                    string vProfin_Case_Assignment_2 = !string.IsNullOrEmpty(this.GetCustomLabel(service, tracingService, "Profin_Case_Assignment_2")) ? this.GetCustomLabel(service, tracingService, "Profin_Case_Assignment_2") : _sEmpty;
                                    if (vProfin_Case_Assignment_1.Contains(_sPolicyClassOfBusinessName) || vProfin_Case_Assignment_2.Contains(_sPolicyClassOfBusinessName))
                                    {
                                        profinQueues = !string.IsNullOrEmpty(this.GetCustomLabel(service, tracingService, "Profin_New_Business_Trading_Sites")) ? this.GetCustomLabel(service, tracingService, "Profin_New_Business_Trading_Sites") : _sEmpty;
                                        profinQueuesList = profinQueues.Split(';').ToList();
                                        int i = 0;
                                        while (i < profinQueuesList.Count)
                                        {
                                            profinQueuesMap.Add(profinQueuesList[i], profinQueuesList[i + 1]);
                                            i += 2;
                                        }
                                    }
                                }
                            }
                        }
                        

                        if (((Money)((AliasedValue)_eCase.Attributes["opp.rsa_expiringpremium"]).Value).Value >= _dRenewalTradingThreshold)
                        {
                            if (_eCase.Attributes["pol.rsa_policytrader"] != null)
                            {
                                _eCase["ownerid"] = _eCase.Attributes["pol.rsa_policytrader"];
                                _eCase["rsa_traded"] = new OptionSetValue((int)CASE_TRADED.Traded);
                            }
                        }
                        else
                        {
                            if (_eCase.Attributes["pol.rsa_policyhandler"] != null)
                            {
                                _eCase["ownerid"] = _eCase.Attributes["pol.rsa_policyhandler"];
                                _eCase["rsa_traded"] = new OptionSetValue((int)CASE_TRADED.OpsTraded);
                            }
                        }
                        var vCL0016 = !string.IsNullOrEmpty(this.GetCustomLabel(service, tracingService, "CL0016")) ? this.GetCustomLabel(service, tracingService, "CL0016") : _sEmpty;
                        var vCL0016List = vCL0016.Split(';');
                        if (vCL0016List.Contains(_sPolicyClassOfBusinessName))
                        {
                            _eCase["rsa_status"] = new EntityReference("rsa_status", new Guid("1336CDDD-78BC-EA11-A812-000D3AF01FA0"));
                        }
                    }
                }
                */
                #endregion
            }
            else
            {
                //CR 1511 : Defect 1877 : Assign Case to Default queue
                tracingService.Trace("This Case '{0}' is an orphan record and is not associated to any Policy.", _sTicketNumber);
                tracingService.Trace("Default queue if policy not exist");
                _eCase = ecCaseCollections[0];
                tracingService.Trace("_eCase.Id: " + _eCase.Id);
                #region check if Case is already assign to any queue
                QueryExpression qry = new QueryExpression("queueitem");
                qry.NoLock = true;
                qry.TopCount = 1;
                qry.Criteria = new FilterExpression();
                ConditionExpression cndt = new ConditionExpression();
                cndt.AttributeName = "objectid";
                cndt.Operator = ConditionOperator.Equal;
                cndt.Values.Add(_eCase.Id);
                qry.Criteria.AddCondition(cndt);
                qry.ColumnSet = new ColumnSet(new string[] { "queueid", "objectid" });
                EntityCollection queueCase = service.RetrieveMultiple(qry);
                tracingService.Trace("queueCase.Entities.Count: " + queueCase.Entities.Count);
                if (queueCase.Entities.Count > 0)
                {
                    tracingService.Trace("Case already exists in queue :" + (queueCase.Entities[0].Attributes.Contains("queueid") ? ((EntityReference)queueCase.Entities[0].Attributes["queueid"]).Name : string.Empty));
                    return;
                }
                #endregion
                bool queueAssign = SetDefaultQueue(_eCase, tracingService, service);
                if (queueAssign)
                {
                    tracingService.Trace("Case Assigned to Queue");
                }
            }
            tracingService.Trace("RSA.CSI.Plugins.Case.AssignToQueue=>Execute()- Unloaded");
        }

        ////CR 1511 : Defect 1877 : Assign Case to Default queue
        private bool SetDefaultQueue(Entity eCase, ITracingService tracer, IOrganizationService service)
        {
            string classOfBusinessName = string.Empty;
            Entity Opportunity = null;
            Guid COBId = Guid.Empty;
            Guid classOfBusinessId = Guid.Empty;
            EntityReference policyId = new EntityReference();
            #region Retrive ClassofBusinessName
            if (eCase.Attributes.Contains("rsa_classofbusiness") && !eCase.Attributes.Contains("rsa_originatingcase"))
            {
                tracer.Trace("classOfBusinessName 2");
                classOfBusinessName = Convert.ToString(eCase.Attributes["rsa_classofbusiness"]);
            }
            if (eCase.Attributes.Contains("rsa_classofbusinesssme") && !eCase.Attributes.Contains("rsa_originatingcase"))
            {
                tracer.Trace("classOfBusinessName 3");
                classOfBusinessName = Convert.ToString(eCase.Attributes["rsa_classofbusinesssme"]);
            }
            //Fetch XML added to retrieve COB: Bug id: 2444
            if (eCase.Attributes.Contains("rsa_opportunityid"))
            {
                tracer.Trace("Get the class name from opportunity");
                EntityReference opportunityId = eCase.Attributes.Contains("rsa_opportunityid") ? (EntityReference)eCase.Attributes["rsa_opportunityid"] : null;
                if (opportunityId != null)
                {
                    string lineofbusiness = string.Empty;
                    Guid lineofbusinessId = Guid.Empty;
                    string pl = string.Empty;
                    Guid plid = Guid.Empty;
                    tracer.Trace("classOfBusinessName 4");
                    Opportunity = service.Retrieve(opportunityId.LogicalName, opportunityId.Id, new ColumnSet(new string[] { "rsa_classofbusiness", "rsa_lineofbusiness", "rsa_pandlid", "rsa_classofbusiness" }));
                    classOfBusinessName = Opportunity.Attributes.Contains("rsa_classofbusiness") ? ((EntityReference)Opportunity.Attributes["rsa_classofbusiness"]).Name : string.Empty;
                    tracer.Trace("Class of Business Name from optty " + classOfBusinessName);
                    //2444
                    lineofbusiness = Opportunity.Attributes.Contains("rsa_lineofbusiness") ? ((EntityReference)Opportunity.Attributes["rsa_lineofbusiness"]).Name : string.Empty;
                    tracer.Trace("Line of Business Name from optty " + lineofbusiness);
                    lineofbusinessId = Opportunity.Attributes.Contains("rsa_lineofbusiness") ? ((EntityReference)Opportunity.Attributes["rsa_lineofbusiness"]).Id : Guid.Empty;
                    pl = Opportunity.Attributes.Contains("rsa_pandlid") ? ((EntityReference)Opportunity.Attributes["rsa_pandlid"]).Name : string.Empty;
                    tracer.Trace("P&L Name from optty " + pl);
                    plid = Opportunity.Attributes.Contains("rsa_pandlid") ? ((EntityReference)Opportunity.Attributes["rsa_pandlid"]).Id : Guid.Empty;
                    COBId = Opportunity.Attributes.Contains("rsa_classofbusiness") ? ((EntityReference)Opportunity.Attributes["rsa_classofbusiness"]).Id : Guid.Empty;
                    tracer.Trace("COBId" + COBId);
                    if (classOfBusinessName != string.Empty)
                    {
                        // fetch COB based on COBName +LOB + P&L combination : If found then override COBID value else continue
                        string fetchCOB = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                <entity name='rsa_classofbusiness'>
                                <attribute name='rsa_name' />
                                <attribute name='createdon' />
                                <attribute name='rsa_pl' />
                                <attribute name='rsa_description' />
                                <attribute name='rsa_lineofbusiness' />
                                <attribute name='rsa_classofbusinessid' />
                                <order attribute='rsa_name' descending='false' />
                                <filter type='and'>
                                <condition attribute='rsa_lineofbusiness' operator='eq'  uitype='rsa_lineofbusiness' value='{0}' />
                                <condition attribute='rsa_name' operator='eq' value='{2}' />
                                </filter>
                                <link-entity name='rsa_pl' from='rsa_plid' to='rsa_pl' link-type='inner' alias='ac'>
                                <filter type='and'>
                                <condition attribute='rsa_name' operator='eq' value='{1}' />
                                </filter>
                                </link-entity>
                                </entity>
                                </fetch>";

                        EntityCollection OpptyentityCollection = service.RetrieveMultiple(new FetchExpression(String.Format(fetchCOB, lineofbusinessId, WebUtility.HtmlEncode(pl), WebUtility.HtmlEncode(classOfBusinessName))));
                        if (OpptyentityCollection.Entities.Count > 0)
                        {
                            foreach (var cob in OpptyentityCollection.Entities)
                            {
                                COBId = cob.Id;
                                //COBID to be override
                                break;
                            }
                        }
                    }
                }
            }
            else if (eCase.Attributes.Contains("rsa_classofbusinessphoneenqid"))
            {
                tracer.Trace("classOfBusinessName 1");
                classOfBusinessId = ((EntityReference)eCase.Attributes["rsa_classofbusinessphoneenqid"]).Id;
                classOfBusinessName = ((EntityReference)eCase.Attributes["rsa_classofbusinessphoneenqid"]).Name;

                COBId = ((EntityReference)eCase.Attributes["rsa_classofbusinessphoneenqid"]).Id;
                //Regression Issue: COB Null check
                if (classOfBusinessName == null)
                {
                    Entity eClassofbusiness = service.Retrieve("rsa_classofbusiness", COBId, new ColumnSet("rsa_name"));
                    classOfBusinessName = eClassofbusiness.Contains("rsa_name") ? eClassofbusiness.GetAttributeValue<string>("rsa_name").ToString() : null;

                }
                tracer.Trace("COBId" + COBId);
            }
            else if (eCase.Attributes.Contains("rsa_policyid"))
            {
                tracer.Trace("Get the class name from policy");
                policyId = eCase.Attributes.Contains("rsa_policyid") ? (EntityReference)eCase.Attributes["rsa_policyid"] : null;
                if (policyId != null)
                {
                    string Policy = string.Empty;
                    Guid lineofbusinessId = Guid.Empty;
                    string pl = string.Empty;
                    Guid plid = Guid.Empty;
                    Guid policytype = Guid.Empty;
                    Entity PolicyData = service.Retrieve(policyId.LogicalName, policyId.Id, new ColumnSet(new string[] { "rsa_classofbusiness", "rsa_plcode", "rsa_name", "rsa_policytype" }));
                    classOfBusinessName = PolicyData.Attributes.Contains("rsa_classofbusiness") ? ((EntityReference)PolicyData.Attributes["rsa_classofbusiness"]).Name : string.Empty;
                    tracer.Trace("Class of Business Name from policy " + classOfBusinessName);
                    Policy = PolicyData.Attributes.Contains("rsa_policytype") ? ((EntityReference)PolicyData.Attributes["rsa_policytype"]).Name : string.Empty;
                    tracer.Trace("Policy Name " + Policy);
                    policytype = PolicyData.Attributes.Contains("rsa_policytype") ? ((EntityReference)PolicyData.Attributes["rsa_policytype"]).Id : Guid.Empty;
                    pl = PolicyData.Attributes.Contains("rsa_plcode") ? ((EntityReference)PolicyData.Attributes["rsa_plcode"]).Name : string.Empty;
                    tracer.Trace("P&L Name from optty " + pl);
                    plid = PolicyData.Attributes.Contains("rsa_plcode") ? ((EntityReference)PolicyData.Attributes["rsa_plcode"]).Id : Guid.Empty;
                    COBId = PolicyData.Attributes.Contains("rsa_classofbusiness") ? ((EntityReference)PolicyData.Attributes["rsa_classofbusiness"]).Id : Guid.Empty;
                    tracer.Trace("COBId" + COBId);
                    if (classOfBusinessName != string.Empty)
                    {
                        // fetch COB based on COBName +LOB + P&L combination : If found then override COBID value else continue
                        string fetchCOBfromPolicy = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                <entity name='rsa_classofbusiness'>
                                <attribute name='rsa_name' />
                                <attribute name='createdon' />
                                <attribute name='rsa_pl' />
                                <attribute name='rsa_description' />
                                <attribute name='rsa_lineofbusiness' />
                                <attribute name='rsa_classofbusinessid' />
                                <order attribute='rsa_name' descending='false' />
                                <filter type='and'>
                                <condition attribute='rsa_policytype' operator='eq' uitype='rsa_policytype' value='{0}' />
                                <condition attribute='rsa_name' operator='eq' value='{2}' />
                                </filter>
                                <link-entity name='rsa_pl' from='rsa_plid' to='rsa_pl' link-type='inner' alias='ac'>
                                <filter type='and'>
                                <condition attribute='rsa_name' operator='eq' value='{1}' />
                                </filter>
                                </link-entity>
                                </entity>
                                </fetch>";

                        EntityCollection PolicyCollection = service.RetrieveMultiple(new FetchExpression(String.Format(fetchCOBfromPolicy, policytype, WebUtility.HtmlEncode(pl), WebUtility.HtmlEncode(classOfBusinessName))));
                        if (PolicyCollection.Entities.Count > 0)
                        {
                            foreach (var cob in PolicyCollection.Entities)
                            {
                                COBId = cob.Id;
                                tracer.Trace("COBId" + COBId);
                                //COBID to be override
                                break;
                            }
                        }
                    }
                }
            }
            #endregion
            tracer.Trace("Class of Business Name " + classOfBusinessName);

            bool assignDefaultQueue = false;
            #region assign case to default queue
            RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon = new CaseCommon.CaseCommon(service, tracer);

            List<string> lstCustomLables = new List<string>();
            lstCustomLables.Add("Default_Queues");
            EntityCollection enColCustomLabel = caseCommon.GetCustomLabel(lstCustomLables);
            string enDefaultQueue = string.Empty;
            foreach (var enCustomLabel in enColCustomLabel.Entities)
            {
                tracer.Trace("rsa_name: " + enCustomLabel.Attributes["rsa_name"].ToString());
                tracer.Trace("rsa_dependentoptionsetjson: " + enCustomLabel.Attributes["rsa_dependentoptionsetjson"].ToString());
                if (enCustomLabel.Attributes.Contains("rsa_name") &&
                    enCustomLabel.Attributes.Contains("rsa_dependentoptionsetjson"))
                {
                    tracer.Trace("Custom label contains rsa_name & rsa_dependentoptionsetjson");
                    enDefaultQueue = enCustomLabel.Attributes["rsa_dependentoptionsetjson"].ToString();
                    tracer.Trace("Started with JSONCode ");
                    var defaultQueueRoot = new DefaultQueueRoot();
                    var ms = new MemoryStream(Encoding.UTF8.GetBytes(enDefaultQueue));
                    //tracer.Trace("enDefaultQueue " + enDefaultQueue);
                    try
                    {
                        var ser = new DataContractJsonSerializer(defaultQueueRoot.GetType());
                        defaultQueueRoot = ser.ReadObject(ms) as DefaultQueueRoot;
                    }
                    catch (Exception ex)
                    {
                        throw new InvalidPluginExecutionException(ex.Message);
                    }
                    finally
                    {
                        ms.Close();
                    }
                    if (classOfBusinessName != string.Empty)
                    {
                        foreach (var item in defaultQueueRoot.DefaultQueueJSON)
                        {
                            if (item.COB.ToLower().Contains(classOfBusinessName.ToLower()))
                            {
                                tracer.Trace("COB.Contains(classOfBusinessName) ");
                                _eQueue = new Entity("queue", new Guid(item.QueueId));
                                if (_eQueue != null)
                                {
                                    tracer.Trace("_eQueue is not null ");
                                    this.AssignCaseToQueue(tracer, service);
                                    assignDefaultQueue = true;
                                    //this.UpdatePolicyCaseAssignStatus(service, tracer, (int)CASE_ASSIGN_STATUS_CODE.Success, _sEmpty);
                                }
                            }
                        }
                    }
                }
            }
            #endregion
            return assignDefaultQueue;

        }

        /// <summary>
        /// Prepare Case Query
        /// </summary>
        /// <param name="tracingService"></param>
        /// <param name="gIncidentId"></param>
        /// <returns></returns>
        private string PrepareCaseQueryPolicy(ITracingService tracingService, Guid gIncidentId)
        {
            //tracingService.Trace("RSA.CSI.Plugins.Case.AssignToQueue=>PrepareCaseQuery()- Loaded");
            var fXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' >
                            <entity name='incident' >
                                <attribute name='title' />
                                <attribute name='ticketnumber' />
                                <attribute name='createdon' />
                                <attribute name='incidentid' />
                                <attribute name='caseorigincode' />
                                <attribute name='rsa_policyid' />
                                <attribute name='rsa_opportunityid' />
                                <attribute name='rsa_account' />
                                <attribute name='rsa_casetype' />
                                <order attribute='title' descending='false' />
                                <filter type='and' >
                                    <condition attribute='incidentid' operator='eq' value='{0}' />
                                </filter>
                                <link-entity name='opportunity' from='opportunityid' to='rsa_opportunityid' visible='false' link-type='outer' alias='opp' >
                                    <attribute name='rsa_expiringpremium' />
                                </link-entity>
                                <link-entity name='account' from='accountid' to='rsa_account' link-type='inner' alias='acc' >
                                    <attribute name='rsa_branch' />
                                </link-entity>
                                <link-entity name='rsa_policy' from='rsa_policyid' to='rsa_policyid' link-type='inner' alias='pol' >
                                    <attribute name='rsa_tradinghandlingsite' />
                                    <attribute name='rsa_operationshandlingsite' />
                                    <attribute name='rsa_reviewtypecode' />
                                    <attribute name='rsa_renewalgenerationstatuscode' />
                                    <attribute name='rsa_renewalgenerationid' />
                                    <attribute name='rsa_renewalgenerationfailreason' />
                                    <attribute name='rsa_policytrader' />
                                    <attribute name='rsa_policyhandler' />
                                    <attribute name='rsa_plcode' />
                                    <attribute name='rsa_mumbaihandler' />
                                    <attribute name='rsa_premium' />
                                    <attribute name='rsa_classofbusiness' />
                                </link-entity>
                            </entity></fetch>";



            fXml = string.Format(fXml, gIncidentId.ToString());
            //tracingService.Trace("RSA.CSI.Plugins.Case.AssignToQueue=>PrepareCaseQuery()- Unloaded");
            return fXml;
        }

        private string PrepareCaseQuery(ITracingService tracingService, Guid gIncidentId)
        {
            //tracingService.Trace("RSA.CSI.Plugins.Case.AssignToQueue=>PrepareCaseQuery()- Loaded");
            var fXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' >
                            <entity name='incident' >
                                <attribute name='title' />
                                <attribute name='ticketnumber' />
                                <attribute name='createdon' />
                                <attribute name='incidentid' />
                                <attribute name='caseorigincode' />
                                <attribute name='rsa_policyid' />
                                <attribute name='rsa_opportunityid' />
                                <attribute name='rsa_account' />
                                <attribute name='rsa_casetype' />
                                <order attribute='title' descending='false' />
                                <filter type='and' >
                                    <condition attribute='incidentid' operator='eq' value='{0}' />
                                </filter>                                
                            </entity></fetch>";



            fXml = string.Format(fXml, gIncidentId.ToString());
            //tracingService.Trace("RSA.CSI.Plugins.Case.AssignToQueue=>PrepareCaseQuery()- Unloaded");
            return fXml;
        }

        /// <summary>
        /// Get trading thresold details
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="guidCOB"></param>
        /// <param name="intOffice"></param>
        /// <returns></returns>
        private Entity GetTradingThresoldDetails(IOrganizationService service, ITracingService tracingService, Guid guidCOB, int intOffice)
        {
            tracingService.Trace("RSA.CSI.Plugins.Case.AssignToQueue=>GetTradingThresoldDetails()- Loaded.");

            var entityTradingThresold = new Entity();
            try
            {
                var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' no-lock='true'>
                                <entity name='rsa_tradingthreshold' >
                                    <attribute name='rsa_name' />
                                    <attribute name='createdon' />
                                    <attribute name='rsa_pl' />
                                    <attribute name='rsa_office' />
                                    <attribute name='rsa_thresholdvalue' />
                                    <attribute name='rsa_renewaltradingthreshold' />
                                    <attribute name='rsa_renewalpromisethreshold' />
                                    <attribute name='rsa_classofbusiness' />
                                    <attribute name='rsa_tradingthresholdid' />
                                    <attribute name='rsa_vettingthreshold' />
                                    <order attribute='rsa_name' descending='false' />
                                    <filter type='and' >
                                        <condition attribute='rsa_office' operator='eq' value='{1}' />
                                        <condition attribute='rsa_classofbusiness' operator='eq' value='{0}' />
                                    </filter>
                                </entity>
                            </fetch>";

                var colTradingThresold = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, guidCOB, intOffice)));
                if (colTradingThresold != null && colTradingThresold.Entities.Count > 0)
                {
                    entityTradingThresold = colTradingThresold.Entities[0];
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetch Trading Thresold: " + ex.Message);
            }
            tracingService.Trace("RSA.CSI.Plugins.Case.AssignToQueue=>GetTradingThresoldDetails()- Unloaded.");
            return entityTradingThresold;
        }

        /// <summary>
        /// RetrieveMultiple
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="query"></param>
        /// <returns></returns>
        private EntityCollection RetrieveMultiple(IOrganizationService service, ITracingService tracingService, string query)
        {
            tracingService.Trace("RSA.CSI.Plugins.Case.AssignToQueue=>RetrieveMultiple()- Loaded.");
            EntityCollection eCollection = null; //new EntityCollection();
            try
            {
                eCollection = service.RetrieveMultiple(new FetchExpression(query));
            }
            catch (Exception ex)
            {
                if (!string.IsNullOrEmpty(ex.Message))
                    tracingService.Trace(string.Format("Error in RSA.CSI.Plugins.Case.AssignToQueue=>RetrieveMultiple(). Desc.: {0}", ex.Message));
                else if (!string.IsNullOrEmpty(ex.InnerException.Message))
                    tracingService.Trace(string.Format("Error in RSA.CSI.Plugins.Case.AssignToQueue=>RetrieveMultiple(). Desc.: {0}", ex.InnerException.Message));
                //throw new InvalidPluginExecutionException(string.Format("Error in RetrieveMultiple(). Desc.:", ex.InnerException.Message));
            }
            tracingService.Trace("RSA.CSI.Plugins.Case.AssignToQueue=>RetrieveMultiple()- Unloaded.");
            return eCollection;
        }

        ///// <summary>
        ///// Fetch record from Custom Label entity based on key
        ///// </summary>
        ///// <param name="service"></param>
        ///// <param name="key"></param>
        ///// <returns></returns>
        //private string GetCustomLabel(IOrganizationService service, ITracingService tracingService, string key)
        //{
        //    tracingService.Trace("RSA.CSI.Plugins.Case.AssignToQueue=>GetCustomLabel()- Loaded.");
        //    var returnValue = string.Empty;
        //    var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
        //                      <entity name='rsa_customlabel'>
        //                        <attribute name='rsa_values' />
        //                        <attribute name='rsa_shortdescription' />
        //                        <attribute name='rsa_categories' />  
        //                        <filter type='and'>
        //                          <condition attribute='rsa_name' operator='eq' value='{0}' />
        //                        </filter>
        //                      </entity>
        //                    </fetch>";
        //    var entityCustomLevel = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, key)));
        //    if (entityCustomLevel.Entities.Count > 0)
        //    {
        //        returnValue = entityCustomLevel[0].Attributes.Contains("rsa_values") ? entityCustomLevel[0].GetAttributeValue<string>("rsa_values") : string.Empty;
        //    }
        //    tracingService.Trace("RSA.CSI.Plugins.Case.AssignToQueue=>GetCustomLabel()- Unloaded.");
        //    return returnValue;
        //}

        /// <summary>
        /// PrepareQueueQuery
        /// </summary>
        /// <param name="tracingService"></param>
        /// <param name="sQueueName"></param>
        /// <returns></returns>
        private string PrepareQueueQuery(ITracingService tracingService, string sQueueName)
        {
            tracingService.Trace("RSA.CSI.Plugins.Case.AssignToQueue=>PrepareQueueQuery()- Loaded.");
            string fXml = @"<fetch mapping='logical' version='1.0' distinct='false' output-format='xml-platform'>
                              <entity name='queue'>
                                <attribute name='name' />
                                <attribute name='emailaddress' />
                                <attribute name='queueid' />
                                <order descending='false' attribute='name' />
                                <filter type='and'>
                                  <condition value='{0}' attribute='name' operator='eq' />
                                  <condition attribute='statecode' value='0' operator='eq'/>
                                </filter>
                              </entity>
                            </fetch>";
            fXml = string.Format(fXml, sQueueName);
            tracingService.Trace("RSA.CSI.Plugins.Case.AssignToQueue=>PrepareQueueQuery()- Unloaded.");
            return fXml;
        }

        private string PrepareQueueItemQuery(ITracingService tracingService, Guid CaseId)
        {
            tracingService.Trace("RSA.CSI.Plugins.Case.AssignToQueue=>PrepareQueueItemQuery()- Loaded.");
            //string fXmlQ = @"<fetch mapping='logical' version='1.0' distinct='false' output-format='xml-platform'>
            //                  <entity name='queueitem'>
            //                    <attribute name='title' />
            //                    <attribute name='objecttypecode' />
            //                    <attribute name='objectid' />
            //                    <filter type='and'>
            //                      condition attribute='objectid' value='{0}' operator='eq' />
            //                    </filter>
            //                  </entity>
            //                </fetch>";

            string fXmlQ = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                             <entity name='queueitem'>
                            <attribute name='objecttypecode' />
                            <attribute name='objectid' />
                            <attribute name='title' />
                            <attribute name='enteredon' />
                            <order attribute='enteredon' descending='true' />
                            <filter type='and'>
                              <condition attribute='objectid' operator='eq' uitype='incident' value='{0}' />
                              <condition attribute='objecttypecode' operator='eq' value='112' />
                            </filter>
                          </entity>
                        </fetch>";

            fXmlQ = string.Format(fXmlQ, CaseId);
            tracingService.Trace("RSA.CSI.Plugins.Case.AssignToQueue=>PrepareQueueItemQuery()- Unloaded.");
            return fXmlQ;
        }

        /// <summary>
        /// Add Case to Queue.
        /// </summary>
        /// <param name="tracingService"></param>
        /// <param name="service"></param>
        /// <param name="entityName"></param>
        /// <param name="caseId"></param>
        /// <param name="destinationQueueId"></param>
        private Boolean AssignCaseToQueue(ITracingService tracingService, IOrganizationService service)//, string entityName, Guid caseId, Guid destinationQueueId)
        {
            tracingService.Trace("Method RSA.CSI.Plugins.AssignToCase=>AssignCaseToDefaultQueue()- Loaded.");
            Boolean bCaseAllocationHappened = false;
            if (_eQueue != null)
            {

                var routeRequest = new AddToQueueRequest
                {
                    Target = new EntityReference(_eCase.LogicalName, _eCase.Id),
                    DestinationQueueId = _eQueue.Id
                };
                string responseName = service.Execute(routeRequest).ResponseName;
                if (!String.IsNullOrEmpty(responseName))
                    bCaseAllocationHappened = true;
            }
            tracingService.Trace("Method RSA.CSI.Plugins.AssignToCase=>AssignCaseToDefaultQueue()- Unloaded.");
            return bCaseAllocationHappened;
        }

        /// <summary>
        /// IdentifyQueueForCase
        /// </summary>
        /// <param name="tracingService"></param>
        /// <param name="service"></param>
        /// <param name="_eCase"></param>
        private Boolean IdentifyTheCaseQueue(ITracingService tracingService, IOrganizationService service)
        {
            tracingService.Trace("Method RSA.CSI.Plugins.AssignToCase=>IdentifyQueueForCase()- Loaded.");
            Boolean isQueueIdentified = false;
            if (_eCase.Attributes.Contains("pol.rsa_operationshandlingsite") && _eCase["pol.rsa_operationshandlingsite"] != null)
            {
                _sOperationsHandlingSiteName = _eCase.FormattedValues["pol.rsa_operationshandlingsite"];
                _iOperationsHandlingSite = ((OptionSetValue)((AliasedValue)_eCase["pol.rsa_operationshandlingsite"]).Value).Value;
            }
            if (_eCase.Attributes.Contains("pol.rsa_plcode") && ((EntityReference)((AliasedValue)_eCase.Attributes["pol.rsa_plcode"]).Value).Id != _gEmpty)
            {
                _sPolicyPLCodeName = WebUtility.HtmlEncode(((EntityReference)((AliasedValue)_eCase.Attributes["pol.rsa_plcode"]).Value).Name);
                _gPolicyPLCodeId = ((EntityReference)((AliasedValue)_eCase.Attributes["pol.rsa_plcode"]).Value).Id;
            }
            if (_eCase.Attributes.Contains("pol.rsa_classofbusiness") && ((EntityReference)((AliasedValue)_eCase.Attributes["pol.rsa_classofbusiness"]).Value).Id != _gEmpty)
            {
                _sPolicyClassOfBusinessName = ((EntityReference)((AliasedValue)_eCase.Attributes["pol.rsa_classofbusiness"]).Value).Name;
                _gPolicyClassOfBusinessId = ((EntityReference)((AliasedValue)_eCase.Attributes["pol.rsa_classofbusiness"]).Value).Id;
            }
            if (_eCase.Attributes.Contains("pol.rsa_tradinghandlingsite") && _eCase["pol.rsa_tradinghandlingsite"] != null)
            {
                _sTradingHandlingSiteName = _eCase.FormattedValues["pol.rsa_tradinghandlingsite"];
                _iTradingHandlingSite = ((OptionSetValue)((AliasedValue)_eCase["pol.rsa_tradinghandlingsite"]).Value).Value;
            }

            _sQueueName = _sPolicyPLCodeName + " - " + _sOperationsHandlingSiteName;

            tracingService.Trace("_sQueueName generated" + _sQueueName);
            RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon = new CaseCommon.CaseCommon(service, tracingService);
            string sLabelMessage = caseCommon.GetCustomLabel(MESSAGE_CL0023);
            if (sLabelMessage != _sEmpty)
            {
                foreach (string s in sLabelMessage.Split(';'))
                {
                    if (s.ToLower().Trim().ToLower() == _sPolicyClassOfBusinessName.ToLower())
                    {
                        _sQueueName = _sPolicyPLCodeName + " - " + _sTradingHandlingSiteName;
                        break;
                    }
                }
                string sQuery = this.PrepareQueueQuery(tracingService, _sQueueName);
                tracingService.Trace("Queue query" + sQuery);
                EntityCollection businessRecordTypes = service.RetrieveMultiple(new FetchExpression(sQuery));
                tracingService.Trace("Queue query" + businessRecordTypes.Entities.Count);
                if (businessRecordTypes.Entities.Count > 0)
                {
                    foreach (var val in businessRecordTypes.Entities)
                    {
                        //Commented as this is not required. We are checking the same queue which is fetched. 
                        //string queueName = val.Attributes.Contains("rsa_name") ? val.GetAttributeValue<string>("rsa_name") : string.Empty;
                        //if (queueName.ToLower().Equals(_sQueueName.ToLower()))
                        //{

                        //    var ecQueueColl = this.RetrieveMultiple(service, tracingService, sQuery);
                        //    if (ecQueueColl != null && ecQueueColl.Entities.Count > 0 && ecQueueColl[0] != null)
                        //    {
                        //_eQueue = ecQueueColl[0];
                        _eQueue = val;
                        isQueueIdentified = true;
                        //    }
                        //  }
                        tracingService.Trace("isQueueIdentified : " + isQueueIdentified);
                    }
                }
            }
            tracingService.Trace("Method RSA.CSI.Plugins.AssignToCase=>IdentifyQueueForCase()- Unloaded.");
            return isQueueIdentified;
        }

        /// <summary>
        /// UpdatePolicyCaseAssignStatus
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="ePolicy"></param>
        /// <param name="sUpdateResult"></param>
        /// <param name="sComments"></param>
        private void UpdatePolicyCaseAssignStatus(IOrganizationService service, ITracingService tracingService, int iCaseAssignStatusCode, string sComments)
        {
            tracingService.Trace("Method RSA.CSI.Plugins.AssignToCase=>UpdatePolicyCaseAssignStatus()- Loaded.");
            Entity ePolicy_update = new Entity("rsa_policy");
            ePolicy_update.Id = _gPolicyId;
            if (iCaseAssignStatusCode == (int)CASE_ASSIGN_STATUS_CODE.Success)
            {
                ePolicy_update["rsa_renewalgenerationcaseassignstatuscode"] = new OptionSetValue((int)CASE_ASSIGN_STATUS_CODE.Success);
            }
            else if (iCaseAssignStatusCode == (int)CASE_ASSIGN_STATUS_CODE.Failed)
            {
                ePolicy_update["rsa_renewalgenerationcaseassignstatuscode"] = new OptionSetValue((int)CASE_ASSIGN_STATUS_CODE.Failed);
                ePolicy_update["rsa_caseupdatefailreason"] = sComments;
            }
            service.Update(ePolicy_update);
            tracingService.Trace("Method RSA.CSI.Plugins.AssignToCase=>UpdatePolicyCaseAssignStatus()- Unloaded.");
        }
    }
    enum CASE_ASSIGN_STATUS_CODE
    {
        Success = 860002,
        Failed = 860000
    }
    enum CASE_TRADED
    {
        Traded = 866760000,
        OpsTraded = 866760001
    }

    [DataContract]
    public class DefaultQueueJSON
    {
        [DataMember]
        public string COB { get; set; }
        [DataMember]
        public string QueueName { get; set; }
        [DataMember]
        public string QueueId { get; set; }
    }

    [DataContract]
    public class DefaultQueueRoot
    {
        [DataMember]
        public List<DefaultQueueJSON> DefaultQueueJSON { get; set; }
    }
}