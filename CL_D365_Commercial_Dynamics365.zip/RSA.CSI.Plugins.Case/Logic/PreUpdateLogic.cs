﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using RSA.CSI.Plugins.Case.Helper;

namespace RSA.CSI.Plugins.Case.Logic
{
    internal class PreUpdateLogic
    {
        IOrganizationService service = null;
        ITracingService tracingService = null;
        Entity enCaseTarget = null;
        Entity enCasePreImage = null;
        Entity enNewCase = null;
        Guid guidCallingUserId = Guid.Empty;
        string strTargetCaseType = string.Empty;
        string strTargetTransactionType = string.Empty;
        string strTargetCaseStatus = string.Empty;

        #region Constructor 
        internal PreUpdateLogic(IOrganizationService cService, ITracingService cTracingService, Entity cEnCaseTarget, Entity cEntityCasePreImage, Entity cNewEntityCase, Guid cGuidCallingUserId)
        {
            service = cService;
            tracingService = cTracingService;
            enCaseTarget = cEnCaseTarget;
            guidCallingUserId = cGuidCallingUserId;
            enCasePreImage = cEntityCasePreImage;
            enNewCase = cNewEntityCase;
        }
        #endregion Constructor

        #region Constants 
        private const string CL_CASE_RECORD_TYPE_NAME_FOR_TRIGGER = "CL_CASE_RECORD_TYPE_NAME_FOR_TRIGGER";
        private const string CASE_TYPE_NEW_BUSINESS = "New Business";
        private const string SME_IMARKET_REFERRAL = "SME - iMarket Referral";
        private const string CASE_TYPE_RENEWAL = "Renewal";
        private const string CASE_TYPE_MTA = "Mid-Term Adjustment";
        private const string CASE_TYPE_RR = "Revised Renewal";
        private const string CASE_TYPE_QUERY = "Query";
        private const string TRANS_TYPE_NEW_BUSINESS = "New Business";
        #endregion Constants

        #region PreUpdate
        /// <summary>
        /// Execute Case pre update logic
        /// </summary>
        internal void Execute()
        {
            //Sumegh Dhole : 20 Oct 2020 

            tracingService.Trace("Calling UpdateBasePremium()");
            UpdateBasePremium();
            tracingService.Trace("Calling PopulateEntityRefName()");
            this.PopulateEntityRefName();
            tracingService.Trace("Calling CSIRequiredBrokerCommitment()1");
            this.CSIRequiredBrokerCommitment();
            tracingService.Trace("End CSIRequiredBrokerCommitment()");
            tracingService.Trace("Calling SMEWorkingDaystoCompleteCase()");
            this.SMEWorkingDaystoCompleteCase();
            tracingService.Trace("End SMEWorkingDaystoCompleteCase()");
            tracingService.Trace("Calling MapAttributes()");
            //this.MapAttributes();
            tracingService.Trace("End MapAttributes()");
            //Call function AP10_CaseActivityOwnerUpdate cseObj = new AP10_CaseActivityOwnerUpdate(Trigger.OldMap, NewCaseMap); //TODO
            tracingService.Trace("Calling CaseActivityOwnerUpdate()");
            this.CaseActivityOwnerUpdate();
            tracingService.Trace("End CaseActivityOwnerUpdate()");
            tracingService.Trace("Calling SetSurveyVEFFlag()");
            this.SetSurveyVEFFlag();
            tracingService.Trace("End SetSurveyVEFFlag()");
            bool isSMECase = false;
            bool isExtranetEmailParsing = false;
            bool isPowerPlaceEmailParsing = false;
            bool isFreeFormatEmailParsing = false;
            tracingService.Trace("Calling ExtranetEmailParsing()");
            this.ExtranetEmailParsing(out isSMECase, out isExtranetEmailParsing);
            tracingService.Trace("End ExtranetEmailParsing()");
            tracingService.Trace("Calling PowerPlaceEmailParsing()");
            this.PowerPlaceEmailParsing(out isSMECase, out isPowerPlaceEmailParsing);
            tracingService.Trace("End PowerPlaceEmailParsing()");
            tracingService.Trace("Calling FreeFormatEmailParsing()");
            this.FreeFormatEmailParsing(out isSMECase, out isFreeFormatEmailParsing);
            tracingService.Trace("End FreeFormatEmailParsing()");
            tracingService.Trace("Calling PopulateBrokerAndCustomer()");
            this.PopulateBrokerAndCustomer();
            tracingService.Trace("End PopulateBrokerAndCustomer()");
            tracingService.Trace("Calling QuickCreate()");
            this.QuickCreate(out isSMECase);
            tracingService.Trace("End QuickCreate()");
            if (!isExtranetEmailParsing && !isPowerPlaceEmailParsing && !isFreeFormatEmailParsing)
            {
                tracingService.Trace("Calling SetCaseRecordTypeRules()");
                this.SetCaseRecordTypeRules(isSMECase);
                tracingService.Trace("End SetCaseRecordTypeRules()");
                //TODO - Once Pipeline class will be ready. then integrate 
                tracingService.Trace("Calling CallCreatePipelineOpportunity()");
                this.CallCreatePipelineOpportunity();
                tracingService.Trace("End CallCreatePipelineOpportunity()");
            }
            tracingService.Trace("Calling setpromisenonpromise()");
            this.setpromisenonpromise();
            tracingService.Trace("End setpromisenonpromise()");

            //TFS 500: 10Nov2022: PrimaryReference function added
            this.UpdatePreviousPrimaryReference();
            tracingService.Trace("Update Previous Broker Primary Reference");
            tracingService.Trace("End of Pre Update Execute()");

        }

        // Samiksha Dhakde || CR: TFS_500 || Set primary reference for previous broker primary reference field.
        private void UpdatePreviousPrimaryReference()
        {
            tracingService.Trace("Entered to Update Previous Primary Reference field");
            string primaryReference = string.Empty;
            if (enCasePreImage.Attributes.Contains("rsa_brokerprimaryreference"))
            {
                tracingService.Trace("Preimage Primary Reference" + primaryReference);
                primaryReference = enCasePreImage["rsa_brokerprimaryreference"].ToString();
                if (primaryReference.Equals(string.Empty))
                {
                    primaryReference = enCaseTarget.Attributes.Contains("rsa_brokerprimaryreference") ? enCaseTarget["rsa_brokerprimaryreference"].ToString() : null;                   
                }
                tracingService.Trace("Primary Reference is  : " + primaryReference);  
            }
            enCaseTarget["rsa_previousbrokerprimaryreference"] = primaryReference;
        }   

        /// <summary>
        /// TODO : Call AP10_CaseActivityOwnerUpdate translated function Assigned to Sachin
        /// </summary>
        private void CaseActivityOwnerUpdate()
        {
            tracingService.Trace("Within CaseActivityOwnerUpdate()-This is handled in Task management");
            /*
             if(NewCaseMap.size()>0 && Trigger.OldMap.size() > 0) {
                        System.debug('case before update for Activity owner');
                        AP10_CaseActivityOwnerUpdate cseObj = new AP10_CaseActivityOwnerUpdate(Trigger.OldMap,NewCaseMap);
                    }
             */
        }

        /// <summary>
        /// Get target site details
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="guidCOBId"></param>
        /// <param name="intDivision"></param>
        /// <param name="intTradingSite"></param>
        /// <returns></returns>
        private EntityCollection GetTargetSiteDetails(Guid guidCOBId)
        {
            EntityCollection enTargetSite = null;
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' no-lock='true'>
                              <entity name='rsa_sitetarget'>
                                <attribute name='rsa_productid' />
                                <attribute name='rsa_sitetargetid' />
                                <attribute name='rsa_target' />
                                <attribute name='rsa_periodcommencing' />
                                <attribute name='rsa_division' />
                                <order attribute='rsa_productid' descending='false' />
                                <filter type='and'>
                                  <condition attribute='rsa_classofbusiness' operator='eq' value='{0}' />                             
                                </filter>
                              </entity>
                            </fetch>";
            try
            {
                enTargetSite = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, guidCOBId)));
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception in GetTargetSiteDetails: " + ex.Message);
                //throw new Exception("Exception in GetTargetSiteDetails: " + ex.Message);
            }
            return enTargetSite;
        }


        /// <summary>
        ///Sumegh Dhole 13 Oct 2020 
        ///Update Base premium 
        /// </summary>
        private void UpdateBasePremium()
        {
            tracingService.Trace("Start Base premium update from opportunity or Policy");

            decimal policyPremium = 0.00M, calculatedpremium = 0.00M, targetPremium = 0.00M, basePremium = 0.00M, oppTargerPremium = 0.00M;
            try
            {
                EntityReference opportunityId = new EntityReference();
                EntityReference policyId = new EntityReference();
                opportunityId = enCaseTarget.Attributes.Contains("rsa_opportunityid") ? (EntityReference)enCaseTarget.Attributes["rsa_opportunityid"] : null;
                if (opportunityId == null)
                {
                    opportunityId = enCasePreImage.Attributes.Contains("rsa_opportunityid") ? (EntityReference)enCasePreImage.Attributes["rsa_opportunityid"] : null;
                }
                tracingService.Trace("Opportunity :" + opportunityId);
                policyId = enCaseTarget.Attributes.Contains("rsa_policyid") ? (EntityReference)enCaseTarget.Attributes["rsa_policyid"] : null;
                if (policyId == null)
                {
                    policyId = enCasePreImage.Attributes.Contains("rsa_policyid") ? (EntityReference)enCasePreImage.Attributes["rsa_policyid"] : null;
                }
                tracingService.Trace("Policy : " + policyId);
                EntityReference caseType = enCasePreImage.Attributes.Contains("rsa_casetype") ? (EntityReference)enCasePreImage.Attributes["rsa_casetype"] : null;
                tracingService.Trace("Case Type :" + caseType);
                if (policyId != null && !caseType.Name.ToLower().Equals("new business"))
                {
                    tracingService.Trace("Fetch policy premium if policy exists for case record");
                    Entity policy = service.Retrieve(policyId.LogicalName, policyId.Id, new ColumnSet(new string[] { "rsa_premium" }));
                    policyPremium = policy.Attributes.Contains("rsa_premium") ? ((Money)policy.Attributes["rsa_premium"]).Value : 0.00M;
                    tracingService.Trace("Policy Premium :" + policyPremium);
                    tracingService.Trace("Policy Premium data is  :" + policyPremium);
                }
                else if (opportunityId != null)
                {
                    tracingService.Trace("Case is linkedto oppty");
                    // Entity Opportunity = service.Retrieve(opportunityId.LogicalName, new Guid("5451b47b-f4e2-ea11-a814-000d3a7fc45e"), new ColumnSet(new string[] { "rsa_calcutatedpremium", "rsa_targetpremium" }));
                    Entity Opportunity = service.Retrieve(opportunityId.LogicalName, opportunityId.Id, new ColumnSet(new string[] { "rsa_calcutatedpremium", "rsa_targetpremium" }));
                    tracingService.Trace("Retrieve oppty details");
                    calculatedpremium = Opportunity.Attributes.Contains("rsa_calcutatedpremium") ? ((OptionSetValue)Opportunity.Attributes["rsa_calcutatedpremium"]).Value : 0.00M;
                    tracingService.Trace("calculatedpremium :" + calculatedpremium);
                    targetPremium = enCaseTarget.Attributes.Contains("rsa_targetpremium") ? (decimal)enCaseTarget.Attributes["rsa_targetpremium"] : 0.00M;
                    oppTargerPremium = Opportunity.Attributes.Contains("rsa_targetpremium") ? (decimal)Opportunity.Attributes["rsa_targetpremium"] : 0.00M;
                    tracingService.Trace("Retrieve oppty detailsoppTargerPremium" + oppTargerPremium);
                    tracingService.Trace("targetPremium :" + targetPremium);
                }

                //Ramesh YELAMAENNI : Defect No: 2193 if (caseType.Name .ToLower().Equals("renewal") || caseType.Name.ToLower().Equals("mid-term adjustment") || caseType.Name.ToLower().Equals("query") || caseType.Name.ToLower().Equals("revised renewal") || caseType.Name.ToLower().Equals("sme - email enquiry"))
                if (policyPremium > 0.00M && !caseType.Name.ToLower().Equals("new business"))
                {
                    basePremium = policyPremium;
                }
                else if (policyPremium == 0.00M && !caseType.Name.ToLower().Equals("new business") && (oppTargerPremium != 0))
                {
                    basePremium = oppTargerPremium;
                }
                ///Changes made for BUG 888. Added few extra check conditions.
                else if (caseType.Name.ToLower().Equals("new business") && (oppTargerPremium == 0 || oppTargerPremium == null))
                {
                    switch (calculatedpremium.ToString())
                    {
                        case "866760000":
                            basePremium = 1000.00M;
                            break;
                        case "866760001":
                            basePremium = 5000.00M;
                            break;
                        case "866760002":
                            basePremium = 5000.01M;
                            break;
                        case "866760003":
                            basePremium = 10000.00M;
                            break;
                        case "866760004":
                            basePremium = 15000.00M;
                            break;
                        case "866760005":
                            basePremium = 15000.01M;
                            break;
                        case "866760006":
                            basePremium = 25000.00M;
                            break;
                        case "866760007":
                            basePremium = 50000.00M;
                            break;
                        case "866760008":
                            basePremium = 100000.00M;
                            break;
                        case "866760009":
                            basePremium = 250000.00M;
                            break;
                        case "866760010":
                            basePremium = 500000.00M;
                            break;
                        case "866760011":
                            basePremium = 1000000.00M;
                            break;
                        case "866760012":
                            basePremium = 1000000.01M;
                            break;
                        default:
                            break;
                    }
                }
                else if (caseType.Name.ToLower().Equals("new business") && (oppTargerPremium != 0))
                {
                    tracingService.Trace(":Line 243 target premium contains data ");
                    basePremium = oppTargerPremium;
                }
                tracingService.Trace("basePremium :" + basePremium);
                enCaseTarget["rsa_basepremium"] = new Money(basePremium);
                enCaseTarget["rsa_basepremiumrsa"] = (decimal)basePremium;


            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while updating in Base Premium(): " + ex.Message);
            }
        }


        /// <summary>
        /// Email extranet parcing logic
        /// </summary>
        /// <param name="isSMECase"></param>
        /// <param name="isExtranetEmailParsing"></param>
        private void ExtranetEmailParsing(out bool isSMECase, out bool isExtranetEmailParsing)
        {
            tracingService.Trace("Within ExtranetEmailParsing()");
            isExtranetEmailParsing = false;
            isSMECase = false;
            RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon = new RSA.CSI.Plugins.Case.CaseCommon.CaseCommon(service, tracingService);

            var strRecordTypeName = caseCommon.GetCustomLabel("CL0030_SME_EmailTemplate");
            tracingService.Trace("Successfully fetched CL0030_SME_EmailTemplate: " + strRecordTypeName);
            //if ((enCaseTarget.Attributes.Contains("rsa_casetype") &&
            //    strRecordTypeName.Contains(((EntityReference)enCaseTarget.Attributes["rsa_casetype"]).Name))
            //    ||
            //    (enNewCase.Attributes.Contains("rsa_casetype") &&
            //    strRecordTypeName.Contains(((EntityReference)enNewCase.Attributes["rsa_casetype"]).Name)))
            if (strRecordTypeName.Contains(strTargetCaseType))
            {
                tracingService.Trace("selected rsa_casetype target: " + enCaseTarget.Attributes.Contains("rsa_casetype"));
                tracingService.Trace("selected rsa_casetype new: " + enNewCase.Attributes.Contains("rsa_casetype"));
                isSMECase = true;
                string enStatus = string.Empty;
                if (enCaseTarget.Attributes.Contains("rsa_status"))
                {
                    enStatus = caseCommon.GetNameByStatusId(((EntityReference)enCaseTarget.Attributes["rsa_status"]).Id);
                }
                else if (enNewCase.Attributes.Contains("rsa_status"))
                {
                    enStatus = caseCommon.GetNameByStatusId(((EntityReference)enNewCase.Attributes["rsa_status"]).Id);
                }
                //if (!String.IsNullOrEmpty(enStatus) && !enStatus.Equals("Closed"))
                if ((!enCaseTarget.Attributes.Contains("rsa_policyid") &&
                !enCaseTarget.Attributes.Contains("rsa_customerrsa") &&
                !string.IsNullOrEmpty(enStatus) && enStatus.Equals("New"))
                ||
                (!enNewCase.Attributes.Contains("rsa_policyid") &&
                !enNewCase.Attributes.Contains("rsa_customerrsa") &&
                !string.IsNullOrEmpty(enStatus) && enStatus.Equals("New")))
                {
                    isExtranetEmailParsing = true;
                    //Call EmailTemplateEmailToCase function
                    tracingService.Trace("Calling EmailTemplateEmailToCase()");
                    this.EmailTemplateEmailToCase();
                }
                else
                {
                    tracingService.Trace("Unable to call EmailTemplateEmailToCase() due to validation failed");
                    tracingService.Trace("rsa_policyid exists target: " + enCaseTarget.Attributes.Contains("rsa_policyid"));
                    tracingService.Trace("rsa_customerrsa exists target: " + enCaseTarget.Attributes.Contains("rsa_customerrsa"));
                    tracingService.Trace("rsa_status exists target: " + enCaseTarget.Attributes.Contains("rsa_status"));
                    tracingService.Trace("rsa_policyid exists new: " + enNewCase.Attributes.Contains("rsa_policyid"));
                    tracingService.Trace("rsa_customerrsa exists new: " + enNewCase.Attributes.Contains("rsa_customerrsa"));
                    tracingService.Trace("rsa_status exists new: " + enNewCase.Attributes.Contains("rsa_status"));
                }
            }
        }
        /// <summary>
        /// Call Email Template email to to case function
        /// </summary>
        private void EmailTemplateEmailToCase()
        {
            tracingService.Trace("Winthin EmailTemplateEmailToCase() and calling SMEEmailTemplate()");
            EmailToCaseLogic emailToCaseLogic = new EmailToCaseLogic(service, tracingService, enCaseTarget, enNewCase);
            emailToCaseLogic.SMEEmailTemplate();
            tracingService.Trace("End of SMEEmailTemplate()");
        }
        /// <summary>
        /// Free format email power place logic
        /// </summary>
        /// <param name="isSMECase"></param>
        /// <param name="isPowerPlaceEmailParsing"></param>
        private void PowerPlaceEmailParsing(out bool isSMECase, out bool isPowerPlaceEmailParsing)
        {
            tracingService.Trace("Within PowerPlaceEmailParsing()");
            isPowerPlaceEmailParsing = false;
            isSMECase = false;
            RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon = new RSA.CSI.Plugins.Case.CaseCommon.CaseCommon(service, tracingService);
            var strRecordTypeName = caseCommon.GetCustomLabel("CL0031_SME_EmailTemplate_Powerplace");
            tracingService.Trace("Successfully fetched CL0031_SME_EmailTemplate_Powerplace: " + strRecordTypeName);
            //if ((enCaseTarget.Attributes.Contains("rsa_casetype") &&
            //    strRecordTypeName.Contains(((EntityReference)enCaseTarget.Attributes["rsa_casetype"]).Name))
            //    ||
            //    (enNewCase.Attributes.Contains("rsa_casetype") &&
            //    strRecordTypeName.Contains(((EntityReference)enNewCase.Attributes["rsa_casetype"]).Name)))
            if (strRecordTypeName.Contains(strTargetCaseType))
            {
                tracingService.Trace("selected rsa_casetype target: " + enCaseTarget.Attributes.Contains("rsa_casetype"));
                tracingService.Trace("selected rsa_casetype new: " + enNewCase.Attributes.Contains("rsa_casetype"));
                isSMECase = true;
                if ((!enCaseTarget.Attributes.Contains("rsa_isemailparsingalreadyrun") || (enCaseTarget.Attributes.Contains("rsa_isemailparsingalreadyrun") &&
                    !enCaseTarget.Attributes["rsa_isemailparsingalreadyrun"].ToString().ToUpper().Equals("TRUE")))
                    ||
                    (!enNewCase.Attributes.Contains("rsa_isemailparsingalreadyrun") || (enNewCase.Attributes.Contains("rsa_isemailparsingalreadyrun") &&
                    !enNewCase.Attributes["rsa_isemailparsingalreadyrun"].ToString().ToUpper().Equals("TRUE"))))
                {
                    isPowerPlaceEmailParsing = true;
                    //Call EmailTemplateEmailToCase function
                    tracingService.Trace("Calling PowerPlaceEmailTemplateEmailToCase()");
                    this.PowerPlaceEmailTemplateEmailToCase();
                }
                else
                {
                    tracingService.Trace("Unable to call PowerPlaceEmailTemplateEmailToCase() due to validation failed");
                    tracingService.Trace("rsa_isemailparsingalreadyrun exists target: " + enCaseTarget.Attributes.Contains("rsa_isemailparsingalreadyrun"));
                    tracingService.Trace("rsa_isemailparsingalreadyrun exists new: " + enNewCase.Attributes.Contains("rsa_isemailparsingalreadyrun"));
                    tracingService.Trace("rsa_isemailparsingalreadyrun is 'TRUE'?: ");
                }
            }
        }

        /// <summary>
        /// Call power place function
        /// </summary>
        private void PowerPlaceEmailTemplateEmailToCase()
        {
            tracingService.Trace("Winthin PowerPlaceEmailTemplateEmailToCase() and calling SMEPowerPlace()");
            EmailToCaseLogic emailToCaseLogic = new EmailToCaseLogic(service, tracingService, enCaseTarget, enNewCase);
            emailToCaseLogic.SMEPowerPlace();
            tracingService.Trace("End of SMEPowerPlace()");
        }

        /// <summary>
        /// Free format email parsing logic
        /// </summary>
        /// <param name="isSMECase"></param>
        /// <param name="isFreeFormatEmailParsing"></param>
        private void FreeFormatEmailParsing(out bool isSMECase, out bool isFreeFormatEmailParsing)
        {
            tracingService.Trace("Within FreeFormatEmailParsing()");
            isFreeFormatEmailParsing = false;
            isSMECase = false;
            RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon = new RSA.CSI.Plugins.Case.CaseCommon.CaseCommon(service, tracingService);
            var strRecordTypeName = caseCommon.GetCustomLabel("CL0032_SME_FreeFormat");
            tracingService.Trace("Successfully fetched CL0032_SME_FreeFormat: " + strRecordTypeName);
            //if ((enCaseTarget.Attributes.Contains("rsa_casetype") &&
            //    strRecordTypeName.Contains(((EntityReference)enCaseTarget.Attributes["rsa_casetype"]).Name)) ||
            //    (enNewCase.Attributes.Contains("rsa_casetype") &&
            //    strRecordTypeName.Contains(((EntityReference)enNewCase.Attributes["rsa_casetype"]).Name)))
            if (strRecordTypeName.Contains(strTargetCaseType))
            {
                tracingService.Trace("selected rsa_casetype target: " + enCaseTarget.Attributes.Contains("rsa_casetype"));
                tracingService.Trace("selected rsa_casetype new: " + enNewCase.Attributes.Contains("rsa_casetype"));
                isSMECase = true;
                if ((!enCaseTarget.Attributes.Contains("rsa_isemailparsingalreadyrun") || (enCaseTarget.Attributes.Contains("rsa_isemailparsingalreadyrun") &&
                    !enCaseTarget.Attributes["rsa_isemailparsingalreadyrun"].ToString().ToUpper().Equals("TRUE")))
                    ||
                    (!enNewCase.Attributes.Contains("rsa_isemailparsingalreadyrun") || (enNewCase.Attributes.Contains("rsa_isemailparsingalreadyrun") &&
                    !enNewCase.Attributes["rsa_isemailparsingalreadyrun"].ToString().ToUpper().Equals("TRUE"))))
                {
                    tracingService.Trace("Calling FreeFormatEmailTemplateEmailToCase()");
                    isFreeFormatEmailParsing = true;
                    //Call EmailTemplateEmailToCase function
                    this.FreeFormatEmailTemplateEmailToCase();
                }
                else
                {
                    tracingService.Trace("Unable to call FreeFormatEmailTemplateEmailToCase() due to validation failed");
                    tracingService.Trace("rsa_isemailparsingalreadyrun exists target: " + enCaseTarget.Attributes.Contains("rsa_isemailparsingalreadyrun"));
                    tracingService.Trace("rsa_isemailparsingalreadyrun exists new: " + enNewCase.Attributes.Contains("rsa_isemailparsingalreadyrun"));
                    tracingService.Trace("rsa_isemailparsingalreadyrun is 'TRUE'?: ");
                }
            }
        }

        /// <summary>
        /// Call Free format email template
        /// </summary>
        private void FreeFormatEmailTemplateEmailToCase()
        {
            tracingService.Trace("Winthin FreeFormatEmailTemplateEmailToCase() and calling SMEFreeFormat()");
            EmailToCaseLogic emailToCaseLogic = new EmailToCaseLogic(service, tracingService, enCaseTarget, enNewCase);
            emailToCaseLogic.SMEFreeFormat();
            tracingService.Trace("End of SMEFreeFormat()");
        }

        /// <summary>
        /// for bug 1208,1209,1210,1211,1212
        /// to set the promise data on case. 
        /// </summary>
        private void setpromisenonpromise()
        {
            tracingService.Trace("Enter: setpromisenonpromise");
            EntityReference caseType = enCaseTarget.Attributes.Contains("rsa_casetype") ? enCaseTarget.GetAttributeValue<EntityReference>("rsa_casetype") : null;
            EntityReference opportunityId = enCaseTarget.Attributes.Contains("rsa_opportunityid") ? enCaseTarget.GetAttributeValue<EntityReference>("rsa_opportunityid") : null;
            EntityReference BrokerId = enCaseTarget.Attributes.Contains("rsa_account") ? enCaseTarget.GetAttributeValue<EntityReference>("rsa_account") : null;
            EntityReference policyId = enCaseTarget.Attributes.Contains("rsa_policyid") ? enCaseTarget.GetAttributeValue<EntityReference>("rsa_policyid") : null;
            string pandl = enCaseTarget.Attributes.Contains("rsa_pl_w") ? enCaseTarget.GetAttributeValue<string>("rsa_pl_w") : null;
            string promiseBroker = enCaseTarget.Attributes.Contains("rsa_promisebroker") ? enCaseTarget.GetAttributeValue<string>("rsa_promisebroker") : string.Empty;
            string promiseNewBusiness = null;
            string promiseRenewal = null;
            if (caseType != null)
            {
                tracingService.Trace("case type found:" + caseType.Id);

                tracingService.Trace("case type name:" + caseType.Name);

                if (BrokerId != null)
                {
                    Entity BrokerData = service.Retrieve(BrokerId.LogicalName, BrokerId.Id, new ColumnSet(new string[] { "rsa_promisenewbusiness", "rsa_promiserenewal" }));
                    promiseNewBusiness = BrokerData.FormattedValues.ContainsKey("rsa_promisenewbusiness") ? BrokerData.FormattedValues["rsa_promisenewbusiness"] : null;
                    tracingService.Trace("promise new business broker from broker value" + promiseNewBusiness);
                    promiseRenewal = BrokerData.FormattedValues.ContainsKey("rsa_promiserenewal") ? BrokerData.FormattedValues["rsa_promiserenewal"] : null;
                    tracingService.Trace("promise renewal broker from broker value" + promiseRenewal);
                }
                tracingService.Trace("Promise/Non-promise about to set");
                if (caseType.Name.ToLowerInvariant().Equals("new business") || caseType.Name.ToLowerInvariant().Equals("schemes - bordereaux"))
                {
                    if (promiseNewBusiness != null && pandl != null && promiseNewBusiness.ToLowerInvariant().Contains(pandl.ToLowerInvariant()))
                    {
                        tracingService.Trace("Promise about to set");
                        enCaseTarget["rsa_promise"] = new OptionSetValue(866760000);
                    }
                    else if (promiseNewBusiness != null && pandl != null && !promiseNewBusiness.ToLowerInvariant().Contains(pandl.ToLowerInvariant()))
                    {
                        tracingService.Trace("Non Promise about to set 1");
                        enCaseTarget["rsa_promise"] = new OptionSetValue(866760001);
                    }
                    else
                    {
                        tracingService.Trace("Non Promise about to set 2");
                        enCaseTarget["rsa_promise"] = new OptionSetValue(866760001);
                    }
                }
                else if (caseType.Name.ToLowerInvariant().Contains("renewal"))
                {
                    if (promiseRenewal != null && pandl != null && promiseRenewal.ToLowerInvariant().Contains(pandl.ToLowerInvariant()))
                    {
                        tracingService.Trace("Promise renewal about to set");
                        enCaseTarget["rsa_promise"] = new OptionSetValue(866760000);
                    }
                    else if (promiseRenewal != null && pandl != null && !promiseRenewal.ToLowerInvariant().Contains(pandl.ToLowerInvariant()))
                    {
                        tracingService.Trace("Non Promise about to set 1");
                        enCaseTarget["rsa_promise"] = new OptionSetValue(866760001);
                    }
                    else
                    {
                        tracingService.Trace("Non Promise about to set 2");
                        enCaseTarget["rsa_promise"] = new OptionSetValue(866760001);
                    }

                }
            }

        }

        /// <summary>
        /// Quick create
        /// </summary>
        /// <param name="isSMECase"></param>
        private void QuickCreate(out bool isSMECase)
        {
            tracingService.Trace("Winthin QuickCreate()");
            isSMECase = false;
            RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon = new RSA.CSI.Plugins.Case.CaseCommon.CaseCommon(service, tracingService);
            var strRecordTypeName = caseCommon.GetCustomLabel("CL0030_SME_Quick_Create");
            tracingService.Trace("Successfully fetched CL0030_SME_Quick_Create: " + strRecordTypeName);
            //if ((enCaseTarget.Attributes.Contains("rsa_casetype") &&
            //   strRecordTypeName.Contains(((EntityReference)enCaseTarget.Attributes["rsa_casetype"]).Name))
            //   ||
            //   (enNewCase.Attributes.Contains("rsa_casetype") &&
            //   strRecordTypeName.Contains(((EntityReference)enNewCase.Attributes["rsa_casetype"]).Name)))
            if (strRecordTypeName.Contains(strTargetCaseType))
            {
                isSMECase = true;
                EmailToCaseLogic emailToCaseLogic = new EmailToCaseLogic(service, tracingService, enCaseTarget, enNewCase);
                tracingService.Trace("selected rsa_casetype target: " + enCaseTarget.Attributes.Contains("rsa_casetype"));
                tracingService.Trace("selected rsa_casetype new: " + enNewCase.Attributes.Contains("rsa_casetype"));
                if ((!enCaseTarget.Attributes.Contains("rsa_policyid") &&
                    enCaseTarget.Attributes.Contains("rsa_policynumberqc") &&
                    enCaseTarget.Attributes.Contains("rsa_policysystemqc"))
                    ||
                    (!enNewCase.Attributes.Contains("rsa_policyid") &&
                    enNewCase.Attributes.Contains("rsa_policynumberqc") &&
                    enNewCase.Attributes.Contains("rsa_policysystemqc")))
                {
                    tracingService.Trace("Calling SMEQuickCreatePolicy()");
                    emailToCaseLogic.SMEQuickCreatePolicy();
                }
                else
                {
                    tracingService.Trace("Unable to call SMEQuickCreatePolicy() due to validation failed");
                    tracingService.Trace("rsa_policyid does not exists target: " + !enCaseTarget.Attributes.Contains("rsa_policyid"));
                    tracingService.Trace("rsa_policynumberqc exists target: " + enCaseTarget.Attributes.Contains("rsa_policynumberqc"));
                    tracingService.Trace("rsa_policysystemqc exists target: " + enCaseTarget.Attributes.Contains("rsa_policysystemqc"));
                    tracingService.Trace("rsa_policyid does not exists new: " + !enNewCase.Attributes.Contains("rsa_policyid"));
                    tracingService.Trace("rsa_policynumberqc exists new: " + enNewCase.Attributes.Contains("rsa_policynumberqc"));
                    tracingService.Trace("rsa_policysystemqc exists new: " + enNewCase.Attributes.Contains("rsa_policysystemqc"));
                }
                if ((!enCaseTarget.Attributes.Contains("rsa_customerrsa") &&
                    enCaseTarget.Attributes.Contains("rsa_customerpostcode") &&
                    enCaseTarget.Attributes.Contains("rsa_customername"))
                    ||
                    (!enNewCase.Attributes.Contains("rsa_customerrsa") &&
                    enNewCase.Attributes.Contains("rsa_customerpostcode") &&
                    enNewCase.Attributes.Contains("rsa_customername")))
                {
                    tracingService.Trace("Calling QuickCreateCustomer()");
                    emailToCaseLogic.QuickCreateCustomer();
                }
                else
                {
                    tracingService.Trace("Unable to call QuickCreateCustomer() due to validation failed");
                    tracingService.Trace("rsa_customerrsa exists target: " + enCaseTarget.Attributes.Contains("rsa_policyid"));
                    tracingService.Trace("rsa_customerpostcode exists target: " + enCaseTarget.Attributes.Contains("rsa_customerpostcode"));
                    tracingService.Trace("rsa_customername exists target: " + enCaseTarget.Attributes.Contains("rsa_customername"));
                    tracingService.Trace("rsa_customerrsa exists new: " + enNewCase.Attributes.Contains("rsa_policyid"));
                    tracingService.Trace("rsa_customerpostcode exists new: " + enNewCase.Attributes.Contains("rsa_customerpostcode"));
                    tracingService.Trace("rsa_customername exists new: " + enNewCase.Attributes.Contains("rsa_customername"));
                }
                if ((!enCaseTarget.Attributes.Contains("rsa_account") &&
                    enCaseTarget.Attributes.Contains("rsa_agencynumber"))
                    ||
                    (!enNewCase.Attributes.Contains("rsa_account") &&
                    enNewCase.Attributes.Contains("rsa_agencynumber")))
                {
                    tracingService.Trace("Calling QuickCreateBroker()");
                    emailToCaseLogic.QuickCreateBroker();
                }
                else
                {
                    tracingService.Trace("Unable to call QuickCreateBroker() due to validation failed");
                    tracingService.Trace("rsa_broker exists target: " + enCaseTarget.Attributes.Contains("rsa_account"));
                    tracingService.Trace("rsa_agencynumber exists target: " + enCaseTarget.Attributes.Contains("rsa_agencynumber"));
                    tracingService.Trace("rsa_broker exists new: " + enNewCase.Attributes.Contains("rsa_account"));
                    tracingService.Trace("rsa_agencynumber exists new: " + enNewCase.Attributes.Contains("rsa_agencynumber"));
                }

            }
            else
            {
                tracingService.Trace("Unable to call Quick create sub methods() due to validation failed");
                tracingService.Trace("rsa_isemailparsingalreadyrun exists: ");
                tracingService.Trace("rsa_isemailparsingalreadyrun is 'TRUE'?: ");
            }
            tracingService.Trace("End QuickCreate()");
        }

        /// <summary>
        /// This is to store the Broker & Customer on the Case record from the Quote record linked to the Case
        /// </summary>
        private void PopulateBrokerAndCustomer()
        {
            tracingService.Trace("Winthin PopulateBrokerAndCustomer()");
            if ((enCaseTarget.Attributes.Contains("rsa_quoteid")) || (enNewCase.Attributes.Contains("rsa_quoteid")))
            {
                tracingService.Trace("Calling GetQuoteDetails()");
                Entity enRSAQuoteDetails = null;
                if (enCaseTarget.Attributes.Contains("rsa_quoteid") && enCaseTarget.Attributes["rsa_quoteid"] != null)
                {
                    tracingService.Trace("rsa_quoteid in target1");
                    enRSAQuoteDetails = this.GetQuoteDetails(((EntityReference)enCaseTarget.Attributes["rsa_quoteid"]).Id);
                    tracingService.Trace("rsa_quoteid in target2");
                }
                else if (enNewCase.Attributes.Contains("rsa_quoteid") && enNewCase.Attributes["rsa_quoteid"] != null)
                {
                    tracingService.Trace("rsa_quoteid in new1");
                    EntityReference Quoteidcheck = enCaseTarget.Attributes.Contains("rsa_quoteid") ? enCaseTarget.GetAttributeValue<EntityReference>("rsa_quoteid") : null;
                    tracingService.Trace("rsa_quoteid Quoteidcheck" + Quoteidcheck);
                    if (Quoteidcheck != null)
                    {
                        tracingService.Trace("Quote ID for getQuotedetails" + Quoteidcheck.Id);

                        enRSAQuoteDetails = this.GetQuoteDetails(((EntityReference)enCaseTarget.Attributes["rsa_quoteid"]).Id);
                        tracingService.Trace("rsa_quoteid in new2");
                    }
                }

                //var enRSAQuoteDetails = this.GetQuoteDetails(((EntityReference)enCasePreImage.Attributes["rsa_quoteid"]).Id);
                if (enRSAQuoteDetails != null && enRSAQuoteDetails.Id != Guid.Empty)
                {
                    tracingService.Trace("enRSAQuoteDetails contains values");
                    if (enRSAQuoteDetails.Attributes.Contains("rsa_customerid"))
                    {
                        tracingService.Trace("enRSAQuoteDetails contains rsa_customerid");
                        enCaseTarget["rsa_customerrsa"] = enRSAQuoteDetails["rsa_customerid"];
                        tracingService.Trace("Populating  enCaseTarget rsa_customerrsa");
                    }
                    else
                    {
                        tracingService.Trace("rsa_customerid is null");
                    }
                    if (enRSAQuoteDetails.Attributes.Contains("rsa_brokerid"))
                    {
                        tracingService.Trace("enRSAQuoteDetails contains rsa_brokerid");
                        enCaseTarget["rsa_account"] = enRSAQuoteDetails["rsa_brokerid"];
                        tracingService.Trace("Populating  enCaseTarget rsa_account");
                    }
                    else
                    {
                        tracingService.Trace("rsa_brokerid is null");
                    }
                }
                else
                {
                    tracingService.Trace("Unable to fetch GetQuoteDetails()");
                }
            }
        }

        /// <summary>
        /// Get RSA quote details
        /// </summary>
        /// <param name="guidQuoteId"></param>
        /// <returns></returns>
        private Entity GetQuoteDetails(Guid guidQuoteId)
        {
            Entity enRSAQuote = null;
            try
            {
                enRSAQuote = service.Retrieve("rsa_rsaquote", guidQuoteId, new ColumnSet("rsa_customerid", "rsa_brokerid"));
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception in GetQuoteDetails: " + ex.Message);
                //throw new Exception("Exception in GetQuoteDetails: " + ex.Message);
            }

            return enRSAQuote;
        }
        /// <summary>
        /// Set Case record type rules
        /// </summary>
        /// <param name="isSMECase"></param>
        private void SetCaseRecordTypeRules(bool isSMECase)
        {
            tracingService.Trace("Winthin SetCaseRecordTypeRules()");
            //if there is no update in rsa_rsarecordtype, capturing the same from post image
            if ((enCaseTarget.Attributes.Contains("rsa_casetype")) || (enNewCase.Attributes.Contains("rsa_casetype")))
                //enCaseTarget.Attributes["rsa_casetype"] = enCasePreImage.Attributes["rsa_casetype"]; Sumanta
                if ((enCaseTarget.Attributes.Contains("ownerid")) || (enNewCase.Attributes.Contains("ownerid")))
                    //enCaseTarget.Attributes["ownerid"] = enCasePreImage.Attributes["ownerid"]; Sumanta
                    tracingService.Trace("Calling CallRequestCaseTypeMethods()");
            this.CallRequestCaseTypeMethods(isSMECase);
        }

        /// <summary>
        /// Call function based in rsa record type [Revised Renewal,Mid-Term Adjustment ,Renewal,Query]
        /// </summary>
        /// <param name="isSMECase"></param>
        private void CallRequestCaseTypeMethods(bool isSMECase)
        {
            tracingService.Trace("Winthin CallRequestCaseTypeMethods()");
            RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon = new RSA.CSI.Plugins.Case.CaseCommon.CaseCommon(service, tracingService);
            // populate owner copy 
            //if (enCasePreImage.Attributes.Contains("ownerid") && ((EntityReference)enCasePreImage.Attributes["ownerid"]).Name.StartsWith("005"))

            if (enCaseTarget.Attributes.Contains("ownerid"))
            {
                enCaseTarget["rsa_ownercopyid"] = enCaseTarget["ownerid"];
                tracingService.Trace("rsa_ownercopyid polulated");
            }

            else if (enNewCase.Attributes.Contains("ownerid"))
            {
                enCaseTarget["rsa_ownercopyid"] = enNewCase["ownerid"];
                tracingService.Trace("rsa_ownercopyid polulated");
            }
            string enStatus = string.Empty;
            if (enCaseTarget.Attributes.Contains("rsa_status"))
            {
                enStatus = caseCommon.GetNameByStatusId(((EntityReference)enCaseTarget.Attributes["rsa_status"]).Id);
            }
            else if (enNewCase.Attributes.Contains("rsa_status"))
            {
                enStatus = caseCommon.GetNameByStatusId(((EntityReference)enNewCase.Attributes["rsa_status"]).Id);
            }
            if (!String.IsNullOrEmpty(enStatus) && !enStatus.Equals("Closed"))
            {
                tracingService.Trace("Calling SetCaseReceivedDate");
                this.SetCaseReceivedDate();
                tracingService.Trace("Successfully executed SetCaseReceivedDate");
            }
            if ((enCaseTarget.Attributes.Contains("rsa_casetype") &&
                enCaseTarget.Attributes.Contains("rsa_policyid"))
                ||
                (enNewCase.Attributes.Contains("rsa_casetype") &&
                enNewCase.Attributes.Contains("rsa_policyid")))
            {
                //var intRequestType = ((OptionSetValue)enCasePreImage.Attributes["rsa_rsarecordtype"]).Value;
                string strCaseType = string.Empty;
                //if (enNewCase.Attributes.Contains("rsa_casetype"))
                //    strCaseType = ((EntityReference)enNewCase.Attributes["rsa_casetype"]).Name;
                //else if (enCaseTarget.Attributes.Contains("rsa_casetype"))
                //    strCaseType = ((EntityReference)enNewCase.Attributes["rsa_casetype"]).Name;
                strCaseType = strTargetCaseType;
                tracingService.Trace("Calling function based on Renewl Type: " + strCaseType);
                ///if (intRequestType == 866760012) // Mid-Term Adjustment 
                if (strCaseType.Equals(CASE_TYPE_MTA))
                {
                    tracingService.Trace("Calling function SetMTACaseTeam");
                    //call function
                    //preCreateLogic.SetMTACaseTeam(service, tracingService, enCaseTarget);
                    this.SetMTACaseTeam();
                    tracingService.Trace("Completed function SetMTACaseTeam");
                }
                //else if (intRequestType == 866760020 &&
                //    enCasePreImage.Attributes.Contains("rsa_opportunityid")) // Renewal 
                else if ((strCaseType.Equals(CASE_TYPE_RENEWAL) &&
                    enCaseTarget.Attributes.Contains("rsa_opportunityid"))
                    ||
                    (strCaseType.Equals(CASE_TYPE_RENEWAL) &&
                    enNewCase.Attributes.Contains("rsa_opportunityid"))) // Renewal 
                {
                    tracingService.Trace("Calling function SetPromise");
                    //call function
                    //preCreateLogic.SetPromise(service, tracingService, enCaseTarget);
                    this.SetPromise();
                    tracingService.Trace("Completed function SetPromise");
                    //this.ValidatePolicy(service, tracingService, enCaseTarget);
                    //tracingService.Trace("Completed function ValidatePolicy");
                }
                //else if (intRequestType == 866760018) // Query 
                else if (strCaseType.Equals(CASE_TYPE_QUERY)) // Query 
                {
                    tracingService.Trace("Calling function SetServicing");
                    //call function
                    //preCreateLogic.SetServicing(service, tracingService, enCaseTarget);
                    this.SetServicing();
                    tracingService.Trace("Completed function SetServicing");
                }
                //else if (intRequestType == 866760023 && !isSMECase) // Revised Renewal
                else if (strCaseType.Equals(CASE_TYPE_RR) && !isSMECase) // Revised Renewal
                {
                    tracingService.Trace("Calling function SetRRCaseTeam");
                    //call function
                    //preCreateLogic.SetRRCaseTeam(service, tracingService, enCaseTarget);
                    this.SetRRCaseTeam();
                    tracingService.Trace("Completed function SetRRCaseTeam");
                }
                //else if (intRequestType == 866760013 && enCasePreImage != null &&
                //    enCasePreImage.Attributes.Contains("rsa_outcomedate") && enCasePreImage.Attributes.Contains("rsa_status") && 
                //        !((EntityReference)enCasePreImage.Attributes["rsa_status"]).Name.Equals("Accepted")) // New Business
                string enStatusValue = string.Empty;
                if (enCaseTarget.Attributes.Contains("rsa_status"))
                {
                    enStatusValue = caseCommon.GetNameByStatusId(((EntityReference)enCaseTarget.Attributes["rsa_status"]).Id);
                }
                else if (enNewCase.Attributes.Contains("rsa_status"))
                {
                    enStatusValue = caseCommon.GetNameByStatusId(((EntityReference)enNewCase.Attributes["rsa_status"]).Id);
                }
                else if ((strCaseType.Equals(CASE_TYPE_NEW_BUSINESS) && enCaseTarget != null &&
                    enCaseTarget.Attributes.Contains("rsa_outcomedate") && !String.IsNullOrEmpty(enStatusValue) && enStatusValue.Equals("Accepted"))
                        ||
                        (strCaseType.Equals(CASE_TYPE_NEW_BUSINESS) && enNewCase != null &&
                    enNewCase.Attributes.Contains("rsa_outcomedate") && !String.IsNullOrEmpty(enStatusValue) && enStatusValue.Equals("Accepted"))) // New Business 
                {
                    tracingService.Trace("Calling function StampCaseSiteTarget");
                    //call function
                    this.StampCaseSiteTarget();
                    tracingService.Trace("Completed function StampCaseSiteTarget");
                }

                if (!String.IsNullOrEmpty(enStatusValue) && enStatusValue.Equals("Closed") &&
                    !enCaseTarget.Attributes.Contains("rsa_dummyreportingfield")
                    ||
                    (!String.IsNullOrEmpty(enStatusValue) && enStatusValue.Equals("Closed") &&
                    !enNewCase.Attributes.Contains("rsa_dummyreportingfield")))
                {

                    tracingService.Trace("Calling GetUserDetails()");
                    Entity enUser = caseCommon.GetUserDetails(guidCallingUserId);
                    if (enUser != null && enUser.Id != Guid.Empty)
                    {
                        if (enUser.Attributes.Contains("rsa_usersite"))
                        {
                            //Prachi Paunikar: Bug 1391
                            //Reason: Completed by User does not have same value as User Site.
                            //enCaseTarget["rsa_completedbysite"] = enUser["rsa_usersite"];
                            tracingService.Trace("Populating rsa_completedbysite");
                        }
                        if (enUser.Attributes.Contains("rsa_userteamlevel2"))
                        {
                            //TODO, it is lookup in Case and at user level it is OptionSet
                            //It should be OptionSet in Case entity
                            //enCaseTarget["rsa_completedbyteamid"] = enUser["rsa_userteamlevel2"];
                        }
                        if (enUser.Attributes.Contains("fullname"))
                        {
                            enCaseTarget["rsa_completedbyuser"] = enUser["fullname"];
                            tracingService.Trace("Populating rsa_completedbyuser");
                        }
                        if (enUser.Attributes.Contains("rsa_division"))
                        {
                            //Prachi Paunikar: Bug 1391
                            //Reason: Completed by Divison does not have same value as User's Division.
                            //enCaseTarget["rsa_completedbydivision"] = enUser["rsa_division"];
                            tracingService.Trace("Populating rsa_completedbydivision");
                        }
                        enCaseTarget["rsa_dummyreportingfield"] = "Inserted a Value";
                        tracingService.Trace("Populating rsa_dummyreportingfield");
                    }
                }
            }
        }
        /// <summary>
        /// Stamp site target fucntionality and polulate 'rsa_sitetargetid'
        /// </summary>
        private void StampCaseSiteTarget()
        {
            tracingService.Trace("Winthin StampCaseSiteTarget()");
            if ((enCaseTarget.Attributes.Contains("rsa_classofbusinessphoneenqid") &&
                enCaseTarget.Attributes.Contains("rsa_currentownerdivision") &&
                enCaseTarget.Attributes.Contains("rsa_currentownersite") &&
                enCaseTarget.Attributes.Contains("rsa_outcomedate"))
                ||
                (enNewCase.Attributes.Contains("rsa_classofbusinessphoneenqid") &&
                enNewCase.Attributes.Contains("rsa_currentownerdivision") &&
                enNewCase.Attributes.Contains("rsa_currentownersite") &&
                enNewCase.Attributes.Contains("rsa_outcomedate")))
            {
                tracingService.Trace("Calling GetTargetSiteDetails()");
                tracingService.Trace("Due to Datatype Mismatch, can not retrive value of Target Site");
                //TODO: Due to Datatype Mismatch, can not retrive value of Target Site - Once confirmed for Class of Business
                //Compared ClassofBusiness(Case) and Product(TargetSite)
                //rsa_currentownerdivision(Case) calculated single line and rsa_division(Site Target) - Optionset
                //rsa_currentownersite(Case) - Calculated Single Line and rsa_tradingsite(Site Target) - Optionset
                //Entity enTargetSite = this.GetTargetSiteDetails(service,tracingService,((EntityReference)enCasePreImage.Attributes["rsa_classofbusinessphoneenqid"]).Id,
                //((OptionSetValue)enCasePreImage.Attributes["rsa_currentownerdivision"]).Value, ((OptionSetValue)enCasePreImage.Attributes["rsa_currentownersite"]).Value);

                string currentOwnerDivision = string.Empty;
                string currentOwnerSite = string.Empty;

                if (enCaseTarget.Attributes.Contains("rsa_currentownerdivision"))
                    currentOwnerDivision = enCaseTarget.Attributes["rsa_currentownerdivision"].ToString();
                else if (enNewCase.Attributes.Contains("rsa_currentownerdivision"))
                    currentOwnerDivision = enNewCase.Attributes["rsa_currentownerdivision"].ToString();

                if (enCaseTarget.Attributes.Contains("rsa_currentownersite"))
                    currentOwnerSite = enCaseTarget.Attributes["rsa_currentownersite"].ToString();
                else if (enNewCase.Attributes.Contains("rsa_currentownersite"))
                    currentOwnerSite = enNewCase.Attributes["rsa_currentownersite"].ToString();

                EntityCollection enTargetSiteCollection = null;
                if (enCaseTarget.Attributes.Contains("rsa_classofbusinessphoneenqid"))
                    enTargetSiteCollection = this.GetTargetSiteDetails(((EntityReference)enCaseTarget.Attributes["rsa_classofbusinessphoneenqid"]).Id);
                else if (enNewCase.Attributes.Contains("rsa_classofbusinessphoneenqid"))
                    enTargetSiteCollection = this.GetTargetSiteDetails(((EntityReference)enNewCase.Attributes["rsa_classofbusinessphoneenqid"]).Id);
                //EntityCollection enTargetSiteCollection = this.GetTargetSiteDetails(((EntityReference)enCasePreImage.Attributes["rsa_classofbusinessphoneenqid"]).Id);
                foreach (var en in enTargetSiteCollection.Entities)
                {
                    if (en.Attributes.Contains("rsa_periodcommencing") &&
                        en.Attributes.Contains("rsa_division") &&
                        en.Attributes.Contains("rsa_tradingsite") &&
                        en.Attributes.Contains("rsa_outcomedate") &&
                        en.Attributes.Contains("rsa_periodcommencing"))
                    {
                        if (currentOwnerDivision.Equals(en.FormattedValues["rsa_division"].Trim()) &&
                            currentOwnerSite.Equals(en.FormattedValues["rsa_tradingsite"].Trim()))
                        {
                            int dtOutComeYear = -1; //Sumanta
                            int dtOutComeMonth = -1;
                            if (enCaseTarget.Attributes.Contains("rsa_outcomedate"))
                            {
                                dtOutComeYear = ((DateTime)enCaseTarget.Attributes["rsa_outcomedate"]).Year;
                                dtOutComeMonth = ((DateTime)enCaseTarget.Attributes["rsa_outcomedate"]).Month;
                            }
                            else if (enNewCase.Attributes.Contains("rsa_outcomedate"))
                            {
                                dtOutComeYear = ((DateTime)enNewCase.Attributes["rsa_outcomedate"]).Year;
                                dtOutComeMonth = ((DateTime)enNewCase.Attributes["rsa_outcomedate"]).Month;
                            }

                            tracingService.Trace("dtOutComeYear: " + dtOutComeYear.ToString());
                            tracingService.Trace("dtOutComeMonth: " + dtOutComeMonth.ToString());
                            tracingService.Trace("((DateTime)en.Attributes[rsa_periodcommencing]).Year :" + ((DateTime)en.Attributes["rsa_periodcommencing"]).Year, ToString());
                            tracingService.Trace("((DateTime)en.Attributes[rsa_periodcommencing]).Month :" + ((DateTime)en.Attributes["rsa_periodcommencing"]).Month.ToString());
                            if (((DateTime)en.Attributes["rsa_periodcommencing"]).Year == dtOutComeYear &&
                                ((DateTime)en.Attributes["rsa_periodcommencing"]).Month == dtOutComeMonth)
                            {
                                enCaseTarget["rsa_sitetargetid"] = en["rsa_sitetargetid"];
                                tracingService.Trace("Populating rsa_sitetargetid");
                                break;
                            }
                        }
                    }


                }


            }
            else
            {
                tracingService.Trace("Unable to call GetTargetSiteDetails() due to validation failed");
                tracingService.Trace("rsa_classofbusinessphoneenqid exists target: " + enCaseTarget.Attributes.Contains("rsa_classofbusinessphoneenqid"));
                tracingService.Trace("rsa_currentownerdivision target: " + enCaseTarget.Attributes.Contains("rsa_currentownerdivision"));
                tracingService.Trace("rsa_currentownersite exists target: " + enCaseTarget.Attributes.Contains("rsa_currentownersite"));
                tracingService.Trace("rsa_outcomedate target: " + enCaseTarget.Attributes.Contains("rsa_outcomedate"));
                tracingService.Trace("rsa_classofbusinessphoneenqid exists new: " + enNewCase.Attributes.Contains("rsa_classofbusinessphoneenqid"));
                tracingService.Trace("rsa_currentownerdivision new: " + enNewCase.Attributes.Contains("rsa_currentownerdivision"));
                tracingService.Trace("rsa_currentownersite exists new: " + enNewCase.Attributes.Contains("rsa_currentownersite"));
                tracingService.Trace("rsa_outcomedate new: " + enNewCase.Attributes.Contains("rsa_outcomedate"));
            }
        }

        /// <summary>
        /// Set VEF and Survey flag based on business rules
        /// </summary>
        private void SetSurveyVEFFlag()
        {
            tracingService.Trace("Start: SetSurveyVEFFlag()");
            //if ((enCaseTarget.Attributes.Contains("rsa_transactiontypeid") && ((EntityReference)enCaseTarget.Attributes["rsa_transactiontypeid"]).Name.Equals(TRANS_TYPE_NEW_BUSINESS) &&
            //    enCaseTarget.Attributes.Contains("rsa_casetype") && ((EntityReference)enCaseTarget.Attributes["rsa_casetype"]).Name.Equals(SME_IMARKET_REFERRAL))
            //    ||
            //    (enNewCase.Attributes.Contains("rsa_transactiontypeid") && ((EntityReference)enNewCase.Attributes["rsa_transactiontypeid"]).Name.Equals(TRANS_TYPE_NEW_BUSINESS) &&
            //    enNewCase.Attributes.Contains("rsa_casetype") && ((EntityReference)enNewCase.Attributes["rsa_casetype"]).Name.Equals(SME_IMARKET_REFERRAL)))
            if (strTargetTransactionType.Equals(TRANS_TYPE_NEW_BUSINESS) && strTargetCaseType.Equals(SME_IMARKET_REFERRAL))
            {
                //Chandani : 12 Oct 2020 : Changed the message for the exception/error
                // tracingService.Trace("Exception: New Business SME - iMarket Referral cases are not accepted.");
                //throw new Exception("New Business SME - iMarket Referral cases are not accepted.");
                tracingService.Trace("Exception: New Business Transaction Type is not valid for SME - iMarket Refferal.");
                throw new Exception("New Business Transaction Type is not valid for SME - iMarket Refferal.");
            }
            RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon = new RSA.CSI.Plugins.Case.CaseCommon.CaseCommon(service, tracingService);

            string strRecordTypes = caseCommon.GetCustomLabel(CL_CASE_RECORD_TYPE_NAME_FOR_TRIGGER);
            tracingService.Trace("Get Custom Level CL_CASE_RECORD_TYPE_NAME_FOR_TRIGGER " + strRecordTypes);
            //if ((!String.IsNullOrEmpty(strRecordTypes) &&
            //    enCaseTarget.Attributes.Contains("rsa_casetype") &&
            //    strRecordTypes.Contains(((EntityReference)enCaseTarget.Attributes["rsa_casetype"]).Name) &&
            //    enCaseTarget.Attributes.Contains("rsa_policyid") &&
            //    ((enCaseTarget.Attributes.Contains("rsa_surveycaseopen") && (bool)enCaseTarget.Attributes["rsa_surveycaseopen"] == false) ||
            //    (enCaseTarget.Attributes.Contains("rsa_vefcaseopen") && (bool)enCaseTarget.Attributes["rsa_vefcaseopen"] == false)))
            //    ||
            //    (!String.IsNullOrEmpty(strRecordTypes) &&
            //    enNewCase.Attributes.Contains("rsa_casetype") &&
            //    strRecordTypes.Contains(((EntityReference)enNewCase.Attributes["rsa_casetype"]).Name) &&
            //    enNewCase.Attributes.Contains("rsa_policyid") &&
            //    ((enNewCase.Attributes.Contains("rsa_surveycaseopen") && (bool)enNewCase.Attributes["rsa_surveycaseopen"] == false) ||
            //    (enNewCase.Attributes.Contains("rsa_vefcaseopen") && (bool)enNewCase.Attributes["rsa_vefcaseopen"] == false))))
            if ((strRecordTypes.Contains(strTargetCaseType) &&
               enCaseTarget.Attributes.Contains("rsa_policyid") &&
               ((enCaseTarget.Attributes.Contains("rsa_surveycaseopen") && (bool)enCaseTarget.Attributes["rsa_surveycaseopen"] == false) ||
               (enCaseTarget.Attributes.Contains("rsa_vefcaseopen") && (bool)enCaseTarget.Attributes["rsa_vefcaseopen"] == false)))
               ||
                (strRecordTypes.Contains(strTargetCaseType) &&
               enNewCase.Attributes.Contains("rsa_policyid") &&
               ((enNewCase.Attributes.Contains("rsa_surveycaseopen") && (bool)enNewCase.Attributes["rsa_surveycaseopen"] == false) ||
               (enNewCase.Attributes.Contains("rsa_vefcaseopen") && (bool)enNewCase.Attributes["rsa_vefcaseopen"] == false))))
            {

                //var strSMESurvey = caseCommon.GetCustomLabel("CL_CASE_RECORD_TYPE_NAME_SME_SURVEY");
                //tracingService.Trace("Get Custom Level CL_CASE_RECORD_TYPE_NAME_SME_SURVEY " + strSMESurvey);
                //var strSMEVef = caseCommon.GetCustomLabel("CL_CASE_RECORD_TYPE_NAME_SME_VEF");
                //tracingService.Trace("Get Custom Level CL_CASE_RECORD_TYPE_NAME_SME_VEF " + strSMEVef);
                //var enColCase = this.GetAllCaseByPolicyId(((EntityReference)enCasePreImage.Attributes["rsa_policyid"]).Id);
                var strSMESurvey = string.Empty;// caseCommon.GetCustomLabel("CL_CASE_RECORD_TYPE_NAME_SME_SURVEY");
                var strSMEVef = string.Empty;// caseCommon.GetCustomLabel("CL_CASE_RECORD_TYPE_NAME_SME_VEF");
                caseCommon.GetSetSurveyVEFFlagCustomLabels(out strSMESurvey, out strSMEVef);
                tracingService.Trace("Get Custom Level CL_CASE_RECORD_TYPE_NAME_SME_SURVEY " + strSMESurvey);
                tracingService.Trace("Get Custom Level CL_CASE_RECORD_TYPE_NAME_SME_VEF " + strSMEVef);
                //var enColCase = this.GetAllCaseByPolicyId(((EntityReference)enCasePreImage.Attributes["rsa_policyid"]).Id);
                EntityCollection enColCase = null;
                if (enCaseTarget.Attributes.Contains("rsa_policyid") && enCaseTarget.Attributes["rsa_policyid"] != null)
                {
                    tracingService.Trace("enColCase target1");
                    enColCase = this.GetAllCaseByPolicyId(((EntityReference)enCaseTarget.Attributes["rsa_policyid"]).Id);
                    tracingService.Trace("enColCase target2");
                }
                else if (enNewCase.Attributes.Contains("rsa_policyid") && enNewCase.Attributes["rsa_policyid"] != null)
                {
                    tracingService.Trace("enColCase new1");
                    enColCase = this.GetAllCaseByPolicyId(((EntityReference)enNewCase.Attributes["rsa_policyid"]).Id);
                    tracingService.Trace("enColCase new2");
                }

                if (enColCase != null && enColCase.Entities.Count > 0)
                {
                    tracingService.Trace("Successfully fetched enColCase associated with policy id");
                    bool bIsSurvey = false;
                    bool bIsVEF = false;
                    tracingService.Trace("Successfully fetched policy(s) COUNT:" + enColCase.Entities.Count);
                    foreach (var en in enColCase.Entities)
                    {
                        //tracingService.Trace("Case Type name : " + ((EntityReference)en.Attributes["rsa_casetype"]).Name);
                        if ((en.Attributes.Contains("rsa_casetype") && strSMESurvey.Equals(((EntityReference)en.Attributes["rsa_casetype"]).Name)))
                        {
                            bIsSurvey = true;
                            enCaseTarget["rsa_surveycaseopen"] = true;//new OptionSetValue(1);
                            tracingService.Trace("Setting rsa_surveycaseopen to true");
                        }
                        else if ((en.Attributes.Contains("rsa_casetype") && strSMEVef.Equals(((EntityReference)en.Attributes["rsa_casetype"]).Name)))
                        {
                            bIsVEF = true;
                            enCaseTarget["rsa_vefcaseopen"] = true; //new OptionSetValue(1);
                            tracingService.Trace("Setting rsa_vefcaseopen to true");
                        }
                        else
                        {
                            tracingService.Trace("Failed to populate rsa_surveycaseopen and rsa_vefcaseopen");
                        }
                        if (bIsSurvey && bIsVEF) break;
                    }
                }
                else
                {
                    tracingService.Trace("Failed to fetch policy GetAllCaseByPolicyId()");
                }
            }
        }

        /// <summary>
        /// Get All cases by policy ids
        /// </summary>
        /// <param name="guidPolicyId"></param>
        /// <returns></returns>
        private EntityCollection GetAllCaseByPolicyId(Guid guidPolicyId)
        {
            var enColCase = new EntityCollection(null);
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' no-lock='true'>
                              <entity name='incident'>
                                <attribute name='title' />
                                <attribute name='ticketnumber' />
                                <attribute name='rsa_casetype' />
                                <attribute name='incidentid' />
                                <attribute name='caseorigincode' />
                                <order attribute='title' descending='false' />
                                <filter type='and'>
                                  <condition attribute='rsa_policyid' operator='eq' value='{0}' />
                                  <condition attribute='statecode' operator='eq' value='0' />
                                </filter>
                              </entity>
                            </fetch>";
            try
            {
                enColCase = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, guidPolicyId)));
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception in GetAllCaseByPolicyId: " + ex.Message);
                //throw new Exception("Exception in GetAllCaseByPolicyId: " + ex.Message);
            }
            return enColCase;
        }

        /// <summary>
        /// Call Create pipeline opportunity 
        /// </summary>
        private void CallCreatePipelineOpportunity()
        {
            try
            {
                tracingService.Trace("Within CallCreatePipelineOpportunity()");
                RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon = new RSA.CSI.Plugins.Case.CaseCommon.CaseCommon(service, tracingService);
                string enStatus = string.Empty;
                if (enCaseTarget.Attributes.Contains("rsa_status"))
                {
                    enStatus = caseCommon.GetNameByStatusId(((EntityReference)enCaseTarget.Attributes["rsa_status"]).Id);
                }
                else if (enNewCase.Attributes.Contains("rsa_status"))
                {
                    enStatus = caseCommon.GetNameByStatusId(((EntityReference)enNewCase.Attributes["rsa_status"]).Id);
                }
                if (((enCaseTarget.Attributes.Contains("rsa_status") &&
                    !String.IsNullOrEmpty(enStatus) &&
                    (enStatus.Equals("Not Taken Up") || enStatus.Equals("Lapsed")))
                    ||
                    (enNewCase.Attributes.Contains("rsa_status") &&
                    !String.IsNullOrEmpty(enStatus) &&
                    (enStatus.Equals("Not Taken Up") || enStatus.Equals("Lapsed")))))
                {
                    tracingService.Trace("Validation passed");
                    var guidOpportunityId = Guid.Empty;
                    if (enCaseTarget.Attributes.Contains("rsa_opportunityid"))
                    {
                        guidOpportunityId = ((EntityReference)enCaseTarget["rsa_opportunityid"]).Id;
                    }
                    else if (enNewCase.Attributes.Contains("rsa_opportunityid"))
                    {
                        guidOpportunityId = ((EntityReference)enNewCase["rsa_opportunityid"]).Id;
                    }
                    if (guidOpportunityId != Guid.Empty)
                    {
                        tracingService.Trace("fetched opportunity successfully");
                        var enOpportunity = this.GetOpportinityDetailsById(guidOpportunityId);
                        if (enOpportunity != null && enOpportunity.Attributes.Contains("rsa_createopportunityfornextyearifntu"))
                        {
                            tracingService.Trace("fetched opportunity successfully");
                            this.CreateOpportunity(enOpportunity);
                            tracingService.Trace("Opportunity created successfully");
                        }
                        else
                        {
                            tracingService.Trace("Unable to fetch opportunity");
                        }
                    }
                    else
                    {
                        tracingService.Trace("Opportunity doesn't exists.");
                    }
                }
                else
                {
                    tracingService.Trace("Validation failed during opportunity creation in CallCreatePipelineOpportunity()");
                    tracingService.Trace("Target rsa_status exsists ?)" + enCaseTarget.Attributes.Contains("rsa_status"));
                    tracingService.Trace("Target rsa_status rsa_opportunityid ?)" + enCaseTarget.Attributes.Contains("rsa_opportunityid"));
                    if (enCaseTarget.Attributes.Contains("rsa_status"))
                        tracingService.Trace("Target rsa_status = " + enCaseTarget.Attributes.Contains("rsa_status"));
                    tracingService.Trace("PreImage rsa_status exsists ?)" + enCaseTarget.Attributes.Contains("rsa_status"));
                    tracingService.Trace("PreImage rsa_status rsa_opportunityid ?)" + enCaseTarget.Attributes.Contains("rsa_opportunityid"));
                    if (enCaseTarget.Attributes.Contains("rsa_status"))
                        tracingService.Trace("PreImage rsa_status = " + enNewCase.Attributes.Contains("rsa_status"));
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception in CallCreatePipelineOpportunity():" + ex.Message);
            }
        }

        /// <summary>
        /// Get Opportunity details by Id
        /// </summary>
        /// <param name="guidOpportunityId"></param>
        /// <returns></returns>
        private Entity GetOpportinityDetailsById(Guid guidOpportunityId)
        {
            try
            {
                // Samiksha Dhakde: 08/09/2022
                // CR:2159 Hiding of currency symbol: Replacing currency field to decimal field: rsa_technicalprice to rsa_opptytechnicalprice_dc.
                ColumnSet columnSetOpportunity = new ColumnSet("name", "rsa_case", "rsa_policyid", "estimatedvalue", "rsa_stage", "rsa_targetpremium", "rsa_secondaryowner",
                "rsa_opportunityoutcomereason", "rsa_opportunityorigin", "rsa_opportunityname", "rsa_opportunitydescription", "rsa_isupdated",
                "rsa_closedate", "rsa_brokercontact", "rsa_amountvariance", "description", "rsa_createopportunityfornextyearifntu", "rsa_prospecttype", "totalamount",
                "rsa_lineofbusiness", "rsa_customer", "parentaccountid", "rsa_holdingagent", "rsa_holdingagentnametext", "rsa_brokercommitment", "rsa_potentialtowin",
                "rsa_dualenquiry", "rsa_leadteam", "rsa_winback", "rsa_existinginsurerid", "rsa_pandlid", "rsa_productid", "rsa_classofbusiness", "rsa_totalpremiumforinsurance",
                "rsa_opptytechnicalprice_dc", "rsa_contractdurationyears", "rsa_otherinsurer", "rsa_premiumlostfor", "rsa_secondaryowner");

                return service.Retrieve("opportunity", guidOpportunityId, columnSetOpportunity);
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetching opportunity" + ex.Message);
            }
            return null;
        }

        /// <summary>
        /// Create opportunity
        /// </summary>
        /// <param name="enOpportunity"></param>
        private void CreateOpportunity(Entity enOpportunity)
        {
            //var newOppty = Microsoft.Xrm.Client.EntityExtensions.Clone(enOpportunity, true);
            var newOppty = enOpportunity;
            newOppty.Id = Guid.Empty;
            newOppty.Attributes.Remove("opportunityid");
            //ewOppty["rsa_opportunitystage"] = new OptionSetValue((int)RSAEnum.OPS_Opportunity_rsa_stage.InView);
            Guid guidStageId = this.GetOpportunityStageIdByName("In View");
            if (guidStageId != Guid.Empty)
                newOppty["rsa_opportunitystage"] = new EntityReference("rsa_opportunitystage", guidStageId);
            newOppty["rsa_opportunityorigin"] = new OptionSetValue((int)RSAEnum.OPS_Opportunity_rsa_opportunityorigin.Pipeline);
            if (enOpportunity.Attributes.Contains("rsa_closedate"))
                newOppty["rsa_closedate"] = ((DateTime)enOpportunity["rsa_closedate"]).AddYears(1);
            newOppty["rsa_createopportunityfornextyearifntu"] = false;
            newOppty["rsa_isupdated"] = false;
            try
            {
                service.Create(enOpportunity);
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while creating opportunity in CreateOpportunity(): " + ex.Message);
            }
        }


        /// <summary>
        /// Get Opportunity stage id by name
        /// </summary>
        /// <param name="strStageName"></param>
        /// <returns></returns>
        private Guid GetOpportunityStageIdByName(String strStageName)
        {
            Guid guidStageId = Guid.Empty;
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' no-lock='true'>
                                  <entity name='rsa_opportunitystage'>
                                    <attribute name='rsa_name' />
                                    <attribute name='createdon' />
                                    <attribute name='rsa_lineofbusiness' />
                                    <attribute name='rsa_opportunitystageid' />
                                    <order attribute='rsa_name' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='rsa_name' operator='eq' value='{0}' />
                                    </filter>
                                  </entity>
                                </fetch>";
            try
            {
                var enColOpptyStage = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, strStageName)));
                if (enColOpptyStage != null && enColOpptyStage.Entities.Count > 0)
                    guidStageId = enColOpptyStage.Entities[0].Id;
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while creating opportunity in CreateOpportunity(): " + ex.Message);
            }
            return guidStageId;
        }

        /// <summary>
        /// Set Case Receive date
        /// </summary>
        private void SetCaseReceivedDate()
        {
            tracingService.Trace("Within SetCaseReceivedDate() - Started");
            // Samiksha Dhakde: INC2291363: Case received date is not getting saved: Update or condition to and
            if ((!enCaseTarget.Attributes.Contains("rsa_casereceiveddate") && !enNewCase.Attributes.Contains("rsa_casereceiveddate")) && enNewCase.Attributes.Contains("createdon"))
            {
                enCaseTarget["rsa_casereceiveddate"] = enNewCase["createdon"];
                tracingService.Trace("Successufully populated enCaseTarget[rsa_casereceiveddate]");
            }
            //else if (!enNewCase.Attributes.Contains("rsa_casereceiveddate"))
            //{
            //    enCaseTarget["rsa_casereceiveddate"] = enNewCase["createdon"];
            //    tracingService.Trace("Successufully populated enCaseTarget[rsa_casereceiveddate]");
            //}
            if ((enCaseTarget.Attributes.Contains("rsa_classofbusinessphoneenqid") &&
                enCaseTarget.Attributes["rsa_classofbusinessphoneenqid"] != null &&
                enCaseTarget.Attributes.Contains("rsa_account") && enCaseTarget.Attributes["rsa_account"] != null)
                ||
                (enNewCase.Attributes.Contains("rsa_classofbusinessphoneenqid") &&
                enNewCase.Attributes["rsa_classofbusinessphoneenqid"] != null &&
                enNewCase.Attributes.Contains("rsa_account") && enNewCase.Attributes["rsa_account"] != null))
            {
                RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon = new RSA.CSI.Plugins.Case.CaseCommon.CaseCommon(service, tracingService);
                tracingService.Trace("Successufully populated enCaseTarget[rsa_casereceiveddate]");
                Entity enAgencyHandler = null;
                if (enCaseTarget.Attributes.Contains("rsa_classofbusinessphoneenqid") &&
                enCaseTarget.Attributes.Contains("rsa_account"))
                {
                    enAgencyHandler = this.GetAgencyHandlerDetails(((EntityReference)enCaseTarget.Attributes["rsa_account"]).Id, ((EntityReference)enCaseTarget.Attributes["rsa_classofbusinessphoneenqid"]).Id);
                }
                else if (enNewCase.Attributes.Contains("rsa_classofbusinessphoneenqid") &&
                enNewCase.Attributes.Contains("rsa_account"))
                {
                    enAgencyHandler = this.GetAgencyHandlerDetails(((EntityReference)enNewCase.Attributes["rsa_account"]).Id, ((EntityReference)enNewCase.Attributes["rsa_classofbusinessphoneenqid"]).Id);
                }
                //var enAgencyHandler = this.GetAgencyHandlerDetails(((EntityReference)enCasePreImage.Attributes["rsa_account"]).Id, ((EntityReference)enCasePreImage.Attributes["rsa_classofbusinessphoneenqid"]).Id);
                if (enAgencyHandler != null &&
                    enAgencyHandler.Attributes.Contains("rsa_tradingsite"))
                {
                    tracingService.Trace("Successufully fetched rsa_tradingsite");
                    Entity enTradingThreshol = null;
                    if (enCaseTarget.Attributes.Contains("rsa_classofbusinessphoneenqid"))
                    {
                        enTradingThreshol = this.GetTradingThresholdDetails(((EntityReference)enCaseTarget.Attributes["rsa_classofbusinessphoneenqid"]).Id, ((OptionSetValue)enAgencyHandler.Attributes["rsa_tradingsite"]).Value);
                    }
                    else if (enNewCase.Attributes.Contains("rsa_classofbusinessphoneenqid"))
                    {
                        enTradingThreshol = this.GetTradingThresholdDetails(((EntityReference)enNewCase.Attributes["rsa_classofbusinessphoneenqid"]).Id, ((OptionSetValue)enAgencyHandler.Attributes["rsa_tradingsite"]).Value);
                    }
                    //var enTradingThreshol = this.GetTradingThresholdDetails(((EntityReference)enCasePreImage.Attributes["rsa_classofbusinessphoneenqid"]).Id, ((OptionSetValue)enAgencyHandler.Attributes["rsa_tradingsite"]).Value);
                    //if ((enTradingThreshol != null && enTradingThreshol.Attributes.Contains("rsa_thresholdvalue") &&
                    //    enCaseTarget.Attributes.Contains("rsa_targetpremium") &&
                    //    ((Money)enCaseTarget.Attributes["rsa_targetpremium"]).Value >= ((Money)enTradingThreshol.Attributes["rsa_thresholdvalue"]).Value &&
                    //    enCaseTarget.Attributes.Contains("rsa_casetype") &&
                    //    ((EntityReference)enCaseTarget.Attributes["rsa_casetype"]).Name.Equals(CASE_TYPE_NEW_BUSINESS))
                    //    ||
                    //    (enTradingThreshol != null && enTradingThreshol.Attributes.Contains("rsa_thresholdvalue") &&
                    //    enNewCase.Attributes.Contains("rsa_targetpremium") &&
                    //    ((Money)enNewCase.Attributes["rsa_targetpremium"]).Value >= ((Money)enTradingThreshol.Attributes["rsa_thresholdvalue"]).Value &&
                    //    enNewCase.Attributes.Contains("rsa_casetype") &&
                    //    ((EntityReference)enNewCase.Attributes["rsa_casetype"]).Name.Equals(CASE_TYPE_NEW_BUSINESS)))
                    if ((enTradingThreshol != null && enTradingThreshol.Attributes.Contains("rsa_thresholdvalue") &&
                       enCaseTarget.Attributes.Contains("rsa_targetpremium") &&
                       ((Money)enCaseTarget.Attributes["rsa_targetpremium"]).Value >= ((Money)enTradingThreshol.Attributes["rsa_thresholdvalue"]).Value &&
                       enCaseTarget.Attributes.Contains("rsa_casetype") &&
                       strTargetCaseType.Equals(CASE_TYPE_NEW_BUSINESS))
                       ||
                       (enTradingThreshol != null && enTradingThreshol.Attributes.Contains("rsa_thresholdvalue") &&
                       enNewCase.Attributes.Contains("rsa_targetpremium") &&
                       ((Money)enNewCase.Attributes["rsa_targetpremium"]).Value >= ((Money)enTradingThreshol.Attributes["rsa_thresholdvalue"]).Value &&
                       enNewCase.Attributes.Contains("rsa_casetype") &&
                       strTargetCaseType.Equals(CASE_TYPE_NEW_BUSINESS).Equals(CASE_TYPE_NEW_BUSINESS)))
                    {
                        tracingService.Trace("Successufully fetched for CASE_TYPE_NEW_BUSINESS");
                        if ((!enCaseTarget.Attributes.Contains("rsa_caseinitialassignedtosite") &&
                            !enCaseTarget.Attributes.Contains("rsa_dummyfieldfornb"))
                            ||
                            (!enNewCase.Attributes.Contains("rsa_caseinitialassignedtosite") &&
                            !enNewCase.Attributes.Contains("rsa_dummyfieldfornb")))
                            //&& enTradingThreshol.Attributes.Contains("rsa_tradingsite")) TODO
                            tracingService.Trace("rsa_tradingsite not available in Trading Threshold Entity so skipped that condition");

                        {
                            tracingService.Trace("rsa_tradingsite not available in Trading Threshold Entity");
                            // TODO : rsa_tradingsite not available in Trading Threshold Entity
                            //enCaseTarget["rsa_caseinitialassignedtosite"] = enTradingThreshol["rsa_tradingsite"];
                            tracingService.Trace("Successufully populated for rsa_tradingsite");
                        }
                        if (enAgencyHandler.Attributes.Contains("rsa_trader"))
                        {
                            tracingService.Trace("Successufully fetched rsa_trader");
                            if ((!enCaseTarget.Attributes.Contains("rsa_caseinitialassignedtosite") &&
                           !enCaseTarget.Attributes.Contains("rsa_dummyfieldfornb"))
                           ||
                           (!enNewCase.Attributes.Contains("rsa_caseinitialassignedtosite") &&
                           !enNewCase.Attributes.Contains("rsa_dummyfieldfornb")))
                            {
                                tracingService.Trace("Successufully fetched rsa_caseinitialassignedtosite and rsa_dummyfieldfornb");
                                var enUser = caseCommon.GetUserDetails(((EntityReference)enAgencyHandler.Attributes["rsa_trader"]).Id);
                                if (enUser != null && enUser.Attributes.Contains("fullname"))
                                {
                                    enCaseTarget["rsa_initialassignedtousers"] = enUser.Attributes["fullname"];
                                    tracingService.Trace("Successufully fetched enUser.Id->rsa_trader");
                                }
                                if ((enUser != null && !enCaseTarget.Attributes.Contains("rsa_initialassignedtousers") && !enCaseTarget.Attributes.Contains("rsa_dummyfieldfornb"))
                                    ||
                                    (enUser != null && !enNewCase.Attributes.Contains("rsa_initialassignedtousers") && !enNewCase.Attributes.Contains("rsa_dummyfieldfornb")))
                                {
                                    tracingService.Trace("Successfully fetched User");
                                    if (enUser.Attributes.Contains("rsa_division"))
                                        enCaseTarget["rsa_caseinitialassignedtodivision"] = enUser.Attributes["rsa_division"];
                                    //if (enUser.Attributes.Contains("rsa_userteamlevel2"))
                                    //enCaseTarget["rsa_caseinitialassignedtoteam"] = enUser.Attributes["rsa_userteamlevel2"]; // TODO : Datatype mismatch: rsa_userteamlevel2- Lookup and rsa_caseinitialassignedtoteam- Optionset
                                    tracingService.Trace("Datatype mismatch: rsa_userteamlevel2- Lookup and rsa_caseinitialassignedtoteam- Optionset");
                                    tracingService.Trace("Completed fetched User");
                                }
                            }
                        }
                        if (enCaseTarget.Attributes.Contains("rsa_opportunityid") || enNewCase.Attributes.Contains("rsa_opportunityid"))
                        {
                            enCaseTarget["rsa_dummyfieldfornb"] = "Inserting a Dummy value";
                            tracingService.Trace("rsa_dummyfieldfornb 0");
                        }
                    }
                    else
                    {    //// Commented code for rsa_opshandlersite as fix of 2647 - Mofified on- 11/03/2022 - Nida
                       
                        tracingService.Trace("Unable to fetched for CASE_TYPE_NEW_BUSINESS");
                        if ((!enCaseTarget.Attributes.Contains("rsa_caseinitialassignedtosite") &&
                            !enCaseTarget.Attributes.Contains("rsa_dummyfieldfornb") //&&
                          /*  enTradingThreshol.Attributes.Contains("rsa_opshandlersite")*/)
                            ||
                            (!enNewCase.Attributes.Contains("rsa_caseinitialassignedtosite") &&
                            !enNewCase.Attributes.Contains("rsa_dummyfieldfornb") //&&
                            /*enTradingThreshol.Attributes.Contains("rsa_opshandlersite")*/)) // TODO : rsa_opshandlersite is missing
                        {
                           // enCaseTarget["rsa_caseinitialassignedtosite"] = enTradingThreshol["rsa_opshandlersite"];
                            //tracingService.Trace("Successufully populated for rsa_opshandlersite");
                        }
                        if (enAgencyHandler.Attributes.Contains("rsa_opshandler"))
                        {
                            tracingService.Trace("Successufully fetched rsa_opshandler");
                            if ((!enCaseTarget.Attributes.Contains("rsa_caseinitialassignedtosite") &&
                           !enCaseTarget.Attributes.Contains("rsa_dummyfieldfornb"))
                           ||
                           (!enNewCase.Attributes.Contains("rsa_caseinitialassignedtosite") &&
                           !enNewCase.Attributes.Contains("rsa_dummyfieldfornb")))
                            {
                                tracingService.Trace("Successufully fetched rsa_caseinitialassignedtosite and rsa_dummyfieldfornb 1");
                                var enUser = caseCommon.GetUserDetails(((EntityReference)enAgencyHandler.Attributes["rsa_opshandler"]).Id);
                                if (enUser != null && enUser.Attributes.Contains("fullname"))
                                {
                                    enCaseTarget["rsa_initialassignedtousers"] = enUser.Attributes["fullname"];
                                    tracingService.Trace("Successufully fetched enUser.Id->rsa_opshandler");
                                }
                                if ((enUser != null && !enCaseTarget.Attributes.Contains("rsa_initialassignedtousers") && !enCaseTarget.Attributes.Contains("rsa_dummyfieldfornb"))
                                    ||
                                    (enUser != null && !enNewCase.Attributes.Contains("rsa_initialassignedtousers") && !enNewCase.Attributes.Contains("rsa_dummyfieldfornb")))
                                {
                                    tracingService.Trace("Successfully fetched User 1");
                                    if (enUser.Attributes.Contains("rsa_division"))
                                        enCaseTarget["rsa_caseinitialassignedtodivision"] = enUser.Attributes["rsa_division"];
                                    //if (enUser.Attributes.Contains("rsa_userteamlevel2"))
                                    //  enCaseTarget["rsa_caseinitialassignedtoteam"] = enUser.Attributes["rsa_userteamlevel2"]; // TODO : Datatype mismatch: rsa_userteamlevel2- Lookup and rsa_caseinitialassignedtoteam- Optionset
                                    tracingService.Trace("Datatype mismatch: rsa_userteamlevel2- Lookup and rsa_caseinitialassignedtoteam- Optionset");
                                    tracingService.Trace("Completed fetched User 1");
                                }
                            }
                        }
                        if (enCaseTarget.Attributes.Contains("rsa_opportunityid") || enCaseTarget.Attributes.Contains("rsa_opportunityid"))
                        {
                            enCaseTarget["rsa_dummyfieldfornb"] = "Inserting a Dummy value";
                            tracingService.Trace("rsa_dummyfieldfornb 1");
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Get trading threshold details
        /// </summary>
        /// <param name="guidCOBId"></param>
        /// <param name="intOffice"></param>
        /// <returns></returns>
        private Entity GetTradingThresholdDetails(Guid guidCOBId, int intOffice)
        {
            Entity enTradingThreshol = null;
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' no-lock='true'>
                              <entity name='rsa_tradingthreshold'>
                                <attribute name='rsa_name' />
                                <attribute name='rsa_classofbusiness' />
                                <attribute name='rsa_tradingthresholdid' />
                                <attribute name='rsa_thresholdvalue' />
                                <order attribute='rsa_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='rsa_classofbusiness' operator='eq' value='{0}' />
                                  <condition attribute='rsa_office' operator='eq' value='{1}' />
                                </filter>
                              </entity>
                            </fetch>";
            try
            {
                var enColTrdThreshold = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, guidCOBId, intOffice)));
                if (enColTrdThreshold != null && enColTrdThreshold.Entities.Count > 0)
                    enTradingThreshol = enColTrdThreshold.Entities[0];
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception in GetAgencyHandler: " + ex.Message);
                //throw new Exception("Exception in GetAgencyHandler: " + ex.Message);
            }
            return enTradingThreshol;
        }

        /// <summary>
        /// Get Agency Handler
        /// </summary>
        /// <param name="guidAccountId"></param>
        /// <param name="guidCOBId"></param>
        /// <returns></returns>
        private Entity GetAgencyHandlerDetails(Guid guidAccountId, Guid guidCOBId)
        {
            Entity enAgencyHandler = null;

            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' no-lock='true'>
                              <entity name='rsa_agencyhandler'>
                                <attribute name='rsa_agencyhandlerid' />
                                <attribute name='rsa_name' />
                                <attribute name='createdon' />
                                <attribute name='rsa_tradingsite' />
                                <attribute name='rsa_tradingcentre' />
                                <attribute name='rsa_trader' />
                                <attribute name='rsa_opshandler' />
                                <attribute name='rsa_pl' />
                                <attribute name='rsa_classofbusiness' />
                                <attribute name='rsa_agency' />
                                <order attribute='rsa_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='rsa_classofbusiness' operator='eq' value='{0}'/>
                                  <condition attribute='rsa_agency' operator='eq' value='{1}'/>
                                </filter>
                              </entity>
                            </fetch>";
            try
            {
                var enColAgencyHandler = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, guidCOBId, guidAccountId)));
                if (enColAgencyHandler != null && enColAgencyHandler.Entities.Count > 0)
                    enAgencyHandler = enColAgencyHandler.Entities[0];
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception in GetAgencyHandler: " + ex.Message);
                //throw new Exception("Exception in GetAgencyHandler: " + ex.Message);
            }
            return enAgencyHandler;
        }


        #region Set MTA
        internal void SetMTACaseTeam()
        {
            //rsa_dummyfieldformta
            tracingService.Trace("Calling SetRequestType(rsa_dummyfieldformta) for SetMTACaseTeam()");
            this.SetRequestType("rsa_dummyfieldformta");
            tracingService.Trace("Completed SetRequestType(rsa_dummyfieldformta) for SetMTACaseTeam()");
        }
        #endregion Set MTA

        #region Set RR
        internal void SetRRCaseTeam()
        {
            //rsa_dummyfieldforrr
            tracingService.Trace("Calling SetRequestType(rsa_dummyfieldforrr) for SetRRCaseTeam()");
            this.SetRequestType("rsa_dummyfieldforrr");
            tracingService.Trace("Completed SetRequestType(rsa_dummyfieldforrr) for SetRRCaseTeam()");
        }
        #endregion Set RR

        #region Set Promise
        internal void SetPromise()
        {
            ////"rsa_dummyfieldforrenewals" 
            tracingService.Trace("Calling SetRequestType(rsa_dummyfieldforrenewals) for SetPromise()");
            this.SetApplyR90Conditions();
            tracingService.Trace("Completed SetRequestType(rsa_dummyfieldforrenewals) for SetPromise()");
        }
        #endregion Set Promise

        #region Set Servicing
        /// <summary>
        /// This class caters to the cases of record type servicing, we stamp the intial 
        /// assigned fields and the related broker and customer from the attached policy
        /// </summary>
        internal void SetServicing()
        {
            //rsa_dummyfieldforquery
            tracingService.Trace("Calling SetRequestType(rsa_dummyfieldforquery) for SetServicing()");
            this.SetRequestType("rsa_dummyfieldforquery");
            tracingService.Trace("Completed SetRequestType(rsa_dummyfieldforquery) for SetServicing()");
        }
        #endregion Set Servicing

        private void SetRequestType(string strDummyFieldName)
        {
            RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon = new RSA.CSI.Plugins.Case.CaseCommon.CaseCommon(service, tracingService);
            if (enCaseTarget.Attributes.Contains("rsa_policyid") || enNewCase.Attributes.Contains("rsa_policyid"))
            {
                Guid guidPolicyId = Guid.Empty;
                if (enCaseTarget.Attributes.Contains("rsa_policyid"))
                    guidPolicyId = ((EntityReference)enCaseTarget.Attributes["rsa_policyid"]).Id;
                else if (enNewCase.Attributes.Contains("rsa_policyid"))
                    guidPolicyId = ((EntityReference)enNewCase.Attributes["rsa_policyid"]).Id;
                //Guid guidPolicyId = ((EntityReference)enCasePreImage.Attributes["rsa_policyid"]).Id;
                Entity enPolicy = caseCommon.GetPolicyDetails(guidPolicyId);
                if (enPolicy != null)
                {
                    tracingService.Trace("successfully fetched Policy");
                    if ((enCaseTarget.Attributes.Contains("rsa_account") && (enPolicy.Attributes.Contains("rsa_broker") &&
            ((EntityReference)enCaseTarget.Attributes["rsa_account"]).Id != ((EntityReference)(enPolicy.Attributes["rsa_broker"])).Id))
            ||
            (enNewCase.Attributes.Contains("rsa_account") && (enPolicy.Attributes.Contains("rsa_broker") &&
            ((EntityReference)enNewCase.Attributes["rsa_account"]).Id != ((EntityReference)(enPolicy.Attributes["rsa_broker"])).Id)))
                    {
                        tracingService.Trace("rsa_account");
                        enCaseTarget["rsa_account"] = new EntityReference("account", ((EntityReference)(enPolicy.Attributes["rsa_broker"])).Id);
                    }
                    else if (!enCaseTarget.Attributes.Contains("rsa_account") || !enNewCase.Attributes.Contains("rsa_account"))
                    {
                        tracingService.Trace("rsa_account 1");
                        if (enPolicy.Attributes.Contains("rsa_account") && enPolicy.GetAttributeValue<EntityReference>("rsa_broker") != null)
                        {
                            enCaseTarget["rsa_account"] = new EntityReference("account", ((EntityReference)(enPolicy.Attributes["rsa_broker"])).Id);
                        }
                    }
                    if ((enCaseTarget.Attributes.Contains("rsa_customerrsa") && (enPolicy.Attributes.Contains("rsa_customer") &&
            ((EntityReference)enCaseTarget.Attributes["rsa_customerrsa"]).Id != ((EntityReference)(enPolicy.Attributes["rsa_customer"])).Id))
            ||
            (enNewCase.Attributes.Contains("rsa_customerrsa") && (enPolicy.Attributes.Contains("rsa_customer") &&
            ((EntityReference)enNewCase.Attributes["rsa_customerrsa"]).Id != ((EntityReference)(enPolicy.Attributes["rsa_customer"])).Id)))
                    {
                        tracingService.Trace("rsa_customerrsa");
                        enCaseTarget["rsa_customerrsa"] = new EntityReference("rsa_customer", ((EntityReference)(enPolicy.Attributes["rsa_customer"])).Id);
                    }
                    else if (!enCaseTarget.Attributes.Contains("rsa_customerrsa") || !enNewCase.Attributes.Contains("rsa_customerrsa"))
                    {
                        tracingService.Trace("rsa_customerrsa1");
                        if (enPolicy.Attributes.Contains("rsa_customer") && enPolicy.GetAttributeValue<EntityReference>("rsa_customer") != null)
                        {
                            enCaseTarget["rsa_customerrsa"] = new EntityReference("rsa_customer", ((EntityReference)(enPolicy.Attributes["rsa_customer"])).Id);
                        }
                    }
                    //Stamping of the Initial Assigned to fields for reporting purpose
                    if ((!enCaseTarget.Attributes.Contains("rsa_caseinitialassignedtosite") && !enCaseTarget.Attributes.Contains(strDummyFieldName) &&
                                        enPolicy.Attributes.Contains("rsa_operationshandlingsite"))
                                        ||
                                        (!enNewCase.Attributes.Contains("rsa_caseinitialassignedtosite") && !enNewCase.Attributes.Contains(strDummyFieldName) &&
                                        enPolicy.Attributes.Contains("rsa_operationshandlingsite")))
                    {
                        tracingService.Trace("rsa_customerrsa1");
                        enCaseTarget["rsa_caseinitialassignedtosite"] = new OptionSetValue(((OptionSetValue)(enPolicy.Attributes["rsa_operationshandlingsite"])).Value);
                    }
                    if (enPolicy.Attributes.Contains("rsa_policyhandler"))
                    {
                        tracingService.Trace("rsa_policyhandler");
                        if ((!enCaseTarget.Attributes.Contains("rsa_initialassignedtousers") && !enCaseTarget.Attributes.Contains(strDummyFieldName))
                            || (!enNewCase.Attributes.Contains("rsa_initialassignedtousers") && !enNewCase.Attributes.Contains(strDummyFieldName)))
                        {
                            tracingService.Trace("rsa_initialassignedtousers");
                            enCaseTarget["rsa_initialassignedtousers"] = ((EntityReference)(enPolicy.Attributes["rsa_policyhandler"])).Name;
                            Entity enUser = caseCommon.GetUserDetails(((EntityReference)(enPolicy.Attributes["rsa_policyhandler"])).Id);
                            if (enUser != null)
                            {
                                if (enUser.Attributes.Contains("rsa_division"))
                                    enCaseTarget["rsa_caseinitialassignedtodivision"] = enUser.Attributes["rsa_division"];
                                //TODO: rsa_caseinitialassignedtoteam is an OptionSet
                                //TODO: rsa_userteamlevel2 is an Lookup
                                //if (enUser.Attributes.Contains("rsa_userteamlevel2"))
                                //enCase["rsa_caseinitialassignedtoteam"] = enUser.Attributes["rsa_userteamlevel2"];
                            }
                        }
                    }
                    enCaseTarget[strDummyFieldName] = "Inserting a Dummy Value";
                    tracingService.Trace("Setting rsa_dummyfieldforrenewals 0");
                }
            }
        }


        /// <summary>
        /// Set R90 Conditions
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="enCase"></param>
        private void SetApplyR90Conditions()
        {
            tracingService.Trace("Within and started SetApplyR90Conditions()");
            Guid guidCOB = Guid.Empty;
            string strCOBName = string.Empty;
            var strAccountBranch = string.Empty;
            var intAccountBranch = -1;
            var strCOB = string.Empty;
            var bRuleBranchCheck = false;
            var bRuleCOBCheck = false;
            var bRuleDistributionCategoryAgency = false;
            var bRuleDistributionAgencySegment = false;
            var bRuleNetwork = false;
            var enColTradingThresold = new EntityCollection(null);
            if (enCaseTarget.Attributes.Contains("rsa_opportunityid") || enNewCase.Attributes.Contains("rsa_opportunityid"))
            {
                RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon = new RSA.CSI.Plugins.Case.CaseCommon.CaseCommon(service, tracingService);
                var strR90COB = string.Empty;// caseCommon.GetCustomLabel(service, tracingService, "R_90_CoBs").Trim();
                var strR90DistributionCategory = string.Empty;//caseCommon.GetCustomLabel(service, tracingService, "R_90_Distribution_Categories").Trim();
                var strR90DistributionSegment = string.Empty;//caseCommon.GetCustomLabel(service, tracingService, "R_90_Distribution_Subsegments").Trim();
                var strR90Network = string.Empty;//caseCommon.GetCustomLabel(service, tracingService, "R_90_Network").Trim();
                var strR90Branchs = string.Empty;//caseCommon.GetCustomLabel(service, tracingService, "R_90_broker_branches").Trim();
                caseCommon.GetR90CustomLables(out strR90COB, out strR90DistributionCategory,
                    out strR90DistributionSegment, out strR90Network, out strR90Branchs);
                tracingService.Trace("R_90_CoBs:{0}||R_90_Distribution_Categories:{1}||R_90_Distribution_Subsegments:{2}||R_90_Network:{3}||R_90_broker_branches:{4}", strR90COB, strR90DistributionCategory, strR90DistributionSegment, strR90Network, strR90Branchs);
                tracingService.Trace("Get Opportunity");
                Entity enOpptyAndPolicy = null;
                if (enCaseTarget.Attributes.Contains("rsa_opportunityid") && enCaseTarget.Attributes["rsa_opportunityid"] != null)
                    enOpptyAndPolicy = caseCommon.GetOpptyAndPolicyDetails(((EntityReference)enCaseTarget.Attributes["rsa_opportunityid"]).Id);
                else if (enNewCase.Attributes.Contains("rsa_opportunityid") && enNewCase.Attributes["rsa_opportunityid"] != null)
                    enOpptyAndPolicy = caseCommon.GetOpptyAndPolicyDetails(((EntityReference)enNewCase.Attributes["rsa_opportunityid"]).Id);
                //var enOpptyAndPolicy = caseCommon.GetOpptyAndPolicyDetails(((EntityReference)enCasePreImage.Attributes["rsa_opportunityid"]).Id);
                if (enOpptyAndPolicy != null)
                {
                    tracingService.Trace("Successfully fetched Opportunity");
                    // Get Account details
                    if (enOpptyAndPolicy.Attributes.Contains("pol.rsa_classofbusiness"))
                    {
                        strCOB = ((EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_classofbusiness"]).Value).Name.Trim();
                        guidCOB = ((EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_classofbusiness"]).Value).Id;
                        bRuleCOBCheck = strR90COB.Contains(strCOB);
                        tracingService.Trace("bRuleCOBCheck:" + bRuleCOBCheck.ToString());
                        if (enOpptyAndPolicy.Attributes.Contains("pol.rsa_broker"))
                        {
                            var enBroker = service.Retrieve("account", ((EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_broker"]).Value).Id, new ColumnSet("rsa_salesteam", "rsa_branch", "name", "rsa_distributioncategoryagency", "rsa_distributionsubsegment", "rsa_network"));
                            if (enBroker != null && enBroker.Attributes.Contains("rsa_branch") && bRuleCOBCheck)
                            {
                                tracingService.Trace("Successfully fetched broker");
                                strAccountBranch = enBroker.FormattedValues["rsa_branch"].Trim();
                                intAccountBranch = ((OptionSetValue)enBroker["rsa_branch"]).Value;
                                bRuleBranchCheck = strR90Branchs.Contains(strAccountBranch);
                                tracingService.Trace("Branch from strR90Branchs " + strR90Branchs);
                                tracingService.Trace("Branch Name from Broker " + strAccountBranch);
                                tracingService.Trace("Branch Id from Broker " + intAccountBranch);
                                tracingService.Trace("guidCOB " + guidCOB.ToString());
                                if (bRuleBranchCheck)
                                {
                                    enColTradingThresold = caseCommon.GetTradingThresoldDetails(guidCOB, intAccountBranch);
                                    tracingService.Trace("Successfully fetched GetTradingThresoldDetails");
                                    //TODO - the below fields are calculated fields in D365 and cannot be accessed in plugins, need discussion
                                    // Need to write for extraction
                                    if (enBroker.Attributes.Contains("rsa_distributioncategoryagency") &&
                                        strR90DistributionCategory.Contains(enBroker.Attributes["rsa_distributioncategoryagency"].ToString()))
                                    {
                                        bRuleDistributionCategoryAgency = true;
                                    }
                                    if (enBroker.Attributes.Contains("rsa_distributionsubsegment") &&
                                        strR90DistributionSegment.Contains(enBroker.Attributes["rsa_distributionsubsegment"].ToString()))
                                    {
                                        bRuleDistributionAgencySegment = true;
                                    }
                                    if (enBroker.Attributes.Contains("rsa_network") &&
                                        strR90Network.Contains(enBroker.Attributes["rsa_network"].ToString()))
                                    {
                                        bRuleNetwork = true;
                                    }
                                    if (bRuleDistributionCategoryAgency || bRuleDistributionAgencySegment || bRuleNetwork)
                                    {
                                        tracingService.Trace("Iterating threasold");
                                        foreach (var enTh in enColTradingThresold.Entities)
                                        {

                                            if (enTh.Attributes.Contains("rsa_classofbusiness") && enTh.Attributes.Contains("rsa_office") &&
                                                enTh.Attributes.Contains("rsa_vettingthreshold") && enOpptyAndPolicy.Attributes.Contains("pol.rsa_premium"))
                                            {
                                                if (intAccountBranch == ((OptionSetValue)enTh["rsa_office"]).Value &&
                                                    guidCOB == ((EntityReference)enTh.Attributes["rsa_classofbusiness"]).Id &&
                                                    ((Money)enTh.Attributes["rsa_vettingthreshold"]).Value < ((Money)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_premium"]).Value).Value)
                                                {
                                                    enCaseTarget["rsa_applyr90conditions"] = true; // set to true
                                                    tracingService.Trace("rsa_applyr90conditions is true");
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        tracingService.Trace("(bRuleDistributionCategoryAgency || bRuleDistributionAgencySegment || bRuleNetwork- FALSE");
                                    }
                                }
                                else
                                {
                                    tracingService.Trace("branch doesn't exist");
                                }
                            }
                            else
                            {
                                tracingService.Trace("Unable to fetched broker details,branch etc.");
                            }
                        }
                        else
                        {
                            tracingService.Trace("Unable to fetched broker");
                        }
                    }
                    else
                    {
                        tracingService.Trace("Unable to fetched CoB");
                    }
                }
                else
                {
                    tracingService.Trace("Unable to fetched Opportunity");
                }
                tracingService.Trace("Calling SetPromiseConditions");
                if (enOpptyAndPolicy != null)
                {
                    tracingService.Trace("Calling SetPromiseConditions");
                    this.SetPromiseConditions(service, tracingService, enCaseTarget, enNewCase, enOpptyAndPolicy, enColTradingThresold);
                }
                else
                    tracingService.Trace("enOpptyAndPolicy is null");
                tracingService.Trace("Complated SetPromiseConditions");
            }
            tracingService.Trace("End SetApplyR90Conditions()");
        }
        /// <summary>
        /// Polulate Case Promise fields with other fields as well
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="enCase"></param>
        /// <param name="enOpptyAndPolicy"></param>
        /// <param name="enBroker"></param>
        /// <param name="enColTradingThresold"></param>
        private void SetPromiseConditions(IOrganizationService service, ITracingService tracingService, Entity enCaseTarget, Entity enNewCase, Entity enOpptyAndPolicy, EntityCollection enColTradingThresold)
        {
            tracingService.Trace("Within SetPromiseConditions()");
            RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon = new RSA.CSI.Plugins.Case.CaseCommon.CaseCommon(service, tracingService);
            tracingService.Trace("rsa_account target : " + enCaseTarget.Attributes.Contains("rsa_account"));
            tracingService.Trace("rsa_account new : " + enNewCase.Attributes.Contains("rsa_account"));
            tracingService.Trace("new");
            //tracingService.Trace("enOpptyAndPolicy :" + enOpptyAndPolicy);
            //tracingService.Trace("pol.rsa_broker : " + enOpptyAndPolicy.Attributes.Contains("pol.rsa_broker"));

            //if ((enCaseTarget.Attributes.Contains("rsa_account") && enOpptyAndPolicy != null && enCaseTarget.Attributes["rsa_account"] != null && (enOpptyAndPolicy.Attributes.Contains("pol.rsa_broker")
            //     && ((EntityReference)enCaseTarget.Attributes["rsa_account"]).Id != ((EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_broker"]).Value).Id))
            //|| (enNewCase.Attributes.Contains("rsa_account") && enOpptyAndPolicy != null && enNewCase.Attributes["rsa_account"] != null && (enOpptyAndPolicy.Attributes.Contains("pol.rsa_broker")
            //    && ((EntityReference)enNewCase.Attributes["rsa_account"]).Id != ((EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_broker"]).Value).Id)))

            // Bug 2088 --> Added null check broker and Customer entity
            EntityReference enBroker = enOpptyAndPolicy.Attributes.Contains("pol.rsa_broker") ? (EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_broker"]).Value : null;

            if (enBroker != null)
            {

                if (enBroker.Id != null && enBroker.Id != Guid.Empty)
                {

                    if ((enCaseTarget.Attributes.Contains("rsa_account") && enOpptyAndPolicy != null && enCaseTarget.Attributes["rsa_account"] != null && (enOpptyAndPolicy.Attributes.Contains("pol.rsa_broker")
                          && ((EntityReference)enCaseTarget.Attributes["rsa_account"]).Id != enBroker.Id))
                        || (enNewCase.Attributes.Contains("rsa_account") && enOpptyAndPolicy != null && enNewCase.Attributes["rsa_account"] != null && (enOpptyAndPolicy.Attributes.Contains("pol.rsa_broker")
                          && ((EntityReference)enNewCase.Attributes["rsa_account"]).Id != enBroker.Id)))
                    {

                        if (enOpptyAndPolicy.Attributes.Contains("pol.rsa_broker") && enBroker != null)
                        {
                            tracingService.Trace("Polulate account" + ((EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_broker"]).Value).Id.ToString());
                            enCaseTarget["rsa_account"] = new EntityReference("account", ((EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_broker"]).Value).Id);
                        }
                    }

                    else if (!enCaseTarget.Attributes.Contains("rsa_account") || !enNewCase.Attributes.Contains("rsa_account"))
                    {

                        tracingService.Trace("Polulate account 1" + ((EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_broker"]).Value).Id.ToString());
                        enCaseTarget["rsa_account"] = new EntityReference("account", ((EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_broker"]).Value).Id);
                    }
                }
            }

            EntityReference encustomer = enOpptyAndPolicy.Attributes.Contains("pol.rsa_customer") ? (EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_customer"]).Value : null;

            if (encustomer != null)
            {

                if (encustomer.Id != null && encustomer.Id != Guid.Empty)
                {
                    if ((enCaseTarget.Attributes.Contains("rsa_customerrsa") && enOpptyAndPolicy != null && enCaseTarget.Attributes["rsa_customerrsa"] != null && (enOpptyAndPolicy.Attributes.Contains("pol.rsa_customer") &&
                    ((EntityReference)enCaseTarget.Attributes["rsa_customerrsa"]).Id != ((EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_customer"]).Value).Id))
                    || (enNewCase.Attributes.Contains("rsa_customerrsa") && enOpptyAndPolicy != null && enNewCase.Attributes["rsa_customerrsa"] != null && (enOpptyAndPolicy.Attributes.Contains("pol.rsa_customer") &&
                    ((EntityReference)enNewCase.Attributes["rsa_customerrsa"]).Id != ((EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_customer"]).Value).Id)))
                    {
                        if (enOpptyAndPolicy.Attributes.Contains("pol.rsa_customer") && ((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_customer"]) != null)
                        {
                            tracingService.Trace("Polulate rsa_customerrsa" + ((EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_customer"]).Value).Id.ToString());
                            enCaseTarget["rsa_customerrsa"] = new EntityReference("rsa_customer", ((EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_customer"]).Value).Id);
                        }
                    }

                    else if (!enCaseTarget.Attributes.Contains("rsa_customerrsa") || !enNewCase.Attributes.Contains("rsa_customerrsa"))
                    {
                        tracingService.Trace("Polulate rsa_customerrsa1" + ((EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_customer"]).Value).Id.ToString());
                        enCaseTarget["rsa_customerrsa"] = new EntityReference("rsa_customer", ((EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_customer"]).Value).Id);
                    }
                }
            }
            tracingService.Trace("Before enColTradingThresold");
            if (enColTradingThresold != null)
            {
                foreach (var enTh in enColTradingThresold.Entities)
                {
                    tracingService.Trace("With In enColTradingThresold");
                    if (enTh.Attributes.Contains("rsa_classofbusiness") && enTh.Attributes.Contains("rsa_office") &&
                        enOpptyAndPolicy.Attributes.Contains("pol.rsa_tradinghandlingsite") && enOpptyAndPolicy.Attributes.Contains("rsa_classofbusiness"))
                    {
                        tracingService.Trace("With In rsa_tradinghandlingsite");
                        if (
                            (((EntityReference)enTh.Attributes["rsa_classofbusiness"]).Id == ((EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_classofbusiness"]).Value).Id) &&
                                (((OptionSetValue)enTh.Attributes["rsa_office"]).Value == ((OptionSetValue)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_tradinghandlingsite"]).Value).Value)
                            )
                        {
                            tracingService.Trace("With In rsa_tradinghandlingsite: " + (((OptionSetValue)enTh.Attributes["rsa_office"]).Value.ToString()));
                            if (enTh.Attributes.Contains("rsa_renewaltradingthreshold") && enOpptyAndPolicy.Attributes.Contains("rsa_expiringpremium"))
                            {
                                tracingService.Trace("With In rsa_renewaltradingthreshold");
                                if (((Money)(enOpptyAndPolicy.Attributes["rsa_expiringpremium"])).Value >= ((Money)enTh.Attributes["rsa_renewaltradingthreshold"]).Value)
                                {
                                    tracingService.Trace("With In rsa_expiringpremium");
                                    enCaseTarget["rsa_traded"] = new OptionSetValue((int)RSAEnum.OPS_Case_rsa_traded.Traded); // Traded
                                    if ((!enCaseTarget.Attributes.Contains("rsa_caseinitialassignedtosite") && !enCaseTarget.Attributes.Contains("rsa_dummyfieldforrenewals") &&
                                        enOpptyAndPolicy.Attributes.Contains("pol.rsa_tradinghandlingsite"))
                                        || (!enNewCase.Attributes.Contains("rsa_caseinitialassignedtosite") && !enNewCase.Attributes.Contains("rsa_dummyfieldforrenewals") &&
                                        enOpptyAndPolicy.Attributes.Contains("pol.rsa_tradinghandlingsite")))
                                    {
                                        tracingService.Trace("With In pol.rsa_tradinghandlingsite");
                                        enCaseTarget["rsa_caseinitialassignedtosite"] = new OptionSetValue(((OptionSetValue)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_tradinghandlingsite"]).Value).Value);
                                    }
                                    if (enOpptyAndPolicy.Attributes.Contains("pol.rsa_policytrader"))
                                    {
                                        tracingService.Trace("With In pol.rsa_policyhandler");
                                        if ((!enCaseTarget.Attributes.Contains("rsa_caseinitialassignedtosite") && !enCaseTarget.Attributes.Contains("rsa_dummyfieldforrenewals"))
                                            || (!enNewCase.Attributes.Contains("rsa_caseinitialassignedtosite") && !enNewCase.Attributes.Contains("rsa_dummyfieldforrenewals")))
                                        {
                                            tracingService.Trace("rsa_initialassignedtousers");
                                            enCaseTarget["rsa_initialassignedtousers"] = ((EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_policytrader"]).Value).Name;
                                        }
                                        tracingService.Trace("Calling User");
                                        Entity enUser = caseCommon.GetUserDetails(((EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_policytrader"]).Value).Id);
                                        if ((enUser != null && !enCaseTarget.Attributes.Contains("rsa_initialassignedtousers") && !enCaseTarget.Attributes.Contains("rsa_dummyfieldforrenewals"))
                                            || (enUser != null && !enNewCase.Attributes.Contains("rsa_initialassignedtousers") && !enNewCase.Attributes.Contains("rsa_dummyfieldforrenewals")))
                                        {
                                            tracingService.Trace("Successfully fetched User");
                                            if (enUser.Attributes.Contains("rsa_division"))
                                                enCaseTarget["rsa_caseinitialassignedtodivision"] = enUser.Attributes["rsa_division"];
                                            //if (enUser.Attributes.Contains("rsa_userteamlevel2")) //TODO (rsa_userteamlevel2-Lookup) and (rsa_caseinitialassignedtoteam)OptionSet
                                            //    enCase["rsa_caseinitialassignedtoteam"] = enUser.Attributes["rsa_userteamlevel2"];
                                            tracingService.Trace("Completed fetched User");
                                        }
                                    }
                                    enCaseTarget["rsa_dummyfieldforrenewals"] = "Inserting a Dummy Value";
                                    tracingService.Trace("Setting rsa_dummyfieldforrenewals 1");
                                }
                                else
                                {
                                    tracingService.Trace("'Ops-Traded'");
                                    enCaseTarget["rsa_traded"] = new OptionSetValue((int)RSAEnum.OPS_Case_rsa_traded.OpsTraded); // 'Ops-Traded'
                                    if ((!enCaseTarget.Attributes.Contains("rsa_caseinitialassignedtosite") && !enCaseTarget.Attributes.Contains("rsa_dummyfieldforrenewals") &&
                                            enOpptyAndPolicy.Attributes.Contains("pol.rsa_operationshandlingsite"))
                                            || (!enNewCase.Attributes.Contains("rsa_caseinitialassignedtosite") && !enNewCase.Attributes.Contains("rsa_dummyfieldforrenewals") &&
                                            enOpptyAndPolicy.Attributes.Contains("pol.rsa_operationshandlingsite")))
                                    {
                                        tracingService.Trace("pol.rsa_operationshandlingsite");
                                        enCaseTarget["rsa_caseinitialassignedtosite"] = new OptionSetValue(((OptionSetValue)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_operationshandlingsite"]).Value).Value);
                                    }
                                    if (enOpptyAndPolicy.Attributes.Contains("pol.rsa_policyhandler"))
                                    {
                                        tracingService.Trace("pol.rsa_policyhandler");
                                        Entity enUser = caseCommon.GetUserDetails(((EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_policyhandler"]).Value).Id);
                                        if ((enUser != null && !enCaseTarget.Attributes.Contains("rsa_initialassignedtousers") && !enCaseTarget.Attributes.Contains("rsa_dummyfieldforrenewals"))
                                            || (enUser != null && !enNewCase.Attributes.Contains("rsa_initialassignedtousers") && !enNewCase.Attributes.Contains("rsa_dummyfieldforrenewals")))
                                        {
                                            tracingService.Trace("successfully fetched user 1");
                                            enCaseTarget["rsa_initialassignedtousers"] = ((EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_policyhandler"]).Value).Name;
                                            if (enUser.Attributes.Contains("rsa_division"))
                                                enCaseTarget["rsa_caseinitialassignedtodivision"] = enUser.Attributes["rsa_division"];
                                            //if (enUser.Attributes.Contains("rsa_userteamlevel2")) //TODO (rsa_userteamlevel2-Lookup) and (rsa_caseinitialassignedtoteam)OptionSet
                                            //    enCase["rsa_caseinitialassignedtoteam"] = enUser.Attributes["rsa_userteamlevel2"];
                                            tracingService.Trace("completed successfully fetched user 1");
                                        }
                                    }
                                    enCaseTarget["rsa_dummyfieldforrenewals"] = "Inserting a Dummy Value";
                                    tracingService.Trace("Setting rsa_dummyfieldforrenewals 2");
                                }
                            }
                            if (enOpptyAndPolicy.Attributes.Contains("rsa_expiringpremium") && enTh.Attributes.Contains("rsa_renewalpromisethreshold"))
                            {
                                tracingService.Trace("rsa_expiringpremium");
                                if ((((Money)enOpptyAndPolicy.Attributes["rsa_expiringpremium"]).Value >= ((Money)enTh.Attributes["rsa_renewalpromisethreshold"]).Value &&
                                    enCaseTarget.Attributes.Contains("rsa_promisebroker") && enCaseTarget.Attributes["rsa_promisebroker"].ToString().Equals("Promise"))
                                    || (((Money)enOpptyAndPolicy.Attributes["rsa_expiringpremium"]).Value >= ((Money)enTh.Attributes["rsa_renewalpromisethreshold"]).Value &&
                                    enNewCase.Attributes.Contains("rsa_promisebroker") && enNewCase.Attributes["rsa_promisebroker"].ToString().Equals("Promise")))
                                {
                                    tracingService.Trace("set Promise");
                                    enCaseTarget["rsa_promise"] = new OptionSetValue((int)RSAEnum.OPS_Case_rsa_promise.Promise); // set Promise
                                }
                                else
                                {
                                    tracingService.Trace("set Non-Promise");
                                    enCaseTarget["rsa_promise"] = new OptionSetValue((int)RSAEnum.OPS_Case_rsa_promise.NonPromise); // set Non-Promise
                                }
                            }
                        }
                    }
                }

            }
            tracingService.Trace("END SetPromiseConditions()");
        }


        /// <summary>
        /// Attributes updated might not be available in PreImage with Post value but PreImage 
        /// with new values are required sometime to validate and other fields. 
        /// </summary>
        /// <param name="enCaseTarget"></param>
        /// <param name="enCasePreImage"></param>
        private void MapAttributes()
        {
            if (enCaseTarget.Attributes.Contains("description"))
                enCasePreImage["description"] = enCaseTarget["description"];
            if (enCaseTarget.Attributes.Contains("rsa_casetype"))
                enCasePreImage["rsa_casetype"] = enCaseTarget["rsa_casetype"];
            if (enCaseTarget.Attributes.Contains("rsa_policyid") && ((EntityReference)enCaseTarget.Attributes["rsa_policyid"]).Id.ToString() != string.Empty)
                enCasePreImage["rsa_policyid"] = enCaseTarget["rsa_policyid"];
            if (enCaseTarget.Attributes.Contains("rsa_customerrsa"))
                enCasePreImage["rsa_customerrsa"] = enCaseTarget["rsa_customerrsa"];
            if (enCaseTarget.Attributes.Contains("rsa_status"))
                enCasePreImage["rsa_status"] = enCaseTarget["rsa_status"];
            if (enCaseTarget.Attributes.Contains("rsa_isemailparsingalreadyrun"))
                enCasePreImage["rsa_isemailparsingalreadyrun"] = enCaseTarget["rsa_isemailparsingalreadyrun"];
            if (enCaseTarget.Attributes.Contains("rsa_policynumberqc"))
                enCasePreImage["rsa_policynumberqc"] = enCaseTarget["rsa_policynumberqc"];
            if (enCaseTarget.Attributes.Contains("rsa_policysystemqc"))
                enCasePreImage["rsa_policysystemqc"] = enCaseTarget["rsa_policysystemqc"];
            if (enCaseTarget.Attributes.Contains("rsa_customerpostcode"))
                enCasePreImage["rsa_customerpostcode"] = enCaseTarget["rsa_customerpostcode"];
            if (enCaseTarget.Attributes.Contains("rsa_customername"))
                enCasePreImage["rsa_customername"] = enCaseTarget["rsa_customername"];
            if (enCaseTarget.Attributes.Contains("rsa_account"))
                enCasePreImage["rsa_account"] = enCaseTarget["rsa_account"];
            if (enCaseTarget.Attributes.Contains("rsa_agencynumber"))
                enCasePreImage["rsa_agencynumber"] = enCaseTarget["rsa_agencynumber"];
            if (enCaseTarget.Attributes.Contains("rsa_quoteid"))
                enCasePreImage["rsa_quoteid"] = enCaseTarget["rsa_quoteid"];
            if (enCaseTarget.Attributes.Contains("ownerid"))
                enCasePreImage["ownerid"] = enCaseTarget["ownerid"];
            if (enCaseTarget.Attributes.Contains("rsa_opportunityid"))
                enCasePreImage["rsa_opportunityid"] = enCaseTarget["rsa_opportunityid"];
            if (enCaseTarget.Attributes.Contains("rsa_outcomedate"))
                enCasePreImage["rsa_outcomedate"] = enCaseTarget["rsa_outcomedate"];
            if (enCaseTarget.Attributes.Contains("rsa_dummyreportingfield"))
                enCasePreImage["rsa_dummyreportingfield"] = enCaseTarget["rsa_dummyreportingfield"];
            if (enCaseTarget.Attributes.Contains("rsa_classofbusinessphoneenqid"))
                enCasePreImage["rsa_classofbusinessphoneenqid"] = enCaseTarget["rsa_classofbusinessphoneenqid"];
            if (enCaseTarget.Attributes.Contains("rsa_currentownerdivision"))
                enCasePreImage["rsa_currentownerdivision"] = enCaseTarget["rsa_currentownerdivision"];
            if (enCaseTarget.Attributes.Contains("rsa_currentownersite"))
                enCasePreImage["rsa_currentownersite"] = enCaseTarget["rsa_currentownersite"];
            if (enCaseTarget.Attributes.Contains("rsa_currentownersite"))
                enCasePreImage["rsa_currentownersite"] = enCaseTarget["rsa_currentownersite"];
            if (enCaseTarget.Attributes.Contains("rsa_transactiontypeid"))
                enCasePreImage["rsa_transactiontypeid"] = enCaseTarget["rsa_transactiontypeid"];
            if (enCaseTarget.Attributes.Contains("rsa_surveycaseopen"))
                enCasePreImage["rsa_surveycaseopen"] = enCaseTarget["rsa_surveycaseopen"];
            if (enCaseTarget.Attributes.Contains("rsa_casereceiveddate"))
                enCasePreImage["rsa_casereceiveddate"] = enCaseTarget["rsa_casereceiveddate"];
            if (enCaseTarget.Attributes.Contains("rsa_account"))
                enCasePreImage["rsa_account"] = enCaseTarget["rsa_account"];
            if (enCaseTarget.Attributes.Contains("rsa_targetpremium"))
                enCasePreImage["rsa_targetpremium"] = enCaseTarget["rsa_targetpremium"];
            if (enCaseTarget.Attributes.Contains("rsa_initialassignedtosite"))
                enCasePreImage["rsa_initialassignedtosite"] = enCaseTarget["rsa_initialassignedtosite"];
            if (enCaseTarget.Attributes.Contains("rsa_dummyfieldfornb"))
                enCasePreImage["rsa_dummyfieldfornb"] = enCaseTarget["rsa_dummyfieldfornb"];
            if (enCaseTarget.Attributes.Contains("rsa_initialassignedtousers"))
                enCasePreImage["rsa_initialassignedtousers"] = enCaseTarget["rsa_initialassignedtousers"];

        }
        #endregion PreUpdate

        #region Validation Rule - Javascript replacement

        private void CSIRequiredBrokerCommitment()
        {
            try
            {
                tracingService.Trace("Start in CSIRequiredBrokerCommitment()");
                string caseType = string.Empty;
                int promise = -1;
                string brokerCommitmentImage = string.Empty;
                string potentialToWin = string.Empty;
                tracingService.Trace("enCasePreImage.Attributes.Contains(rsa_status) :" + enCasePreImage.Attributes.Contains("rsa_status"));
                tracingService.Trace("enCaseTarget.Attributes.Contains(rsa_status') : " + enCaseTarget.Attributes.Contains("rsa_status"));
                tracingService.Trace("enCaseTarget.LogicalName :" + enCaseTarget.LogicalName);
                tracingService.Trace("Apex In-Progress");
                if (enCaseTarget.Attributes.Contains("rsa_status") && enCasePreImage.Attributes.Contains("rsa_status"))
                {
                    RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon = new RSA.CSI.Plugins.Case.CaseCommon.CaseCommon(service, tracingService);
                    string statusNew = caseCommon.GetNameByStatusId(((EntityReference)enCaseTarget.Attributes["rsa_status"]).Id);
                    tracingService.Trace("statusNew : " + statusNew);
                    string statusOld = caseCommon.GetNameByStatusId(((EntityReference)enCasePreImage.Attributes["rsa_status"]).Id);
                    tracingService.Trace("statusOld : " + statusOld);
                    if (statusNew.ToLower() == "To be Quoted".ToLower() && statusOld.ToLower() == "To be Vetted".ToLower())
                    {
                        tracingService.Trace("Status condition completed");
                        //if (enCaseTarget.Attributes.Contains("rsa_casetype"))
                        //    caseType = ((EntityReference)enCaseTarget.Attributes["rsa_casetype"]).Name;
                        //else if (enCasePreImage.Attributes.Contains("rsa_casetype"))
                        //    caseType = ((EntityReference)enCasePreImage.Attributes["rsa_casetype"]).Name;
                        caseType = strTargetCaseType;

                        if (enCaseTarget.Attributes.Contains("rsa_promise"))
                            promise = ((OptionSetValue)enCaseTarget.Attributes["rsa_promise"]).Value;
                        else if (enCasePreImage.Attributes.Contains("rsa_promise"))
                            promise = ((OptionSetValue)enCasePreImage.Attributes["rsa_promise"]).Value;

                        if (enCaseTarget.Attributes.Contains("rsa_brokercommitmentimage"))
                            brokerCommitmentImage = enCaseTarget.Attributes["rsa_brokercommitmentimage"].ToString();
                        else if (enCasePreImage.Attributes.Contains("rsa_brokercommitmentimage"))
                            brokerCommitmentImage = enCasePreImage.Attributes["rsa_brokercommitmentimage"].ToString();

                        if (enCaseTarget.Attributes.Contains("rsa_potentialtowin"))
                            potentialToWin = enCaseTarget.Attributes["rsa_potentialtowin"].ToString();
                        else if (enCasePreImage.Attributes.Contains("rsa_potentialtowin"))
                            potentialToWin = enCasePreImage.Attributes["rsa_potentialtowin"].ToString();
                        tracingService.Trace("caseType :" + caseType);
                        tracingService.Trace("promise :" + promise);
                        tracingService.Trace("brokerCommitmentImage :" + brokerCommitmentImage);
                        tracingService.Trace("potentialToWin :" + potentialToWin);
                        if (caseType != string.Empty &&
                            (caseType == "New Business" || caseType == "Renewal") &&
                            promise == 866760000 &&
                            (brokerCommitmentImage == string.Empty || potentialToWin == string.Empty))
                        {
                            tracingService.Trace("Throwing error message");
                            throw new Exception("'Broker Commitment' and 'Potential to Win' should be populated on the opportunity before moving the case to status 'To be Quoted'.");
                        }
                    }


                }
                tracingService.Trace("End CSIRequiredBrokerCommitment()");
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception in CSIRequiredBrokerCommitment()" + ex.Message);
                throw new Exception(ex.Message);
            }
        }

        private void SMEWorkingDaystoCompleteCase()
        {
            try
            {
                tracingService.Trace("Start in SMEWorkingDaystoCompleteCase()");
                bool flag = false;
                DateTime closedDate = new DateTime();
                DateTime createdDate = new DateTime();
                tracingService.Trace("Plugin Tracing");
                if (enCaseTarget.Attributes.Contains("rsa_status"))
                {
                    RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon = new RSA.CSI.Plugins.Case.CaseCommon.CaseCommon(service, tracingService);
                    string strStatus = caseCommon.GetNameByStatusId(((EntityReference)enCaseTarget.Attributes["rsa_status"]).Id);
                    tracingService.Trace("strStatus : " + strStatus);
                    if (strStatus.Contains("Closed - Awaiting Broker Response") || strStatus.Contains("Closed"))
                    {
                        tracingService.Trace("In Loop of Status : ");
                        if (enCaseTarget.Attributes.Contains("rsa_datetimeclosed"))
                        {
                            tracingService.Trace("Found DateTime Closed in Target");
                            flag = true;
                            closedDate = (DateTime)enCaseTarget.Attributes["rsa_datetimeclosed"];
                            createdDate = (DateTime)enCasePreImage.Attributes["createdon"];
                        }
                        else if (enCasePreImage.Attributes.Contains("rsa_datetimeclosed"))
                        {
                            tracingService.Trace("Found DateTime Closed in PreImage");
                            flag = true;
                            closedDate = (DateTime)enCasePreImage.Attributes["rsa_datetimeclosed"];
                            createdDate = (DateTime)enCasePreImage.Attributes["createdon"];
                        }
                        if (flag)
                        {
                            tracingService.Trace("Calling CalcualteBusinessDays");
                            var businessDays = StringUtilities.CalcualteBusinessDays(createdDate, closedDate);
                            enCaseTarget["rsa_workingdaystocompletecase"] = (Double)businessDays;
                            tracingService.Trace("Updated businessDays : " + businessDays);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception in SMEWorkingDaystoCompleteCase()" + ex.Message);
                //throw new Exception("Exception in SMEWorkingDaystoCompleteCase()" + ex.Message);
            }
        }

        /// <summary>
        /// populate entity refernce name
        /// </summary>
        private void PopulateEntityRefName()
        {
            RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon = new RSA.CSI.Plugins.Case.CaseCommon.CaseCommon(service, tracingService);
            tracingService.Trace("Fetching rsa_status");
            if (enCaseTarget.Attributes.Contains("rsa_status") && enCaseTarget.Attributes["rsa_status"] != null)
                strTargetCaseStatus = caseCommon.GetNameByEntityId("rsa_status", ((EntityReference)enCaseTarget.Attributes["rsa_status"]).Id, "rsa_name");
            else if (enNewCase.Attributes.Contains("rsa_status") && enNewCase.Attributes["rsa_status"] != null)
                strTargetCaseStatus = caseCommon.GetNameByEntityId("rsa_status", ((EntityReference)enNewCase.Attributes["rsa_status"]).Id, "rsa_name");
            tracingService.Trace("rsa_status = " + strTargetCaseStatus);

            tracingService.Trace("Fetching rsa_casetype");
            if (enCaseTarget.Attributes.Contains("rsa_casetype") && enCaseTarget.Attributes["rsa_casetype"] != null)
                strTargetCaseType = caseCommon.GetNameByEntityId("rsa_casetype", ((EntityReference)enCaseTarget.Attributes["rsa_casetype"]).Id, "rsa_casetype");
            else if (enNewCase.Attributes.Contains("rsa_casetype") && enNewCase.Attributes["rsa_casetype"] != null)
                strTargetCaseType = caseCommon.GetNameByEntityId("rsa_casetype", ((EntityReference)enNewCase.Attributes["rsa_casetype"]).Id, "rsa_casetype");
            tracingService.Trace("rsa_casetype = " + strTargetCaseType);

            tracingService.Trace("Fetching rsa_transactiontypeid");
            if (enCaseTarget.Attributes.Contains("rsa_transactiontypeid") && enCaseTarget.Attributes["rsa_transactiontypeid"] != null)
                strTargetTransactionType = caseCommon.GetNameByEntityId("rsa_transactiontype", ((EntityReference)enCaseTarget.Attributes["rsa_transactiontypeid"]).Id, "rsa_name");
            else if (enNewCase.Attributes.Contains("rsa_transactiontypeid") && enNewCase.Attributes["rsa_transactiontypeid"] != null)
                strTargetTransactionType = caseCommon.GetNameByEntityId("rsa_transactiontype", ((EntityReference)enNewCase.Attributes["rsa_transactiontypeid"]).Id, "rsa_name");
            tracingService.Trace("rsa_transactiontypeid = " + strTargetTransactionType);
        }
        #endregion
    }
}