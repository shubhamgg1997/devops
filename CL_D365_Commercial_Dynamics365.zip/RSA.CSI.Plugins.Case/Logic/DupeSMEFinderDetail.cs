﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using RSA.CSI.Plugins.Case.CaseCommon;


namespace RSA.CSI.Plugins.Case.Logic
{

    internal class DupeSMEFinderDetail
    {
        #region Constants
        private const double AUTO_IDENTIFY_NOPOSTCODETOWN_COST_THRESHOLD = 66.00;
        private const double AUTO_IDENTIFY_COST_THRESHOLD = 70.00;
        #endregion Constants

        IOrganizationService service;
        ITracingService tracingService;
        Dictionary<Entity, string> enCustStaging1;
        Dictionary<EntityCollection, string> enCustStaging2;
        internal DupeSMEFinderDetail(IOrganizationService cService, ITracingService cTracingService, Dictionary<Entity, string> cEnCustStaging1,
            Dictionary<EntityCollection, string> cEnCustStaging2)
        {
            service = cService;
            tracingService = cTracingService;
            enCustStaging1 = cEnCustStaging1;
            enCustStaging2 = cEnCustStaging2;
        }

        internal void Execute()
        {
            if (enCustStaging1 != null && enCustStaging1.Count > 0)
            {
                tracingService.Trace("enCustStaging1 having value and count : " + enCustStaging1.Count);
                foreach (var en1 in enCustStaging1)
                {
                    tracingService.Trace("In Loop of enCustStaging1");
                    if (en1.Key.Contains("rsa_duplicatecheckstatus") && en1.Key.FormattedValues["rsa_duplicatecheckstatus"].Trim() == "Done")
                    {
                        tracingService.Trace("enCustStaging1 duplicate check status : " + en1.Key.FormattedValues["rsa_duplicatecheckstatus"].Trim());
                        if (en1.Key.Contains("rsa_customernamebigrams") && en1.Key.Contains("rsa_name") && en1.Key.Contains("rsa_postcode"))
                        {
                            tracingService.Trace("enCustStaging1 contains rsa_customernamebigrams,rsa_namersa_postcode");
                            var cust1BigramString = en1.Key.Attributes["rsa_customernamebigrams"];
                            var cust1StagingID = en1.Key.Attributes["rsa_name"];
                            var cust1PostCode = en1.Key.Attributes["rsa_postcode"];
                            tracingService.Trace("cust1BigramString : " + cust1BigramString);
                            tracingService.Trace("cust1StagingID : " + cust1StagingID);
                            tracingService.Trace("cust1PostCode : " + cust1PostCode);
                            if (enCustStaging2 != null && enCustStaging2.Count > 0)
                            {
                                tracingService.Trace("enCustStaging2 having value and count : " + enCustStaging2.Count);
                                foreach (var en2Collection in enCustStaging2)
                                {
                                    tracingService.Trace("In Loop of enCustStaging2");
                                    var costThreshold = AUTO_IDENTIFY_NOPOSTCODETOWN_COST_THRESHOLD;

                                    foreach (var en2 in en2Collection.Key.Entities)
                                    {
                                        tracingService.Trace("In Loop of en2Collection of enCustStaging2");
                                        var cust2PostCode = en2.Attributes["rsa_postcode"];
                                        if (cust2PostCode.ToString().ToLower() != "none" && cust1PostCode.ToString().ToLower() != "none")
                                        {
                                            tracingService.Trace("cust2PostCode and cust1PostCode are not 'none'");
                                            if (cust1PostCode == cust2PostCode)
                                            {
                                                tracingService.Trace("cust2PostCode and cust1PostCode are equal");
                                                costThreshold = AUTO_IDENTIFY_COST_THRESHOLD;
                                            }
                                            if (en2.Contains("rsa_customernamebigrams"))
                                            {
                                                var cust2BigramString = en2.Attributes["rsa_customernamebigrams"];
                                                tracingService.Trace("cust2BigramString : " + cust2BigramString);
                                                var costRatio = RSA.CSI.Plugins.Case.Helper.DiceCoefficient.compareBigramStrings(cust1BigramString.ToString(), cust2BigramString.ToString());
                                                tracingService.Trace("costRatio : " + costRatio);
                                                if (costRatio >= costThreshold)
                                                {
                                                    tracingService.Trace("costRatio >= costThreshold");
                                                    if (en1.Key.GetType().ToString() == "rsa_smecustomerstaging")
                                                    {
                                                        en1.Key.Attributes["rsa_duplicatecheckstatus"] = new OptionSetValue(866760001); //Duplicate
                                                    }
                                                    if (en2.GetType().ToString() == "rsa_customer")
                                                    {
                                                        //TODO: 
                                                        /*// if already 'Duplicated' check that new likeness exceeds old likeness
                                                        Double oldLikeness = (c1status == 'Duplicated') ? Double.valueOf(c1.get('Duplicate_Likeness__c')) : 0;
                                                        //if (c1status == 'Duplicated') system.assert(false, c1status +'::'+likeness+'::'+oldLikeness+'::'+c1);
                                                        if (likeness > oldLikeness)
                                                        {
                                                            // link c1 to c2 - flag as 'Duplicated' until batch end
                                                            updateCust(c1, likeness, link, stagingID, 'Duplicated', custListMap2);
                                                        }
                                                        else updated = false;
                                                        More code on DupeSMEFinderDetail Apex class*/
                                                    }

                                                    try
                                                    {
                                                        service.Update(en1.Key);
                                                    }
                                                    catch (Exception ex)
                                                    {
                                                        tracingService.Trace("Exception while DupeSMEFinderDetail()" + ex.Message);
                                                        //throw new Exception("Exception while DupeSMEFinderDetail()" + ex.Message);
                                                    }

                                                    tracingService.Trace("en1 updated successfully with Duplicate");
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
