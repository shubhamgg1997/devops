﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using RSA.CSI.Plugins.Case.Helper;
using System.Text.RegularExpressions;
using System.Text;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.IO;
using System.Runtime.Serialization.Json;

namespace RSA.CSI.Plugins.Case.Logic
{
    internal class PreCreateLogic
    {
        IOrganizationService service = null;
        ITracingService tracingService = null;
        Entity enCaseTarget = null;
        Guid caseTypeID = Guid.Empty;
        #region Constants
        private const string CASE_TYPE_RENEWAL = "Renewal";
        private const string CASE_TYPE_MTA = "Mid-Term Adjustment";
        private const string CASE_TYPE_RR = "Revised Renewal";
        private const string CASE_TYPE_QUERY = "Query";
        Guid guidCallingUserId = Guid.Empty;
        #endregion Constants

        #region Constructor 
        internal PreCreateLogic(IOrganizationService cService, ITracingService cTracingService, Entity cEnCaseTarget, Guid cGuidCallingUserId)
        {
            service = cService;
            tracingService = cTracingService;
            enCaseTarget = cEnCaseTarget;
            guidCallingUserId = cGuidCallingUserId;
            //caseTypeID = ccaseType;
        }
        #endregion Constructor

        /// <summary>
        /// Execute method on Case Pre Create
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="enCase"></param>
        internal void Execute()
        {
            tracingService.Trace("Calling CallRequestCaseTypeMethiods()");
            this.CallRequestCaseTypeMethiods();
            tracingService.Trace("Successfully completed CallRequestCaseTypeMethiods() and Calling ValidateQuote()");
            this.ValidateQuote();
            tracingService.Trace("Calling UpdateBrokerName()");
            this.UpdateBrokerName();
            tracingService.Trace("Successfully completed ValidateQuote");
            //Sumegh Dhole 13 Oct 2020 
            //Update Base premium 
            this.UpdateBasePremium();
            tracingService.Trace("Successfully completed UpdateBasePremium");
            //Sujeet 30/04/2021

            tracingService.Trace("Calling setpromisenonpromise");
            this.setpromisenonpromise();
            tracingService.Trace("end of setpromisenonpromise");
            tracingService.Trace("Calling AmIPolicyHandler");
            this.AmIPolicyHandler();
            tracingService.Trace("end of Calling AmIPolicyHandler");
            tracingService.Trace("Calling currentActivityIsMine");
            this.currentActivityIsMine();
            tracingService.Trace("end of Calling currentActivityIsMine");
            tracingService.Trace("Calling IsMyCase");
            this.IsMyCase();
            tracingService.Trace("end of Calling IsMyCase");
            tracingService.Trace("Calling IsMyTeamsCase");
            this.IsMyTeamsCase();
            tracingService.Trace("end of Calling IsMyTeamsCase");
            this.SetCaseReceivedDate();
            tracingService.Trace("finished Calling SetCaseReceivedDate");
            this.setCaseDescriptionAsplainText();
            tracingService.Trace("finished Calling setCaseDescriptionAsplainText");

            //2570 : Sumegh Dhole : 02 Feb 2022 : Click For Assist/Dynamics
            tracingService.Trace("Start Calling UpdateLookupSMELiveChat");
            this.UpdateLookupSMELiveChat();
            tracingService.Trace("finished Calling UpdateLookupSMELiveChat");
        }


        //Populate policy and product lookup on case entity
        //Defect 2570 : Sumegh Dhole : 02 Feb 2020 
        private void UpdateLookupSMELiveChat()
        {
            try
            {
                string policyno = enCaseTarget.Attributes.Contains("rsa_policynumberqc") ? enCaseTarget.GetAttributeValue<string>("rsa_policynumberqc") : string.Empty;
                //fetch policy to populate policy lookup
                tracingService.Trace("Policy no" + policyno);
                if (!string.IsNullOrWhiteSpace(policyno))
                {
                    tracingService.Trace("Retrieve policy record" + policyno);
                    Entity policyEntity = GetPolicyRecordIdByName(policyno);
                    //tracingService.Trace("Retrieve policy record completed " + policyEntity.Id);
                    if (policyEntity != null)
                    {
                        if (policyEntity.Attributes.Contains("rsa_policyid"))
                        {
                          enCaseTarget["rsa_policyid"] = new EntityReference("rsa_policy",(Guid)policyEntity.Attributes["rsa_policyid"]);
                        }
                        if (policyEntity.Attributes.Contains("rsa_productid"))
                        {
                            enCaseTarget["rsa_productphoneenqid"] = (EntityReference)policyEntity.Attributes["rsa_productid"];
                            enCaseTarget["rsa_productlivechat"] = ((EntityReference)policyEntity.Attributes["rsa_productid"]).Name;
                        }
                    }
                }
            }
            catch (InvalidPluginExecutionException ex)
            {
                throw ex;
            }
        }

        private void SetCaseReceivedDate() // bug 2179 , 2184 case received is empty 
        {
            DateTime CaseReceivedDate = enCaseTarget.Attributes.Contains("rsa_casereceiveddate") ? enCaseTarget.GetAttributeValue<DateTime>("rsa_casereceiveddate") : DateTime.MinValue;
            DateTime CaseCreatedOn = enCaseTarget.Attributes.Contains("createdon") ? enCaseTarget.GetAttributeValue<DateTime>("createdon") : DateTime.MinValue;

            if (CaseReceivedDate == DateTime.MinValue && CaseCreatedOn != DateTime.MinValue)
            {
                enCaseTarget["rsa_casereceiveddate"] = CaseCreatedOn;
                tracingService.Trace("end of Calling SetCaseReceivedDate");
            }
        }
        private void IsMyTeamsCase()
        {
            RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon = new RSA.CSI.Plugins.Case.CaseCommon.CaseCommon(service, tracingService);
            Entity username = caseCommon.GetUserDetails(guidCallingUserId);

            //var username = service.Retrieve("systemuser", enUser, new ColumnSet(new string[] { "rsa_userteamlevel2", "firstname" }));
            tracingService.Trace("username found:" + username);
            if (username != null)
            {
                string Myname = username.Attributes.Contains("firstname") ? username["firstname"].ToString() : null;
                tracingService.Trace("Myname found:" + Myname);
                string userteamlevel2 = username.Attributes.Contains("rsa_userteamlevel2") ? username["rsa_userteamlevel2"].ToString() : null;
                EntityReference ownerCopy = enCaseTarget.Attributes.Contains("rsa_ownercopyid") ? enCaseTarget.GetAttributeValue<EntityReference>("rsa_ownercopyid") : null;
                tracingService.Trace("owner found:" + ownerCopy);
                if (ownerCopy != null)
                {
                    Entity enownerCopy = service.Retrieve(ownerCopy.LogicalName, ownerCopy.Id, new ColumnSet(new string[] { "rsa_userteamlevel2" }));
                    string ownerCopyUserTeamLevel2 = enownerCopy.Attributes.Contains("rsa_userteamlevel2") ? enownerCopy["rsa_userteamlevel2"].ToString() : null;
                    tracingService.Trace("ownerCopyUserTeamLevel2 found:" + ownerCopyUserTeamLevel2);
                    if (!string.IsNullOrEmpty(userteamlevel2) && !string.IsNullOrEmpty(ownerCopyUserTeamLevel2))
                        if (userteamlevel2.Contains(ownerCopyUserTeamLevel2))
                        {
                            tracingService.Trace("line 88:");
                            enCaseTarget["rsa_rsaismyteamscase"] = "True";
                            tracingService.Trace("rsa_ismyteamscase:");
                        }
                        else
                        {
                            enCaseTarget["rsa_rsaismyteamscase"] = "False";
                            tracingService.Trace("rsa_ismyteamscase:False");
                        }
                }
            }
            // service.Update(enCaseTarget);
        }



        private void IsMyCase()
        {
            RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon = new RSA.CSI.Plugins.Case.CaseCommon.CaseCommon(service, tracingService);
            Entity userId = caseCommon.GetUserDetails(guidCallingUserId);
            tracingService.Trace("userId found:" + userId);
            EntityReference owner = enCaseTarget.Attributes.Contains("ownerid") ? enCaseTarget.GetAttributeValue<EntityReference>("ownerid") : null;
            tracingService.Trace("owner found:" + owner.Id);
            if (userId.Id.Equals(owner.Id))
            {
                enCaseTarget["rsa_rsaismycase"] = "True";
                tracingService.Trace("rsa_rsaismycase:True");
            }
            else
            {
                enCaseTarget["rsa_rsaismycase"] = "False";
                tracingService.Trace("rsa_rsaismycase:False");
            }
            // service.Update(enCaseTarget);
        }
        private void AmIPolicyHandler()
        {
            RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon = new RSA.CSI.Plugins.Case.CaseCommon.CaseCommon(service, tracingService);
            Entity userId = caseCommon.GetUserDetails(guidCallingUserId);

            EntityReference owner = enCaseTarget.Attributes.Contains("ownerid") ? enCaseTarget.GetAttributeValue<EntityReference>("ownerid") : null;
            tracingService.Trace("owner found:" + owner);
            EntityReference policyId = enCaseTarget.Attributes.Contains("rsa_policyid") ? enCaseTarget.GetAttributeValue<EntityReference>("rsa_policyid") : null;
            tracingService.Trace("policyId found:" + policyId);
            if (policyId != null)
            {
                Entity enPolicyHandler = service.Retrieve(policyId.LogicalName, policyId.Id, new ColumnSet(new string[] { "rsa_policyhandler" }));
                tracingService.Trace("enPolicyHandler found:" + enPolicyHandler);
                Guid PolicyHandlerId = enPolicyHandler.Attributes.Contains("rsa_policyhandler") ? enPolicyHandler.GetAttributeValue<EntityReference>("rsa_policyhandler").Id : Guid.Empty;
                tracingService.Trace("PolicyHandlerId found:" + PolicyHandlerId);
                if (userId.Id.Equals(PolicyHandlerId))
                {
                    enCaseTarget["rsa_rsaamipolicyhandler"] = "True";
                    tracingService.Trace("rsa_rsaamipolicyhandler:");
                }
                else
                {
                    enCaseTarget["rsa_rsaamipolicyhandler"] = "False";
                    tracingService.Trace("rsa_rsaamipolicyhandler:False");
                }
            }
            // service.Update(enCaseTarget);
        }

        private void currentActivityIsMine()
        {
            //rsa_activityownerid

            RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon = new RSA.CSI.Plugins.Case.CaseCommon.CaseCommon(service, tracingService);
            Entity userId = caseCommon.GetUserDetails(guidCallingUserId);

            EntityReference activityOwnerId = enCaseTarget.Attributes.Contains("rsa_activityownerid") ? enCaseTarget.GetAttributeValue<EntityReference>("rsa_activityownerid") : null;
            tracingService.Trace("activityOwnerId found:" + activityOwnerId);
            if (activityOwnerId != null)
            {


                if (userId.Id.Equals(activityOwnerId.Id))
                {
                    enCaseTarget["rsa_rsacurrentactivityismine"] = "True";
                    tracingService.Trace("rsa_rsacurrentactivityismine:");
                }
                else
                {
                    enCaseTarget["rsa_rsacurrentactivityismine"] = "False";
                    tracingService.Trace("rsa_rsacurrentactivityismine:False");
                }
            }
            //  service.Update(enCaseTarget);
        }
        /// <summary>
        /// for bug 1208,1209,1210,1211,1212
        /// to set the promise data on case. 
        /// </summary>
        private void setpromisenonpromise()
        {

            EntityReference opportunityId = enCaseTarget.Attributes.Contains("rsa_opportunityid") ? enCaseTarget.GetAttributeValue<EntityReference>("rsa_opportunityid") : null;
            tracingService.Trace("opportunityId from setpromisenonpromise " + opportunityId);
            EntityReference BrokerId = enCaseTarget.Attributes.Contains("rsa_account") ? enCaseTarget.GetAttributeValue<EntityReference>("rsa_account") : null;
            tracingService.Trace("BrokerId from setpromisenonpromise " + BrokerId);
            EntityReference policyId = enCaseTarget.Attributes.Contains("rsa_policyid") ? enCaseTarget.GetAttributeValue<EntityReference>("rsa_policyid") : null;
            tracingService.Trace("policyId from setpromisenonpromise " + policyId);
            if (enCaseTarget.Attributes.Contains("rsa_casetype"))
            {
                tracingService.Trace("caseType from setpromisenonpromise " + enCaseTarget.Attributes["rsa_casetype"].GetType());
                string caseDataTye = Convert.ToString(enCaseTarget.Attributes["rsa_casetype"].GetType());
                EntityReference caseType = null;
                Entity enCaseType = null;
                //throw new InvalidPluginExecutionException();
                switch (caseDataTye)
                {
                    case "System.Guid":
                        tracingService.Trace("when datatype is system.guid");
                        Guid caseTypeGuid = enCaseTarget.Attributes.Contains("rsa_casetype") ? enCaseTarget.GetAttributeValue<Guid>("rsa_casetype") : Guid.Empty;
                        caseType = new EntityReference("incident", caseTypeGuid);
                        enCaseType = service.Retrieve("rsa_casetype", caseTypeGuid, new ColumnSet("rsa_casetype"));
                        ////tracingService.Trace("enCaseType from setpromisenonpromise "+ enCaseType.Attributes.Count);
                        caseType.Name = enCaseType.Attributes.Contains("rsa_casetype") ? enCaseType.GetAttributeValue<string>("rsa_casetype") : null;
                        break;
                    case "Microsoft.Xrm.Sdk.EntityReference":
                        caseType = enCaseTarget.Attributes.Contains("rsa_casetype") ? enCaseTarget.GetAttributeValue<EntityReference>("rsa_casetype") : null;
                        enCaseType = service.Retrieve("rsa_casetype", caseType.Id, new ColumnSet("rsa_casetype"));
                        ////tracingService.Trace("enCaseType from setpromisenonpromise "+ enCaseType.Attributes.Count);
                        caseType.Name = enCaseType.Attributes.Contains("rsa_casetype") ? enCaseType.GetAttributeValue<string>("rsa_casetype") : null;
                        break;
                    default:
                        break;
                }
                //try
                //{
                //     caseType = enCaseTarget.Attributes.Contains("rsa_casetype") ? enCaseTarget.GetAttributeValue<EntityReference>("rsa_casetype") : null;
                //}
                //catch (Exception ex)
                //{
                //    Guid caseTypeGuid = enCaseTarget.Attributes.Contains("rsa_casetype") ? enCaseTarget.GetAttributeValue<Guid>("rsa_casetype") : Guid.Empty;
                //     caseType = new EntityReference("incident", caseTypeGuid);
                //    Entity enCaseType = service.Retrieve("rsa_casetype", caseTypeGuid, new ColumnSet("rsa_casetype"));
                //    ////tracingService.Trace("enCaseType from setpromisenonpromise "+ enCaseType.Attributes.Count);
                //    caseType.Name = enCaseType.Attributes.Contains("rsa_casetype") ? enCaseType.GetAttributeValue<string>("rsa_casetype") : null;
                //}
                tracingService.Trace("caseType from setpromisenonpromise " + caseType);
                EntityReference pandl = null;
                string promiseBroker = enCaseTarget.Attributes.Contains("rsa_promisebroker") ? enCaseTarget.GetAttributeValue<string>("rsa_promisebroker") : string.Empty;
                string promiseNewBusiness = null;
                string promiseRenewal = null;
                if (caseType != null)
                {
                    tracingService.Trace("case type found:" + caseType.Id);

                    tracingService.Trace("case type name:" + caseType.Name);
                    if ((opportunityId != null && policyId != null) || (opportunityId != null && policyId == null))
                    {
                        Entity opptyPl = service.Retrieve(opportunityId.LogicalName, opportunityId.Id, new ColumnSet(new string[] { "rsa_pandlid" }));
                        pandl = opptyPl.Attributes.Contains("rsa_pandlid") ? opptyPl.GetAttributeValue<EntityReference>("rsa_pandlid") : null;
                        tracingService.Trace("pandl" + pandl);
                    }
                    else if (opportunityId == null && policyId != null)
                    {
                        Entity policyPl = service.Retrieve(policyId.LogicalName, policyId.Id, new ColumnSet(new string[] { "rsa_plcode" }));
                        pandl = policyPl.Attributes.Contains("rsa_plcode") ? policyPl.GetAttributeValue<EntityReference>("rsa_plcode") : null;
                        tracingService.Trace("pandl" + pandl);
                        if (pandl != null)
                        {
                            tracingService.Trace("pandl" + pandl.Name);
                            enCaseTarget["rsa_pl_w"] = pandl.Name;
                        }
                    }
                    if (BrokerId != null)
                    {
                        Entity BrokerData = service.Retrieve(BrokerId.LogicalName, BrokerId.Id, new ColumnSet(new string[] { "rsa_promisenewbusiness", "rsa_promiserenewal" }));
                        promiseNewBusiness = BrokerData.FormattedValues.ContainsKey("rsa_promisenewbusiness") ? BrokerData.FormattedValues["rsa_promisenewbusiness"] : null;
                        tracingService.Trace("promise new business broker from broker value" + promiseNewBusiness);
                        promiseRenewal = BrokerData.FormattedValues.ContainsKey("rsa_promiserenewal") ? BrokerData.FormattedValues["rsa_promiserenewal"] : null;
                        tracingService.Trace("promise renewal broker from broker value" + promiseRenewal);
                    }
                    tracingService.Trace("Promise/Non-promise about to set");

                    if (caseType.Name.ToLowerInvariant().Equals("new business") || caseType.Name.ToLowerInvariant().Equals("schemes - bordereaux"))
                    {
                        if (promiseNewBusiness != null && pandl != null && promiseNewBusiness.ToLowerInvariant().Contains(pandl.Name.ToLowerInvariant()))
                        {
                            tracingService.Trace("Promise about to set");
                            enCaseTarget["rsa_promise"] = new OptionSetValue(866760000);
                        }
                        else if (promiseNewBusiness != null && pandl != null && !promiseNewBusiness.ToLowerInvariant().Contains(pandl.Name.ToLowerInvariant()))
                        {
                            tracingService.Trace("Non Promise about to set 1");
                            enCaseTarget["rsa_promise"] = new OptionSetValue(866760001);
                        }
                        else
                        {
                            tracingService.Trace("Non Promise about to set 2");
                            enCaseTarget["rsa_promise"] = new OptionSetValue(866760001);
                        }
                    }
                    else if (caseType.Name.ToLowerInvariant().Equals("renewal"))
                    {
                        if (promiseRenewal != null && pandl != null && promiseRenewal.ToLowerInvariant().Contains(pandl.Name.ToLowerInvariant()))
                        {
                            tracingService.Trace("Promise renewal about to set");
                            enCaseTarget["rsa_promise"] = new OptionSetValue(866760000);
                        }
                        else if (promiseRenewal != null && pandl != null && !promiseRenewal.ToLowerInvariant().Contains(pandl.Name.ToLowerInvariant()))
                        {
                            tracingService.Trace("Non Promise about to set 1");
                            enCaseTarget["rsa_promise"] = new OptionSetValue(866760001);
                        }
                        else
                        {
                            tracingService.Trace("Non Promise about to set 2");
                            enCaseTarget["rsa_promise"] = new OptionSetValue(866760001);
                        }

                    }
                }
            }
        }


        /// <summary>
        ///Sumegh Dhole 13 Oct 2020 
        ///Update Base premium 
        /// </summary>
        private void UpdateBasePremium()
        {
            tracingService.Trace("Start Base premium update from opportunity or Policy");
            decimal policyPremium = 0.00M, calculatedpremium = 0.00M, targetPremium = 0.00M, basePremium = 0.00M, oppTargerPremium = 0.00M;
            try
            {
                EntityReference opportunityId = enCaseTarget.Attributes.Contains("rsa_opportunityid") ? (EntityReference)enCaseTarget.Attributes["rsa_opportunityid"] : null;
                tracingService.Trace("Opportunity :" + opportunityId);
                EntityReference policyId = enCaseTarget.Attributes.Contains("rsa_policyid") ? (EntityReference)enCaseTarget.Attributes["rsa_policyid"] : null;
                tracingService.Trace("Policy : " + policyId);
                //Defect id : 1365 : 13 May 2021:  Sumegh DHole : Queue not found after renewal generation
                if (enCaseTarget.Attributes.Contains("rsa_casetype"))
                {
                    //EntityReference caseType = enCaseTarget.Attributes.Contains("rsa_casetype") ? enCaseTarget.GetAttributeValue<EntityReference>("rsa_casetype") : null;
                    tracingService.Trace("caseType from setpromisenonpromise " + enCaseTarget.Attributes["rsa_casetype"].GetType());
                    string caseDataTye = Convert.ToString(enCaseTarget.Attributes["rsa_casetype"].GetType());
                    EntityReference caseType = null;
                    //throw new InvalidPluginExecutionException();
                    Entity enCaseType = null;
                    switch (caseDataTye)
                    {
                        case "System.Guid":
                            tracingService.Trace("when datatype is system.guid");
                            Guid caseTypeGuid = enCaseTarget.Attributes.Contains("rsa_casetype") ? enCaseTarget.GetAttributeValue<Guid>("rsa_casetype") : Guid.Empty;
                            caseType = new EntityReference("incident", caseTypeGuid);
                            enCaseType = service.Retrieve("rsa_casetype", caseTypeGuid, new ColumnSet("rsa_casetype"));
                            ////tracingService.Trace("enCaseType from setpromisenonpromise "+ enCaseType.Attributes.Count);
                            caseType.Name = enCaseType.Attributes.Contains("rsa_casetype") ? enCaseType.GetAttributeValue<string>("rsa_casetype") : null;
                            break;
                        case "Microsoft.Xrm.Sdk.EntityReference":
                            caseType = enCaseTarget.Attributes.Contains("rsa_casetype") ? enCaseTarget.GetAttributeValue<EntityReference>("rsa_casetype") : null;
                            enCaseType = service.Retrieve("rsa_casetype", caseType.Id, new ColumnSet("rsa_casetype"));
                            ////tracingService.Trace("enCaseType from setpromisenonpromise "+ enCaseType.Attributes.Count);
                            caseType.Name = enCaseType.Attributes.Contains("rsa_casetype") ? enCaseType.GetAttributeValue<string>("rsa_casetype") : null;
                            break;
                        default:
                            break;
                    }

                    //tracingService.Trace("Case Type :" + caseType.);
                    //date05022021 changes made for bug id 1018
                    if (policyId != null && !caseType.Name.ToLower().Equals("new business"))
                    {
                        tracingService.Trace("Fetch policy premium if policy exists for case record");
                        Entity policy = service.Retrieve(policyId.LogicalName, policyId.Id, new ColumnSet(new string[] { "rsa_premium" }));
                        policyPremium = policy.Attributes.Contains("rsa_premium") ? ((Money)policy.Attributes["rsa_premium"]).Value : 0.00M;
                        tracingService.Trace("Policy Premium :" + policyPremium);
                    }
                    else if (opportunityId != null)
                    {
                        // Entity Opportunity = service.Retrieve(opportunityId.LogicalName, new Guid("5451b47b-f4e2-ea11-a814-000d3a7fc45e"), new ColumnSet(new string[] { "rsa_calcutatedpremium", "rsa_targetpremium" }));
                        Entity Opportunity = service.Retrieve(opportunityId.LogicalName, opportunityId.Id, new ColumnSet(new string[] { "rsa_calcutatedpremium", "rsa_targetpremium" }));
                        calculatedpremium = Opportunity.Attributes.Contains("rsa_calcutatedpremium") ? ((OptionSetValue)Opportunity.Attributes["rsa_calcutatedpremium"]).Value : 0.00M;
                        tracingService.Trace("calculatedpremium :" + calculatedpremium);
                        targetPremium = enCaseTarget.Attributes.Contains("rsa_targetpremium") ? (decimal)enCaseTarget.Attributes["rsa_targetpremium"] : 0.00M;
                        tracingService.Trace("targetPremium :" + targetPremium);
                        oppTargerPremium = Opportunity.Attributes.Contains("rsa_targetpremium") ? (decimal)Opportunity.Attributes["rsa_targetpremium"] : 0.00M;
                        tracingService.Trace("oppTargerPremium Opportunity :" + oppTargerPremium);
                    }
                    //Ramesh YELAMAENNI : Defect No: 2193 if (caseType.Name .ToLower().Equals("renewal") || caseType.Name.ToLower().Equals("mid-term adjustment") || caseType.Name.ToLower().Equals("query") || caseType.Name.ToLower().Equals("revised renewal") || caseType.Name.ToLower().Equals("sme - email enquiry"))

                    //    if (caseType.Name.ToLower().Equals("renewal") || caseType.Name.ToLower().Equals("mid-term adjustment") || caseType.Name.ToLower().Equals("query") || caseType.Name.ToLower().Equals("revised renewal"))
                    if (policyPremium > 0.00M && !caseType.Name.ToLower().Equals("new business"))
                    {
                        basePremium = policyPremium;
                    }
                    else if (policyPremium == 0.00M && !caseType.Name.ToLower().Equals("new business") && (oppTargerPremium != 0))
                    {
                        basePremium = oppTargerPremium;
                    }
                    else if (caseType.Name.ToLower().Equals("new business") && (oppTargerPremium == 0 || oppTargerPremium == null))
                    {
                        switch (calculatedpremium.ToString())
                        {
                            case "866760000":
                                basePremium = 1000.00M;
                                break;
                            case "866760001":
                                basePremium = 5000.00M;
                                break;
                            case "866760002":
                                basePremium = 5000.01M;
                                break;
                            case "866760003":
                                basePremium = 10000.00M;
                                break;
                            case "866760004":
                                basePremium = 15000.00M;
                                break;
                            case "866760005":
                                basePremium = 15000.01M;
                                break;
                            case "866760006":
                                basePremium = 25000.00M;
                                break;
                            case "866760007":
                                basePremium = 50000.00M;
                                break;
                            case "866760008":
                                basePremium = 100000.00M;
                                break;
                            case "866760009":
                                basePremium = 250000.00M;
                                break;
                            case "866760010":
                                basePremium = 500000.00M;
                                break;
                            case "866760011":
                                basePremium = 1000000.00M;
                                break;
                            case "866760012":
                                basePremium = 1000000.01M;
                                break;
                            default:
                                break;
                        }
                    }
                    else if (oppTargerPremium != 0 || oppTargerPremium != null)
                    {
                        tracingService.Trace(":target premium contains data");
                        basePremium = oppTargerPremium;
                    }
                    tracingService.Trace("basePremium :" + basePremium);
                    enCaseTarget["rsa_basepremium"] = new Money(basePremium);
                    enCaseTarget["rsa_basepremiumrsa"] = (decimal)basePremium;
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while updating in Base Premium(): " + ex.Message);
            }
        }

        /// <summary>
        /// Populate broker name
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="enCaseTarget"></param>
        /// <param name="guidCallingUserId"></param>
        private void UpdateBrokerName()
        {
            if (enCaseTarget.Attributes.Contains("rsa_testbrokeragency") &&
                !enCaseTarget.Attributes["rsa_testbrokeragency"].ToString().Contains(","))
            {
                var strBrokerAgency = enCaseTarget.Attributes["rsa_testbrokeragency"].ToString();
                var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' no-lock='true'>
                                  <entity name='account'>
                                    <attribute name='name' />
                                    <attribute name='primarycontactid' />
                                    <attribute name='telephone1' />
                                    <attribute name='accountid' />
                                    <order attribute='name' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='rsa_primaryreference' operator='eq' value='{0}' />
                                    </filter>
                                  </entity>
                                </fetch>";
                try
                {
                    var enColBroker = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, strBrokerAgency)));
                    if (enColBroker != null && enColBroker.Entities.Count > 0)
                        enCaseTarget["rsa_account"] = new EntityReference("account", enColBroker.Entities[0].Id);
                }
                catch (Exception ex)
                {
                    tracingService.Trace("Exception while fetching in UpdateBrokerName(): " + ex.Message);
                }
            }
        }
        /// <summary>
        /// Call function based in rsa record type [Revised Renewal,Mid-Term Adjustment ,Renewal,Query]
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="enCase"></param>
        private void CallRequestCaseTypeMethiods()
        {
            // 03 Oct 2020 : To handle the issues with account/broker values for web chat. 
            //Web chat will send the OOB account and it will be copied to the custom field. 
            //if (enCaseTarget.Attributes.Contains("customerid")) {
            //      enCaseTarget["rsa_account"] = enCaseTarget["customerid"];
            // }

            //03 Oct 2020 :Sumegh Dhole
            //Handle the parent account id value if it is not provided before record creation
            if (enCaseTarget.Attributes.Contains("rsa_account"))
            {
                enCaseTarget["customerid"] = enCaseTarget["rsa_account"];
            }

            // populate owner copy 
            //if (enCaseTarget.Attributes.Contains("ownerid") && ((EntityReference)enCaseTarget.Attributes["ownerid"]).Name.StartsWith("005"))
            if (enCaseTarget.Attributes.Contains("ownerid"))
            {
                enCaseTarget["rsa_ownercopyid"] = enCaseTarget["ownerid"];
                tracingService.Trace("rsa_ownercopyid polulated");
            }
            if (enCaseTarget.Attributes.Contains("rsa_casetype"))
            {

                var strCaseType = ((EntityReference)enCaseTarget.Attributes["rsa_casetype"]).Name;
                if (strCaseType == null)
                {
                    // if (strCaseType.Equals(string.Empty))
                    {
                        Entity caseType = service.Retrieve("rsa_casetype", enCaseTarget.GetAttributeValue<EntityReference>("rsa_casetype").Id, new ColumnSet(new string[] { "rsa_casetype" }));
                        strCaseType = caseType.Attributes.Contains("rsa_name") ? Convert.ToString(caseType.Attributes["rsa_casetype"]) : string.Empty;
                    }
                }

                tracingService.Trace("Calling function based on Renewl Type: " + strCaseType);

                var strCaseTypeRef = ((EntityReference)enCaseTarget.Attributes["rsa_casetype"]);

                if (strCaseTypeRef != null)
                {
                    Entity casetype = RetrieveCaseType(strCaseTypeRef.Id, service);
                    strCaseType = casetype.Attributes.Contains("rsa_casetype") ? casetype.GetAttributeValue<string>("rsa_casetype") : null;
                }
                //if (intRequestType == 866760023 &&
                //    enCaseTarget.Attributes.Contains("rsa_policyid")) // Revised Renewal
                if (strCaseType.Equals(CASE_TYPE_RR) &&
                   enCaseTarget.Attributes.Contains("rsa_policyid")) // Revised Renewal
                {
                    tracingService.Trace("Calling function SetRRCaseTeam");
                    //call function
                    this.SetRRCaseTeam(service, tracingService, enCaseTarget);
                    tracingService.Trace("Completed function SetRRCaseTeam");
                }
                //else if (intRequestType == 866760012 &&
                //   enCaseTarget.Attributes.Contains("rsa_policyid")) // Mid-Term Adjustment 
                else if (strCaseType.Equals(CASE_TYPE_MTA) &&
                  enCaseTarget.Attributes.Contains("rsa_policyid")) // Mid-Term Adjustment 
                {
                    tracingService.Trace("Calling function SetMTACaseTeam");
                    //call function
                    this.SetMTACaseTeam(service, tracingService, enCaseTarget);
                    tracingService.Trace("Completed function SetMTACaseTeam");
                }
                //else if (intRequestType == 866760020 && 
                //    enCaseTarget.Attributes.Contains("rsa_opportunityid") &&
                //   enCaseTarget.Attributes.Contains("rsa_policyid")) // Renewal 
                else if (strCaseType.Equals(CASE_TYPE_RENEWAL) &&
                   enCaseTarget.Attributes.Contains("rsa_opportunityid") &&
                   enCaseTarget.Attributes.Contains("rsa_policyid")) // Renewal 
                {
                    tracingService.Trace("Calling function SetPromise");
                    //call function
                    this.SetPromise(service, tracingService, enCaseTarget);
                    tracingService.Trace("Completed function SetPromise");
                    this.ValidatePolicy();
                    tracingService.Trace("Completed function ValidatePolicy");
                }
                //else if (intRequestType == 866760018 &&
                //   enCaseTarget.Attributes.Contains("rsa_policyid")) // Query 
                else if (strCaseType.Equals(CASE_TYPE_QUERY) &&
                   enCaseTarget.Attributes.Contains("rsa_policyid")) // Query 
                {
                    tracingService.Trace("Calling function SetServicing");
                    //call function
                    this.SetServicing(service, tracingService, enCaseTarget);
                    tracingService.Trace("Completed function SetServicing");
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="guid"></param>
        /// <param name="service"></param>
        /// <returns></returns>
        public Entity RetrieveCaseType(Guid guid, IOrganizationService service)
        {
            try
            {
                var recordName = new Entity();
                QueryExpression query = new QueryExpression("rsa_casetype");
                query.ColumnSet = new ColumnSet(new string[] { "rsa_casetype" });
                query.Criteria.AddCondition("rsa_casetypeid", ConditionOperator.Equal, guid);
                query.NoLock = true;
                EntityCollection businessRecordTypes = service.RetrieveMultiple(query);
                if (businessRecordTypes != null && businessRecordTypes.Entities.Count > 0)
                {
                    recordName = businessRecordTypes.Entities[0];
                }
                return recordName;
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        /// <summary>
        /// validate quote and populate case broker and case customer from quote
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="enCase"></param>
        private void ValidateQuote()
        {
            if (enCaseTarget.Attributes.Contains("rsa_quoteid"))
            {
                tracingService.Trace("Within ValidateQuote and calling GetQuoteDetails");
                var enQuote = this.GetQuoteDetails(((EntityReference)enCaseTarget.Attributes["rsa_quoteid"]).Id);
                if (enQuote != null)
                {
                    tracingService.Trace("Successfully fetched GetQuoteDetails");
                    if (enQuote.Attributes.Contains("rsa_brokerid"))
                    {
                        enCaseTarget["rsa_account"] = enQuote["rsa_brokerid"];
                        tracingService.Trace("Within ValidateQuote and calling GetQuoteDetails- populating enCase['rsa_account']:" + ((EntityReference)enQuote["rsa_brokerid"]).Name);
                    }
                    if (enQuote.Attributes.Contains("rsa_customerid"))
                    {
                        enCaseTarget["rsa_customerrsa"] = enQuote["rsa_customerid"];
                        tracingService.Trace("Within ValidateQuote and calling GetQuoteDetails- populating enCase['rsa_customer']:" + ((EntityReference)enQuote["rsa_customerid"]).Name);
                    }
                }
            }
        }
        /// <summary>
        /// Get quote details
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="guidQuote"></param>
        /// <returns></returns>
        private Entity GetQuoteDetails(Guid guidQuote)
        {
            var enQuote = new Entity();
            try
            {
                var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' no-lock='true'>
                              <entity name='rsa_rsaquote'>
                                <attribute name='rsa_name' />
                                <attribute name='rsa_customerid' />
                                <attribute name='rsa_brokerid' />
                                <attribute name='rsa_rsaquoteid' />
                                <order attribute='rsa_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='rsa_rsaquoteid' operator='eq' value='{0}' />
                                </filter>
                              </entity>
                            </fetch>";
                var enColRSAQuote = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, guidQuote.ToString())));
                if (enColRSAQuote != null && enColRSAQuote.Entities.Count > 0)
                {
                    enQuote = enColRSAQuote.Entities[0];
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetching quote: " + ex.Message);
                //throw new Exception("Exception while fetching quote: " + ex.Message);
            }
            return enQuote;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="enCase"></param>
        private void ValidatePolicy()
        {
            if (enCaseTarget.Attributes.Contains("rsa_policyid"))
            {
                var enPolicy = service.Retrieve("rsa_policy", ((EntityReference)enCaseTarget.Attributes["rsa_policyid"]).Id, new ColumnSet("rsa_operationshandlingsite"));
                //check for 'Isle of Man' - 866760021 in Policy
                if (enPolicy != null &&
                    enPolicy.Attributes.Contains("rsa_operationshandlingsite") &&
                    ((OptionSetValue)enPolicy.Attributes["rsa_operationshandlingsite"]).Value == (int)RSAEnum.OPS_Policy_rsa_operationshandlingsite.IsleofMan)
                {
                    //'Renewal - Isle of Man'
                    //enCaseTarget["rsa_rsarecordtype"] = new OptionSetValue(866760021);
                    var enCaseType = GetCaseTypeIdByName("Renewal - Isle of Man");
                    if (enCaseType != null && enCaseType.Id != Guid.Empty)
                    {
                        enCaseTarget["rsa_casetype"] = new EntityReference("rsa_casetype", enCaseType.Id);
                    }

                    // set status for 'To be Quoted' 
                    tracingService.Trace("Populating 'Renewal - Isle of Man' and assigning status");
                    this.SetStatus();
                    tracingService.Trace("Completed assigning status");
                }
            }
        }

        /// <summary>
        /// Get rsa_status entity guid by passing status name
        /// </summary>   
        /// <param name="strCaseTypeName"></param>
        private Entity GetCaseTypeIdByName(string strCaseTypeName)
        {
            Entity enCaseType = null;
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' no-lock='true'>
                                  <entity name='rsa_casetype'>
                                    <attribute name='rsa_casetypeid' />
                                    <attribute name='rsa_casetype' />
                                    <attribute name='rsa_description' />
                                    <attribute name='rsa_casetypecode' />
                                    <order attribute='rsa_casetype' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='rsa_casetype' operator='eq' value='{0}' />
                                    </filter>
                                  </entity>
                                </fetch>";
            try
            {
                var enColCaseType = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, strCaseTypeName.Trim())));
                if (enColCaseType != null && enColCaseType.Entities.Count > 0)
                {
                    enCaseType = enColCaseType[0];
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetching case type GetCaseTypeIdByName()" + ex.Message);
                //throw new Exception("Exception while fetching case type GetCaseTypeIdByName()" + ex.Message);
            }
            return enCaseType;
        }

        private Entity GetPolicyRecordIdByName(string strTypeName)
        {
            Entity enRecordType = null;
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' no-lock='true'>
                                  <entity name='rsa_policy'>
                                    <attribute name='rsa_policyid' />
                                    <attribute name='rsa_productid' />
                                    <filter type='and'>
                                      <condition attribute='rsa_name' operator='eq' value='{0}' />
                                    </filter>
                                  </entity>
                                </fetch>";
            try
            {
                var enColType = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, strTypeName.Trim())));
                if (enColType != null && enColType.Entities.Count > 0)
                {
                    enRecordType = enColType[0];
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetching guid using name" + ex.Message);
                //throw new Exception("Exception while fetching case type GetCaseTypeIdByName()" + ex.Message);
            }
            return enRecordType;
        }

        /// <summary>
        /// Set Case Status
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="enCase"></param>
        private void SetStatus()
        {
            var strStatus = "To be Quoted";
            Guid guidStatusId = Guid.Empty;
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' no-lock='true'>
                              <entity name='rsa_status'>
                                <attribute name='rsa_name' />
                                <attribute name='createdon' />
                                <attribute name='rsa_casetype' />
                                <attribute name='rsa_statusid' />
                                <attribute name='rsa_statuscode' />
                                <order attribute='rsa_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='rsa_name' operator='eq' value='{0}' />
                                </filter>
                              </entity>
                            </fetch>";
            // status code - 866760002
            try
            {
                var enColStatus = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, strStatus.Trim())));
                if (enColStatus != null && enColStatus.Entities.Count > 0)
                {
                    enCaseTarget["rsa_status"] = new EntityReference("rsa_status", enColStatus.Entities[0].Id);
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetching status for 'To Be Quoted'" + ex.Message);
                //throw new Exception("Exception while fetching status for 'To Be Quoted'" + ex.Message);
            }
        }



        #region Set MTA
        internal void SetMTACaseTeam(IOrganizationService service, ITracingService tracingService, Entity enCase)
        {
            //rsa_dummyfieldformta
            tracingService.Trace("Calling SetRequestType(rsa_dummyfieldformta) for SetMTACaseTeam()");
            this.SetRequestType("rsa_dummyfieldformta");
            tracingService.Trace("Completed SetRequestType(rsa_dummyfieldformta) for SetMTACaseTeam()");
        }
        #endregion Set MTA

        #region Set RR
        internal void SetRRCaseTeam(IOrganizationService service, ITracingService tracingService, Entity enCase)
        {
            //rsa_dummyfieldforrr
            tracingService.Trace("Calling SetRequestType(rsa_dummyfieldforrr) for SetRRCaseTeam()");
            this.SetRequestType("rsa_dummyfieldforrr");
            tracingService.Trace("Completed SetRequestType(rsa_dummyfieldforrr) for SetRRCaseTeam()");
        }
        #endregion Set RR

        #region Set Promise
        internal void SetPromise(IOrganizationService service, ITracingService tracingService, Entity enCase)
        {
            ////"rsa_dummyfieldforrenewals" 
            tracingService.Trace("Calling SetRequestType(rsa_dummyfieldforrenewals) for SetPromise()");
            this.SetApplyR90Conditions();
            tracingService.Trace("Completed SetRequestType(rsa_dummyfieldforrenewals) for SetPromise()");
        }
        #endregion Set Promise

        #region Set Servicing
        /// <summary>
        /// This class caters to the cases of record type servicing, we stamp the intial 
        /// assigned fields and the related broker and customer from the attached policy
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="enCase"></param>
        internal void SetServicing(IOrganizationService service, ITracingService tracingService, Entity enCase)
        {
            //rsa_dummyfieldforquery
            tracingService.Trace("Calling SetRequestType(rsa_dummyfieldforquery) for SetServicing()");
            this.SetRequestType("rsa_dummyfieldforquery");
            tracingService.Trace("Completed SetRequestType(rsa_dummyfieldforquery) for SetServicing()");
        }
        #endregion Set Servicing

        #region Set Promise

        /// <summary>
        /// fetching Case,Policy,Broker and Oppty information 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="guidCaseId"></param>
        /// <returns></returns>
        private Entity GetCaseAndRelatedEntityDetails(Guid guidCaseId)
        {
            var enEntity = new Entity();
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' no-lock='true'>
                    <entity name='incident' >
                        <attribute name='title' />
                        <attribute name='ticketnumber' />
                        <attribute name='createdon' />
                        <attribute name='incidentid' />
                        <attribute name='caseorigincode' />
                        <attribute name='rsa_policyid' />
                        <attribute name='rsa_opportunityid' />
                        <attribute name='rsa_account' />
                        <attribute name='rsa_customerrsa' />
                        <order attribute='title' descending='false' />
                        <filter type='and' >
                            <condition attribute='incidentid' operator='eq' value='{0}' />
                        </filter>
                        <link-entity name='opportunity' from='opportunityid' to='rsa_opportunityid' visible='false' link-type='outer' alias='opp' >
                            <attribute name='rsa_expiringpremium' />
                            <attribute name='rsa_classofbusiness' />
                        </link-entity>
                        <link-entity name='account' from='accountid' to='rsa_account' link-type='inner' alias='acc' >
                            <attribute name='rsa_salesteam' />
                            <attribute name='rsa_branch' />
                            <attribute name='name' />
                            <attribute name='rsa_distributioncategoryagency' />
                            <attribute name='rsa_distributionsubsegment' />
                            <attribute name='rsa_network' />
                        </link-entity>
                        <link-entity name='rsa_policy' from='rsa_policyid' to='rsa_policyid' link-type='inner' alias='pol' >
                            <attribute name='rsa_tradinghandlingsite' />
                            <attribute name='rsa_operationshandlingsite' />
                            <attribute name='rsa_reviewtypecode' />
                            <attribute name='rsa_renewalgenerationstatuscode' />
                            <attribute name='rsa_renewalgenerationid' />
                            <attribute name='rsa_renewalgenerationfailreason' />
                            <attribute name='rsa_policytrader' />
                            <attribute name='rsa_policyhandler' />
                            <attribute name='rsa_plcode' />
                            <attribute name='rsa_mumbaihandler' />
                            <attribute name='rsa_premium' />
                            <attribute name='rsa_classofbusiness' />
                            <attribute name='rsa_broker' />
                            <attribute name='rsa_customer' />
                        </link-entity>
                    </entity>
                </fetch>";
            try
            {
                var enColDetails = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, guidCaseId)));
                if (enColDetails != null && enColDetails.Entities.Count > 0)
                {
                    enEntity = enColDetails.Entities[0];
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetching Case,Policy,Broker and Oppty information in GetCaseAndRelatedEntityDetails:" + ex.Message);
                //throw new Exception("Exception while fetching Case,Policy,Broker and Oppty information in GetCaseAndRelatedEntityDetails: " + ex.Message);
            }
            return enEntity;
        }

        /// <summary>
        /// Get trading thresold details
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="guidCOB"></param>
        /// <param name="intOffice"></param>
        /// <returns></returns>
        private EntityCollection GetTradingThresoldDetails(Guid guidCOB, int intOffice)
        {
            var enColTradingThresold = new EntityCollection();

            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' no-lock='true'>
                                <entity name='rsa_tradingthreshold' >
                                    <attribute name='rsa_name' />
                                    <attribute name='rsa_office' />
                                    <attribute name='rsa_pl' />
                                    <attribute name='rsa_thresholdvalue' />
                                    <attribute name='rsa_renewaltradingthreshold' />
                                    <attribute name='rsa_renewalpromisethreshold' />
                                    <attribute name='rsa_classofbusiness' />
                                    <attribute name='rsa_tradingthresholdid' />
                                    <attribute name='rsa_vettingthreshold' />
                                    <order attribute='rsa_name' descending='false' />
                                    <filter type='and' >
                                        <condition attribute='rsa_office' operator='eq' value='{0}' />
                                        <condition attribute='rsa_classofbusiness' operator='eq' value='{1}' />
                                    </filter>
                                </entity>
                            </fetch>";
            try
            {
                enColTradingThresold = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, intOffice, guidCOB)));
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetch Trading Thresold: " + ex.Message);
                //throw new Exception("Exception while fetching GetTradingThresoldDetails: " + ex.Message);
            }
            return enColTradingThresold;
        }

        /// <summary>
        /// Set R90 Conditions
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="enCase"></param>
        private void SetApplyR90Conditions()
        {
            tracingService.Trace("Within and started SetApplyR90Conditions()");
            Guid guidCOB = Guid.Empty;
            string strCOBName = string.Empty;
            var strAccountBranch = string.Empty;
            var intAccountBranch = -1;
            var strCOB = string.Empty;
            var bRuleBranchCheck = false;
            var bRuleCOBCheck = false;
            var bRuleDistributionCategoryAgency = false;
            var bRuleDistributionAgencySegment = false;
            var bRuleNetwork = false;
            var enColTradingThresold = new EntityCollection(null);
            if (enCaseTarget.Attributes.Contains("rsa_opportunityid"))
            {
                RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon = new RSA.CSI.Plugins.Case.CaseCommon.CaseCommon(service, tracingService);
                var strR90COB = string.Empty;// caseCommon.GetCustomLabel(service, tracingService, "R_90_CoBs").Trim();
                var strR90DistributionCategory = string.Empty;//caseCommon.GetCustomLabel(service, tracingService, "R_90_Distribution_Categories").Trim();
                var strR90DistributionSegment = string.Empty;//caseCommon.GetCustomLabel(service, tracingService, "R_90_Distribution_Subsegments").Trim();
                var strR90Network = string.Empty;//caseCommon.GetCustomLabel(service, tracingService, "R_90_Network").Trim();
                var strR90Branchs = string.Empty;//caseCommon.GetCustomLabel(service, tracingService, "R_90_broker_branches").Trim();
                caseCommon.GetR90CustomLables(out strR90COB, out strR90DistributionCategory, out strR90DistributionSegment, out strR90Network, out strR90Branchs);
                tracingService.Trace("R_90_CoBs:{0}||R_90_Distribution_Categories:{1}||R_90_Distribution_Subsegments:{2}||R_90_Network:{3}||R_90_broker_branches:{4}", strR90COB, strR90DistributionCategory, strR90DistributionSegment, strR90Network, strR90Branchs);
                tracingService.Trace("Get Opportunity");
                var enOpptyAndPolicy = caseCommon.GetOpptyAndPolicyDetails(((EntityReference)enCaseTarget.Attributes["rsa_opportunityid"]).Id);
                if (enOpptyAndPolicy != null)
                {
                    tracingService.Trace("Successfully fetched Opportunity");
                    // Get Account details
                    if (enOpptyAndPolicy.Attributes.Contains("pol.rsa_classofbusiness"))
                    {
                        strCOB = ((EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_classofbusiness"]).Value).Name.Trim();
                        guidCOB = ((EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_classofbusiness"]).Value).Id;
                        bRuleCOBCheck = strR90COB.Contains(strCOB);
                        tracingService.Trace("bRuleCOBCheck:" + bRuleCOBCheck.ToString());
                        if (enOpptyAndPolicy.Attributes.Contains("pol.rsa_broker"))
                        {
                            var enBroker = service.Retrieve("account", ((EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_broker"]).Value).Id, new ColumnSet("rsa_salesteam", "rsa_branch", "name", "rsa_distributioncategoryagency", "rsa_distributionsubsegment", "rsa_network"));
                            if (enBroker != null && enBroker.Attributes.Contains("rsa_branch") && bRuleCOBCheck)
                            {
                                tracingService.Trace("Successfully fetched broker");
                                strAccountBranch = enBroker.FormattedValues["rsa_branch"].Trim();
                                intAccountBranch = ((OptionSetValue)enBroker["rsa_branch"]).Value;
                                bRuleBranchCheck = strR90Branchs.Contains(strAccountBranch);
                                tracingService.Trace("Branch from strR90Branchs " + strR90Branchs);
                                tracingService.Trace("Branch Name from Broker " + strAccountBranch);
                                tracingService.Trace("Branch Id from Broker " + intAccountBranch);
                                tracingService.Trace("guidCOB " + guidCOB.ToString());
                                if (bRuleBranchCheck)
                                {
                                    enColTradingThresold = this.GetTradingThresoldDetails(guidCOB, intAccountBranch);
                                    tracingService.Trace("Successfully fetched GetTradingThresoldDetails");
                                    //TODO - the below fields are calculated fields in D365 and cannot be accessed in plugins, need discussion
                                    // Need to write for extraction
                                    if (enBroker.Attributes.Contains("rsa_distributioncategoryagency") &&
                                        strR90DistributionCategory.Contains(enBroker.Attributes["rsa_distributioncategoryagency"].ToString()))
                                    {
                                        bRuleDistributionCategoryAgency = true;
                                    }
                                    if (enBroker.Attributes.Contains("rsa_distributionsubsegment") &&
                                        strR90DistributionSegment.Contains(enBroker.Attributes["rsa_distributionsubsegment"].ToString()))
                                    {
                                        bRuleDistributionAgencySegment = true;
                                    }
                                    if (enBroker.Attributes.Contains("rsa_network") &&
                                        strR90Network.Contains(enBroker.Attributes["rsa_network"].ToString()))
                                    {
                                        bRuleNetwork = true;
                                    }
                                    if (bRuleDistributionCategoryAgency || bRuleDistributionAgencySegment || bRuleNetwork)
                                    {
                                        tracingService.Trace("Iterating threasold");
                                        foreach (var enTh in enColTradingThresold.Entities)
                                        {
                                            if (enTh.Attributes.Contains("rsa_classofbusiness") && enTh.Attributes.Contains("rsa_office") &&
                                                enTh.Attributes.Contains("rsa_vettingthreshold") && enOpptyAndPolicy.Attributes.Contains("pol.rsa_premium"))
                                            {
                                                if (intAccountBranch == ((OptionSetValue)enTh["rsa_office"]).Value &&
                                                    guidCOB == ((EntityReference)enTh.Attributes["rsa_classofbusiness"]).Id &&
                                                    ((Money)enTh.Attributes["rsa_vettingthreshold"]).Value < ((Money)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_premium"]).Value).Value)
                                                {
                                                    enCaseTarget["rsa_applyr90conditions"] = true; // set to true
                                                    tracingService.Trace("rsa_applyr90conditions is true");
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        tracingService.Trace("(bRuleDistributionCategoryAgency || bRuleDistributionAgencySegment || bRuleNetwork- FALSE");
                                    }
                                }
                                else
                                {
                                    tracingService.Trace("branch doesn't exist");
                                }
                            }
                            else
                            {
                                tracingService.Trace("Unable to fetched broker details,branch etc.");
                            }
                        }
                        else
                        {
                            tracingService.Trace("Unable to fetched broker");
                        }
                    }
                    else
                    {
                        tracingService.Trace("Unable to fetched CoB");
                    }
                }
                else
                {
                    tracingService.Trace("Unable to fetched Opportunity");
                }
                tracingService.Trace("Calling SetPromiseConditions");
                this.SetPromiseConditions(enOpptyAndPolicy, enColTradingThresold);
                tracingService.Trace("Complated SetPromiseConditions");
            }
            tracingService.Trace("End SetApplyR90Conditions()");
        }

        /// <summary>
        /// Polulate Case Promise fields with other fields as well
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="enCase"></param>
        /// <param name="enOpptyAndPolicy"></param>
        /// <param name="enBroker"></param>
        /// <param name="enColTradingThresold"></param>
        private void SetPromiseConditions(Entity enOpptyAndPolicy, EntityCollection enColTradingThresold)
        {
            tracingService.Trace("Within SetPromiseConditions()");
            RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon = new RSA.CSI.Plugins.Case.CaseCommon.CaseCommon(service, tracingService);

            //Chandani 13 Oct 2020 : Added condition for the opportunity policy
            if (enOpptyAndPolicy != null)
            {
                if (enCaseTarget.Attributes.Contains("rsa_account") && (enOpptyAndPolicy.Attributes.Contains("pol.rsa_broker") &&
                ((EntityReference)enCaseTarget.Attributes["rsa_account"]).Id != ((EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_broker"]).Value).Id))
                {
                    tracingService.Trace("Polulate account" + ((EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_broker"]).Value).Id.ToString());
                    enCaseTarget["rsa_account"] = new EntityReference("account", ((EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_broker"]).Value).Id);
                }
                else if (!enCaseTarget.Attributes.Contains("rsa_account"))
                {
                    tracingService.Trace("Polulate account 1" + ((EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_broker"]).Value).Id.ToString());
                    enCaseTarget["rsa_account"] = new EntityReference("account", ((EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_broker"]).Value).Id);
                }

                if (enCaseTarget.Attributes.Contains("rsa_customerrsa") && (enOpptyAndPolicy.Attributes.Contains("pol.rsa_customer") &&
                ((EntityReference)enCaseTarget.Attributes["rsa_customerrsa"]).Id != ((EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_customer"]).Value).Id))
                {
                    tracingService.Trace("Polulate rsa_customerrsa" + ((EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_customer"]).Value).Id.ToString());
                    enCaseTarget["rsa_customerrsa"] = new EntityReference("rsa_customer", ((EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_customer"]).Value).Id);
                }
                else if (!enCaseTarget.Attributes.Contains("rsa_customerrsa"))
                {
                    tracingService.Trace("Polulate rsa_customerrsa1" + ((EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_customer"]).Value).Id.ToString());
                    enCaseTarget["rsa_customerrsa"] = new EntityReference("rsa_customer", ((EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_customer"]).Value).Id);
                }
                if (enColTradingThresold != null)
                {
                    foreach (var enTh in enColTradingThresold.Entities)
                    {
                        tracingService.Trace("With In enColTradingThresold");
                        if (enTh.Attributes.Contains("rsa_classofbusiness") && enTh.Attributes.Contains("rsa_office") &&
                            enOpptyAndPolicy.Attributes.Contains("pol.rsa_tradinghandlingsite") && enOpptyAndPolicy.Attributes.Contains("rsa_classofbusiness"))
                        {
                            tracingService.Trace("With In rsa_tradinghandlingsite");
                            if (
                                (((EntityReference)enTh.Attributes["rsa_classofbusiness"]).Id == ((EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_classofbusiness"]).Value).Id) &&
                                    (((OptionSetValue)enTh.Attributes["rsa_office"]).Value == ((OptionSetValue)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_tradinghandlingsite"]).Value).Value)
                                )
                            {
                                tracingService.Trace("With In rsa_tradinghandlingsite: " + (((OptionSetValue)enTh.Attributes["rsa_office"]).Value.ToString()));
                                if (enTh.Attributes.Contains("rsa_renewaltradingthreshold") && enOpptyAndPolicy.Attributes.Contains("rsa_expiringpremium"))
                                {
                                    tracingService.Trace("With In rsa_renewaltradingthreshold");
                                    if (((Money)(enOpptyAndPolicy.Attributes["rsa_expiringpremium"])).Value >= ((Money)enTh.Attributes["rsa_renewaltradingthreshold"]).Value)
                                    {
                                        tracingService.Trace("With In rsa_expiringpremium");
                                        enCaseTarget["rsa_traded"] = new OptionSetValue((int)RSAEnum.OPS_Case_rsa_traded.Traded); // Traded
                                        if (!enCaseTarget.Attributes.Contains("rsa_caseinitialassignedtosite") && !enCaseTarget.Attributes.Contains("rsa_dummyfieldforrenewals") &&
                                            enOpptyAndPolicy.Attributes.Contains("pol.rsa_tradinghandlingsite"))
                                        {
                                            tracingService.Trace("With In pol.rsa_tradinghandlingsite");
                                            enCaseTarget["rsa_caseinitialassignedtosite"] = new OptionSetValue(((OptionSetValue)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_tradinghandlingsite"]).Value).Value);
                                        }
                                        if (enOpptyAndPolicy.Attributes.Contains("pol.rsa_policytrader"))
                                        {
                                            tracingService.Trace("With In pol.rsa_policyhandler");
                                            if (!enCaseTarget.Attributes.Contains("rsa_caseinitialassignedtosite") && !enCaseTarget.Attributes.Contains("rsa_dummyfieldforrenewals"))
                                            {
                                                tracingService.Trace("rsa_initialassignedtousers");
                                                enCaseTarget["rsa_initialassignedtousers"] = ((EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_policytrader"]).Value).Name;
                                            }
                                            tracingService.Trace("Calling User");
                                            Entity enUser = caseCommon.GetUserDetails(((EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_policytrader"]).Value).Id);
                                            if (enUser != null && !enCaseTarget.Attributes.Contains("rsa_initialassignedtousers") && !enCaseTarget.Attributes.Contains("rsa_dummyfieldforrenewals"))
                                            {
                                                tracingService.Trace("Successfully fetched User");
                                                if (enUser.Attributes.Contains("rsa_division"))
                                                    enCaseTarget["rsa_caseinitialassignedtodivision"] = enUser.Attributes["rsa_division"];
                                                //if (enUser.Attributes.Contains("rsa_userteamlevel2")) //TODO (rsa_userteamlevel2-Lookup) and (rsa_caseinitialassignedtoteam)OptionSet
                                                //    enCase["rsa_caseinitialassignedtoteam"] = enUser.Attributes["rsa_userteamlevel2"];
                                                tracingService.Trace("Completed fetched User");
                                            }
                                        }
                                        enCaseTarget["rsa_dummyfieldforrenewals"] = "Inserting a Dummy Value";
                                        tracingService.Trace("Setting rsa_dummyfieldforrenewals 1");
                                    }
                                    else
                                    {
                                        tracingService.Trace("'Ops-Traded'");
                                        enCaseTarget["rsa_traded"] = new OptionSetValue((int)RSAEnum.OPS_Case_rsa_traded.OpsTraded); // 'Ops-Traded'
                                        if (!enCaseTarget.Attributes.Contains("rsa_caseinitialassignedtosite") && !enCaseTarget.Attributes.Contains("rsa_dummyfieldforrenewals") &&
                                                enOpptyAndPolicy.Attributes.Contains("pol.rsa_operationshandlingsite"))
                                        {
                                            tracingService.Trace("pol.rsa_operationshandlingsite");
                                            enCaseTarget["rsa_caseinitialassignedtosite"] = new OptionSetValue(((OptionSetValue)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_operationshandlingsite"]).Value).Value);
                                        }
                                        if (enOpptyAndPolicy.Attributes.Contains("pol.rsa_policyhandler"))
                                        {
                                            tracingService.Trace("pol.rsa_policyhandler");
                                            Entity enUser = caseCommon.GetUserDetails(((EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_policyhandler"]).Value).Id);
                                            if (enUser != null && !enCaseTarget.Attributes.Contains("rsa_initialassignedtousers") && !enCaseTarget.Attributes.Contains("rsa_dummyfieldforrenewals"))
                                            {
                                                tracingService.Trace("successfully fetched user 1");
                                                enCaseTarget["rsa_initialassignedtousers"] = ((EntityReference)((AliasedValue)enOpptyAndPolicy.Attributes["pol.rsa_policyhandler"]).Value).Name;
                                                if (enUser.Attributes.Contains("rsa_division"))
                                                    enCaseTarget["rsa_caseinitialassignedtodivision"] = enUser.Attributes["rsa_division"];
                                                //if (enUser.Attributes.Contains("rsa_userteamlevel2")) //TODO (rsa_userteamlevel2-Lookup) and (rsa_caseinitialassignedtoteam)OptionSet
                                                //    enCase["rsa_caseinitialassignedtoteam"] = enUser.Attributes["rsa_userteamlevel2"];
                                                tracingService.Trace("completed successfully fetched user 1");
                                            }
                                        }
                                        enCaseTarget["rsa_dummyfieldforrenewals"] = "Inserting a Dummy Value";
                                        tracingService.Trace("Setting rsa_dummyfieldforrenewals 2");
                                    }
                                }
                                if (enOpptyAndPolicy.Attributes.Contains("rsa_expiringpremium") && enTh.Attributes.Contains("rsa_renewalpromisethreshold"))
                                {
                                    tracingService.Trace("rsa_expiringpremium");
                                    if (((Money)enOpptyAndPolicy.Attributes["rsa_expiringpremium"]).Value >= ((Money)enTh.Attributes["rsa_renewalpromisethreshold"]).Value &&
                                        enCaseTarget.Attributes.Contains("rsa_promisebroker") && enCaseTarget.Attributes["rsa_promisebroker"].ToString().Equals("Promise"))
                                    {
                                        tracingService.Trace("set Promise");
                                        enCaseTarget["rsa_promise"] = new OptionSetValue((int)RSAEnum.OPS_Case_rsa_promise.Promise); // set Promise
                                    }
                                    else
                                    {
                                        tracingService.Trace("set Non-Promise");
                                        enCaseTarget["rsa_promise"] = new OptionSetValue((int)RSAEnum.OPS_Case_rsa_promise.NonPromise); // set Non-Promise
                                    }
                                }
                            }
                        }
                    }
                }
            }
            tracingService.Trace("END SetPromiseConditions()");
        }

        #endregion Set Promise

        #region Stamp Case Site Target
        //TODO
        private void StampCaseSiteTarget(IOrganizationService service, ITracingService tracingService, Entity enCaseTarget, Entity enCasePostImage)
        {
            // TODO
        }
        #endregion Stamp Case Site Target

        /// <summary>
        /// Set account customer for MTA,RR and Query. This class caters to the cases of record type servicing, we stamp the intial 
        /// assigned fields and the related broker and customer from the attached policy
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="enCase"></param>
        /// <param name="strDummyFieldName"></param>
        private void SetRequestType(string strDummyFieldName)
        {
            RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon = new RSA.CSI.Plugins.Case.CaseCommon.CaseCommon(service, tracingService);
            if (enCaseTarget.Attributes.Contains("rsa_policyid"))
            {
                Guid guidPolicyId = ((EntityReference)enCaseTarget.Attributes["rsa_policyid"]).Id;
                Entity enPolicy = caseCommon.GetPolicyDetails(guidPolicyId);
                if (enPolicy != null)
                {
                    tracingService.Trace("successfully fetched Policy");
                    if ((enCaseTarget.Attributes.Contains("rsa_account") && enPolicy.Attributes.Contains("rsa_broker")))
                    {
                        if (((EntityReference)(enCaseTarget.Attributes["rsa_account"])).Id != ((EntityReference)enPolicy.Attributes["rsa_broker"]).Id)
                        {
                            tracingService.Trace("rsa_account");
                            if (enPolicy.Attributes.Contains("rsa_broker") && enPolicy.GetAttributeValue<EntityReference>("rsa_broker") != null)
                            {
                                enCaseTarget["rsa_account"] = new EntityReference("account", ((EntityReference)(enPolicy.Attributes["rsa_broker"])).Id);
                            }
                        }
                    }
                    else if (!enCaseTarget.Attributes.Contains("rsa_account"))
                    {
                        tracingService.Trace("rsa_account 1");
                        if (enPolicy.Attributes.Contains("rsa_broker"))
                        {
                            EntityReference brokerID = enPolicy.Attributes.Contains("rsa_broker") ? enPolicy.GetAttributeValue<EntityReference>("rsa_broker") : null;
                            tracingService.Trace("check 0");
                            if (brokerID != null)
                            {
                                tracingService.Trace("check 1");
                                if (brokerID.Id != Guid.Empty)
                                {
                                    tracingService.Trace("check 2");
                                    enCaseTarget["rsa_account"] = new EntityReference("account", ((EntityReference)(enPolicy.Attributes["rsa_broker"])).Id);
                                }
                            }
                        }
                    }
                    tracingService.Trace("customercheck 1");
                    if (enCaseTarget.Attributes.Contains("rsa_customerrsa") && enPolicy.Attributes.Contains("rsa_customer"))
                    {
                        if (((EntityReference)enCaseTarget.Attributes["rsa_customerrsa"]).Id != ((EntityReference)enPolicy.Attributes["rsa_customer"]).Id)
                        {
                            tracingService.Trace("rsa_customerrsa");
                            if (enPolicy.Attributes.Contains("rsa_customer") && enPolicy.GetAttributeValue<EntityReference>("rsa_customer") != null)
                            {
                                enCaseTarget["rsa_customerrsa"] = new EntityReference("rsa_customer", ((EntityReference)(enPolicy.Attributes["rsa_customer"])).Id);
                            }
                        }
                    }
                    else if (!enCaseTarget.Attributes.Contains("rsa_customerrsa"))
                    {
                        tracingService.Trace("rsa_customerrsa1");
                        if (enPolicy.Attributes.Contains("rsa_customer") && enPolicy.GetAttributeValue<EntityReference>("rsa_customer") != null && enPolicy.GetAttributeValue<EntityReference>("rsa_customer").Id != Guid.Empty)
                        {
                            enCaseTarget["rsa_customerrsa"] = new EntityReference("rsa_customer", ((EntityReference)(enPolicy.Attributes["rsa_customer"])).Id);
                        }
                    }
                    //Stamping of the Initial Assigned to fields for reporting purpose
                    if (!enCaseTarget.Attributes.Contains("rsa_caseinitialassignedtosite") && !enCaseTarget.Attributes.Contains(strDummyFieldName) &&
                                        enPolicy.Attributes.Contains("rsa_operationshandlingsite"))
                    {
                        tracingService.Trace("rsa_customerrsa1");
                        if (enPolicy.Attributes.Contains("rsa_operationshandlingsite") && enPolicy.GetAttributeValue<OptionSetValue>("rsa_operationshandlingsite") != null)
                        {
                            enCaseTarget["rsa_caseinitialassignedtosite"] = new OptionSetValue(((OptionSetValue)(enPolicy.Attributes["rsa_operationshandlingsite"])).Value);
                        }
                    }
                    if (enPolicy.Attributes.Contains("rsa_policyhandler"))
                    {
                        tracingService.Trace("rsa_policyhandler");
                        if (!enCaseTarget.Attributes.Contains("rsa_initialassignedtousers") && !enCaseTarget.Attributes.Contains(strDummyFieldName))
                        {
                            tracingService.Trace("rsa_initialassignedtousers");
                            enCaseTarget["rsa_initialassignedtousers"] = ((EntityReference)(enPolicy.Attributes["rsa_policyhandler"])).Name;
                            Entity enUser = caseCommon.GetUserDetails(((EntityReference)(enPolicy.Attributes["rsa_policyhandler"])).Id);
                            if (enUser != null)
                            {
                                if (enUser.Attributes.Contains("rsa_division"))
                                    enCaseTarget["rsa_caseinitialassignedtodivision"] = enUser.Attributes["rsa_division"];
                                //TODO: rsa_caseinitialassignedtoteam is an OptionSet
                                //TODO: rsa_userteamlevel2 is an Lookup
                                //if (enUser.Attributes.Contains("rsa_userteamlevel2"))
                                //enCase["rsa_caseinitialassignedtoteam"] = enUser.Attributes["rsa_userteamlevel2"];
                            }
                        }
                    }
                    enCaseTarget[strDummyFieldName] = "Inserting a Dummy Value";
                    tracingService.Trace("Setting rsa_dummyfieldforrenewals 0");
                }
            }
        }

        #region Update formated text from HTML Bug 2487
        private void setCaseDescriptionAsplainText()
        {
            tracingService.Trace("Entered into setCaseDescriptionAsplainText");
            string caseDescription = enCaseTarget.Attributes.Contains("description") ? enCaseTarget.GetAttributeValue<string>("description") : null;
            string caseDescriptionFormatted = string.Empty;
            tracingService.Trace("caseDescription: " + caseDescription);



            if (caseDescription != null)
            {
                caseDescriptionFormatted = HtmlToPlainText(caseDescription);
                tracingService.Trace("caseDescriptionFormatted: " + caseDescriptionFormatted);
                enCaseTarget["description"] = caseDescriptionFormatted;
                tracingService.Trace("Updated Description");

                #region Populate Total_Client_Premium and Message

                //Populate Total Client Premium from the email to case             
                string TOT_CLIENT_PREM_PATTEREN = @"(?i)Total Client Premium\s*:\s*(\d+(\.\d+)?)";
                Match premiumMatch = Regex.Match(caseDescriptionFormatted, TOT_CLIENT_PREM_PATTEREN);
                if (premiumMatch.Success)
                {
                    decimal totalClientPremium =decimal.Round(Convert.ToDecimal(premiumMatch.Groups[1].Value),2);
                    tracingService.Trace("TOT_CLIENT_PREM_PATTEREN: " + totalClientPremium);
                    enCaseTarget["rsa_totalclientpremium"] = new Money(totalClientPremium);                   
                }


                //Populate Message from the email to case
                string MESSAGE_PATTERN = @"(?i)Message\s*:\s*(.*?)(?i)Refer Reason";
                Regex regex = new Regex(MESSAGE_PATTERN, RegexOptions.Singleline);
                Match messageMatch = regex.Match(caseDescriptionFormatted);              
                
                if (messageMatch.Success)
                {
                    string message = messageMatch.Groups[1].Value.Trim();
                    tracingService.Trace("MESSAGE_PATTERN: " + message);
                    enCaseTarget["rsa_brokermessage"] = message;                 
                    
                    int MessageLength = message.Length;
                    tracingService.Trace("MessageLength: " + MessageLength);
                    if (MessageLength == 0)
                        enCaseTarget["rsa_messagelengthscore"] = 0;
                    else if(MessageLength <= 50)
                        enCaseTarget["rsa_messagelengthscore"] = 14;
                    else if (MessageLength <= 100)
                        enCaseTarget["rsa_messagelengthscore"] = 13;
                    else if (MessageLength <= 150)
                        enCaseTarget["rsa_messagelengthscore"] = 12;
                    else if (MessageLength <= 200)
                        enCaseTarget["rsa_messagelengthscore"] = 11;
                    else if (MessageLength <= 250)
                        enCaseTarget["rsa_messagelengthscore"] = 10;
                    else if (MessageLength <= 300)
                        enCaseTarget["rsa_messagelengthscore"] = 9;
                    else if (MessageLength <= 350)
                        enCaseTarget["rsa_messagelengthscore"] = 8;
                    else if (MessageLength <= 400)
                        enCaseTarget["rsa_messagelengthscore"] = 7;
                    else if (MessageLength <= 450)
                        enCaseTarget["rsa_messagelengthscore"] = 6;
                    else if (MessageLength <= 500)
                        enCaseTarget["rsa_messagelengthscore"] = 5;
                    else if (MessageLength <= 550)
                        enCaseTarget["rsa_messagelengthscore"] = 4;
                    else if (MessageLength <= 600)
                        enCaseTarget["rsa_messagelengthscore"] = 3;
                    else if (MessageLength <= 650)
                        enCaseTarget["rsa_messagelengthscore"] = 2;
                    else if (MessageLength > 650)
                        enCaseTarget["rsa_messagelengthscore"] = 1;
                   

                }

                #endregion

                #region Keywordscore from message
                string brokerMessage = enCaseTarget.GetAttributeValue<string>("rsa_brokermessage");
                if (brokerMessage != null && brokerMessage != string.Empty)
                {
                    Entity Keywordscore = GetCustomLabel(service, tracingService, "PriorityScoreCase");
                    string keywordJSON = string.Empty;

                    if (Keywordscore != null)
                    {
                        if (Keywordscore.Attributes.Contains("rsa_dependentoptionsetjson"))
                        {
                            keywordJSON = Keywordscore.Attributes["rsa_dependentoptionsetjson"].ToString();
                            var isKeywordRoot = new KeywordJSONRoot();
                            var ms = new MemoryStream(Encoding.UTF8.GetBytes(keywordJSON));
                            tracingService.Trace("KeywordJSON " + keywordJSON);
                            try
                            {
                                tracingService.Trace("in Try block ");
                                var ser = new DataContractJsonSerializer(isKeywordRoot.GetType());
                                isKeywordRoot = ser.ReadObject(ms) as KeywordJSONRoot;
                                tracingService.Trace("in Try block set isKeywordRoot");
                            }
                            catch (Exception ex)
                            {
                                throw new InvalidPluginExecutionException(ex.Message);
                            }
                            finally
                            {
                                ms.Close();
                            }
                            tracingService.Trace("Started with JSONCode");
                            KeywordScoreJSON KeywordMap = new KeywordScoreJSON();
                            int keywordcount = 0;
                            foreach (var item in isKeywordRoot.KeywordScoreJSON)
                            {
                                foreach (var keywords in item.keyword)
                                {
                                    
                                    if (Regex.IsMatch(brokerMessage, keywords))
                                    //if (brokerMessage.Contains(keywords))
                                    {
                                        keywordcount = keywordcount + item.keywordscore;
                                        continue;
                                    }
                                }
                            }
                            tracingService.Trace("Keyword score: " + keywordcount);
                            enCaseTarget["rsa_keywordscore"] = keywordcount;
                        }
                    }
                }
                else
                {                  
                    enCaseTarget["rsa_keywordscore"] = 0;
                }
                #endregion
            }
        }

        public static string HtmlToPlainText(string HTMLCode)
        {
            //string text;
            HTMLCode = HTMLCode.Replace("\n", " ");

            // Remove tab spaces
            HTMLCode = HTMLCode.Replace("\t", " ");

            // Remove multiple white spaces from HTML
            HTMLCode = Regex.Replace(HTMLCode, "\\s+", " ");

            // Remove HEAD tag
            HTMLCode = Regex.Replace(HTMLCode, "<head.*?</head>", ""
                                , RegexOptions.IgnoreCase | RegexOptions.Singleline);

            // Remove any JavaScript
            HTMLCode = Regex.Replace(HTMLCode, "<script.*?</script>", ""
              , RegexOptions.IgnoreCase | RegexOptions.Singleline);

            // Replace special characters like &, <, >, " etc.
            StringBuilder sbHTML = new StringBuilder(HTMLCode);
            // Note: There are many more special characters, these are just
            // most common. You can add new characters in this arrays if needed
            string[] OldWords = {"&nbsp;", "&amp;", "&quot;", "&lt;",
   "&gt;", "&reg;", "&copy;", "&bull;", "&trade;","&#39;"};
            string[] NewWords = { " ", "&", "\"", "<", ">", "Â®", "Â©", "â€¢", "â„¢", "\'" };
            for (int i = 0; i < OldWords.Length; i++)
            {
                sbHTML.Replace(OldWords[i], NewWords[i]);
            }

            // Check if there are line breaks (<br>) or paragraph (<p>)
            sbHTML.Replace("<br>", "\n<br>");
            sbHTML.Replace("<br ", "\n<br ");
            sbHTML.Replace("<p ", "\n<p ");
            sbHTML.Replace("<br>", "");
            // Finally, remove all HTML tags and return plain text
            return System.Text.RegularExpressions.Regex.Replace(
              sbHTML.ToString(), "<[^>]*>", "");

            //return htmlString;
        }
        #endregion
        private Entity GetCustomLabel(IOrganizationService service, ITracingService tracer, string key)
        {
            Entity returnValue = null;
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' no-lock='true'>
                              <entity name='rsa_customlabel'>
                                <attribute name='rsa_values' />
                                <attribute name='rsa_shortdescription' />
                                <attribute name='rsa_categories' />   
                                <attribute name='rsa_dependentoptionsetjson'/>
                                <filter type='and'>
                                  <condition attribute='rsa_name' operator='eq' value ='{0}'/>
                                </filter>
                              </entity>
                            </fetch>";
            var entityCustomLevel = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, key)));
            if (entityCustomLevel.Entities.Count > 0)
            {
                
                returnValue = entityCustomLevel.Entities[0];
            }
            return returnValue;
        }
        [DataContract]
        public class KeywordJSONRoot
        {
            [DataMember]
            public List<KeywordScoreJSON> KeywordScoreJSON { get; set; }
        }
        [DataContract]
        public class KeywordScoreJSON
        {
            [DataMember]
            public int keywordscore { get; set; }
            [DataMember]
            public List<string> keyword { get; set; }
        }
    }
}