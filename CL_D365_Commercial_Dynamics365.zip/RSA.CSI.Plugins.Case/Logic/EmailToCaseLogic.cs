﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using RSA.CSI.Plugins.Case.CaseCommon;
using RSA.CSI.Plugins.Case.Helper;


namespace RSA.CSI.Plugins.Case.Logic
{
    internal class EmailToCaseLogic
    {
        IOrganizationService service = null;
        ITracingService tracingService = null;
        Entity enCaseTarget = null;
        Entity enCasePreImage = null;
        Guid guidCallingUserId = Guid.Empty;

        #region Constructor 
        internal EmailToCaseLogic(IOrganizationService cService, ITracingService cTracingService, Entity cEnCaseTarget, Entity cEntityCasePreImage)
        {
            service = cService;
            tracingService = cTracingService;
            enCaseTarget = cEnCaseTarget;
            enCasePreImage = cEntityCasePreImage;
        }
        #endregion Constructor

        #region Constants
        /// <summary>
        /// Code for UKRIS
        /// </summary>
        private const int SOURCE_SYSTEM_UKRIS_ID = 866760001;
        /// <summary>
        /// string for UKRIS
        /// </summary>
        private const string SOURCE_SYSTEM_UKRIS = "UKRIS";
        /// <summary>
        /// string for P and L = SME
        /// </summary>
        private const string P_AND_L_SME = "SME";
        /// <summary>
        /// string for COB = Extranet
        /// </summary>
        private const string COB_EXTRANET = "Extranet";

        #region REGEX PATTERNS
        private const string RX_POLICY_NUMBER = "Policy Number";
        private const string RX_POLICY_NUMBER_PATTERN = "(?m)Policy Number\\s*:\\s*([a-zA-Z0-9@.]\\s?)*(.*?)$";
        private const string RX_CLIENT_NAME = "Client Name";
        private const string RX_CLIENT_NAME_PATTERN = "(?m)Client Name\\s*:\\s*([a-zA-Z0-9@.]\\s?)*(.*?)$";
        private const string RX_CLIENT_POSTCODE = "Client Postcode";
        private const string RX_CLIENT_POSTCODE_PATTERN = "(?m)Client Postcode\\s*:\\s*([a-zA-Z0-9@.]\\s?)*(.*?)$";
        private const string RX_REFER_REASON = "Refer Reason";
        private const string RX_REFER_REASON_PATTEREN = "(?m)Refer Reason\\s*:\\s*([a-zA-Z0-9@.:\\s*)]\\s?)*(.*?)$";
        private const string RX_BROKER_AGENCY_NUMNER = "Broker Agency Number";
        private const string RX_BROKER_AGENCY_NUMNER_PATTEREN = "(?m)Broker Agency Number\\s*:\\s*([a-zA-Z0-9@.]\\s?)*(.*?)$";
        private const string RX_BROKER_CONTACT_NAME = "Broker Contact Name";
        private const string RX_BROKER_CONTACT_NAME_PATTEREN = "(?m)Broker Contact Name\\s*:\\s*([a-zA-Z0-9@.]\\s?)*(.*?)$";
        private const string RX_BROKER_TEL_NO = "Broker Telephone Number";
        private const string RX_BROKER_TEL_NO_PATTEREN = "(?m)Broker Telephone Number\\s*:\\s*([a-zA-Z0-9@.]\\s?)*(.*?)$";
        private const string RX_BROKER_EMAIL = "Broker Email";
        private const string RX_BROKER_EMAIL_PATTEREN = "(?m)Broker Email\\s*:\\s*([a-zA-Z0-9@.]\\s?)*(.*?)$";
        private const string RX_CLIENT_REF = "Client Ref";
        private const string RX_CLIENT_REF_PATTEREN = "(?m)Client Ref\\s*:\\s*([a-zA-Z0-9@.]\\s?)*(.*?)$";
        private const string RX_QUOTE_REF = "Quote Ref";
        private const string RX_QUOTE_REF_PATTEREN = "(?m)Quote Ref\\s*:\\s*([a-zA-Z0-9@.]\\s?)*(.*?)$";
        private const string RX_VERSION_REF = "Version Ref";
        private const string RX_VERSION_REF_PATTEREN = "(?m)Version Ref\\s*:\\s*([a-zA-Z0-9@.]\\s?)*(.*?)$";
        private const string RX_PRODUCT = "Product";
        private const string RX_PRODUCT_PATTEREN = "(?m)Product\\s*:\\s*([a-zA-Z0-9@.]\\s?)*(.*?)$";
        private const string RX_TOT_CLIENT_PREM = "Total Client Premium";
        private const string RX_TOT_CLIENT_PREM_PATTEREN = "(?m)Total Client Premium\\s*:\\s*([a-zA-Z0-9@.]\\s?)*(.*?)$";
        private const string RX_MESSAGE = "Message";
        private const string RX_MESSAGE_PATTEREN = "(?m)Message\\s*:\\s*([a-zA-Z0-9@.!]\\s?)*(.*?)$";
        #endregion REGEX PATTERNS

        #endregion Constants

        /// <summary>
        /// Email Template Email to Case - parsing
        /// </summary>
        internal void SMEEmailTemplate()
        {
            tracingService.Trace("Start SMEEmailTemplate()");
            string strCaseDescription = string.Empty;
            if (enCaseTarget.Attributes.Contains("description"))
            {
                strCaseDescription = enCaseTarget.Attributes["description"].ToString();
            }
            else if (enCasePreImage.Attributes.Contains("description"))
            {
                strCaseDescription = enCasePreImage.Attributes["description"].ToString();
            }
            if (String.IsNullOrEmpty(strCaseDescription))
            {
                tracingService.Trace("There is no information available in case description.");
                return;
            }
            //enCasePreImage.Attributes["description"] = "Contact request received regarding a referred quotation: Quote Ref: 92278922, Refer Reason: EA1093 Claims, Total Client Premium: 345, Client Name: Arnolds Haulage, Client Postcode: HR7 7TY, Client Ref: 7143956, Broker Email: shaun@squaremilebroking.com<mailto:shaun@squaremilebroking.com>, Broker Name: Square Mile Broking Ltd, Broker Agency Number: AT789, Broker Contact Name: Shaun Stevens, Broker Telephone Number: 0844 561 6075, RSA Region: Chesham, Company Name: Square Mile Broking Ltd, Contact First name: Contact Surname:, Phone Number:, Message: Please could you confirm terms ASAP as policy due tomorrow, Policy Number: RSAP1234567883,";
            Dictionary<string, string> dicRgx = new Dictionary<string, string>();
            dicRgx.Add(RX_POLICY_NUMBER, RX_POLICY_NUMBER_PATTERN);
            dicRgx.Add(RX_CLIENT_NAME, RX_CLIENT_NAME_PATTERN);
            dicRgx.Add(RX_CLIENT_POSTCODE, RX_CLIENT_POSTCODE_PATTERN);
            dicRgx.Add(RX_REFER_REASON, RX_REFER_REASON_PATTEREN);
            dicRgx.Add(RX_BROKER_AGENCY_NUMNER, RX_BROKER_AGENCY_NUMNER_PATTEREN);
            dicRgx.Add(RX_BROKER_CONTACT_NAME, RX_BROKER_CONTACT_NAME_PATTEREN);
            dicRgx.Add(RX_BROKER_TEL_NO, RX_BROKER_TEL_NO_PATTEREN);
            dicRgx.Add(RX_BROKER_EMAIL, RX_BROKER_EMAIL_PATTEREN);
            dicRgx.Add(RX_CLIENT_REF, RX_CLIENT_REF_PATTEREN);
            dicRgx.Add(RX_QUOTE_REF, RX_QUOTE_REF_PATTEREN);
            dicRgx.Add(RX_VERSION_REF, RX_VERSION_REF_PATTEREN);
            dicRgx.Add(RX_PRODUCT, RX_PRODUCT_PATTEREN);
            dicRgx.Add(RX_TOT_CLIENT_PREM, RX_TOT_CLIENT_PREM_PATTEREN);
            dicRgx.Add(RX_MESSAGE, RX_MESSAGE_PATTEREN);
            var enPolicy = new Entity("rsa_policy");

            Regex regex;
            Match match;
            var intStartPolicyIdx = -1;
            var intStrEndPolicyIdx = -1;
            var strMatchedString = string.Empty;
            var strPolicyNumber = string.Empty;
            var strClientName = string.Empty;
            var strClientPostCode = string.Empty;
            var strPolicyKey = string.Empty;
            var strBrokerNameRetrieved = string.Empty;
            var guidBrokerIdRetrieved = Guid.Empty;
            var strCustomerNameRetrieved = string.Empty;
            var guidCustomerIdRetrieved = Guid.Empty;
            var strPolicyNameRetrieved = string.Empty;
            var guidPolicyIdRetrieved = Guid.Empty;
            var strReferReason = string.Empty;
            var strBrokerAgencyNumber = string.Empty;
            var strBrokerContactName = string.Empty;
            var strBrokerTelNo = string.Empty;
            var strBrokerEmail = string.Empty;
            var strClientRef = string.Empty;
            var strQuoteRef = string.Empty;
            var strVersionRef = string.Empty;
            var strProduct = string.Empty;
            decimal dTotalClientPrem = 0;
            var strMessage = string.Empty;
            var bPolicyNotFound = true;
            var bBrokerNotFound = false;
            var bContactNotFound = true;
            Guid guidBrokerRetrieveFromAgencyCode = Guid.Empty;
            Guid guidContactId = Guid.Empty;
            tracingService.Trace("Case Description in SMEEmailTemplate(): " + strCaseDescription);
            foreach (var dicItem in dicRgx)
            {
                try
                {
                    regex = new Regex(dicItem.Value);
                    //match = regex.Match(strCaseDescription);
                    //if (match.Success)
                    if (regex.IsMatch(strCaseDescription))
                    {
                        foreach (Match patMatch in regex.Matches(strCaseDescription))
                        {
                            //string[] strSplitted = patMatch.Value.Split(new char[':'], 2);
                            string[] strSplitted = patMatch.Value.Split(':');
                            if (strSplitted.Length >= 2)
                            {
                                intStartPolicyIdx = strSplitted[1].Trim().IndexOf(strSplitted[1], 0) + 1;
                                intStrEndPolicyIdx = strSplitted[1].Trim().IndexOf(',');
                                if (intStartPolicyIdx >= 0 && intStrEndPolicyIdx >= 0)
                                    strMatchedString = strSplitted[1].Trim().Substring(intStartPolicyIdx, intStrEndPolicyIdx).Trim();
                                else
                                    strMatchedString = strSplitted[1].Trim();
                                if (dicItem.Key.Equals(RX_POLICY_NUMBER))
                                {
                                    strPolicyNumber = strMatchedString;
                                    tracingService.Trace(RX_POLICY_NUMBER + " : " + strMatchedString);
                                }
                                else if (dicItem.Key.Equals(RX_CLIENT_NAME))
                                {
                                    strClientName = strMatchedString;
                                    tracingService.Trace(RX_CLIENT_NAME + " : " + strMatchedString);
                                }
                                else if (dicItem.Key.Equals(RX_CLIENT_POSTCODE))
                                {
                                    strClientPostCode = strMatchedString;
                                    tracingService.Trace(RX_CLIENT_POSTCODE + " : " + strMatchedString);
                                }
                                else if (dicItem.Key.Equals(RX_REFER_REASON))
                                {
                                    strReferReason = strMatchedString;
                                    enCaseTarget["rsa_referreason"] = strMatchedString;
                                    tracingService.Trace(RX_REFER_REASON + " : " + strMatchedString);
                                }
                                else if (dicItem.Key.Equals(RX_BROKER_AGENCY_NUMNER))
                                {
                                    strBrokerAgencyNumber = strMatchedString;
                                    tracingService.Trace(RX_BROKER_AGENCY_NUMNER + " : " + strMatchedString);
                                }
                                else if (dicItem.Key.Equals(RX_BROKER_CONTACT_NAME))
                                {
                                    strBrokerContactName = strMatchedString;
                                    tracingService.Trace(RX_BROKER_CONTACT_NAME + " : " + strMatchedString);
                                }
                                else if (dicItem.Key.Equals(RX_BROKER_TEL_NO))
                                {
                                    strBrokerTelNo = strMatchedString.Replace("\\s", "");
                                    tracingService.Trace(RX_BROKER_TEL_NO + " : " + strMatchedString);
                                }
                                else if (dicItem.Key.Equals(RX_BROKER_EMAIL))
                                {
                                    strBrokerEmail = strMatchedString.Replace("<([a-zA-Z0-9@.:]+\\s?)*>", "");
                                    tracingService.Trace(RX_BROKER_EMAIL + " : " + strMatchedString);
                                }
                                else if (dicItem.Key.Equals(RX_CLIENT_REF))
                                {
                                    strClientRef = strMatchedString;
                                    enCaseTarget["rsa_clientref"] = strMatchedString;
                                    tracingService.Trace(RX_CLIENT_REF + " : " + strMatchedString);
                                }
                                else if (dicItem.Key.Equals(RX_QUOTE_REF))
                                {
                                    strQuoteRef = strMatchedString;
                                    enCaseTarget["rsa_quotereference"] = strMatchedString;
                                    tracingService.Trace(RX_QUOTE_REF + " : " + strMatchedString);
                                }
                                else if (dicItem.Key.Equals(RX_VERSION_REF))
                                {
                                    strVersionRef = strMatchedString;
                                    enCaseTarget["rsa_versionref"] = strMatchedString;
                                    tracingService.Trace(RX_VERSION_REF + " : " + strMatchedString);
                                }
                                else if (dicItem.Key.Equals(RX_PRODUCT))
                                {
                                    strProduct = strMatchedString;
                                    enCaseTarget["rsa_productholder"] = strMatchedString;
                                    tracingService.Trace(RX_PRODUCT + " : " + strMatchedString);
                                }
                                else if (dicItem.Key.Equals(RX_TOT_CLIENT_PREM))
                                {
                                    dTotalClientPrem = Convert.ToDecimal(strMatchedString);
                                    enCaseTarget["rsa_totalclientpremium"] = new Money(dTotalClientPrem);
                                    tracingService.Trace(RX_TOT_CLIENT_PREM + " : " + strMatchedString);
                                }
                                else if (dicItem.Key.Equals(RX_MESSAGE))
                                {
                                    strMessage = strMatchedString;
                                    enCaseTarget["rsa_brokermessage"] = strMatchedString;
                                    tracingService.Trace(RX_MESSAGE + " : " + strMatchedString);
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    tracingService.Trace("Exception while fetching matched items: " + ex.Message);
                }
            }
            if (!String.IsNullOrEmpty(strPolicyNumber))
            {
                //generate policy key
                strPolicyKey = SOURCE_SYSTEM_UKRIS + ":" + strPolicyNumber;
                tracingService.Trace("PolicyNumber contains data and PolicyKey: " + strPolicyKey);
                enPolicy = this.GetPolicyDetailsByPolicyKey(strPolicyKey);
                if (enPolicy != null)
                {
                    tracingService.Trace("Policy contains data");
                    bPolicyNotFound = false;
                    enCaseTarget["rsa_policyid"] = new EntityReference("rsa_policy", enPolicy.Id);
                    if (enPolicy.Attributes.Contains("rsa_broker"))
                    {
                        bBrokerNotFound = false;
                        strBrokerNameRetrieved = ((EntityReference)enPolicy.Attributes["rsa_broker"]).Name;
                        guidBrokerIdRetrieved = ((EntityReference)enPolicy.Attributes["rsa_broker"]).Id;
                        enCaseTarget["rsa_account"] = new EntityReference("account", guidBrokerIdRetrieved);
                    }
                    if (enPolicy.Attributes.Contains("rsa_customer"))
                    {
                        strCustomerNameRetrieved = ((EntityReference)enPolicy.Attributes["rsa_customer"]).Name;
                        guidCustomerIdRetrieved = ((EntityReference)enPolicy.Attributes["rsa_customer"]).Id;
                        enCaseTarget["rsa_customerrsa"] = new EntityReference("rsa_customer", guidCustomerIdRetrieved);
                    }
                    //if (enPolicy.Attributes.Contains("rsa_name"))
                    //{
                    //    strPolicyNameRetrieved = enPolicy.Attributes["rsa_name"].ToString();
                    //    guidPolicyIdRetrieved = enPolicy.Id;
                    //    enCaseTarget["rsa_brokermessage"] = strMatchedString;
                    //}
                }
                else
                {
                    tracingService.Trace("Policy doesn't exist with policy key :" + strPolicyKey);
                    var enPolicyToBeInserted = new Entity("rsa_policy");
                    enPolicyToBeInserted["rsa_name"] = strPolicyNumber;
                    enPolicyToBeInserted["rsa_policysystemcode"] = new OptionSetValue(SOURCE_SYSTEM_UKRIS_ID);
                    enPolicyToBeInserted["rsa_premium"] = new Money(dTotalClientPrem);
                    tracingService.Trace("rsa_name :" + strPolicyNumber);
                    tracingService.Trace("rsa_policysystemcode :" + SOURCE_SYSTEM_UKRIS_ID);
                    tracingService.Trace("rsa_premium :" + dTotalClientPrem.ToString());
                    Guid guidPAndLId = this.GetPAndLByName(P_AND_L_SME);
                    tracingService.Trace("guidPAndLId :" + guidPAndLId.ToString());
                    if (guidPAndLId != Guid.Empty)
                        enPolicyToBeInserted["rsa_plcode"] = new EntityReference("rsa_pl", guidPAndLId);
                    Guid guidCOBId = this.GeCOBByName(COB_EXTRANET);
                    if (guidCOBId != Guid.Empty)
                       enPolicyToBeInserted["rsa_classofbusiness"] = new EntityReference("rsa_classofbusiness", guidCOBId);
                    try
                    {
                        if (!String.IsNullOrEmpty(strProduct))
                        {
                            tracingService.Trace("strProduct contain value :" + strProduct);
                            Guid guidProductId = this.GetProductByName(strProduct);
                            if (guidProductId != Guid.Empty)
                            {
                                tracingService.Trace("guidProductId not empty");
                                enPolicyToBeInserted["rsa_productid"] = new EntityReference("rsa_product", guidProductId);
                                Guid guidPolicyCreated = service.Create(enPolicyToBeInserted);
                                tracingService.Trace("Created Policy");
                                if (guidPolicyCreated != null && guidPolicyCreated != Guid.Empty)
                                    enCaseTarget["rsa_policyid"] = new EntityReference("rsa_policy", guidPolicyCreated);
                            }
                            else
                            {
                                tracingService.Trace("guidProductId empty");
                            }
                        }

                    }
                    catch (Exception ex)
                    {
                        tracingService.Trace("Exception while policy creation: " + ex.Message);
                    }
                }
            }
            else
            {
                tracingService.Trace("Policy Numeber is blank.");
            }
            //Search broker in Agency code
            if (bPolicyNotFound && !String.IsNullOrEmpty(strBrokerAgencyNumber))
            {
                tracingService.Trace("Policy not found and Agency Number contains data");
                var enBroker = this.GetBrokerAgencyByNumber(strBrokerAgencyNumber);
                if (enBroker != null)
                {
                    bBrokerNotFound = false;
                    enCaseTarget["rsa_account"] = enBroker["rsa_agency"];
                    guidBrokerRetrieveFromAgencyCode = enBroker.Id;
                }
            }
            else
            {
                tracingService.Trace("Policy found and Agency Number not contains data");
                guidBrokerRetrieveFromAgencyCode = guidBrokerIdRetrieved;
            }
            // create contact 
            if ((bPolicyNotFound && !bBrokerNotFound) && !String.IsNullOrEmpty(strPolicyNameRetrieved))
            {
                if (!String.IsNullOrEmpty(strBrokerEmail) && guidBrokerIdRetrieved != Guid.Empty)
                {
                    var enContact = this.GetContactDetailsByEmail(guidBrokerIdRetrieved, strBrokerEmail);
                    if (enContact != null)
                    {
                        tracingService.Trace("enContact contains data");
                        bContactNotFound = false;
                        guidContactId = enContact.Id;
                    }
                    else
                    {
                        var enContactToBeCreated = new Entity("contact");
                        tracingService.Trace("enContact not contains data");
                        if (!String.IsNullOrEmpty(strBrokerContactName))
                        {
                            tracingService.Trace("strBrokerContactName contains data");
                            string[] strArrBrokerContactName = strBrokerContactName.Split(' ');
                            if (strArrBrokerContactName.Length == 2)
                            {
                                enContactToBeCreated["firstname"] = strArrBrokerContactName[0];
                                enContactToBeCreated["lastname"] = strArrBrokerContactName[1];
                                tracingService.Trace("Broker Contact first name :" + strArrBrokerContactName[0] + "Broker Contact last name : " + strArrBrokerContactName[1]);
                            }
                            if (strArrBrokerContactName.Length == 3)
                            {
                                enContactToBeCreated["firstname"] = strArrBrokerContactName[0];
                                enContactToBeCreated["lastname"] = strArrBrokerContactName[2];
                                tracingService.Trace("Broker Contact first name :" + strArrBrokerContactName[0] + "Broker Contact last name : " + strArrBrokerContactName[1]);
                            }
                        }
                        if (!String.IsNullOrEmpty(strBrokerTelNo))
                        {
                            enContactToBeCreated["telephone2"] = strBrokerTelNo;
                            enContactToBeCreated["mobilephone"] = strBrokerTelNo;
                            tracingService.Trace("Broker Contact tel no. :" + strBrokerTelNo + "Broker Contact mobile no : " + strBrokerTelNo);
                        }
                        if (!String.IsNullOrEmpty(strBrokerEmail))
                        {
                            enContactToBeCreated["emailaddress1"] = strBrokerEmail;
                            tracingService.Trace("Broker Contact email address. :" + strBrokerEmail);
                        }
                        if (guidBrokerRetrieveFromAgencyCode != Guid.Empty)
                        {
                            enContactToBeCreated["rsa_accountid"] = new EntityReference("contact", guidBrokerRetrieveFromAgencyCode);
                            tracingService.Trace("Populating rsa_accountid with broker retrieved from agency code: " + guidBrokerRetrieveFromAgencyCode.ToString());
                        }
                        try
                        {
                            enCaseTarget["primarycontactid"] = new EntityReference("contact", service.Create(enContactToBeCreated));
                            tracingService.Trace("Successfully created contact.");
                        }
                        catch (Exception ex)
                        {
                            tracingService.Trace("Unable to create contact: " + ex.Message);
                        }
                    }
                }
                else
                {
                    tracingService.Trace("Unable to retrieve broker id and email( from case description).");
                }
            }

            if (bPolicyNotFound)
            {
                tracingService.Trace("Calling CallSearchCustomerDedupe() as policy not found");
                tracingService.Trace("Parameter- Customer: " + strClientName);
                tracingService.Trace("Parameter- postcode: " + strClientPostCode);
                this.CallSearchCustomerDedupe(strClientName, strClientPostCode);
            }

            tracingService.Trace("Exiting SMEEmailTemplate()");
        }


        /// <summary>
        /// Get contact details by broker email, id
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="guidBrokerId"></param>
        /// <param name="strBrokerEmail"></param>
        /// <returns></returns>
        private Entity GetContactDetailsByEmail(Guid guidBrokerId, string strBrokerEmail)
        {
            Entity enContact = null;
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' no-lock='true'>
                                  <entity name='contact'>
                                    <attribute name='fullname' />
                                    <attribute name='telephone1' />
                                    <attribute name='contactid' />
                                    <attribute name='mobilephone' />
                                    <attribute name='lastname' />
                                    <attribute name='telephone2' />
                                    <attribute name='firstname' />
                                    <attribute name='emailaddress1' />
                                    <attribute name='rsa_accountid' />
                                    <attribute name='rsa_agencyid' />
                                    <order attribute='fullname' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='rsa_accountid' operator='eq' value='{0}' />
                                      <condition attribute='emailaddress1' operator='eq' value='{1}' />
                                    </filter>
                                  </entity>
                                </fetch>";
            try
            {
                var enColContact = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, guidBrokerId, strBrokerEmail)));
                if (enColContact != null && enColContact.Entities.Count > 0)
                    enContact = enColContact.Entities[0];
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception in GetContactDetails: " + ex.Message);
            }
            return enContact;
        }

        /// <summary>
        /// Get broker from agency code
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="strBrokerAgencyCodeNumber"></param>
        /// <returns></returns>
        private Entity GetBrokerFromAgencyCode(string strBrokerAgencyCodeNumber)
        {
            Entity enAgencyCode = null;
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' no-lock='true'>
                                  <entity name='rsa_agencycode'>
                                    <attribute name='rsa_agencycodeid' />
                                    <attribute name='rsa_name' />
                                    <attribute name='createdon' />
                                    <attribute name='rsa_policysystem' />
                                    <attribute name='rsa_agencyreference' />
                                    <attribute name='rsa_agencycodekey' />
                                    <attribute name='rsa_agency' />
                                    <order attribute='rsa_name' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='rsa_name' operator='eq' value='{0}' />
                                    </filter>
                                  </entity>
                                </fetch>";
            try
            {
                var enColAgencyCode = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, strBrokerAgencyCodeNumber)));
                if (enColAgencyCode != null && enColAgencyCode.Entities.Count > 0)
                    enAgencyCode = enColAgencyCode.Entities[0];
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception in GetBrokerFromAgencyCode: " + ex.Message);
            }
            return enAgencyCode;
        }

        /// <summary>
        /// Search for customer exists 
        /// </summary>
        /// <param name="strClientName"></param>
        /// <param name="strClientPostCode"></param>
        private void CallSearchCustomerDedupe(string strClientName, string strClientPostCode)
        {
            if (!String.IsNullOrEmpty(strClientName))
            {
                tracingService.Trace("Calling SearchCustomer()");
                this.SearchCustomer(strClientName, strClientPostCode);
                tracingService.Trace("Exiting CallSearchCustomerDedupe()");
            }
            else
            {
                tracingService.Trace("strClientName is null");
            }
        }

        /// <summary>
        /// Get PandL guid by name
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="strPAndLName"></param>
        /// <returns></returns>
        private Guid GetPAndLByName(string strPAndLName)
        {
            var guidPandLId = Guid.Empty;
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' no-lock='true'>
                              <entity name='rsa_pl'>
                                <attribute name='rsa_name' />
                                <attribute name='createdon' />
                                <attribute name='rsa_lineofbusiness' />
                                <attribute name='rsa_plid' />
                                <order attribute='rsa_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='rsa_name' operator='eq' value='{0}' />
                                </filter>
                              </entity>
                            </fetch>";
            try
            {
                var enColPAndL = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, strPAndLName)));
                if (enColPAndL != null && enColPAndL.Entities.Count > 0)
                {
                    guidPandLId = enColPAndL.Entities[0].Id;
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception in GetPAndLByName: " + ex.Message);
            }
            return guidPandLId;
        }
        /// <summary>
        /// Get COB guid by name
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="strCOB"></param>
        /// <returns></returns>
        private Guid GeCOBByName(string strCOB)
        {
            var guidCOBId = Guid.Empty;
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' no-lock='true'>
                              <entity name='rsa_classofbusiness'>
                                <attribute name='rsa_name' />
                                <attribute name='createdon' />
                                <attribute name='rsa_pl' />
                                <attribute name='rsa_description' />
                                <attribute name='rsa_lineofbusiness' />
                                <attribute name='rsa_classofbusinessid' />
                                <order attribute='rsa_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='rsa_name' operator='eq' value='{0}' />
                                </filter>
                              </entity>
                            </fetch>";
            try
            {
                var enColCOB = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, strCOB)));
                if (enColCOB != null && enColCOB.Entities.Count > 0)
                {
                    guidCOBId = enColCOB.Entities[0].Id;
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception in GeCOBByName: " + ex.Message);
            }
            return guidCOBId;
        }

        /// <summary>
        /// Get productid by product name
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="strProduct"></param>
        /// <returns></returns>
        private Guid GetProductByName(string strProduct)
        {
            var guidProductId = Guid.Empty;
            strProduct = strProduct.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;");
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' no-lock='true'>
                              <entity name='rsa_product'>
                                <attribute name='rsa_name' />
                                <attribute name='createdon' />
                                <attribute name='rsa_pandlid' />
                                <attribute name='rsa_lineofbusiness' />
                                <attribute name='rsa_classofbusinessid' />
                                <attribute name='rsa_productid' />
                                <order attribute='rsa_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='rsa_name' operator='eq' value='{0}' />
                                </filter>
                              </entity>
                            </fetch>";
            try
            {
                var enColProduct = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, strProduct)));
                if (enColProduct != null && enColProduct.Entities.Count > 0)
                {
                    guidProductId = enColProduct.Entities[0].Id;
                }
                return guidProductId;
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception in GetProductByName: " + ex.Message);
            }
            return guidProductId;
        }

        /// <summary>
        /// Get Agency code by broker Agency Numner (rsa_name)
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="brokerAgencyNumber"></param>
        /// <returns></returns>
        private Entity GetBrokerAgencyByNumber(string brokerAgencyNumber)
        {
            Entity enBroker = null;
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' no-lock='true'>
                                  <entity name='rsa_agencycode'>
                                    <attribute name='rsa_agencycodeid' />
                                    <attribute name='rsa_name' />
                                    <attribute name='createdon' />
                                    <attribute name='rsa_policysystem' />
                                    <attribute name='rsa_agencyreference' />
                                    <attribute name='rsa_agencycodekey' />
                                    <attribute name='rsa_agency' />
                                    <order attribute='rsa_name' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='rsa_name' operator='eq' value='{0}' />
                                    </filter>
                                  </entity>
                                </fetch>";
            try
            {
                var enColPolicy = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, brokerAgencyNumber)));
                if (enColPolicy != null && enColPolicy.Entities.Count > 0)
                {
                    enBroker = enColPolicy.Entities[0];
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception in GetBrokerAgencyByNumber: " + ex.Message);
            }
            return enBroker;
        }
        private Entity GetPolicyDetailsByPolicyKey(string strPolicyKey)
        {
            Entity enPolicy = null;
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' no-lock='true'>
                                  <entity name='rsa_policy'>
                                    <attribute name='rsa_policyid' />
                                    <attribute name='rsa_name' />
                                    <attribute name='createdon' />
                                    <attribute name='rsa_customer' />
                                    <attribute name='rsa_broker' />
                                    <order attribute='rsa_name' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='rsa_policykey' operator='eq' value='{0}' />
                                    </filter>
                                  </entity>
                                </fetch>";
            try
            {
                var enColPolicy = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, strPolicyKey)));
                if (enColPolicy != null && enColPolicy.Entities.Count > 0)
                {
                    enPolicy = enColPolicy.Entities[0];
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception in GetPolicyDetailsByPolicyKey: " + ex.Message);
            }
            return enPolicy;
        }

        /// <summary>
        /// Free format email processing 
        /// </summary>
        internal void SMEFreeFormat()
        {
            tracingService.Trace("Start SMEFreeFormat()");

            RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon = new RSA.CSI.Plugins.Case.CaseCommon.CaseCommon(service, tracingService);
            string[] strArrRegx = caseCommon.GetCustomLabel("CL0027_SME_FreeFormat_EmailParsing").Split(',');
            string strPAndL = caseCommon.GetCustomLabel("CL_Free_Format_P_L");
            string strCOB = caseCommon.GetCustomLabel("CL_Free_Format_Class_Of_Business");
            Regex regex;
            Match match;
            var intStartPolicyIdx = -1;
            var intStrEndPolicyIdx = -1;
            var strMatchedString = string.Empty;
            var bIsMatchedSubject = false;
            var bIsMatchedDesc = false;
            var strEdiPolicyNumber = string.Empty;
            var strNonEdiPolicyNumber = string.Empty;
            //enCasePreImage.Attributes["rsa_subject"] = "Refer Renewal / Birmingham / Dexters Supplies / 7156438";
            //enCasePreImage.Attributes["description"] = "Contact request received regarding a referred quotation: Quote Ref: 92278922, Refer Reason: EA1093 Claims, Total Client Premium: 345, Client Name: Arnolds Haulage, Client Postcode: HR7 7TY, Client Ref: 7143956, Broker Email: shaun@squaremilebroking.com<mailto:shaun@squaremilebroking.com>, Broker Name: Square Mile Broking Ltd, Broker Agency Number: AT789, Broker Contact Name: Shaun Stevens, Broker Telephone Number: 0844 561 6075, RSA Region: Chesham, Company Name: Square Mile Broking Ltd, Contact First name: Contact Surname:, Phone Number:, Message: Please could you confirm terms ASAP as policy due tomorrow, Policy Number: RSAP1234567883,";
            var strCaseSubject = string.Empty;

            if (enCaseTarget.Attributes.Contains("rsa_subject"))
            {
                strCaseSubject = enCaseTarget.Attributes["rsa_subject"].ToString();
            }

            else if (enCasePreImage.Attributes.Contains("rsa_subject"))
            {
                strCaseSubject = enCasePreImage.Attributes["rsa_subject"].ToString();
            }
            if (String.IsNullOrEmpty(strCaseSubject))
            {
                tracingService.Trace("There is no information available in case subject.");
            }
            tracingService.Trace("Subject contains data");
            if (!String.IsNullOrEmpty(strCaseSubject))
            {
                foreach (var strRgx in strArrRegx)
                {
                    if (bIsMatchedSubject) break;
                    regex = new Regex(strRgx);
                    match = regex.Match(strCaseSubject);
                    if (regex.IsMatch(strCaseSubject))
                    {
                        foreach (Match patMatch in regex.Matches(strCaseSubject))
                        {
                            strMatchedString = patMatch.Value.Trim();
                            if (!String.IsNullOrEmpty(patMatch.Value.Trim()))
                            {
                                bIsMatchedSubject = true;
                                tracingService.Trace("bIsMatchedSubject set to true");
                                break;
                            }
                        }
                    }
                }
            }
            if ((!bIsMatchedSubject && enCaseTarget.Attributes.Contains("description") &&
                !String.IsNullOrEmpty(enCaseTarget.Attributes["description"].ToString())) ||
                (!bIsMatchedSubject && enCasePreImage.Attributes.Contains("description") &&
                !String.IsNullOrEmpty(enCasePreImage.Attributes["description"].ToString())))
            {
                tracingService.Trace("bIsMatchedSubject is false and Description contains data");
                string strCaseDesc = string.Empty;
                if (enCaseTarget.Attributes.Contains("description"))
                {
                    strCaseDesc = enCaseTarget.Attributes["description"].ToString();
                }
                else if (enCasePreImage.Attributes.Contains("description"))
                {
                    strCaseDesc = enCasePreImage.Attributes["description"].ToString();
                }
                if (String.IsNullOrEmpty(strCaseDesc))
                {
                    tracingService.Trace("There is no information available in case description.");
                }

                foreach (var strRgx in strArrRegx)
                {
                    if (bIsMatchedDesc) break;
                    regex = new Regex(strRgx);
                    match = regex.Match(strCaseDesc);
                    if (regex.IsMatch(strCaseDesc))
                    {
                        foreach (Match patMatch in regex.Matches(strCaseDesc))
                        {
                            strMatchedString = patMatch.Value.Trim();
                            if (!String.IsNullOrEmpty(patMatch.Value.Trim()))
                            {
                                tracingService.Trace("bIsMatchedDesc set to true");
                                bIsMatchedDesc = true;
                                break;
                            }
                        }
                    }
                }
            }
            // Case updation while no policy number match in Email
            string caseOrigin = string.Empty;
            if (enCaseTarget.Contains("caseorigincode")) { 
             caseOrigin = enCaseTarget.FormattedValues["caseorigincode"];
        }
            if (caseOrigin.Contains("Email")&& !string.IsNullOrEmpty(caseOrigin)) { 
            if (bIsMatchedSubject == bIsMatchedDesc)//email to case (Subject and description)
            {
                tracingService.Trace("bIsMatchedSubject and bIsMatchedDesc is false");
                //'No Policy Number in Email'
                enCaseTarget["rsa_policymatchstatus"] = new OptionSetValue((int)RSAEnum.OPS_Case_rsa_policymatchstatus.NoPolicyNumberinEmail);
                var enStatus = caseCommon.GetStatusIdByName("Initial Processing");
                if (enStatus != null && enStatus.Id != Guid.Empty)
                {
                    enCaseTarget["rsa_status"] = new EntityReference("rsa_status", enStatus.Id);
                }
                enCaseTarget["rsa_isemailparsingalreadyrun"] = "TRUE";
            }
            // Confirm if policy number is of Channel type EDI
            var enPolicyToUpdate = new Entity(null);
            var intEDIPolicyCount = 0;
            if (!String.IsNullOrEmpty(strMatchedString))
            {
                tracingService.Trace("strMatchedString contains data");
                if ((strMatchedString.StartsWith("A") || strMatchedString.StartsWith("B")) &&
                    strMatchedString.Split(' ').Length > 0)
                {
                    tracingService.Trace("strMatchedString starts with A or B : " + strMatchedString);
                    strEdiPolicyNumber = strMatchedString.Split(' ')[0].ToString().Trim();
                    tracingService.Trace("strEdiPolicyNumber : " + strEdiPolicyNumber);
                    if (!String.IsNullOrEmpty(strEdiPolicyNumber))
                    {
                        tracingService.Trace("strEdiPolicyNumber contains data");
                        EntityCollection enColEDIPolicy = this.GetEDIPolicyDetails(strEdiPolicyNumber);

                        if (enColEDIPolicy != null && enColEDIPolicy.Entities.Count > 0)
                        {
                            tracingService.Trace("enColEDIPolicy contains data");
                            foreach (var enEDIPolicy in enColEDIPolicy.Entities)
                            {
                                if (enEDIPolicy.Attributes.Contains("rsa_classofbusiness") &&
                                       String.IsNullOrEmpty(strCOB) &&
                                       strCOB.Contains(((EntityReference)enEDIPolicy.Attributes["rsa_classofbusiness"]).Name) &&
                                       enEDIPolicy.Attributes.Contains("rsa_plcode") &&
                                       String.IsNullOrEmpty(strPAndL) &&
                                       strPAndL.Contains(((EntityReference)enEDIPolicy.Attributes["rsa_plcode"]).Name))
                                {
                                    tracingService.Trace("Inloop of enEDIPolicy contains COB & P&L.");
                                    enPolicyToUpdate = enEDIPolicy;
                                    intEDIPolicyCount++;
                                }
                            }
                        }

                    }
                }
                else
                {
                    strNonEdiPolicyNumber = strMatchedString;
                    if (!String.IsNullOrEmpty(strNonEdiPolicyNumber))
                    {
                        tracingService.Trace("strNonEdiPolicyNumber is not null.");
                        tracingService.Trace("strNonEdiPolicyNumber : " + strNonEdiPolicyNumber);
                        EntityCollection enColNonEDIPolicy = this.GetNonEDIPolicyDetails(strNonEdiPolicyNumber);
                        if (enColNonEDIPolicy != null && enColNonEDIPolicy.Entities.Count > 0)
                        {
                            tracingService.Trace("enColNonEDIPolicy is not null.");
                            intEDIPolicyCount = enColNonEDIPolicy.Entities.Count;
                            tracingService.Trace("enColNonEDIPolicy is not null and Policy Count : " + intEDIPolicyCount);
                            foreach (var enEDIPolicy in enColNonEDIPolicy.Entities)
                            {
                                enPolicyToUpdate = enEDIPolicy;
                                tracingService.Trace("enEDIPolicy assigning to enPolicyToUpdate.");
                            }
                        }
                    }
                }
            }

            if ((bIsMatchedSubject || bIsMatchedDesc))
            {
                tracingService.Trace("Subject or Description matched");
                var enStatus = caseCommon.GetStatusIdByName("Initial Processing");
                if (enStatus != null)
                    enCaseTarget["rsa_status"] = new EntityReference("rsa_status", enStatus.Id);
                if (intEDIPolicyCount > 1)
                {
                    tracingService.Trace("Multiple Matching Policies");
                    //Multiple Matching Policies
                    enCaseTarget["rsa_policymatchstatus"] = new OptionSetValue((int)RSAEnum.OPS_Case_rsa_policymatchstatus.MultipleMatchingPolicies);
                }
                else if (enPolicyToUpdate != null && enPolicyToUpdate.Id != Guid.Empty)
                {
                    tracingService.Trace("Single Matching Policies");
                    //Match Found
                    enCaseTarget["rsa_policymatchstatus"] = new OptionSetValue((int)RSAEnum.OPS_Case_rsa_policymatchstatus.MatchFound);
                    tracingService.Trace("rsa_policymatchstatus :" + (int)RSAEnum.OPS_Case_rsa_policymatchstatus.MatchFound);
                    enCaseTarget["rsa_policyid"] = new EntityReference("rsa_policy", enPolicyToUpdate.Id);
                    tracingService.Trace("enPolicyToUpdate.Id :" + enPolicyToUpdate.Id);
                    enCaseTarget["caseorigincode"] = new OptionSetValue((int)RSAEnum.OPS_Case_caseorigincode.Email); // Email
                    tracingService.Trace("caseorigincode :" + (int)RSAEnum.OPS_Case_caseorigincode.Email);
                    if (enPolicyToUpdate.Attributes.Contains("rsa_customer"))
                    {
                        enCaseTarget["rsa_customerrsa"] = enPolicyToUpdate["rsa_customer"];
                        tracingService.Trace("rsa_customerrsa guid updated:" + ((EntityReference)enPolicyToUpdate["rsa_customer"]).Id);
                    }

                    if (enPolicyToUpdate.Attributes.Contains("rsa_broker"))
                    {
                        enCaseTarget["rsa_account"] = enPolicyToUpdate["rsa_broker"];
                        tracingService.Trace("rsa_broker guid updated:" + ((EntityReference)enPolicyToUpdate["rsa_broker"]).Id);
                    }
                }
            }
            tracingService.Trace("Exiting SMEFreeFormat()");
        } }

        /// <summary>
        /// Get Edi policy details
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="strPolicyNumber"></param>
        /// <returns></returns>
        private EntityCollection GetEDIPolicyDetails(string strPolicyNumber)
        {
            var enColPolicy = new EntityCollection(null);
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' no-lock='true'>
                              <entity name='rsa_policy'>
                                <attribute name='rsa_policyid' />
                                <attribute name='rsa_name' />
                                <attribute name='rsa_classofbusiness' />
                                <attribute name='rsa_customer' />
                                <attribute name='rsa_broker' />
                                <attribute name='rsa_plcode' />
                                <order attribute='rsa_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='rsa_codetorelatequotespolicies' operator='eq' value='{0}' />
                                </filter>
                              </entity>
                            </fetch>";
            try
            {
                enColPolicy = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, strPolicyNumber)));
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception in GetEDIPolicyDetails: " + ex.Message);
            }
            return enColPolicy;
        }

        /// <summary>
        /// Get Non-Edi policy details
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="strPolicyNumber"></param>
        /// <returns></returns>
        private EntityCollection GetNonEDIPolicyDetails(string strPolicyNumber)
        {
            var enColPolicy = new EntityCollection(null);
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' no-lock='true'>
                              <entity name='rsa_policy'>
                                <attribute name='rsa_policyid' />
                                <attribute name='rsa_name' />
                                <attribute name='createdon' />
                                <attribute name='rsa_customer' />
                                <attribute name='rsa_broker' />
                                <order attribute='rsa_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='rsa_name' operator='eq' value='{0}' />
                                </filter>
                              </entity>
                            </fetch>";
            try
            {
                enColPolicy = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, strPolicyNumber)));
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception in GetNonEDIPolicyDetails: " + ex.Message);
            }
            return enColPolicy;
        }

        internal void SMEPowerPlace()
        {
            tracingService.Trace("Start SMEPowerPlace()");
            String regexPowerPlace = "(?m)(?i)^\\s*Policy Number\\s*:\\s*([a-zA-Z0-9@.]\\s?)*( *)$";
            RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon = new RSA.CSI.Plugins.Case.CaseCommon.CaseCommon(service, tracingService);
            string strCaseDescription = string.Empty;
            if (enCaseTarget.Attributes.Contains("description"))
            {
                strCaseDescription = enCaseTarget.Attributes["description"].ToString();
            }
            else if (enCasePreImage.Attributes.Contains("description"))
            {
                strCaseDescription = enCasePreImage.Attributes["description"].ToString();
            }
            if (String.IsNullOrEmpty(strCaseDescription))
            {
                tracingService.Trace("There is no information available in case description.");
                return;
            }
            Regex regex;
            Match match;
            var intStartPolicyIdx = -1;
            var intStrEndPolicyIdx = -1;
            var strMatchedString = string.Empty;
            var strPolicyKey = string.Empty;
            Dictionary<string, string> dicRgx = new Dictionary<string, string>();
            dicRgx.Add("Policy Number", RX_POLICY_NUMBER_PATTERN);
            dicRgx.Add("Policy Number2", regexPowerPlace);
            //enCasePreImage.Attributes["description"] = "Contact request received regarding a referred quotation: Quote Ref: 92278922, Refer Reason: EA1093 Claims, Total Client Premium: 345, Client Name: Arnolds Haulage, Client Postcode: HR7 7TY, Client Ref: 7143956, Broker Email: shaun@squaremilebroking.com<mailto:shaun@squaremilebroking.com>, Broker Name: Square Mile Broking Ltd, Broker Agency Number: AT789, Broker Contact Name: Shaun Stevens, Broker Telephone Number: 0844 561 6075, RSA Region: Chesham, Company Name: Square Mile Broking Ltd, Contact First name: Contact Surname:, Phone Number:, Message: Please could you confirm terms ASAP as policy due tomorrow, Policy Number: RSAP1234567883,";

            tracingService.Trace("Case Description in SMEPowerPlace(): " + strCaseDescription);
            foreach (var dicItem in dicRgx)
            {
                regex = new Regex(dicItem.Value.ToLower());
                var strPolicyNumber = string.Empty;
                if (regex.IsMatch(strCaseDescription.ToLower()))
                {
                    tracingService.Trace("strCaseDescription matched with regex");
                    foreach (Match patMatch in regex.Matches(strCaseDescription.ToLower()))
                    {
                        //string[] strSplitted = regex.Matches(strCaseDescription)[0].Value.Split(new char[':'], 2);
                        string[] strSplitted = patMatch.Value.Split(':');
                        if (strSplitted.Length >= 2)
                        {
                            intStartPolicyIdx = strSplitted[1].Trim().IndexOf(strSplitted[1], 0) + 1;
                            intStrEndPolicyIdx = strSplitted[1].Trim().IndexOf(',');
                            if (intStartPolicyIdx >= 0 && intStrEndPolicyIdx >= 0)
                                strMatchedString = strSplitted[1].Trim().Substring(intStartPolicyIdx, intStrEndPolicyIdx).Trim();
                            else
                                strMatchedString = strSplitted[1].Trim();

                            tracingService.Trace("strMatchedString : " + strMatchedString);
                            if (strSplitted[0].ToLower().Contains(RX_POLICY_NUMBER.ToLower()))
                            {
                                strPolicyNumber = strMatchedString.Replace("Policy Number", string.Empty).Replace("policy Number", string.Empty).Replace(" ", string.Empty).Replace(":", "").Replace("(\\s)", string.Empty);
                                strPolicyKey = SOURCE_SYSTEM_UKRIS + ':' + strPolicyNumber;
                                tracingService.Trace("Policy Key" + " : " + strPolicyKey);
                                Entity enPolicy = this.GetPolicyDetailsByPolicyKey(strPolicyKey.Trim());
                                if (enPolicy != null)
                                {
                                    tracingService.Trace("enPolicy matched");
                                    enCaseTarget["rsa_policyid"] = new EntityReference("rsa_policy", enPolicy.Id);
                                    if (enPolicy.Attributes.Contains("rsa_broker"))
                                    {
                                        enCaseTarget["rsa_account"] = enPolicy["rsa_broker"];
                                        tracingService.Trace("enPolicy - rsa_broker matched");
                                    }
                                    if (enPolicy.Attributes.Contains("rsa_customer"))
                                    {
                                        enCaseTarget["rsa_customerrsa"] = enPolicy["rsa_customer"];
                                        tracingService.Trace("enPolicy - rsa_customer matched");
                                    }
                                    var enStatus = caseCommon.GetStatusIdByName("New");
                                    tracingService.Trace("Status Retrived");
                                    if (enStatus != null)
                                    {
                                        tracingService.Trace("Set Status to new");
                                        enCaseTarget["rsa_status"] = new EntityReference("rsa_status", enStatus.Id);
                                    }
                                    break;
                                }
                                else
                                {
                                    tracingService.Trace("enPolicy does not matched");
                                    var enStatus = caseCommon.GetStatusIdByName("Initial Processing");
                                    tracingService.Trace("enStatus Initial Processing retriving");
                                    if (enStatus != null)
                                    {
                                        tracingService.Trace("Setting status Initial Processing");
                                        enCaseTarget["rsa_status"] = new EntityReference("rsa_status", enStatus.Id);
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    tracingService.Trace("Description mismatched with Policy Number : " + dicItem.Key.ToString());
                }
            }

            enCaseTarget["rsa_isemailparsingalreadyrun"] = "TRUE";
            tracingService.Trace("Exiting SMEPowerPlace()");
        }

        /// <summary>
        /// This function is called from 
        /// </summary>
        internal void SMEQuickCreatePolicy()
        {
            tracingService.Trace("Start SMEQuickCreate()");
            RSA.CSI.Plugins.Case.CaseCommon.CaseCommon caseCommon = new RSA.CSI.Plugins.Case.CaseCommon.CaseCommon(service, tracingService);
            //rsa_policynumber,rsa_policysystem are calculated field in Case

            string strPolicyNumber = string.Empty;
            string strPolicySystem = string.Empty;
            if (enCaseTarget.Attributes.Contains("rsa_policynumberqc") &&
                enCaseTarget.Attributes.Contains("rsa_policysystemqc"))
            {
                tracingService.Trace("Found rsa_policynumberqc and rsa_policysystemqc in target1");
                strPolicyNumber = enCaseTarget.Attributes["rsa_policynumberqc"].ToString();
                tracingService.Trace("strPolicyNumber :" + strPolicyNumber);
                strPolicySystem = caseCommon.GetOptionSetMetadata(enCaseTarget.LogicalName, "rsa_policysystemqc",
                    ((OptionSetValue)enCaseTarget.Attributes["rsa_policysystemqc"]).Value.ToString(), null);
                tracingService.Trace("strPolicySystem value :" + ((OptionSetValue)enCaseTarget.Attributes["rsa_policysystemqc"]).Value);
                tracingService.Trace("strPolicySystem text :" + strPolicySystem);
                //strPolicySystem = enCaseTarget.FormattedValues["rsa_policysystemqc"].Trim();
                tracingService.Trace("Found rsa_policynumberqc and rsa_policysystemqc in target2");
            }
            else if (enCasePreImage.Attributes.Contains("rsa_policynumberqc") &&
               enCasePreImage.Attributes.Contains("rsa_policysystemqc"))
            {
                tracingService.Trace("Found rsa_policynumberqc and rsa_policysystemqc in new1");
                strPolicyNumber = enCasePreImage.Attributes["rsa_policynumberqc"].ToString();
                //Fix for defect no 759 : Sumegh Dhole : 31 Dec 2020.  enCasePreImage to be used rather than enCaseTarget
                tracingService.Trace("strPolicyNumber :" + strPolicyNumber);
                strPolicySystem = caseCommon.GetOptionSetMetadata(enCasePreImage.LogicalName, "rsa_policysystemqc",
                    ((OptionSetValue)enCasePreImage.Attributes["rsa_policysystemqc"]).Value.ToString(), null);
                tracingService.Trace("strPolicySystem value :" + ((OptionSetValue)enCasePreImage.Attributes["rsa_policysystemqc"]).Value);
                tracingService.Trace("strPolicySystem text :" + strPolicySystem);
                tracingService.Trace("Found rsa_policynumberqc and rsa_policysystemqc in new2");
            }

            if (!String.IsNullOrEmpty(strPolicyNumber) && !String.IsNullOrEmpty(strPolicySystem))
            {
                string strPolicyKey = strPolicySystem.Trim() + ":" + strPolicyNumber.Trim();
                tracingService.Trace("strPolicyKey : " + strPolicyKey);
                Entity enPolicy = this.GetPolicyDetailsByPolicyKey(strPolicyKey);
                if (enPolicy != null)
                {
                    tracingService.Trace("enPolicy contains value");
                    enCaseTarget["rsa_policyid"] = new EntityReference("rsa_policy", enPolicy.Id);
                    if (enPolicy.Attributes.Contains("rsa_broker"))
                    {
                        enCaseTarget["rsa_account"] = enPolicy["rsa_broker"];
                        tracingService.Trace("rsa_account updated");
                    }
                    if (enPolicy.Attributes.Contains("rsa_customer"))
                    {
                        enCaseTarget["rsa_customerrsa"] = enPolicy["rsa_customer"];
                        tracingService.Trace("rsa_customerrsa updated");
                    }
                }
                else
                {
                    tracingService.Trace("enPolicy does not contain value");
                    var enPolicyToBeCreated = new Entity("rsa_policy");
                    if (strPolicyNumber.Length > 20)
                    {
                        tracingService.Trace("strPolicyNumber.Length > 20");
                        enPolicyToBeCreated["rsa_policynumber"] = strPolicyNumber.Substring(0, 19); // rsa_policynumber length is 20
                        enPolicyToBeCreated["rsa_name"] = strPolicyNumber.ToString().Substring(0, 19);
                    }
                    else
                    {
                        tracingService.Trace("strPolicyNumber.Length <= 20");
                        enPolicyToBeCreated["rsa_policynumber"] = strPolicyNumber;
                        enPolicyToBeCreated["rsa_name"] = strPolicyNumber;
                    }
                    enPolicyToBeCreated["rsa_policysystemcode"] = new OptionSetValue(SOURCE_SYSTEM_UKRIS_ID);
                    tracingService.Trace("rsa_policysystemcode updated with " + SOURCE_SYSTEM_UKRIS_ID);
                    if (strPolicyKey.Length > 20)
                    {
                        tracingService.Trace("strPolicyKey.Length > 20");
                        enPolicyToBeCreated["rsa_policykey"] = strPolicyKey.Substring(0, 19); // rsa_policykey length is 20
                    }
                    else
                    {
                        tracingService.Trace("strPolicyKey.Length <= 20");
                        enPolicyToBeCreated["rsa_policykey"] = strPolicyKey;
                    }
                    var guidPolicy = this.CreatePolicy(enPolicyToBeCreated);
                    tracingService.Trace("guidPolicy : " + guidPolicy);
                    if (guidPolicy != Guid.Empty)
                    {
                        enCaseTarget["rsa_policyid"] = new EntityReference("rsa_policy", guidPolicy);
                        tracingService.Trace("rsa_policyid updated");
                    }

                }
            }
            tracingService.Trace("Exiting SMEQuickCreate()");
        }

        /// <summary>
        ///  /// <This method is called from the Case Before Update trigger. 
        ///The scenario is that the agent will have already filled the
        ///Customer Name and the Customer Post Code field on the Case, 
        ///if this happens the code makes a call to this method.
        /// </summary>
        internal void QuickCreateCustomer()
        {
            string strCustomerName = string.Empty;
            string strCustomerPostCode = string.Empty;
            if (!enCaseTarget.Attributes.Contains("rsa_customerrsa") &&
                enCaseTarget.Attributes.Contains("rsa_customername") &&
                enCaseTarget.Attributes.Contains("rsa_customerpostcode"))
            {
                strCustomerName = enCaseTarget.Attributes["rsa_customername"].ToString();
                strCustomerPostCode = enCaseTarget.Attributes["rsa_customerpostcode"].ToString();
            }
            else if (!enCasePreImage.Attributes.Contains("rsa_customerrsa") &&
                enCasePreImage.Attributes.Contains("rsa_customername") &&
                enCasePreImage.Attributes.Contains("rsa_customerpostcode"))
            {
                strCustomerName = enCasePreImage.Attributes["rsa_customername"].ToString();
                strCustomerPostCode = enCasePreImage.Attributes["rsa_customerpostcode"].ToString();
            }

            if (!String.IsNullOrEmpty(strCustomerName) && !String.IsNullOrEmpty(strCustomerPostCode))
            {
                tracingService.Trace("Calling CallSearchCustomerDedupe()");
                this.CallSearchCustomerDedupe(strCustomerName, strCustomerPostCode);
                tracingService.Trace("Exiting CallSearchCustomerDedupe()");
            }
            else
            {
                tracingService.Trace("Unable to call CallSearchCustomerDedupe() from QuickCreateCustomer()");
                tracingService.Trace("Either rsa_customerrsa||rsa_customername||rsa_customerpostcode are false");
                tracingService.Trace("enCaseTarget rsa_customerrsa :" + enCaseTarget.Attributes.Contains("rsa_customerrsa"));
                tracingService.Trace("enCaseTarget rsa_customername :" + enCaseTarget.Attributes.Contains("rsa_customername"));
                tracingService.Trace("enCaseTargetrsa_customerpostcode :" + enCaseTarget.Attributes.Contains("rsa_customerpostcode"));
                tracingService.Trace("enCasePreImage rsa_customerrsa :" + enCasePreImage.Attributes.Contains("rsa_customerrsa"));
                tracingService.Trace("enCasePreImage rsa_customername :" + enCasePreImage.Attributes.Contains("rsa_customername"));
                tracingService.Trace("enCasePreImage rsa_customerpostcode :" + enCasePreImage.Attributes.Contains("rsa_customerpostcode"));
            }
        }

        /// <summary>
        /// Populate broker in Case from Agency code
        /// </summary>
        internal void QuickCreateBroker()
        {
            string strBrokerAgencyNumber = string.Empty;
            if (enCaseTarget.Attributes.Contains("rsa_agencynumber"))
            {
                strBrokerAgencyNumber = enCaseTarget.Attributes["rsa_agencynumber"].ToString();
            }
            else if (enCasePreImage.Attributes.Contains("rsa_agencynumber"))
            {
                strBrokerAgencyNumber = enCasePreImage.Attributes["rsa_agencynumber"].ToString();
            }
            if (!String.IsNullOrEmpty(strBrokerAgencyNumber))
            {
                var enAgencyCode = this.GetBrokerAgencyByNumber(strBrokerAgencyNumber);
                if (enAgencyCode != null && enAgencyCode.Attributes.Contains("rsa_agency"))
                    enCaseTarget["rsa_account"] = enAgencyCode["rsa_agency"];
            }
            else
            {
                tracingService.Trace("Agency Number is null while checking QuickCreateBroker()");
            }
        }

        /// <summary>
        /// Create policy
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="enPolicy"></param>
        /// <returns></returns>
        private Guid CreatePolicy(Entity enPolicy)
        {
            var retNewPolicyId = Guid.Empty;
            try
            {
                retNewPolicyId = service.Create(enPolicy);
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while creating Policy: " + ex.Message);
            }
            return retNewPolicyId;
        }

        internal void SMEMatchCustomer()
        {
            tracingService.Trace("Start SMEMatchCustomer()");

            tracingService.Trace("Exiting SMEMatchCustomer()");
        }

        /// <summary>
        /// Search customer based on name and postcode
        /// 
        /// </summary>
        /// <param name="strClientName"></param>
        /// <param name="strClientPostCode"></param>
        private void SearchCustomer(string strClientName, string strClientPostCode)
        {
            tracingService.Trace("Start SearchCustomer()");
            var query = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='rsa_customer'>
                                <attribute name='rsa_name' />
                                <attribute name='rsa_customerrsa' />
                                <attribute name='rsa_processstatus' />
                                <attribute name='rsa_rsapostalcode' />
                                <attribute name='rsa_postcodeprefix' />
                                <attribute name='rsa_rsakeywordprefix3value' />
                                <attribute name='rsa_keywordprefix3' />
                                <attribute name='rsa_keywordprefix' />
                                <attribute name='rsa_keywordcheckname' />
                                <attribute name='rsa_duplicatecheckstatus' />
                                <attribute name='rsa_rsacompanynamestripped' />
                                <attribute name='rsa_rsacustomernamebigrams' />
                                <order attribute='rsa_customerkeyword' descending='false' />
                                <filter type='and'>
                                  <condition attribute='rsa_keywordcheckname' operator='like' value='%{0}%' />
                                  <condition attribute='rsa_rsacustomerkeyword' operator='eq' value='Not Found' />
                                     <condition attribute='rsa_processstatus' operator='eq' value='Live' />
                                </filter>
                              </entity>
                            </fetch>";

            //Create the Customer Key to check if the incoming Customer information exists in the CSI Customer Object
            string strCustomerKey = strClientName + ":" + strClientPostCode;
            tracingService.Trace("strCustomerKey : " + strCustomerKey);

            if (!String.IsNullOrEmpty(strCustomerKey) && !String.IsNullOrEmpty(strClientName) && !enCaseTarget.Attributes.Contains("rsa_customerrsa"))
            {
                var guidCustomerStaging = Guid.Empty;
                string strCustomerKeyword = string.Empty;
                string customerNameBigrams = string.Empty;
                string strKeywordPrefix3 = string.Empty;
                string strCustomerNameStripped = RSA.CSI.Plugins.Case.Helper.StringUtilities.TrimString(strClientName);
                tracingService.Trace("strCustomerNameStripped: " + strCustomerNameStripped);
                if (!String.IsNullOrEmpty(strCustomerNameStripped))
                {
                    strCustomerKeyword = RSA.CSI.Plugins.Case.Helper.StringUtilities.GetKeyWords(strCustomerNameStripped);
                    tracingService.Trace("strCustomerKeyword: " + strCustomerKeyword);
                    strKeywordPrefix3 = RSA.CSI.Plugins.Case.Helper.StringUtilities.GetKeywordPrefix3(strCustomerKeyword);
                    tracingService.Trace("strKeywordPrefix3: " + strKeywordPrefix3);
                    customerNameBigrams = RSA.CSI.Plugins.Case.Helper.DiceCoefficient.GetBigramString(strCustomerNameStripped);
                    tracingService.Trace("customerNameBigrams: " + customerNameBigrams);
                    if (!String.IsNullOrEmpty(strKeywordPrefix3))
                    {
                        var strKeyWord = strKeywordPrefix3.Length < 3 ? strKeywordPrefix3.Replace("_", " ") : strKeywordPrefix3;
                        tracingService.Trace("strKeyWord : " + strKeyWord);
                        query = String.Format(query, strKeyWord);
                        tracingService.Trace("query : " + query);
                        tracingService.Trace("Calling  custDupeFinderNew()");
                        //SynchEmailParsingCustDupeFinderNew.execute(prefixes, query, custSMEStagingList, searchMethod, batchSize, caseList); //TODO
                        CustDupeFinderNew custDupeFinderNew = new CustDupeFinderNew(service, tracingService, strKeyWord, strClientName, strClientPostCode, query, enCaseTarget, enCasePreImage);
                        custDupeFinderNew.Execute();
                        tracingService.Trace("Complated  custDupeFinderNew()");
                    }
                }
            }

            /*if (!String.IsNullOrEmpty(strCustomerKey) && !String.IsNullOrEmpty(strClientName) && !enCasePreImage.Attributes.Contains("rsa_customerrsa"))
            {
                var guidCustomerStaging = this.CreateStagingCustomer(strClientName, strClientPostCode);
                tracingService.Trace("guidCustomerStaging : " + guidCustomerStaging);
                if (guidCustomerStaging != Guid.Empty)
                {
                    var enCustomerStaging = this.GetCustomerStagingDetails(guidCustomerStaging);
                    if (enCustomerStaging != null &&
                        enCustomerStaging.Attributes.Contains("rsa_keywordprefix3") &&
                        !enCustomerStaging.Attributes.Contains("rsa_possiblesmeduplicatelinkid") &&
                        !enCasePreImage.Attributes.Contains("rsa_customerrsa") &&
                        !enCustomerStaging.Attributes.Contains("rsa_possiblesmeduplicatelinkid"))
                    {
                        var strKeyWord = enCustomerStaging.Attributes["rsa_keywordprefix3"].ToString().Replace("_", " ");
                        tracingService.Trace("strKeyWord : " + strKeyWord);
                        query = String.Format(query, strKeyWord);
                        tracingService.Trace("query : " + query);
                        tracingService.Trace("Calling  custDupeFinderNew()");
                        //SynchEmailParsingCustDupeFinderNew.execute(prefixes, query, custSMEStagingList, searchMethod, batchSize, caseList); //TODO
                        CustDupeFinderNew custDupeFinderNew = new CustDupeFinderNew(service, tracingService, strKeyWord, query, enCustomerStaging, enCaseTarget, null, enCasePreImage);
                        custDupeFinderNew.Execute();
                        tracingService.Trace("Executed  custDupeFinderNew()");
                    }
                }
            }*/
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="guidCustomerStaging"></param>
        /// <returns></returns>
        private Entity GetCustomerStagingDetails(Guid guidCustomerStaging)
        {
            var enCustomerStaging = new Entity(null);
            try
            {
                enCustomerStaging = service.Retrieve("rsa_smecustomerstaging", guidCustomerStaging, new ColumnSet("rsa_keywordprefix3", "rsa_caseid", "rsa_possiblesmeduplicatelinkid", "rsa_customernamefinal", "rsa_postcodefinal", "rsa_duplicatecheckstatus", "rsa_customernamestripped", "rsa_customername", "rsa_postcode", "rsa_customernamebigrams", "rsa_possiblesmeduplicatelinkid"));
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while creating Policy: " + ex.Message);
            }
            return enCustomerStaging;
        }

        /// <summary>
        /// Create Customer Staging recrod 
        /// </summary>
        /// <param name="strClientName"></param>
        /// <param name="strClientPostCode"></param>
        /// <returns></returns>
        private Guid CreateStagingCustomer(string strClientName, string strClientPostCode)
        {
            var guidCustomerStaging = Guid.Empty;
            string strCustomerKeyword = string.Empty;
            string customerNameBigrams = string.Empty;
            string strKeywordPrefix3 = string.Empty;
            string strCustomerNameStripped = RSA.CSI.Plugins.Case.Helper.StringUtilities.TrimString(strClientName);
            if (!String.IsNullOrEmpty(strCustomerNameStripped))
            {
                strCustomerKeyword = RSA.CSI.Plugins.Case.Helper.StringUtilities.GetKeyWords(strCustomerNameStripped);
                strKeywordPrefix3 = RSA.CSI.Plugins.Case.Helper.StringUtilities.GetKeywordPrefix3(strCustomerKeyword);
                tracingService.Trace("strKeywordPrefix3: " + strKeywordPrefix3);
                tracingService.Trace("strCustomerKeyword: " + strCustomerKeyword);
                customerNameBigrams = RSA.CSI.Plugins.Case.Helper.DiceCoefficient.GetBigramString(strCustomerNameStripped);
                tracingService.Trace("customerNameBigrams: " + customerNameBigrams);
            }
            var enCustomerStaging = new Entity("rsa_smecustomerstaging");
            enCustomerStaging["rsa_customernamefinal"] = strClientName;
            enCustomerStaging["rsa_postcodefinal"] = strClientPostCode;
            enCustomerStaging["rsa_duplicatecheckstatus"] = new OptionSetValue((int)RSAEnum.OPS_Case_rsa_duplicatecheckstatus.Checking); // 'Checking'
            enCustomerStaging["rsa_customerkeyword"] = strCustomerKeyword;
            enCustomerStaging["rsa_customernamestripped"] = strCustomerNameStripped;
            enCustomerStaging["rsa_caseid"] = new EntityReference("incident", enCaseTarget.Id);
            enCustomerStaging["rsa_customername"] = strClientName;
            enCustomerStaging["rsa_postcode"] = strClientPostCode;
            enCustomerStaging["rsa_customernamebigrams"] = customerNameBigrams;
            enCustomerStaging["rsa_keywordprefix3"] = strKeywordPrefix3;
            try
            {
                guidCustomerStaging = service.Create(enCustomerStaging);
                tracingService.Trace("Customer Staging Created Successfully.");
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while creating Customer staging record: " + ex.Message);
            }
            return guidCustomerStaging;
        }

        private Guid GetCustomerByExternalId(string strCustomerKey, string strCutomerName)
        {
            var customerId = Guid.Empty;
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' no-lock='true'>
                      <entity name='rsa_customer'>
                        <attribute name='rsa_name' />
                        <attribute name='createdon' />
                        <attribute name='rsa_turnover' />
                        <attribute name='rsa_trade' />
                        <attribute name='rsa_ideassolutions' />
                        <attribute name='rsa_hurdlescompetition' />
                        <attribute name='rsa_customerid' />
                        <order attribute='rsa_customerkeyword' descending='false' />
                        <filter type='and'>
                          <condition attribute='rsa_rsaexternalid' operator='eq' value='{0}' />
                          <condition attribute='rsa_name' operator='eq' value='{1}' />
                        </filter>
                      </entity>
                    </fetch>";
            try
            {
                var enColCustomer = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, strCustomerKey, strCutomerName)));
                if (enColCustomer != null && enColCustomer.Entities.Count > 0)
                {
                    customerId = enColCustomer.Entities[0].Id;
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while creating Policy: " + ex.Message);
            }
            return customerId;
        }
    }
}