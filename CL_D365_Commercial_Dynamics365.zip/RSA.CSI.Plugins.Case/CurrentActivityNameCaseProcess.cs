﻿using Microsoft.Xrm.Sdk;
using System;
using System.ServiceModel;
using System.Activities;
using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Xrm.Sdk.Query;

namespace RSA.CSI.Plugins.Case.Common
{
    public class CurrentActivityNameCaseProcess : CodeActivity
    {
        [RequiredArgument]
        [ReferenceTarget("incident")]
        [Input("case")]

        public InArgument<EntityReference> entity { get; set; }

        [Output("Duedate")]
        public OutArgument<DateTime> duedate { get; set; }
        [Output("activityname")]
        public OutArgument<string> activityname { get; set; }
        [Output("Owner")]
        [ReferenceTarget("systemuser")]
        public OutArgument<EntityReference> Ownerid { get; set; }


        protected override void Execute(CodeActivityContext _executionContext)
        {
            IWorkflowContext _context = _executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = _executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService _service = serviceFactory.CreateOrganizationService(_context.InitiatingUserId);

            ITracingService _tracingService = _executionContext.GetExtension<ITracingService>();

            //Entity entity = new Entity("incident");
            Entity _enTaskFromCase = null;
            //_tracingService.Trace("reached 1156");
            //Defect id 1962 1995 &  : Sumegh Dhole Updated source code for the object reference error : ISV code fix
            //entity. = ((AliasedValue)_eTaskNewObj["inc.incidentid"]) != null ? ((AliasedValue)_eTaskNewObj["inc.incidentid"]).Value != null ? new Guid(((AliasedValue)_eTaskNewObj["inc.incidentid"]).Value.ToString()) : Guid.Empty : Guid.Empty;
            //entity.Id = new Guid(((AliasedValue)_eTaskNewObj["inc.incidentid"]).Value.ToString());
            //_tracingService.Trace("reached 1160");
            if (entity != null)
            {
               // _tracingService.Trace("TaskManagementLogic=>CascadeTaskInfoToCase - eNTITYid of case" + entity.Id);
                EntityReference RelatedId = entity.Get<EntityReference>(_executionContext); 
      
                _tracingService.Trace("realated id" + RelatedId.Id);
               string fetchQuery = "<fetch mapping = 'logical'>";
                fetchQuery += "<entity name = 'task'>";
                fetchQuery += "<attribute name='subject'/>";
                fetchQuery += "<attribute name = 'statecode'/>";
                fetchQuery += "<attribute name='prioritycode'/>";
                fetchQuery += "<attribute name = 'scheduledend'/>";
                fetchQuery += "<attribute name = 'rsa_slastatus'/>";
                fetchQuery += "<attribute name='createdby'/>";
                fetchQuery += "<attribute name = 'regardingobjectid'/>";
                fetchQuery += "<attribute name='activityid' />";
                fetchQuery += "<attribute name='ownerid' />";
                fetchQuery += "<order descending = 'false' attribute='scheduledend'/>";
                fetchQuery += "<filter type = 'and'>";
                fetchQuery += "<condition attribute='statuscode' value='5' operator='ne'/>";
                fetchQuery += "<condition attribute = 'regardingobjectid' value= '"+ RelatedId.Id +"' operator='eq'/>";
                fetchQuery += "</filter>";
                fetchQuery += "</entity>";
                fetchQuery += "</fetch>";

                EntityCollection CaseTaskCOllection = _service.RetrieveMultiple(new FetchExpression(fetchQuery));
                Entity EnCase = new Entity("incident");
                _tracingService.Trace("TaskManagementLogic=>CascadeTaskInfoToCase - Tasks  of case" + CaseTaskCOllection.Entities.Count);
                if (CaseTaskCOllection != null && CaseTaskCOllection.Entities.Count > 0)
                {
                    foreach (var en in CaseTaskCOllection.Entities)
                    {
                        _enTaskFromCase = en;
                        _tracingService.Trace("TaskManagementLogic=>CascadeTaskInfoToCase Task from case retreived");
                        break;
                    }

                    string taskSubject = _enTaskFromCase.Attributes.Contains("subject") ? _enTaskFromCase.GetAttributeValue<string>("subject") : string.Empty;
                    DateTime Duedate = _enTaskFromCase.Attributes.Contains("scheduledend") ? _enTaskFromCase.GetAttributeValue<DateTime>("scheduledend") : DateTime.MinValue;
                    EntityReference EnOwner = _enTaskFromCase.Attributes.Contains("ownerid") ? _enTaskFromCase.GetAttributeValue<EntityReference>("ownerid") : null;
                    if (Duedate != DateTime.MinValue)
                    {
                        _tracingService.Trace("Due date when task is not completed");
                        EnCase["rsa_nextactiondate"] = Duedate;
                        _tracingService.Trace("due date" + Duedate);

                    }                      
                        EnCase["rsa_nextactivityname"] = taskSubject;
                    _tracingService.Trace("activity name" + taskSubject);
                    EnCase["rsa_activityownerid "] = new EntityReference(EnOwner.LogicalName,EnOwner.Id);
                    _tracingService.Trace("rsa_activityownerid" + EnOwner.Name);
                    this.duedate.Set(_executionContext, Duedate);
                    this.activityname.Set(_executionContext, taskSubject);
                    this.Ownerid.Set(_executionContext, new EntityReference(EnOwner.LogicalName, EnOwner.Id));

                }

                _tracingService.Trace("parent case has been updated.");
            }
            }
        }

       }
    
       

    

           