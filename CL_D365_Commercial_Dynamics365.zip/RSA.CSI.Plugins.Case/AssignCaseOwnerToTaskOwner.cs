﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSA.CSI.Plugins.Case
{
    public class AssignCaseOwnerToTaskOwner : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService tracingService =
           (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            IPluginExecutionContext context = (IPluginExecutionContext)
                serviceProvider.GetService(typeof(IPluginExecutionContext));
            tracingService.Trace("AssignCaseOwnerToTaskOwner - Loaded");
            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                tracingService.Trace("Before Try");
                Entity caseEntity = (Entity)context.InputParameters["Target"];
                IOrganizationServiceFactory serviceFactory =
                    (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

                try
                {
                    if (context.Depth > 1)
                    {
                        return;
                    }

                    tracingService.Trace("In Try");
                    //EntityReference ownerid = (EntityReference)context.InputParameters["Assignee"];
                    Entity enTask = null;
                    var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' no-lock='true'>
                                    <entity name='task'>
                                    <attribute name='subject' />
                                    <attribute name='statecode' />
                                    <attribute name='prioritycode' />
                                    <attribute name='rsa_tasktype' />
                                    <attribute name='scheduledend' />
                                    <attribute name='createdby' />
                                    <attribute name='regardingobjectid' />
                                    <attribute name='activityid' />
                                    <attribute name='ownerid' />
                                    <order attribute='subject' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='regardingobjectid' operator='eq' value='{0}'/>
                                    </filter>
                                    <link-entity name='rsa_activitytype' from='rsa_activitytypeid' to='rsa_tasktype' link-type='inner' alias='ac'>
                                      <filter type='and'>
                                        <condition attribute='rsa_isbpotask' operator='ne' value='1' />
                                      </filter>
                                    </link-entity>
                                  </entity>
                                </fetch>";

                    tracingService.Trace("Fetched Tasks." + String.Format(fetchXml, caseEntity.Id));

                    Entity caseOwnerId = service.Retrieve("incident", caseEntity.Id, new ColumnSet ( new string[] { "ownerid" } ));
                    EntityReference caseOwnerName = caseOwnerId.Contains("ownerid")?caseOwnerId.GetAttributeValue<EntityReference>("ownerid") : null;

                    var enColTasks = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, caseEntity.Id)));
                    if (enColTasks != null && enColTasks.Entities.Count > 0)
                    {
                        tracingService.Trace("Number of Task:" + enColTasks.Entities.Count);
                        //Modified on -19/04 ;Modified By-Nida;Details:defect 2689 : activity owner updating wrong hence commented 

                        //caseEntity["rsa_activityownerid"] = caseOwnerName;
                        //tracingService.Trace("Current Activity Owner:" + caseOwnerName.Name);

                        foreach (var item in enColTasks.Entities)
                        {

                            //AssignRequest assignRequest = new AssignRequest
                            //{
                            //    Assignee = caseOwnerName,
                            //    Target = new EntityReference("task", item.Id)
                            //};
                            //service.Execute(assignRequest);
                            //commented assignRequest as its depricated
                            //Modified on -18/03 ;Modified By-Nida;Details:MS remediation applied to  Replace deprecated assignrequest message
                            //Modified on -19/04 ;Modified By-Nida;Details:defect 2689 : Assigned to Issue for BPO and Non - BPO Task

                            Entity taskUpdate = new Entity("task",item.Id);
                            taskUpdate["ownerid"] = caseOwnerName;
                            service.Update(taskUpdate);
                        }

                    }

                    //Modified on -21/04 ;Modified By-Nida;Details:defect 2689 : activity owner update post assignment
                    string fetchQuery1 = "<fetch mapping = 'logical'>";
                    fetchQuery1 += "<entity name = 'task'>";
                    fetchQuery1 += "<attribute name='subject'/>";
                    fetchQuery1 += "<attribute name = 'statecode'/>";
                    fetchQuery1 += "<attribute name='prioritycode'/>";
                    fetchQuery1 += "<attribute name = 'scheduledend'/>";
                    fetchQuery1 += "<attribute name = 'rsa_slastatus'/>";
                    fetchQuery1 += "<attribute name =  'rsa_duedatetime'/>";
                    fetchQuery1 += "<attribute name='createdby'/>";
                    fetchQuery1 += "<attribute name = 'regardingobjectid'/>";
                    fetchQuery1 += "<attribute name='activityid' />";
                    fetchQuery1 += "<attribute name='ownerid' />";
                    fetchQuery1 += "<order descending = 'false' attribute='scheduledend'/>";
                    fetchQuery1 += "<filter type = 'and'>";
                    fetchQuery1 += "<condition attribute='statecode' value='1' operator='ne'/>";
                    fetchQuery1 += "<condition attribute = 'regardingobjectid' value= '" + caseEntity.Id + "' operator='eq'/>";
                    fetchQuery1 += "</filter>";
                    fetchQuery1 += "</entity>";
                    fetchQuery1 += "</fetch>";

                    EntityCollection CaseTaskCOllection = service.RetrieveMultiple(new FetchExpression(fetchQuery1));
                    if (CaseTaskCOllection != null && CaseTaskCOllection.Entities.Count > 0)
                    {
                        tracingService.Trace("Number of Task:" + CaseTaskCOllection.Entities.Count);
                        string taskSubject = CaseTaskCOllection[0].Attributes.Contains("subject") ? CaseTaskCOllection[0].GetAttributeValue<string>("subject") : string.Empty;
                        tracingService.Trace("Task Subject : " + taskSubject);
                        DateTime Duedate = CaseTaskCOllection[0].Attributes.Contains("rsa_duedatetime") ? CaseTaskCOllection[0].GetAttributeValue<DateTime>("rsa_duedatetime") : DateTime.MinValue;
                        tracingService.Trace("Task Duedate : " + Duedate);
                        EntityReference EnOwner = CaseTaskCOllection[0].Attributes.Contains("ownerid") ? CaseTaskCOllection[0].GetAttributeValue<EntityReference>("ownerid") : null;
                        tracingService.Trace("Task EnOwner : " + EnOwner.Name);
                        Entity EnCase = new Entity("incident", caseEntity.Id);
                        if (Duedate != DateTime.MinValue)
                        {
                            EnCase["rsa_nextactiondate"] = Duedate;

                        }
                        EnCase["rsa_nextactivityname"] = taskSubject;
                        EnCase["rsa_activityownerid"] = new EntityReference(EnOwner.LogicalName, EnOwner.Id);
                        service.Update(EnCase);
                        tracingService.Trace("Case SLA Updated :");
                    }


                }
                catch (Exception ex)
                {
                    tracingService.Trace("AssignCaseOwnerToTaskOwner: {0}", ex.Message);
                    //throw;
                    //Remediation - 18/07/2022
                    throw new InvalidPluginExecutionException(ex.Message);
                }
            }
        }
    }
}
