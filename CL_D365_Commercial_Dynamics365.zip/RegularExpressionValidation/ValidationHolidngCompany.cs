﻿using System;
using System.Text.RegularExpressions;
using Microsoft.Xrm.Sdk;

namespace RegularExpressionValidation
{
    public class ValidateHoldingCompanyCode : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context =
               (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            if (!context.InputParameters.Contains("ams_validateholdingcompanycode") ||
                context.InputParameters["ams_validateholdingcompanycode"] == null)
            {
                throw new InvalidPluginExecutionException("Input value not provided.");
            }
            string inputValue = context.InputParameters["ams_validateholdingcompanycode"].ToString();
            string pattern = @"^[A-Za-z]{2}(\d{3}|\d{8})$";
            bool isValid = Regex.IsMatch(inputValue, pattern);
            if (!isValid)
            {
                // Throwing an exception stops the flow and shows the message
                throw new InvalidPluginExecutionException(
                    "Invalid Holding Company Code!\n\nAllowed formats:\n" +
                    " • 2 letters + 3 digits (Example: AB123)\n" +
                    " • 2 letters + 8 digits (Example: AB12345678)");
            }
            context.OutputParameters["IsValid"] = true;
        }
    }
}
