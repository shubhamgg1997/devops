﻿DataMig = window.DataMig || { __namespace: true, __typeName: "DataMig" };
DataMig.D365CRM = DataMig.D365CRM || { __namespace: true, __typeName: "DataMig.D365CRM" };
DataMig.D365CRM.Account = DataMig.D365CRM.Account || { __namespace: true, __typeName: "DataMig.D365CRM.Account" };
DataMig.D365CRM.Account.Ribbon = DataMig.D365CRM.Account.Ribbon || ({
    Clone_Click: function (formCotext) {

        alert("Clone button has been clicked.");
        /*
        parent.Xrm.Page.ui.clearFormNotification("ErrAccountInProgress");
        parent.Xrm.Page.ui.clearFormNotification("ErrAccountCheckbox");
        parent.Xrm.Page.ui.clearFormNotification("ErrNoPolicyForRenewal");
        if (parent.Xrm.Page.getAttribute("DataMig_generaterenewalsstatus").getValue() != undefined && parent.Xrm.Page.getAttribute("DataMig_generaterenewalsstatus").getValue() == DataMig.D365CRM.Account.Ribbon.GenerateRenewalsStatus.InProgress) {
            parent.Xrm.Page.ui.setFormNotification("Renewal Generation process is running for this record. Please wait for the operation to complete.", "ERROR", "ErrAccountInProgress");
            return;
        }
        var parameters = {};
        parameters.renewalId = parent.Xrm.Page.data.entity.getId();
        parameters.mode = "IdentifyRenewal";
        parameters.triggeredBy = Xrm.Utility.getGlobalContext().userSettings.userId;

        var req = new XMLHttpRequest();
        req.open("POST", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/DataMig_IdentifyRenewal", false);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 204) {
                    //Success - No Return Data - Do Something
                } else {
                    Xrm.Utility.alertDialog(this.statusText);
                }
            }
        };
        req.send(JSON.stringify(parameters));

        DataMig.D365CRM.Account.Ribbon._refreshForm();
        parent.Xrm.Page.getControl("DataMig_generaterenewals").setFocus();
        */
    },
    //Account_Click: function () {
    //    parent.Xrm.Page.ui.clearFormNotification("ErrAccountInProgress");
    //    parent.Xrm.Page.ui.clearFormNotification("ErrAccountCheckbox");
    //    parent.Xrm.Page.ui.clearFormNotification("ErrNoPolicyForRenewal");
    //    if (parent.Xrm.Page.getAttribute("DataMig_generaterenewalsstatus").getValue() != undefined && parent.Xrm.Page.getAttribute("DataMig_generaterenewalsstatus").getValue() == DataMig.D365CRM.Account.Ribbon.GenerateRenewalsStatus.InProgress) {
    //        parent.Xrm.Page.ui.setFormNotification("Renewal Generation process is running for this record. Please wait for the operation to complete.", "ERROR", "ErrAccountInProgress");
    //        return;
    //    }

    //    if (!(parent.Xrm.Page.getAttribute("DataMig_totalpoliciesidentifiedforrenewal").getValue() != undefined &&
    //        parent.Xrm.Page.getAttribute("DataMig_totalpoliciesidentifiedforrenewal").getValue() != null &&
    //        parent.Xrm.Page.getAttribute("DataMig_totalpoliciesidentifiedforrenewal").getValue() > 0)) {
    //        parent.Xrm.Page.ui.setFormNotification("No policy has been detected due for renewal. Please modify the Renewal Generation criteria and retry.", "ERROR", "ErrNoPolicyForRenewal");
    //        return;
    //    }
    //    if (parent.Xrm.Page.getAttribute("DataMig_generaterenewals").getValue() != undefined && parent.Xrm.Page.getAttribute("DataMig_generaterenewals").getValue() != DataMig.D365CRM.Account.Ribbon.GenerateRenewalsCheckbox.Yes) {
    //        parent.Xrm.Page.ui.setFormNotification("Please select the Generate Renewals checkbox.", "ERROR", "ErrAccountCheckbox");
    //        parent.Xrm.Page.getControl("DataMig_generaterenewals").setFocus();
    //        return;
    //    }
    //    else {
    //        debugger;
    //        parent.Xrm.Page.ui.clearFormNotification("ErrAccountCheckbox");
    //        var entityName = "DataMig_Accounts";
    //        var entityId = parent.Xrm.Page.data.entity.getId().slice(1, -1);
    //        var triggeredBy = Xrm.Utility.getGlobalContext().userSettings.userId.slice(1, -1);

    //        var entity = {};
    //        entity.DataMig_generaterenewalsstatus = DataMig.D365CRM.Account.Ribbon.GenerateRenewalsStatus.InProgress;
    //        entity.DataMig_datetimegeneraterenewalsrun = new Date(); //Date.now();
    //        //entity["DataMig_runningusergeneraterenewals@odata.bind"] = "/systemusers(" + triggeredBy + ")";
    //        //entity["DataMig_runningusergeneraterenewals@odata.bind"] = "/systemusers(7ee8c751-812a-48b4-892b-f06f0e17ab6f)";
    //        DataMig.D365CRM.Account.Ribbon.UpdateEntity(entityName, entityId, entity, false);
    //        DataMig.D365CRM.Account.Ribbon._refreshForm();

    //        var parameters = {};
    //        parameters.renewalId = parent.Xrm.Page.data.entity.getId();
    //        parameters.mode = "Account";
    //        parameters.triggeredBy = Xrm.Utility.getGlobalContext().userSettings.userId;
    //        var req = new XMLHttpRequest();
    //        req.open("POST", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/DataMig_Account", true);
    //        req.setRequestHeader("OData-MaxVersion", "4.0");
    //        req.setRequestHeader("OData-Version", "4.0");
    //        req.setRequestHeader("Accept", "application/json");
    //        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    //        req.onreadystatechange = function () {
    //            if (this.readyState === 4) {
    //                req.onreadystatechange = null;
    //                if (this.status === 204) {
    //                    //Success - No Return Data - Do Something
    //                } else {
    //                    Xrm.Utility.alertDialog(this.statusText);
    //                }
    //            }
    //        };
    //        req.send(JSON.stringify(parameters));
    //        DataMig.D365CRM.Account.Ribbon._refreshForm();
    //        parent.Xrm.Page.getControl("DataMig_generaterenewalsstatus").setFocus();
    //    }
    //},
    //Clone_Click: function () {  

    //    debugger;
    //    var entityName = "DataMig_Accounts";
    //    var entity = {};
    //    if (parent.Xrm.Page.getAttribute("DataMig_policyrenewaldatefrom").getValue() != undefined && parent.Xrm.Page.getAttribute("DataMig_policyrenewaldatefrom").getValue() != null)
    //        entity.DataMig_policyrenewaldatefrom = parent.Xrm.Page.getAttribute("DataMig_policyrenewaldatefrom").getValue();
    //    if (parent.Xrm.Page.getAttribute("DataMig_policyrenewaldateto").getValue() != undefined && parent.Xrm.Page.getAttribute("DataMig_policyrenewaldateto").getValue() != null)
    //        entity.DataMig_policyrenewaldateto = parent.Xrm.Page.getAttribute("DataMig_policyrenewaldateto").getValue();
    //    if (parent.Xrm.Page.getAttribute("DataMig_name").getValue() != undefined && parent.Xrm.Page.getAttribute("DataMig_name").getValue() != null)
    //        entity.DataMig_name = parent.Xrm.Page.getAttribute("DataMig_name").getValue()+" - Cloned";
    //    if (parent.Xrm.Page.getAttribute("DataMig_mingwp").getValue() != undefined && parent.Xrm.Page.getAttribute("DataMig_mingwp").getValue() != null)
    //        entity.DataMig_mingwp = parent.Xrm.Page.getAttribute("DataMig_mingwp").getValue();
    //    if (parent.Xrm.Page.getAttribute("DataMig_gwpmax").getValue() != undefined && parent.Xrm.Page.getAttribute("DataMig_gwpmax").getValue() != null)
    //        entity.DataMig_gwpmax = parent.Xrm.Page.getAttribute("DataMig_gwpmax").getValue();
    //    if (parent.Xrm.Page.getAttribute("DataMig_product_class").getValue() != undefined && parent.Xrm.Page.getAttribute("DataMig_product_class").getValue() != null) {
    //        var DataMig_product_class = parent.Xrm.Page.getAttribute("DataMig_product_class").getValue();
    //        entity.DataMig_product_class = DataMig_product_class[0].toString();
    //    }
    //    if (parent.Xrm.Page.getAttribute("DataMig_renewalreviewtype").getValue() != undefined && parent.Xrm.Page.getAttribute("DataMig_renewalreviewtype").getValue() != null) {
    //        var DataMig_renewalreviewtype = parent.Xrm.Page.getAttribute("DataMig_renewalreviewtype").getValue();
    //        entity.DataMig_renewalreviewtype = DataMig_renewalreviewtype[0].toString();
    //    }
    //    if (parent.Xrm.Page.getAttribute("DataMig_opshandlingsite").getValue() != undefined && parent.Xrm.Page.getAttribute("DataMig_opshandlingsite").getValue() != null) {
    //        var DataMig_opshandlingsite = parent.Xrm.Page.getAttribute("DataMig_opshandlingsite").getValue();
    //        entity.DataMig_opshandlingsite = DataMig_opshandlingsite[0].toString();
    //    }
    //    var entityId = DataMig.D365CRM.Account.Ribbon.CreateEntity(entityName, entity, false);
    //    if (entityId != undefined && entityId != null) {
    //        var entityFormOptions = {};
    //        entityFormOptions["entityName"] = "DataMig_Account";
    //        entityFormOptions["entityId"] = entityId;
    //        // Open the form.
    //        Xrm.Navigation.openForm(entityFormOptions).then(
    //            function (success) {
    //                console.log(success);
    //            },
    //            function (error) {
    //                console.log(error);
    //            });
    //    }
    //},
    //CreateEntity: function (entityName, entity, isAsync) {
    //    //debugger;

    //    var newEntityId;
    //    var req = new XMLHttpRequest();
    //    req.open("POST", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/" + entityName, isAsync);
    //    req.setRequestHeader("OData-MaxVersion", "4.0");
    //    req.setRequestHeader("OData-Version", "4.0");
    //    req.setRequestHeader("Accept", "application/json");
    //    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    //    req.onreadystatechange = function () {
    //        if (this.readyState === 4) {
    //            req.onreadystatechange = null;
    //            //debugger;
    //            if (this.status === 204) {
    //                //Success - No Return Data - Do Something

    //                var uri = this.getResponseHeader("OData-EntityId");
    //                var regExp = /\(([^)]+)\)/;
    //                var matches = regExp.exec(uri);
    //                newEntityId = matches[1];
    //            } else {
    //                Xrm.Utility.alertDialog(this.statusText);
    //            }
    //        }
    //    };
    //    req.send(JSON.stringify(entity));

    //    return newEntityId;
    //},
    //UpdateEntity: function (entityName, entityId, entity, isAsync) {
    //    //debugger;
    //    var req = new XMLHttpRequest();
    //    req.open("PATCH", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/" + entityName + "(" + entityId + ")", isAsync);
    //    req.setRequestHeader("OData-MaxVersion", "4.0");
    //    req.setRequestHeader("OData-Version", "4.0");
    //    req.setRequestHeader("Accept", "application/json");
    //    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    //    req.onreadystatechange = function () {
    //        if (this.readyState === 4) {
    //            req.onreadystatechange = null;
    //            //debugger;
    //            if (this.status === 204) {
    //                //Success - No Return Data - Do Something
    //            } else {
    //                Xrm.Utility.alertDialog(this.statusText);
    //            }
    //        }
    //    };
    //    req.send(JSON.stringify(entity));
    //},
    //_refreshForm: function () {
    //    parent.Xrm.Page.data.refresh();
    //},

    __namespace: true,
    __typeName: "DataMig.D365CRM.Account.Ribbon"
});