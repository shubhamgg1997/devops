﻿RSA = window.RSA || { __namespace: true, __typeName: "RSA" };
RSA.D365CRM = RSA.D365CRM || { __namespace: true, __typeName: "RSA.D365CRM" };
RSA.D365CRM.RenewalGeneration = RSA.D365CRM.RenewalGeneration || { __namespace: true, __typeName: "RSA.D365CRM.RenewalGeneration" };
RSA.D365CRM.RenewalGeneration.Ribbon = RSA.D365CRM.RenewalGeneration.Ribbon || ({
    GenerateRenewalsStatus: {
        NotStarted: 866760000,
        InProgress: 866760001,
        CompletedNoErrors: 866760002,
        CompletedErrors: 866760003,
        Failed: 866760004
    },
    GenerateRenewalsCheckbox: {
        Yes: true,
        No: false
    },
    OperationType: {
        IdentifyRenewal: 0,
        RenewalGeneration: 1
    },
    Mode: {
        IdentifyRenewal: "IdentifyRenewal",
        RenewalGeneration: "RenewalGeneration"
    },
    IdentifyRenewal_Click: function (primaryControl) {
        //debugger;
        var formContext = primaryControl;
        if (!RSA.D365CRM.RenewalGeneration.Ribbon._preOperationValidation(formContext, 0)) {
            console.log("_preOperationValidation logic has failed");
            return;
        }

        var parameters = {};
        parameters.renewalId = formContext.data.entity.getId();
        parameters.mode = RSA.D365CRM.RenewalGeneration.Ribbon.Mode.IdentifyRenewal;
        parameters.triggeredBy = Xrm.Utility.getGlobalContext().userSettings.userId;

        RSA.D365CRM.RenewalGeneration.Ribbon.ExecuteAction(formContext, "rsa_IdentifyRenewal", parameters, false);
        RSA.D365CRM.RenewalGeneration.Ribbon._refreshForm(formContext);

        formContext.getControl("rsa_generaterenewals").setFocus();
        //formContext.getControl("rsa_generaterenewals").setFocus();
    },
    RenewalGeneration_Click: function (primaryControl) {
        //debugger;
        var formContext = primaryControl;
        if (!RSA.D365CRM.RenewalGeneration.Ribbon._preOperationValidation(formContext, 1)) {
            console.log("_preOperationValidation logic has failed");
            return;
        }

        var entityName = "rsa_renewalgenerations";
        var entityId = formContext.data.entity.getId().slice(1, -1);
        var triggeredBy = Xrm.Utility.getGlobalContext().userSettings.userId.slice(1, -1);

        var entity = {};
        entity.rsa_generaterenewalsstatus = RSA.D365CRM.RenewalGeneration.Ribbon.GenerateRenewalsStatus.InProgress;
        entity.rsa_datetimegeneraterenewalsrun = new Date().toUTCString();
        RSA.D365CRM.RenewalGeneration.Ribbon.UpdateEntity(formContext, entityName, entityId, entity, false);
        RSA.D365CRM.RenewalGeneration.Ribbon._refreshForm(formContext);

        var parameters = {};
        parameters.renewalId = formContext.data.entity.getId();
        parameters.mode = RSA.D365CRM.RenewalGeneration.Ribbon.Mode.RenewalGeneration; //"RenewalGeneration";
        parameters.triggeredBy = Xrm.Utility.getGlobalContext().userSettings.userId;

        RSA.D365CRM.RenewalGeneration.Ribbon.ExecuteAction(formContext, "rsa_RenewalGeneration", parameters, true);
        RSA.D365CRM.RenewalGeneration.Ribbon._refreshForm(formContext);

        formContext.getControl("rsa_generaterenewalsstatus").setFocus();
    },
    Clone_Click: function (primaryControl) {
        //debugger;
        var formContext = primaryControl;

        var entityName = "rsa_renewalgenerations";
        var entity = {};
        if (formContext.getAttribute("rsa_policyrenewaldatefrom").getValue() != undefined && formContext.getAttribute("rsa_policyrenewaldatefrom").getValue() != null)
            entity.rsa_policyrenewaldatefrom = formContext.getAttribute("rsa_policyrenewaldatefrom").getValue();
        if (formContext.getAttribute("rsa_policyrenewaldateto").getValue() != undefined && formContext.getAttribute("rsa_policyrenewaldateto").getValue() != null)
            entity.rsa_policyrenewaldateto = formContext.getAttribute("rsa_policyrenewaldateto").getValue();
        if (formContext.getAttribute("rsa_name").getValue() != undefined && formContext.getAttribute("rsa_name").getValue() != null)
            entity.rsa_name = formContext.getAttribute("rsa_name").getValue().substring(0, 31) + " - Cloned";
        if (formContext.getAttribute("rsa_mingwp").getValue() != undefined && formContext.getAttribute("rsa_mingwp").getValue() != null)
            entity.rsa_mingwp = formContext.getAttribute("rsa_mingwp").getValue();
        if (formContext.getAttribute("rsa_gwpmax").getValue() != undefined && formContext.getAttribute("rsa_gwpmax").getValue() != null)
            entity.rsa_gwpmax = formContext.getAttribute("rsa_gwpmax").getValue();
        if (formContext.getAttribute("rsa_product_class").getValue() != undefined && formContext.getAttribute("rsa_product_class").getValue() != null) {
            var rsa_product_class = formContext.getAttribute("rsa_product_class").getValue();
            entity.rsa_product_class = rsa_product_class[0].toString();
        }
        if (formContext.getAttribute("rsa_renewalreviewtype").getValue() != undefined && formContext.getAttribute("rsa_renewalreviewtype").getValue() != null) {
            var rsa_renewalreviewtype = formContext.getAttribute("rsa_renewalreviewtype").getValue();
            entity.rsa_renewalreviewtype = rsa_renewalreviewtype[0].toString();
        }
        if (formContext.getAttribute("rsa_opshandlingsite").getValue() != undefined && formContext.getAttribute("rsa_opshandlingsite").getValue() != null) {
            var rsa_opshandlingsite = formContext.getAttribute("rsa_opshandlingsite").getValue();
            entity.rsa_opshandlingsite = rsa_opshandlingsite[0].toString();
        }
        var entityId = RSA.D365CRM.RenewalGeneration.Ribbon.CreateEntity(formContext, entityName, entity, false);
        if (entityId != undefined && entityId != null) {
            var entityFormOptions = {};
            entityFormOptions["entityName"] = "rsa_renewalgeneration";
            entityFormOptions["entityId"] = entityId;
            Xrm.Navigation.openForm(entityFormOptions).then(
                function (success) {
                    console.log(success);
                },
                function (error) {
                    console.log(error);
                });
        }
    },
    CreateEntity: function (formContext, entityName, entity, isAsync) {
        //debugger;

        var newEntityId;
        var req = new XMLHttpRequest();
        req.open("POST", formContext.context.getClientUrl() + "/api/data/v8.2/" + entityName, isAsync);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                //debugger;
                if (this.status === 204) {
                    //Success - No Return Data - Do Something

                    var uri = this.getResponseHeader("OData-EntityId");
                    var regExp = /\(([^)]+)\)/;
                    var matches = regExp.exec(uri);
                    newEntityId = matches[1];
                } else {
                    Xrm.Utility.alertDialog(this.statusText);
                }
            }
        };
        req.send(JSON.stringify(entity));

        return newEntityId;
    },
    UpdateEntity: function (formContext, entityName, entityId, entity, isAsync) {
        //debugger;
        var req = new XMLHttpRequest();
        req.open("PATCH", formContext.context.getClientUrl() + "/api/data/v8.2/" + entityName + "(" + entityId + ")", isAsync);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                //debugger;
                if (this.status === 204) {
                    //Success - No Return Data - Do Something
                } else {
                    Xrm.Utility.alertDialog(this.statusText);
                }
            }
        };
        req.send(JSON.stringify(entity));
    },
    ExecuteAction: function (formContext, actionName, parameters, isAsync) {
        //debugger
        var req = new XMLHttpRequest();
        req.open("POST", formContext.context.getClientUrl() + "/api/data/v8.2/" + actionName, isAsync);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                //debugger;
                if (this.status === 204) {
                    //Success - No Return Data - Do Something
                } else {
                    Xrm.Utility.alertDialog(this.statusText);
                }
            }
        };
        req.send(JSON.stringify(parameters));
    },
    _preOperationValidation: function (formContext, operationType) {
        //debugger;
        var _boolValidateOperation = false;
        if (typeof operationType != 'undefined' && operationType != null) {
            if (typeof formContext.getAttribute("rsa_generaterenewalsstatus").getValue() != 'undefined' && formContext.getAttribute("rsa_generaterenewalsstatus").getValue() == RSA.D365CRM.RenewalGeneration.Ribbon.GenerateRenewalsStatus.InProgress) {
                formContext.ui.setFormNotification("Renewal Generation process is running for this Renewal Generation. Please wait for the operation to complete.", "ERROR", "ErrRenewalGenerationInProgress");
                formContext.getControl("rsa_generaterenewalsstatus").setFocus();
                return _boolValidateOperation;
            }
            else {
                _boolValidateOperation = true;
                formContext.ui.clearFormNotification("ErrRenewalGenerationInProgress");
            }

            if (operationType == RSA.D365CRM.RenewalGeneration.Ribbon.OperationType.IdentifyRenewal) {
                formContext.ui.clearFormNotification("ErrNoPolicyForRenewal");
                formContext.ui.clearFormNotification("ErrRenewalGenerationCheckbox");
            }
            else if (operationType == RSA.D365CRM.RenewalGeneration.Ribbon.OperationType.RenewalGeneration) {
                if (!(formContext.getAttribute("rsa_totalpoliciesidentifiedforrenewal").getValue() != undefined &&
                    formContext.getAttribute("rsa_totalpoliciesidentifiedforrenewal").getValue() != null &&
                    formContext.getAttribute("rsa_totalpoliciesidentifiedforrenewal").getValue() > 0)) {
                    formContext.ui.setFormNotification("No policy has been identified due for renewal. Please modify the Renewal Generation criteria and execute Identify Renewal again.", "ERROR", "ErrNoPolicyForRenewal");
                    formContext.getControl("rsa_totalpoliciesidentifiedforrenewal").setFocus();
                    _boolValidateOperation = false;
                    return _boolValidateOperation;
                }
                else {
                    _boolValidateOperation = true;
                    formContext.ui.clearFormNotification("ErrNoPolicyForRenewal");
                }
                if (formContext.getAttribute("rsa_generaterenewals").getValue() != undefined && formContext.getAttribute("rsa_generaterenewals").getValue() != RSA.D365CRM.RenewalGeneration.Ribbon.GenerateRenewalsCheckbox.Yes) {
                    formContext.ui.setFormNotification("Please select the Generate Renewals checkbox.", "ERROR", "ErrRenewalGenerationCheckbox");
                    formContext.getControl("rsa_generaterenewals").setFocus();
                    _boolValidateOperation = false;
                    return _boolValidateOperation;
                }
                else {
                    _boolValidateOperation = true;
                    formContext.ui.clearFormNotification("ErrRenewalGenerationCheckbox");
                }
            }
        }
        return _boolValidateOperation;
    },
    _refreshForm: function (formContext) {
        formContext.data.refresh();
    },

    __namespace: true,
    __typeName: "RSA.D365CRM.RenewalGeneration.Ribbon"
});