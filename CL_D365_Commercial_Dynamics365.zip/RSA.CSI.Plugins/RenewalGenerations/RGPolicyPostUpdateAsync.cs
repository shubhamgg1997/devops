﻿using Microsoft.Xrm.Sdk;
using RSA.CSI.Plugins.Common;
using System;
using RSA.CSI.Plugins.Logic;
using RSA.CSI.Plugins.RenewalGenerations.Logic;

namespace RSA.CSI.Plugins.RenewalGeneration
{
    public class RGPolicyPostUpdateAsync : PluginBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="RGPolicyPostUpdateAsync"/> class.
        /// </summary>
        public RGPolicyPostUpdateAsync()
            : base(typeof(RGPolicyPostUpdateAsync))
        {
            RegisteredEvents.Add(new Tuple<int, string, string, Action<LocalPluginContext>>(40, "Update", "rsa_policy", UpdatePolicyForRenewal));
        }

        /// <summary>
        /// Start executing the record when the regsiterd event occurs
        /// </summary>
        /// <param name="localContext"></param>
        protected void UpdatePolicyForRenewal(LocalPluginContext localContext)
        {
            #region Generic block of Context null checking and service creation block

            if (localContext == null)
            {
                throw new InvalidPluginExecutionException("Failed to retrieve plugin context.");
            }
            IPluginExecutionContext context = localContext.PluginExecutionContext;
            IOrganizationService service = localContext.OrganizationService;
            ITracingService tracingService = localContext.TracingService;

            #endregion Generic block of Context null checking and service creation block

            if (context.PostEntityImages["PolicyPostImage"] != null)
            {
                #region Get Input parameters

                tracingService.Trace("Getting post image entity");
                tracingService.Trace("Plugin Depth.." + context.Depth);
                Entity entityPolicy = (Entity)context.PostEntityImages["PolicyPostImage"];
                tracingService.Trace("Successfully fetched post image entity");
                RGPolicyUpdateLogic rGPolicyUpdateLogic = new RGPolicyUpdateLogic();
                rGPolicyUpdateLogic.Execute(service, tracingService, entityPolicy);                
                #endregion Get Input parameters
            }
            else
            {
                tracingService.Trace("Failed to create opportunity ...");
            }
        }
    }
}