﻿using Microsoft.Xrm.Sdk;
using RSA.CSI.Plugins.Common;
using System;
using RSA.CSI.Plugins.Logic;

namespace RSA.CSI.Plugins.RenewalGeneration
{
    public class RenewalGenerationAction : PluginBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="RenewalGenerationAction"/> class.
        /// </summary>
        public RenewalGenerationAction()
            : base(typeof(RenewalGenerationAction))
        {
            //sync 
            RegisteredEvents.Add(new Tuple<int, string, string, Action<LocalPluginContext>>(40, "rsa_IdentifyRenewal", "", ExecuteIdentifyAction));
            //Async
            RegisteredEvents.Add(new Tuple<int, string, string, Action<LocalPluginContext>>(40, "rsa_RenewalGeneration", "", ExecuteRenewalProcessAction));
        }

        /// <summary>
        /// Start executing the record when the regsiterd event occurs
        /// </summary>
        /// <param name="localContext"></param>
        protected void ExecuteIdentifyAction(LocalPluginContext localContext)
        {
            #region Generic block of Context null checking and service creation block

            if (localContext == null)
            {
                throw new InvalidPluginExecutionException("Failed to retrieve plugin context.");
            }
            IPluginExecutionContext context = localContext.PluginExecutionContext;
            IOrganizationService service = localContext.OrganizationService;
            ITracingService tracingService = localContext.TracingService;

            #endregion Generic block of Context null checking and service creation block

            try
            {
                if (context.InputParameters["renewalId"] != null && context.InputParameters["triggeredBy"] != null)
                {
                    #region Get Input parameters
                    tracingService.Trace("Renewal Id: " + (string)context.InputParameters["renewalId"]);
                    Guid renewalId = new Guid(((string)context.InputParameters["renewalId"]).Replace("{", "").Replace("}", ""));
                    tracingService.Trace("Identify Renewals triggered Id: " + renewalId);
                    Guid triggeredBy = new Guid(((string)context.InputParameters["triggeredBy"]).Replace("{", "").Replace("}", ""));
                    tracingService.Trace("Identify Renewals triggered Id: " + triggeredBy.ToString());
                    #endregion Get Input parameters

                    #region Identify Renewals process
                    tracingService.Trace("Calling GetRenwalGenerationDetails() ....");
                    RenewalGenerationLogic renewalGenerationLogic = new RenewalGenerationLogic();
                    renewalGenerationLogic.ExecuteIdentifyRenewal(service, tracingService, renewalId, triggeredBy);

                    #endregion Identify Renewals process
                }
                else
                {
                    throw new InvalidPluginExecutionException("Wrong Input. Contact your administrator.");
                }
            }
            catch (InvalidPluginExecutionException exception) { throw new InvalidPluginExecutionException(exception.Message); }
            catch (Exception exception) { throw new InvalidPluginExecutionException(exception.Message); }
        }

        /// <summary>
        /// Start executing the record when the regsiterd event occurs
        /// </summary>
        /// <param name="localContext"></param>
        protected void ExecuteRenewalProcessAction(LocalPluginContext localContext)
        {
            #region Generic block of Context null checking and service creation block

            if (localContext == null)
            {
                //throw new ArgumentNullException("localContext");
                //Remediation - 19/07/2022
                throw new InvalidPluginExecutionException("localContext");
            }
            IPluginExecutionContext context = localContext.PluginExecutionContext;
            IOrganizationService service = localContext.OrganizationService;
            ITracingService tracingService = localContext.TracingService;
            #endregion Generic block of Context null checking and service creation block

            if (context.InputParameters["renewalId"] != null && context.InputParameters["triggeredBy"] != null)
            {
                #region Get Input parameters
                tracingService.Trace("Renewal Id: " + (string)context.InputParameters["renewalId"]);
                Guid renewalId = new Guid(((string)context.InputParameters["renewalId"]).Replace("{", "").Replace("}", ""));
                tracingService.Trace("Identify Renewals triggered Id: " + renewalId);
                Guid triggeredBy = new Guid(((string)context.InputParameters["triggeredBy"]).Replace("{", "").Replace("}", ""));
                #endregion Get Input parameters

                #region Renewals Generation process
                tracingService.Trace("Calling GetRenwalGenerationDetails() ....");
                RenewalGenerationLogic renewalGenerationLogic = new RenewalGenerationLogic();
                renewalGenerationLogic.ExecuteRenewalGeneration(service, tracingService, renewalId, triggeredBy);

                #endregion Identify Renewals process
            }
            else
            {
                throw new InvalidPluginExecutionException("Wrong Input. Contact your administrator.");
            }
        }
    }
}