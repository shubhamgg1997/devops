﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSA.CSI.Plugins.RenewalGenerations.Common
{
    internal class Entities
    {
        internal class RenewalGeneration
        {
            string entityName;
            Guid entityId;
            DateTime startDateTime;
            DateTime endDateTime;
            int status;
            Guid triggeredById;
            decimal failedCount = 0;
            decimal successCount = 0;
            decimal identifiedPolicyCount = 0;

            public DateTime StartDateTime { get => startDateTime; set => startDateTime = value; }
            public DateTime EndDateTime { get => endDateTime; set => endDateTime = value; }
            public int Status { get => status; set => status = value; }
            public Guid TriggeredById { get => triggeredById; set => triggeredById = value; }
            public Guid EntityId { get => entityId; set => entityId = value; }
            public string EntityName { get => entityName; set => entityName = value; }
            public decimal FailedCount { get => failedCount; set => failedCount = value; }
            public decimal SuccessCount { get => successCount; set => successCount = value; }
            public decimal IdentifiedPolicyCount { get => identifiedPolicyCount; set => identifiedPolicyCount = value; }

        }

        internal class PolicyUpdate
        {
            string entityName;
            Guid entityId;
            DateTime startDateTime;
            DateTime endDateTime;
            int status;
            Guid triggeredById;
            decimal failedCount = 0;
            decimal successCount = 0;
            decimal identifiedPolicyCount = 0;

            public DateTime StartDateTime { get => startDateTime; set => startDateTime = value; }
            public DateTime EndDateTime { get => endDateTime; set => endDateTime = value; }
            public int Status { get => status; set => status = value; }
            public Guid TriggeredById { get => triggeredById; set => triggeredById = value; }
            public Guid EntityId { get => entityId; set => entityId = value; }
            public string EntityName { get => entityName; set => entityName = value; }
            public decimal FailedCount { get => failedCount; set => failedCount = value; }
            public decimal SuccessCount { get => successCount; set => successCount = value; }
            public decimal IdentifiedPolicyCount { get => identifiedPolicyCount; set => identifiedPolicyCount = value; }

        }

        internal class InsertProgress
        {
            Guid policyId;
            Guid opportunityId;
            Guid caseId;
            Boolean isOpportunityCreated;
            Boolean isCaseCreated;
            Entity policy;
            Entity successOpportunity;
            Entity successCase;
            Entity renewalGeneration;
            String name;
            string policyRenewalGenerationFailedReason;
            int policyRenewalGenerationStatusCode;

            public Guid PolicyId { get => policyId; set => policyId = value; }
            public Guid OpportunityId { get => opportunityId; set => opportunityId = value; }
            public Guid CaseId { get => caseId; set => caseId = value; }
            public bool IsOpportunityCreated { get => isOpportunityCreated; set => isOpportunityCreated = value; }
            public bool IsCaseCreated { get => isCaseCreated; set => isCaseCreated = value; }
            public Entity Policy { get => policy; set => policy = value; }
            public Entity Opportunity { get => successOpportunity; set => successOpportunity = value; }
            public Entity Case { get => successCase; set => successCase = value; }
            public Entity RenewalGeneration { get => renewalGeneration; set => renewalGeneration = value; }
            public string Name { get => name; set => name = value; }
            public string PolicyRenewalGenerationFailedReason { get => policyRenewalGenerationFailedReason; set => policyRenewalGenerationFailedReason = value; }
            public int PolicyRenewalGenerationStatusCode { get => policyRenewalGenerationStatusCode; set => policyRenewalGenerationStatusCode = value; }

        }
    }
}