﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSA.CSI.Plugins.RenewalGenerations.Common
{
    internal class Constants
    {
        internal const string POLICY_FAIL_REASON_MAND_FLDS_UNAVLBLE = "Data in Mandatory fields not available";
        internal const string POLICY_FAIL_REASON_TRADER_INACTIVE = "Policy Trader is Inactive in D365";
        internal const string POLICY_FAIL_REASON_CUST_UNAVAILABLE = "Customer not available for the policy";
        internal const string POLICY_FAIL_REASON_BROKER_UNAVAILABLE = "Broker not available for the policy";
        internal const string POLICY_FAIL_SYS_EXCEPTION = "System Exception";
        internal const int POLICY_FAIL_STATUS = 860002;
        internal const int POLICY_SUCCESS_STATUS = 860001;
        internal const int POLICY_PENDING_STATUS = 860000;
        internal const string NEW_RENEWAL_CASE_TYPE = "Renewal"; // should be from optionset but Entity created
        internal const string NEW_RENEWAL_CASE_STATUS = "Initial Processing"; // should be from optionset but Entity created
        internal const int NEW_RENEWAL_CASE_RECORDTYPE = 866760020;
        /// <summary>
        /// BPO Renewals
        /// </summary>
        internal const string NEW_RENEWAL_CASE_QUEUE = "99172d9f-2ac7-ea11-a812-000d3af01f8c";
        /// <summary>
        /// Renewal - Automated
        /// </summary>
        internal const int NEW_RENEWAL_CASE_ORIGIN = 866760002;
        internal const string LINE_OF_BUSINESS_GSL_RENEWAL = "GSL - Renewal"; //Renewals - Marine London
        internal const string LINE_OF_BUSINESS_GSL_RENEWAL_MARINE_LONDON = "Renewal - Marine London"; //Renewals - Marine London
        internal const string LINE_OF_BUSINESS_GSL_RENEWAL_REGIONAL_MARIENE = "Renewal - Marine Regional"; //Renewals - Marine London
        internal const string LINE_OF_BUSINESS_LONDON_MARIENE = "London Marine"; // Marine London
        internal const string LINE_OF_BUSINESS_REGIONAL_MARIENE = "Regional Marine"; //Regional Marine
        internal const string POLICY_FAIL_REASON_LOB_GSL_RENEWAL_MISSING = "MISSING 'GSL Renewal' line of business";
        internal const string POLICY_FAIL_REASON_LOB_MARINE_LONDON_MISSING = "MISSING 'Renewal - Marine London' line of business";
        internal const string POLICY_FAIL_REASON_LOB_MARINE_REGIONAL_MISSING = "MISSING 'Renewal - Marine Regional' line of business";
        internal const string POLICY_FAIL_REASON_HANDLER_INACTIVE = "Policy Handler is Inactive in D365";
        //objNewCase.Status = mapRnwlGenConstants.get('NEW_RENEWAL_CASE_STATUS').Constant_Value__c;
        //objNewCase.OwnerId = mapRnwlGenConstants.get('NEW_RENEWAL_CASE_QUEUE').Constant_Value__c;
        //objNewCase.Origin = mapRnwlGenConstants.get('NEW_RENEWAL_CASE_ORIGIN').Constant_Value__c; 
        internal const string LINE_OF_BUSINESS_NEW_BUSINESS_MARINE_LONDON = "New Business - Marine London";
        internal const string LINE_OF_BUSINESS_NEW_BUSINESS_MARINE_REGIONAL = "New Business - Marine Regional";
        //New Business - Marine London
        //New Business - Marine Regional"
    }
}