﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;

namespace RSA.CSI.Plugins.Logic
{
    internal class RenewalGenerationLogic
    {
        #region Constant Variables
        private const string POLICY_FAIL_REASON_MAND_FLDS_UNAVLBLE = "Data in Mandatory fields not available";
        private const string POLICY_FAIL_REASON_TRADER_INACTIVE = "Policy Trader is Inactive in D365";
        private const string POLICY_FAIL_REASON_CUST_UNAVAILABLE = "Customer not available for the policy";
        private const string POLICY_FAIL_REASON_BROKER_UNAVAILABLE = "Broker not available for the policy";
        private const string POLICY_FAIL_SYS_EXCEPTION = "System Exception";
        private const int POLICY_FAIL_STATUS = 860002;
        private const int POLICY_SUCCESS_STATUS = 860001;
        private const int POLICY_PENDING_STATUS = 860000;
        private const string NEW_RENEWAL_CASE_TYPE = "Renewal"; // should be from optionset but Entity created
        private const string NEW_RENEWAL_CASE_STATUS = "Initial Processing"; // should be from optionset but Entity created
        private const int NEW_RENEWAL_CASE_RECORDTYPE = 866760020;
        private string POLICY_DETAILS_QUERY = string.Empty;
        /// <summary>
        /// BPO Renewals
        /// </summary>
        private const string NEW_RENEWAL_CASE_QUEUE = "99172d9f-2ac7-ea11-a812-000d3af01f8c";
        /// <summary>
        /// Renewal - Automated
        /// </summary>
        private const int NEW_RENEWAL_CASE_ORIGIN = 866760002;
        private const string LINE_OF_BUSINESS_GSL_RENEWAL = "GSL - Renewal"; //Renewals - Marine London
        private const string LINE_OF_BUSINESS_GSL_RENEWAL_MARINE_LONDON = "Renewal - Marine London"; //Renewals - Marine London
        private const string LINE_OF_BUSINESS_GSL_RENEWAL_REGIONAL_MARIENE = "Renewal - Marine Regional"; //Renewals - Marine London
        private const string LINE_OF_BUSINESS_LONDON_MARIENE = "London Marine"; // Marine London
        private const string LINE_OF_BUSINESS_REGIONAL_MARIENE = "Regional Marine"; //Regional Marine
        private const string POLICY_FAIL_REASON_LOB_GSL_RENEWAL_MISSING = "MISSING 'GSL Renewal' line of business";
        private const string POLICY_FAIL_REASON_LOB_MARINE_LONDON_MISSING = "MISSING 'Renewal - Marine London' line of business";
        private const string POLICY_FAIL_REASON_LOB_MARINE_REGIONAL_MISSING = "MISSING 'Renewal - Marine Regional' line of business";
        private const string POLICY_FAIL_REASON_HANDLER_INACTIVE = "Policy Handler is Inactive in D365";
        private const string LINE_OF_BUSINESS_NEW_BUSINESS_MARINE_LONDON = "New Business - Marine London";
        private const string LINE_OF_BUSINESS_NEW_BUSINESS_MARINE_REGIONAL = "New Business - Marine Regional";
        #endregion Constant Variables

        #region Identify Renewal
        internal void ExecuteIdentifyRenewal(IOrganizationService service, ITracingService tracingService, Guid guidRenewalGenerationId, Guid guidTriggeredById)
        {
            tracingService.Trace("Identify Renewals started");
            
            DateTime dtExecutionStartTime = DateTime.UtcNow;
            var enRenewalGeneration = GetRenwalGenerationDetails(service, tracingService, guidRenewalGenerationId);
            tracingService.Trace("Fetched renewal generation details");
            if (enRenewalGeneration == null) return;

            POLICY_DETAILS_QUERY = this.GetCustomLabel(service, tracingService, "RenewalGeneration.IdentifyAndExecute", true);
            if (string.IsNullOrEmpty(POLICY_DETAILS_QUERY))
            {
                tracingService.Trace($"RenewalGeneration.IdentifyAndExecute value cannot be blank");
                //throw new Exception($"RenewalGeneration.IdentifyAndExecute value cannot be blank");
                return;
            }
            tracingService.Trace("Eneterd RSA.CSI.Plugins.RenewalGenerationLogic.RenewalGenerationCommon.ExecuteRenewalGeneration() method.");
            string query = this.GenerateQueryPolicyDetails(service, tracingService, enRenewalGeneration, true);
            tracingService.Trace("Query fetched successfully" + query);
            decimal policyCount = 0;
            tracingService.Trace("Validate and Update policy stated");
            UpdatePolicyDetails(service, tracingService, query, out policyCount, enRenewalGeneration, guidTriggeredById, true, dtExecutionStartTime);
            tracingService.Trace("Validate and Update policy ended with total policy fetched: " + policyCount);
        }
        /// <summary>
        /// fetch renewal generation entity details 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="requestRenewalGenerationEntity"></param>
        /// <returns>rsa_renewalgeneration</returns>
        private Entity GetRenwalGenerationDetails(IOrganizationService service, ITracingService tracingService, Guid requestRenewalGenerationEntity)
        {
            Entity returnRenewalGeneration = null;
            var fetchXmlRenewalGeneration = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='rsa_renewalgeneration'>
                                                <attribute name='rsa_renewalgenerationid' />
                                                <attribute name='rsa_name' />
                                                <attribute name='createdon' />
                                                <attribute name='rsa_renewalreviewtype' />
                                                <attribute name='rsa_policyrenewaldateto' />
                                                <attribute name='rsa_policyrenewaldatefrom' />
                                                <attribute name='rsa_mingwp' />
                                                <attribute name='rsa_gwpmax' />
                                                <attribute name='rsa_product_class' />
                                                <attribute name='rsa_opshandlingsite' />
                                                <attribute name='rsa_totalpoliciesidentifiedforrenewal' />
                                                <order attribute='rsa_name' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='rsa_renewalgenerationid' operator='eq' value='{0}'/>
                                                </filter>
                                              </entity>
                                            </fetch>";
            var query = String.Format(fetchXmlRenewalGeneration, requestRenewalGenerationEntity.ToString());
            tracingService.Trace("Query Renewal Generation: " + query);
            var entityColRenewalGeneration = service.RetrieveMultiple(new FetchExpression(query));
            foreach (var entity in entityColRenewalGeneration.Entities)
            {
                tracingService.Trace("Successfully get the Renewal details ...");
                returnRenewalGeneration = (Entity)entity;
                tracingService.Trace("End get the Renewal details ...");
            }
            return returnRenewalGeneration;
        }
        /// <summary>
        /// Get attribute list for Renewal Generation process fetch xml, and empty string for Identify Renewal process
        /// </summary>
        /// <param name="isIdentifyRenewal"></param>
        /// <returns></returns>
        private string GetPolicyAttributes(bool isIdentifyRenewal)
        {
            var fetchPolicyAttributes = @"<attribute name='rsa_tradinghandlingsite' />
                                            <attribute name='rsa_renewable' />
                                            <attribute name='rsa_productname' />
                                            <attribute name='rsa_ppmscore' />
                                            <attribute name='rsa_policytrader' />
                                            <attribute name='rsa_policyrenewaldate' />
                                            <attribute name='rsa_policyhandler' />
                                            <attribute name='rsa_name' />
                                            <attribute name='rsa_fapcurrency' />
                                            <attribute name='rsa_epicurrency' />
                                            <attribute name='rsa_classofbusiness' />
                                            <attribute name='rsa_broker' />
                                            <attribute name='rsa_mumbaihandler' />
                                            <attribute name='rsa_rsaexpiringpremiumpc' />
                                            <attribute name='rsa_rsaexpiringcommissionpercent' />
                                            <attribute name='rsa_rsaexpiringcommissionpc' />
                                            <attribute name='rsa_policysystemcode' />
                                            <attribute name='rsa_policynumber' />
                                            <attribute name='ownerid' />
                                            <attribute name='rsa_expiringpolicysystem' />
                                            <attribute name='rsa_expiringpolicynumber' />
                                            <attribute name='rsa_expiringbranch' />
                                            <attribute name='rsa_classificationcode' />
                                            <attribute name='rsa_atlasclientid' />
                                            <attribute name='rsa_3yearlossratio' />
                                            <attribute name='rsa_vat' />
                                            <attribute name='rsa_state' />
                                            <attribute name='rsa_sourcecountry' />
                                            <attribute name='rsa_sourcearea' />
                                            <attribute name='rsa_methodofplacement' />
                                            <attribute name='rsa_exposurecountry' />
                                            <attribute name='rsa_exposurearea' />
                                            <attribute name='rsa_typeofrisk' />
                                            <attribute name='rsa_source' />
                                            <attribute name='rsa_reviewtypecode' />
                                            <attribute name='rsa_renewalgenerationstatuscode' />
                                            <attribute name='rsa_premium' />
                                            <attribute name='rsa_operationshandlingsite' />
                                            <attribute name='rsa_marinestamp' />
                                            <attribute name='rsa_customer' />
                                            <attribute name='rsa_policysystemcode' />
                                            <attribute name='rsa_plcode' />
                                            <attribute name = 'rsa_productid' />";
            if (isIdentifyRenewal) fetchPolicyAttributes = string.Empty;
            return fetchPolicyAttributes;
        }

        /// <summary>
        /// Get policy count and policy entity details based on renewal generation parameters
        /// </summary>
        /// <param name="service"></param>
        /// <param name="requestRenewalGeneration"></param>
        /// <param name="isIdentifyRenewal"></param>
        /// <returns></returns>
        private string GenerateQueryPolicyDetails(IOrganizationService service, ITracingService tracingService, Entity requestRenewalGeneration, bool isIdentifyRenewal)
        {
            #region Field Missing to do items
            //Reinsured_Name__c 
            //P_L__c = rsa_pl
            //Opportunity__c = rsa_opportunity,
            //Synergy_Branch__c
            //Opportunity__r.Region__c = rsa_region,
            //     Opportunity__r.Secondary_Owner__c = rsa_secondaryowner,
            //     Opportunity__r.recordTypeID = rsa_recordtype
            //     Opportunity__r.Expiry_Date_Marine__c ?,
            //     Opportunity__r.Description__c = rsa_opportunitydescription,
            //     Opportunity__r.Description = description,
            //     Opportunity__r.Date_Quote_Received__c = rsa_datequotereceived,
            //    Opportunity__r.Source_Country__c = ?,
            //    Opportunity__r.Classification__c = ?,
            //    Opportunity__r.Payment_Terms__c c = ?,
            //    Opportunity__r.Method_of_Placement__c = ?,
            //    Opportunity__r.TRI__c = ?,
            //     Opportunity__r.TRI_PC__c = rsa_tripc,
            //     Opportunity__r.Policy_Limit_PC__c = rsa_policylimitpc,
            //     Opportunity__r.Currency__c = rsa_currency,
            //    Opportunity__r.Annual_Aggregate_Deduction_ELC_PC__c ?,
            //     Opportunity__r.Broker_Primary_Reference__c = rsa_brokerprimaryreference, 
            #endregion Field Missing to do items
            string fetchXmlTop = isIdentifyRenewal ? "top='1000'" : string.Empty;
            var emptyCondition = "<value></value>";

            var fetchXmlPolicy = POLICY_DETAILS_QUERY;
            var policyrenewaldatefrom = requestRenewalGeneration.Attributes.Contains("rsa_policyrenewaldatefrom") ? requestRenewalGeneration.GetAttributeValue<DateTime>("rsa_policyrenewaldatefrom").ToLocalTime() : DateTime.Now;
            var policyrenewaldateto = requestRenewalGeneration.Attributes.Contains("rsa_policyrenewaldateto") ? requestRenewalGeneration.GetAttributeValue<DateTime>("rsa_policyrenewaldateto").ToLocalTime() : DateTime.Now;

            //Sumegh Dhole : 13 May 2022 : A-23394 - Profin Regions - A&H - Renewal cases allocated to centre PIU & BOF queue
            //2645 :handle the UTC date to the local date for renewal generation issue. UTC to convert into local time to handle daylight savings time difference.
            int? userTimezone = RetrieveCurrentUsersSettings(service);

            policyrenewaldatefrom = RetrieveLocalTimeFromUTCTime(policyrenewaldatefrom, userTimezone, service);
            policyrenewaldateto = RetrieveLocalTimeFromUTCTime(policyrenewaldateto, userTimezone, service);
            //2645 : Code complete

            var valueProductClass = requestRenewalGeneration.Attributes.Contains("rsa_product_class") ? GenerateStringCondition(requestRenewalGeneration.GetAttributeValue<OptionSetValueCollection>("rsa_product_class")) : string.Empty;
            //var valueOpsHandlingSite = requestRenewalGeneration.Attributes.Contains("rsa_opshandlingsite") ? GenerateStringInOperator(requestRenewalGeneration.GetAttributeValue<OptionSetValueCollection>("rsa_opshandlingsite")): emptyCondition;
            //Defect 2098
            var valueOpsHandlingSite = requestRenewalGeneration.Attributes.Contains("rsa_opshandlingsite") ? "<condition attribute='rsa_operationshandlingsite' operator='in' >" + GenerateStringInOperator(requestRenewalGeneration.GetAttributeValue<OptionSetValueCollection>("rsa_opshandlingsite")) + "</condition>" : string.Empty;
            //var valueReviewType = requestRenewalGeneration.Attributes.Contains("rsa_renewalreviewtype") ? GenerateStringInOperator(requestRenewalGeneration.GetAttributeValue<OptionSetValueCollection>("rsa_renewalreviewtype")) : emptyCondition;
            //Defect 2098
            var valueReviewType = requestRenewalGeneration.Attributes.Contains("rsa_renewalreviewtype") ? "<condition attribute='rsa_reviewtypecode' operator='in'>" + GenerateStringInOperator(requestRenewalGeneration.GetAttributeValue<OptionSetValueCollection>("rsa_renewalreviewtype")) + "</condition>" : string.Empty;

            fetchXmlPolicy = String.Format(fetchXmlPolicy, GetPolicyAttributes(isIdentifyRenewal), valueReviewType,
                this.GetGWPCondition(requestRenewalGeneration),
                policyrenewaldatefrom,
                policyrenewaldateto, valueOpsHandlingSite, valueProductClass, fetchXmlTop); ;
            return fetchXmlPolicy;
        }

        public DateTime RetrieveLocalTimeFromUTCTime(DateTime utcTime, int? timeZoneCode, IOrganizationService service)
        {
            if (!timeZoneCode.HasValue)

                return DateTime.Now;

            var request = new LocalTimeFromUtcTimeRequest
            {

                TimeZoneCode = timeZoneCode.Value,

                UtcTime = utcTime.ToUniversalTime()

            };
            var response = (LocalTimeFromUtcTimeResponse)service.Execute(request);
            return response.LocalTime;

        }

        public int? RetrieveCurrentUsersSettings(IOrganizationService service)
        {
            var currentUserSettings = service.RetrieveMultiple(
                new QueryExpression("usersettings")
                {
                    ColumnSet = new ColumnSet("timezonecode"),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {

                            new ConditionExpression("systemuserid", ConditionOperator.EqualUserId)
                        }
                    },

                    NoLock = true

                }).Entities[0].ToEntity<Entity>();
            //return time zone code
            return (int?)currentUserSettings.Attributes["timezonecode"];

        }
        /// <summary>
        /// create xml for execute multiple
        /// </summary>
        /// <param name="service"></param>
        /// <param name="xml"></param>
        /// <param name="cookie"></param>
        /// <param name="page"></param>
        /// <param name="count"></param>
        /// <returns></returns>
        public string CreateXml(IOrganizationService service, string xml, string cookie, int page, int count)
        {
            StringReader stringReader = new StringReader(xml);
            XmlTextReader reader = new XmlTextReader(stringReader);
            // Load document
            XmlDocument doc = new XmlDocument();
            //Remediation - 22/07/2022
            try 
            {
                doc.Load(reader);
            }
            catch (Exception ex) 
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
            finally 
            {
                stringReader.Close();
                reader.Close();
            }
            return CreateXml(service, doc, cookie, page, count);
        }
        /// <summary>
        /// create xml for execute multiple
        /// </summary>
        /// <param name="service"></param>
        /// <param name="doc"></param>
        /// <param name="cookie"></param>
        /// <param name="page"></param>
        /// <param name="count"></param>
        /// <returns></returns>
        public string CreateXml(IOrganizationService service, XmlDocument doc, string cookie, int page, int count)
        {
            XmlAttributeCollection attrs = doc.DocumentElement.Attributes;
            if (cookie != null)
            {
                XmlAttribute pagingAttr = doc.CreateAttribute("paging-cookie");
                pagingAttr.Value = cookie;
                attrs.Append(pagingAttr);
            }
            XmlAttribute pageAttr = doc.CreateAttribute("page");
            pageAttr.Value = System.Convert.ToString(page);
            attrs.Append(pageAttr);
            XmlAttribute countAttr = doc.CreateAttribute("count");
            countAttr.Value = System.Convert.ToString(count);
            attrs.Append(countAttr);
            StringBuilder sb = new StringBuilder(1024);
            StringWriter stringWriter = new StringWriter(sb);
            XmlTextWriter writer = new XmlTextWriter(stringWriter);
            //doc.WriteTo(writer);
            //writer.Close();
            //Remediation - 21/07/2022
            try 
            {
                doc.WriteTo(writer);
            }
            catch (Exception ex) 
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
            finally 
            {
                stringWriter.Close();
                writer.Close();
            }
            return sb.ToString();
        }

        /// <summary>
        /// Fetch policy details from D365 database based on Renewal generation parameters
        /// </summary>
        /// <param name="service"></param>
        /// <param name="query"></param>
        /// <param name="policyCount"></param>
        /// <returns></returns>
        private void UpdatePolicyDetails(IOrganizationService service, ITracingService tracingService, string query, out decimal policyCount, Entity enRenewalGeneration, Guid guidTriggeredById, bool isIdentifyRenewal, DateTime dtExecutionStartTime)
        {
            // Define the fetch attributes.
            // Set the number of records per page to retrieve.
            int fetchCount = 1000;
            // Initialize the page number.
            int pageNumber = 1;
            // Initialize the number of records.
            policyCount = 0;
            // Specify the current paging cookie. For retrieving the first page, 
            // pagingCookie should be null.
            string pagingCookie = null;
            int intFailedCountPolicy = 0;
            int intSuccessCountPolicy = 0;            
            try
            {
                if (isIdentifyRenewal)
                {
                    EntityCollection returnCollection = service.RetrieveMultiple(new FetchExpression(query));
                    policyCount = returnCollection.Entities.Count;
                    var renewalGeneration = new RenewalGeneration
                    {
                        EntityName = enRenewalGeneration.LogicalName,
                        EntityId = enRenewalGeneration.Id,
                        StartDateTime = DateTime.Now,                        
                        TriggeredById = guidTriggeredById,
                        IdentifiedPolicyCount = policyCount
                    };
                    this.UpdateRenewalGeneration(service, tracingService, renewalGeneration, false, true);
                }
                else
                {
                    while (true)
                    {
                        // Build fetchXml string with the placeholders.
                        string xml = CreateXml(service, query, pagingCookie, pageNumber, fetchCount);

                        // Excute the fetch query and get the xml result.
                        var fetchRequest1 = new RetrieveMultipleRequest
                        {
                            Query = new FetchExpression(xml)
                        };

                        //EntityCollection returnCollection = ((RetrieveMultipleResponse)service.Execute(fetchRequest1)).EntityCollection;
                        //Remediation - 22/07/2022
                        EntityCollection returnCollection = service.RetrieveMultiple(new FetchExpression(xml));
                        policyCount += returnCollection.Entities.Count;
                        if (!isIdentifyRenewal)
                        {
                            EntityCollection entityColPolicyValidated = this.ValidatePolicy(service, tracingService, returnCollection, enRenewalGeneration);
                            //this.UpdatePolicyExecuteMultiple(service, tracingService, entityColPolicyValidated);
                            //get success 
                            intSuccessCountPolicy += entityColPolicyValidated.Entities.Where(x => ((OptionSetValue)x.Attributes["rsa_renewalgenerationstatuscode"]).Value == 860001).Count();
                            //get fail
                            intFailedCountPolicy += entityColPolicyValidated.Entities.Where(x => ((OptionSetValue)x.Attributes["rsa_renewalgenerationstatuscode"]).Value == 860002).Count();


                            var intStatusRenwalGeneration = this.GetRenewalGenerationStatus(intSuccessCountPolicy, intFailedCountPolicy);
                            var renewalGeneration = new RenewalGeneration
                            {

                                EntityName = enRenewalGeneration.LogicalName,
                                EntityId = enRenewalGeneration.Id,
                                StartDateTime = dtExecutionStartTime,
                                TriggeredById = guidTriggeredById,
                                Status = intStatusRenwalGeneration,
                                SuccessCount = intSuccessCountPolicy,
                                FailedCount = intFailedCountPolicy
                            };
                            this.UpdateRenewalGeneration(service, tracingService, renewalGeneration, true, false);
                            if (intSuccessCountPolicy != 0)
                                this.DeactivateRecord(service, tracingService, "rsa_renewalgeneration", renewalGeneration.EntityId);

                            this.UpdatePolicyExecuteMultiple(service, tracingService, entityColPolicyValidated);
                        }
                        // Check for morerecords, if it returns 1.
                        if (returnCollection.MoreRecords)
                        {
                            // Increment the page number to retrieve the next page.
                            pageNumber++;

                            // Set the paging cookie to the paging cookie returned from current results.                            
                            pagingCookie = returnCollection.PagingCookie;
                        }
                        //else
                        //{
                        // If no more records in the result nodes, exit the loop.
                        break;
                        //}
                    }

                    //var intStatusRenwalGeneration = this.GetRenewalGenerationStatus(intSuccessCountPolicy, intFailedCountPolicy);
                    //var renewalGeneration = new RenewalGeneration
                    //{

                    //    EntityName = enRenewalGeneration.LogicalName,
                    //    EntityId = enRenewalGeneration.Id,
                    //    StartDateTime = dtExecutionStartTime,
                    //    TriggeredById = guidTriggeredById,
                    //    Status = intStatusRenwalGeneration,
                    //    SuccessCount = intSuccessCountPolicy,
                    //    FailedCount = intFailedCountPolicy
                    //};
                    //this.UpdateRenewalGeneration(service, tracingService, renewalGeneration, true, false);
                    //if (intSuccessCountPolicy != 0)
                    //    this.DeactivateRecord(service, tracingService, "rsa_renewalgeneration", renewalGeneration.EntityId);
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception during (UpdatePolicyDetails)" + ex.Message);
            }
        }

        /// <summary>
        /// calculate the status based on number of pass/failed
        /// </summary>
        /// <param name="intSuccessCount"></param>
        /// <param name="intFailedCount"></param>
        /// <returns></returns>
        private int GetRenewalGenerationStatus(int intSuccessCount, int intFailedCount)
        {
            int returnStatusCode = -1;
            //if success = 0 
            if (intSuccessCount == 0 && intFailedCount != 0)
                returnStatusCode = 866760004; // failed
            else if (intSuccessCount != 0 && intFailedCount != 0)
                returnStatusCode = 866760003; // Completed with error
            else if (intSuccessCount != 0 && intFailedCount == 0)
                returnStatusCode = 866760002; // Completed no error
            else
                returnStatusCode = 866760002;//Completed no error

            return returnStatusCode;
        }

        /// <summary>
        /// Get GWP condition tag for policy fetch Xml
        /// </summary>
        /// <param name="requestRenewalGeneration"></param>
        /// <returns></returns>
        private string GetGWPCondition(Entity requestRenewalGeneration)
        {
            var returnValue = string.Empty;
            if (requestRenewalGeneration.Attributes.Contains("rsa_mingwp"))
            {
                decimal value = (requestRenewalGeneration.GetAttributeValue<Money>("rsa_mingwp")).Value;
                returnValue = String.Format("<condition attribute='rsa_premium' operator='ge' value ='{0}'/>", value);
            }
            if (requestRenewalGeneration.Attributes.Contains("rsa_gwpmax"))
            {
                decimal value = (requestRenewalGeneration.GetAttributeValue<Money>("rsa_gwpmax")).Value;
                returnValue += String.Format("<condition attribute='rsa_premium' operator='le' value ='{0}'/>", value);
            }
            return returnValue;
        }
        /// <summary>
        /// Generic function to format 'In' operator for fetchxml
        /// </summary>
        /// <param name="keyCol"></param>
        /// <returns></returns>
        private string GenerateStringInOperator(OptionSetValueCollection keyCol)
        {
            string returnValue = string.Empty;
            foreach (OptionSetValue op in keyCol)
            {
                returnValue += String.Format("<value>{0}</value>", op.Value.ToString());
            }
            return returnValue;
        }
        /// <summary>
        /// Generic function to format <condition></condition> tag for fetchxml
        /// </summary>
        /// <param name="keyCol"></param>
        /// <returns></returns>
        private string GenerateStringCondition(OptionSetValueCollection keyCol)
        {
            string returnValue = string.Empty;
            foreach (OptionSetValue op in keyCol)
            {
                returnValue += String.Format("<condition attribute='rsa_classofbusinesscode' operator='eq' value='{0}' />", op.Value.ToString());
            }
            if (returnValue != string.Empty)
            {
                returnValue = String.Format("<filter type='and'><filter type='or'>{0}</filter></filter>", returnValue);
            }
            return returnValue;
        }
        /// <summary>
        /// Fetch record from Custom Label entity based on key 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        private string GetCustomLabel(IOrganizationService service, ITracingService tracingService, string key)
        {
            var returnValue = string.Empty;
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='rsa_customlabel'>
                                <attribute name='rsa_values' />
                                <attribute name='rsa_shortdescription' />
                                <attribute name='rsa_categories' />   
                                <filter type='and'>
                                  <condition attribute='rsa_name' operator='eq' value='{0}' />
                                </filter>
                              </entity>
                            </fetch>";
            var entityCustomLevel = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, key)));
            if (entityCustomLevel.Entities.Count > 0)
            {
                returnValue = entityCustomLevel[0].Attributes.Contains("rsa_values") ? entityCustomLevel[0].GetAttributeValue<string>("rsa_values") : string.Empty;
            }
            return returnValue;
        }

        /// <summary>
        /// Fetch JSon value of a RSA CUstom Label.
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="key"></param>
        /// <param name="wantToFetchJSonValue"></param>
        /// <returns></returns>
        private string GetCustomLabel(IOrganizationService service, ITracingService tracingService, string key, bool wantToFetchJSonValue)
        {
            var returnValue = string.Empty;
            if (wantToFetchJSonValue)
            {
                var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='rsa_customlabel'>
                                <attribute name='rsa_values' />
                                <attribute name='rsa_shortdescription' />
                                <attribute name='rsa_categories' /> 
                                <attribute name='rsa_dependentoptionsetjson' />
                                <filter type='and'>
                                  <condition attribute='rsa_name' operator='eq' value='{0}' />
                                </filter>
                              </entity>
                            </fetch>";
                var entityCustomLevel = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, key)));
                if (entityCustomLevel.Entities.Count > 0)
                {
                    returnValue = entityCustomLevel[0].Attributes.Contains("rsa_dependentoptionsetjson") ? entityCustomLevel[0].GetAttributeValue<string>("rsa_dependentoptionsetjson") : string.Empty;
                }
            }
            else { returnValue = this.GetCustomLabel(service, tracingService, key); }
            return returnValue;
        }

        #endregion Identify Renewal

        #region  Generate Renewal Process
        /// <summary>
        /// Execute renewal generation process once clicked on Renewal Generation button 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="guidRenewalGenerationId"></param>
        /// <param name="guidTriggeredById"></param>
        internal void ExecuteRenewalGeneration(IOrganizationService service, ITracingService tracingService, Guid guidRenewalGenerationId, Guid guidTriggeredById)
        {
            try
            {
                tracingService.Trace("Start processing ExecuteRenewalGeneration:..");
                //Chandani: Setting up user local time
                int? userTimezone = RetrieveCurrentUsersSettings(service);
                tracingService.Trace("ExecuteRenewalGeneration:userTimezone:" + userTimezone.ToString());
                DateTime dtExecutionStartTime= RetrieveLocalTimeFromUTCTime(DateTime.UtcNow, userTimezone, service);
                tracingService.Trace("ExecuteRenewalGeneration:dtExecutionStartTime:" + dtExecutionStartTime.ToString());
                //DateTime dtExecutionStartTime = DateTime.UtcNow;
                
                Entity enRenewalGeneration = GetRenwalGenerationDetails(service, tracingService, guidRenewalGenerationId);
                if (enRenewalGeneration == null)
                {
                    tracingService.Trace("Renewal generation obj null.");
                    return;
                }
                POLICY_DETAILS_QUERY = this.GetCustomLabel(service, tracingService, "RenewalGeneration.IdentifyAndExecute", true);
                if (string.IsNullOrEmpty(POLICY_DETAILS_QUERY))
                {
                    tracingService.Trace($"RenewalGeneration.IdentifyAndExecute value cannot be blank");
                    return;
                }
                tracingService.Trace("Calling GenerateQueryPolicyDetails method.");
                
                tracingService.Trace("Calling GenerateQueryPolicyDetails method.- flow");
                // Enable Renewal Generation Flow Chandani
                enRenewalGeneration["rsa_datetimegeneraterenewalsrun"] = dtExecutionStartTime;
                tracingService.Trace("Calling GenerateQueryPolicyDetails method.- flow - updated executiontime");
                enRenewalGeneration["rsa_runningusergeneraterenewals"] = new EntityReference("systemuser", guidTriggeredById);
                tracingService.Trace("Calling GenerateQueryPolicyDetails method.- flow - updated guidTriggeredById");
                service.Update(enRenewalGeneration);
                tracingService.Trace("Calling GenerateQueryPolicyDetails method.- flow - updated");
                
                /*
                string query = this.GenerateQueryPolicyDetails(service, tracingService, enRenewalGeneration, false);
                tracingService.Trace("FetchXML Query: " + query);
                decimal policyCount = 0;
                this.UpdatePolicyDetails(service, tracingService, query, out policyCount, enRenewalGeneration, guidTriggeredById, false, dtExecutionStartTime);
                */
            }
            catch (Exception ex)
            {
                tracingService.Trace("Error in ExecuteRenewalGeneration() method. Desc.: {0}", ex.InnerException.Message);
                throw new InvalidPluginExecutionException(string.Format("Error in ExecuteRenewalGeneration() method. Desc.: {0}", ex.InnerException.Message));
            }
        }

        /// <summary>
        /// Execute multiple for valiation and updation of policies
        /// On Updation of policy with a rsa_rgexecutiondate field , policy post create plugin will be triggered to create oppty
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="entityCollectionPolicy"></param>
        private void UpdatePolicyExecuteMultiple(IOrganizationService service, ITracingService tracingService, EntityCollection entityCollectionPolicy)
        {
            // Create an ExecuteMultipleRequest object.
            var requestWithResults = new ExecuteMultipleRequest()
            {
                // Assign settings that define execution behavior: continue on error, return responses. 
                Settings = new ExecuteMultipleSettings()
                {
                    ContinueOnError = false,
                    ReturnResponses = true
                },
                // Create an empty organization request collection.
                Requests = new OrganizationRequestCollection()
            };

            // Add a UpdateRequest for each entity to the request collection.
            foreach (var entity in entityCollectionPolicy.Entities)
            {
                UpdateRequest updateRequest = new UpdateRequest { Target = entity };
                requestWithResults.Requests.Add(updateRequest);
            }

            // Execute all the requests in the request collection using a single web method call.
            ExecuteMultipleResponse responseWithResults =
                (ExecuteMultipleResponse)service.Execute(requestWithResults);

            // Display the results returned in the responses.
            //foreach (var responseItem in responseWithResults.Responses)
            //{
            //    // A valid response.
            //    if (responseItem.Response != null)
            //        DisplayResponse(requestWithResults.Requests[responseItem.RequestIndex], responseItem.Response);

            //    // An error has occurred.
            //    else if (responseItem.Fault != null)
            //        DisplayFault(requestWithResults.Requests[responseItem.RequestIndex],
            //            responseItem.RequestIndex, responseItem.Fault);
            //}
        }

        /// <summary>
        /// Validation of policies
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="ecTargetedPolicies"></param>
        /// <param name="enRenewalGeneration"></param>
        /// <returns></returns>
        private EntityCollection ValidatePolicy(IOrganizationService service, ITracingService tracingService, EntityCollection ecTargetedPolicies, Entity enRenewalGeneration)
        {
            tracingService.Trace("Eneterd RSA.CSI.Plugins.RenewalGenerationLogic.RenewalGenerationCommon.CreateOpportunity() method.");
            bool bRuleBrokerAvailable;       //Rule to check if broker is available
            bool bRuleCustomerAvailable;     //Rule to check if Customer is available
            bool bRuleUnderwriterActive;     //Rule to check if Underwriter is active
            bool bRuleTraderActive;          //Rule to check if Trader is active
            bool bRuleMandatoryFieldCheck;   //Rule to check if data for mandatory fields is available
            bool isValidationPass = true;       //Rule to check if BDM of Broker is active
            int policyStatusCode = -1;
            string policyFailReason = string.Empty;
            Guid guidOpportunityId = Guid.Empty;
            var entityCollectionUpdatePolicy = new EntityCollection();
            Entity entityUpdatePolicy; ;
            var strFailedReason = string.Empty;
            foreach (Entity enPolicy in ecTargetedPolicies.Entities)
            {
                try
                {
                    isValidationPass = true;
                    policyStatusCode = POLICY_SUCCESS_STATUS;
                    policyFailReason = string.Empty;
                    bRuleBrokerAvailable = enPolicy.Attributes.Contains("rsa_broker");
                    bRuleCustomerAvailable = enPolicy.Attributes.Contains("rsa_customer");
                    bRuleUnderwriterActive = enPolicy.Attributes.Contains("hnd.isdisabled") ? (bool)((AliasedValue)enPolicy.Attributes["hnd.isdisabled"]).Value : true;
                    bRuleTraderActive = enPolicy.Attributes.Contains("trd.isdisabled") ? (bool)((AliasedValue)enPolicy.Attributes["trd.isdisabled"]).Value : true;
                    bRuleMandatoryFieldCheck = enPolicy.Attributes.Contains("rsa_policyrenewaldate") &&
                                                enPolicy.Attributes.Contains("rsa_classofbusiness") &&
                                                enPolicy.Attributes.Contains("rsa_plcode");
                    if (bRuleBrokerAvailable)
                    {
                        if (bRuleCustomerAvailable)
                        {
                            if (!bRuleMandatoryFieldCheck)
                            {
                                isValidationPass = false;
                                policyStatusCode = POLICY_FAIL_STATUS;
                                policyFailReason = POLICY_FAIL_REASON_MAND_FLDS_UNAVLBLE;
                            }
                            // Defect - 2098
                            //if (!bRuleUnderwriterActive)
                            //{
                            //    if (!bRuleTraderActive)
                            //    {
                            //        if (!bRuleMandatoryFieldCheck)
                            //        {
                            //            isValidationPass = false;
                            //            policyStatusCode = POLICY_FAIL_STATUS;
                            //            policyFailReason = POLICY_FAIL_REASON_MAND_FLDS_UNAVLBLE;
                            //        }
                            //    }
                            //    else
                            //    {
                            //        isValidationPass = false;
                            //        policyStatusCode = POLICY_FAIL_STATUS;
                            //        policyFailReason = POLICY_FAIL_REASON_TRADER_INACTIVE;
                            //    }
                            //}
                            //else
                            //{
                            //    isValidationPass = false;
                            //    policyStatusCode = POLICY_FAIL_STATUS;
                            //    policyFailReason = POLICY_FAIL_REASON_HANDLER_INACTIVE;
                            //}
                        }
                        else
                        {
                            isValidationPass = false;
                            policyStatusCode = POLICY_FAIL_STATUS;
                            policyFailReason = POLICY_FAIL_REASON_CUST_UNAVAILABLE;
                        }
                    }
                    else
                    {
                        isValidationPass = false;
                        policyStatusCode = POLICY_FAIL_STATUS;
                        policyFailReason = POLICY_FAIL_REASON_BROKER_UNAVAILABLE;
                    }
                }
                catch (Exception ex)
                {
                    isValidationPass = false;
                    policyStatusCode = POLICY_FAIL_STATUS;
                    policyFailReason = POLICY_FAIL_SYS_EXCEPTION;
                }
                finally
                {
                    entityUpdatePolicy = new Entity("rsa_policy");
                    entityUpdatePolicy.Id = enPolicy.Id;
                    entityUpdatePolicy["rsa_renewalgenerationid"] = new EntityReference("rsa_policy", enRenewalGeneration.Id);
                    if (!isValidationPass)
                    {
                        entityUpdatePolicy["rsa_renewalgenerationstatuscode"] = new OptionSetValue(860002); // failed
                        entityUpdatePolicy["rsa_renewalgenerationfailreason"] = policyFailReason;
                    }
                    else
                    {

                        entityUpdatePolicy["rsa_rgexecutiondate"] = DateTime.Now;
                        entityUpdatePolicy["rsa_renewalgenerationstatuscode"] = new OptionSetValue(860001); // success
                    }

                    entityCollectionUpdatePolicy.Entities.Add(entityUpdatePolicy);
                    tracingService.Trace("Adding Policy in col count:" + entityCollectionUpdatePolicy.Entities.Count());
                }
            }
            return entityCollectionUpdatePolicy;
        }

        /// <summary>
        /// Validate Policy Line of business 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="entityPolicy"></param>
        /// <param name="entityRenewalGeneration"></param>
        /// <param name="strFailedReason"></param>
        /// <returns></returns>
        private bool ValidateLineOfBusiness(IOrganizationService service, ITracingService tracingService, Entity entityPolicy, Entity entityRenewalGeneration, out string strFailedReason)
        {
            var lineOfBusinessId = Guid.Empty;
            bool bIsValidationPass = true;
            strFailedReason = string.Empty;

            if (this.IsExistsOpportunityByLineOfBusiness(service, tracingService, entityPolicy.Id, LINE_OF_BUSINESS_NEW_BUSINESS_MARINE_LONDON) ||
                                                ((EntityReference)entityPolicy["rsa_plcode"]).Name.Equals(LINE_OF_BUSINESS_LONDON_MARIENE)) //'London Marine'
            {
                lineOfBusinessId = this.GetLineOfBusinessById(service, LINE_OF_BUSINESS_GSL_RENEWAL_MARINE_LONDON);
                if (lineOfBusinessId == Guid.Empty)
                {
                    bIsValidationPass = false;
                    strFailedReason = POLICY_FAIL_REASON_LOB_MARINE_LONDON_MISSING;
                }
            }
            else if (this.IsExistsOpportunityByLineOfBusiness(service, tracingService, entityPolicy.Id, LINE_OF_BUSINESS_NEW_BUSINESS_MARINE_REGIONAL) ||
               ((EntityReference)entityPolicy["rsa_plcode"]).Name.Equals(LINE_OF_BUSINESS_REGIONAL_MARIENE)) //'Regional Marine'
                                                                                                             //else if ((enPolicy.GetAttributeValue<OptionSetValue>("rsa_plcode")).Value == 860007) //'Regional Marine'
            {
                lineOfBusinessId = this.GetLineOfBusinessById(service, LINE_OF_BUSINESS_GSL_RENEWAL_REGIONAL_MARIENE);
                if (lineOfBusinessId == Guid.Empty)
                {
                    bIsValidationPass = false;
                    strFailedReason = POLICY_FAIL_REASON_LOB_MARINE_REGIONAL_MISSING;
                }
            }
            else
            {
                // GSL - Renewal
                lineOfBusinessId = this.GetLineOfBusinessById(service, LINE_OF_BUSINESS_GSL_RENEWAL);
                if (lineOfBusinessId == Guid.Empty)
                {
                    bIsValidationPass = false;
                    strFailedReason = POLICY_FAIL_REASON_LOB_GSL_RENEWAL_MISSING;
                }
            }

            return bIsValidationPass;
        }



        /// <summary>
        /// Get trading thresold details
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="guidCOB"></param>
        /// <param name="intOffice"></param>
        /// <returns></returns>
        private Entity GetTradingThresoldDetails(IOrganizationService service, ITracingService tracingService, Guid guidCOB, int intOffice)
        {
            var entityTradingThresold = new Entity();
            try
            {
                var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' >
                                <entity name='rsa_tradingthreshold' >
                                    <attribute name='rsa_name' />
                                    <attribute name='createdon' />
                                    <attribute name='rsa_pl' />
                                    <attribute name='rsa_office' />
                                    <attribute name='rsa_thresholdvalue' />
                                    <attribute name='rsa_renewaltradingthreshold' />
                                    <attribute name='rsa_renewalpromisethreshold' />
                                    <attribute name='rsa_classofbusiness' />
                                    <attribute name='rsa_tradingthresholdid' />
                                    <attribute name='rsa_vettingthreshold' />
                                    <order attribute='rsa_name' descending='false' />
                                    <filter type='and' >
                                        <condition attribute='rsa_office' operator='eq' value='{0}' />
                                        <condition attribute='rsa_classofbusiness' operator='eq' value='{1}' />
                                    </filter>
                                </entity>
                            </fetch>";

                var colTradingThresold = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, guidCOB, intOffice)));
                if (colTradingThresold != null && colTradingThresold.Entities.Count > 0)
                {
                    entityTradingThresold = colTradingThresold.Entities[0];
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetch Trading Thresold: " + ex.Message);
            }
            return entityTradingThresold;
        }

        /// <summary>
        /// Get Case status id
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <returns></returns>
        private Guid GetCaseStatusForRenewal(IOrganizationService service, ITracingService tracingService, string strCaseRenewalStatus)
        {
            var returnValue = Guid.Empty;
            try
            {
                var guidCaseTypeId = this.GetCaseTypeForRenewalById(service, tracingService, NEW_RENEWAL_CASE_TYPE);
                var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='rsa_status'>
                                <attribute name='rsa_name' />
                                <attribute name='createdon' />
                                <attribute name='rsa_casetype' />
                                <attribute name='rsa_statusid' />
                                <order attribute='rsa_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='rsa_name' operator='eq' value='{0}' />
                                  <condition attribute='rsa_casetype' operator='eq' value='{1}' />
                                </filter>
                              </entity>
                            </fetch>";
                var entityColCaseSatus = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, strCaseRenewalStatus, guidCaseTypeId)));
                if (entityColCaseSatus != null && entityColCaseSatus.Entities.Count > 0)
                {
                    returnValue = entityColCaseSatus.Entities[0].Id;
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetching case status: " + ex.Message);
            }
            return returnValue;
        }

        /// <summary>
        /// Deactivate record
        /// </summary>
        /// <param name="entityName"></param>
        /// <param name="recordId"></param>
        /// <param name="organizationService"></param>
        private void DeactivateRecord(IOrganizationService service, ITracingService tracingService, string entityName, Guid recordId)
        {
            try
            {
                /*SetStateRequest setStateRequest = new SetStateRequest()
                {
                    EntityMoniker = new EntityReference
                    {
                        Id = recordId,
                        LogicalName = entityName,
                    },
                    State = new OptionSetValue(1),
                    Status = new OptionSetValue(2)
                };
                service.Execute(setStateRequest);*/
                //Remediation - 14/07/2022
                Entity entity = new Entity(entityName, recordId);
                entity["statecode"] = new OptionSetValue(1);
                entity["statuscode"] = new OptionSetValue(2);
                service.Update(entity);
                tracingService.Trace("Deactivate Record.");
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception during RG deactivation.");
            }
        }

        /// <summary>
        /// Get Case type Id based on case type as string
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="strCaseType"></param>
        /// <returns></returns>
        private Guid GetCaseTypeForRenewalById(IOrganizationService service, ITracingService tracingService, string strCaseType)
        {
            var returnValue = Guid.Empty;
            try
            {
                var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='rsa_casetype'>
                                <attribute name='rsa_casetypeid' />
                                <attribute name='rsa_casetype' />
                                <attribute name='createdon' />
                                <order attribute='rsa_casetype' descending='false' />
                                <filter type='and'>
                                  <condition attribute='rsa_casetype' operator='eq' value='{0}' />
                                </filter>
                              </entity>
                            </fetch>";
                var entityColCaseType = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, strCaseType)));
                if (entityColCaseType != null && entityColCaseType.Entities.Count > 0)
                {
                    returnValue = entityColCaseType.Entities[0].Id;
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetching case type id: " + ex.Message);
            }
            return returnValue;
        }

        /// <summary>
        /// check whether opportiniy with specific LOB exists or not
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="guidPolicyId"></param>
        /// <param name="strLOB"></param>
        /// <returns></returns>
        private bool IsExistsOpportunityByLineOfBusiness(IOrganizationService service, ITracingService tracingService, Guid guidPolicyId, string strLOB)
        {
            //New Business - Marine London
            //New Business - Marine Regional"
            var returnValue = false;
            try
            {
                if (strLOB != string.Empty)
                {
                    Guid guidLOBId = this.GetLineOfBusinessById(service, strLOB);
                    if (guidLOBId != Guid.Empty)
                    {
                        var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                      <entity name='opportunity'>
                        <attribute name='name' />
                        <attribute name='customerid' />
                        <attribute name='estimatedvalue' />
                        <attribute name='statuscode' />
                        <attribute name='opportunityid' />
                        <order attribute='name' descending='false' />
                        <filter type='and'>
                          <condition attribute='rsa_policyid' operator='eq' value='{0}' />
                          <condition attribute='rsa_lineofbusiness' operator='eq' value='{1}' />
                        </filter>
                      </entity>
                    </fetch>";
                        var entityColOpportunity = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, guidPolicyId, guidLOBId)));
                        if (entityColOpportunity != null && entityColOpportunity.Entities.Count > 0)
                            returnValue = true;
                    }
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetching LOB(IsExistsOpportunityByLineOfBusiness): " + ex.Message);
            }
            return returnValue;
        }

        /// <summary>
        /// Get Line Of business , P&L and Class Of business code for a Class of busniess record
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="guidCOBId"></param>
        /// <param name="guidPandLId"></param>
        /// <param name="guidLOBId"></param>
        /// <param name="intCOBCode"></param>
        /// <returns></returns>
        private bool GetClassOfBusinessDetails(IOrganizationService service, ITracingService tracingService,
            Guid guidCOBId, out Guid guidPandLId, out Guid guidLOBId, out int intCOBCode)
        {
            bool returnValue = false;
            guidPandLId = Guid.Empty;
            guidLOBId = Guid.Empty;
            intCOBCode = -1;
            try
            {
                var entityColCOB = service.Retrieve("rsa_classofbusniess", guidCOBId, new ColumnSet("rsa_lineofbusiness", "rsa_pl", "rsa_classofbusinesscode"));
                if (entityColCOB != null && entityColCOB.Attributes.Contains("rsa_lineofbusiness") &&
                    entityColCOB.Attributes.Contains("rsa_pl") &&
                    entityColCOB.Attributes.Contains("rsa_classofbusinesscode"))
                {
                    guidLOBId = ((EntityReference)entityColCOB["rsa_lineofbusiness"]).Id;
                    guidPandLId = ((EntityReference)entityColCOB["rsa_pl"]).Id;
                    intCOBCode = (int)entityColCOB["rsa_lineofbusiness"];
                    returnValue = true;
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetching line of business: " + ex.Message);
            }
            return returnValue;
        }

        /// <summary>
        /// Get Line of business id 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="lineOfBusiness"></param>
        /// <returns></returns>
        private Guid GetLineOfBusinessById(IOrganizationService service, string lineOfBusiness)
        {
            Guid lobId = Guid.Empty;
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='rsa_lineofbusiness'>
                                <attribute name='rsa_lineofbusinessid' />
                                <filter type='and'>
                                  <condition attribute='rsa_name' operator='eq' value='GSL - Renewal' />
                                </filter>
                              </entity>
                            </fetch>";
            var lineOfBusinessEntity = service.RetrieveMultiple(new FetchExpression(fetchXml));
            if (lineOfBusinessEntity != null && lineOfBusinessEntity.Entities.Count > 0)
                lobId = lineOfBusinessEntity.Entities[0].Id;
            return lobId;
        }


        /// <summary>
        /// Update renewal generation entity after
        /// 1. Identify Renewal Generation
        /// 2. Renewal Generation process completion
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="renewalGeneration"></param>
        /// <param name="isCompleted"></param>
        /// <param name="isIdentityRenewal"></param>
        private void UpdateRenewalGeneration(IOrganizationService service, ITracingService tracingService, RenewalGeneration renewalGeneration, bool isCompleted, bool isIdentityRenewal)
        {
            Entity enRenewalGeneration = new Entity(renewalGeneration.EntityName);
            enRenewalGeneration.Id = renewalGeneration.EntityId;
            if (!isIdentityRenewal)
            {
                enRenewalGeneration["rsa_generaterenewalsstatus"] = new OptionSetValue(renewalGeneration.Status);
                enRenewalGeneration["rsa_runningusergeneraterenewals"] = new EntityReference("systemuser", renewalGeneration.TriggeredById);
                if (!isCompleted)
                {
                    enRenewalGeneration["rsa_datetimegeneraterenewalsrun"] = DateTime.Now;
                }
                else
                {
                    enRenewalGeneration["rsa_datetimegeneraterenewalsrun"] = renewalGeneration.StartDateTime;
                    enRenewalGeneration["rsa_numberofsuccesses"] = renewalGeneration.SuccessCount;
                    enRenewalGeneration["rsa_numberoffailures"] = renewalGeneration.FailedCount;
                    enRenewalGeneration["rsa_datetimegeneraterenewalscompleted"] = DateTime.Now;
                }
            }
            else
            {
                //Chandani: Setting up user local time
                int? userTimezone = RetrieveCurrentUsersSettings(service);               
                DateTime dtIdentifyRenewal = RetrieveLocalTimeFromUTCTime(DateTime.UtcNow, userTimezone, service);                
                enRenewalGeneration["rsa_runninguseridentifyrenewalsid"] = new EntityReference("systemuser", renewalGeneration.TriggeredById);
                //enRenewalGeneration["rsa_datetimeidentifyrenewalsrun"] = DateTime.Now;
                enRenewalGeneration["rsa_datetimeidentifyrenewalsrun"] = dtIdentifyRenewal;
                enRenewalGeneration["rsa_totalpoliciesidentifiedforrenewal"] = renewalGeneration.IdentifiedPolicyCount;
            }
            service.Update(enRenewalGeneration);
        }
        #endregion  Generate Renewal Process

    }

    #region Payload class
    internal class RenewalGeneration
    {
        string entityName;
        Guid entityId;
        DateTime startDateTime;
        DateTime endDateTime;
        int status;
        Guid triggeredById;
        decimal failedCount = 0;
        decimal successCount = 0;
        decimal identifiedPolicyCount = 0;

        public DateTime StartDateTime { get => startDateTime; set => startDateTime = value; }
        public DateTime EndDateTime { get => endDateTime; set => endDateTime = value; }
        public int Status { get => status; set => status = value; }
        public Guid TriggeredById { get => triggeredById; set => triggeredById = value; }
        public Guid EntityId { get => entityId; set => entityId = value; }
        public string EntityName { get => entityName; set => entityName = value; }
        public decimal FailedCount { get => failedCount; set => failedCount = value; }
        public decimal SuccessCount { get => successCount; set => successCount = value; }
        public decimal IdentifiedPolicyCount { get => identifiedPolicyCount; set => identifiedPolicyCount = value; }

    }


    #endregion Payload class
}