﻿using Microsoft.Xrm.Sdk;
using RSA.CSI.Plugins.Common;
using System;
using Microsoft.Xrm.Sdk.Query;
using System.Runtime.Serialization;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Runtime.Serialization.Json;
using RSA.CSI.Plugins.Utility;

namespace RSA.CSI.Plugins.RenewalGenerations.Logic
{
    internal class RGPolicyUpdateLogic
    {
        #region Constant Variables
        private const string POLICY_FAIL_REASON_MAND_FLDS_UNAVLBLE = "Data in Mandatory fields not available";
        private const string POLICY_FAIL_REASON_TRADER_INACTIVE = "Policy Trader is Inactive in D365";
        private const string POLICY_FAIL_REASON_CUST_UNAVAILABLE = "Customer not available for the policy";
        private const string POLICY_FAIL_REASON_BROKER_UNAVAILABLE = "Broker not available for the policy";
        private const string POLICY_FAIL_SYS_EXCEPTION = "System Exception";
        private const int POLICY_FAIL_STATUS = 860002;
        private const int POLICY_SUCCESS_STATUS = 860001;
        private const int POLICY_PENDING_STATUS = 860000;
        private const string NEW_RENEWAL_CASE_TYPE = "Renewal"; // should be from optionset but Entity created
        private const string NEW_RENEWAL_CASE_STATUS = "Initial Processing"; // should be from optionset but Entity created
        private const int NEW_RENEWAL_CASE_RECORDTYPE = 866760020;
        /// <summary>
        /// BPO Renewals
        /// </summary>
        private const string NEW_RENEWAL_CASE_QUEUE = "99172d9f-2ac7-ea11-a812-000d3af01f8c";
        /// <summary>
        /// Renewal - Automated
        /// </summary>
        private const int NEW_RENEWAL_CASE_ORIGIN = 866760002;
        private const string LINE_OF_BUSINESS_GSL_RENEWAL = "GSL - Renewal"; //Renewals - Marine London
        private const string LINE_OF_BUSINESS_GSL_RENEWAL_MARINE_LONDON = "Renewal - Marine London"; //Renewals - Marine London
        private const string LINE_OF_BUSINESS_GSL_RENEWAL_REGIONAL_MARIENE = "Renewal - Marine Regional"; //Renewals - Marine London
        private const string LINE_OF_BUSINESS_LONDON_MARIENE = "London Marine"; // Marine London
        private const string LINE_OF_BUSINESS_REGIONAL_MARIENE = "Regional Marine"; //Regional Marine
        private const string POLICY_FAIL_REASON_LOB_GSL_RENEWAL_MISSING = "MISSING 'GSL Renewal' line of business";
        private const string POLICY_FAIL_REASON_LOB_MARINE_LONDON_MISSING = "MISSING 'Renewal - Marine London' line of business";
        private const string POLICY_FAIL_REASON_LOB_MARINE_REGIONAL_MISSING = "MISSING 'Renewal - Marine Regional' line of business";
        private const string POLICY_FAIL_REASON_HANDLER_INACTIVE = "Policy Handler is Inactive in D365";
        //objNewCase.Status = mapRnwlGenConstants.get('NEW_RENEWAL_CASE_STATUS').Constant_Value__c;
        //objNewCase.OwnerId = mapRnwlGenConstants.get('NEW_RENEWAL_CASE_QUEUE').Constant_Value__c;
        //objNewCase.Origin = mapRnwlGenConstants.get('NEW_RENEWAL_CASE_ORIGIN').Constant_Value__c; 
        private const string LINE_OF_BUSINESS_NEW_BUSINESS_MARINE_LONDON = "New Business - Marine London";
        private const string LINE_OF_BUSINESS_NEW_BUSINESS_MARINE_REGIONAL = "New Business - Marine Regional";
        //New Business - Marine London
        //New Business - Marine Regional"
        #endregion Constant Variables
        /// <summary>
        /// Execute opportunity create on Policy update
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="entityPolicy"></param>
        internal void Execute(IOrganizationService service, ITracingService tracingService, Entity entityPolicy)
        {
            tracingService.Trace("Population of opportunity entity");
            var entityOpportunity = this.PopulateOpportunity(service, tracingService, entityPolicy);
            tracingService.Trace("Opportunity successfully populated");
            if (entityOpportunity != null)
            {
                tracingService.Trace("Creating opportunity");
                this.CreateOpportunity(service, tracingService, entityOpportunity);
                tracingService.Trace("Successfully opportunity created");
            }
        }

        /// <summary>
        /// Create opportunity on Policy Update on rsa_rgexecutiondate
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="enOpportunity"></param>
        private void CreateOpportunity(IOrganizationService service, ITracingService tracingService, Entity enOpportunity)
        {
            try
            {
                tracingService.Trace("Creating opportunity ...");
                //Creating opportunity
                var guidOpportunityId = service.Create(enOpportunity);
                tracingService.Trace("Opportunity created successfully with Id..." + guidOpportunityId);
            }
            catch (Exception ex)
            {
                tracingService.Trace("Failed to create opportunity ...");
                tracingService.Trace($"Error details:{Environment.NewLine}{ex.Message}");
            }
        }

        /// <summary>
        /// Polulate opportunity
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="enPolicy"></param>
        /// <returns></returns>
        private Entity PopulateOpportunity(IOrganizationService service, ITracingService tracingService, Entity enPolicy)
        {
            var opportunityFailReason = string.Empty;
            bool isValidationPass = true;
            string strEmptyString = string.Empty;
            Guid guidEmpty = Guid.Empty;
            string strOpportunityName = string.Empty;
            string strOpportunityDescription = string.Empty;
            string strPolicyCustomerName = string.Empty;
            string strPolicyCOBName = string.Empty;
            string strPolicyRenewalYear = string.Empty;
            string strCLassOfBusiness = string.Empty;
            string strReviewType = string.Empty;
            string strCustomerName = string.Empty;

            var enOpportunity = new Entity("opportunity");
            var ms = Stream.Null;
            try
            {
                tracingService.Trace("Population of opportunity started");
                enOpportunity["rsa_policyid"] = new EntityReference("rsa_policy", enPolicy.Id);
                EntityReference lob = new EntityReference();
                var lineOfBusinessId = Guid.Empty;
                //Fetch Opportunity based COB LOB and Pl&L to autopopulate : Defect id 2326
                EntityReference en_RG = enPolicy.Attributes.Contains("rsa_renewalgenerationid") ? enPolicy.GetAttributeValue<EntityReference>("rsa_renewalgenerationid") : null;
                tracingService.Trace("Fetch Opportunity based COB LOB and Pl&L to autopopulate for isle of Man");
                if (enPolicy.Attributes.Contains("rsa_operationshandlingsite") && enPolicy.Attributes.Contains("rsa_tradinghandlingsite"))
                {
                    if (Convert.ToString(enPolicy.FormattedValues["rsa_operationshandlingsite"]).Equals("Isle of Man") ||
                    Convert.ToString(enPolicy.FormattedValues["rsa_tradinghandlingsite"]).Equals("Isle of Man"))
                    {
                        string plName = enPolicy.Attributes.Contains("rsa_plcode") ? ((EntityReference)enPolicy["rsa_plcode"]).Name : string.Empty;
                        tracingService.Trace("PL" + plName);
                        string COBName = enPolicy.Attributes.Contains("rsa_plcode") ? ((EntityReference)enPolicy["rsa_classofbusiness"]).Name : string.Empty;
                        tracingService.Trace("COBName" + COBName);
                        string fetchQuery = "<fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>";
                        fetchQuery += "<entity name='rsa_classofbusiness'>";
                        fetchQuery += "<attribute name='rsa_classofbusinessid'/>";
                        fetchQuery += "<attribute name='rsa_name' />";
                        fetchQuery += "<attribute name='createdon' />";
                        fetchQuery += "<attribute name='rsa_pl' />";
                        fetchQuery += "<attribute name='rsa_lineofbusiness' />";
                        fetchQuery += "<order descending='false' attribute='rsa_name' />";
                        fetchQuery += "<filter type='and'>";
                        fetchQuery += "<condition attribute='rsa_lineofbusinessname' operator='like' value='Renewal - Isle of Man'/>";
                        fetchQuery += "<condition attribute='rsa_plname' operator='like' value='" + plName.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;") + "%' />";
                        fetchQuery += "<condition attribute='rsa_name' operator='like' value='" + COBName.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;") + "%' />";
                        fetchQuery += "</filter>";
                        fetchQuery += "</entity>";
                        fetchQuery += "</fetch>";

                        EntityCollection pandLColl = service.RetrieveMultiple(new FetchExpression(fetchQuery));
                        tracingService.Trace("COBName COunt" + pandLColl.Entities.Count);
                        if (pandLColl.Entities.Count > 0)
                        {
                            foreach (var item in pandLColl.Entities)
                            {
                                enOpportunity["rsa_pandlid"] = item["rsa_pl"];

                                enOpportunity["rsa_classofbusiness"] = new EntityReference("rsa_classofbusiness", item.Id);
                            }
                        }
                        else
                        {
                            enOpportunity["rsa_pandlid"] = enPolicy["rsa_plcode"];

                            enOpportunity["rsa_classofbusiness"] = enPolicy["rsa_classofbusiness"];
                        }
                    }
                    else
                    {

                        enOpportunity["rsa_pandlid"] = enPolicy["rsa_plcode"];

                        enOpportunity["rsa_classofbusiness"] = enPolicy["rsa_classofbusiness"];
                    }
                }
                else
                {

                    enOpportunity["rsa_pandlid"] = enPolicy["rsa_plcode"];

                    enOpportunity["rsa_classofbusiness"] = enPolicy["rsa_classofbusiness"];
                }

                enOpportunity["rsa_closedate"] = enPolicy["rsa_policyrenewaldate"];
                // Source is Renewal Generation
                enOpportunity["rsa_dataorigin"] = new OptionSetValue(866760003);
                //bug 2349 Renewal generation ID populate.
                if (en_RG != null)
                {
                    enOpportunity["rsa_renewalgenerationid"] = new EntityReference(en_RG.LogicalName, en_RG.Id);
                    tracingService.Trace(" renewalgeneration is updated on Opportunity ");
                }
                //Bug 2420// can comment below as covered in precreate
                //if (enPolicy != null)
                //{
                //    string fetchAllOpportunity = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' count='1'>";
                //    fetchAllOpportunity += "<entity name='opportunity'>";
                //    fetchAllOpportunity += "<attribute name='name' />";
                //    fetchAllOpportunity += "<attribute name='opportunityid' />";
                //    fetchAllOpportunity += "<attribute name='rsa_lineofbusiness' />";
                //    fetchAllOpportunity += "<attribute name='rsa_opportunitystage' />";
                //    fetchAllOpportunity += "<attribute name='createdon' />";
                //    fetchAllOpportunity += "<attribute name='rsa_policyid' />";
                //    fetchAllOpportunity += "<attribute name='rsa_expiringpremium' />";
                //    fetchAllOpportunity += "<attribute name='rsa_rsaquotedpremium' />";
                //    fetchAllOpportunity += "<order attribute='createdon' descending='true' />";
                //    fetchAllOpportunity += "<filter type='and'>";
                //    fetchAllOpportunity += "<condition attribute='rsa_policyid' operator='eq' value='" + enPolicy.Id + "' />";
                //    fetchAllOpportunity += "</filter>";
                //    fetchAllOpportunity += "</entity>";
                //    fetchAllOpportunity += "</fetch>";

                //    EntityCollection opportunityColl = service.RetrieveMultiple(new FetchExpression(fetchAllOpportunity));
                //    tracingService.Trace("Opportunity Count" + opportunityColl.Entities.Count);
                //    if (opportunityColl != null && opportunityColl.Entities.Count == 0)
                //    {
                //        tracingService.Trace("Opportunity Count is 0");
                //        if (enPolicy.Attributes.Contains("rsa_premium"))
                //            enOpportunity["rsa_expiringpremium"] = enPolicy["rsa_premium"];
                //    }
                //    else if (opportunityColl != null && opportunityColl.Entities.Count > 0)
                //    {
                //        tracingService.Trace("Opportunity Count is greater than 0");
                //        foreach (var item in opportunityColl.Entities)
                //        {
                //            enOpportunity["rsa_expiringpremium"] = item.Attributes.Contains("rsa_rsaquotedpremium") ? item.GetAttributeValue<Money>("rsa_rsaquotedpremium") : new Money(0.00M);
                //        }
                //    }
                //}

                strPolicyCOBName = ((EntityReference)enPolicy["rsa_classofbusiness"]).Name; // TODO
                if (enPolicy.Attributes.Contains("rsa_productid") && ((EntityReference)enPolicy["rsa_productid"]).Id != guidEmpty)
                {
                    enOpportunity["rsa_productid"] = enPolicy["rsa_productid"];
                }
                if (enPolicy.Attributes.Contains("rsa_broker") && ((EntityReference)enPolicy["rsa_broker"]).Id != guidEmpty)
                {
                    enOpportunity["parentaccountid"] = enPolicy["rsa_broker"];
                }
                enOpportunity["rsa_stage"] = new OptionSetValue(866760017); // Renewal Work Up (NEW_RENEWAL_OPP_STAGE)

                if (enPolicy.Attributes.Contains("rsa_customer") && ((EntityReference)enPolicy["rsa_customer"]).Name != strEmptyString)
                {
                    enOpportunity["rsa_customer"] = new EntityReference("rsa_customer", ((EntityReference)enPolicy["rsa_customer"]).Id);
                    strPolicyCustomerName = ((EntityReference)enPolicy["rsa_customer"]).Name;
                }
                if (enPolicy.Attributes.Contains("rsa_classofbusiness") && ((EntityReference)enPolicy["rsa_classofbusiness"]).Name != strEmptyString)
                {
                    strPolicyCOBName = ((EntityReference)enPolicy["rsa_classofbusiness"]).Name;
                }
                if (enPolicy.Attributes.Contains("rsa_policyrenewaldate") && ((DateTime)enPolicy["rsa_policyrenewaldate"]).ToString() != strEmptyString)
                {
                    strPolicyRenewalYear = ((DateTime)enPolicy["rsa_policyrenewaldate"]).Year.ToString();
                }
                strOpportunityName = (strPolicyCustomerName != strEmptyString ? strPolicyCustomerName : strEmptyString) + '-' +
                              (strPolicyCOBName != strEmptyString ? strPolicyCOBName : strEmptyString) + '-' +
                              (strPolicyRenewalYear != strEmptyString ? strPolicyRenewalYear : "0");
                enOpportunity["name"] = strOpportunityName;
                if (enPolicy.Attributes.Contains("rsa_expiringpolicynumber"))
                {
                    enOpportunity["rsa_expiringpolicynumber"] = enPolicy["rsa_expiringpolicynumber"];
                }
                if (enPolicy.Attributes.Contains("rsa_expiringpolicysystem"))
                {
                    enOpportunity["rsa_expiringpolicysystem"] = enPolicy["rsa_expiringpolicysystem"];
                }

                if (enPolicy.Attributes.Contains("rsa_reviewtypecode") && ((OptionSetValue)enPolicy["rsa_reviewtypecode"]).Value.ToString() != strEmptyString)
                {
                    int reviewType = enPolicy.GetAttributeValue<OptionSetValue>("rsa_reviewtypecode").Value;
                    tracingService.Trace("Review Type :" + reviewType);

                    Dictionary<int, int> reviewTypeNumber = new Dictionary<int, int>();
                    reviewTypeNumber.Add(866760001, 866760000); // Full Review
                    reviewTypeNumber.Add(866760002, 866760001); // Light Touch
                    reviewTypeNumber.Add(866760005, 866760002); // Standard
                    reviewTypeNumber.Add(866760003, 866760003); // None
                    reviewTypeNumber.Add(866760004, 866760004); // RDF
                    reviewTypeNumber.Add(866760000, 866760005); // Fast Track
                    reviewTypeNumber.Add(866760006, 866760006); // Interim Review

                    foreach (var item in reviewTypeNumber)
                    {
                        if (item.Key.Equals(reviewType))
                        {
                            enOpportunity["rsa_reviewtype"] = new OptionSetValue(item.Value);
                            tracingService.Trace("Review Type:" + item.Value);
                        }
                    }

                    //enOpportunity["rsa_reviewtype"] = enPolicy["rsa_reviewtypecode"];
                    //strReviewType = enPolicy.FormattedValues["rsa_reviewtypecode"].ToString();
                    //tracingService.Trace("Review Type:" + strReviewType);
                }


                //// Defect 2093, 2098: Atul Agrawal
                tracingService.Trace("Setting Opportunity Stage lookup");
                var oppStageId = this.GetOpportunityStageId(service, tracingService, "Renewal Work Up");
                if (oppStageId != Guid.Empty)
                    enOpportunity["rsa_opportunitystage"] = new EntityReference("rsa_opportunitystage", oppStageId);

                if (((EntityReference)enPolicy["rsa_plcode"]).Name.ToLower().Contains("marine") &&
                    (((EntityReference)enPolicy["rsa_plcode"]).Name.ToLower().Contains("london") || ((EntityReference)enPolicy["rsa_plcode"]).Name.ToLower().Contains("regional")))
                {
                    if (enPolicy.Attributes.Contains("rsa_epicurrency") && enPolicy["rsa_epicurrency"].ToString() != strEmptyString)
                    {
                        string policyEpiCurrency = enPolicy.GetAttributeValue<string>("rsa_epicurrency");
                        string Fetch = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='transactioncurrency'>
                                            <attribute name='transactioncurrencyid' />
                                            <attribute name='currencyname' />
                                            <attribute name='isocurrencycode' />
                                            <attribute name='currencysymbol' />
                                            <attribute name='exchangerate' />
                                            <attribute name='currencyprecision' />
                                            <order attribute='currencyname' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='isocurrencycode' operator='eq'  value='" + policyEpiCurrency + @"' />
                                            </filter>
                                          </entity>
                                        </fetch>";
                        EntityCollection currencyCollection = service.RetrieveMultiple(new FetchExpression(Fetch));
                        tracingService.Trace("currencyCollection reteieved:");
                        if (currencyCollection.Entities.Count != 0)
                        {
                            enOpportunity["rsa_currency"] = new EntityReference((currencyCollection.Entities[0]).LogicalName, (currencyCollection.Entities[0]).Id);
                            tracingService.Trace("Policy EPI Currency is retrieved for Marine london and Region!");
                            UpdateExchangeRateOnOppty(service, tracingService, enOpportunity, currencyCollection.Entities[0].GetAttributeValue<string>("currencyname"), currencyCollection.Entities[0].Id);

                            //EntityReference exLimitCurrencyELC = null;

                            //if (enOpportunity.Attributes.Contains("rsa_excesslimitcurrencyelcid") && enOpportunity.GetAttributeValue<EntityReference>("rsa_excesslimitcurrencyelcid") != null)
                            //{
                            //    exLimitCurrencyELC = enOpportunity.Attributes.Contains("rsa_excesslimitcurrencyelcid") ? enOpportunity.GetAttributeValue<EntityReference>("rsa_excesslimitcurrencyelcid") : null;
                            //}
                            //string currencyNameELC = string.Empty;
                            //if (exLimitCurrencyELC != null)
                            //{
                            //    var currencyListELC = service.Retrieve(exLimitCurrencyELC.LogicalName, exLimitCurrencyELC.Id, new ColumnSet("currencyname"));
                            //    currencyNameELC = currencyListELC["currencyname"].ToString();
                            //}
                            //if (exLimitCurrencyELC == null)
                            //{
                            //    UpdateExchangeRateOnOppty(service, tracingService, enOpportunity, currencyCollection.Entities[0].GetAttributeValue<string>("currencyname"), currencyCollection.Entities[0].Id);
                            //}
                            //if (exLimitCurrencyELC != null)
                            //{
                            //    UpdateExchangeRateOnOppty(service, tracingService, enOpportunity, currencyCollection.Entities[0].GetAttributeValue<string>("currencyname"), currencyCollection.Entities[0].Id);

                            //}
                        }

                    }
                }
                //if ((policyRec.Opportunity__c != null && opptyRt_Map.get(policyRec.Opportunity__r.recordTypeID).getname().equalsIgnoreCase('New Business - Marine London')) || (policyRec.P_L__c.equalsIgnoreCase('London Marine')))
                //if ((enPolicy.GetAttributeValue<OptionSetValue>("rsa_plcode")).Value == 860006) //'New Business London Marine'
                //if (this.IsExistsOpportunityByLineOfBusiness(service, tracingService, enPolicy.Id, LINE_OF_BUSINESS_NEW_BUSINESS_MARINE_LONDON) &&
                //((EntityReference)enPolicy["rsa_plcode"]).Name.Equals(LINE_OF_BUSINESS_LONDON_MARIENE)) //' New Business London Marine'
                #region New Business London Marine
                //if (((EntityReference)enPolicy["rsa_plcode"]).Name.Equals(LINE_OF_BUSINESS_LONDON_MARIENE)) //' New Business London Marine'
                //                {
                //                    tracingService.Trace("Within 'New Business London Marine'");
                //                    var lineOfBusinessId = this.GetLineOfBusinessById(service, tracingService, LINE_OF_BUSINESS_GSL_RENEWAL_MARINE_LONDON);
                //                    if (lineOfBusinessId != Guid.Empty)
                //                        enOpportunity["rsa_lineofbusiness"] = new EntityReference("rsa_lineofbusiness", lineOfBusinessId);
                //                    else
                //                    {
                //                        isValidationPass = false;
                //                        opportunityFailReason = POLICY_FAIL_REASON_LOB_MARINE_LONDON_MISSING;
                //                        tracingService.Trace("Error in LOB:" + opportunityFailReason);
                //                    }

                //                    if (enPolicy.Attributes.Contains("rsa_product") && ((EntityReference)enPolicy["rsa_product"]).Id != guidEmpty)
                //                        enOpportunity["rsa_product"] = new EntityReference("rsa_product", ((EntityReference)enPolicy["rsa_product"]).Id);
                //                    if (enPolicy.Attributes.Contains("rsa_reviewtypecode") && ((OptionSetValue)enPolicy["rsa_reviewtypecode"]).Value.ToString() != strEmptyString)
                //                    {
                //                        enOpportunity["rsa_reviewtype"] = enPolicy["rsa_reviewtypecode"];
                //                        strReviewType = enPolicy.FormattedValues["rsa_reviewtypecode"].ToString();
                //                        tracingService.Trace("Review Type:" + strReviewType);
                //                    }
                //                    //if (enPolicy["rsa_tradinghandlingsite"] != null && ((EntityReference)enPolicy["rsa_tradinghandlingsite"]).Id != guidEmpty)
                //                    //    enOpportunity["rsa_region"] = enPolicy["rsa_tradinghandlingsite"]; // TODO Cross check
                //                    if (enPolicy.Attributes.Contains("rsa_policyrenewaldate") && enPolicy["rsa_policyrenewaldate"].ToString() != strEmptyString)
                //                    {
                //                        //Defect 2327 : Renewal date is not generating correctly.  
                //                        enOpportunity["rsa_closedate"] = enPolicy["rsa_policyrenewaldate"];
                //                        //enOpportunity["rsa_closedate"] = (enPolicy.GetAttributeValue<DateTime>("rsa_policyrenewaldate")).AddYears(1).AddDays(-1);
                //                    }
                //                    /*
                //                    if (enPolicy.Attributes.Contains("rsa_policysystemcode") &&
                //                        enPolicy.GetAttributeValue<OptionSetValue>("rsa_policysystemcode").Value == 866760001 &&
                //                        enPolicy.Attributes.Contains("rsa_fapcurrency")) //UKRIS
                //                    {
                //                        enOpportunity["rsa_currency"] = enPolicy["rsa_fapcurrency"];
                //                    }
                //                    else if (enPolicy.Attributes.Contains("rsa_policysystemcode") &&
                //                        enPolicy.GetAttributeValue<OptionSetValue>("rsa_policysystemcode").Value == 866760001 &&
                //                        enPolicy.Attributes.Contains("rsa_epicurrency"))
                //                    {
                //                        enOpportunity["rsa_currency"] = enPolicy["rsa_epicurrency"];
                //                    }
                //                    */
                //                    enOpportunity["rsa_stage"] = new OptionSetValue(866760033); // 'In View'
                //                    strOpportunityDescription = strReviewType + " " + strPolicyCOBName + " " + strPolicyCustomerName;
                //                    enOpportunity["description"] = strOpportunityDescription;
                //                    if (enPolicy.Attributes.Contains("rsa_policyrenewaldate"))
                //                    {
                //                        enOpportunity["rsa_expirydatemarine"] = (enPolicy.GetAttributeValue<DateTime>("rsa_policyrenewaldate")).AddYears(1).AddDays(-1);
                //                    }
                //#region MISSING FIELDS - TODO

                //                    /* //if (enPolicy["rsa_tradinghandlingsite"] != null && ((EntityReference)enPolicy["rsa_tradinghandlingsite"]).Id != guidEmpty)
                //                    //    enOpportunity["rsa_region"] = enPolicy["rsa_tradinghandlingsite"]; // TODO Cross check
                //                     */

                //#endregion MISSING FIELDS

                //                    if (enPolicy.Attributes.Contains("rsa_ppmscore") && enPolicy["rsa_ppmscore"].ToString() != strEmptyString)
                //                        enOpportunity["rsa_ppmscore"] = enPolicy["rsa_ppmscore"];

                //                    if (enPolicy.Attributes.Contains("rsa_classificationcode") && enPolicy["rsa_classificationcode"].ToString() != strEmptyString)
                //                        enOpportunity["rsa_expiringclassificationcode"] = enPolicy["rsa_classificationcode"];

                //                    if (enPolicy.Attributes.Contains("rsa_rsaexpiringcommissionpercent") && enPolicy["rsa_rsaexpiringcommissionpercent"].ToString() != strEmptyString)
                //                        enOpportunity["rsa_rsaexpiringcommission"] = enPolicy["rsa_rsaexpiringcommissionpercent"];

                //                    if (enPolicy.Attributes.Contains("rsa_rsaexpiringcommissionpc") && enPolicy["rsa_rsaexpiringcommissionpc"].ToString() != strEmptyString)
                //                        enOpportunity["rsa_rsaexpiringcommissionpc"] = enPolicy["rsa_rsaexpiringcommissionpc"];

                //                    if (enPolicy.Attributes.Contains("rsa_rsaexpiringpremiumpc") && enPolicy["rsa_rsaexpiringpremiumpc"].ToString() != strEmptyString)
                //                        enOpportunity["rsa_expiringgrosspremiumpc"] = enPolicy["rsa_rsaexpiringpremiumpc"];

                //                    if (enPolicy.Attributes.Contains("rsa_expiringpolicynumber") && enPolicy["rsa_expiringpolicynumber"].ToString() != strEmptyString)
                //                        enOpportunity["rsa_expiringpolicynumber"] = enPolicy["rsa_expiringpolicynumber"];

                //                    if (enPolicy.Attributes.Contains("rsa_expiringpolicysystem") && enPolicy["rsa_expiringpolicysystem"].ToString() != strEmptyString)
                //                        enOpportunity["rsa_expiringpolicysystem"] = enPolicy["rsa_expiringpolicysystem"];

                //                    if (enPolicy.Attributes.Contains("rsa_expiringbranch") && enPolicy["rsa_expiringbranch"].ToString() != strEmptyString)
                //                        enOpportunity["rsa_expiringpolicybranch"] = enPolicy["rsa_expiringbranch"];

                //                    if (enPolicy.Attributes.Contains("rsa_3yearlossratio") && enPolicy["rsa_3yearlossratio"].ToString() != strEmptyString)
                //                        enOpportunity["rsa_3yearlossratiomarine"] = enPolicy["rsa_3yearlossratio"];
                //                    //
                //                }
                #endregion
                if (((EntityReference)enPolicy["rsa_plcode"]).Name.ToLower().Contains("marine")
                && ((EntityReference)enPolicy["rsa_plcode"]).Name.ToLower().Contains("london")) //'London Marine'
                {
                    tracingService.Trace("Within 'London Marine'");
                     lineOfBusinessId = this.GetLineOfBusinessByName(service, tracingService, LINE_OF_BUSINESS_GSL_RENEWAL_MARINE_LONDON);

                    if (lineOfBusinessId != Guid.Empty)
                        enOpportunity["rsa_lineofbusiness"] = new EntityReference("rsa_lineofbusiness", lineOfBusinessId);
                    else
                    {
                        isValidationPass = false;
                        opportunityFailReason = POLICY_FAIL_REASON_LOB_MARINE_LONDON_MISSING;
                        tracingService.Trace("Error in LOB:" + opportunityFailReason);
                    }

                    var oppStageLondonMarine = this.GetOpportunityStageName(service, tracingService, "In View", LINE_OF_BUSINESS_GSL_RENEWAL_MARINE_LONDON);
                    if (oppStageLondonMarine != Guid.Empty)
                        enOpportunity["rsa_opportunitystage"] = new EntityReference("rsa_opportunitystage", oppStageLondonMarine);

                    enOpportunity["rsa_stage"] = new OptionSetValue(866760033); // 'In View'


                    string policyRegion = string.Empty;
                    if (enPolicy.Attributes.Contains("rsa_tradinghandlingsite"))
                    {
                        policyRegion = Convert.ToString(enPolicy.FormattedValues["rsa_tradinghandlingsite"]);
                    }

                    var TradingSitetoRegionRoot = new TradingSitetoRegionRoot();
                    TradingSitetoRegionRoot = getRegionJsonValues("TradingSitetoRegion_RG", tracingService, service);

                    TradingSitetoRegion rosMap = new TradingSitetoRegion();

                    if (TradingSitetoRegionRoot.TradingSitetoRegion != null && enPolicy.Attributes.Contains("rsa_tradinghandlingsite"))
                    {
                        rosMap = (TradingSitetoRegion)TradingSitetoRegionRoot.TradingSitetoRegion.Find(a => a.PolicyValue.Equals(enPolicy.GetAttributeValue<OptionSetValue>("rsa_tradinghandlingsite").Value));
                        tracingService.Trace("RouteOfSaleMapping Quote Status" + rosMap.ToString());

                        if (rosMap != null && rosMap.OpportunityValue != 0)
                        {
                            enOpportunity["rsa_region"] = new OptionSetValue((int)rosMap.OpportunityValue);
                        }

                    }

                    Guid opportunityOwnerId = Guid.Empty;
                    //strPolicyCOBName,LINE_OF_BUSINESS_GSL_RENEWAL_MARINE_LONDON,policyRegion
                    opportunityOwnerId = GetOpportunityOwnerDetails(service, tracingService, policyRegion, LINE_OF_BUSINESS_GSL_RENEWAL_MARINE_LONDON, strPolicyCOBName, "Marine Renewal Opportunity Onwer");

                    if (!opportunityOwnerId.Equals(Guid.Empty))
                        enOpportunity["ownerid"] = new EntityReference("systemuser", opportunityOwnerId);

                    if (enPolicy.Attributes.Contains("rsa_plcode") && ((EntityReference)enPolicy["rsa_plcode"]).Id != guidEmpty
                        && enPolicy.Attributes.Contains("rsa_classofbusiness") && ((EntityReference)enPolicy["rsa_classofbusiness"]).Id != guidEmpty
                        && enPolicy.Attributes.Contains("rsa_broker") && ((EntityReference)enPolicy["rsa_broker"]).Id != guidEmpty)
                    {
                        string plname = ((EntityReference)enPolicy["rsa_plcode"]).Name;
                        string cobName = ((EntityReference)enPolicy["rsa_classofbusiness"]).Name;
                        Guid brokerId = ((EntityReference)enPolicy["rsa_broker"]).Id;
                        Guid BAMUser = this.getBAMUser(service, tracingService, plname, cobName, brokerId);
                        if (BAMUser != Guid.Empty)
                        {
                            enOpportunity["rsa_bdaownerbam"] = new EntityReference("systemuser", BAMUser);
                        }
                    }


                    if (enPolicy.Attributes.Contains("rsa_product") && ((EntityReference)enPolicy["rsa_product"]).Id != guidEmpty)
                        enOpportunity["rsa_product"] = new EntityReference("rsa_product", ((EntityReference)enPolicy["rsa_product"]).Id);
                    if (enPolicy.Attributes.Contains("rsa_reviewtypecode") && ((OptionSetValue)enPolicy["rsa_reviewtypecode"]).Value.ToString() != strEmptyString)
                    {
                        //enOpportunity["rsa_reviewtype"] = enPolicy["rsa_reviewtypecode"];
                        //strReviewType = enPolicy.FormattedValues["rsa_reviewtypecode"].ToString();
                        //tracingService.Trace("Review Type:" + strReviewType);
                    }
                    //if (enPolicy["rsa_tradinghandlingsite"] != null && ((EntityReference)enPolicy["rsa_tradinghandlingsite"]).Id != guidEmpty)
                    //    enOpportunity["rsa_region"] = enPolicy["rsa_tradinghandlingsite"]; // TODO Cross check
                    if (enPolicy.Attributes.Contains("rsa_policyrenewaldate") && enPolicy["rsa_policyrenewaldate"].ToString() != strEmptyString)
                    {
                        //Defect 2327 : Renewal date is not generating correctly.  
                        enOpportunity["rsa_closedate"] = enPolicy["rsa_policyrenewaldate"];
                        //enOpportunity["rsa_closedate"] = (enPolicy.GetAttributeValue<DateTime>("rsa_policyrenewaldate")).AddYears(1).AddDays(-1);
                    }
                    /*
                    if (enPolicy.Attributes.Contains("rsa_policysystemcode") &&
                        enPolicy.GetAttributeValue<OptionSetValue>("rsa_policysystemcode").Value == 866760001 &&
                        enPolicy.Attributes.Contains("rsa_fapcurrency")) //UKRIS
                    {
                        enOpportunity["rsa_currency"] = enPolicy["rsa_fapcurrency"];
                    }
                    else if (enPolicy.Attributes.Contains("rsa_policysystemcode") &&
                        enPolicy.GetAttributeValue<OptionSetValue>("rsa_policysystemcode").Value == 866760001 &&
                        enPolicy.Attributes.Contains("rsa_epicurrency"))
                    {
                        enOpportunity["rsa_currency"] = enPolicy["rsa_epicurrency"];
                    }
                    */



                    strOpportunityDescription = strReviewType + " " + strPolicyCOBName + " " + strPolicyCustomerName;
                    enOpportunity["description"] = strOpportunityDescription;
                    if (enPolicy.Attributes.Contains("rsa_policyrenewaldate"))
                    {
                        enOpportunity["rsa_expirydatemarine"] = (enPolicy.GetAttributeValue<DateTime>("rsa_policyrenewaldate")).AddYears(1).AddDays(-1);
                    }
                    #region MISSING FIELDS - TODO

                    /* //if (enPolicy["rsa_tradinghandlingsite"] != null && ((EntityReference)enPolicy["rsa_tradinghandlingsite"]).Id != guidEmpty)
                    //    enOpportunity["rsa_region"] = enPolicy["rsa_tradinghandlingsite"]; // TODO Cross check
                     */

                    #endregion MISSING FIELDS

                    if (enPolicy.Attributes.Contains("rsa_ppmscore") && enPolicy["rsa_ppmscore"].ToString() != strEmptyString)
                        enOpportunity["rsa_ppmscore"] = enPolicy["rsa_ppmscore"];

                    if (enPolicy.Attributes.Contains("rsa_classificationcode") && enPolicy["rsa_classificationcode"].ToString() != strEmptyString)
                        enOpportunity["rsa_expiringclassificationcode"] = enPolicy["rsa_classificationcode"];

                    //Defect id 2454 : sumegh  Dhole : 20 Oct 2021: Expiring premium to be displayed in decimals on opportunity 
                    if (enPolicy.Attributes.Contains("rsa_rsaexpiringcommissionpercent") && enPolicy["rsa_rsaexpiringcommissionpercent"].ToString() != strEmptyString)
                    {
                        enOpportunity["rsa_rsaexpiringcommission"] = Convert.ToDecimal(enPolicy["rsa_rsaexpiringcommissionpercent"]) / 100;
                        enOpportunity["rsa_rsaexpiringcommissiongbpper"] = Convert.ToDecimal(enPolicy["rsa_rsaexpiringcommissionpercent"]) / 100;
                    }

                    if (enPolicy.Attributes.Contains("rsa_rsaexpiringcommissionpc") && enPolicy["rsa_rsaexpiringcommissionpc"].ToString() != strEmptyString)
                        enOpportunity["rsa_rsaexpiringcommissionpc"] = Convert.ToDecimal(enPolicy["rsa_rsaexpiringcommissionpc"]);

                    if (enPolicy.Attributes.Contains("rsa_rsaexpiringpremiumpc") && enPolicy["rsa_rsaexpiringpremiumpc"].ToString() != strEmptyString)
                        enOpportunity["rsa_expiringgrosspremiumpc"] = enPolicy["rsa_rsaexpiringpremiumpc"];

                    if (enPolicy.Attributes.Contains("rsa_expiringpolicynumber") && enPolicy["rsa_expiringpolicynumber"].ToString() != strEmptyString)
                        enOpportunity["rsa_expiringpolicynumber"] = enPolicy["rsa_expiringpolicynumber"];

                    if (enPolicy.Attributes.Contains("rsa_expiringpolicysystem") && enPolicy["rsa_expiringpolicysystem"].ToString() != strEmptyString)
                        enOpportunity["rsa_expiringpolicysystem"] = enPolicy["rsa_expiringpolicysystem"];

                    if (enPolicy.Attributes.Contains("rsa_expiringbranch") && enPolicy["rsa_expiringbranch"].ToString() != strEmptyString)
                        enOpportunity["rsa_expiringpolicybranch"] = enPolicy["rsa_expiringbranch"];

                    if (enPolicy.Attributes.Contains("rsa_3yearlossratio") && enPolicy["rsa_3yearlossratio"].ToString() != strEmptyString)
                        enOpportunity["rsa_3yearlossratiomarine"] = enPolicy["rsa_3yearlossratio"];
                    //
                }

                //if ((policyRec.Opportunity__c != null && opptyRt_Map.get(policyRec.Opportunity__r.recordTypeID).getname().equalsIgnoreCase('New Business - Marine Regional')) || (policyRec.P_L__c.equalsIgnoreCase('Regional Marine')))
                //else if (this.IsExistsOpportunityByLineOfBusiness(service, tracingService, enPolicy.Id, LINE_OF_BUSINESS_NEW_BUSINESS_MARINE_REGIONAL) ||
                //  ((EntityReference)enPolicy["rsa_plcode"]).Name.Equals(LINE_OF_BUSINESS_REGIONAL_MARIENE)) //'Regional Marine'
                //else if ((enPolicy.GetAttributeValue<OptionSetValue>("rsa_plcode")).Value == 860007) //'Regional Marine'
                else if (((EntityReference)enPolicy["rsa_plcode"]).Name.ToLower().Contains("marine")
                         && ((EntityReference)enPolicy["rsa_plcode"]).Name.ToLower().Contains("regional"))//'Regional Marine'
                {
                    tracingService.Trace("Within 'Regional Marine'");
                     lineOfBusinessId = this.GetLineOfBusinessByName(service, tracingService, LINE_OF_BUSINESS_GSL_RENEWAL_REGIONAL_MARIENE);
                    if (lineOfBusinessId != Guid.Empty)
                        enOpportunity["rsa_lineofbusiness"] = new EntityReference("rsa_lineofbusiness", lineOfBusinessId);
                    else
                    {
                        isValidationPass = false;
                        opportunityFailReason = POLICY_FAIL_REASON_LOB_MARINE_REGIONAL_MISSING;
                    }

                    var oppStageLondonRegion = this.GetOpportunityStageName(service, tracingService, "In View", LINE_OF_BUSINESS_GSL_RENEWAL_REGIONAL_MARIENE);
                    if (oppStageLondonRegion != Guid.Empty)
                        enOpportunity["rsa_opportunitystage"] = new EntityReference("rsa_opportunitystage", oppStageLondonRegion);

                    string policyRegion = string.Empty;
                    if (enPolicy.Attributes.Contains("rsa_tradinghandlingsite"))
                    {
                        policyRegion = Convert.ToString(enPolicy.FormattedValues["rsa_tradinghandlingsite"]);
                    }

                    var TradingSitetoRegionRoot = new TradingSitetoRegionRoot();
                    TradingSitetoRegionRoot = getRegionJsonValues("TradingSitetoRegion_RG", tracingService, service);

                    TradingSitetoRegion rosMap = new TradingSitetoRegion();

                    if (TradingSitetoRegionRoot.TradingSitetoRegion != null && enPolicy.Attributes.Contains("rsa_tradinghandlingsite"))
                    {
                        rosMap = (TradingSitetoRegion)TradingSitetoRegionRoot.TradingSitetoRegion.Find(a => a.PolicyValue.Equals(enPolicy.GetAttributeValue<OptionSetValue>("rsa_tradinghandlingsite").Value));
                        tracingService.Trace("RouteOfSaleMapping Quote Status" + rosMap.ToString());

                        if (rosMap != null && rosMap.OpportunityValue != 0)
                        {
                            enOpportunity["rsa_region"] = new OptionSetValue((int)rosMap.OpportunityValue);
                        }

                    }

                    Guid opportunityOwnerId = Guid.Empty;
                    //strPolicyCOBName,LINE_OF_BUSINESS_GSL_RENEWAL_MARINE_LONDON,policyRegion
                    opportunityOwnerId = GetOpportunityOwnerDetails(service, tracingService, policyRegion, LINE_OF_BUSINESS_GSL_RENEWAL_REGIONAL_MARIENE, strPolicyCOBName, "Marine Renewal Opportunity Onwer");

                    if (!opportunityOwnerId.Equals(Guid.Empty))
                        enOpportunity["ownerid"] = new EntityReference("systemuser", opportunityOwnerId);

                    if (enPolicy.Attributes.Contains("rsa_plcode") && ((EntityReference)enPolicy["rsa_plcode"]).Id != guidEmpty
                        && enPolicy.Attributes.Contains("rsa_classofbusiness") && ((EntityReference)enPolicy["rsa_classofbusiness"]).Id != guidEmpty
                        && enPolicy.Attributes.Contains("rsa_broker") && ((EntityReference)enPolicy["rsa_broker"]).Id != guidEmpty)
                    {
                        string plname = ((EntityReference)enPolicy["rsa_plcode"]).Name;
                        string cobName = ((EntityReference)enPolicy["rsa_classofbusiness"]).Name;
                        Guid brokerId = ((EntityReference)enPolicy["rsa_broker"]).Id;
                        Guid BAMUser = this.getBAMUser(service, tracingService, plname, cobName, brokerId);
                        if (BAMUser != Guid.Empty)
                        {
                            enOpportunity["rsa_bdaownerbam"] = new EntityReference("systemuser", BAMUser);
                        }
                    }

                    if (enPolicy.Attributes.Contains("rsa_product") && ((EntityReference)enPolicy["rsa_product"]).Id != guidEmpty)
                        enOpportunity["rsa_product"] = new EntityReference("rsa_product", ((EntityReference)enPolicy["rsa_product"]).Id);
                    if (enPolicy.Attributes.Contains("rsa_reviewtypecode") && ((OptionSetValue)enPolicy["rsa_reviewtypecode"]).Value.ToString() != strEmptyString)
                    {
                        //enOpportunity["rsa_reviewtype"] = enPolicy["rsa_reviewtypecode"];
                        //strReviewType = enPolicy.FormattedValues["rsa_reviewtypecode"].ToString();
                    }
                    //if (enPolicy["rsa_tradinghandlingsite"] != null && ((EntityReference)enPolicy["rsa_tradinghandlingsite"]).Id != guidEmpty)
                    //    enOpportunity["rsa_region"] = enPolicy["rsa_tradinghandlingsite"]; // TODO Cross check
                    if (enPolicy.Attributes.Contains("rsa_policyrenewaldate") && enPolicy["rsa_policyrenewaldate"].ToString() != strEmptyString)
                    {
                        //Defect 2327 : Renewal date is not generating correctly.  
                        enOpportunity["rsa_closedate"] = enPolicy["rsa_policyrenewaldate"];
                        // enOpportunity["rsa_closedate"] = (enPolicy.GetAttributeValue<DateTime>("rsa_policyrenewaldate")).AddYears(1).AddDays(-1);
                    }
                    /*
                    if (enPolicy.Attributes.Contains("rsa_policysystemcode") &&
                        enPolicy.GetAttributeValue<OptionSetValue>("rsa_policysystemcode").Value == 866760001 &&
                        enPolicy.Attributes.Contains("rsa_fapcurrency")) //UKRIS
                    {
                        enOpportunity["rsa_currency"] = enPolicy["rsa_fapcurrency"];
                    }
                    else if (enPolicy.Attributes.Contains("rsa_policysystemcode") &&
                        enPolicy.GetAttributeValue<OptionSetValue>("rsa_policysystemcode").Value == 866760001 &&
                        enPolicy.Attributes.Contains("rsa_epicurrency"))
                    {
                        enOpportunity["rsa_currency"] = enPolicy["rsa_epicurrency"];
                    }
                    */
                    enOpportunity["rsa_stage"] = new OptionSetValue(866760033); // 'In View'
                                                                                //enOpportunity["description"] = strOpportunityDescription;
                    if (enPolicy.Attributes.Contains("rsa_policyrenewaldate"))
                    {
                        enOpportunity["rsa_expirydatemarine"] = (enPolicy.GetAttributeValue<DateTime>("rsa_policyrenewaldate")).AddYears(1).AddDays(-1);
                    }
                    #region MISSING FIELDS - TODO

                    /*
                    //if (enPolicy["rsa_tradinghandlingsite"] != null && ((EntityReference)enPolicy["rsa_tradinghandlingsite"]).Id != guidEmpty)
                    //    enOpportunity["rsa_region"] = enPolicy["rsa_tradinghandlingsite"]; // TODO Cross check
                     */
                    #endregion MISSING FIELDS - TODO
                    if (enPolicy.Attributes.Contains("rsa_ppmscore") && enPolicy["rsa_ppmscore"].ToString() != strEmptyString)
                        enOpportunity["rsa_ppmscore"] = enPolicy["rsa_ppmscore"];

                    if (enPolicy.Attributes.Contains("rsa_classificationcode") && enPolicy["rsa_classificationcode"].ToString() != strEmptyString)
                        enOpportunity["rsa_expiringclassificationcode"] = enPolicy["rsa_classificationcode"];

                    //Defect id 2356 : sumegh  Dhole : 20 Oct 2021: Expiring premium to be displayed in decimals on opportunity 
                    if (enPolicy.Attributes.Contains("rsa_rsaexpiringcommissionpercent") && enPolicy["rsa_rsaexpiringcommissionpercent"].ToString() != strEmptyString)
                    {
                        enOpportunity["rsa_rsaexpiringcommission"] = Convert.ToDecimal(enPolicy["rsa_rsaexpiringcommissionpercent"]) / 100;
                        enOpportunity["rsa_rsaexpiringcommissiongbpper"] = Convert.ToDecimal(enPolicy["rsa_rsaexpiringcommissionpercent"]) / 100;
                    }

                    if (enPolicy.Attributes.Contains("rsa_rsaexpiringcommissionpc") && enPolicy["rsa_rsaexpiringcommissionpc"].ToString() != strEmptyString)
                        enOpportunity["rsa_rsaexpiringcommissionpc"] = enPolicy["rsa_rsaexpiringcommissionpc"];

                    if (enPolicy.Attributes.Contains("rsa_rsaexpiringpremiumpc") && enPolicy["rsa_rsaexpiringpremiumpc"].ToString() != strEmptyString)
                        enOpportunity["rsa_expiringgrosspremiumpc"] = enPolicy["rsa_rsaexpiringpremiumpc"];

                    if (enPolicy.Attributes.Contains("rsa_expiringpolicynumber") && enPolicy["rsa_expiringpolicynumber"].ToString() != strEmptyString)
                        enOpportunity["rsa_expiringpolicynumber"] = enPolicy["rsa_expiringpolicynumber"];

                    if (enPolicy.Attributes.Contains("rsa_expiringpolicysystem") && enPolicy["rsa_expiringpolicysystem"].ToString() != strEmptyString)
                        enOpportunity["rsa_expiringpolicysystem"] = enPolicy["rsa_expiringpolicysystem"];

                    if (enPolicy.Attributes.Contains("rsa_expiringbranch") && enPolicy["rsa_expiringbranch"].ToString() != strEmptyString)
                        enOpportunity["rsa_expiringpolicybranch"] = enPolicy["rsa_expiringbranch"];

                    if (enPolicy.Attributes.Contains("rsa_3yearlossratio") && enPolicy["rsa_3yearlossratio"].ToString() != strEmptyString)
                        enOpportunity["rsa_3yearlossratiomarine"] = enPolicy["rsa_3yearlossratio"];
                }

                else if (Convert.ToString(enPolicy.FormattedValues["rsa_operationshandlingsite"]).Equals("Isle of Man") ||
                    Convert.ToString(enPolicy.FormattedValues["rsa_tradinghandlingsite"]).Equals("Isle of Man")) //'Isle of Man'

                {
                    tracingService.Trace("Within 'Isle of Man'");
                     lineOfBusinessId = this.GetLineOfBusinessByName(service, tracingService, "Renewal - Isle of Man");
                    if (lineOfBusinessId != Guid.Empty)
                        enOpportunity["rsa_lineofbusiness"] = new EntityReference("rsa_lineofbusiness", lineOfBusinessId);
                    else
                    {
                        isValidationPass = false;
                        opportunityFailReason = POLICY_FAIL_REASON_LOB_MARINE_REGIONAL_MISSING;
                    }
                    if (enPolicy.Attributes.Contains("rsa_product") && ((EntityReference)enPolicy["rsa_product"]).Id != guidEmpty)
                        enOpportunity["rsa_product"] = new EntityReference("rsa_product", ((EntityReference)enPolicy["rsa_product"]).Id);
                    if (enPolicy.Attributes.Contains("rsa_reviewtypecode") && ((OptionSetValue)enPolicy["rsa_reviewtypecode"]).Value.ToString() != strEmptyString)
                    {
                        //enOpportunity["rsa_reviewtype"] = enPolicy["rsa_reviewtypecode"];
                        //strReviewType = enPolicy.FormattedValues["rsa_reviewtypecode"].ToString();
                    }
                    //if (enPolicy["rsa_tradinghandlingsite"] != null && ((EntityReference)enPolicy["rsa_tradinghandlingsite"]).Id != guidEmpty)
                    //    enOpportunity["rsa_region"] = enPolicy["rsa_tradinghandlingsite"]; // TODO Cross check
                    if (enPolicy.Attributes.Contains("rsa_policyrenewaldate") && enPolicy["rsa_policyrenewaldate"].ToString() != strEmptyString)
                    {
                        enOpportunity["rsa_closedate"] = enPolicy["rsa_policyrenewaldate"];
                        //Defect 2327 : Renewal date is not generating correctly.  
                        // enOpportunity["rsa_closedate"] = (enPolicy.GetAttributeValue<DateTime>("rsa_policyrenewaldate")).AddYears(1).AddDays(-1);
                    }
                    /*
                    if (enPolicy.Attributes.Contains("rsa_policysystemcode") &&
                        enPolicy.GetAttributeValue<OptionSetValue>("rsa_policysystemcode").Value == 866760001 &&
                        enPolicy.Attributes.Contains("rsa_fapcurrency")) //UKRIS
                    {
                        enOpportunity["rsa_currency"] = enPolicy["rsa_fapcurrency"];
                    }
                    else if (enPolicy.Attributes.Contains("rsa_policysystemcode") &&
                        enPolicy.GetAttributeValue<OptionSetValue>("rsa_policysystemcode").Value == 866760001 &&
                        enPolicy.Attributes.Contains("rsa_epicurrency"))
                    {
                        enOpportunity["rsa_currency"] = enPolicy["rsa_epicurrency"];
                    }
                    */
                    enOpportunity["rsa_stage"] = new OptionSetValue(866760033); // 'In View'
                                                                                //enOpportunity["description"] = strOpportunityDescription;
                    if (enPolicy.Attributes.Contains("rsa_policyrenewaldate"))
                    {
                        enOpportunity["rsa_expirydatemarine"] = (enPolicy.GetAttributeValue<DateTime>("rsa_policyrenewaldate")).AddYears(1).AddDays(-1);
                    }
                    #region MISSING FIELDS - TODO

                    /*
                    //if (enPolicy["rsa_tradinghandlingsite"] != null && ((EntityReference)enPolicy["rsa_tradinghandlingsite"]).Id != guidEmpty)
                    //    enOpportunity["rsa_region"] = enPolicy["rsa_tradinghandlingsite"]; // TODO Cross check
                     */
                    #endregion MISSING FIELDS - TODO
                    if (enPolicy.Attributes.Contains("rsa_ppmscore") && enPolicy["rsa_ppmscore"].ToString() != strEmptyString)
                        enOpportunity["rsa_ppmscore"] = enPolicy["rsa_ppmscore"];

                    if (enPolicy.Attributes.Contains("rsa_classificationcode") && enPolicy["rsa_classificationcode"].ToString() != strEmptyString)
                        enOpportunity["rsa_expiringclassificationcode"] = enPolicy["rsa_classificationcode"];

                    //Defect id 2356 : sumegh  Dhole : 20 Oct 2021: Expiring premium to be displayed in decimals on opportunity 
                    if (enPolicy.Attributes.Contains("rsa_rsaexpiringcommissionpercent") && enPolicy["rsa_rsaexpiringcommissionpercent"].ToString() != strEmptyString)
                    {
                        enOpportunity["rsa_rsaexpiringcommission"] = Convert.ToDecimal(enPolicy["rsa_rsaexpiringcommissionpercent"]) / 100;
                        enOpportunity["rsa_rsaexpiringcommissiongbpper"] = Convert.ToDecimal(enPolicy["rsa_rsaexpiringcommissionpercent"]) / 100;
                    }

                    if (enPolicy.Attributes.Contains("rsa_rsaexpiringcommissionpc") && enPolicy["rsa_rsaexpiringcommissionpc"].ToString() != strEmptyString)
                        enOpportunity["rsa_rsaexpiringcommissionpc"] = enPolicy["rsa_rsaexpiringcommissionpc"];

                    if (enPolicy.Attributes.Contains("rsa_rsaexpiringpremiumpc") && enPolicy["rsa_rsaexpiringpremiumpc"].ToString() != strEmptyString)
                        enOpportunity["rsa_expiringgrosspremiumpc"] = enPolicy["rsa_rsaexpiringpremiumpc"];

                    if (enPolicy.Attributes.Contains("rsa_expiringpolicynumber") && enPolicy["rsa_expiringpolicynumber"].ToString() != strEmptyString)
                        enOpportunity["rsa_expiringpolicynumber"] = enPolicy["rsa_expiringpolicynumber"];

                    if (enPolicy.Attributes.Contains("rsa_expiringpolicysystem") && enPolicy["rsa_expiringpolicysystem"].ToString() != strEmptyString)
                        enOpportunity["rsa_expiringpolicysystem"] = enPolicy["rsa_expiringpolicysystem"];

                    if (enPolicy.Attributes.Contains("rsa_expiringbranch") && enPolicy["rsa_expiringbranch"].ToString() != strEmptyString)
                        enOpportunity["rsa_expiringpolicybranch"] = enPolicy["rsa_expiringbranch"];

                    if (enPolicy.Attributes.Contains("rsa_3yearlossratio") && enPolicy["rsa_3yearlossratio"].ToString() != strEmptyString)
                        enOpportunity["rsa_3yearlossratiomarine"] = enPolicy["rsa_3yearlossratio"];
                }
                else
                {
                    tracingService.Trace("Within 'RGSL - Renewal'");
                    // GSL - Renewal
                    lineOfBusinessId = this.GetLineOfBusinessById(service, tracingService, LINE_OF_BUSINESS_GSL_RENEWAL);
                    if (lineOfBusinessId != Guid.Empty)
                        enOpportunity["rsa_lineofbusiness"] = new EntityReference("rsa_lineofbusiness", lineOfBusinessId);
                    else
                    {
                        isValidationPass = false;
                        opportunityFailReason = POLICY_FAIL_REASON_LOB_GSL_RENEWAL_MISSING;
                    }
                }

                //2440 : Populate default values of opportunity while renewal generation : Samiksha Dhakde : 23 Feb 2022

                //1. fetch RSA custom label for default values config. 
                // Dependentoptionset // JSON parsing
                //List of default values.. populate if doesnt contain data
                tracingService.Trace("Fetch custom Label for default values of currency and decimal");
                QueryExpression CustomLblDefaultvalue = new QueryExpression("rsa_customlabel");
                CustomLblDefaultvalue.TopCount = 1;
                CustomLblDefaultvalue.NoLock = true;
                CustomLblDefaultvalue.ColumnSet = new ColumnSet(new string[] { "rsa_dependentoptionsetjson", "rsa_name" });
                ConditionExpression cond = new ConditionExpression();
                cond.AttributeName = "rsa_opportunitylob";
                cond.Operator = ConditionOperator.Equal;
               // cond.Values.Add(lob.Id);
                cond.Values.Add(lineOfBusinessId);
                CustomLblDefaultvalue.Criteria.AddCondition(cond);
                EntityCollection customLblColl = service.RetrieveMultiple(CustomLblDefaultvalue);
                tracingService.Trace("Fetch custom Label for default values count :" + customLblColl.Entities.Count +"---" +  lob.Id + "--" + lineOfBusinessId);
                RSAcustomlabelJson rSAcustomlabelJson = new RSAcustomlabelJson();
                foreach (var item in customLblColl.Entities)
                {

                    string decimalDefaultJson = item.Attributes.Contains("rsa_dependentoptionsetjson") ? Convert.ToString(item.Attributes["rsa_dependentoptionsetjson"]) : string.Empty;
                    tracingService.Trace("DefaultJSON found");
                    //Parse this string to object 
                    //var ms = new MemoryStream(Encoding.UTF8.GetBytes(decimalDefaultJson));
                    //var ser = new DataContractJsonSerializer(rSAcustomlabelJson.GetType());
                    //rSAcustomlabelJson = ser.ReadObject(ms) as RSAcustomlabelJson;
                    //ms.Close();
                    //Remediation - 21/07/2022
                    ms = new MemoryStream(Encoding.UTF8.GetBytes(decimalDefaultJson));
                    var ser = new DataContractJsonSerializer(rSAcustomlabelJson.GetType());
                    rSAcustomlabelJson = ser.ReadObject(ms) as RSAcustomlabelJson;
                    tracingService.Trace("Start populating data");
                    List<ParentFieldDependency> prtDependency = rSAcustomlabelJson.ParentFieldDependency;
                    foreach (var decimalCollectionItem in prtDependency)
                    {
                        List<DecimalCurrencyfield> DecimalDependency = decimalCollectionItem.DecimalCurrencyfields;

                        foreach (var decimalitem in DecimalDependency)
                        {
                            if (decimalitem.DataType != null)
                            {
                                tracingService.Trace("Attribute Schema : "+ decimalitem.DependentField);
                                if (enOpportunity.Attributes.Contains(decimalitem.DependentField))
                                {
                                   // tracingService.Trace("Attribute Schema present in existing object ");
                                    switch (decimalitem.DataType.ToLower())
                                    {
                                        case "money":
                                            enOpportunity[decimalitem.DependentField] = ((Money)enOpportunity[decimalitem.DependentField]).Value != 0.00M ? enOpportunity[decimalitem.DependentField] : new Money(0.00M);
                                            break;
                                        case "decimal":
                                            enOpportunity[decimalitem.DependentField] = Convert.ToDecimal(enOpportunity[decimalitem.DependentField]) != 0.00M ? enOpportunity[decimalitem.DependentField] : 0.00M;
                                            break;
                                        default:
                                            break;
                                    }
                                }
                                else
                                {
                                   // tracingService.Trace("Attribute Schema not present in existing object hence marking it as 0.00");
                                    switch (decimalitem.DataType.ToLower())
                                    {
                                        case "money":
                                            enOpportunity[decimalitem.DependentField] = new Money(0.00M);
                                            break;
                                        case "decimal":
                                            enOpportunity[decimalitem.DependentField] = 0.00M;
                                            break;
                                        default:
                                            break;
                                    }
                                }
                            }
                        }
                    }
                }
                //

                tracingService.Trace("Population of opportunity completed");
                if (!isValidationPass)
                {
                    tracingService.Trace("validation failed during opportunity creation: " + opportunityFailReason);
                    tracingService.Trace("Opportunity population failed due to: " + opportunityFailReason);
                    enOpportunity = null;
                    throw new Exception(opportunityFailReason);
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Opportunity population failed: " + ex.Message);
                enOpportunity = null;
            }
            finally 
            {
                ms.Close();
            }
            return enOpportunity;
        }

        private Guid getBAMUser(IOrganizationService service, ITracingService tracingService, string plname, string cobName, Guid brokerId)
        {
            Guid userGuid = Guid.Empty;
            string BDMrole = string.Empty;
            var fetchXml = @"<fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>
                                <entity name='rsa_salesteamroles'>
                                <attribute name='rsa_salesteamrolesid'/>
                                <attribute name='rsa_name'/>
                                <attribute name='createdon'/>
                                <attribute name='rsa_salesmanagerrolename'/>
                                <attribute name='rsa_pl'/>
                                <attribute name='rsa_classofbusiness'/>
                                <attribute name='rsa_bdmrolename'/>
                                <order descending='false' attribute='rsa_name'/>
                                <link-entity name='rsa_pl' alias='aa' link-type='inner' to='rsa_pl' from='rsa_plid'>
                                <filter type='and'>
                                <condition attribute='rsa_name' value='{0}' operator='eq'/>
                                </filter>
                                </link-entity>
                                <link-entity name='rsa_classofbusiness' alias='ab' link-type='inner' to='rsa_classofbusiness' from='rsa_classofbusinessid'>
                                <filter type='and'>
                                <condition attribute='rsa_name' value='{1}' operator='eq'/>
                                </filter>
                                </link-entity>
                                </entity>
                                </fetch>";

            try
            {
                cobName = cobName.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;");
                plname = plname.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;");
                var enOwnerDetails = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, plname, cobName)));
                if (enOwnerDetails != null && enOwnerDetails.Entities.Count > 0)
                {
                    tracingService.Trace("BDMrole fetching");
                    BDMrole = enOwnerDetails[0].Attributes.Contains("rsa_bdmrolename") ? Convert.ToString(enOwnerDetails[0].Attributes["rsa_bdmrolename"]) : string.Empty;
                    tracingService.Trace("BDMrole:" + BDMrole);
                    if (BDMrole != string.Empty)
                    {
                        var fetchXmlBAMUser = @"<fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>
                                                    <entity name='connection'>
                                                    <attribute name='record2id'/>
                                                    <attribute name='record2roleid'/>
                                                    <attribute name='connectionid'/>
                                                    <order descending='false' attribute='record2id'/>
                                                    <filter type='and'>
                                                    <condition attribute='record1id' value='{0}' uitype='account' operator='eq'/>
                                                    </filter>
                                                    <link-entity name='connectionrole' alias='ae' link-type='inner' to='record2roleid' from='connectionroleid'>
                                                    <filter type='and'>
                                                    <condition attribute='name' value='{1}' operator='eq'/>
                                                    </filter>
                                                    </link-entity>
                                                    </entity>
                                                    </fetch>";

                        try
                        {
                            var BAMUserDetails = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXmlBAMUser, brokerId, BDMrole)));
                            if (BAMUserDetails != null && BAMUserDetails.Entities.Count > 0)
                            {
                                userGuid = BAMUserDetails[0].Attributes.Contains("record2id") ? ((EntityReference)BAMUserDetails[0].Attributes["record2id"]).Id : Guid.Empty;
                                tracingService.Trace("userGuid:" + userGuid.ToString());
                            }
                        }
                        catch (Exception ex)
                        {
                            tracingService.Trace("Exception while fetching BAMUserDetails in getBAMUser:" + ex.Message);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetching enOwnerDetails in getBAMUser:" + ex.Message);
            }
            return userGuid;
        }

        public Guid GetOpportunityOwnerDetails(IOrganizationService service, ITracingService tracingService, string region, string recordtypename, string class_of_business, string customName)
        {
            Guid userGuid = Guid.Empty;
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' no-lock='true'>
                    <entity name='rsa_customsetting'>
                        <attribute name='rsa_region' />
                            <attribute name = 'rsa_recordtypename' />
                            <attribute name='rsa_opportunityownerid' />
                            <attribute name='rsa_class_of_business' /> 
							<attribute name='rsa_user' /> 							
                        <filter type='and'>
							<condition attribute='rsa_region' value='{0}' operator='eq'/>
							<condition attribute='rsa_recordtypename' value='{1}' operator='eq'/>
                             <filter type='or'>
                              <condition attribute = 'rsa_class_of_business' operator= 'null' />
                              <condition attribute = 'rsa_class_of_business' value = '{2}' operator= 'eq' />
                              </filter>
                              <condition attribute = 'rsa_customsettingtypename' operator= 'like' value='{3}%' />
							   </filter>                 
                    </entity>
                </fetch>";
            try
            {
                var enOwnerDetails = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, region, recordtypename, class_of_business, customName)));
                if (enOwnerDetails != null && enOwnerDetails.Entities.Count > 0)
                {
                    userGuid = enOwnerDetails[0].Attributes.Contains("rsa_user") ? ((EntityReference)enOwnerDetails[0].Attributes["rsa_user"]).Id : Guid.Empty;
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetching OpportunityOwnerDetails in GetOpportunityOwnerDetails:" + ex.Message);
            }
            return userGuid;
        }

        public TradingSitetoRegionRoot getRegionJsonValues(string strCustomLabel, ITracingService tracingService, IOrganizationService service)
        {
            tracingService.Trace("getRouteOfSaleJsonValues - Loaded");
            var tsOptionsetRoot = new TradingSitetoRegionRoot();

            string dependentOptionset = string.Empty;

            QueryExpression RegionExpression = new QueryExpression("rsa_customlabel");
            RegionExpression.TopCount = 1;
            RegionExpression.NoLock = true;
            RegionExpression.ColumnSet = new ColumnSet(new string[] { "rsa_dependentoptionsetjson" });
            RegionExpression.Criteria = new FilterExpression();
            RegionExpression.Criteria.AddCondition("rsa_name", ConditionOperator.Equal, strCustomLabel);
            EntityCollection regionCustomLabel = service.RetrieveMultiple(RegionExpression);
            if (regionCustomLabel != null && regionCustomLabel.Entities.Count > 0)
            {
                tracingService.Trace("regionCustomLabel != null && regionCustomLabel.Entities.Count > 0");

                if (regionCustomLabel.Entities[0].Contains("rsa_dependentoptionsetjson")
                    && !string.IsNullOrEmpty(regionCustomLabel.Entities[0]["rsa_dependentoptionsetjson"].ToString()))
                {
                    dependentOptionset = regionCustomLabel.Entities[0]["rsa_dependentoptionsetjson"].ToString();
                    tracingService.Trace("Optionset Mapping retrieved: TradingSitetoRegion Optionset");

                    //var ms = new MemoryStream(Encoding.UTF8.GetBytes(dependentOptionset));
                    //var ser = new DataContractJsonSerializer(tsOptionsetRoot.GetType());
                    //tsOptionsetRoot = ser.ReadObject(ms) as TradingSitetoRegionRoot;
                    //ms.Close();
                    //Remediation - 21/07/2022
                    var ms = new MemoryStream(Encoding.UTF8.GetBytes(dependentOptionset));
                    try 
                    {
                        var ser = new DataContractJsonSerializer(tsOptionsetRoot.GetType());
                        tsOptionsetRoot = ser.ReadObject(ms) as TradingSitetoRegionRoot;
                    }
                    catch (Exception ex) 
                    {
                        throw new InvalidPluginExecutionException(ex.Message);
                    }
                    finally 
                    {
                        ms.Close();
                    }
                }
            }
            else
            {
                tracingService.Trace("regionCustomLabel == null || regionCustomLabel.Entities.Count < 1");
            }
            tracingService.Trace("getRegionJsonValues - Unloaded");
            return tsOptionsetRoot;
        }

        /// <summary>
        /// check whether opportiniy with specific LOB exists or not
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="guidPolicyId"></param>
        /// <param name="strLOB"></param>
        /// <returns></returns>
        private bool IsExistsOpportunityByLineOfBusiness(IOrganizationService service, ITracingService tracingService, Guid guidPolicyId, string strLOB)
        {
            //New Business - Marine London
            //New Business - Marine Regional"
            var returnValue = false;
            try
            {
                if (strLOB != string.Empty)
                {
                    Guid guidLOBId = this.GetLineOfBusinessById(service, tracingService, strLOB);
                    if (guidLOBId != Guid.Empty)
                    {
                        var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                      <entity name='opportunity'>
                        <attribute name='name' />
                        <attribute name='customerid' />
                        <attribute name='estimatedvalue' />
                        <attribute name='statuscode' />
                        <attribute name='opportunityid' />
                        <order attribute='name' descending='false' />
                        <filter type='and'>
                          <condition attribute='rsa_policyid' operator='eq' value='{0}' />
                          <condition attribute='rsa_lineofbusiness' operator='eq' value='{1}' />
                        </filter>
                      </entity>
                    </fetch>";
                        var entityColOpportunity = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, guidPolicyId, guidLOBId)));
                        if (entityColOpportunity != null && entityColOpportunity.Entities.Count > 0)
                            returnValue = true;
                    }
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Exception while fetching LOB(IsExistsOpportunityByLineOfBusiness): " + ex.Message);
            }
            tracingService.Trace("Within IsExistsOpportunityByLineOfBusiness: " + returnValue.ToString());
            return returnValue;
        }

        /// <summary>
        /// Get Line of business id 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="lineOfBusiness"></param>
        /// <returns></returns>
        private Guid GetLineOfBusinessById(IOrganizationService service, ITracingService tracingService, string lineOfBusiness)
        {
            Guid lobId = Guid.Empty;
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='rsa_lineofbusiness'>
                                <attribute name='rsa_lineofbusinessid' />
                                <filter type='and'>
                                  <condition attribute='rsa_name' operator='eq' value='Renewal' />
                                </filter>
                              </entity>
                            </fetch>";
            var lineOfBusinessEntity = service.RetrieveMultiple(new FetchExpression(fetchXml));
            if (lineOfBusinessEntity != null && lineOfBusinessEntity.Entities.Count > 0)
                lobId = lineOfBusinessEntity.Entities[0].Id;
            tracingService.Trace("Within GetLineOfBusinessById: " + lobId.ToString());
            return lobId;
        }

        private Guid GetLineOfBusinessByName(IOrganizationService service, ITracingService tracingService, string lineOfBusiness)
        {
            Guid lobId = Guid.Empty;
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='rsa_lineofbusiness'>
                                <attribute name='rsa_lineofbusinessid' />
                                <filter type='and'>
                                  <condition attribute='rsa_name' operator='eq' value='{0}' />
                                </filter>
                              </entity>
                            </fetch>";
            var lineOfBusinessEntity = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, lineOfBusiness)));
            if (lineOfBusinessEntity != null && lineOfBusinessEntity.Entities.Count > 0)
                lobId = lineOfBusinessEntity.Entities[0].Id;
            tracingService.Trace("Within GetLineOfBusinessByName: " + lobId.ToString());
            return lobId;
        }

        /// <summary>
        /// Get Opportunity Stage id 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="oppStageName"></param>
        /// <returns></returns>
        private Guid GetOpportunityStageId(IOrganizationService service, ITracingService tracingService, string oppStageName)
        {
            Guid oppStageId = Guid.Empty;
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
    <entity name = 'rsa_opportunitystage'>   
       <attribute name = 'rsa_name'/>    
          <attribute name = 'rsa_opportunitystageid'/>       
           <order attribute = 'rsa_name' descending = 'false'/>          
              <filter type = 'and'>           
                 <condition attribute = 'rsa_name' operator= 'eq' value = 'Renewal Work Up'/>               
                   </filter>               
                   <link-entity name = 'rsa_lineofbusiness' from = 'rsa_lineofbusinessid' to = 'rsa_lineofbusiness' link-type = 'inner' alias = 'ab'>                            
                                  <filter type = 'and'>                             
                                     <condition attribute = 'rsa_name' operator= 'eq' value = 'Renewal'/>                                 
                                       </filter>                                 
                                     </link-entity>                                 
                                   </entity>
                                 </fetch>";
            var oppStageEntity = service.RetrieveMultiple(new FetchExpression(fetchXml));
            if (oppStageEntity != null && oppStageEntity.Entities.Count > 0)
                oppStageId = oppStageEntity.Entities[0].Id;
            tracingService.Trace("Within GetOpportunityStageId: " + oppStageId.ToString());
            return oppStageId;
        }

        private Guid GetOpportunityStageName(IOrganizationService service, ITracingService tracingService, string oppStageName, string lineofBusinessName)
        {
            Guid oppStageId = Guid.Empty;
            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
    <entity name = 'rsa_opportunitystage'>   
       <attribute name = 'rsa_name'/>    
          <attribute name = 'rsa_opportunitystageid'/>       
           <order attribute = 'rsa_name' descending = 'false'/>          
              <filter type = 'and'>           
                 <condition attribute = 'rsa_name' operator= 'eq' value = '{0}'/>               
                   </filter>               
                   <link-entity name = 'rsa_lineofbusiness' from = 'rsa_lineofbusinessid' to = 'rsa_lineofbusiness' link-type = 'inner' alias = 'ab'>                            
                                  <filter type = 'and'>                             
                                     <condition attribute = 'rsa_name' operator= 'eq' value = '{1}'/>                                 
                                       </filter>                                 
                                     </link-entity>                                 
                                   </entity>
                                 </fetch>";
            var oppStageEntity = service.RetrieveMultiple(new FetchExpression(String.Format(fetchXml, oppStageName, lineofBusinessName)));
            if (oppStageEntity != null && oppStageEntity.Entities.Count > 0)
                oppStageId = oppStageEntity.Entities[0].Id;
            tracingService.Trace("Within GetOpportunityStageName: " + oppStageId.ToString());
            return oppStageId;
        }

        internal void UpdateExchangeRateOnOppty(IOrganizationService service, ITracingService tracer, Entity entity, string currencyName, Guid currencyID)
        {

            string conversionIdsSet = string.Empty;
            string recordTypeNames = string.Empty;
            string[] recordTypeName = null;
            Dictionary<string, Entity> my_Dict = new Dictionary<string, Entity>();
            EntityCollection customLabels = GetCutomLabelDetails(service, "Conversion_ID_Currency", "Page_Layouts_supporting_To_GBP_conversion", string.Empty);
            if (customLabels.Entities.Count > 0)
            {
                foreach (var objCustomLabel in customLabels.Entities)
                {
                    string customLabelName = objCustomLabel.GetAttributeValue<string>("rsa_name");
                    if (customLabelName == "Conversion_ID_Currency")
                    {
                        conversionIdsSet = objCustomLabel.Attributes.Contains("rsa_values") ? objCustomLabel.GetAttributeValue<string>("rsa_values") : string.Empty; //gbp
                    }

                    if (customLabelName == "Page_Layouts_supporting_To_GBP_conversion")
                    {
                        recordTypeNames = objCustomLabel.Attributes.Contains("rsa_values") ? objCustomLabel.GetAttributeValue<string>("rsa_values") : string.Empty;
                        if (recordTypeNames.Contains(";"))
                            recordTypeName = recordTypeNames.Split(';'); //??
                    }
                }
                if (recordTypeName != null && recordTypeName.Length > 0)
                {
                    EntityCollection exchangeRates = GetExchangeRates(service, conversionIdsSet, currencyID);

                    tracer.Trace("Exchange Rate Count:{0}", exchangeRates.Entities.Count);
                    // tracer.Trace("ELC Exchange Rate Count:{0}", ELCexchangeRates.Entities.Count);
                    for (int i = 0; i <= (recordTypeName.Length) - 1; i++)
                    {
                        if (exchangeRates.Entities.Count > 0)
                        {
                            foreach (var exrate in exchangeRates.Entities)
                            {
                                EntityReference exrCurrency = exrate.GetAttributeValue<EntityReference>("rsa_currencyid");
                                {
                                    decimal exRates = exrate.Attributes.Contains("rsa_rate") ? exrate.GetAttributeValue<decimal>("rsa_rate") : 0;
                                    if (exrCurrency.Name != null && exRates != 0 && !string.IsNullOrEmpty(currencyName) && currencyName.ToLowerInvariant() == exrCurrency.Name.ToLowerInvariant())
                                    {
                                        tracer.Trace("Exchange line 67");
                                        entity["rsa_exchangerate"] = exrate.GetAttributeValue<decimal>("rsa_rate");
                                        //entity["rsa_exchangeid"] = exrate.Id;
                                    }

                                }
                            }
                        }



                    }
                }
            }
        }
        public static EntityCollection GetExchangeRates(IOrganizationService service, string conversionIdsSet, Guid currencyid)
        {
            string fetchQuery = "<fetch mapping = 'logical'>";
            fetchQuery += "<entity name = 'rsa_exchangerate'>";
            fetchQuery += "<attribute name = 'rsa_rate'/>";
            fetchQuery += "<attribute name = 'rsa_currencyid'/>";
            fetchQuery += "<attribute name = 'rsa_exchangerateid'/>";
            fetchQuery += "<filter type = 'and'> ";
            fetchQuery += "<condition attribute = 'rsa_conversionidname' operator= 'like' value = '%" + conversionIdsSet + "%'/>";
            fetchQuery += "<condition attribute = 'rsa_currencyid' operator= 'eq' value = '" + currencyid + "' />";
            fetchQuery += "</filter>";
            fetchQuery += "</entity>";
            fetchQuery += "</fetch>";
            EntityCollection exchangeRates = service.RetrieveMultiple(new FetchExpression(fetchQuery));
            return exchangeRates;
        }
        public static EntityCollection GetCutomLabelDetails(IOrganizationService service, string prm1, string prm2, string prm3)
        {
            string fetchQuery = "<fetch mapping = 'logical'>";
            fetchQuery += "<entity name = 'rsa_customlabel'>";
            fetchQuery += "<attribute name = 'rsa_name'/>";
            fetchQuery += "<attribute name = 'rsa_values'/>";
            fetchQuery += "<filter type = 'and'> ";
            fetchQuery += "<filter type = 'or'> ";
            if (!string.IsNullOrEmpty(prm1))
                fetchQuery += "<condition attribute = 'rsa_name' operator= 'eq' value = '" + prm1 + "'/>";
            if (!string.IsNullOrEmpty(prm2))
                fetchQuery += "<condition attribute = 'rsa_name' operator= 'eq' value = '" + prm2 + "'/>";
            if (!string.IsNullOrEmpty(prm3))
                fetchQuery += "<condition attribute = 'rsa_name' operator= 'eq' value = '" + prm3 + "'/>";
            fetchQuery += "</filter>";
            fetchQuery += "</filter>";
            fetchQuery += "</entity>";
            fetchQuery += "</fetch>";
            EntityCollection customLabel = service.RetrieveMultiple(new FetchExpression(fetchQuery));
            return customLabel;
        }
    }


    [DataContract]
    public class TradingSitetoRegion
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public int? PolicyValue { get; set; }
        [DataMember]
        public int OpportunityValue { get; set; }
    }

    [DataContract]
    public class TradingSitetoRegionRoot
    {
        [DataMember]
        public List<TradingSitetoRegion> TradingSitetoRegion { get; set; }
    }

   // [DataContract]
    public class OptionSet
    {
      //  [DataMember]
        public string DependentField { get; set; }
        //[DataMember]
        public string ApplicableValue { get; set; }
    }

    public class LookUp
    {
    }

    [DataContract]
    public class DecimalCurrencyfield
    {
        [DataMember]
        public string DependentField { get; set; }
        [DataMember]
        public int DefaultValue { get; set; }
        [DataMember]
        public string DataType { get; set; }
    }

    [DataContract]
    public class ParentFieldDependency
    {
        [DataMember]
        public List<OptionSet> OptionSet { get; set; }
        [DataMember]
        public List<LookUp> LookUp { get; set; }
        [DataMember]
        public List<DecimalCurrencyfield> DecimalCurrencyfields { get; set; }
    }

    [DataContract]
    public class RSAcustomlabelJson
    {
        [DataMember]
        public string ParentField { get; set; }
        [DataMember]
        public List<ParentFieldDependency> ParentFieldDependency { get; set; }
    }
}