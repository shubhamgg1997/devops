﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using RSA.Crm.Plugins;
using System;
using System.Collections.Generic;
using System.ServiceModel;
namespace RSA.CSI.Plugin.Email
{
    public class EmailUpdate : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService tracer = null;
            IPluginExecutionContext context = null;
            IOrganizationService service = null;

            CrmPluginHelper.Initialise(serviceProvider, ref context, ref service, ref tracer, false);
            if (context.Depth > 1)
            {
                return;
            }

            if ((context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity) && context.MessageName.ToLowerInvariant() == "update" && context.Stage == 20)
            {
                try
                {
                    tracer.Trace("Instace created and target is avaialble.");
                    Entity entity = (Entity)context.InputParameters["Target"];
                 
                    Entity enCase = new Entity();
                    string subject = entity.Attributes.Contains("subject") ? entity.GetAttributeValue<string>("subject") : null;
                    EntityReference regardingObjectId = entity.Attributes.Contains("regardingobjectid") ? entity.GetAttributeValue<EntityReference>("regardingobjectid") : null;

     
                    Entity email = service.Retrieve("email", entity.Id, new ColumnSet("to"));

                    string toAttributeName = string.Empty;


                    if (email.Attributes.Contains("to"))
                    {
                        EntityCollection toAttribute = (EntityCollection)email.Attributes["to"];
                        int count = toAttribute.Entities.Count;
                        int countstart = 0;

                        foreach (Entity item in toAttribute.Entities)
                        {
                            countstart++;
                            if (item.Attributes.Contains("partyid"))
                            {

                                toAttributeName += ((EntityReference)item.Attributes["partyid"]).Name;

                                if (countstart < count)
                                {
                                    toAttributeName += ',';
                                }
                            }

                        }


                    }

                    if (subject != null && subject.Contains("ref:"))
                    {
                        enCase = EmailUpdate.getCaseData(service, tracer, regardingObjectId.Id);
                        enCase["rsa_toaddress"] = toAttributeName;
                    }
                    if (toAttributeName != null && toAttributeName.ToLowerInvariant().Equals("bluefin.shopweb@uk.rsagroup.com"))
                    {
                        enCase["rsa_casereasonrsa"] = new OptionSetValue(866760054);
                    }
                    if (enCase != null)
                        service.Update(enCase);
                }
                catch (Exception ex)
                {

                    //throw ex;
                    //Remediation - 20/07/2022
                    throw new InvalidPluginExecutionException(ex.Message);
                }
            }
        }


        ///////////Function Definition////////////////
        public static Entity getCaseData(IOrganizationService service, ITracingService tracer, Guid guid)
        {
            try
            {
                Entity Case = new Entity();


                string fetchQuery = "< fetch distinct = 'false' mapping = 'logical'/>";
                fetchQuery += "<entity name = 'incident'>";

                fetchQuery += "<attribute name = 'ticketnumber'/>";
                fetchQuery += "<attribute name = 'incidentid'/>";
                fetchQuery += "<attribute name = 'rsa_toaddress'/>";
                fetchQuery += "<attribute name = 'rsa_casereasonrsa'/>";
                fetchQuery += "<order descending = 'false' attribute = 'title'/>";
                fetchQuery += "< filter type = 'and' >";
                fetchQuery += "<condition attribute = 'incidentid' operator= 'eq' value = '" + guid + "'/>";
                fetchQuery += " </filter >";
                fetchQuery += " </entity >";
                fetchQuery += "</fetch >";
                EntityCollection encase = service.RetrieveMultiple(new FetchExpression(fetchQuery));
                if (encase != null && encase.Entities.Count > 0)
                {
                    Case = encase.Entities[0];
                }
                return Case;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
}