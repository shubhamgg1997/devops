﻿using Microsoft.Xrm.Sdk;
using System;
using System.ServiceModel;

namespace RSA.Crm.Plugins
{
    public static class CrmPluginHelper
    {
        public static string MESSAGE_PreEntityNotRegistered = "{0} plug-in requires a pre entity image to be registered.";
        public static string MESSAGE_PostEntityNotRegistered = "{0} plug-in requires a post entity image to be registered.";

        public enum EntityStateCode
        {
            Active = 0,
            Inactive = 1
        }

        public static EntityReference GetEntityMoniker(IPluginExecutionContext context)
        {
            return context.InputParameters.Contains("EntityMoniker")
                ? ((EntityReference)context.InputParameters["EntityMoniker"])
                : null;
        }

        public static OptionSetValue GetEntityStatus(IPluginExecutionContext context)
        {
            return context.InputParameters.Contains("Status")
                ? (OptionSetValue)context.InputParameters["Status"]
                : null;
        }

        public static OptionSetValue GetEntityState(IPluginExecutionContext context)
        {
            return context.InputParameters.Contains("State")
                ? (OptionSetValue)context.InputParameters["State"]
                : null;
        }

        public static T GetEntity<T>(IPluginExecutionContext context) where T : Entity
        {
            Entity entity = null;
            if (context.InputParameters["Target"] is EntityReference)
            {
                var entityReference = ((EntityReference)context.InputParameters["Target"]);
                entity = new Entity(entityReference.LogicalName) { Id = entityReference.Id };
                return entity.ToEntity<T>();
            }
            if (context.InputParameters.Contains("Target"))
            {
                entity = (Entity)context.InputParameters["Target"];
            }

            return entity.ToEntity<T>();
        }

        public static T GetPreEntity<T>(IPluginExecutionContext context) where T : Entity
        {
            return context.InputParameters.Contains("Target") && context.PreEntityImages.Contains("PreImage")
                       ? context.PreEntityImages["PreImage"].ToEntity<T>()
                       : null;
        }

        public static T GetPostEntity<T>(IPluginExecutionContext context) where T : Entity
        {
            return context.InputParameters.Contains("Target") && context.PostEntityImages.Contains("PostImage")
                       ? context.PostEntityImages["PostImage"].ToEntity<T>()
                       : null;
        }

        public static void Initialise(
            IServiceProvider serviceProvider,
            ref IPluginExecutionContext context,
            ref IOrganizationService organizationService,
            ref ITracingService tracingService,
            bool asAdmin)
        {
            // Context
            context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            if (context == null)
            {
                throw new InvalidPluginExecutionException(@"Could not get IPluginExecutionContext from IServiceProvider passed into Plugin.\nPlease contact your system administrator with this screenshot.");
            }

            //((Microsoft.Crm.Extensibility.PipelineExecutionContext)context).ProxyTypesAssembly = typeof(XrmServiceContext).Assembly;

            // Service
            var serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            if (serviceFactory == null)
            {
                throw new InvalidPluginExecutionException(@"Could not get IOrganizationServiceFactory from IServiceProvider passed into Plugin.\nPlease contact your system administrator with this screenshot.");
            }

            organizationService = asAdmin
                                      ? serviceFactory.CreateOrganizationService(null)
                                      : serviceFactory.CreateOrganizationService(context.UserId);

            if (organizationService == null)
            {
                throw new InvalidPluginExecutionException(@"Could not get IOrganizationService from IServiceProvider passed into Plugin.\nPlease contact your system administrator with this screenshot.");
            }

            // Tracing service
            tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            if (tracingService == null)
            {
                throw new InvalidPluginExecutionException(@"Could not get ITracingService from IServiceProvider passed into Plugin.\nPlease contact your system administrator with this screenshot.");
            }
        }

        public static void CatchFaultException(FaultException<OrganizationServiceFault> ex, object o)
        {
            var error =
                string.Format(
                    "An error occurred at " + o.GetType() + " as OrganizationServiceFault in the plug-in.\nPlease contact your system administrator with this screenshot.\nError Message:{0}",
                    ex.Message);
            throw new InvalidPluginExecutionException(error);
        }

        public static void CatchFaultException(FaultException<OrganizationServiceFault> ex, ITracingService tracingService, object o)
        {
            var error =
                string.Format(
                    "An error occurred at " + o.GetType() + " as OrganizationServiceFault in the plug-in.\nPlease contact your system administrator with this screenshot.\nError Message:{0}",
                    ex.Message);
            tracingService.Trace("An error occurred at " + o.GetType() + " as OrganizationServiceFault in the plug-in.\nPlease contact your system administrator with this screenshot.\nError Message:{0}\n{1}",
                    ex.Message,
                    ex.StackTrace);
            throw new InvalidPluginExecutionException(error);
        }

        public static void CatchGenericException(Exception ex, object o)
        {
            var error =
                string.Format("An error occurred at " + o.GetType() + " plug-in.\nPlease contact your system administrator with this screenshot.\nError Message:{0}",
                ex.Message);
            throw new InvalidPluginExecutionException(error);
        }

        public static void CatchGenericException(Exception ex, ITracingService tracingService, object o)
        {
            var error =
                string.Format("An error occurred at " + o.GetType() + " plug-in.\nPlease contact your system administrator with this screenshot.\nError Message:{0}",
                ex.Message);

            tracingService.Trace("An error occurred at " + o.GetType() + " plug-in.\nPlease contact your system administrator with this screenshot.\nError Message:{0}\n{1}",
                    ex.Message,
                    ex.StackTrace);
            throw new InvalidPluginExecutionException(error);
        }

        public static void CatchInvalidPluginException(InvalidPluginExecutionException ex)
        {
            var error = string.Format("{0}.\n\n", ex.Message);
            throw new InvalidPluginExecutionException(error);
        }
    }
}
