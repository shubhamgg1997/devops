﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSA.CSI.Plugins.Request
{
    public class SetTargetDates : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            // Obtain the tracing service
            ITracingService tracingService =
            (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            // Obtain the execution context from the service provider.  
            IPluginExecutionContext context = (IPluginExecutionContext)
                serviceProvider.GetService(typeof(IPluginExecutionContext));

            // The InputParameters collection contains all the data passed in the message request.  
            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                tracingService.Trace("Before Try");

                // Obtain the target entity from the input parameters.  
                Entity entity = (Entity)context.InputParameters["Target"];
                //if (context.MessageName.ToLower().Equals("create"))
                //{
                //  Entity entity = (Entity)context.InputParameters["Target"];
                //}
                //else if (context.MessageName.ToLower().Equals("update"))
                //{
                //   Entity postImageentity = (Entity)context.PostEntityImages["PostImage"];
                //}

                // Obtain the organization service reference which you will need for  
                // web service calls.  
                IOrganizationServiceFactory serviceFactory =
                    (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
                tracingService.Trace("Before Try");
                try
                {

                    tracingService.Trace("In Try");
                    TimeSpan diffInDays = entity.GetAttributeValue<DateTime>("createdon").AddDays(1) - new DateTime(7 / 1 / 1900);
                    int totalDays = (int)Math.Floor(diffInDays.TotalDays);
                    tracingService.Trace("Difference in days : " + totalDays);
                    int modOfDaysBy7 = totalDays % 7;
                    tracingService.Trace("Mod of days by 7 : " + modOfDaysBy7);

                    DateTime setCreatedDatePlus7 = entity.GetAttributeValue<DateTime>("createdon").AddDays(7);//mm/dd/yyyy
                    DateTime setCreatedDatePlus3 = entity.GetAttributeValue<DateTime>("createdon").AddDays(3);
                    DateTime setCreatedDatePlus2 = entity.GetAttributeValue<DateTime>("createdon").AddDays(2);
                    DateTime setCreatedDatePlus1 = entity.GetAttributeValue<DateTime>("createdon").AddDays(1);
                    DateTime setCreatedDatePlus083 = entity.GetAttributeValue<DateTime>("createdon").AddDays(0.0833333);

                    tracingService.Trace("Set created Date plus 7: " + setCreatedDatePlus7);
                    tracingService.Trace("Set created Date plus 3: " + setCreatedDatePlus3);
                    tracingService.Trace("Set created Date plus 2: " + setCreatedDatePlus2);
                    tracingService.Trace("Set created Date plus 1: " + setCreatedDatePlus1);
                    tracingService.Trace("Set created Date plus 0.0833333 : " + setCreatedDatePlus083);

                    if (modOfDaysBy7 == 6)
                    {
                        tracingService.Trace("Request type : 1");
                        entity["rsa_initialanalysistargetdate"] = setCreatedDatePlus2;//dd/mm/yyyy
                    }
                    else if (modOfDaysBy7 == 0)
                    {
                        tracingService.Trace("Request type : 2");
                        entity["rsa_initialanalysistargetdate"] = setCreatedDatePlus2;
                    }
                    else
                    {
                        tracingService.Trace("Request type : 3");
                        entity["rsa_initialanalysistargetdate"] = setCreatedDatePlus1;
                    }
                    tracingService.Trace("Request type : ");
                    //string requestTypeOption = entity.FormattedValues.ContainsKey("rsa_requesttype") ? entity.FormattedValues["rsa_requesttype"] : null;
                    var requestTypeOption = entity.Attributes.Contains("rsa_requesttype") ? ((OptionSetValue)entity.Attributes["rsa_requesttype"]).Value : -1;

                    tracingService.Trace("Request type : " + requestTypeOption);
                    
                    switch (requestTypeOption)
                    {
                        //User: New User Request 866760008
                        case 866760008:
                            entity["rsa_targetcompletion"] = setCreatedDatePlus2;
                            break;
                        //User: User Modification 866760011
                        case 866760011:
                            entity["rsa_targetcompletion"] = setCreatedDatePlus2;
                            break;
                        //  User: Team Change  866760010
                        case 866760010:
                            entity["rsa_targetcompletion"] = setCreatedDatePlus2;
                            break;
                        // User: Deactivation 866760007
                        case 866760007:
                            entity["rsa_targetcompletion"] = setCreatedDatePlus2;
                            break;
                        // User: Password Reset   866760009
                        case 866760009:
                            entity["rsa_targetcompletion"] = setCreatedDatePlus083;
                            break;
                        // Change Request 866760001
                        case 866760001:
                            entity["rsa_targetcompletion"] = setCreatedDatePlus7;
                            break;
                        // System Issue   866760005
                        case 866760005:
                            entity["rsa_targetcompletion"] = setCreatedDatePlus7;
                            break;
                        //System Query   866760006
                        case 866760006:
                            entity["rsa_targetcompletion"] = setCreatedDatePlus2;
                            break;
                        default:
                            entity["rsa_targetcompletion"] = setCreatedDatePlus2;
                            break;
                    }

                    //  service.Update(entity);
                }
                catch (Exception ex)
                {
                    tracingService.Trace("SetTargetDatePlugin: {0}", ex.Message);
                    //throw;
                    //Remediation - 20/07/2022
                    throw new InvalidPluginExecutionException(ex.Message);
                }
            }
        }
    }
}
